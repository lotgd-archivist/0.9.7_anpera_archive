<?php
// commonroom module
// ModulAuthor: Kevz <webmaster@lotgd.dyndns.biz>
// Author: Chaosmaker <webmaster@chaosonline.de>

// all function names MUST end with the module's name (as in $info['modulename'])!!!
function module_getinfo_library() {
	$info = array(
					'modulename'=>'library', 		// internal name; use letters, numbers and underscores only!
					'modulefile'=>basename(__FILE__), 				// filename of the module; if you allow to rename the script, do NOT change this!
					'moduleauthor'=>'`2K`@e`2v`@z', 				// the author's name
					'moduleversion'=>'1.0',							// the module's version number
					'built_in'=>'1',										// '1', if each house should have this module built-in; otherwise '0'
					'linkcategory'=>'Zimmer',						// the category (in houses.php's menu) under which the link to this module should be shown
					'linktitle'=>'Bibliothek',					// the link title of the module
					'showto'=>'owner,guest'								// who should use this module? possible options: 'owner', 'guest' and 'owner,guest'
	);
	return $info;
}

function module_install_library() {
	// insert data into module table - do NOT change this (well... just change the function name ;))!
	$info = module_getinfo_library();
	$sql = "INSERT INTO housemodules
				(modulefile, modulename, moduleversion, moduleauthor, built_in, linkcategory, linktitle, showto)
				VALUES ('{$info['modulefile']}','{$info['modulename']}','{$info['moduleversion']}','{$info['moduleauthor']}','{$info['built_in']}','{$info['linkcategory']}','{$info['linktitle']}','{$info['showto']}')";
	db_query($sql);
	$moduleid = db_insert_id(LINK);

	// insert global module data (you can add several entries - but do NOT
	// change anything else than "FieldName" and FieldValue"!)

	// here you can change everything else needed (e.g. adding settings)
	// be careful: these changes must be global; per-house-changes will be done
	// in module_build()!
}

function module_uninstall_library() {
	// uninstalling the module
	// this function should also contain all module_destroy contents

	// getting moduleid - do NOT change this (same as above... the function name should be changed)!
	$info = module_getinfo_library();
	$moduleid = getmoduleid($info['modulename']);

	// deleting module from db - do NOT change this!
	$sql = 'DELETE FROM housemodules WHERE moduleid='.$moduleid;
	db_query($sql);

	// deleting internal module data - do NOT change this!
	$sql = 'DELETE FROM housemoduledata WHERE moduleid='.$moduleid;
	db_query($sql);

	// here you should delete all other added things (e.g. settings) of this module
}

function module_build_library($houseid) {
	// this is only needed if 'built_in' in module_info() is set to 0

	// getting moduleid - do NOT change this (function name... blablabla)!
	$info = module_getinfo_library();
	$moduleid = getmoduleid($info['modulename']);

	// setting flag for house - do NOT change this!
	$sql = 'INSERT INTO housemoduledata (moduleid, name, houseid, value)
				VALUES ('.$moduleid.',"#activated#",'.$houseid.',"1")';
	db_query($sql);

	// here you can change everything else needed (e.g. changing user settings)
	// be careful: these changes must be for this house only; global changes will be done
	// in module_install()!
}

function module_destroy_library($houseid) {
	// this is only needed if 'built_in' in module_info() is set to 0

	// getting moduleid - do NOT change this (function name... moooooooooh!)!
	$info = module_getinfo_library();
	$moduleid = getmoduleid($info['modulename']);

	// deleting module data of this house - do NOT change this!
	$sql = 'DELETE FROM housemoduledata WHERE moduleid='.$moduleid.' AND houseid='.$houseid;
	db_query($sql);

	// here you should delete all other added things (e.g. user settings) of this module and house
}

function module_show_library() {
	// this is the main part of the module where all output is done ;)
	// don't forget the navs; only the default module does not need them (but may add some)
	// to return to the main module, use this link: houses.php?op=drin&module (without id!)
	global $session;
	
	$sql = 'SELECT houses.housename, houses.owner FROM houses LEFT JOIN accounts ON accounts.acctid=houses.owner WHERE houses.houseid='.$session['user']['specialmisc']['houseid'];
	$result = db_query($sql) or die(db_error(LINK));
	$row = db_fetch_assoc($result);

	output("`2`b`c$row[housename] `2 (In der Bibliothek)`c`b`n`n");


	addnav("B�cher");
	addnav("Alles �ber Gartenteiche","houses.php?op=drin&act=teiche");
	addnav("Drachent�ter in 10 Tagen","houses.php?op=drin&act=dragon");
	addnav("Kama Sutra","houses.php?op=drin&act=kama");
	addnav("Kochen f�r Helden","houses.php?op=drin&act=kochen");
	addnav("Necrotelicomnicon","houses.php?op=drin&act=necro");
	addnav("The Dark Tower I-VII","houses.php?op=drin&act=the");
	addnav("Zur�ck");
	addnav("Zur�ck zum Haus","houses.php?op=drin&module=");
		
	if($_GET[act]==""){
	
		output("`2In der Bibliothek steht eine Couch, auf der Du es Dir bequem machen kannst, sobald Du Dir eine Buch ausgesucht hast. Und nat�rlich ein B�cherschrank an der Wand, in den bereits die ersten B�cher einger�umt sind.`n`n");

	} elseif ($_GET[act]=="teiche"){
	
		output("`2Irgendwie steht Dir der Sinn heute nicht nach Do-It-Yourself-Lekt�ren, deswegen legst Du das Buch fast schneller wieder weg, als Du es herausgenommen hast.");
	
	} elseif ($_GET[act]=="dragon") {
	
		output("`2In nur 10 Tagen soweit zu sein, den Drachen zu t�ten? Das klingt allerdings vielversprechend! Allerdings auch irgendwie ein wenig unwirklich... nur 10 Tage? Ne, das glaubst Du nicht und l��t das Buch erstmal im Schrank stehen.");
	
	} elseif ($_GET[act]=="kama") {
	
		output("`2Du nimmst das Kama Sutra und verziehst dich damit in eine dunkle Ecke, um dich von den Bildern und Beschreibungen anregen zu lassen.`n"
			  ."Ob Du wohl von diesem Buch erz�hlen solltest?");
	
	} elseif ($_GET[act]=="kochen") {
	
		output("`2Du nimmst das Helden-Kochbuch aus dem Regal und schl�gst eine zuf�llige Seite auf.`n`n"
		  	  ."`&Mole Poblano`n`n`^"
		  	  ."6 Chile ancho (s��-scharf)`n"
		  	  ."4 Chile pasilla (mild)`n"
		  	  ."4 Chile mulato (rauchig, s��-scharf)`n"
		  	  ."2 Chipotle-Chilies (ger�ucherte Japalenos)`n`n"
		  	  ."Die Chilies entkernen und zerkleinern. Sollten die Chilies zu scharf sein, Wasser kochen und dr�bergiessen, dann 30 Minuten stehen lassen.`n`n"
		  	  ."1 Tasse Mandeln`n"
		  	  ."1 Tasse Erdn�sse`n"
		  	  ."4 EL Sesam`n"
		  	  ."1/4 TL Nelken, gemahlen`n"
		  	  ."1 TL Anis`n"
		  	  ."1/2 TL Zimt`n"
		  	  ."6 Tomaten (oder 400g-Dose)`n`n"
		  	  ."Vermischen und p�rieren.`n`n"
		  	  ."1 EL Fett erhitzen und die p�rierte Masse dazugeben. 5 Minuten anschwitzen, dann 2 Tassen Br�he dar�bergeben. 90g Schokolade (Kuvert�re, Kochschokolade, etc.) unterr�hren. Mit Salz & Pfeffer & Zucker w�rzen. Die Konsistenz sollte �hnlich wie fl�ssige Sahne sein.`n`n"
		  	  ."`2Du �berlegst, ob Du Dir das merken und in der K�che ausprobieren solltest oder besser doch nicht...");
	
	} elseif ($_GET[act]=="necro") {
	
		output("`2Du nimmst das Nekrotelicomnicon aus dem Schrank und schaust Dir den Umschlag an. Doch irgendwie will es Dir nicht gelingen, dich auf die Bilder zu konzentrieren - sie verschwimmen immer wieder direkt vor Deinen Augen, wenn Du gerade glaubst Du h�ttest Sie verstanden. Du mu�t Dir selber eingestehen, dass die Dunklen K�nste nicht gerade Dein Spezialgebiet sind und stellt das Buch lieber wieder in den Schrank.");
	
	} elseif ($_GET[act]=="the") {
	
		output("`2Du nimmst dir Band I, und liest die ersten 50 Seiten. Dabei stellst du fest, wie fesselnd dieses Mammutwerk ist. Schnell stellst du es wieder zur�ck, bevor du nicht mehr davon loskommst. Denn dann m�sstest du alle 7 B�nde lesen und h�ttest die n�chsten Tage und Wochen keine Zeit mehr, Drachen zu t�ten.");
	
	}
		$sql = "SELECT name,description FROM items WHERE value1={$session['user']['specialmisc']['houseid']} AND class='M�bel' ORDER BY class,id ASC";
	$result = db_query($sql) or die(db_error(LINK));
	 for ($i=1;$i<=db_num_rows($result);$i++){
		$item = db_fetch_assoc($result);
			if ($item[name]=="Lesesessel") output("`n`6Lesesessel`0 (`i$item[description]`i)");
			if ($item[name]=="Beistelltisch") output("`n`6Beistelltisch`0 (`i$item[description]`i)");
			if ($item[name]=="Priemel") output("`n`6Priemel`0 (`i$item[description]`i)");
			if ($item[name]=="Gem�lde Eythgim") output("`n`6Gem�lde Eythgim`0 (`i$item[description]`i)");
	}
	// uncomment these lines if you want to show the default navs even if this is not the default module
	// global $shownavs;
	// $shownavs = true;

	// uncomment these lines if you want to hide the default navs even if this is the default module
	// global $shownavs;
	// $shownavs = false;
}
?>