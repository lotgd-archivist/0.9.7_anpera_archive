<?php
// default module template
// use this to create modules for houses
// Author: Chaosmaker <webmaster@chaosonline.de>

// all function names MUST end with the module's name (as in $info['modulename'])!!!
// hint: use search&replace ;) replace 'private_chamber' with your module's (internal) name.
function module_getinfo_private_chamber() {
	$info = array(
					'modulename'=>'private_chamber', 		// internal name; use letters, numbers and underscores only!
					'modulefile'=>basename(__FILE__), 	// filename of the module; if you allow to rename the script, do NOT change this!
					'moduleauthor'=>'Chaosmaker', 			// the author's name
					'moduleversion'=>'1.0',			// the module's version number
					'built_in'=>'1',				// '1', if each house should have this module built-in; otherwise '0'
					'linkcategory'=>'Weitere R�ume',			// the category (in houses.php's menu) under which the link to this module should be shown
					'linktitle'=>'Privatgemach',			// the link title of the module
					'showto'=>'owner,guest'						// who should use this module? possible options: 'owner', 'guest' and 'owner,guest'
	);
	return $info;
}

function module_install_private_chamber() {
	// insert data into module table - do NOT change this (well... just change the function name ;))!
	$info = module_getinfo_private_chamber();
	$sql = "INSERT INTO housemodules
				(modulefile, modulename, moduleversion, moduleauthor, built_in, linkcategory, linktitle,showto)
				VALUES ('{$info['modulefile']}', '{$info['modulename']}', '{$info['moduleversion']}', '{$info['moduleauthor']}', '{$info['built_in']}', '{$info['linkcategory']}', '{$info['linktitle']}', '{$info['showto']}')";
	db_query($sql);
	$moduleid = db_insert_id(LINK);

	// insert global module data (you can add several entries - but do NOT
	// change anything else than "FieldName" and "FieldValue"!)
	/*
	$sql = 'INSERT INTO housemoduledata (moduleid, name, houseid, value)
				VALUES ('.$moduleid.',"FieldName",0,"FieldValue")';
	db_query($sql);
	*/
	/* install_moduledata begin */

/* install_moduledata end */

	// here you can change everything else needed (e.g. adding settings)
	// be careful: these changes must be global; per-house-changes will be done
	// in module_build()!
	/* install_other begin */

/* install_other end */
}

function module_uninstall_private_chamber() {
	// uninstalling the module
	// this function should also contain all module_destroy contents

	// getting moduleid - do NOT change this (same as above... the function name should be changed)!
	$info = module_getinfo_private_chamber();
	$moduleid = getmoduleid($info['modulename']);

	// deleting module from db - do NOT change this!
	$sql = 'DELETE FROM housemodules WHERE moduleid='.$moduleid;
	db_query($sql);

	// deleting internal module data - do NOT change this!
	$sql = 'DELETE FROM housemoduledata WHERE moduleid='.$moduleid;
	db_query($sql);

	// here you should delete all other added things (e.g. settings) of this module
	/* delete_other begin */

/* delete_other end */
}

function module_build_private_chamber($houseid) {
	// this is only needed if 'built_in' in module_info() is set to 0

	// getting moduleid - do NOT change this (function name... blablabla)!
	$info = module_getinfo_private_chamber();
	$moduleid = getmoduleid($info['modulename']);

	// setting flag for house - do NOT change this!
	$sql = 'INSERT INTO housemoduledata (moduleid, name, houseid, value)
				VALUES ('.$moduleid.',"#activated#",'.$houseid.',"1")';
	db_query($sql);

	// here you can change everything else needed (e.g. changing user settings)
	// be careful: these changes must be for this house only; global changes will be done
	// in module_install()!
	/* build_other begin */

/* build_other end */
}

function module_destroy_private_chamber($houseid) {
	// this is only needed if 'built_in' in module_info() is set to 0

	// getting moduleid - do NOT change this (function name... moooooooooh!)!
	$info = module_getinfo_private_chamber();
	$moduleid = getmoduleid($info['modulename']);

	// deleting module data of this house - do NOT change this!
	$sql = 'DELETE FROM housemoduledata WHERE moduleid='.$moduleid.' AND houseid='.$houseid;
	db_query($sql);

	// here you should delete all other added things (e.g. user settings) of this module and house
	/* destroy_other begin */

/* destroy_other end */
}

function module_show_private_chamber() {
	// this is the main part of the module where all output is done ;)
	// don't forget the navs; only the default module does not need them (but may add some)
	// to return to the main module, use this link: houses.php?op=drin&module (without id!)
	// don't forget 'global $session;' if you need the player's data (and you WILL need them!)
   
   /* content_show begin */
	global $session;

	addcommentary();

	$sql = 'SELECT owner FROM houses WHERE houseid='.$session['user']['specialmisc']['houseid'];
	$result = db_query($sql);
	$row = db_fetch_assoc($result);
	// falls eigentuemer oder partner
	if ($session['user']['house']==$session['user']['specialmisc']['houseid'] || $session['user']['marriedto']==$row['owner']){
		output('`qDu trittst durch eine unscheinbare T�r in dein privates Schlafgemach. Es ist angenehm warm, kein Wunder, denn in dem sch�n verzierten Kamin in der Ecke prasselt ein kleines Feuer. Auf einem steinernen Vorsprung der Mauer, der mehr schon eine Bank zu sein scheint, liegt zusammengefaltet ein gro�es, kuscheliges Fell, wohl eine Erinnerung an deinen letzten Jagdausflug.`n');
		output('Die andere Ecke des Raumes nimmt dein gro�es, mit Holzschnitzereien versehenes Himmelbett ein. Die seidenen Vorh�nge sind ge�ffnet und geben den Blick frei auf rote, mit Goldf�den bestickte Kissen. Du �berlegst, was dich mehr anzieht, das Fell vor dem Kamin, die Steinbank oder dein gem�tliches Bett, entscheidest dich dann aber, zuerst ein wenig im Zuber des angrenzenden Bads zu planschen.`n');
		// Verheiratet?
		if($session['user']['charisma']==4294967295) output('Du h�rst Ger�usche vor der T�r und hoffst, dass '.($session['user']['sex']?'dein Liebster':'deine Liebste').' inzwischen heimgekommen ist.`n');
		output('`n');
		addnav("Einschlafen","houses.php?op=drin&act=logout"); viewcommentary("private-".$session['user']['specialmisc']['houseid'],($session['user']['sex']?"Deinem":"Deiner")." Liebsten zufl�stern:",50,"fl�stert");
	} else { // jeder andere
		output("Du r�ttelst ein wenig an der T�r - verschlossen.`n");
		output("Tja, in den Privatgem�chern hast du eben nichts zu suchen.");
	}
	addnav("Zur�ck zum Haus","houses.php?op=drin&module=");
	$sql = "SELECT name,description FROM items WHERE value1={$session['user']['specialmisc']['houseid']} AND class='M�bel' ORDER BY class,id ASC";
	$result = db_query($sql) or die(db_error(LINK));
	 for ($i=1;$i<=db_num_rows($result);$i++){
		$item = db_fetch_assoc($result);
			if ($item[name]=="Himmelbett") output("`n`6Himmelbett`0 (`i$item[description]`i)");
			if ($item[name]=="Baldachin") output("`n`6Baldachin f�r das Himmelbett`0 (`i$item[description]`i)");
			if ($item[name]=="Daunendecke") output("`n`6Daunendecke`0 (`i$item[description]`i)");
			if ($item[name]=="Daunenkissen") output("`n`6Daunenkissen`0 (`i$item[description]`i)");
			if ($item[name]=="Mehrarmiger Kerzenst�nder") output("`n`6Mehrarmiger Kerzenst�nder`0 (`i$item[description]`i)");
			if ($item[name]=="Kleiderschrank") output("`n`6Kleiderschrank`0 (`i$item[description]`i)");
			if ($item[name]=="Teppich") output("`n`6Teppich`0 (`i$item[description]`i)");
			if ($item[name]=="Kleines Ledersofa") output("`n`6Kleines Ledersofa`0 (`i$item[description]`i)");
			if ($item[name]=="Diwan") output("`n`6Diwan`0 (`i$item[description]`i)");
			if ($item[name]=="Hoher Sessel") output("`n`6Hoher Sessel`0 (`i$item[description]`i)");
			if ($item[name]=="Fusschemel") output("`n`6Fusschemel`0 (`i$item[description]`i)");
			if ($item[name]=="Beistelltischchen") output("`n`8Beistelltischchen`0 (`i$item[description]`i)");
			if ($item[name]=="Rosenstock") output("`n`2 Ein Zimmer`\$Rosen`2stock`0 (`i$item[description]`i)");
			if ($item[name]=="Lilie") output("`n`2Eine `&Lilie`0 (`i$item[description]`i)");
			if ($item[name]=="Statue der Aphrodite") output("`n`6Statue der Aphrodite`0 (`i$item[description]`i)");
			if ($item[name]=="Pl�schdrachen") output("`n`6Pl�schdrachen`0 (`i$item[description]`i)");
			if ($item[name]=="Freundschaftsanh�nger") output("`n`6Freundschaftsanh�nger`0 (`i$item[description]`i)");
			if ($item[name]=="Freundschaftsb�ndchen") output("`n`6Freundschaftsb�ndchen`0 (`i$item[description]`i)");
			if ($item[name]=="Beutel Heilkr�uter") output("`n`6Beutel Heilkr�uter`0 (`i$item[description]`i)");
			if ($item[name]=="Halskette") output("`n`6Halskette`0 (`i$item[description]`i)");
			if ($item[name]=="Ehering aus Silber") output("`n`6Ehering aus Silber`0 (`i$item[description]`i)");
			if ($item[name]=="Ehering aus Gold") output("`n`6Ehering aus Gold`0 (`i$item[description]`i)");
			if ($item[name]=="Reich verzierter Ehering aus Gold mit Diamantsplittern") output("`n`6Reich verzierter Ehering aus Gold mit Diamantsplittern`0 (`i$item[description]`i)");
	}
    if ($_GET[act]=="logout"){ 

        if ($session['user']['housekey']!=$session['user']['specialmisc']['houseid']) { 
            $sql = "UPDATE items SET hvalue=".$session['user']['specialmisc']['houseid']." WHERE value1=".(int)$session['user']['specialmisc']['houseid']." AND owner=".$session['user']['acctid']." AND class='Schl�ssel'"; 
            db_query($sql) or die(sql_error($sql)); 
        } 
        debuglog("logged out in a house "); 
        $sql = "UPDATE accounts SET loggedin=0,location=2 WHERE acctid = ".$session['user']['acctid']; 
        db_query($sql) or die(sql_error($sql)); 
        $session=array(); 
        redirect("index.php");
	}
	// uncomment these lines if you want to show the default navs even if this is not the default module
	// global $shownavs;
	// $shownavs = true;

	// uncomment these lines if you want to hide the default navs even if this is the default module
	// global $shownavs;
	// $shownavs = false;
/* content_show end */
}
?>