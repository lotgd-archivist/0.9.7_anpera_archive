<?php
// kitchen module
// ModulAuthor: Kevz <webmaster@lotgd.dyndns.biz>
// Author: Chaosmaker <webmaster@chaosonline.de>

// all function names MUST end with the module's name (as in $info['modulename'])!!!
function module_getinfo_kitchen() {
	$info = array(
					'modulename'=>'kitchen', 		// internal name; use letters, numbers and underscores only!
					'modulefile'=>basename(__FILE__), 				// filename of the module; if you allow to rename the script, do NOT change this!
					'moduleauthor'=>'`2K`@e`2v`@z', 				// the author's name
					'moduleversion'=>'1.0',							// the module's version number
					'built_in'=>'1',										// '1', if each house should have this module built-in; otherwise '0'
					'linkcategory'=>'Zimmer',						// the category (in houses.php's menu) under which the link to this module should be shown
					'linktitle'=>'K�che',					// the link title of the module
					'showto'=>'owner,guest'								// who should use this module? possible options: 'owner', 'guest' and 'owner,guest'
	);
	return $info;
}

function module_install_kitchen() {
	// insert data into module table - do NOT change this (well... just change the function name ;))!
	$info = module_getinfo_kitchen();
	$sql = "INSERT INTO housemodules
				(modulefile, modulename, moduleversion, moduleauthor, built_in, linkcategory, linktitle, showto)
				VALUES ('{$info['modulefile']}','{$info['modulename']}','{$info['moduleversion']}','{$info['moduleauthor']}','{$info['built_in']}','{$info['linkcategory']}','{$info['linktitle']}','{$info['showto']}')";
	db_query($sql);
	$moduleid = db_insert_id(LINK);

	// insert global module data (you can add several entries - but do NOT
	// change anything else than "FieldName" and FieldValue"!)

	// here you can change everything else needed (e.g. adding settings)
	// be careful: these changes must be global; per-house-changes will be done
	// in module_build()!
}

function module_uninstall_kitchen() {
	// uninstalling the module
	// this function should also contain all module_destroy contents

	// getting moduleid - do NOT change this (same as above... the function name should be changed)!
	$info = module_getinfo_kitchen();
	$moduleid = getmoduleid($info['modulename']);

	// deleting module from db - do NOT change this!
	$sql = 'DELETE FROM housemodules WHERE moduleid='.$moduleid;
	db_query($sql);

	// deleting internal module data - do NOT change this!
	$sql = 'DELETE FROM housemoduledata WHERE moduleid='.$moduleid;
	db_query($sql);

	// here you should delete all other added things (e.g. settings) of this module
}

function module_build_kitchen($houseid) {
	// this is only needed if 'built_in' in module_info() is set to 0

	// getting moduleid - do NOT change this (function name... blablabla)!
	$info = module_getinfo_kitchen();
	$moduleid = getmoduleid($info['modulename']);

	// setting flag for house - do NOT change this!
	$sql = 'INSERT INTO housemoduledata (moduleid, name, houseid, value)
				VALUES ('.$moduleid.',"#activated#",'.$houseid.',"1")';
	db_query($sql);

	// here you can change everything else needed (e.g. changing user settings)
	// be careful: these changes must be for this house only; global changes will be done
	// in module_install()!
}

function module_destroy_kitchen($houseid) {
	// this is only needed if 'built_in' in module_info() is set to 0

	// getting moduleid - do NOT change this (function name... moooooooooh!)!
	$info = module_getinfo_kitchen();
	$moduleid = getmoduleid($info['modulename']);

	// deleting module data of this house - do NOT change this!
	$sql = 'DELETE FROM housemoduledata WHERE moduleid='.$moduleid.' AND houseid='.$houseid;
db_query($sql);

	// here you should delete all other added things (e.g. user settings) of this module and house
}

function module_show_kitchen() {
	// this is the main part of the module where all output is done ;)
	// don't forget the navs; only the default module does not need them (but may add some)
	// to return to the main module, use this link: houses.php?op=drin&module (without id!)
	global $session;

	addcommentary();
	
	$sql = 'SELECT houses.housename, houses.owner FROM houses LEFT JOIN accounts ON accounts.acctid=houses.owner WHERE houses.houseid='.$session['user']['specialmisc']['houseid'];
	$result = db_query($sql) or die(db_error(LINK));
	$row = db_fetch_assoc($result);
	
	$link = "houses.php?op=drin";
	$kitchen = "kitchen-".$session['user']['specialmisc']['houseid'];
	
	output("`2`b`c$row[housename] `2 (In der K�che)`c`b`n`n");
	output("`2Es ist jetzt `^".getgametime()."`2 Uhr, und du befindest dich in der K�che.`n");
	output("Und es ziemlich still in der K�che, du siehst dich ein wenig um und genie�t die ruhige Atmosph�re...`n`n`n");
	
	switch($_GET['act']){
	        
			
		// drinks
			case "saft":
			$saft = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'".$kitchen."',".$session[user][acctid].",'/me `\&holt eine Karaffe voller Orangensaft hervor und sch�ttet ein.')";
	        db_query($saft) or die(db_error(LINK));
	        redirect($link);
			break;
			
			case "tee":
			$tee = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'".$kitchen."',".$session[user][acctid].",'/me `\&hat einen Kessel Tee zubereitet.')";
	        db_query($tee) or die(db_error(LINK));
	        redirect($link);
			break;
			
			case "kaffe":
			$kaffe = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'".$kitchen."',".$session[user][acctid].",'/me `\&hat vor, noch eine Weile wach zu bleiben, und sich deshalb eine Kanne Kaffee zubereitet.')";
	        db_query($kaffe) or die(db_error(LINK));
	        redirect($link);
			break;
			
			case "ale":
			if($session['user']['drunkenness']<=66){
				$ale = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'".$kitchen."',".$session[user][acctid].",'/me `\&ist in Partystimmung und sticht ein F��chen Ale an!')";
	        	db_query($ale) or die(db_error(LINK));
				$session['user']['drunkenness']+=33;
	        	redirect($link);
			} else{
			output("`qDu hast f�r heute genug Getrunken, schlafe erstmal deinen Rausch aus!");
			}
			break;
			
			case "wein":
			if($session['user']['drunkenness']<=76){
				$wein = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'".$kitchen."',".$session[user][acctid].",'/me `\&m�chte etwas feiern und entkorkt eine Flasche leckeren Rotweines.')";
	        	db_query($wein) or die(db_error(LINK));
				$session['user']['drunkenness']+=38;
	        	redirect($link);
			} else{
			output("`qDu hast f�r heute genug Getrunken, schlafe erstmal deinen Rausch aus!");
			}
			break;
			
		// end of drinks
			
			
		// meals
			case "frustuck":
			$frustuck = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'".$kitchen."',".$session[user][acctid].",'/me `\&hat Br�tchen geholt und Eier gekocht. Sobald jemand den Tisch deckt, gibt es Fr�hst�ck!')";
		db_query($frustuck) or die(db_error(LINK)); 
		redirect($link); 
			break;
			
			case "mittagessen":
			$mittagessen = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'".$kitchen."',".$session[user][acctid].",'/me `\&hat Hunger bekommen und einen kurzen Mittagssnack zubereitet.')";
	        db_query($mittagessen) or die(db_error(LINK));
	        redirect($link);
			break;
			
			case "abendessen":
			$abendessen = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'".$kitchen."',".$session[user][acctid].",'/me `\&stellt sich f�r zwei Stunden in die K�che und kocht f�r alle ein herrliches Mahl!')";
	        db_query($abendessen) or die(db_error(LINK));
	        redirect($link);
			break;
			
			case "snack":
			$snack = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'".$kitchen."',".$session[user][acctid].",'/me `\&braucht mal was f�r zwischendurch.')";
	        db_query($snack) or die(db_error(LINK));
	        redirect($link);
			break;
			
		// end of meals
	
	}

	
	viewcommentary("kitchen-".$session['user']['specialmisc']['houseid'],"�ber's Essen plaudern:",20,"sagt");
	
	// kitchen nav
	addnav("Getr�nke");
	addnav("Saft","houses.php?op=drin&act=saft");
	addnav("Tee","houses.php?op=drin&act=tee");
	addnav("Kaffee","houses.php?op=drin&act=kaffe");
	addnav("Ale","houses.php?op=drin&act=ale");
	addnav("Wein","houses.php?op=drin&act=wein");
	addnav("Mahlzeiten");
	addnav("Fr�hst�ck","houses.php?op=drin&act=frustuck");
	addnav("Mittagessen","houses.php?op=drin&act=mittagessen");
	addnav("Abendessen","houses.php?op=drin&act=abendessen");
	addnav("Snack","houses.php?op=drin&act=snack");
	addnav("Vorratslager");
	$sql = "SELECT name,description FROM items WHERE value1={$session['user']['specialmisc']['houseid']} AND class='M�bel' ORDER BY class,id ASC";
	$result = db_query($sql) or die(db_error(LINK));
	 for ($i=1;$i<=db_num_rows($result);$i++){
		$item = db_fetch_assoc($result);
			if ($item[name]=="K�chenschrank")addnav("Essensrationen","kueschrank.php");
			if ($item[name]=="Wasserfass")addnav("Wasserartionen","wafa.php");
	}
	addnav("Zur�ck");
	//end
		$sql = "SELECT name,description FROM items WHERE value1={$session['user']['specialmisc']['houseid']} AND class='M�bel' ORDER BY class,id ASC";
	$result = db_query($sql) or die(db_error(LINK));
	 for ($i=1;$i<=db_num_rows($result);$i++){
		$item = db_fetch_assoc($result);
			if ($item[name]=="K�chenschrank") output("`n`&K�chenschrank`0 (`i$item[description]`i)");
			if ($item[name]=="Wasserfass") output("`n`#Wasserfass`0 (`i$item[description]`i)");
			if ($item[name]=="K�chentisch") output("`n`&K�chentisch`0 (`i$item[description]`i)");
			if ($item[name]=="4 K�chenst�hle") output("`n`&4 K�chenst�hle`0 (`i$item[description]`i)");
			if ($item[name]=="kleines Weinregal") output("`n`4Kleines Weinregal`0 (`i$item[description]`i)");
			if ($item[name]=="K�chenkr�uter") output("`n`2K�c`@hen`2kr`@�u`2ter`0 (`i$item[description]`i)");
	}
	addnav("Zur�ck zum Haus","houses.php?op=drin&module=");

	// uncomment these lines if you want to show the default navs even if this is not the default module
	// global $shownavs;
	// $shownavs = true;

	// uncomment these lines if you want to hide the default navs even if this is the default module
	// global $shownavs;
	// $shownavs = false;
}
?>