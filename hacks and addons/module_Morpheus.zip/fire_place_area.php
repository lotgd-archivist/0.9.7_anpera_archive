<?php
// default module template
// use this to create modules for houses
// Author: Chaosmaker <webmaster@chaosonline.de>

// all function names MUST end with the module's name (as in $info['modulename'])!!!
// hint: use search&replace ;) replace 'fire_place_area' with your module's (internal) name.
function module_getinfo_fire_place_area() {
	$info = array(
					'modulename'=>'fire_place_area', 		// internal name; use letters, numbers and underscores only!
					'modulefile'=>basename(__FILE__), 				// filename of the module; if you allow to rename the script, do NOT change this!
					'moduleauthor'=>'Hadriel', 				// the author's name
					'moduleversion'=>'0.1b',							// the module's version number
					'built_in'=>'1',										// '1', if each house should have this module built-in; otherwise '0'
					'linkcategory'=>'Zimmer',						// the category (in houses.php's menu) under which the link to this module should be shown
					'linktitle'=>'Kaminraum',				// the link title of the module
					'showto'=>'owner,guest'								// who should use this module? possible options: 'owner', 'guest' and 'owner,guest'
	);
	return $info;
}

function module_install_fire_place_area() {
	// insert data into module table - do NOT change this (well... just change the function name ;))!
	$info = module_getinfo_fire_place_area();
	$sql = "INSERT INTO housemodules
				(modulefile, modulename, moduleversion, moduleauthor, built_in, linkcategory, linktitle,showto)
				VALUES ('{$info['modulefile']}','{$info['modulename']}','{$info['moduleversion']}','{$info['moduleauthor']}','{$info['built_in']}','{$info['linkcategory']}','{$info['linktitle']}','{$info['showto']}')";
	db_query($sql);
	$moduleid = db_insert_id(LINK);

	// insert global module data (you can add several entries - but do NOT
	// change anything else than "FieldName" and FieldValue"!)
	/*
	$sql = 'INSERT INTO housemoduledata (moduleid, name, houseid, value)
				VALUES ('.$moduleid.',"FieldName",0,"FieldValue")';
	db_query($sql);
	*/

	// here you can change everything else needed (e.g. adding settings)
	// be careful: these changes must be global; per-house-changes will be done
	// in module_build()!
}

function module_uninstall_fire_place_area() {
	// uninstalling the module
	// this function should also contain all module_destroy contents

	// getting moduleid - do NOT change this (same as above... the function name should be changed)!
	$info = module_getinfo_fire_place_area();
	$moduleid = getmoduleid($info['modulename']);

	// deleting module from db - do NOT change this!
	$sql = 'DELETE FROM housemodules WHERE moduleid='.$moduleid;
	db_query($sql);

	// deleting internal module data - do NOT change this!
	$sql = 'DELETE FROM housemoduledata WHERE moduleid='.$moduleid;
	db_query($sql);

	// here you should delete all other added things (e.g. settings) of this module
}

function module_build_fire_place_area($houseid) {
	// this is only needed if 'built_in' in module_info() is set to 0

	// getting moduleid - do NOT change this (function name... blablabla)!
	$info = module_getinfo_fire_place_area();
	$moduleid = getmoduleid($info['modulename']);

	// setting flag for house - do NOT change this!
	$sql = 'INSERT INTO housemoduledata (moduleid, name, houseid, value)
				VALUES ('.$moduleid.',"#activated#",'.$houseid.',"1")';
	db_query($sql);

	// here you can change everything else needed (e.g. changing user settings)
	// be careful: these changes must be for this house only; global changes will be done
	// in module_install()!
}

function module_destroy_fire_place_area($houseid) {
	// this is only needed if 'built_in' in module_info() is set to 0

	// getting moduleid - do NOT change this (function name... moooooooooh!)!
	$info = module_getinfo_fire_place_area();
	$moduleid = getmoduleid($info['modulename']);

	// deleting module data of this house - do NOT change this!
	$sql = 'DELETE FROM housemoduledata WHERE moduleid='.$moduleid.' AND houseid='.$houseid;
	db_query($sql);

	// here you should delete all other added things (e.g. user settings) of this module and house
}

function module_show_fire_place_area() {
	// this is the main part of the module where all output is done ;)
	// don't forget the navs; only the default module does not need them (but may add some)
	// to return to the main module, use this link: houses.php?op=drin&module (without id!)
	// don't forget 'global $session;' if you need the player's data (and you WILL need them!)
        global $session;
        
	addcommentary();

        $ql="SELECT name,dragonkills FROM accounts WHERE house='".$session['user']['specialmisc']['houseid']."'";
        $res=db_query($ql);
        $row=db_fetch_assoc($res);
        
        if($_GET[act]==""){
	output("`n<table align='center'><tr><td><IMG SRC=\"images/feuerflammen45.gif\"></tr></td></table>",true);
        output("`6Du betrittst den hell erleuchteten Kaminraum des Hauses. Auf dem Boden liegt ein kuscheliges B�renfell, vor dem Kamin steht ein Sessel und ".($row[dragonkills]==1?"ein Drachenkopf":"".$row[dragonkills]." Drachenk�pfe")." schm�cken den Raum.`n");
	viewcommentary("fire-".$session['user']['specialmisc']['houseid'],"Mit Mitbewohnern reden:",20,"sagt");
        addnav("Ausruhen","houses.php?op=drin&act=ruhe");
        }else if($_GET[act]=="ruhe"){
        switch(e_rand(1,3)){
        case 1:
        output("`6Du schaust dir ".($row[dragonkills]==1?"den Drachenkopf":"die ".$row[dragonkills]." Drachenk�pfe")." und Bilder an der Wand an.");
        break;
        case 2:
        output("`6Du setzt dich auf den Sessel und geniesst die Ruhe.");
        break;
        case 3:
        output("`6 Du liegst auf das B�renfell und schl�fst fast ein.");
        break;
        }
        }
        addnav("Zur�ck","houses.php?op=drin&module=");
	$sql = "SELECT name,description FROM items WHERE value1={$session['user']['specialmisc']['houseid']} AND class='M�bel' ORDER BY class,id ASC";
	$result = db_query($sql) or die(db_error(LINK));
	 for ($i=1;$i<=db_num_rows($result);$i++){
		$item = db_fetch_assoc($result);
			if ($item[name]=="Ledersofa") output("`n`6Ledersofa`0 (`i$item[description]`i)");
			if ($item[name]=="Ledersessel") output("`n`6Ledersessel`0 (`i$item[description]`i)");
			if ($item[name]=="Verzierter Schreibtisch") output("`n`6Verzierter Schreibtisch`0 (`i$item[description]`i)");
			if ($item[name]=="Zimmerpflanze") output("`n`2Zimmerpflanze`0 (`i$item[description]`i)");
			if ($item[name]=="Topfrose") output("`n`2Topf`\$rose`0 (`i$item[description]`i)");
			if ($item[name]=="Orangenbaum") output("`n`6Orangenbaum`0 (`i$item[description]`i)");
			if ($item[name]=="Gro�er Teppich") output("`n`6Gro�er Teppich`0 (`i$item[description]`i)");
			if ($item[name]=="Weidenkorb") output("`n`6Weidenkorb`0 (`i$item[description]`i)");
			if ($item[name]=="Vase") output("`n`6Vase`0 (`i$item[description]`i)");
			if ($item[name]=="Kerzenst�nder") output("`n`6Kerzenst�nder`0 (`i$item[description]`i)");
			if ($item[name]=="Kasten") output("`n`6Kasten`0 (`i$item[description]`i)");
			if ($item[name]=="Edler Wohnzimmerschrank") output("`n`6Edler Wohnzimmerschrank`0 (`i$item[description]`i)");
			if ($item[name]=="Bild") output("`n`6Bild`0 (`i$item[description]`i)");
			if ($item[name]=="Uhr") output("`n`6Uhr`0 (`i$item[description]`i)");
			if ($item[name]=="Hundek�rbchen") output("`n`6Hundek�rbchen`0 (`i$item[description]`i)");
			if ($item[name]=="Schachspiel aus Edelholz") output("`n`6Schachspiel aus Edelholz`0 (`i$item[description]`i)");
			if ($item[name]=="Wandregal") output("`n`6Wandregal`0 (`i$item[description]`i)");
			if ($item[name]=="Vorh�nge") output("`n`6Vorh�nge`0 (`i$item[description]`i)");
			}
	// uncomment these lines if you want to show the default navs even if this is not the default module
	// global $shownavs;
	// $shownavs = true;

	// uncomment these lines if you want to hide the default navs even if this is the default module
	// global $shownavs;
	// $shownavs = false;
}
?>