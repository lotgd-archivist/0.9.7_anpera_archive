<?php
/*Das goldene Buch

code by The Grinch
*/
if (!isset($session)) exit();{
switch ($_GET['op']){
case "":
       $session['user']['specialinc']="goldenesbuch.php";
       output("Auf dem Boden liegt ein goldenes Buch, neugierig betrachtest du es");
       addnav("Die erste Seite lesen","forest.php?op=1seite");
       addnav("Die zweite Seite lesen","forest.php?op=2seite");
       addnav("Die dritte Seite lesen","forest.php?op=3seite");
       addnav("Die vierte Seite lesen","forest.php?op=4seite");
       addnav("Die fünfte Seite lesen","forest.php?op=5seite");
       addnav("Lass das Buch liegen","forest.php?op=return");
	   break;

case "return":
      $session['user']['specialinc']="";
       break;

case "1seite":
      $session['user']['specialinc']="goldenesbuch.php";
      output("Du schlägst die erste seite auf.`n Du fängst an zu lesen.`n Die erste Seite handelt von einer einsamen Insel wo ein Schatz versteckt ist.`n");
      addnav("Schatz suchen ?","forest.php?op=schatzsuche");
      addnav("Schlage das Buch wieder zu","forest.php?op=return");
      break;
//_________________________________________      
case "schatzsuche":
switch(e_rand(1,2)){
case 1:
   $session['user']['specialinc']="goldenesbuch.php";
   output("Du öffnest den Schatz und füllst deine Taschen.`n");
   addnews($session['user']['name']."`\$ hat ein großen Schatzgefunden!.");
   $session[user][gold]+=5000;
   addnav("Kehre Heim","forest.php?op=return");
break;
case 2:
   $session['user']['specialinc']="goldenesbuch.php";
   $exp = round($session['user']['experience']*0.05);
   output("Du öffnest den Schatz und füllst deine Taschen, aber du wirst erwischt durch ein Pirat !`n`n
   `\$Du bist tot und kannst Morgen weiter spielen!`n
   Du verlierst all dein `^Gold`\$ und `^".$exp."`\$ Erfahrung");
   addnews($session['user']['name']."`\$ wurde beim klauen von ein Pirat erwischt!.");
   $session['user']['alive']=false;
   $session['user']['gold']=0;
   $session['user']['hitpoints']=0;
   $session['user']['experience']-=$exp;
   addnav("Tägliche News","news.php");
   $session['user']['specialinc']="";
break;
  }
break;
//ERSTER SEINTE AB HIER VORBEI
case "2seite":
    $session['user']['specialinc']="goldenesbuch.php";
	output("Du schlägst die zweite seite auf.`n Du fängst an zu lesen.`n Die zweite Seite handelt von einer schönen Frau namens Schneewittchen.`n");
    addnav("Schneewitchen retten","forest.php?op=schneewittchen");
    addnav("Schlage das Buch wieder zu","forest.php?op=return");
break;
case "schneewittchen":
    $session['user']['specialinc']="goldenesbuch.php";
	output("Es steht ein großer Zwerg und beschützt Schneewittchen.`nWas tust willst du tun?");
       addnav("Den Zwerg töten","forest.php?op=zwergtoeten");
       addnav("Flüchte","forest.php?op=return");
break;

case "zwergtoeten":
        output("Du entscheidest dich für den Zwerg. Der Zwerg ist sehr erzürnt darüber und will dich vernichten!!!`n");
        $session['user']['specialinc']="goldenesbuch.php";
        $badguy = array(
                "creaturename"=>"Zwerg",
                "creaturelevel"=>$session['user']['level'],
                "creatureweapon"=>"Ale Fässer",
                "creatureattack"=>$session['user']['attack']*0.8,
                "creaturedefense"=>$session['user']['defence']*0.7,
                "creaturehealth"=>round($session['user']['maxhitpoints']*1.3),
                "diddamage"=>0);
        $session['user']['badguy']=createstring($badguy);
        $battle=true;
        
break;
case "fight":
        $session['user']['specialinc']="goldenesbuch.php";
        $battle=true;
break;
case "run":
        $session['user']['specialinc']="goldenesbuch.php";
        output("Es gibt kein Entkommen, du bist von dem Zwerg umstellt.");
        $battle=true;
break;

//2 SEITE AB HIER VORBEI
case "3seite":
	$session['user']['specialinc']="goldenesbuch.php";
	output("Du schlägst die dritte Seite auf.`n Du fängst an zu lesen.`n Die dritte Seite handelt von einem Pirat der gierig nach Geld und Edelsteinen ist.`n`nWas willst du tun?");
	addnav("Dich ergeben","forest.php?op=ergeben");
	addnav("Pirat","forest.php?op=pirat");
break;
//_________________________________________
case "ergeben":
switch(e_rand(5,6)){
case 5:
	$session['user']['specialinc']="goldenesbuch.php";
	output("Du gibt ihn ohne mit der Wimper zu zucken all dein Reichtum was du bei dir trägst.");
	addnews("Man hört die Schadenfreude von ein Pirat");
	$session['user']['gold']=0;
	$session['user']['gems']=0;
break;
case 6:
	$session['user']['specialinc']="goldenesbuch.php";
	output("Der Pirat erleidet ein Schwächeanfall, du kannst schnell flüchten.");
	addnav("Zurück in den Wald","forest.php?op=return");
break;
}
break;
case "pirat":
	$session['user']['specialinc']="goldenesbuch.php";
	output("Der Pirat stürzt sich auf dich!");
	addnav("Weiter","forest.php?op=weiter");
break;
case "weiter":
switch(e_rand(7,9)){
case 7:
    $session['user']['specialinc']="goldenesbuch.php";
    output("Der Pirat zieht sein Schwert und tÃ¶tet Dich!`nDu bist TOT und verlierst all dein Gold!");   
	$session['user']['alive']=false;
    $session['user']['gold']=0;
    $session['user']['hitpoints']=0;
    addnav("Tägliche News","news.php");
break;
case 8:
   $session['user']['specialinc']="goldenesbuch.php";
   output("Du kannst flüchten und bringst dein Gold schnell in Sicherheit");
   addnav("Zur Bank","bank.php");
break;
case 9:
   $session['user']['specialinc']="goldenesbuch.php";
   output("Du kämpfst gegen den Pirat und besiegst ihn`nDu bekommst 3000 Gold, 3 Rohdiamanten und 300 Erfahrungspunkte !");   
   addnews($session['user']['name']."Hat den Pirat besiegt!");
   $session['user']['gold']+=3000;
   $session['user']['experience']+=300;
   $session['user']['rohdiamant ']+=3;
break;
   }
break;
//3Seite AB HIER VORBEI
case "4seite":
	$session['user']['specialinc']="goldenesbuch.php";	
	output("Die vierte Seite handelt von ein Casino, vor dir steht ein großes Rad zum drehen.`n Was willst du tun `n Daran drehen?´n oder es lieber lassen und nichts riskieren?");
	addnav("Daran drehen","forest.php?op=drehen");
	addnav("Es lieber lassen","forest.php?op=return");
break;
//__________________________________________________
case "drehen":
switch(e_rand(10,19)){
case 10:
	$session['user']['specialinc']="goldenesbuch.php";
	output("`mDu erhälts doppelt soviel Gold!");
	$session['user']['gold']*2;
	addnav("Zurück in den Wald","forest.php?op=return");
break;
case 11:
	$session['user']['specialinc']="goldenesbuch.php";
	output("`mDu verlierst all dein Gold!");
	$session['user']['gold']=0;
	addnav("Zurück in den Wald","forest.php?op=return");
break;
case 12:
	$session['user']['specialinc']="goldenesbuch.php";
	output("`#Du bekommst doppelt soviele Edelsteine!");
	$session['user']['gems']*2;
	addnav("Zurück in den Wald","forest.php?op=return");
break;
case 13:
	$session['user']['specialinc']="goldenesbuch.php";
	output("`#Du verlierst all deine Edelsteine!");
	$session['user']['gems']=0;
	addnav("Zurück in den Wald","forest.php?op=return");
	break;
case 14:
	$session['user']['specialinc']="goldenesbuch.php";
	output("`#Du bekommst du doppelt soviele Rohdiamanten!");
	$session['user']['rohdiamant']*2;
	addnav("Zurück in den Wald","forest.php?op=return");
break;
case 15:
	$session['user']['specialinc']="goldenesbuch.php";
	output("`#Du verlierst all deine Rohdiamanten!");
	$session['user']['rohdiamant']=0;
	addnav("Zurück in den Wald","forest.php?op=return");
break;
case 16:
	$session['user']['specialinc']="goldenesbuch.php";
	output("`]Du bekommst doppelt soviele Waldkämpfe!");
	$session['user']['turns']*2;
	addnav("Zurück in den Wald","forest.php?op=return");
break;
case 17:
	$session['user']['specialinc']="goldenesbuch.php";
	output("`]Du verlierst all deine Waldkämpfe!");
	$session['user']['turns']=0;
	addnav("Zurück in den Wald","forest.php?op=return");
break;
case 18:
	$session['user']['specialinc']="goldenesbuch.php";
	output("`‹Du heilst vollständig!");
	$session['user']['hitpoints'] = $session[user][maxhitpoints];
	addnav("Zurück in den Wald","forest.php?op=return");	
break;
case 19:
	$session['user']['specialinc']="goldenesbuch.php";
	output("`pDu bist TOT!!!");
	$session['user']['alive']=false;
    $session['user']['gold']=0;
    $session['user']['hitpoints']=0;
    addnav("Tägliche News","news.php");
break;
	}
break;
//SEITE 4 AB HIER ZUENDE
case "5seite":
	$session['user']['specialinc']="goldenesbuch.php";	
	output("Die fünfte Seite handelt vom Dschungel, überall sind Dschungelkreaturen die dich beobacten.`nEs gibt viele möglichkeitenden den Dschungel zu meistern entweder du bestehst die Dschungel prüfungen oder du gehts feige nach 			hause.");
	output("Für was entscheidest du dich?");
	addnav("Prüfung 1","forest.php?op=pruefung1");
	addnav("Prüfung 2","forest.php?op=pruefung2");
	addnav("Prüfung 3","forest.php?op=pruefung3");
	addnav("Prüfung 4","forest.php?op=pruefung4");
	addnav("Feige flüchten","forest.php?op=nein");
break;
case "pruefung1":
	$session['user']['specialinc']="goldenesbuch.php";
	output("Willkommen zur ersten Dschungel du wirst heute einiges aufgetischt bekommen.`n Ob du sie machst ist dir überlassen.`n Ja oder Nein?");
	addnav("Ja!","forest.php?op=ja");
	addnav("Nein!","forest.php?op=nein");
break;
case "ja":
switch(e_rand(20,24)){
case 20:
	$session['user']['specialinc']="goldenesbuch.php";
	output("Du bekommst ein Rattenschwanz vor die Nase gesetzt!`n Du beißt ab und spuckst es gleich wieder aus.`nDu verlierst Erfahrung!");
	$session['user']['experience']-=300;
	addnav("Zurück in den Wald","forest.php?op=return");
break;
case 21:
	$session['user']['specialinc']="goldenesbuch.php";
	output("Du bekommst Vogelhirn vor die Nase gesetzt!`nDu beißt ab und es scheint dir zu schmecken.`nDu bekommst Erfahrung!");
	$session['user']['experience']+=300;
	addnav("Zurück in den Wald","forest.php?op=return");
break;
case 22:
	$session['user']['specialinc']="goldenesbuch.php";
	output("Du bekommst 5 Vogelaugen vor die Nase gesetzt!`nDu isst alle aufeinmal auf und erstickst qualvoll daran`n`p Du bist TOT");
	$session['user']['alive']=false;
    $session['user']['gold']=0;
    $session['user']['hitpoints']=0;
    addnav("Tägliche News","news.php");
	addnav("Zurück in den Wald","forest.php?op=return");
break;
case 23:
	$session['user']['specialinc']="goldenesbuch.php";
	output("Du bekommst Krokodilaugen vor die Nase gesetzt!`nDu fängst langsam an es zu essen, nach einiger Zeit hast du es vertilgt aber die wird schlecht!`nDu musst dich übergeben`nDu schämst dich!");
	$session['user']['charm']-=5;
	addnav("Zurück in den Wald","forest.php?op=return");
break;
case 24:
	$session['user']['specialinc']="goldenesbuch.php";
	output("Du bekommst Schlangenhaut vor die Nase gesetzt!`nDu steckst sie Schnell in den Mund und behälts alles drin!`nDie Jungle Ureinwohner finden dich sehr tapfer du bekommst 5 Charme punkte");
	$session['user']['charm']+=5;
	addnav("Zurück in den Wald","forest.php?op=return");
break;
}
break;
//_________________________________________________________________
case "pruefung2":
	$session['user']['specialinc']="goldenesbuch.php";
	output("Willkommen zur zweiten Jungleprüfung du musst in ein 40 Meter hohen Baum klettern und dich denn von einer Liane wieder abseilen!.`n Ob du sie machst ist dir überlassen.`n Ja oder Nein?");
	addnav("Ja!","forest.php?op=ja1");
	addnav("Nein!","forest.php?op=nein");
break;
case "ja1":
switch(e_rand(25,27)){
case 25:
	$session['user']['specialinc']="goldenesbuch.php";
	output("Du fängst an zu klettern.`nAls du oben bist schnappst du dir die Liane und seilst dich daran ab`n Du hast die Prüfung bestanden!");
	$session['user']['experience']+=500;
	$session['user']['gold']+=2500;
	addnav("Zurück in den Wald","forest.php?op=return");
break;
case 26:
	$session['user']['specialinc']="goldenesbuch.php";
	output("Du fängst an zu klettern nach 3 Meter stürzt du hinuter und verletzt dich.`nDu verlierst fast alle deine Lebenspunkte");
	$session['user']['hitpoints']=1;
	addnav("Zurück in den Wald","forest.php?op=return");
break;
case 27:
	$session['user']['specialinc']="goldenesbuch.php";
	output("Du fängst an zu klettern als du oben angekommen bist versucht du an die Liane zu springen aber verfehlst diese du fällst mit einem lauten knall auf den Boden und bist auf der Stelle tot!");
	addnews($session['user']['name']."Fiel von oben tot auf den Boden!");
	$session['user']['alive']=false;
    $session['user']['gold']=0;
    $session['user']['hitpoints']=0;
    addnav("Tägliche News","news.php");
break;
}
break;
case "pruefung3":
	$session['user']['specialinc']="goldenesbuch.php";
	output("Willkommen zur dritten Jungleprüfung du musst in eine Holzkiste und dadrin eine Viertelstunde verbringen`n Ob du sie machst ist dir überlassen.`n Ja oder Nein?");
	addnav("Ja!","forest.php?op=ja3");
	addnav("Nein!","forest.php?op=nein");
break;
case "ja3":
switch(e_rand(28,29)){
case 28:
	$session['user']['specialinc']="goldenesbuch.php";
	output("Du steigst in die Kiste, nach 10 Minuten willst du allerdings raus.`nDurch die verschwundung deiner Zeit verlierst du 3 Waldkämpfe!");
	$session['user']['turns']-=5;
	addnav("Zurück in den Wald","forest.php?op=return");
break;
case 29:
	$session['user']['specialinc']="goldenesbuch.php";
	output("Du hälst es die vollen 15 Minuten aus du bekommst einige Waldkämpfe!");	
	$session['user']['turns']+=5;
	addnav("Zurück in den Wald","forest.php?op=return");
break;
}
break;
case "pruefung4":
	$session['user']['specialinc']="goldenesbuch.php";
	output("Willkommen zur vierten Jungleprüfung du musst in eine große Wanne gefüllt mir Kakerlaken !.`n Ob du sie machst ist dir überlassen.`n Ja oder Nein?");
	addnav("Ja!","forest.php?op=ja4");
	addnav("Nein!","forest.php?op=nein");
break;
case "ja4":
switch(e_rand(30,31)){
case 30:
	$session['user']['specialinc']="goldenesbuch.php";	
	output("Du ekelst dich so vor den Kakerlaken das du einige Charmepunkte verlierst!");
	$session['user']['charm']+=5;
	addnav("Zurück in den Wald","forest.php?op=return");
break;
case 31:
	$session['user']['specialinc']="goldenesbuch.php";	
	output("Du ziehst die Sache durch und wirst dafür mit eingigen Erfahrungspunkten belohnt!");
	$session['user']['experience']+=300;
	addnav("Zurück in den Wald","forest.php?op=return");
break;
}
break;
case "nein":
	$session['user']['specialinc']="goldenesbuch.php";	
	output("Weil du zu feige bist verlierst du 5 Waldkämofe!");
	$session['user']['turns']-=5;
	addnav("Zurück in den Wald","forest.php?op=return");
break;
	}

}	

if ($battle) {
	include("battle.php");
 	$session['user']['specialinc']="goldenesbuch.php";
    if ($victory){
        $session['user']['specialinc']="";
        $badguy=array();
        $session['user']['badguy']="";
        $expbonus = round($session['user']['experience']*0.10);
        output("`n`nNachdem du den Zwerg getötet hast fühlst Du, dass Du das richtige getan hast. Als Dank bekommst du 2 Edelsteine und $expbonus Erfahrung.");
        addnews($session['user']['name']." Hat es geschafft Schneewittchen zu retten und wurde dafür belohnt.");
        $session['user']['experience']+=$expbonus;
        $session['user']['gems']+=2;
  	}elseif ($defeat){
        $expmalus = round($session['user']['experience']*0.95);
        $session['user']['specialinc']="";
        $badguy=array();
        output("`n`n`\$Du wurdest von dem Zwerg getötet. Dein edler gedanke hat dir den tot gebracht..... War es Schneewittchen wert?");
        addnews($session['user']['name']."`\$ wurde von einem Zwerg getötet.");
        $session['user']['badguy']="";
        $session['user']['alive']=false;
        $session['user']['gold']=0;
        $session['user']['hitpoints']=0;
        $session['user']['experience']-=$expmalus;
        addnav("Tägliche News","news.php");
    }else{
        fightnav(true,true);
	}

}

