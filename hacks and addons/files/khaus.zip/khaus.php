<?php
/*Krankenhaus by Spitzi
F�r Land Everon http://www.spitzisundcindysgame.de
31.10.06
hier k�nnen M�tter in einem Geburtsraum ihre Kinder zur Welt bringen. Kranke k�nnen sich von einem Pfleger heilen lassen.
SQL: ALTER TABLE `accounts` ADD `pfleger` INT( 11 ) NOT NULL DEFAULT '0';
*/
require_once "common.php";
addcommentary();

page_header("Lazarett");
$session[user][ort]='Lazarett';
output("`c`b`&L`)a`7z`Ma`lr`7e`)t`&t`b`c`n`n
`c`7Im `&L`)a`7z`Ma`lr`7e`)t`&t `7triffst du viele bekannte `�K`��`=m`4p`|f`\$e`Xr`7; einige haben furchtbare `mN`Garb`&en `7vom`n `~K`Aa`Dm`lp`Mf `7mit der gr�nen `aB`se`os`wt`2i`ke `7davongetragen und lassen sich nun hier von einigen`n guten `&S`#e`3e`:l`9e`!n `7und ein paar angehenden `&H`ge`@i`kl`2e`wr`on `7wieder gesund pflegen; doch gibt es`n auch harmlose 
`mVe`Grletzung`&en `7wie `�B`�e`=u`4l`|e`$n `7vom `&U`#m`3k`:i`9p`!p`1e`yn `7in der `TS`�c`�h`te`&n`gk`@e `7�ber
`n blaugeschlagene `uA`yu`1g`!e`9n `7von `aEh`sez`owi`wst`2ig`kke`@it`gen `7oder `TSt`�re`�it`tere`�i`�e`Tn `7zwischen`n `aNe`�be`Rnb`Kuh`3le`#rn `7um 
eine sch�ne `mM`Gai`&d `7sowie ab und an mal ein zerquetschter `mF`Gus`&s `7`n vom `TB`�a`�u`tm`gf`@�`kl`2l`we`on`7...... Du blickst `ndich interessiert um...`n`n");
if($session['user']['jobid'] ==3){
if($session['user']['turns'] >=6){
addnav("Arbeiten");
addnav("Melden","khaus.php?op=da");
addnav("K�ndigen","khaus.php?op=go");
addnav("Stehlen","khaus.php?op=ste");
}elseif($session['user']['turns'] <=5){
output(" Du hast nicht genug Runden um Heute zu Arbeiten`n");
}
}
if($session['user']['jobid'] ==2){
if($session['user']['turns'] >=6){
addnav("Arbeiten");
addnav("Melden","khaus.php?op=da");
addnav("K�ndigen","khaus.php?op=go");
addnav("Stehlen","khaus.php?op=ste");

}elseif($session['user']['turns'] <=5){
output(" Du hast nicht genug Runden um Heute zu Arbeiten`n");
addnav("zur�ck","khaus.php");
}
}
if($session['user']['jobid'] ==17){
if($session['user']['turns'] >=6){
addnav("Arbeiten");
addnav("Melden","khaus.php?op=dazwei");
addnav("K�ndigen","khaus.php?op=go");
addnav("Stehlen","khaus.php?op=ste");
}elseif($session['user']['turns'] <=5){
output(" Du hast nicht genug Runden um Heute zu Arbeiten`n");
addnav("zur�ck","khaus.php");
}
}
if($session['user']['jobid'] ==20){
if($session['user']['turns'] >=6){
addnav("Arbeiten");
addnav("Melden","khaus.php?op=dazwei");
addnav("Stehlen","khaus.php?op=ste");
addnav("K�ndigen","khaus.php?op=go");
}elseif($session['user']['turns'] <=5){
output(" Du hast nicht genug Runden um Heute zu Arbeiten`n");
addnav("zur�ck","khaus.php");
}
}
//Ab Jetzt kommt das Testgebiet
if ($_GET['op']=="da"){

if ($session['user']['jobda'] ==1){
output(" Du hast heute schon gearbeitet`n");
}elseif ($session['user']['jobda'] ==0){

output("`8Voller Zuversicht gehst du zum Leiter des Krankenhauses, dem Heiler Patitus. Es war ein kleiner Mann mit aber durchaus stattlichem Spitzbart, wo du bereits Angst bekamst, dass er jeden Augenblick dar�ber stolpern w�rde. `n
Mit pr�fenden Blicken begann er dich zu mustern `&Ai, ihr m�sst Arbeit suchen nicht wahr? Kommt, kommt es gibt reichlich zu tun. Kranke und Verletzte haben wir zur Gen�ge bei uns. `8 `n Ohne ein Widerwort l�sst du dich von ihm an deinen k�nftigen Arbeitsplatz schieben.`n`n");

switch(e_rand(1,5)){

       case '1':
output("`&Seid mir gegr��t, ihr wurdet bereits erwartet `9 hei�t es von der Schwester und sie wei�t euch in eure Arbeit f�r die n�chsten 2 Stunden ein, f�r die ihr einen Lohn von 1000 Gold bekommen solltet.`n`n");
$session['user']['turns']-=2;
$session['user']['gold']+=1000;
$session['user']['jobda']+=1;

break;

case '2':
output("`9Mit eiligen Schritten f�hrt dich die Schwester zu deinem ersten Auftrag, noch ehe du ihr einen guten tag w�nschen konntest. Sie meinte nur, dass es zwar nur f�r 3 Stunden Arbeit gab, doch schien diese wohl umso dringender zu sein. `n
Den Lohn von 1500 Gold erh�ltst du im Anschluss`n`n");
$session['user']['turns']-=3;
$session['user']['gold']+=1500;
$session['user']['jobda']+=1;

break;
case '3':
output("`& Eure Dienste werden heute 4 Stunden lang ben�tigt `9meint die Schwester in freundlichem Ton und tritt zur Seite, damit du eintreten kannst. Sicher w�rde sich die Arbeit nicht von alleine erledigen und so erledigst du eine Aufgabe nach der anderen und gehst schlie�lich mit 2000 Gold als Entsch�digung nach Hause.`n`n");
$session['user']['turns']-=4;
$session['user']['gold']+=2000;
$session['user']['jobda']+=1;

break;
case '4':
output("`9ein Seufzen drang �ber deine Lippen. Heute w�rdest du also 5 Stunden lang nichts anderes sehen als die Kranken und die tristen W�nde des Krankenhauses. Wenigstens belief sich deine Entsch�digung daf�r auf gute 2500 Goldst�cke`n`n");
$session['user']['turns']-=5;
$session['user']['gold']+=2500;
$session['user']['jobda']+=1;

break;
case '5':
output("`&Verzeiht, doch m�sst ihr heute leider ganze 6 Stunden arbeiten `9 Dieser Satz hallte dir immer und immer wieder im Kopf hin und her. Es w�rde ja ewig dauern, bis du endlich fertig warst. 6 Stunden zum Lohn von 3000 Gold� `n
Warst du eigentlich der Einzigste, der so lange arbeiten musste? Irgendwie hattest du das Gef�hl, dass es so war.`n`n");
$session['user']['turns']-=6;
$session['user']['gold']+=3000;
$session['user']['jobda']+=1;

break;
addnav("Krankenhauseingang","khaus.php");
}
}
if($session['user']['jobf'] >=1){
$session['user']['jobf']-=1;
}
}

if ($_GET['op']=="dazwei"){

if ($session['user']['jobda'] ==1){
output(" Du hast heute schon gearbeitet`n");
}elseif ($session['user']['jobda'] ==0){

output("`8Voller Zuversicht gehst du zum Leiter des Krankenhauses, dem Heiler Patitus. Es war ein kleiner Mann mit aber durchaus stattlichem Spitzbart, wo du bereits Angst bekamst, dass er jeden Augenblick dar�ber stolpern w�rde. `n
Mit pr�fenden Blicken begann er dich zu mustern `&Ai, ihr m�sst Arbeit suchen nicht wahr? Kommt, kommt es gibt reichlich zu tun. Kranke und Verletzte haben wir zur Gen�ge bei uns. `8 `n Ohne ein Widerwort l�sst du dich von ihm an deinen k�nftigen Arbeitsplatz schieben.`n`n");

switch(e_rand(1,5)){

       case '1':
output("`9L�chelnd tritt dir die Schwester entgegen und schaut dich freundlich an `&Sch�n, dass ihr da seid. Heute wird es nur 2 Stunden lang Arbeit f�r euch geben. Dennoch werdet ihr 1500 Gold erhalten. `R Danach dreht sie sich herum und deutet euch an, ihr zu folgen, damit sie euch zeigen kann, was es heute zu erledigen gibt.`n`n");
$session['user']['turns']-=2;
$session['user']['gold']+=1500;
$session['user']['jobda']+=1;

break;

case '2':
output("`9Mit gewohnt typischem L�cheln begr��t dich die Schwester am Eingang `&3 Stunden werden es heute sein `9 meint sie und du machst dich sofort ans Werk. Nach getaner Arbeit verl�sst du mit 2250 Goldst�cken das Krankenhaus.`n`n");
$session['user']['turns']-=3;
$session['user']['gold']+=2250;
$session['user']['jobda']+=1;

break;
case '3':
output("`&3000 Gold f�r 4 Stunden Arbeit `9 meint die Schwester freundlich und begleitet dich ins innere des Krankenhauses, wo du dich nat�rlich sofort an die Arbeit machst, damit du nicht bis in die Nacht zu tun hast.`n`n");
$session['user']['turns']-=4;
$session['user']['gold']+=3000;
$session['user']['jobda']+=1;

break;
case '4':
output("`9Immer wieder auf die Turmuhr schauend wirst du von der Schwester in Empfang genommen und sie schiebt dich gleich in die Umkleide `&Bitte beeilt euch es warten 5 Stunden Arbeit auf euch. Den Lohn von 3750 Goldst�cken werdet ihr im Anschluss erhalten`n`n");
$session['user']['turns']-=5;
$session['user']['gold']+=3750;
$session['user']['jobda']+=1;

break;
case '5':
output("`9Du schaust die Schwester entt�uscht an als sie dir mitteilte, dass du f�r die n�chsten 6 Stunden hier arbeiten w�rdest. 6 Stunden zum Lohn von 4500 Goldst�cken. Irgendwie eine geringe Entsch�digung f�r die M�he aber was blieb dir schon anderes �brig?`n`n");
$session['user']['turns']-=6;
$session['user']['gold']+=4500;
$session['user']['jobda']+=1;

break;
addnav("Krankenhauseingang","khaus.php");
}
}
if($session['user']['jobf'] >=1){
$session['user']['jobf']-=1;
}
}

if ($_GET['op']=="ste"){
if(($session['user']['turns'] <=2)||($session['user']['dieb'] <=1)){
switch(e_rand(1,12)){

       case '1':
output("`7Mit ernstem Blick schleichst du dich zu den Geldern, die zur Unterst�tzung des Krankenhauses von den Einnahmen beiseite gelegt werden. `n
Irgendwie tat es dir zwar leid, doch hattest du eine kleine und zus�tzliche Entsch�digung f�r deine M�hen n�tig. Zumindest war das so deine Ansicht. `n
Schnell greifst du dir 5.000 Gold aus der Kasse und verschwindest damit so schnell, wie du gekommen warst.
`n`n");
$session['user']['turns']-=1;
$session['user']['gold']+=5000;
$session['user']['dieb']+=1;
break;
       case '2':
output("`7Zufrieden l�sst du 3000 Gold in deine Taschen wandern, nachdem dich schon keiner dabei beobachtet hatte, dass du hier eingedrungen warst um etwas zu stehlen. `n
Die beute sollte doch f�rs Erste einmal reichen, du k�nntest es ja sp�ter noch einmal versuchen. Auf leisen Sohlen schleichst du dich wieder nach drau�en und gibst darauf Acht, dass dich keiner sieht.`n`n");
$session['user']['turns']-=1;
$session['user']['gold']+=3000;
$session['user']['dieb']+=1;
break;
       case '3':
output("`7Ein Grinsen breitete sich auf deinen Lippen aus als du zum ersten Mal zu sehen bekommst, wie reich das Krankenhaus wirklich war. Da konnte man doch einfach nicht widerstehen und so steckst du 6 der Edelsteine ein. `n
Bei solchen Mengen w�rde es wohl kaum auffallen. Nie h�ttest du zu tr�umen gewagt, dass dein Raubzug so erfolgreich sein w�rde. Und es hatte noch nicht mal einer bemerkt, bis du in Sicherheit warst.`n`n");
$session['user']['turns']-=1;
$session['user']['gems']+=6;
$session['user']['dieb']+=1;
break;
       case '4':
output("`7Im Schutze der Nacht pirscht du dich leise zur Schatzkammer vor, ja darauf bedacht, dass keiner auf dich aufmerksam wurde. Die Kranken schliefen sowieso und die Pfleger und Schwestern waren nicht anwesend, geschweige denn der Rest des Personals. `n
L�chelnd nimmst du dir 4 Edelsteine und beschlie�t es am besten w�re es erst einmal dabei zu belassen und es vielleicht sp�ter noch einmal zu versuchen. `n
Das Gl�ck war erneut auf deiner Seite, sodass du unerkannt entkommen kannst.`n`n");
$session['user']['turns']-=1;
$session['user']['gems']+=4;
$session['user']['dieb']+=1;
break;
       case '5':
output("`7Lautlos dr�ckst du die T�r zur Schatzkammer des Krankenhauses auf und vergewisserst dich erst einmal, dass du auch wirklich ungest�rt sein w�rdest. Nachdem alles ruhig blieb trittst du vorsichtig ein und beginnst damit, deine Taschen zu f�llen. `n
Leider kamen in diesem Augenblick 2 Pfleger um die Ecke und du musstest dich schnell verstecken. Dabei f�llt dir ein Gro�teil des Diebesgutes wieder herunter und du kannst im Endeffekt nur 1000 Gold sicher herausschaffen. Aber es war immer noch besser als, wenn sie dich erwischt h�tten.`n`n");
$session['user']['turns']-=2;
$session['user']['gold']+=1000;
$session['user']['dieb']+=1;
break;
       case '6':
output("`7In aller Stille n�herst du dich den Sch�tzen und schaust dich ein letztes Mal noch um. Als niemand in der N�he war, greifst du einfach hinein und erbeutest ganze 2 Edelsteine auf einmal. `n
Doch pl�tzlich wurde es laut als ein schwer Verletzter herein kam und die Heiler und Pfleger aufgeregt hin und her rannten. Nur in einem g�nstigen Augenblick kannst du unerkannt entkommen und atmest schlie�lich tief ein, als du endlich wieder in Sicherheit warst. `n
Der Verlust w�rde angesichts dieser Situation ohnehin nicht so schnell auffallen`n`n");
$session['user']['turns']-=2;
$session['user']['gems']+=2;
$session['user']['dieb']+=1;
break;
       case '7':
output("`7Mit Wut im Gesicht blickte Patitus dich an als er dich dabei erwischte, wie du dich an den Sch�tzen des Krankenhauses bereichern wolltest. `n
`&Interessant, interessant `7 murmelt er in seinen Bart hinein und noch ehe du dich versehen konntest, standest du schon mit einer fristlosen K�ndigung vor den geschlossenen Toren der Heilanstalt. Und zu allem �berfluss hatte dir diese Tat auch nichts eingebracht au�er der Tatsache, dir einen neuen Arbeitsplatz suchen zu d�rfen.`n`n");
$session['user']['turns']-=2;
$session['user']['jobid']=0;
$session['user']['dieb']+=1;
break;
       case '8':
output("`7Alles w�rde gut gehen hast du dir gedacht als alles still und ruhig war. Nirgends eine Menschenseele und die T�r der Schatzkammer ungeschlossen. `n
Langsam und vorsichtig trittst du ein und steckst soviel in die Tasche, wie es nur ging. `n
Doch pl�tzlich stand er hinter dir. Der Heiler und Leiter des Hauses Patitus. `n
Du konntest nichts mehr sagen bevor er anfing dich w�tend anzubr�llen und dir w�nscht, dass du wohl am besten nie hierher gekommen w�rst. Doch da er dennoch von recht gro�z�gigem Gem�t war, gab er dir noch eine Chance und du kommst noch mal mit einer Verwarnung davon.`n`n");
$session['user']['turns']-=2;
$session['user']['jobf']+=1;
$session['user']['dieb']+=1;
break;
case '9':
output("`7Mit Wut im Gesicht blickte Patitus dich an als er dich dabei erwischte, wie du dich an den Sch�tzen des Krankenhauses bereichern wolltest. `n
`&Interessant, interessant `7 murmelt er in seinen Bart hinein und noch ehe du dich versehen konntest, standest du schon mit einer fristlosen K�ndigung vor den geschlossenen Toren der Heilanstalt. Und zu allem �berfluss hatte dir diese Tat auch nichts eingebracht au�er der Tatsache, dir einen neuen Arbeitsplatz suchen zu d�rfen.`n`n");
$session['user']['turns']-=2;
$session['user']['jobid']=0;
$session['user']['dieb']+=1;
break;
       case '10':
output("`7Alles w�rde gut gehen hast du dir gedacht als alles still und ruhig war. Nirgends eine Menschenseele und die T�r der Schatzkammer ungeschlossen. `n
Langsam und vorsichtig trittst du ein und steckst soviel in die Tasche, wie es nur ging. `n
Doch pl�tzlich stand er hinter dir. Der Heiler und Leiter des Hauses Patitus. `n
Du konntest nichts mehr sagen bevor er anfing dich w�tend anzubr�llen und dir w�nscht, dass du wohl am besten nie hierher gekommen w�rst. Doch da er dennoch von recht gro�z�gigem Gem�t war, gab er dir noch eine Chance und du kommst noch mal mit einer Verwarnung davon.`n`n");
$session['user']['turns']-=2;
$session['user']['jobf']+=1;
$session['user']['dieb']+=1;
break;
case '11':
output("`7Mit Wut im Gesicht blickte Patitus dich an als er dich dabei erwischte, wie du dich an den Sch�tzen des Krankenhauses bereichern wolltest. `n
`&Interessant, interessant `7 murmelt er in seinen Bart hinein und noch ehe du dich versehen konntest, standest du schon mit einer fristlosen K�ndigung vor den geschlossenen Toren der Heilanstalt. Und zu allem �berfluss hatte dir diese Tat auch nichts eingebracht au�er der Tatsache, dir einen neuen Arbeitsplatz suchen zu d�rfen.`n`n");
$session['user']['turns']-=2;
$session['user']['jobid']=0;
$session['user']['dieb']+=1;
break;
       case '12':
output("`7Alles w�rde gut gehen hast du dir gedacht als alles still und ruhig war. Nirgends eine Menschenseele und die T�r der Schatzkammer ungeschlossen. `n
Langsam und vorsichtig trittst du ein und steckst soviel in die Tasche, wie es nur ging. `n
Doch pl�tzlich stand er hinter dir. Der Heiler und Leiter des Hauses Patitus. `n
Du konntest nichts mehr sagen bevor er anfing dich w�tend anzubr�llen und dir w�nscht, dass du wohl am besten nie hierher gekommen w�rst. Doch da er dennoch von recht gro�z�gigem Gem�t war, gab er dir noch eine Chance und du kommst noch mal mit einer Verwarnung davon.`n`n");
$session['user']['turns']-=2;
$session['user']['jobf']+=1;
$session['user']['dieb']+=1;
break;
addnav("Krankenhauseingang","khaus.php");
}
}
if($session['user']['dieb']>=2){
output("`b`n`8Du hast Heute schon 2 Mal gestohlen warte bis der neue Tag anbricht `b`n`n");
}
}
if ($_GET['op']=="go"){
output("`3Zum letzten Mal schaust du dir alle ganz genau an, da das heute wohl dein letzter tag hier sein w�rde. Zumindest, wenn du beruflich hier zu schaffen hast. `n
Beinahe bed�chtig klopfst du bei Patitus an, der dich sofort hereinbittet und dich nicht mal eines Blickes w�rdigt. `n
Beschwerlich bringst du dein Anliegen hervor und zu aller Verwunderung sagte dein ehemaliger Chef nicht einmal etwas dazu und nickte nur stumm. `n
Schulterzuckend gehst du einfach davon und verabschiedest dich noch schnell von deinen ehemaligen Mitarbeitern`n");
$session['user']['jobid']=0;
addnav("Krankenhauseingang","khaus.php");
}
addnav("Zur�ck");
addnav("Zur�ck","village.php");

page_footer();
?>



//Testgebiet Ende