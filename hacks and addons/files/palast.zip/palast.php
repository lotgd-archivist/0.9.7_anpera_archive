<?

/*
palast.php
by LordMontekar
*/

require_once "common.php";
page_header("Der Palast");

$author='LordMontekar';
$copyright='� 2006 by';
$website='http://land-der-drachen.de';


###   EINSTELLUNGEN    ###

$name  = ""; //Name des Herrschers
$name2 = ""; //Name der rechten Hand des Herrschers
$g     = ""; //Geschlecht des Herrschers, 0=> m�nnlich, 1=> weiblich
$dorf  = ""; //Name des Dorfes
$id    =  0; //Account-ID des Herrschers

### EINSTELLUNGEN ENDE ###

output("`b`c".$name."s Palast`c`b`n`n");

if  ($_GET['op']=="") {

    output("`^Du betrittst den Palast von $name, `^".($g?"der Herrscherin und Gr�nderin":"dem Herrscher und Gr�nder")." von `5$dorf.`^");
    output("An den W�nden h�ngen kostbare Wandteppiche in den Boden sind Edelsteine eingelassen. Ein paar Stufen f�hren zum Thron, auf ");
    output("dem ".($g?"die K�nigin":"der K�nig")." sitzt. Neben ".($g?"ihr":"ihm")." sitzen ".($g?"ihre":"seine")." Berater, allen voran $name2, ");
    output("die rechte Hand ".($g?"der K�nigin":"des K�nigs").".`n`n");

    switch(e_rand(1,6)) {
    
        case 1:
        output("Vor dem Thron h�pft gerade ein `b`^B`\$a`^r`\$d`^e`b lustig umher und erheitert ".($g?"die K�nigin":"den K�nig")." mit seinen Sp��en.");
        break;
        
        case 2:
        output("Gerade kommt ein `7`bDiener`b `^herrein und serviert ".($g?"der K�nigin":"dem K�nig")." Spei� und Trank.");
        break;
        
        case 3:
        output("Ein `b`TBerater`b `^unterh�lt sich gerade mit ".($g?"der K�nigin":"dem K�nig").".");
        break;
    
    }

    addnav("`9Zu $name `9sprechen","palast.php?op=spreche");
    addnav("Die Wandteppiche anschauen","palast.php?op=wand");
    addnav("Zur�ck ins Dorf","village.php");

} elseif ($_GET['op']=="spreche") {

    addcommentary();
    if ($session['user']['acctid']==$id && $session['user']['superuser']>3) {
        output("`^Du setzt dich auf deinen Thron.`n`n");
        viewcommentary("palast_thron","Antworten",20,"sagt");
    } else if ($session['user']['superuser']>1) {
        output("`^Du setzt dich neben $name `^und ber�tst ".($g?"sie":"ihn").".`n`n");
        viewcommentary("palast_thron","$name `^beraten",20,"sagt zum K�nig");
    } else {
        output("`^Du trittst vor ".$name."s `^Thron und kniest vor ".($g?"ihr":"ihm")." nieder.`n`n");
        viewcommentary("palast_thron","$name `^eine Frage stellen",20,"fragt");
    }
    
    addnav("Zur�ck","palast.php");

} elseif ($_GET['op']=="wand") {

    switch(e_rand(1,12)) {
    
        case 1:
        case 2:
        case 3:
        output("`2Du schaust dir einen gro�en Teppich an, der eine `4Jagdszene `2zeigt.");
        break;
        
        case 4:
        case 5:
        case 6:
        output("`8Du schaust dir einen Teppich an, der einen `7tapferer Ritter `8im Kampf gegen den `@Gr�nen Drachen `8zeigt.");
        break;
        
        case 7:
        case 8:
        case 9:
        output("`^Du schaust dir einen Teppich an, auf dem $name `^gerade gekr�nt wird.");
        break;

        case 10:
        case 11:
        case 12:
        output("`7Du schaust dir einen Teppich an, auf dem der Palast gerade von `2Wal`@de`2lbe`@nma`2gi`@er `4M`\$o`Qn`qt`^ekar `7erbaut wird. ");
        break;
        
    }
    addnav("Zur�ck","palast.php");

}
output("`n`n`n`9`c$copyright <a href=\"$website\">$author</a>`c`n",true);
page_footer();
?>