<?php



/* Ein Freudenhaus *fg*

   Von : Taikun

   Domain: www.logd-midgar.de



--      

--   SQL:

--   

   CREATE TABLE `frdn` (

   `acctid` int(11) unsigned NOT NULL default '0',

  `id` int(10) unsigned NOT NULL auto_increment,

  `kosten` int(11) unsigned NOT NULL default '0',

  `user` varchar(200) NOT NULL default '0',

 `sex` tinyint(4) unsigned NOT NULL default '0',

 `raum` varchar(200) NOT NULL default '0',

  PRIMARY KEY  (`id`),

  UNIQUE KEY `name` (`name`)

) TYPE=MyISAM AUTO_INCREMENT=1 ;



--

-- SQL Accounts:

--

ALTER TABLE accounts

ADD `room` enum('0','1') NOT NULL default '0',

ADD `roomid` INT ( 11 ) NOT NULL default '';





Version 0.3

FIXES o. Adds

*****
Admins k�nnen R�ume l�schen.
*****




*/



// Anfangssachen :)

// #############################################

require_once "common.php";

checkday();

page_header("Das Freudenhaus");

addcommentary();



$stadt = "XXX";

$verw = "3750";

$start = "21:00";

$end  = "6:00"; 

$sql = "SELECT name, sex FROM accounts";

$result = db_query($sql);

$row = db_fetch_assoc($result);



switch($_GET['op']):

// #############################################

// Altersabfrage

// #############################################


// #############################################


// Anfangstext + Navigation

// #################################################################################################################################################################

case "";





if (date('H:i') >= $start && date('H:i') <= $end) { 



if($session['user']['room']==1){

        output("`@Bitte beachtet, dass wenn Ihr in das Zimmer geht, erst wieder rausgehen k�nnt, wenn Ihr fertig seid. Also wartet ab, bis sich jemand gefunden hat, der sich zu Euch gesellt.`n`n`n");

        viewcommentary("frdn","Mit den Anderen reden",25);
        
        output("`n`n`YEine leicht bekleidete Frau l�sst dich wissen das dies ein Ort des Rollenspiels ist und du dich bitte an die Rpg-Regeln halten sollst.");

        addnav("Ins Zimmer","frdnhaus.php?op=room&id=".$_GET['id']."");

        addnav("Zur�ck ins Dorf","village.php");

} else {

output("`@Willkommen im Freundenhaus von ".$stadt.", ".($row['sex']?"werte":"werter")." ".$session['user']['name'].".

`@Wollt Ihr Euch selber anbieten oder Euch lieber verw�hnen lassen? Wenn Ihr Euch verw�hnen lassen wollt, m�sst Ihr beachten, dass die Preise variieren k�nnen.`n

Wenn Ihr Euch selber anbieten wollt, kostet dies eine geringe Bearbeitungsgeb�hr von `^".$verw." Gold.`n`n`n");

viewcommentary("frdn","Mit den Anderen reden:",25);

output("`n`n`YEine leicht bekleidete Frau l�sst dich wissen das dies ein Ort des Rollenspiels ist und du dich bitte an die Rpg-Regeln halten sollst.");

addnav("Ein Zimmer w�hlen","frdnhaus.php?op=ver");

if($session['user']['gold']>=$verw) {

//addnav("Dich Anbieten","frdnhaus.php?op=anbiet");
addnav("Dich Anbieten","frdnhaus.php?op=anbiet");
}

addnav("Zur�ck ins Dorf","village.php");

}

} else {
	


        output("`@Leider hat das Freudenhaus ".$stadt."s immoment geschlossen. Besucht uns ab 21 Uhr.`n");

viewcommentary("frdn","Mit den Anderen reden:",25);

output("`n`n`YEine leicht bekleidete Frau l�sst dich wissen das dies ein Ort des Rollenspiels ist und du dich bitte an die Rpg-Regeln halten sollst.");

        addnav("Zur�ck ins Dorf","village.php");


}

break;

// ############################################################################################################################################################





// Raum f�r *peep* :D

// ####################################################

case "room";

addcommentary();

output("`@Das sch�ne Zimmer dieses Freudenhaus schm�cken sch�ne Bilder an einer Wand, auf der rechten Seite steht ein sch�nes grosses Bett, indem Ihr Euch austoben k�nnt...`n`n");

viewcommentary("frdn-".$session['user']['roomid'],"Hinzuf�gen",25);

output("`n`n`YEine leicht bekleidete Frau l�sst dich wissen das dies ein Ort des Rollenspiels ist und du dich bitte an die Rpg-Regeln halten sollst.");



addnav("RP Beenden","frdnhaus.php?op=beend");

addnav("Zur�ck ins Dorf","village.php");



break;



// ############################################



// RP beenden

// #####################



case "beend";

output("Du kannst nun wieder in ein neues Zimmer bzw. Dich wieder selber anbieten.");

addnav("Zur�ck zum Eingang","frdnhaus.php");

$session['user']['room']=0;

$session['user']['roomid']=0;

break;





// ############################################



// Gold u. Zimmer ID

// ######################################################################################################

case "anbiet";

        

addnav("Zur�ck zum Freudenhaus","frdnhaus.php");

output("<form action=\"frdnhaus.php?op=send\" method='post'>Bitte gebe an, f�r wieviel Gold Du Dich verkaufen m�chtest und das Zimmer heissen soll.:<br><br>",true);

output("<table><tr><td>Kosten:</td><td>Zimmername:</td></tr>",true);

output("<td valign=top><input name='kosten' size='15'></td>",true);

output("<td valign=top><input name='raum' size='30'></td>",true);

// output("<td valign=top><input name='id' size='10'></td>",true);

output("</table><input type='submit' value='Abschicken'></form>",true);

addnav("","frdnhaus.php?op=send");

output("`n");

break;

// ######################################################################################################



// Absenden und Eintragen

// ######################################################################################################

case "send";        

if ($_POST["kosten"]<="20000" && $_POST['kosten']!="" && $_POST['raum']!=""){

$sql = "INSERT INTO frdn (acctid,user,kosten,sex,raum) VALUES ('".$session['user']['acctid']."','".$session['user']['name']."','".$_POST['kosten']."','".$session['user']['sex']."','".$_POST['raum']."')";

$result = db_query($sql) or die(db_error(LINK));

$id = db_insert_id(LINK);

$session['user']['gold']-=$verw;

$session['user']['room']=1;

// $session['user']['house'] = $houseid;

//$session['user']['roomid'] = $_POST['id'];

$session['user']['roomid'] = $id;

output("Erfolgreich eingetragen. Ihr m�sst jetzt nurnoch warten, bis sich jemand meldet.");

addnav("Zur�ck ins Dorf","village.php");

}

else if ($_POST["raum"]=="" || $_POST["kosten"]==""){

        output("Bitte alle Felder ausf�llen.");

        addnav("Zur�ck","frdnhaus.php?op=anbiet"); 

        

}

else if($_POST['kosten']>"20000"){

output("Bitte einen Preis unter 20000 Gold w�hlen.");

addnav("Zur�ck","frdnhaus.php?op=anbiet");

addnav("Zur�ck ins Dorf","village.php");

}        

break;

// ######################################################################################################





// 'Partner' ausw�hlen

// ######################################################################################################

case "ver";

output("<table cellpadding=2 cellspacing=1 bgcolor='#999999' align='center'><tr class='trhead'><td>Zimmername</td><td>Name</td><td>Kosten</td><td>Nummer</td>",true);
if ($session['user']['superuser']>0){
output("<td>Aktion</td></tr>",true);
}

    $sql = "SELECT id,user,raum,kosten,sex FROM frdn";

    $row = db_fetch_assoc($result);

    $result = db_query($sql) or die(db_error(LINK));



if (db_num_rows($result)==0){



    output("<tr class='trdark'><td colspan=5 align='center'>`&`iDerzeit bietet sich niemand an!`i`0</td></tr>",true);                

addnav("Zur�ck","frdnhaus.php");

} else {

        addnav("Doch lieber nicht","frdnhaus.php");

while ($row = db_fetch_assoc($result)) {

        

        $bgclass = ($bgclass=='trdark'?'trlight':'trdark');

        output("<tr class='".$bgclass."'><td><a href='frdnhaus.php?op=getroom&id=".$row['id']."' onClick='return confirm(\"Willst du wirklich in dieses Zimmer?\");'>".$row['raum']."</a></td><td>".$row['user'],true);

    output("</td><td>".$row['kosten']."</td><td>".$row['id']."</td>",true);
    if ($session['user']['superuser']>0){
    output("<td><a href='frdnhaus.php?op=zimmdel&id=".$row['id']."'>L�schen</a></td>",true);
}

    addnav("","frdnhaus.php?op=getroom&id=".$row['id']);
addnav("","frdnhaus.php?op=zimmdel&id=".$row['id']);
}

}

output("</table>",true);

output('</form>',true);

 

break;

// ######################################################################################################





// 'Partner' und Zimmer bekommen.

// ######################################################################################################

case "getroom";

$sql2 = "SELECT * FROM frdn WHERE id='$_GET[id]'"; 

$result2 = db_query($sql2);

$row = db_fetch_assoc($result2); 

$gold = $row['kosten'];

$id = $row['id'];

$acctid = $row['acctid'];



if($session[user][gold]>=$row[kosten]){ 

output("Du kannst nun in das Zimmer.");

addnav("Zur�ck","frdnhaus.php");

$session['user']['roomid'] = $row['id'];  

$session['user']['gold'] -= $gold;

$session['user']['room']=1;

$sql = "UPDATE accounts SET goldinbank = goldinbank+$row[kosten] WHERE acctid='{$row['acctid']}'";

db_query($sql) or die(db_error(LINK)); 

$sql9 = "INSERT INTO mail (msgfrom,msgto,subject,body,sent) VALUES ('`System`0','$row[acctid]','`^Freudenhaus!`0','`&{$session['user']['name']}`6 hat sich f�r ein Zimmer bei Dir beworben und Dir daf�r den Preis in H�he von ".$row['kosten']." Gold auf deine Bank �berwiesen!',now())";

db_query($sql9); 

$sql2="DELETE FROM frdn WHERE id='$_GET[id]'";

$result2=db_query($sql2); 

}

else if($session[user][gold]<$row[kosten]){

output("Das kannst Du Dir garnicht leisten!");

 addnav("Zur�ck","frdnhaus.php");

}

 



break;

// ######################################################################################################

// Zimmer l�schen "ja o. nein?"

//##############

case "zimmdel";


output("Willst du das Zimmer wirklich l�schen?");
addnav("Ja","frdnhaus.php?op=zimmdel1&id=".$_GET['id']."");
addnav("Nein","frdnhaus.php");

break;

//##############

// Zimmer l�schen

//##############

case "zimmdel1";

$sql3 = "DELETE FROM frdn WHERE id='$_GET[id]'";

$result3 = db_query($sql3); 


output("Du hast das Zimmer ".$_GET['id']." erfolgreich gel�scht.");
addnav("Zur�ck","frdnhaus.php");


break;
//##############

// Abschlusszeug

//##############

endswitch;

page_footer();

//###############

?>