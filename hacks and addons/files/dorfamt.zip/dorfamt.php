<?php

// Dorfamt
// Make by Kevz
// 05-09-2004 September
// E-Mail: logd@gmx.net
//
// Copyright 2004 by Kevz
//
//
// Edit by
// Avengar
// 18. Feb 2008
// Mail: wow-nc.com
// Edit for: wconline.wow-nc.com
//
// Copyright:
// 2008 by Avengar & Kevz  
//
// Anleitung findet ihr auf www.anpera.net
// oder auf Anfrage bei E-Mail: avengar@wow-nc.com

require_once "common.php";

page_header("Das Dorfamt");

    if ($session[user][loggedin]) {
$session[user][ort]='Dorfamt';
}

if (!isset($session)) exit();
if ($_GET[op]=="")
{   output("`c`b`&Das Dorfamt`0`b`c`n`n");
    output("`2Langsam n�herst du dich den gro�en Torfl�geln, als du sie �ffnest stehst du in einer
    gro�en Halle, die an beiden Seiten von wei�en Marmors�ulen ges�umt wird.
    Gegen�ber des Eingangstores befindet sich ein freundlich aussehender Schreibtisch mit einer
    noch freundlicheren Dame dahinter, die sich mit einigen Papieren besch�ftigt.
    An der Wand hinter dem Schreibtisch h�ngt ein Schild mit der Aufschrift`n");
    output("`c`2Derzeit befinden sich in der Amtskasse `^" .getsetting ("amtskasse" ,0). " `2Goldst�cke !`c", true);
    output("`n`2 Als Du n�her trittst hebt die Empfangsdame den Blick, sieht Dich an und fragt nach Deinem Begehr!`n
    \"`@Willkommen, bitte nicht wundern, die Amtssprache wird Euch seltsam erscheinen. Was kann ich f�r Euch tun? \"");
    output("`n`n") ;



    addnav("Informationen");
    addnav("Spielregeln?","dorfamt.php?op=rules");
    addnav("Steuern?","dorfamt.php?op=steuern");
    addnav("Ruhmeshalle","hof.php");

    addnav("Wichtiges...");
    addnav("Steuern Zahlen","dorfamt.php?op=steuernzahlen");
    addnav("Die Amtskasse","dorfamt.php?op=amtskasse");
    //addnav("Der Magistrat","dorfamt.php?op=magistrat");

    //addnav ("Wahlen");
   // addnav ("Wahlzimmer", "wahlzimmer.php");

  addnav("Sonstiges...");
  addnav("Diskussionen","dorfamt.php?op=diskus");

//addnav ("Gericht", "court.php");
    addnav("Zum Dorf");
    addnav("Z?Zur�ck","village.php");
}

else if ($_GET[op]=="rules")
{
    output("`2Du erkundigst dich nach den Regeln und Gesetzen dieser Welt und die freundliche Empfangsdame h�ndigt Dir folgende Liste aus:`n

    `^Allgemeines:`n`2
    1.Kein Spammen! Alles spielunrelevante (Internetadressen, Warez, Porn, Rassismus o.�.)sind verboten`n
    2.Kein Spieler wird beleidigt, es sei denn es geh�rt zum Rollenspiel und eine standesgem��e Herausforderung folgt!`n
    3.Was die Admins sagen ist Gesetz, schlie�lich sind sie nicht umsonst Admins!`n
    4.OOC, oder \"out of character\"-Gespr�che sind auf ein Minimum zu reduzieren`n`n

    `^Wichtiges:`n`2
    Diese Liste ist erweiterbar und wird mit Ihrer Erweiterung sofort g�ltig. Sollte eine Regel nicht hier stehen,
    so ist dies kein Aufruf den Umstand auszunutzen. Im Sinne eines guten Rollenspieles!`n`n
    Der Server auf dem dieses Spiel l�uft, geh�rt dem Admin und wird freiwillig und kostenlos zur Verf�gung gestellt.
    Sollte der Server in irgendeiner Art und Weise kompromittiert werden, in Form von Hacks, Attacken o.�., ist mit
    Ausschluss der ausf�hrenden Person vom Spiel zu rechnen!");


    addnav("Wege");
    addnav("Z?Zur�ck","dorfamt.php");
}

else if ($_GET[op]=="steuern")
{
    output("`2Du erkundigst dich nach den Steuern...`n
    Das Pergament, das Dir von der Empfangsdame gegeben wird, zeigt Dir folgendes:
    `n`n
    `^Steuern f�r Neuank�mmlinge:`n`2
    Neuank�mmlinge sind bis zum ersten Drachenkill Steuerfrei, dannach m�ssen sie die f�r B�rger normalen Steuern zahlen!!
    `n`n`n
    `^Steuern f�r B�rger:`n`2
    Die Steuer betr�gt f�r B�rger `^500Gold`2! Dieses Z�hlt bis zum 10 Sieg �ber den Drachen, dannach werden sie zum Adel und zahlen auch dieselben Steuern.....
    `n`n`n
    `^Steuern f�r den Adel und K�mpfer:`n`2
    Die Steuer betr�gt f�r den Adel und K�mpfer `^2500Gold`2!
    `n`n`n
    ");
    addnav("Wege");
    addnav("Z?Zur�ck","dorfamt.php");
}

else if ($_GET[op]=="amtskasse")
{
    output("`2Du l�ufst durch die G�nge des Amtes...`n
    Als Du einige Herren �ber die AMtskasse reden h�rst, stellst Du Dich wie beil�ufig daneben
    und erf�hrst, dass die Amtskasse zur Zeit `^" .getsetting ("amtskasse" ,0). " `2Goldst�cke enth�lt!");

    addnav("Wege");
    addnav("Zur�ck","dorfamt.php");

}elseif($_GET[op]=="dame1") {
    output ("`&Du schaust dich ein wenig in den Vorzimmern der hohen Herren um und entdeckst, h�bsch geschminkt und �ber und �ber mit Ringen, Ketten und Broschen behangen, das furchteinfl��endsde und gef�hrlichste Wesen, dass dir je begegnet ist : `^die Vorzimmerdame`&!`n");
    output ("`&Sie ist es die in Vornehmen Kreisen die neuesten Ger�chte unter den Mann bringt und dabei auch gut und gern ihr schlechtes Ged�chtnis mit ihrer Phantasie unterst�tzt.`nDie bleibt fast das Herz stehen als sie dich ansieht und erwartungsvoll mit den Wimpern klimpert.");
    addnav("Was nun ?");
    addnav("Ansehen steigern","dorfamt.php?op=dame2");
    addnav("Ger�chte streuen","dorfamt.php?op=dame3");
    addnav("Laufen!","dorfamt.php");

}elseif($_GET[op]=="dame2") {
    output ("Nachdem du der Vorzimmerdame mitgeteilt hast, dass du gern ein wenig beliebter w�rst und dass dich keiner so richtig leiden kann, wischt sie sich demonstrativ ein Tr�nchen von der Wange und schaut dich an. \"`#Na das d�rfte nicht allzu schwer sein. Ich kann den Leuten ja mal erz�hlen was f�r ein tolle".($session[user][sex]?"s M�del ":"r Bursche ")."du bist.`nSo eine kleine Heldengeschichte hat aber ihren Preis... 2 Edelsteine!\"`n`n");
    output ("`&Wieviele Edelsteine willst du ihr geben?");
    output("<form action='dorfamt.php?op=dame21' method='POST'><input name='buy' id='buy'><input type='submit' class='button' value='Geben'></form>",true);
    output("<script language='JavaScript'>document.getElementById('buy').focus();</script>",true);
    addnav("","dorfamt.php?op=dame21");
    addnav("Lieber doch nicht","dorfamt.php?op=dame1");

}else if ($_GET[op]=="dame21") {
    $buy = $HTTP_POST_VARS[buy];
    if (($buy>$session['user']['gems']) || ($buy<1)) {
        output("`&Na das ging nach hinten los... Du bietest ihr Edelsteine an, die du nicht hast. In der Hoffnung, dass sie nun keine Ger�chte �ber deine Armut streut, eilst du davon.");
        addnav("Weg hier!","village.php");
    } else {
        $eff=$buy/2;
        output("`&Die Dame l�sst deine $buy Edelsteine in ihrem Handt�schchen verschwinden und l�chelt dich an. Dein Ansehen steigt um $eff.`n");
        $session['user']['gems']-=$buy;
        if ($buy>10) {
            debuglog("Gibt $amt Edelsteine im Dorfamt f�r Ansehen.");
        }
        $session['user']['reputation']+=$eff;
        if ($session['user']['reputation']>50) {
            $session['user']['reputation']=50;
        }
        addnav("Zur�ck","dorfamt.php?op=dame1");
    }

}elseif ($_GET[op]=="dame3") {
output("`&Die Frau schaut dich an. \"`#Sooo... und um wen geht es?`&\" fragt sie.`n`n");

    if ($HTTP_GET_VARS[who]==""){
    addnav("�h.. um niemanden!","dorfamt.php");
    if ($_GET['subop']!="search"){
                    output("<form action='dorfamt.php?op=dame3&subop=search' method='POST'><input name='name'><input type='submit' class='button' value='Suchen'></form>",true);
                    addnav("","dorfamt.php?op=dame3&subop=search");
                }else{
                    addnav("Neue Suche","dorfamt.php?op=dame3");
                    $search = "%";
                    for ($i=0;$i<strlen($_POST['name']);$i++){
                        $search.=substr($_POST['name'],$i,1)."%";
                    }
                    $sql = "SELECT name,alive,location,sex,level,reputation,laston,loggedin,login FROM accounts WHERE (locked=0 AND name LIKE '$search') ORDER BY level DESC";
                    $result = db_query($sql) or die(db_error(LINK));
                    $max = db_num_rows($result);
                    if ($max > 50) {
                        output("`n`n\"`#Na... damit k�nnte ja jeder gemeint sein..`&`n");
                        $max = 50;
                    }
                    output("<table border=0 cellpadding=0><tr><td>Name</td><td>Level</td></tr>",true);
                    for ($i=0;$i<$max;$i++){
                        $row = db_fetch_assoc($result);
                        output("<tr><td><a href='dorfamt.php?op=dame3&who=".rawurlencode($row[login])."'>$row[name]</a></td><td>$row[level]</td></tr>",true);
                        addnav("","dorfamt.php?op=dame3&who=".rawurlencode($row[login]));
                    }
                    output("</table>",true);
                }
            }else{

                    $sql = "SELECT acctid,login,name,reputation FROM accounts WHERE login=\"$HTTP_GET_VARS[who]\"";
                    $result = db_query($sql) or die(db_error(LINK));
                    if (db_num_rows($result)>0){
                        $row = db_fetch_assoc($result);

    output ("`&Die Vorzimmerdame l�chelt. \"`#Aber nat�rlich! ".($row['name'])." `#! Der Name ist mir ein Begriff... Ich denke dass ich sicherlich ein paar alte Geschichten bekannt werden lassen kann.`nDie Leute sollen ruhig wissen mit wem sie es da zu tun haben! Aber... die Sache wird nicht ganz billig werden, denn ich muss sehr viel in den Akten suchen... und...so.`nEin kleines Ger�cht w�rde 2 Edelsteine kosten..\"`&`n`n");
    output ("`n`&Wieviele Edelsteine willst du ihr geben?");
    output("<form action='dorfamt.php?op=dame31&who=".rawurlencode($row[login])."' method='POST'><input name='buy' id='buy'><input type='submit' class='button' value='Geben'></form>",true);
    output("<script language='JavaScript'>document.getElementById('buy').focus();</script>",true);
    addnav("","dorfamt.php?op=dame31&who=".rawurlencode($row[login])."");
    addnav("Lieber doch nicht","dorfamt.php?op=dame1");
                    }else{
                        output("\"`#Ich kenne niemanden mit diesem Namen.`&\"");
                    }
                }
} else if ($_GET[op]=="dame31") {
    $buy = $HTTP_POST_VARS[buy];
    $sql = "SELECT acctid,name,reputation,login,sex FROM accounts WHERE login=\"$HTTP_GET_VARS[who]\"";
                    $result = db_query($sql) or die(db_error(LINK));
                    if (db_num_rows($result)>0){
                            $row = db_fetch_assoc($result);

            if (($buy>$session['user']['gems']) || ($buy<1)) {
                output("`&Na das ging nach hinten los... Du bietest ihr Edelsteine an, die du nicht hast. In der Hoffnung, dass sie nun keine Ger�chte �ber DICH verstreut, eilst du davon.");
                addnav("Weg hier!","village.php");
            }else{
                $eff=$buy/2;
                output("`&Die Dame l�sst deine $buy Edelsteine in ihrem Handt�schchen verschwinden und l�chelt dich an. Das Ansehen von ".($row['name'])."`& sinkt um $eff.`n");
                $session['user']['gems']-=$buy;
                if ($buy>10) {debuglog("Gibt $amt Edelsteine im Dorfamt f�r Ger�chte.");}
                $rep=$row['reputation']-$eff;
                if ($rep<-50) {$rep=-50;}

                $sql = "UPDATE accounts SET reputation=$rep WHERE acctid = ".$row['acctid']."";
                db_query($sql) or die(sql_error($sql));

                $chance=e_rand(1,3);
                if ($chance==1) {
                    systemmail($row['acctid'],"`\$Ger�chte!`0","`@{$session['user']['name']}`& hat die Vorzimmerdame im Dorfamt bestochen, damit diese �ble Ger�chte �ber dich verbreitet! Dein Ansehen ist um $eff Punkte gesunken! Willst du dir sowas gefallen lassen ?");
                }else {
                    systemmail($row['acctid'],"`\$Ger�chte!`0","`&Jemand hat die Vorzimmerdame im Dorfamt bestochen, damit diese �ble Ger�chte �ber dich verbreitet! Dein Ansehen ist um $eff Punkte gesunken! Willst du dir sowas gefallen lassen ?");

                }
                if ($buy >= 10) {
                    $news="`@Ger�chte besagen, dass `^".$row['name']."";
                    switch(e_rand(1,15)) {
                        case 1 :
                        $news=$news." `@heimlich in der Nase bohrt!";
                        break;
                        case 2 :
                        $news=$news." `@nicht ohne ".($row[sex]?"ihr":"sein")." Kuscheltier einschlafen kann!";
                        break;
                        case 3 :
                        $news=$news." `@etwas mit ".($row[sex]?"Violet":"Seth")." am Laufen haben soll!";
                        break;
                        case 4 :
                        $news=$news." `@ganz �bel aus dem Mund riechen soll.";
                        break;
                        case 5 :
                        $news=$news." `@mehr Haare ".($row[sex]?"an den Beinen ":"auf dem R�cken ")."haben soll als ein B�r!";
                        break;
                        case 6 :
                        $news=$news." `@sich regelm��ig am Bettelstein bedienen soll!";
                        break;
                        case 7 :
                        $news=$news." `@sich bei Angst die Hosen vollmachen soll!";
                        break;
                        case 8 :
                        $news=$news." `@im Bett eine Niete sein soll!";
                        break;
                        case 9 :
                        $news=$news." `@f�r Geld die H�llen fallen lassen soll!";
                        break;
                        case 10 :
                        $news=$news." `@ein Alkoholproblem haben soll!";
                        break;
                        case 11 :
                        $news=$news." `@Angst im Dunkeln haben soll!";
                        break;
                        case 12 :
                        $news=$news." `@einen Hintern wie ein Ackergaul haben soll!";
                        break;
                        case 13 :
                        $news=$news." `@sehr oft bitterlich weinen soll!";
                        break;
                        case 14 :
                        $news=$news." `@eine feuchte Aussprache haben soll!";
                        break;
                        case 15 :
                        $news=$news." `@eine Per�cke tragen soll!";
                        break;
                    }

                    // In die News und in die Bio des Opfers
                    $sql = "INSERT INTO news(newstext,newsdate,accountid) VALUES ('".addslashes($news)."',NOW(),".$row[acctid].")";
                    db_query($sql) or die(sql_error($sql));
                }
            addnav("Zur�ck","dorfamt.php?op=dame1");
        }

    }




}else if ($_GET[op]=="steuernzahlen")
{
    output("\"`@Steuern zahlen k�nnt Ihr dritten Gang rechts...\"`n
    `2Als Du zu einem kleinen alten Mann kommst, blickt dieser auf und sagt:`n
    `@\"Also du willst steuern Zahlen?`n
    Hm, ich guck ma deine Akte durch! Moment bitte...Da ist sie ja\"`n");

    if ($session['user']['marks']<31) {

        output("`^Privatakte...`n`n");
        output("`2Name: `^".$session[user][name]."`n");
        output("`2Alter: `^".$session[user][age]."`^ Tage`n");
        output("`2Level: `^".$session[user][level]."`n`n");

        output("`^Sonstige Informationen...`n`n");
        output("`2Gold: `^".$session[user][gold]."`n");
        output("`2Edelsteine: `^".$session[user][gems]."`n");
        output("`2Gold auf der Bank: `^".$session[user][goldinbank]."`n");

        addnav("Steuern");
        if ($session[user][dragonkills]>=1){ addnav("Steuern zahlen","dorfamt.php?op=steuernzahlen_ok"); }

    }
    else
    {
     output ("`n`n`2Der alte Mann l�chelt dich pl�tzlich ganz f�rsorglich an und sagt:`n");
     output ("    `@\"Euren Gro�mut in Ehren, aber Auserw�hlte zahlen keine Steuern...\"`n");
    }
    addnav("Wege");
    addnav("Zur�ck","dorfamt.php");
}

else if ($_GET[op]=="diskus")
{
    output("`2Der Debattierraum liegt vor Dir!`n
    Hier bekommt das Volk Geh�r und die Admins h�ren sich W�nsche, Anregungen und Beschwerden an.");
    output("Wie Dir scheint ist schon eine rege Diskussion im Gange!`n`n");
    //output("Neue Beitr�ge bitte in Gelb`n`n");
    addcommentary();
    viewcommentary("rat","Rufen",30,"ruft");
    addnav("Zur�ck","dorfamt.php");
}

else if ($_GET[op]=="ooc")
{
    output("`2OOC Raum-komischer Name, denkst Du Dir, als Du die T�r zu diesem Raum aufst�sst!`n");
    output("�berall an den W�nden stehen leuchtende Scheiben und einige dir bekannte und weniger
    bekannte Gesichter starren wie gebannt darauf und klimpern auf bemalten Brettern herum-seltsame Runen`n`n");
    output("`^Du hast den OOC Raum betreten. Wenn Du Gespr�che f�hren m�chtest, die sich au�erhalb Deines Charakters befinden,
    so f�hre sie bitte hier! Sollten sich andere Mitspieler irgendwo anders OOC unterhalten, dann weise sie bitte freundlich
    per Ye Olde Mail darauf hin, dass dies hier der richtige Ort daf�r w�re!`n`n");
    addcommentary();
    viewcommentary("OOC","Tippen",30,"tippt");
    addnav("Zur�ck","dorfamt.php");
}

else if ($_GET[op]=="steuernzahlen_ok")
{

    $cost = ($session['user']['dragonkills'] >= 1) ? 500 : 200;

    if ($session[user][steuertage]<=10)
    {
        if ($session[user][gold]>=$cost)
        {
            output("`2Du zahlst deine `^".$cost." Gold`2 ein!`n
            `^Wenigstens einer der die Steuern hier bezahlt...`n
            `2Der Kassier grinst dich an und verabschiedet dich! ");
            $session[user][gold]-=$cost;
            savesetting ("amtskasse" ,getsetting ("amtskasse",0)+ $cost);

        }
        else
        {
            output("`2Der Mann sagt: `^Du hast nicht genug Gold dabei, wie willst Du da die ".$cost." zahlen?`n");
            output("`^Gut, dann nehmen wir halt etwas von der Bank, hm?`n");
            if($session[user][goldinbank]<$cost)
            {
                output("`^Auch nicht? Dann halt Edelsteine!`n");
                if($session[user][gems]<1)
                {
                    output("`^Du armer Tropf, Du hast ja gar nichts! Na gut, dieses mal sehe ich noch dar�ber hinweg! Troll Dich`n");
                }
                else
                {
                    output("`^Na wenigstens etwas...jetzt troll Dich!`n");
                    $session[user][gems]--;
                    savesetting ("amtskasse" ,getsetting ("amtskasse",0)+ $cost);
                }
            }
            else
            {
                output("`^Na wenigstens etwas...jetzt troll Dich!`n");
                $session[user][goldinbank]-=$cost;
                savesetting ("amtskasse" ,getsetting ("amtskasse",0)+ $cost);
            }

        }    // END nicht genug Gold in Hand

    $session[user][steuertage]=10;

    }
    else
    {
        output("`2Der Mann sagt: `^Du brauchst heute noch keine Steuern zahlen");
    }

    addnav("Zur�ck","dorfamt.php");
}


page_footer();
?>