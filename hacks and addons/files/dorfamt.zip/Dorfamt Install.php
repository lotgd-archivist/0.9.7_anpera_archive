GrundSource:

Dorfamt.php
Make by Kevz
05-09-2004 September
E-Mail: logd@gmx.net

Copyright 
2004 by Kevz



Edit by
Avengar
18. Feb 2008
Mail: wow-nc.com
Edit for: wconline.wow-nc.com

Copyright:
2008 by Avengar & Kevz  

Anleitung findet ihr auf www.anpera.net
oder auf Anfrage bei E-Mail: avengar@wow-nc.com

__________________________________________________

Installations Anleitung:

1. SQL Datein Einf�gen..

- Die folgenden SQL-Befehle einfach in euer PHPMYADIN einf�gen!!


ALTER TABLE `accounts` ADD `wahlen` INT( 11 ) UNSIGNED DEFAULT '1' NOT NULL ;
ALTER TABLE `accounts` ADD `steuertage` INT( 11 ) UNSIGNED DEFAULT '4' NOT NULL ;
ALTER TABLE `accounts` ADD `locate` INT( 11 ) UNSIGNED DEFAULT '0' NOT NULL ;
ALTER TABLE `accounts` ADD `ort` INT( 11 ) UNSIGNED DEFAULT '0' NOT NULL ;



_________________________________________

2. Navigation vom Dorf... 

!!!![Dieser Teil ist bei fast jedem anders... Hier ist mal ein Standart Beispiel angegeben!!!!


- �ffnet nun die village.php und sucht:

addnav("Tavernenstrasse");

- Dort habt ihr dann untendrunter "MEIST" noch diese befehle stehen:


addnav("E?Schenke zum XXXXXX","inn.php",true);  [XXXXXX] = Name eurer Schenke!!
addnav("Mericks St�lle","stables.php");
if (@file_exists("lodge.php"))	addnav("J?J�gerh�tte","lodge.php");
addnav("G?Der Garten", "gardens.php");
addnav("F?Seltsamer Felsen", "rock.php");
 
 
-Dr�ckt nun nach  => addnav("F?Seltsamer Felsen", "rock.php"); ENTER

- und f�gt folgendes ein:

addnav("Rathausplatz");
addnav("Dorfamt","dorfamt.php");


3. �nderungen in der newday.php [Bitte genau beachten, da sonst z.B. die Steuertage nicht gez�hlt werden]

 
Jetzt �ffne die newday.php und suche folgendes:

output("`2Dein heutiger Zinssatz betr�gt `^0% (Die Bank gibt nur den Leuten Zinsen, die daf�r arbeiten)`n");
		}
		
F�ge dannach ein:

if ($session[user][steuertage]==3) {output("`^`cDu hast noch 2 Tage Zeit um die Steuern zu zahlen!`c`n`n");}
 if ($session[user][steuertage]==2) {output("`^`cDu hast noch 1 Tag Zeit um die Steuern zu zahlen!`c`n`n");}
 if ($session[user][steuertage]==1) {output("`^`cHeute is Zahltag, du musst heute Steuern zahlen!");}

 if ($session[user][steuertage]==0) {output("`^Da du Deine Steuern nicht gezahlt hast, wie es dir gesagt wurde, wurde etwas Gold von der Bank gepf?ndet!`n`n");
         savesetting ("amtskasse" ,getsetting ("amtskasse",0)+ 2500);
         $session[user][goldinbank]-=2500;
        if($session[user][goldinbank]<1)
      {$session[user][goldinbank]=0;}
       $session[user][steuertage]=4;
       $soandso = $session[user][name];
      addnews("`2$soandso `2hat die Steuern nicht gezahlt!`n");}


- Dann suche: [!! WICHTIG !!]

 $session[user][age]++;(done)

F�ge dannach ein: [!! WICHTIG !!]

 if($session[user][level]>=5){ $session[user][steuertage]-=1; }
 
____________________________________________________________


Jetzt nur noch die dorfamt.php in euer LoGD verzeichniss packen und Fertig!!!

____________________________________________________________

Solltet ihr dieses Richtig gemacht haben, solltet ihr und eure User nun nach dem 1 Drachenkill Steuern Zahlen m�ssen! (naja... 2 tage nach 1. DK)

____________________________________________________________


Noch zu Tun:

* B�rger und Adels Anpassung
* Gericht und Pranger einf�gen
* Wahlzimmer und  Magistrat fertig stellen :)

______________

Weiter infos auf 

www.anpera.net // PN an Avengar\\

oder 

Mail an avengar@wow-nc.com




