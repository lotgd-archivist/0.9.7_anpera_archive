**************EINLEITUNG********************************************************
Das Berufs-script ist ein Projekt von Savomas und mir.
Wir haben das eigentlich f�r unseren Server optimiert geschrieben, mit dem 
Hintergedanken, es so Benutzerfreundlich zu machen, dass auch andere Admins
damit ihren Spa� haben, deswegen ist das Berufsscript komplett DB basiert,
w�hrend sich das Universit�ts-Script nicht per Admin-Grotte ver�ndern l�sst,
Jobs k�nnen beliebig in das Arbeitsamt eingef�gt werden, und auch deren Werte,
k�nnen komplett ge�ndert werden, seit der ersten Version ist das Script auf
flexibilit�t ausgelegt, daher bitte ich W�nsch und Anregungen sofort an uns
weiter zu leiten, Kontakte gebe ich unten an.
Mfg Gimmick (a.k.a. Tiresias)
********************************************************************************

**********KONTAKT*****************************
Gimmick:

Homep:    http://www.firedragonfly.de
email: webmaster@firedragonfly.de
ICQ  : -------------------------

Savomas:

Homep: http://www.ocasia.de
email: ------------------------
ICQ  : ------------------------
**********************************************

************CHANGELOG*************************

0.1v
	-Entwicklung der su-job.php
	-Entwicklung der job.php
	-Universit�t ohne Campus
0.2v
	-Erste Bugfixes
	-Designanpassung
	-su-job.php komplett �berarbeitet
	-job.php fertigstellung auf BETA-Status
0.3v
	-Neue Bugfixes
	-Designoptimierung und erste Rechtschreibfehlerkorrektur
	-su-job.php operation:deljob fertiggestellt
	-job.php Spr�che verbessert
0.4v
	-gr�bere Bugfixes
	-su-job.php BUGFREE (hoffentlich)
	-zus�tzliche sql Spalte eingef�gt
0.5v
	-newday.php Befehle konzipiert
	-job.php abgeschlossen
	-Universit�t ohne Campus erreicht BETA-Status
1.0v
	-su-job.php Code optimiert/kommentiert
	-job.php Code optimiert/kommetiert
	-uni.php BUGFREE Code optimiert/kommentiert
	(Addon: Campus (beta-status)
**********************************************

*********EINBAU*****************************

//SQL Ausf�hren:

-- 
-- Tabellenstruktur f�r Tabelle `jobs`
-- 
CREATE TABLE `jobs` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `lohn` int(11) unsigned NOT NULL default '0',
  `turns` int(11) unsigned NOT NULL default '0',
  `name` varchar(50) NOT NULL default '0',
  `aubid` int(11) unsigned NOT NULL default '0',
  `listorder` int(10) unsigned NOT NULL default '1',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) TYPE=MyISAM AUTO_INCREMENT=4 ;

-- 
-- Strukturen in Tabelle `accounts`
-- 
 `jobname` varchar(50) NOT NULL default '0',
`jobid` int(11) unsigned NOT NULL default '0',
`aubid` int(11) unsigned NOT NULL default '0',
`lektion` int(11) NOT NULL default '0',

//SQL-ENDE

1.�FFNE village.php

SUCHE: addnav("E?Schenke zum Eberkopf","inn.php",true);

DANACH: 
addnav ("Universit�t","uni.php");
addnav ("Arbeitsamt","job.php");

SPEICHERN & SCHLIESSEN

2.�FFNE superuser.php

SUCHE: addnav("Wortfilter","badword.php");

F�GE DANACH EIN:
	addnav ("Job-System");
	addnav ("Editor","su-job.php");
	addnav ("Arbeitsamt `$ *BETA*","job.php");
	addnav ("Universit�t `$ *BETA*","uni.php");

SPEICHERN & SCHLIESSEN

3.�FFNE newday.php

SUCHE:page_footer();
?>

F�GE DAVOR EIN:
	//Beruf-Script (0.5v)
if ($session[user][jobid]>=1 && $session['user']['race']!=0 && $session['user']['specialty']!=0){
	$sql = "SELECT name,id,lohn,turns FROM jobs";
      	$result = db_query('SELECT `name`,`id`,`lohn`,`turns` FROM `jobs` WHERE `id` = '.$session['user']['jobid']);
  	while ($job = db_fetch_assoc($result)) {
		if ($job['turns']>$session['user']['turns']){
	output ("`$ `b Du bist zu ersch�pft um zu arbeiten, und wirst daher von deinem Arbeitgeber gefeuert!");
	$session['user']['jobid']=0;
	$session['user']['jobname']="Arbeitsloser";
		} else {
	output ("Da du ein flei�iger ".$job['name']." bist, erh�lst du deinen Tageslohn von ".$job['lohn']."!");
	$session['user']['gold']+=$job['lohn'];
	$session['user']['turns']-=$job['turns'];
		}
	}
}else{
output ("`6 Du bist leider Arbeitslos, daher bekommst du keinen Lohn");
}
// Ende Berufs-Script (0.5v)

**************************************************

*********EXTRAS***********************************

Vital-Info-Anzeige
	CHANGE common.php

	FIND:
 .templatereplace("statrow",array("title"=>"Edelsteine","value"=>"".$u['gems']." ".$gems.""))


	DAVOR:
		.templatereplace("stathead",array("title"=>"Ausbildung"))
		.templatereplace("statrow",array("title"=>"Ausbildungszweig","value"=>$u['aubid']))
		.templatereplace("statrow",array("title"=>"Lektion","value"=>$u['lektion']))
		.templatereplace("statrow",array("title"=>"Beruf","value"=>$u['jobname']))


Biographie-Anzeige:
	CHANGE bio.php

	Finde: 
SELECT login,name,level

	Ersetze mit: 
SELECT login,name,level,jobname

	Finde: 
output("`^Spezialgebiet: `@".$specialty[$row[specialty]]."`n");

	Dahinter einf�gen:
output("`^Beruf: `@".$row[jobname]."`n");
*****************************************************