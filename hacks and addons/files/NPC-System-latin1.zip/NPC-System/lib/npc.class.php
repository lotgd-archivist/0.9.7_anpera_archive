<?php

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * *
* NPC-Verwaltungsklasse f�r das NPC-System
* Geschrieben von Auric (dom@toifras.de) (Aug-Sep 2007, Sep 2009)
* Freigegeben unter der GNU-GPL
* Version 1.2
* * * * * * * * * * * * * * * * * * * * * * * * * * * * */

if(!function_exists("StripTags")) {
	function StripTags($input) {
		// 2005 - 2007 by Eliwood
		$input = preg_replace("'[`][^` ]'","",$input);
		return str_replace('``', '`', $input);
	}
}

class npc {
	protected $id;
	protected $name;
	protected $ersteller;
	protected $erstellername;
	protected $erstellerlogin;
	protected $text;
	protected $avatar;
	protected $vater;
	protected $players = array();

	const GS_COST_PREFIX = 'NPC_COST_';

	/*** * * * * * * * * * * * * * * * * * * * * * * * * ***
	 *						 Objektinterne Methoden
	 *** * * * * * * * * * * * * * * * * * * * * * * * * ***/
	
	protected function playerLogins() {
		$sql = "SELECT `acctid`, `login` FROM `accounts` WHERE `acctid` IN (" . implode(',', array_keys($this->getAllPlayers())) . ")";
		$res = db_query($sql) or die(db_error());
		$ret = array();
		for($i = 0, $max = db_num_rows($res); $i < $max; $i++) {
			$row = db_fetch_assoc($res);
			$ret[$row['acctid']] = $row['login'];
		}
		return $ret;
	}

	/*** * * * * * * * * * * * * * * * * * * * * * * * * ***
	 *							�ffentliche Methoden
	 *** * * * * * * * * * * * * * * * * * * * * * * * * ***/
	
	public function __construct($id) {
		if (!empty($id)) {
			$row = db_fetch_assoc(db_query("SELECT npc.*, accounts.name AS erstellername, accounts.login AS erstellerlogin FROM `npc` INNER JOIN `accounts` ON npc.ersteller = accounts.acctid  WHERE `id`=" . $id));
			foreach ($row as $key => $val)
				$this->{$key} = $val;
		}
	}

	public function grantAcces($to = array(), $dontpay = false) {
		$canbuy = true;
		if (!$dontpay)
			$canbuy = self::buy('GRANT');
		if (!empty($to) && $canbuy) {
			$sql = "INSERT INTO `z_npc`(`user_id`,`npc_id`) VALUES ";
			for($i = 0, $max = count($to); $i < $max; $i++) {
				if ($i)
					$sql .= ", ";
				$sql .= "(" . $to[$i] . "," . $this->id . ")";
			}
			db_query($sql);
		}
	}

	public function printBio() {
		$line = "";
		if (!empty($this->id)) {
			page_header("NPC-Beschreibung f�r " . preg_replace("'[`].'", "", $this->name));
			$line = "`c`b`#NPC-Beschreibung f�r " . $this->name . "`0`b`c`n";
		}
		$line .= "<div>\n\t<div style='float: left; width: 200px; height: 200px; border: 0; margin : 0; padding : 0;'>\n";
		if (!empty($this->avatar)) {
			$pic_size = @getimagesize($this->avatar);
			$line .= "\t\t<img src='" . $this->avatar . "' " . ($pic_size[1] > 200 ? "height='200' " : '') . ($pic_size[0] > 200 ? "width='200' " : '');
			$line .= "alt='" . preg_replace("'[`].'", "", $this->name) . "' style='margin : 0; padding : 0;'>\n";
		} else {
			output("\t\t(kein Bild)\n");
		}
		$line .= "\t</div>\n<div>\n";
		
		$line .= "<div style=''>\n";
		$line .= "\t<p>`^Name:`0 " . $this->name . "</p>\n";
		$line .= "\t<p>`^Erstellt von:`0 <a href='bio.php?char=" . $this->erstellerlogin . "&ret=" . URLEncode($_SERVER['REQUEST_URI']) . "'>" . $this->erstellername . "</a></p>\n";
		$line .= "\t<p>`^Spieler, die diesen NPC verwenden d�rfen:`0 <br />";
		$plogins = $this->playerLogins();
		foreach ($this->getAllPlayers() as $key => $val) {
			$line .= "\t\t<a href='bio.php?char=" . $plogins[$key] . "&ret=" . urlencode($_SERVER['REQUEST_URI']) . "'>" . $val . "</a>, ";
			addnav('', "bio.php?char=" . $plogins[$key] . "&ret=" . urlencode($_SERVER['REQUEST_URI']));
		}
		$line .= "\t</p>\n";
		$line .= "\t<p>`^Beschreibung des NPCs: `0<br />\n" . str_replace("\n", "\n\t\t", $this->text) . "\n\t</p>\n";
		return $line;
	}

	public function printRow($rowclass) {
		$in = array($rowclass, $this->name, $this->erstellerlogin, URLEncode($_SERVER['REQUEST_URI']), $this->erstellername, implode(', ', $this->getAllPlayers()), $this->getLink());
		return vsprintf("<tr class='%s'><td>%s</td><td><a href='bio.php?char=%s&ret=%s'>`7%s`0</a></td><td>%s</td><td><a href='%s'>Bio</a></td>", $in);
	}

	public function previewRead($name, $text, $ersteller, $avatar = '') {
		$this->name = $name;
		$this->text = $text;
		$this->ersteller = $ersteller;
		$this->avatar = $avatar;
		$res = db_query("SELECT `name`,`login` FROM `accounts` WHERE `acctid` = " . $ersteller . " LIMIT 1") or die(db_error());
		$usr = db_fetch_assoc($res);
		$this->erstellerlogin = $usr['login'];
		$this->erstellername = $usr['name'];
		$this->players = array($ersteller => $usr['name']);
	}

	/*** * * * * * * * * * * * * * * * * * * * * * * * * ***
	 *						Getter & Setter
	 *** * * * * * * * * * * * * * * * * * * * * * * * * ***/
	
	public function getLink() {
		return "npc.php?op=bio&id=" . $this->id . "&ret=" . URLEncode($_SERVER['REQUEST_URI']);
	}

	public function change($what, $to) {
		if (self::buy($what)) {
			$this->{strtolower($what)} = nl2br($to);
			db_query("UPDATE `npc` SET `" . strtolower($what) . "`='" . nl2br($to) . "' WHERE `id`=" . $this->id . " LIMIT 1");
			return true;
		} else
			return false;
	}

	public function getAllPlayers($refresh = false) {
		if (empty($this->players) || $refresh === true) {
			$result = db_query("SELECT `acctid`, `name` FROM `accounts` a INNER JOIN `z_npc` ON `a`.`acctid` = `z_npc`.`user_id` WHERE `npc_id`=" . $this->id);
			for($i = 0, $max = db_num_rows($result); $i < $max; $i++) {
				$row = db_fetch_assoc($result);
				$this->players[$row['acctid']] = $row['name'];
			}
		}
		return $this->players;
	}

	public function getName() {
		return $this->name;
	}

	public function getId() {
		return $this->id;
	}

	public function getErsteller() {
		return $this->ersteller;
	}

	public function getErstellerName() {
		return $this->erstellername;
	}

	public function getErstellerLogin() {
		return $this->erstellerlogin;
	}

	public function getText() {
		return $this->text;
	}

	public function getAvatar() {
		return $this->avatar;
	}

	/*** * * * * * * * * * * * * * * * * * * * * * * * * ***
	 *						Statische Methoden
	 *** * * * * * * * * * * * * * * * * * * * * * * * * ***/
	
	public static function create($name, $text, $ersteller, $avatar = '', $vater = 0) {
		if (self::checkNameUsed($name) && self::buy()) {
			db_query("INSERT INTO `npc`(`name`,`text`,`ersteller`,`avatar`,`vater`) VALUES ('" . $name . "','" . $text . "'," . $ersteller . ",'" . $avatar . "'," . $vater . ")") or die(db_error());
			$res = db_fetch_assoc(db_query("SELECT `id` FROM `npc` WHERE `name`='" . $name . "' LIMIT 1"));
			$npc = new npc($res['id']);
			$user = array($ersteller);
			$npc->grantAcces($user, true);
			return $npc;
		} else
			return false;
	}

	public static function checkNameUsed($name, $mode='EXACT') {
		# Es gibt 2 Modi f�r die Kontrolle. Entweder wird nur direkt nach dem Namen gesucht, oder aber mit % durchsetzt.
		switch (strtoupper($mode)) {
			# Wenn nach dem exakten Namen gesucht werden soll
			case 'EXACT':
				$strName = "%$name%";
				break;
			
			# Wenn nach dem ungef�hren Namen gesucht werden soll
			case 'ROUGH':
				$strName = chunk_split($name, 1, '%');
				break;
			
			default:
				die('Oooops - Diesen Kontrollmodus gibt es leider nicht');
				break;
		}
		$strName = StripTags($strName);
		$sql = sprintf("SELECT `login` AS `name`, 'Charaktername' AS `typ` FROM `accounts` WHERE `login` LIKE '%s' UNION SELECT `title` AS `name`, 'Charaktertitel' AS `typ` FROM `accounts` WHERE `title` LIKE '%s' UNION SELECT `name` AS `name`, 'NPC-Name' AS `typ` FROM `npc` WHERE `name` LIKE '%s'",$strName, $strName, $strName);
		$result = db_query($sql);
		if (db_num_rows($result) == 0)
			return false;
		else {
			$names = array();
			for($i=0, $max = db_num_rows($result); $i < $max; $i++) {
				$names[] = db_fetch_assoc($result);
			}
			return $names;
		}
	}

	public static function getActOf($userid, $asID = true) {
		$result = db_query("SELECT `npc`,`prefs` FROM `accounts` WHERE `acctid`=" . $userid . " LIMIT 1") or die(db_error(LINK));
		$usr = db_fetch_assoc($result);
		$npc = 0;
		if ($usr['npc']) { // User darf NPCs benutzen
			$prefs = unserialize($usr['prefs']);
			if ($prefs['akt_npc'] != 0) { // User hat gew�hlten NPC
				$sql = "SELECT `npc_id` FROM `z_npc` WHERE `npc_id`=" . $prefs['akt_npc'] . " AND `user_id`=" . $userid . " LIMIT 1";
				$result = db_query($sql);
				if (db_num_rows($result) > 0)
					$npc = $prefs['akt_npc'];
			}
			if ($npc == 0) { // Ersten NPC aus der Liste der Verfuegbaren fue diesen User waehlen
				$all = self::getAllOf($userid);
				$npc = $all[0];
			}
		}
		if ($asID == false && $npc != 0)
			$npc = new self($npc);
		return $npc;
	}

	public static function getAllOf($userid, $asID = true) {
		$result = db_query("SELECT `acctid`, `npc` FROM `accounts` WHERE `acctid`=" . $userid . " LIMIT 1") or die(db_error(LINK));
		$usr = db_fetch_assoc($result);
		$npcs = array();
		if ($usr['npc'] > 0 || !$userid) {
			$sql = "SELECT `n`.`id` FROM `npc` AS n, `z_npc` AS z WHERE `n`.`id`=`z`.`npc_id` " . ($userid ? "AND `z`.`user_id`=" . $userid : 'GROUP BY `n`.`id`');
			$result = db_query($sql) or die(db_error(LINK));
			for($i=0, $max = db_num_rows($result); $i < $max; $i++) {
				$row = db_fetch_assoc($result);
				if ($asID)
					$npcs[] = $row['id'];
				else
					$npcs[] = new self($row['id']);
			}
		}
		return $npcs;
	}

	public static function getCost($of = 'BUY') {
		return array('price' => getsetting(self::GS_COST_PREFIX . strtoupper($of), 0), 'cur' => self::getCurrency());
	}

	public static function getCurrency() {
		return getsetting('NPC_CURRENCY', 'dp');
	}

	public static function canbuy($what = 'BUY', $usernr = 0) {
		$cost = self::getCost($what);
		if ($usernr == 0) {
			global $session;
			$user = &$session['user'];
		} else {
			$sql = "SELECT `acctid`, " . ($cost['cur'] == 'rp' ? "`rpboni`" : "`donation`") . " FROM `accounts` WHERE `acctid`=" . $usernr . " LIMIT 1";
			$user = db_fetch_assoc(db_query($sql));
		}
		$toProof = ($cost['cur'] == 'rp' ? 'rpboni' : 'donation');
		$return = false;
		if ($user[$toProof] >= $cost['price'])
			$return = true;
		return $return;
	}

	public static function buy($what = 'BUY', $usernr = 0) {
		$result = 0;
		if (self::canbuy($what, $usernr)) {
			$result = 1;
			$cost = self::getCost(strtoupper($what));
			$p = ($cost['cur'] == 'rp' ? 'rpboni' : 'donation');
			if ($usernr != 0) {
				$dpsql = "";
				if ($cost['cur'] == 'dp')
					$dpsql = ", `donationspent` = `donationspent` + " . $cost['price'];
				db_query("UPDATE `accounts` SET `" . $p . "`=`" . $p . "`-" . $cost['price'] . $dpsql . " WHERE `acctid`=" . $usernr . " LIMIT 1");
			} else {
				global $session;
				$session['user'][$p] -= $cost['price'];
				if ($cost['cur'] == 'dp')
					$session['user']['donationspent'] += $cost['price'];
			}
		}
		return $result;
	}

	public static function activate($usernr = 0) {
		$match = false;
		if (self::buy('ACTIVATE', $usernr)) {
			if ($usernr != 0) {
				db_query("UPDATE `accounts` SET `npc`=1 WHERE `acctid`=" . $usernr . " LIMIT 1");
			} else {
				global $session;
				$session['user']['npc'] = 1;
			}
			$match = true;
		}
		return $match;
	}

	public static function previewCreate($name, $text, $ersteller, $avatar = '') {
		if(self::checkNameUsed($name))
			return null;
		$npc = new npc(null);
		$npc->previewRead($name, $text, $ersteller, $avatar);
		return $npc;
	}

}

?>