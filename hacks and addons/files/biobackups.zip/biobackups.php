<?
/* 
	
	Backups erzeugen der Biographien
	Danke an Eliwood, der mir wie immer geholfen hat, wenn ich nicht mehr weiter wusste *g*
	
	!Enth�lt Teile aus der mail.php (checkboxen markieren)!
	
	biobackups.php v.0.5
	made by Draza�ar
	http://logd.legend-of-vinestra.de
	drazaar@legend-of-vinestra.de
	
*/

########## EINBAU ########## 
#	CREATE TABLE `biobackups` (
#	  `owner` int(11) NOT NULL,
#	  `ownerlogin` varchar(255) collate latin1_german2_ci NOT NULL,
#	  `lastupdated` date NOT NULL,
#	  `bio` text collate latin1_german2_ci NOT NULL,
#	  PRIMARY KEY  (`owner`)
#	) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german2_ci;
#
#	Und nat�rlich noch in der superuser.php verlinken
#	if($session['user']['superuser']>=2) addnav('Biobackups', 'biobackups.php');
########## EINBAU ##########
	
	
require_once 'common.php';
page_header('Bio Backups');
isnewday(2);

switch($_GET['op']) {
	case '':
		$out .= '`c`b`&Biobackupeditor`b`c `n
				 `n
				 Unter `bBiographien backuppen`b kannst du Backups von Biographien erstellen, die noch nicht in der Tabelle stehen. `n
				 Unter `bBackups updaten`b kannst du die Backups aktualisieren. `n
				 Unter `bsuchen`b kannst du Backups von Biographien suchen. `n
				 Unter `bDatenbankoptionen`b kannst du Einstellungen bez�glich der Backuptabelle vornehmen. `n `n `n';
		
		
		$biosges = db_num_rows(db_query('SELECT owner FROM biobackups'));
		if($biosges == 0) {
			$sql = 'SELECT 
							acctid,
							login,
							bio
					FROM
							accounts
					WHERE 
							bio <> ""';
			$res = db_query($sql);
			$n = 0;
			while($bio = db_fetch_assoc($res)) {
				$sql = 'INSERT INTO
							biobackups
								(owner,
									 ownerlogin,
									 lastupdated,
									 bio)
						VALUES
								('.$bio['acctid'].',
								 "'.$bio['login'].'",
								 now(),
								 "'.addslashes($bio['bio']).'")';
				db_query($sql);
				$n++;
			}
			
			$out .= '`b`&Das Script erstellt beim ersten Ausf�hren automatisch die Backups! `n
					 Es wurden `i'.$n.'`i Biographien hinzugef�gt.`b `n`n`n';
		}		
		
		$biores = db_query('SELECT bio FROM biobackups');
		$wordges = 0;
		while($bio = db_fetch_assoc($biores)) {
			$words = Str_Word_Count($bio['bio']);
			$wordges = $wordges + $words;
		}
		
		$sql = 'SELECT
						b.owner
				FROM
						biobackups b
				LEFT OUTER JOIN
						accounts a
					ON 
						b.owner = a.acctid
				WHERE 
						a.acctid IS NULL
				ORDER BY 
						b.owner
					ASC';
		$res = db_query($sql);
		$oldchars = db_num_rows($res);
		
		$sql = 'SELECT
						a.acctid
				FROM
						accounts a
				LEFT OUTER JOIN
						biobackups b
					ON 
						a.acctid = b.owner
				WHERE 
						b.owner IS NULL
					AND
						a.bio <> ""
				ORDER BY 
						a.acctid 
					ASC';
		$res = db_query($sql);
		$newchars = db_num_rows($res);
			
		$out .= '`c`b`&Infos:`b`c `n
				 `n
				 `&Gespeicherte Bios: `7'.$biosges.'`& `n
				 Gesamte Wortzahl aller Bios: `7'.$wordges.'`& `n
				 Backups zuletzt geupdated: `7'.GetSetting('backupupdated', '0000-00-00').'`& `n
				 Bios von gel�schten/verfallenen Charas: `7'.$oldchars.'`& `n
			     Neue Biographien verf�gbar: `7'.$newchars;
		
		//addnav('Akt', 'biobackups.php');
		addnav('Aktionen');
		addnav('Neue Biographien backuppen', 'biobackups.php?op=backup1');
		addnav('Backups updaten', 'biobackups.php?op=update1');
		addnav('Suchen', 'biobackups.php?op=search');
		//addnav('Datenbankoptionen', 'biobackups.php?op=database');
		addnav('Zur�ck');
		addnav('Zur�ck zum Weltlichen', 'village.php');
		addnav('Zur�ck zur Grotte', 'superuser.php');
	break;
	
	case 'backup1':	
		$sql = 'SELECT
						a.acctid, 
						a.login,
						a.bio
				FROM
						accounts a
				LEFT OUTER JOIN
						biobackups b
					ON 
						a.acctid = b.owner
				WHERE 
						b.owner IS NULL
					AND
						a.bio <> ""
				ORDER BY 
						a.acctid 
					ASC';
		$res = db_query($sql);
		$n = db_num_rows($res);
		
		output('`c`b`&Neue Biographien hinzuf�gen`b `n
				<font size="-2">`i`b'.$n.'`b Ergebnisse gefunden`i</font>`c `n
				`n
		        <form action="biobackups.php?op=backup2" method="POST">', true);
		addnav('', 'biobackups.php?op=backup2');
		
		
		for($i=0; $i<$n; $i++) {
			$row = db_fetch_assoc($res);
			output('<table border="0" cellspacing="1" cellpadding="5" width="750">
						<tr class="trhead">
							<td>`b`&Infos`b</td> 
							<td>`b`&Bio`b [`i`0<a href="bio.php?char='.RAWURLEncode($row['login']).'&ret='.URLEncode($_SERVER['REQUEST_URI']).'">ansehen</a>`i`&]</td>
							<td>`b`&Ausw�hlen`b</td>
						</tr>
						
						<tr class="trdark">
							<td valign="top">`b`&AcctID:`b `7'.$row['acctid'].' `n
											 `b`&Name:`b `7'.$row['login'].' `n
											 `b`&Bio-Wortanzahl:`b `7'.Str_Word_Count(Strip_Tags($row['bio'])).'
							</td>
							
							<td>`b`&Bio:`b `n
								`n', true);
			output(CloseTags(SubStr($row['bio'], 0, 250),'`c`i`b').' '.((StrLen($row['bio']) > 250)?'`&[...]':''));
			output('</td>
							
							<td align="center"><input type="checkbox" id="CheckboxFor'.$i.'" name="acc[]" value="'.$row['acctid'].'">
						</tr>
					</table>`n`n', true);
			addnav('', 'bio.php?char='.RAWURLEncode($row['login']).'&ret='.URLEncode($_SERVER['REQUEST_URI']));
		}
		
		$out .= "<table width='750'>
					<tr>
						<td align='left'>
							<input type='button' value='Alle markieren' class='button' onClick='";
						
        for($i=$i-1;$i>=0;$i--) {
            $out .= "document.getElementById(\"CheckboxFor$i\").checked=true;";
        }

        $out .= "'></td>
					<td align='right'>
						<input type='submit' class='button' value='Backup eintragen'>
					</td>
				</tr></table></form> `n`n`n";
		
		addnav('Aktionen');
		addnav('Aktualisieren', 'biobackups.php?op=backup1');
		addnav('Zur�ck');
		addnav('Zur�ck zum Hauptmenu', 'biobackups.php');
		addnav('Zur�ck zum Weltlichen', 'village.php');
		addnav('Zur�ck zur Grotte', 'superuser.php');
	break;
	
	case 'backup2':
		$acc = $_POST['acc'];
		if(!is_array($acc) || count($acc) < 1) {
			$out .= '`c`b`$!!Fehler!!`b`c `n`n
				     `&Du hast genau 0 (Null) Biographien ausgew�hlt, von denen du ein Backup erstellen willst! `n
					 Du musst schon mindestens eine Bio ausw�hlen ;)';
		}
		else {
			for($i=0; $i<count($acc); $i++) {
				$sql = 'SELECT 
								login,
								bio
						FROM
								accounts
						WHERE 
								acctid = '.$acc[$i];
				$res = db_query($sql);
				$bio = db_fetch_assoc($res);
				
				$sql = 'INSERT INTO
								biobackups
									(owner,
									 ownerlogin,
									 lastupdated,
									 bio)
						VALUES
								('.$acc[$i].',
								 "'.$bio['login'].'",
								 now(),
								 "'.addslashes($bio['bio']).'")';
				db_query($sql);
			}
			if(db_affected_rows() == 0) {
				$out .= '`c`b`$!!Fehler!!`b`c `n
						 `n
						 `&Keine Ahnung warum, aber die Datenbank gab keine R�ckmeldung... `n
						 Irgendwas ist also schiefgelaufen :((';
			}
			else {
				$out .= '`c`b`&Daten eingetragen!`b`c `n
						 `n
						 `&Sehr gut, die Backups wurden erzeugt. `n
						 Sie k�nnen nun jederzeit geupdated werden, gel�scht werden, oder ausgelesen werden, `n
						 falls einem User seine Bio abhanden gekommen ist.';
			}
		}
		addnav('Zur�ck', 'biobackups.php');
	break;
	
	case 'update1':
		$out .= '`c`b`&Backups updaten`b`c `n
				 `n';
		if(getsetting('backupupdated', '0000-00-00') == '0000-00-00') {
			$out .= 'Die Backups wurden noch nie aktualisiert!!';
		}
		else {
			$out .= 'Die Biographien wurden am '.getsetting('backupupdated', '0000-00-00').' 
			         das letzte Mal aktualisiert.';
		}
		
		$out .= '<form action="biobackups.php?op=update2" method="POST"> `n
				 `n
				 Nicht mehr existierende Accounts automatisch l�schen?
					<input type="checkbox" name="delold?" value="1">
					<input type="submit" value="Backups updaten">
				 </form>';
		addnav('', 'biobackups.php?op=update2');
		
		addnav('Zur�ck');
		addnav('Zur�ck zum Hauptmenu', 'biobackups.php');
		addnav('Zur�ck zum Weltlichen', 'village.php');
		addnav('Zur�ck zur Grotte', 'superuser.php');
	break;
	
	case 'update2':
		$out .= '`c`b`&Backups updaten`b`c `n
				 `n';
				 
		if($_POST['delold?']) {
			$sql = 'SELECT
							b.owner
					FROM
							biobackups b
					LEFT OUTER JOIN
							accounts a
						ON 
							b.owner = a.acctid
					WHERE 
							a.acctid IS NULL
					ORDER BY 
							b.owner
						ASC';
			$res = db_query($sql);
			$n1 = 0;
			while($row = db_fetch_assoc($res)) {
				$sql = 'DELETE FROM
								biobackups
						WHERE
								owner = '.$row['owner'];
				db_query($sql);
				$n1++;
			}
			$out .= '`&Es wurden `b'.$n1.'`b Spieler aus der Tabelle gel�scht!`n`n';
		}
		
		$sql = 'SELECT
						a.acctid,
						a.bio
				FROM
						accounts a
				INNER JOIN
						biobackups b
					ON
						a.acctid = b.owner
				ORDER BY
						a.acctid
					ASC';
		$res = db_query($sql);
		$n2 = 0;
		while($row = db_fetch_assoc($res)) {
			$sql = 'UPDATE
							biobackups
					SET
							bio = "'.addslashes($row['bio']).'",
							lastupdated = now()
					WHERE
							owner = '.$row['acctid'];
			db_query($sql);
			$n2++;
		}
		
		$out .= '`&Es wurden `b'.$n2.'`b Backups aktualisiert! `n
				 Die Backups der Biographien sind somit wieder auf dem neusten Stand. `n
				 `n
				 Das Updatedatum wurde auf den heutigen Tag, den '.date('d.m.Y').' gesetzt.';
		
		savesetting('backupupdated', date('d.m.Y'));
		
		addnav('Zur�ck');
		addnav('Zur�ck zum Hauptmenu', 'biobackups.php');
		addnav('Zur�ck zum Weltlichen', 'village.php');
		addnav('Zur�ck zur Grotte', 'superuser.php');
	break;
	
	case 'search':
		$out .= '`c`b`&Backup suchen`b`c `n
				 `n
				 <form action="biobackups.php?op=search&act=searched" method="POST">
					`&Name des Spielers: <input name="name">
					<input type="submit" class="button" value="suchen">
				 </form> `n`n`n';
		addnav('', 'biobackups.php?op=search&act=searched');
		
		switch($_GET['act']) {
			case 'searched':
				$_POST['name'] = stripslashes($_POST['name']); 
				$StrLen = StrLen($_POST['name']); 
        
				$who = ''; 
				for($i = 0; $i < $StrLen; $i++) { 
					$who .= '%'.$_POST['name']{$i};
				} 
			
				$who .= '%'; 
				$who = mysql_real_escape_string($who);
				
				$sql = 'SELECT 
								owner,
								ownerlogin
						FROM
								biobackups
						WHERE			
								(ownerlogin LIKE "%'.$who.'%"
									OR
								 owner LIKE "'.$who.'")
						ORDER BY
								owner
							ASC';
				$res = db_query($sql);
				$n = db_num_rows($res);
				
				if($n == 1) {
					$row = db_fetch_assoc($res);
					redirect('biobackups.php?op=search&act=show&userid='.$row['owner']);
				}
				elseif($n > 25) {
					$out .= '`&Es kommen �ber 25 Spieler in Frage!! `n
							 Pr�zisiere deine Eingabe!';
				}
				elseif($n == 0) {
					$out .= '`&Es wurde kein Spieler mit diesem oder einem �hnlichen Namen gefunden!';
				}
				else {
					$out .= '`&Es kommen mehrere Spieler in Frage: `n`n
							<table>
								<tr class="trhead">
									<td>`b`&Name`b</td>
									<td>`b`&Ausw�hlen`b</td>
								</tr>';
					while($row = db_fetch_assoc($res)) {
						$out .= '<tr class="trdark">
									<td>'.$row['ownerlogin'].'</td>
									<td><a href="biobackups.php?op=search&act=show&userid='.$row['owner'].'">Bio laden</a></td>
								 </tr>';
						addnav('', 'biobackups.php?op=search&act=show&userid='.$row['owner']);
					}
				}
			break;
			
			case 'show':
				$userid = $_GET['userid'];
				$sql = 'SELECT 
								owner,
								ownerlogin,
								bio,
								lastupdated
						FROM
								biobackups
						WHERE
								owner = '.$userid;
				$res = db_query($sql);
				$row = db_fetch_assoc($res);
				
				$date = explode('-', $row['lastupdated']);
				$date = $date[2].'.'.$date[1].'.'.$date[0];
				
				output('`b`&Name:`b '.$row['ownerlogin'].' `n
						`b`&Backup vom:`b '.$date.' `n');
				rawoutput('<textarea rows="10" cols="65" class="input">'.$row['bio'].'</textarea>');
				output('`n
						'.$row['bio'], true);					
			break;
		}
			
		addnav('Zur�ck');
		addnav('Zur�ck zum Hauptmenu', 'biobackups.php');
		addnav('Zur�ck zum Weltlichen', 'village.php');
		addnav('Zur�ck zur Grotte', 'superuser.php');
	break;				 
}

output($out, true);


page_footer();
?>