<?php
Require_once "common.php";
page_header('Eliwoods LoGD-Dumper');

if(empty($_GET['q'])) $_GET['q'] = '';

define('THISFILE',basename(__FILE__));
define('LOGDDUMP_VERSION',"Alpha 1");

switch($_GET['q'])
{
  case 'dumpnow':
    //print "<pre>";
      //print_r($_POST);
    //print "</pre>";
    
    $predump = <<<SQL
--- Eliwood LoGD SQL-Dumper
--- In der Beta-Version
--- BugReport an:
--- <basilius.sauter@hispeed.ch>
---
---
--- Ich gebe keine Garantie dass dieser Dump funktioniert!!
--- Jedwege verwendung auf eigene Gefahr!!
---
---
--- Datenbank: $dumptable
--- Datum: $dumpdate


SQL;

    $dump = '';
    
    $structure = (isset($_POST['structure'])?true:false);
    $rows = (isset($_POST['rows'])?true:false);
    
    Include "dbconnect.php";
    unset($DB_PASS,$DB_USER);
    
    $DB_NAME;
    
    while(list(,$val) = each($_POST['tables']))
    {
      $table = $val;
      $dump .= "CREATE TABLE `$table` ( \n";
      $keys = '';
      $AllColumns = array();

      // Die Tabelle beschreiben um die richtigen Querys zu schreiben
      $result2 = db_Query('DESCRIBE `'.$table.'` ') or die(db_error());
      
      while($columns = DB_Fetch_Assoc($result2))
      {
        $dump.= "\t";
          $dump.= "`{$columns['Field']}` {$columns['Type']} ";
          
          $AllColumns[] = '`'.$columns['Field'].'`';
          
          // Null?
          if($columns['Null'] == 'NO') $dump.=  "NOT NULL ";
          else $dump.= "NULL ";

          // Default-Wert?
          if(!empty($columns['Default']))
          {
            if($columns['Default'] === "NULL" && $columns['Null'] == 'YES')
            {
              $dump.= "default NULL ";
            }
            else
            {
              $dump.= "default '".$columns['Default']."' ";
            }
          }

          // Extra wie auto_increment?
          if(!empty($columns['Extra'])) $dump.= $columns['Extra']." ";

          // Ist irgendein Schl�ssel?
          if(!empty($columns['Key']))
          {
            if($columns['Key'] == "PRI")
            {
              $prikey = "\t PRIMARY KEY (`".$columns['Field']."`),\n";
            }
            elseif($columns['Key'] == "MUL")
            {
              $keys .= "\t KEY `".$columns['Field']."` (`".$columns['Field']."`) ,\n";
            }
          }

        $dump.= ",\n";
      } // End While: Pro Spalte
      
      
        $dump = $dump.$prikey.$keys;
        $dump = substr($dump,0,strlen($dump)-2);
        $dump .= "\n); \n\n";

      if ($rows === true)
      {
        $AllColumnsStr = implode(',',$AllColumns);

        $inserts = "INSERT INTO `$table` ($AllColumnsStr)\n VALUES";

        $InsertResult = DB_Query("SELECT * FROM `$table` ") or die(DB_Error());

        $x = 0;
        while($InsertRow = DB_Fetch_Assoc($InsertResult))
        {
          // $inserts.= "\t('".addslashes(stripslashes(implode("','",$InsertRow)))."'),\n";
          if($x > 0) $inserts.=',';
          $inserts.= "\n\t(";

          $y = 0;
          while(list($key,$val) = each($InsertRow))
          {
            if($y > 0) $inserts.= ',';
            $inserts .= "'".Addslashes(Stripslashes($val))."'";
            $y++;
          }
          $inserts.= ')';
          $x++;
        }
        
        $dump .= $inserts.";\n\n\n";
      }

      
    } // End While: Pro Tabelle
    
    //print "<pre>".$dump."</pre";
    
    $filename = "logddbdump-".date("Y-m-d-h-i-s").".sql";
    $handle = fopen ($filename, "w+");
    
    $dump = str_replace("\n","\r\n",$dump);
    fwrite($handle,$dump);
    
    fclose($handle);

    output('`$Geschafft! Der Dump wurde als "`^'.$filename.'`$ gespeichert.');
    break;
    
  case 'dump':
    Include "dbconnect.php";
    unset($DB_PASS,$DB_USER);
    
    $result = db_query("SHOW TABLES");
    
    $FormOptions = '';
    
    while($table = db_fetch_assoc($result))
    {
      $FormOptions .= "<option value='".$table['Tables_in_'.$DB_NAME]."' />".$table['Tables_in_'.$DB_NAME]."\n";
    }
    
    $dumplink = THISFILE.'?q=dumpnow';
    
    addnav('',$dumplink);
  
    $ausgabe = <<<HTML
  <form action="$dumplink" method="POST">
  <table align="center">
    <th>Eliwoods LoGD-Dumper</th>
    <tr>
      <td align="center">
        <font color="#FF0000"><strong>Verwendung auf eigene Gefahr!</strong></font>
      </td>
    </tr>
    <tr>
      <td>
        <input type="checkbox" name="structure" /> Struktur<br />
        <input type="checkbox" name="rows" /> Daten
      </td>
    </tr>
    <tr>
      <td>
        <strong>Tabellen</strong> (Mehrfachauswahl m�glich) <br /><br />
        <select name="tables[]" size="5" multiple="multiple">
          <!--<option value="Blub" />Blub-->
          $FormOptions
        </select>
      </td>
    </tr>
    <tr>
      <td align="center">
        <input type="submit" value="Dump ziehen" class="button" />
      </td>
    </tr>
  </table>
  </form>
HTML;


    rawoutput($ausgabe);
    break;
  default:
    output('`2Willkommen beim LoGD-Dump.`n`n'
      .'Bevor du einem Dump ziehst ist es wichtig, dass du �berpr�fst, ob du auch '
      .'im Besitzt der aktuellen Version bist.`n'
      .'Version: `^'.LOGDDUMP_VERSION.'`2`n`n'
      .'Mit dem Klick auf "Dump-Assistent" bekommst du ein Formular zu Gesicht, '
      .'in dem du deinen gew�nschten Dump-Vorgang zusammen stellen kannst.`n`n'
      .'`$Ich stelle hier nochmal klar, dass ich KEINERLEI Verantwortung f�r '
      .'diese Art von BackUp �bernehme!`n'
      .'Sollte bei einem Datenbankcrash die mit diesem Tool extrahierten Daten '
      .'fehlerhaft sein, so tr�gst du selbst die Verantwortung!`n`n`n'
      .'`^&copy; ~Eliwood 2006`0'
    ,true);
    break;
}

addnav('Dump-Assistent',THISFILE.'?q=dump');
addnav('Zur�ck');
addnav('Zur�ck zur Grotte','superuser.php');

page_footer();
?>
