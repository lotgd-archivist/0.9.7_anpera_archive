<?
/*
   
    +----------------------------------+
    | DIESE BOX BITTE NICHT ENTFERNEN! |
    +----------------------------------+
    | made by Draza�ar                 |
    | http://logd.legend-of-vinestra.de|
    | drazaar@legend-of-vinestra.de    |
    +----------------------------------+
    | waldsee v1.01                     |
    | Part of System 3V                |
    +----------------------------------+
    
    Idee von pool.php, fish.php und bait.php by Kevin Hatfield - Arune
    Code vereinfacht und zusammengefasst auf 2 Scripts.
    2 neue K�der hinzugef�gt. Einige Ver�nderungen.
    Einige Buges entfernt.
*/

require_once "common.php";
require "waldseefuncs.php";

addcommentary();
checkday();

page_header("Der Waldsee");
//$session['user']['angelrunden']=5;
switch($_GET['op']){
    case '':
        output("`c`b`9Der Waldsee`b`c`n`n");
        viewcommentary("Waldsee","Hinzuf�gen");
        if($session['user']['rpchar']<1){
                addnav("Angeln");
                addnav("A?Angelladen","waldsee.php?op=laden");
                addnav("n?Angeln gehen","waldsee.php?op=angeln");
        }
       // addnav("Wege");
       // addnav("W?Wasserfall","wasserfall.php");
       // addnav("o?Wolkeninsel","wolkeninsel.php");
        addnav("Umkehren");
        addnav("Zur�ck zum Dorf","village.php");
    break;
    case 'laden':
        output("`c`b`9Validas' Angelladen`b`c`n`n");
        output("<table border=0 cellspacing=1 bgcolor='#999999'>
                  <tr bgcolor='990000'>
                    <td colspan=3><b>Dein Anglerbeutel</b></td>
                  </tr><tr class='trdark'>
                    <td><b>Brotst�cke</b></td><td>".$session['user']['brot']."/40</td>
                  </tr><tr class='trdark'>
                    <td><b>Fliegen</b></td><td>".$session['user']['fliege']."/30</td>
                  </tr><tr class='trdark'>
                    <td><b>W�rmer</b></td><td>".$session['user']['wurm']."/25</td>
                  </tr><tr class='trdark'>
                    <td><b>Spezialk�der</b></td><td>".$session['user']['spezial']."/15</td>
                  </tr><tr bgcolor='#990000'>
                    <td colspan=3 align='right'><i>.:: System V3 ::.</i></td>
                  </tr>                    
                </table>",true);
        if($session['user']['dragonkills']>=1){
                addnav("Kaufen");
                addnav("Brotst�ckchen (".getsetting("breadcost",10)." Gold)","waldsee.php?op=buy&what=brot");
        }
        if($session['user']['dragonkills']>=7){
                addnav("Fliegen (".getsetting("minnowcost",25)." Gold)","waldsee.php?op=buy&what=fliege");
        }
        if($session['user']['dragonkills']>=20){
                addnav("W�rmer (".getsetting("wormcost",50)." Gold)","waldsee.php?op=buy&what=wurm");
        }
        if($session['user']['dragonkills']>=45){
                addnav("Spezialk�der (".getsetting("specialcost",250)." Gold)","waldsee.php?op=buy&what=spezial");
        }
        addnav("Umkehren");
        addnav("Zur�ck zum See","waldsee.php");
    break;
    case 'buy':
        $what = $_GET['what'];
        if($what=="wurm") $word = "W�rmer";
        elseif($what=="fliege") $word = "Fliegen";
        elseif($what=="brot") $word = "Brotst�cke";   
        elseif($what=="spezial") $word = "Spezialk�der"; 
        output("`7Wie viele ".$word." willst du kaufen?");
        output("<form action='waldsee.php?op=buy&act=give&what=$what' method='POST'>
                Anzahl der ".$word.": <input name='number'>
                <input type='submit' class='button' value='Anzahl'>`n`n`n",true);
        addnav("","waldsee.php?op=buy&act=give&what=$what");
        addnav("Etwas anderes kaufen","waldsee.php?op=laden");
        addnav("Zur�ck zum See","waldsee.php");
        switch($_GET['act']){
            case 'give':
                $what = $_GET['what'];
                $number = $_POST['number'];
                //output($number);
                IWillBuy($what,$number);
            break;
        }
    break;
    case 'angeln':
        if($session['user']['dragonkills']<1){
                output("`7Du bist noch nicht erfahren genug um zu angeln!");
                addnav("Zur�ck zum See","waldsee.php");
        }elseif($session['user']['angelrunden']<1){
                output("`7Du hast heute schon genug geangelt und nun wirklich keine Lust mehr!");
                addnav("Zur�ck zum See","waldsee.php");
        }else{
                output("<table border=0 cellspacing=1 bgcolor='#999999'>
                          <tr bgcolor='990000'>
                            <td colspan=3><b>Dein Anglerbeutel</b></td>
                          </tr><tr class='trdark'>
                            <td><b>Brotst�cke</b></td><td>".$session['user']['brot']."/40</td>
                          </tr><tr class='trdark'>
                            <td><b>Fliegen</b></td><td>".$session['user']['fliege']."/30</td>
                          </tr><tr class='trdark'>
                            <td><b>W�rmer</b></td><td>".$session['user']['wurm']."/25</td>
                          </tr><tr class='trdark'>
                          <td><b>Spezialk�der</b></td><td>".$session['user']['spezial']."/15</td>
                          </tr><tr class='trdark'>
                            <td><b>Angelrunden</b></td><td>".$session['user']['angelrunden']."</td>
                          </tr><tr bgcolor='#990000'>
                            <td colspan=3 align='right'><i>.:: System V3 ::.</i></td>
                          </tr>                    
                        </table>`n`n",true);
                $w�rmer = $session['user']['wurm'];
                $fliegen = $session['user']['fliege'];
                $brot = $session['user']['brot'];
                $spezial = $session['user']['spezial'];
                $inventory = $w�rmer + $fliegen + $brot + $spezial;
                if($session['user']['angelrunden']>=1 && $inventory!=0){
                        addnav("angeln");
                        if($brot>0) addnav("Brotst�ck auswerfen","waldsee.php?op=angeln&what=brot");
                        if($fliegen>0) addnav("Fliege auswerfen","waldsee.php?op=angeln&what=fliege");
                        if($w�rmer>0) addnav("Wurm auswerfen","waldsee.php?op=angeln&what=wurm");                        if($spezial>0) addnav("Spezialk�der auswerfen","waldsee.php?op=angeln&what=spezial");
                }
                addnav("Umkehren");
                addnav("Zur�ck zum See","waldsee.php");
                switch($_GET['what']){
                    case 'brot':
                        $what = $_GET['what'];
                        fishing($what);
                        $session['user']['angelrunden']--;
                    break;
                    case 'fliege':
                        $what = $_GET['what'];
                        fishing($what);
                        $session['user']['angelrunden']--;
                    break;
                    case 'wurm':
                        $what = $_GET['what'];
                        fishing($what);
                        $session['user']['angelrunden']--;
                    break;
                    case 'spezial':
                        $what = $_GET['what'];
                        fishing($what);
                        $session['user']['angelrunden']--;
                    break;
                }
        }
    break;        
}
page_footer();
?>   