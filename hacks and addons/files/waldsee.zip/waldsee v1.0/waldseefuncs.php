<?

/*
   
    +----------------------------------+
    | DIESE BOX BITTE NICHT ENTFERNEN! |
    +----------------------------------+
    | made by Draza�ar                 |
    | http://logd.legend-of-vinestra.de|
    | drazaar@legend-of-vinestra.de    |
    +----------------------------------+
    | waldseefuncs v1.0                |
    | Part of System 3V                |
    +----------------------------------+
    
    Idee von pool.php, fish.php und bait.php by Kevin Hatfield - Arune
    Code vereinfacht und zusammengefasst auf 2 Scripts.
    2 neue K�der hinzugef�gt. Einige Ver�nderungen.
    Einige Buges entfernt.
*/

function IWillBuy($what,$number){               //K�der kaufen
        global $session;
        if($what=="wurm"){
                $cost = getsetting("wormcost",50);
        }elseif($what=="fliege"){
                $cost = getsetting("minnowcost",25);
        }elseif($what=="brot"){
                $cost = getsetting("breadcost",10);
        }elseif($what=="spezial"){
                $cost = getsetting("specialcost",250);
        }
        $anzahl = $number;
        $kosten = $cost * $anzahl;
        
        $w�rmer = $session['user']['wurm'];
        $fliegen = $session['user']['fliege'];
        $brot = $session['user']['brot'];
        $spezial = $session['user']['spezial'];
        
        $wurmnow = $w�rmer + $anzahl;
        $fliegenow = $fliegen + $anzahl;
        $brotnow = $brot + $anzahl;
        $spezialnow = $spezial + $anzahl;
        
        $wurmspace = 25;
        $fliegenspace = 30;
        $brotspace = 40;
        $spezialspace = 15;
        
        if($session['user']['gold']<$kosten){
                output("`7Du hast nicht genug Gold!");
                addnav("Zur�ck","waldsee.php?op=laden");
        }elseif($what=="wurm" && $wurmnow>$wurmspace){
                output("So viele W�rmer kriegst du nicht mehr in deinen Anglerbeutel!");
                addnav("Zur�ck","waldsee.php?op=laden");
        }elseif($what=="fliege" && $fliegenow>$fliegenspace){
                output("So viele Fliegen kriegst du nicht mehr in deinen Anglerbeutel!");
                addnav("Zur�ck","waldsee.php?op=laden");
        }elseif($what=="brot" && $brotnow>$brotspace){
                output("So viele Brotst�cke kriegst du nicht mehr in deinen Anglerbeutel!");
                addnav("Zur�ck","waldsee.php?op=laden");
        }elseif($what=="spezial" && $spezialnow>$spezialspace){
                output("So viele Spezialk�der kriegst du nicht mehr in deinen Anglerbeutel!");
                addnav("Zur�ck","waldsee.php?op=laden");
        }else{
                $session['user']['gold']-=$kosten;
                if($what=="wurm"){
                        $session['user']['wurm']+=$anzahl;
                        $word = "W�rmer";
                }elseif($what=="fliege"){
                        $session['user']['fliege']+=$anzahl;
                        $word = "Fliegen";
                }elseif($what=="brot"){
                        $session['user']['brot']+=$anzahl;
                        $word = "Brotst�ckchen";
                }elseif($what=="spezial"){
                        $session['user']['spezial']+=$anzahl;
                        $word = "Spezialk�der";
                }
                output("`b`7Validas nimmt deine ".$kosten." Gold und gibt dir daf�r ".$anzahl." ".$word."`b");
        }
}

function fishing($k�der){
      global $session;
      if($k�der == "brot"){             //Angeln mit Brotst�ckchen
              $rand = e_rand(1,100);
              if($rand>0 && $rand<50){          //Kein Gewinn, kein Verlust
                      switch(e_rand(1,5)){
                          case 1:
                              output("`7Dein Brot weicht auf und wird uninteressant f�r jeden Fisch!");
                          break;
                          case 2:
                              output("`7Du wirfst deine Angel aus, doch noch w�hrend er K�der samt Haken in der Luft ist, f�ngt ihn ein gieriger Vogel. Dein K�der ist weg und du f�ngst nichts!");
                          break;
                          case 3:
                              output("`7Dein Brot scheint die Fische nicht zu interessieren!");
                          break;
                          case 4:
                              output("`7Du bekommst unglaublichen Hunger. Noch bevor du dein Brot auswerfen kannst, hast du es selbst aufgegessen!");
                          break;
                          case 5:
                              output("`7Du schaffst es mit deinem Brot nach Stunden ein mikroskopisch kleines Fischchen zu fangen. So klein, kann man den Fisch nicht einmal als Fisch bezeichnen...");
                          break;
                      }
              }elseif($rand>=50 && $rand<75){           //kleiner Gewinn + kleiner Verlust
                      switch(e_rand(1,6)){
                          case 1:
                              output("`7Du wirfst dein Brot aus, doch n och w�hrend der K�der in der Luft ist, f�ngt ihn ein Fisch. Eisern entschlossen h�lst du fest, doch die Angelschnur rei�t und der Fisch ist weg. Du lernst, dass man nicht nur erfolg haben kann.`n`n`^Du bekommst ein wenig Erfahrung.");
                              $exp = $session['user']['experience']*0.02;
                              $session['user']['experience']+=$exp;
                          break;
                          case 2:
                              output("`7Nach ein paar Minuten ziehst du endlich etwas an Land. Zwar ist es nur ein Stiefel, aber besser als nichts. Im Stiefel findest du ein bisschen Gold.`n`n`^Du bekommst 150 Gold.");
                              $session['user']['gold']+=150;
                          break;
                          case 3:
                              output("`7Das Angeln macht spa�. Du hast Lust auf eine weitere Runde!`n`n`^Du bekommst eine weitere Angelrunde");
                              $session['user']['angelrunden']++;
                          break;
                          case 4:
                              output("`7Schwungvoll wirfst du deine Angel aus. Dummerweise ZU schwungvoll! Deine Angel fliegt in einem gro�en Bogen �ber den See und treibt sofort davon. Du musst dir eine neue Angel kaufen, was dich 500 Gold kostet!`n`n`^Du verlierst 500 Gold!");
                              if($session['user']['gold']>=500){
                                      $session['user']['gold']-=500;
                              }elseif($session['user']['gold']<500 && $session['user']['goldinbank']>=500){
                                      $session['user']['goldinbank']-=500;
                              }
                          break;
                          case 5:
                              output("`7Du holst aus um deine Angel auszuwerfen, doch wohl etwas ZU schwungvoll, denn du rutscht aus und st��t dir den Kopf. Als du aufwachst geht es dir nicht sonderlich gut! Du f�hlst dich nicht in der Lage weiterzuangeln!`n`n`^Du verlierst alle Angelrunden.");
                              $session['user']['angelrunden']=0;
                          break;
                          case 6:
                              output("`7Du holst aus um deine Angel auszuwerfen, doch wohl etwas ZU schwungvoll, denn du rutscht aus und st��t dir den Kopf. Aua das tat weh!`n`n`^Du verlierst Lebenspunkte");
                              if($session['user']['hitpoints']>1) $session['user']['hitpoints']*=0.5;
                          break;
                      }
              }elseif($rand>=75 && $rand<95){           //Mittlere Boni + Mali
                      switch(e_rand(1,4)){
                          case 1:
                              output("`7Du sitzt schon mindestens zwei Stunden da, als dir auff�llt, dass du auf einem unbequemen Stein sitzt. Du findest heraus, dass der Stein ein Edelstein ist!`n`n`^Du bekommst einen Edelstein.");
                              $session['user']['gems']++;
                          break;
                          case 2:
                              output("`7 Du wirst immer besser im Angeln!`n`n`^Du bekommst 3 Angelrunden!");
                              $session['user']['angelrunden']+=3;
                          break;
                          case 3:
                              output("`7Du wirfst die Angel aus, doch die Schnur verheddert sich und wickelt sich ungeschickt um deinen Hals. R�chelnd liegst du auf dem Boden, bis du es endlich wieder schaffst dich zu befreien. Keuchend bekommst du endlich wieder Luft.`n`n`^Du verlierst 2 Angelrunden und fast alle Lebenspunkte!");
                              $session['user']['hitpoints']=1;
                              if($session['user']['angelrunden']>=2) $session['user']['angelrunden']-=2;
                              else $session['user']['angelrunden']=0;
                          break;
                          case 4:
                              output("`7Du schl�fst w�hrend des Angelns ein. Als du aufwachst, hat dir irgendwer dein gesamtes Gold gestohlen!");
                              $session['user']['gold']=0;
                          break;
                      }
              }elseif($rand>=95){
                      switch(e_rand(1,3)){
                          case 1:
                              output("`7Du ziehst nach ein paar Minuten eine gro�e Kiste mit 2000 Gold an Land!");
                              $session['user']['gold']+=2000;
                          break;
                          case 2:
                              output("`7Du wirfst den K�der aus. Ein paar Augenblicke sp�ter ziehst du auch schon einen riesigen Fisch an Land. Das ist gut f�r das Selbstbewusstsein!`n`n`^Du bekommst Erfahrung!");
                              $session['user']['experience']*=1.05;
                          break;
                          case 3:
                              output("`7Gerade holst du mit deiner Angel aus, als du auf einem nassen Stein ausgleitest und ins kalte Wasser f�llst. Zwar ist es verdammt kalt, aber was nicht t�tet, das h�rtet ab!`n`n`^Du bekommst einen permanenten Lebenspunkt!");
                              $session['user']['maxhitpoints']++;
                          break;
                      }
              }
              $session['user']['brot']--;
      }elseif($k�der == "fliege"){               //Angeln mit Fliegen
              $rand = e_rand(1,100);
              if($rand>=1 && $rand<40){
                      switch(e_rand(1,5)){
                          case 1:
                              output("`7Du bekommst Mitleid mit der Fliege und schenkst ihr die Freiheit");
                          break;
                          case 2:
                              output("`7Du wirfst die Fliege aus, dummerweise hast du vergessen sie an den Haken festzumachen! Die Fliege ist �ber alle Berge!");
                          break;
                          case 3:
                              output("`7So sehr du dich auch anstrengst, du f�ngst nichts...");
                          break;
                          case 4:
                              output("`7Nach ein paar Stunden ziehst du ein S�ckchen mit wertlosen Kieselsteinen an Land.");
                          break;
                          case 5:
                              output("`7Kein Fisch scheint sich f�r deine Fliege zu interessieren.");
                          break;
                      }
              }elseif($rand>=40 && $rand<80){
                      switch(e_rand(1,6)){
                          case 1:
                              output("`7Die Fliege tut dir leid und du schenkst ihr die Freiheit! Was f�r eine freundliche Tat!`n`n`^Du bekommst einen Charmepunkt!");
                              $session['user']['charm']++;
                          break;
                          case 2:
                             output("`7Nach ein paar Minuten schl�fst du ein. Schlie�lich wachst du nach ein paar Stunden wieder auf. So ein Schlaf tat gut, du regenerierst v�llig!`n`n`^Du bekommst volle Lebenspunkte!");
                              $session['user']['hitpoints']=$session['user']['maxhitpoints'];
                          break;
                          case 3:
                              output("`7Du f�ngst einen enormen Fisch! So ein Fisch ist gut f�r f�rs Selbstbewusstsein!");
                              $session['bufflist']['angelnselbst'] =  array( "name" => "`^Selbstbewusstsein`0","roundmsg" => "`^Dein Selbstbewusstsein l�sst dich besser k�mpfen!`0","wearoff" => "`^Du f�hlst dich wieder normal`0","rounds" => "50","atkmod" => "1.1","defmod" => "1.1","badguyatkmod" => "0.9","badguydefmod" => "0.9","survivenewday" => "0","activate" => "roundstart,offense,defense");
                          break;
                          case 4:
                              output("`7Mit gek�nstelter Eleganz wirfst du deine Angel aus. Leider l�st sich dabei der K�der und du angelst einige Stunden umsonst. Du f�hlst dich m�de und schlapp, als du endlich bemerkst, dass es keinen Sinn hat weiterzuangeln.`n`n`^Du verlierst fast alle Lebenspunkte und 2 Angelrunden!");
                              $session['user']['hitpoints']=1;
                              if($session['user']['angelrunden']>=2) $session['user']['angelrunden']-=2;
                              else $session['user']['angelrunden']=0;
                          break;
                          case 5:
                              output("`7Du wirfst mit viel Schwung deine Angel aus. Dummerweise wirfst du deinen Beutel mit K�dern auch aus.`n`n`^Du verlierst alle Fliegen!");
                              $session['user']['fliege']=0;
                          break;
                          case 6:
                              output("`7Du kommst auf die geniale Idee, dass ein glitzernder Edelstein vielleicht mehr n�tzt, als eine Fliege. Also nimmst du den Edelstein als K�der, anstatt der Fliege. Dummerweise ist er nach ein paar Minuten weg, als du ihn in's Wasser wirfst...`n`n`^Du verlierst einen Edelstein, beh�lst aber deine Fliege!");
                              $session['user']['fliege']++;
                              $session['user']['gems']--;
                          break;
                      }
              }elseif($rand>=80){
                      switch(e_rand(1,5)){
                          case 1:
                              output("`7Du fischst eine kleine Schatulle mit 2 Edelsteinen darin aus dem Wasser.`n`n`^Du bekommst zwei Edelsteine");
                              $session['user']['gems']+=2;
                          break;
                          case 2:
                              output("`7Du ziehst nach einiger Zeit eine Tasche mit K�dern aus dem Wasser!`n`n`^Du bekomst drei Spezialk�der");
                              $session['user']['spezial']+=3;
                          break;
                          case 3:
                              output("`7Du wirfst deine Angel weit aus und f�ngst schlie�lich eine Qualle. So eine Qualle hat allerdings schmerzhafte Nesseln! Du verletzt dir deine H�nde und kannst heute nicht mehr fischen!`n`n`^Du verlierst alle Angelrunden");
                              $session['user']['angelrunden']=0;
                          break;
                          case 4:
                              output("`7Du hebst deine Angel um sie weit auszuwerfen. Genau in diesem Moment schl�gt ein Blitz in dich ein. Die G�tter meinen es gut mit dir!`n`n`^Dein Angriff steigt um 5!");
                              $session['user']['attack']+=5;
                          break;
                          case 5:
                              output("`7Du hebst deine Angel um sie weit auszuwerfen. Genau in diesem Moment schl�gt ein Blitz in dich ein. Die G�tter meinen es nicht gut mit dir, du bist nur noch ein H�ufchen Asche!`n`n`^Du bist TOT!");
                              $session['user']['alive']=false;
                              $session['user']['hitpoints']=0;
                              addnav("T�gliche News","news.php");
                          break;
                      }
              }
              $session['user']['fliege']--;
      }elseif($k�der == "wurm"){
              $rand = e_rand(1,100);
              if($rand>=1 && $rand<25){
                      switch(e_rand(1,5)){
                          case 1: 
                              output("`7Der Wurm springt vom Haken und freut sich seines Lebens... Seit wann k�nnen W�rmer eigentlich springen?"); //By: Kevin Hatfield - Arune v1.0 fish.php
                          break;
                          case 2:
                              output("`7Dein Wurm schwimmt, sobald er im Wasser landet davon... Seit wann k�nnen W�rmer eigentlich schwimmen???");
                          break;
                          case 3:
                              output("`7Du bekommmst Mitleid mit dem Wurm und schenkst ihm die Freiheit.");
                          break;
                          case 4:
                              output("`7Selbst nach Stunden f�ngst du absolut nichts.");
                          break;
                          case 5:
                              output("`7Nicht einmal ein kleiner Fisch bei�t an..");
                          break;
                      }
              }elseif($rand>=25 && $rand<75){
                      switch(e_rand(1,6)){
                          case 1:
                              output("`7Du ziehst einen wundersch�nen Kristall an Land. Noch bevor du dir �berlegst, was so ein wundersch�ner Kristall alles wert ist, l�st er sich auf und wird zu drei Edelsteinen...`n`n`^Du bekommst drei Edelsteine!");
                              $session['user']['gems']+=3;
                          break;
                          case 2:
                              output("`7Du ziehst einen kleinen, gl�henden Hammer aus dem Wasser. Gerade als du dir �berlegst, was man mit so einem kleinen, gl�henden Hammer alles anstellen kann, ber�hrt dieser deine R�stung.");
                              $true = "Gl�hend";
                              $mystring = $session['user']['armor'];
                              $glueh = strpos($mystring, $true);
                              if($glueh === false){
                                      output("Deine R�stung f�ngt ebenfalls an zu gl�hen und du f�hlst dich darin schon viel sicherer!");
                                      $session['user']['armor'] = "`^Gl�hend `7-".$session['user']['armor'];
                                      $session['user']['defence']+=2;
                              }else{
                                      output("Diese f�ngt an mit dem Hammer um die Wette zu gl�hen.");
                              }
                              output("Nach kurzer Zeit h�rt der Spuk wieder auf. Der Hammer ist verschwunden...");
                          break;
                          case 3:
                              output("`7Du ziehst einen kleinen, gl�henden Hammer aus dem Wasser. Gerade als du dir �berlegst, was man mit so einem kleinen, gl�henden Hammer alles anstellen kann, ber�hrt dieser deine Waffe.");
                              $true = "Gl�hend";
                              $mystring = $session['user']['weapon'];
                              $glueh = strpos($mystring, $true);
                              if($glueh === false){
                                      output("Deine Waffe f�ngt ebenfalls an zu gl�hen und du f�hlst dich darin schon viel sicherer!");
                                      $session['user']['weapon'] = "`^Gl�hend `7-".$session['user']['weapon'];
                                      $session['user']['attack']+=2;
                              }else{
                                      output("Diese f�ngt an mit dem Hammer um die Wette zu gl�hen.");
                              }
                              output("Nach kurzer Zeit h�rt der Spuk wieder auf. Der Hammer ist verschwunden...");
                          break;
                          case 4:
                              output("Nach ein paar Minuten f�ngst bemerkst du, dass etwas an deiner Angel h�ngt. Es stellt sich heraus, dass es der Prinz des Seek�nigs ist.`nEr erz�hlt dir eine grausame Geschichte, welche dir Angst macht.`n`n`^Du verlierst alle Angelrunden!");
                              $session['user']['angelrunden']=0;
                          break;
                          case 5:
                              output("`7Du hast einen Beutel  `^Gold`7 gefangen!`nGanz auf all das Gold fixiert z�hlst du die M�nzen!`n`4BOOM! `7Du wurdest von etwas stumpfen getroffen...Und gehst zu Boden!`n`n`i Wieder einer auf den alten Goldbeuteltrick reingefallen`i h�rst du gerade noch als bei dir das Licht ausgeht!`n`n`^Du verlierst alle Angelrunden, all dein Gold und fast alle deine Lebenspunkte!"); //By: Kevin Hatfield - Arune v1.0 fish.php
                              $session['user']['gold']=0;
                              $session['user']['hitpoints']=1;
                              $session['user']['angelrunden']=0;
                          break;
                          case 6:
                              output("`7Du schl�fst beim Fischen ein, als du wieder aufwachst, ist es schon sp�t und dir fehlt der Wille noch l�nger wach zu bleiben.`n`n`^Du verlierst 5 Waldk�mpfe!");
                              $session['user']['turns']-=5;
                          break;
                      }
              }elseif($rand>=75){
                      switch(e_rand(1,4)){
                          case 1:
                              output("`7Nach einiger Zeit f�ngst du einen gro�en Fisch! Was eine Erfahrung!`n`n`^Du bekommst 1000 Erfahrung!");
                              $session['user']['experience']+=1000;
                          break;
                          case 2:
                              output("`7Du ziehst einen Fisch an Land, doch dieser wehrt sich noch verzweifelt. Geschickt erlegst du ihn mit deine/r/m ".$session['user']['weapon']."`n`n`^Du bekommst 8 Angriffspunkte dazu.");
                              $session['user']['attack']+=8;
                          break;
                          case 3:
                              output("`7Du ziehst nach einiger Zeit eine voll ausgestattete Angelausr�stung an Land!");
                              $session['user']['brot']=40;
                              $session['user']['fliege']=30;
                              $session['user']['wurm']=25;
                              $session['user']['spezial']=15;
                          break;
                          case 4:
                              output("`7Nach einiger Zeit hast du etwas merkw�rdig schweres an der Angel. Als du es endlich schaffst dieses etwas an Land zu ziehen, bemerkst du, dass es ein Kasten Bier ist! Du fragst dich zwar, was ein Kasten ist, aber das Bier ist angenehm kalt, du kannst nicht widersetehen...`n`n`^Du f�hlst dich nach einiger Zeit gut angetrunken...");
                              $session['user']['drunkenness']=99;
                              $session['bufflist']['angelntrunk'] =  array( "name" => "`#Rausch`0","roundmsg" => "`#Du schl�gst h�rter zu in deinem Rausch`0","wearoff" => "`^Du f�hlst dich n�chterner`0","rounds" => "10","atkmod" => "2.5","survivenewday" => "0","activate" => "roundstart,offense");
                              $session['user']['turns']++;
                          break;
                      }
              }
              $session['user']['wurm']--;
      }elseif($k�der == "spezial"){
              $rand = e_rand(1,100);
              if($rand>=1 && $rand<5){
                      switch(e_rand(1,4)){
                          case 1:
                              output("`7Dein Spezialk�der blinkt fr�hlich vor sich hin, aber passieren tut nichts...");
                          break;
                          case 2:
                              output("`7Du wirfst deinen Spezialk�der aus, nach kurzer Zeit schl�fst du allerdings ein...");
                          break;
                          case 3:
                              output("`7Nicht einmal der Spezialk�der hilft bei deinen Angelk�nsten noch!");
                          break;
                          case 4:
                              output("`7Du schaffst es schlussendlich, dass dein K�der nach �ber 5 Stunden einen Fisch findet, der anbei�t. Du bist so �berrascht, dass du vergisst den Fisch an Land zu ziehen...");
                          break;
                      }
              }elseif($rand>=5 && $rand<50){
                      switch(e_rand(1,6)){
                          case 1:
                              output("`7Du wirfst deinene Angel aus und schaffst es schlie�lich, dass ein enormer Fisch anbei�t. Gro�er K�der, gro�er Fisch!`n`n`^Du bekommst 2000 Erfahrung!");
                              $session['user']['experience']+=2000;
                          break;                     
                          case 2:
                              $gold = e_rand(2000,4000);
                              $gems = e_rand(2,4);
                              output("`7Du wirfst deine Angel aus, direkt in die Mitte des Sees. Kurz darauf teilt sich der See und du kannst die Mitte betreten, wo sich eine enorme Schatztruhe befindet.`n`n`^Du bekommst $gold Gold und $gems Edelsteine");
                              $session['user']['gold']+=$gold;
                              $session['user']['gems']+=$gems;
                          break;
                          case 3:
                              output("`7Du wirfst deine Angel aus. Nach kurzer Zeit explodiert dein K�der und dir fliegen ~50 Fische um die Ohren. Du bist der King of Fishing!`n`n`^Du erh�lst 5 Angelrunden und volle K�der!");
                              $session['user']['angelrunden']+=5;
                              $session['user']['brot']=40;
                              $session['user']['fliege']=30;
                              $session['user']['wurm']=25;
                              $session['user']['spezial']=15;
                          break;
                          case 4:
                              output("`7Du ziehst einen gro�en, gl�henden Hammer aus dem Wasser. Gerade als du dir �berlegst, was man mit so einem gro�en, gl�henden Hammer alles anstellen kann, ber�hrt dieser deine Waffe.");
                              $true = "Gl�hend";
                              $mystring = $session['user']['weapon'];
                              $glueh = strpos($mystring, $true);
                              if($glueh === false){
                                      output("Deine Waffe f�ngt ebenfalls an zu gl�hen und du f�hlst dich darin schon viel sicherer!");
                                      $session['user']['weapon'] = "`^Gl�hend `7-".$session['user']['weapon'];
                                      $session['user']['attack']+=8;
                              }else{
                                      output("Diese f�ngt an mit dem Hammer um die Wette zu gl�hen.");
                              }
                              output("Nach kurzer Zeit h�rt der Spuk wieder auf. Der Hammer ist verschwunden...");
                          break;
                          case 5:
                              output("`7Du ziehst einen gro�en, gl�henden Hammer aus dem Wasser. Gerade als du dir �berlegst, was man mit so einem gro�en, gl�henden Hammer alles anstellen kann, ber�hrt dieser deine R�stung.");
                              $true = "Gl�hend";
                              $mystring = $session['user']['armor'];
                              $glueh = strpos($mystring, $true);
                              if($glueh === false){
                                      output("Deine R�stung f�ngt ebenfalls an zu gl�hen und du f�hlst dich darin schon viel sicherer!");
                                      $session['user']['armor'] = "`^Gl�hend `7-".$session['user']['armor'];
                                      $session['user']['defence']+=8;
                              }else{
                                      output("Diese f�ngt an mit dem Hammer um die Wette zu gl�hen.");
                              }
                              output("Nach kurzer Zeit h�rt der Spuk wieder auf. Der Hammer ist verschwunden...");
                          break;
                          case 6:
                              output("`7Du ziehst nach einiger Zeit 5 Edelsteine an Land!");
                              $session['user']['gems']+=5;
                          break;
                      }
              }elseif($rand>=50 && $rand<95){
                      switch(e_rand(1,6)){
                          case 1:
                              output("`7Du bemerkst nicht, dass sich deine Angelschnur mit deinem Edelsteinbeutelchen verwickelt hat. Als du deine Angel auswirfst, fliegt dein Edelsteins�ckchen mit und die Edelsteine verstreuen sich in alle Richtungen. Du brauchst eine Weile, bis du wieder alle gefunden hast, doch einige sind ins Wasser gefallen.`n`n`^Du verlierst 2 Edelsteine.");  
                              if($session['user']['gems']>=2) $session['user']['gems']-=2;
                              else $session['user']['gems']=0;
                          break;                          
                          case 2:
                              output("`7Du willst gerade deine Angel auswerfen, als du bemerkst, dass du schon mitten im See drin stehst. Dummerweise ist um dich herum ein Schwarm Piranhas! Du rennst um dein Leben, doch einige haben dich schon ein wenig angeknabbert!`n`n`^Du verlierst 3 Angelrunden und fast alle Lebenspunkte!");
                              $session['user']['hitpoints']=1;
                              if($session['user']['angelrunden']>=3) $session['user']['angelrunden']-=3;
                              else $session['user']['angelrunden']=0;                        
                          break;                          
                          case 3:
                              output("`7Gerade willst du deine Angel auswerfen, doch da tut sich vor dir eine riesige Flutwelle auf. Du wirst umhergeschleudert und wei�t �berhaupt nicht, wie dir geschieht... Als du wieder aufwachst, bemerkst du: Du bist ziemlich mitgenommen worden und einige Dinge deiner Ausr�stung fehlen dir.`n`n`^Du verlierst fast alle Lebenspunkte, du verlierst alle deine K�der.");
                              $session['bufflist']['angelnwelle'] =  array( "name" => "`3Angelschaden`0","roundmsg" => "`3Du f�hlst dich nicht sehr kampfbereit`0","wearoff" => "`3Dir geht es wieder besser`0","rounds" => "20","atkmod" => "0.5","survivenewday" => "0","activate" => "roundstart,offense");
                              $session['user']['hitpoints']=1;
                              $session['user']['brot']=0;
                              $session['user']['fliege']=0;
                              $session['user']['wurm']=0;
                              $session['user']['spezial']=0;
                          break;                          
                          case 4:
                              output("`7Gerade als du den K�der auswirfst, setzt Ebbe ein und du wirfst deinen K�der praktisch ins Trockene...`n`n`^Du verlierst eine Spezialk�der");
                              $session['user']['spezial']--;                            
                          break;                          
                          case 5:
                              output("`7Du holst aus und wirfst deine Angel aus. Doch hat sich die Schnur an einem morschen Ast verfangen, der dir beim Ziehen nun gegen den Kopf schl�gt...`n`n`^Du f�hlst dich d�mmer als zuvor");
                              $session['user']['experience']*=0.95;
                          break;                          
                          case 6:
                              output("`7Gerade host du weit aus um deine Angel auszuwerfen, als du auf einem nassen Stein ausgleitest und nach hinten stolperst. Bl�der Weise steht dort ein Dornenbusch, in welchen du f�llst. Solche Kratzer sind sehr unsch�n anzusehen...`n`n`^Du verlierst 3 Charmepunkte!");
                              $session['user']['charm']-=3;
                          break;                      
                      }
              }elseif($rand>=95){
                      switch(e_rand(1,2)){
                          case 1:
                              output("`7Du stolperst und dir fliegt dein K�der aus der Hand. Dummerweise war es ein explosionsk�der, der genau vor dir explodiert! Dir fliegt so zu sprichw�rtlich die Umgebung um die Ohren!`n`n`^Du verlierst fast alle Lebenspunkte und 50% deiner Waldk�mpfe!");
                              $session['user']['hitpoints']=1;
                              $half = floor($session['user']['turns']*0.5);
                              $session['user']['turns']=$half;
                          break;
                          case 2:
                              output("`7L�ssig angelst du schon eine Weile, als pl�tzlich sich der See spaltet und du direkten Blick auf die Unterwelt hast. Schon denkst du, dass dein Leben ausgehaucht ist, als Ramius pers�nlich zu dir spreicht `\$\"Eh, es wird feucht! Verschwinde wieder!\" `7gr�hlt er. Damit du auch m�glichst schnell aufh�rst hier herumzuangeln, gew�hrt er dir einige Gefallen und etwas Reichtum.");
                              $gems = rand(2,5);
                              $gefallen = rand(100,200);
                              output("`n`n`^Du verlierst alle Angelrunden, bekommst aber $gems Edelsteine und $gefallen Gefallen.");
                              $session['user']['gems']+=$gems;
                              $session['user']['deathpower']+=$gefallen;
                              $session['user']['angelrunden']=0;
                          break;                          
                      }
              }
              $session['user']['spezial']--;
      }
}
?>