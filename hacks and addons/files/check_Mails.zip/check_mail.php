<?php

///////////////////////////////
//check_mails.php by Rikushai\\
//(Anderswelt-logd.de)       //
//Ver�ffentlicht: 2010       \\
///////////////////////////////
/*

Einbauanleitung:

�ffne: 
superuser.php
f�ge hinzu: 
addnav("Mails pr�fen","check_mail.php");

Save & close

�ffne:
[dein Skin].css

f�ge Hinzu (optional, da bei mir Textinhalte von <th> �berzogen dagestellt werden):

.text {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 10px;
  	text-decoration: none;
	font-weight: normal;
}

Save & close

ehm.. feddich.

*/


require_once "common.php";
addcommentary();
page_header("Admin-Panel");

//benutzte Farbcodes.. 
$o = '`y';
$h = '`@';
$d = '`2';

addnav("Neue Suche starten","check_mail.php");
addnav("Zur�ck");
addnav("Admin-Panel","superuser.php");
//addnav("User-Panel","user_panel.php");

if ($_GET['op']==""){
output("
$h `c`bMails-Pr�fen`b`c
$d Gib einfach in die untere Zeile den Log-in des Users ein, dessen mails du �berpr�fen willst und ja.. dann lies xD
<form action='check_mail.php?op=look' method='POST'>
$d Login: <input name='login'>
<input type='submit' class='button' value='Pr�fen'></form>
",true);
addnav("","check_mail.php?op=look");
}

if ($_GET['op']=="look"){



		$gesucht = "SELECT name,acctid FROM accounts WHERE login='$_POST[login]'";
		$resultgesucht = db_query($gesucht) or die(db_error(LINK));
		$rowgesucht = db_fetch_assoc($resultgesucht);



$absender = "SELECT * FROM mail WHERE msgfrom='$rowgesucht[acctid]' ORDER BY sent DESC";
$resultabsender = db_query($absender) or die(db_error(LINK));
$max1 = db_num_rows($resultabsender);
output("`c<table border='1' cellpadding='3' cellspacing='0'><tr class='trhead'><td align='center'>$o `b$rowgesucht[name]$o als Absender`b</td></tr><tr><td>",true);
for($i1=0;$i1<$max1;$i1++){
	$rowabsender = db_fetch_assoc($resultabsender);
		$empfname = "SELECT name FROM accounts WHERE acctid='$rowabsender[msgto]'";
		$resultempfname = db_query($empfname) or die(db_error(LINK));
		$rowempfname = db_fetch_assoc($resultempfname);
output("
<table class='trhead'>
<tr><td align='center'><table border='1' cellpadding='3' cellspacing='0' width='100%'><tr><td align='center'>$o `bEmpf�nger`b</td></tr></table></td><td align='center'><table border='1' cellpadding='3' cellspacing='0' width='100%'><tr><td align='center'>$o `bDatum/Zeit`b</td></tr></table></td></tr>
<tr><td>$h `b$rowempfname[name]`b</td><td>$h `b$rowabsender[sent]`b</td></tr>
<tr><th colspan='2' align='left' class='text'><table border='1' cellpadding='5' cellspacing='0' width='100%'><tr><td><p align='justify'>$h $rowabsender[subject]`n$d $rowabsender[body]</p></td></tr></table></th></tr>
</table>
 
",true);

}
output("</td></tr></table>`c`n`n",true);







$empfaenger = "SELECT * FROM mail WHERE msgto='$rowgesucht[acctid]' ORDER BY sent DESC";
$resultempfaenger = db_query($empfaenger) or die(db_error(LINK));
$max2 = db_num_rows($resultempfaenger);
output("`c<table border='1' cellpadding='3' cellspacing='0'><tr class='trhead'><td align='center'>$o `b$rowgesucht[name]$o als Empf�nger`b</td></tr><tr><td>",true);
for($i2=0;$i2<$max2;$i2++){
	$rowempfaenger = db_fetch_assoc($resultempfaenger);

		$absname = "SELECT name FROM accounts WHERE acctid='$rowempfaenger[msgfrom]'";
		$resultabsname = db_query($absname) or die(db_error(LINK));
		$rowabsname = db_fetch_assoc($resultabsname);
output("
<table class='trhead'>
<tr><td align='center'><table border='1' cellpadding='3' cellspacing='0' width='100%'><tr><td align='center'>$o `bAbsender`b</td></tr></table></td><td align='center'><table border='1' cellpadding='3' cellspacing='0' width='100%'><tr><td align='center'>$o `bDatum/Zeit`b</td></tr></table></td></tr>
<tr><td>$h `b$rowabsname[name]`b</td><td>$h `b$rowempfaenger[sent]`b</td></tr>
<tr><th colspan='2' align='left' class='text'><table border='1' cellpadding='5' cellspacing='0' width='100%'><tr><td><p align='justify'>$h $rowempfaenger[subject]`n$d $rowempfaenger[body]</p></td></tr></table></th></tr>
</table>
 
",true);

}
output("</td></tr></table>`c",true);


}
//Copyrighthinweis bitte enthalten lassen...
output("`c<h6>$h &copy; $d by <a href='http://anderswelt-logd.de' target='_blank'>$o Rikushai</a><br>$d Ver�ffentlicht:$h 2010</h6>`c",true);
page_footer();
?>