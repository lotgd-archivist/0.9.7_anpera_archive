<?php
#########################################
#                                       #
#  Alchemiemod                          #
#  Trankbrauscript & Anleitung          #
#  by Laserian                          #
#  v 1.0                                #
#                                       #
#########################################
require_once "common.php";
page_header("Tr�nke brauen");
$acctid=$session['user']['acctid'];
loadtable("*","alchemie");
$kraut1="Alraunenwurzel";
$kraut2="Skorpionstachel";
$kraut3="D�monenhorn";
$kraut4="Wei�er Lotos";
$kraut5="Tigerlilie";
$kraut6="Feenstaub";
$kraut7="Einhornhaar";
$kraut8="Engelsfeder";
$kraut1s="Drachenblut";
$kraut2s="Ph�nixfeder";
if($session['alchemie']['progress']>=($session['alchemie']['level']*(1000+100*($session['alchemie']['level']+1)))){
output("`2Durch das Brauen so vieler Tr�nke hast du einiges �ber die Kunst der Alchemie gelernt.`n
Du erh�ltst einen Fertigkeitspunkt.`n`n`n");
$session['alchemie']['fertpkt']++;
$session['alchemie']['level']++;
}
if($_GET['op']==""){
$sql = "SELECT * FROM potions WHERE acctid=".$acctid;
$result=db_query($sql);
$count = db_num_rows($result);
if($count>=10){
    output("`QDein Trankbeutel ist voll. Du kannst keine weiteren Tr�nke brauen.");
}else{
    rawoutput("<table><tr><td>");
    rawoutput("<form action='alchemie.php?op=check' method='POST'>");
    if($session['alchemie']['zutat1']>0) rawoutput("$kraut1: </td><td> <input type='text' name='zutat1' maxlength='5' size='5'>`n");
    rawoutput("</td></tr><tr><td>");
    if($session['alchemie']['zutat2']>0) rawoutput("$kraut2: </td><td> <input type='text' name='zutat2' maxlength='5' size='5'>`n");
    rawoutput("</td></tr><tr><td>");
    if($session['alchemie']['zutat3']>0) rawoutput("$kraut3: </td><td> <input type='text' name='zutat3' maxlength='5' size='5'>`n");
    rawoutput("</td></tr><tr><td>");
    if($session['alchemie']['zutat4']>0) rawoutput("$kraut4: </td><td> <input type='text' name='zutat4' maxlength='5' size='5'>`n");
    rawoutput("</td></tr><tr><td>");
    if($session['alchemie']['zutat5']>0) rawoutput("$kraut5: </td><td> <input type='text' name='zutat5' maxlength='5' size='5'>`n");
    rawoutput("</td></tr><tr><td>");
    if($session['alchemie']['zutat6']>0) rawoutput("$kraut6: </td><td> <input type='text' name='zutat6' maxlength='5' size='5'>`n");
    rawoutput("</td></tr><tr><td>");
    if($session['alchemie']['zutat7']>0) rawoutput("$kraut7: </td><td> <input type='text' name='zutat7' maxlength='5' size='5'>`n");
    rawoutput("</td></tr><tr><td>");
    if($session['alchemie']['zutat8']>0) rawoutput("$kraut8: </td><td> <input type='text' name='zutat8' maxlength='5' size='5'>`n");
    rawoutput("</td></tr><tr><td>");
    if($session['alchemie']['zutat1s']>0) rawoutput("$kraut1s: </td><td> <input type='text' name='zutat1s' maxlength='5' size='5'>`n");
    rawoutput("</td></tr><tr><td>");
    if($session['alchemie']['zutat2s']>0) rawoutput("$kraut2s: </td><td> <input type='text' name='zutat2s' maxlength='5' size='5'>`n");
    rawoutput("</td></tr></table>");
    rawoutput("<input type='submit' class='button' value='Trank brauen'></form>");
    output("`n`n`n`2Diese Zutaten besitzt du:`n`n");
    if($session['alchemie']['zutat1']>0) output("$kraut1: ".$session['alchemie']['zutat1']."`n");
    if($session['alchemie']['zutat2']>0) output("$kraut2: ".$session['alchemie']['zutat2']."`n");
    if($session['alchemie']['zutat3']>0) output("$kraut3: ".$session['alchemie']['zutat3']."`n");
    if($session['alchemie']['zutat4']>0) output("$kraut4: ".$session['alchemie']['zutat4']."`n");
    if($session['alchemie']['zutat5']>0) output("$kraut5: ".$session['alchemie']['zutat5']."`n");
    if($session['alchemie']['zutat6']>0) output("$kraut6: ".$session['alchemie']['zutat6']."`n");
    if($session['alchemie']['zutat7']>0) output("$kraut7: ".$session['alchemie']['zutat7']."`n");
    if($session['alchemie']['zutat8']>0) output("$kraut8: ".$session['alchemie']['zutat8']."`n");
    if($session['alchemie']['zutat1s']>0) output("$kraut1s: ".$session['alchemie']['zutat1s']."`n");
    if($session['alchemie']['zutat2s']>0) output("$kraut2s: ".$session['alchemie']['zutat2s']."`n");
    addnav("","alchemie.php?op=check");
}
}
if($_GET['op']=="check"){
output("`2Folgende Tr�nke kannst du mit den ausgew�hlten Zutaten brauen.`n`n");
if($_POST['zutat5']>=$session['alchemie']['zutat5heal'] && $_POST['zutat6']>=$session['alchemie']['zutat6heal']
&& $session['alchemie']['zutat5heal']>0 && $session['alchemie']['zutat6heal']>0){
    output("Mit diesen Zutaten kannst du einen kleinen Heiltrank brauen.`n");
    addnav("Kl. Heiltrank brauen","alchemie.php?op=brew&act=lightheal");
}
if($_POST['zutat7']>=$session['alchemie']['zutat7heal'] && $_POST['zutat8']>=$session['alchemie']['zutat8heal']
&& $session['alchemie']['zutat7heal']>0 && $session['alchemie']['zutat8heal']>0){
    output("Mit diesen Zutaten kannst du einen Heiltrank brauen.`n");
    addnav("Heiltrank brauen","alchemie.php?op=brew&act=heal");
}
if($_POST['zutat1']>=$session['alchemie']['zutat1poison'] && $_POST['zutat2']>=$session['alchemie']['zutat2poison']
&& $session['alchemie']['zutat1poison']>0 && $session['alchemie']['zutat2poison']>0){
    output("Mit diesen Zutaten kannst du ein Schlafgift brauen.`n");
    addnav("Schlafgift brauen","alchemie.php?op=brew&act=sleep");
}
if($_POST['zutat3']>=$session['alchemie']['zutat3poison'] && $_POST['zutat4']>=$session['alchemie']['zutat4poison']
&& $session['alchemie']['zutat3poison']>0 && $session['alchemie']['zutat4poison']>0){
    output("Mit diesen Zutaten kannst du ein L�hmungsgift brauen.`n");
    addnav("L�hmungsgift brauen","alchemie.php?op=brew&act=paralyze");
}
if($_POST['zutat2']>=$session['alchemie']['zutat2defpush'] && $_POST['zutat5']>=$session['alchemie']['zutat5defpush']
&& $session['alchemie']['zutat2defpush']>0 && $session['alchemie']['zutat5defpush']>0){
    output("Mit diesen Zutaten kannst du einen Trank der Steinhaut brauen.`n");
    addnav("Steinhauttrank brauen","alchemie.php?op=brew&act=stone");
}
if($_POST['zutat1']>=$session['alchemie']['zutat1attpush'] && $_POST['zutat6']>=$session['alchemie']['zutat6attpush']
&& $session['alchemie']['zutat1attpush']>0 && $session['alchemie']['zutat6attpush']>0){
    output("Mit diesen Zutaten kannst du einen Krafttrank brauen.`n");
    addnav("Krafttrank brauen","alchemie.php?op=brew&act=might");
}
if($_POST['zutat1']>=$session['alchemie']['zutat1permhp'] && $_POST['zutat6']>=$session['alchemie']['zutat6permhp']
&& $_POST['zutat7']>=$session['alchemie']['zutat7permhp'] && $_POST['zutat2s']>=$session['alchemie']['zutat2spermhp']
&& $session['alchemie']['zutat1permhp']>0 && $session['alchemie']['zutat6permhp']>0
&& $session['alchemie']['zutat7permhp']>0 && $session['alchemie']['zutat2spermhp']>0){
    output("Mit diesen Zutaten kannst du einen Lebenstrank brauen.`n");
    addnav("Lebenstrank brauen","alchemie.php?op=brew&act=life");
}
if($_POST['zutat2']>=$session['alchemie']['zutat2charme'] && $_POST['zutat5']>=$session['alchemie']['zutat5charme']
&& $_POST['zutat6']>=$session['alchemie']['zutat6charme'] && $_POST['zutat1s']>=$session['alchemie']['zutat1scharme']
&& $session['alchemie']['zutat2charme']>0 && $session['alchemie']['zutat5charme']>0
&& $session['alchemie']['zutat6charme']>0 && $session['alchemie']['zutat1scharme']>0){
    output("Mit diesen Zutaten kannst du einen Sch�nheitstrank brauen.`n");
    addnav("Sch�nheitstrank brauen","alchemie.php?op=brew&act=charme");
}
if($_POST['zutat3']>=$session['alchemie']['zutat3permatt'] && $_POST['zutat7']>=$session['alchemie']['zutat7permatt']
&& $_POST['zutat1s']>=$session['alchemie']['zutat1spermatt'] && $_POST['zutat2s']>=$session['alchemie']['zutat2spermatt']
&& $session['alchemie']['zutat3permatt']>0 && $session['alchemie']['zutat7permatt']>0
&& $session['alchemie']['zutat1spermatt']>0 && $session['alchemie']['zutat2spermatt']>0){
    output("Mit diesen Zutaten kannst du ein Elixier der Kraft brauen.`n");
    addnav("Elixier der St�rke brauen","alchemie.php?op=brew&act=strength");
}
if($_POST['zutat4']>=$session['alchemie']['zutat4permdef'] && $_POST['zutat8']>=$session['alchemie']['zutat8permdef']
&& $_POST['zutat1s']>=$session['alchemie']['zutat1spermdef'] && $_POST['zutat2s']>=$session['alchemie']['zutat2spermdef']
&& $session['alchemie']['zutat4permdef']>0 && $session['alchemie']['zutat8permdef']>0
&& $session['alchemie']['zutat1spermdef']>0 && $session['alchemie']['zutat2spermdef']>0){
    output("Mit diesen Zutaten kannst du ein Elixier des Geschicks brauen.`n");
    addnav("Elixier des Geschicks brauen","alchemie.php?op=brew&act=agility");
}
}
if($_GET['op']=="brew"){
$brew=e_rand(1,100);
$fail=25-round(($session['alchemie']['trankbrau']+$session['alchemie']['umgang'])/2,0);
$perfect=100-round(($session['alchemie']['trankbrau']+$session['alchemie']['umgang'])/2,0);
$luck=e_rand(1,2);
output("`2Du beginnst den Trank nach deinem Rezept zu brauen.`n");
    if($brew<$fail){
        $typ=0;
        output("`QDoch irgendetwas scheint nicht in Ordnung zu sein. Du gehst dein Rezept noch einmal durch`n`n");
    switch(e_rand(1,15)){
        case 1:
        case 2:
            $session['user']['alive']=false;
            $session['user']['hitpoints']=0;
            $session['alchemie']['progress']+=$session['alchemie']['level']*5;
            addnews($session['user']['name']." hat einen Trank mit t�dlichen Folgen gebraut.");
        if($luck==1){
            output("doch bevor du den Fehler entdeckst explodiert der Trank und du wirst in St�cke gerissen.`n`n`n
            Du bist tot!`n
            Du verlierst 1% deiner Erfahrung.");
            $session['user']['experience']*=.99;
        }else{
            output("und merkst, dass du die Reihenfolge einiger Zutaten vertauscht hast. Doch bevor du irgendetwas machen kannst,
            explodiert der Trank und die Scherben und die S�ure, die aus deinem Trank geworden ist, kosten dich das Leben.`n`n`n
            Du bist tot!`n
            Da du den Fehler allerdings noch bemerkt hast bekommst du 1% Erfahrung dazu.");
            $session['user']['experience']*=1.01;
        }
        break;
        case 3:
        case 4:
            output("doch du kannst nichts erkennen was du falsch gemacht haben k�nntest, und so steckst du den Trank ein.");
            $typ=3;
            $session['alchemie']['trank']+=1;
            $session['alchemie']['progress']+=$session['alchemie']['level']*15;
        break;
        case 5:
        case 6:
        case 7:
            output("und musst leicht schmunzeln, da du die Zutaten komplett falsch zugegeben hast.
            Dein Trank ist nichts weiter als ein wohlriechendes Wasser. Na wenigstens hast du ein neues Duftwasser entdeckt.`n
            Du bekommst 5 Charmepunkte.");
            $session['user']['charm']+=5;
            $session['alchemie']['progress']+=$session['alchemie']['level']*5;
        break;
        case 8:
        case 9:
        case 10:
            output("dabei f�llt dir auf, dass du den Trank zu wenig erhitzt hast. Der Trank hat sich in eine z�hfl�ssige Substanz verwandelt.");
            $session['alchemie']['progress']+=$session['alchemie']['level']*5;
        break;
        case 11:
        case 12:
        case 13:
            output("doch w�hrend du noch nach dem Fehler suchst atmest du giftige D�mpfe ein.`n
            Dir wird �bel und du f�llst in Ohnmacht. Als du erwachst merkst du, dass du lang geschlafen hast.`n
            Du verlierst 5 Runden und aufgrund der �belkeit die H�lfte deiner Lebenspunkte.");
            $session['user']['turns']-=5;
            $session['user']['hitpoints']*=.5;
            $session['alchemie']['progress']+=$session['alchemie']['level']*5;
        break;
        case 14:
        case 15:
            output("aber du wirst von einem leichten Gl�hen des Trankes abgelenkt und schaust nach was los ist.`n
            Du traust deinen Augen nicht als du siehst, dass sich der Trank in Gold verwandelt hat. Du nimmst den Goldklumpen heraus,
            und verkaufst ihn an einen H�ndler, der dir daf�r 500 Gold und 1 Edelstein zahlt.");
            $session['user']['gold']+=500;
            $session['user']['gems']+=1;
            $session['alchemie']['progress']+=$session['alchemie']['level']*5;
        break;
        }
        }elseif($brew>=$fail && $brew<=$perfect){
            output("`2Du braust den Trank penibel genau nach dem Rezept und steckst die Flasche, nachdem du kurz daran geschnuppert hast, ein.");
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Leichter Heiltrank\",\"0\",\"0\")";
            db_query($potion);
            $typ=1;
            $session['alchemie']['trank']+=1;
            $session['alchemie']['progress']+=$session['alchemie']['level']*35;
        }else{
        $exp=$session['user']['level']*e_rand(1,5);
            output("`2Als du mit dem Brauen des Trankes fertig bist und nochmal alles durchgehst bist du dir sicher,
            dass dir der Trank absolut perfekt gegl�ckt ist. Zufrieden steckst du den Trank ein.`n
            Du bekommst $exp Erfahrung.");
            $typ=2;
            $session['user']['experience']+=$exp;
            $session['alchemie']['trank']+=1;
            $session['alchemie']['progress']+=$session['alchemie']['level']*50;
    }
    switch($_GET['act']){
        case "lightheal":
        if($typ==1){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Leichter Heiltrank\",\"0\")";
            db_query($potion);
        }elseif($typ==2){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Leichter Heiltrank\",\"1\")";
            db_query($potion);
        }elseif($typ==3){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Leichter Heiltrank\",\"2\")";
            db_query($potion);
        }
        $session['alchemie']['zutat5']-=$session['alchemie']['zutat5heal'];
        $session['alchemie']['zutat6']-=$session['alchemie']['zutat6heal'];
        break;
        case "heal":
        if($typ==0){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Heiltrank\",\"0\")";
            db_query($potion);
        }elseif($typ==1){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Heiltrank\",\"1\")";
            db_query($potion);
        }elseif($typ==2){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Heiltrank\",\"2\")";
            db_query($potion);
        }
        $session['alchemie']['zutat7']-=$session['alchemie']['zutat7heal'];
        $session['alchemie']['zutat8']-=$session['alchemie']['zutat8heal'];
        break;
        case "sleep":
        if($typ==0){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Schlafgift\",\"0\")";
            db_query($potion);
        }elseif($typ==1){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Schlafgift\",\"1\")";
            db_query($potion);
        }elseif($typ==2){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Schlafgift\",\"2\")";
            db_query($potion);
        }
        $session['alchemie']['zutat1']-=$session['alchemie']['zutat1poison'];
        $session['alchemie']['zutat2']-=$session['alchemie']['zutat2poison'];
        break;
        case "paralyze":
        if($typ==0){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"L�hmungsgift\",\"0\")";
            db_query($potion);
        }elseif($typ==1){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"L�hmungsgift\",\"1\")";
            db_query($potion);
        }elseif($typ==2){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"L�hmungsgift\",\"2\")";
            db_query($potion);
        }
        $session['alchemie']['zutat3']-=$session['alchemie']['zutat3poison'];
        $session['alchemie']['zutat4']-=$session['alchemie']['zutat4poison'];
        break;
        case "stone":
        if($typ==0){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Steinhauttrank\",\"0\")";
            db_query($potion);
        }elseif($typ==1){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Steinhauttrank\",\"1\")";
            db_query($potion);
        }elseif($typ==2){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Steinhauttrank\",\"2\")";
            db_query($potion);
        }
        $session['alchemie']['zutat2']-=$session['alchemie']['zutat2defpush'];
        $session['alchemie']['zutat5']-=$session['alchemie']['zutat5defpush'];
        break;
        case "might":
        if($typ==0){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Krafttrank\",\"0\")";
            db_query($potion);
        }elseif($typ==1){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Krafttrank\",\"1\")";
            db_query($potion);
        }elseif($typ==2){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Krafttrank\",\"2\")";
            db_query($potion);
        }
        $session['alchemie']['zutat1']-=$session['alchemie']['zutat1attpush'];
        $session['alchemie']['zutat6']-=$session['alchemie']['zutat6attpush'];
        break;
        case "life":
        if($typ==0){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Lebenstrank\",\"0\")";
            db_query($potion);
        }elseif($typ==1){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Lebenstrank\",\"1\")";
            db_query($potion);
        }elseif($typ==2){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Lebenstrank\",\"2\")";
            db_query($potion);
        }
        $session['alchemie']['zutat1']-=$session['alchemie']['zutat1permhp'];
        $session['alchemie']['zutat6']-=$session['alchemie']['zutat6permhp'];
        $session['alchemie']['zutat7']-=$session['alchemie']['zutat7permhp'];
        $session['alchemie']['zutat2s']-=1;
        break;
        case "charme":
        if($typ==0){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Sch�nheitstrank\",\"0\")";
            db_query($potion);
        }elseif($typ==1){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Sch�nheitstrank\",\"1\")";
            db_query($potion);
        }elseif($typ==2){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Sch�nheitstrank\",\"2\")";
            db_query($potion);
        }
        $session['alchemie']['zutat2']-=$session['alchemie']['zutat2charme'];
        $session['alchemie']['zutat5']-=$session['alchemie']['zutat5charme'];
        $session['alchemie']['zutat6']-=$session['alchemie']['zutat6charme'];
        $session['alchemie']['zutat1s']-=1;
        break;
        case "strength":
        if($typ==0){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Elixier der St�rke\",\"0\")";
            db_query($potion);
        }elseif($typ==1){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Elixier der St�rke\",\"1\")";
            db_query($potion);
        }elseif($typ==2){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Elixier der St�rke\",\"2\")";
            db_query($potion);
        }
        $session['alchemie']['zutat3']-=$session['alchemie']['zutat3permatt'];
        $session['alchemie']['zutat7']-=$session['alchemie']['zutat7permatt'];
        $session['alchemie']['zutat1s']-=1;
        $session['alchemie']['zutat2s']-=1;
        break;
        case "agility":
        if($typ==0){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Elixier der Geschicklichkeit\",\"0\")";
            db_query($potion);
        }elseif($typ==1){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Elixier der Geschicklichkeit\",\"1\")";
            db_query($potion);
        }elseif($typ==2){
            $potion="INSERT INTO `potions` (acctid, name, type) VALUES ($acctid,\"Elixier der Geschicklichkeit\",\"2\")";
            db_query($potion);
        }
        $session['alchemie']['zutat4']-=$session['alchemie']['zutat4permdef'];
        $session['alchemie']['zutat8']-=$session['alchemie']['zutat8permdef'];
        $session['alchemie']['zutat1s']-=1;
        $session['alchemie']['zutat2s']-=1;
        break;
    }
}
if($session['user']['alive']) {
addnav("Zur�ck zum Labor","alchemie.php");
addnav("Zur Alchemistin","alchemistin.php");
addnav("Zur�ck zum Dorf","village.php");
}else{
addnav("T�gliche News","news.php");
}
savetable("alchemie");
$copyright ="<div align='center'><a href=http://www.lotgd-midgar.de/index.php target='_blank'>&copy;`#Laserian`0</a></div>";
output("`n`n`n`n$copyright`n ",true);
page_footer();
?>