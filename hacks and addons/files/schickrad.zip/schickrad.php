<?
/*
Idee: Tiger313
Umsetzung: Tiger313
Version 1.0
Getestet mit: 0.9.7+jt ext (GER)
Demo: http://www.das-ging-fix.de/dorte/MLC-Board2-1-3/logd/index.php (ab Level 7)
Was ist das �berhaupt: 
Wenn der User den Level 7,8 oder 9 hat erscheint im Dorf ein neuer Link (Schicksalsrad)
Dort hat er nun verschiedene M�glichkeiten

1. Rad untersuchen (geht nur wenn man min.500 Gold und 2 Edelsteine in der Tasche hat und geht nur 3x am "Tag")
Da kann man Gold verlieren/finden. Das verlorene Geld landet auf einem extra platz in der db wo es dann zu addiert wird 
bis es jemand findet somit ist der Gewinn abh�ngig von dem pech anderer User
Das gleiche gilt f�r Edelsteine oder man bekommt ein Positives/Negatives Spezial

2. Rad selber drehen (geht nur 2x dann mu� erst der drache get�tet werden um wieder 2 versuche zu bekommen)
Da kann man seine R�stung/Waffe setzen um eine andere zu bekommen
Gewinnm�glichkeiten von je Level 1-25

3. dagegen Tr�tten
Der User kann sein "Leben" setzen um sofort auf Level 14 + Mega Waffe und R�stug zu erhalten
er kann aber auch Pech haben und auf Level 1 abgestufft werden
(Gold auf 0, Waffe/R�stung weg, usw. wie nach drachenkampf nur ohne Bonus) 

Anleitung
---------
Village.php
###########
Suche:
addnav("Marktplatz");

darunter:
if ($session['user']['level']==7 || $session[user]['level']==8 || $session[user]['level']==9){
addnav("`6Schicksalsrad","schickrad.php");
}
--------------------------------------
Newday.php
##########
Suche:
$session['user']['seendragon'] = 0;

darunter:
$session['user']['sradsuch'] = 0;
--------------------------------------
SQL:
####

ALTER TABLE `accounts` ADD `sradsuch` INT( 2 ) DEFAULT '0' NOT NULL ;
ALTER TABLE `accounts` ADD `sradnm` INT( 2 ) DEFAULT '0' NOT NULL ;

CREATE TABLE `schicksalrad` (
  `vergold` int(254) NOT NULL default '100',
  `vergem` int(11) NOT NULL default '0',
  PRIMARY KEY  (`vergold`)
) TYPE=MyISAM;

INSERT INTO `schicksalrad` VALUES (100, 0);
-------------------------------------------

Diese Datei noch ins Root packen 
FERTIG!
*/



require_once "common.php";
page_header("Schicksalsrad");

if ($HTTP_GET_VARS[op] == ""){
    addcommentary();
    checkday();
    page_header("Das Schicksalsrad");
    output("`b`c`2Das Schicksalsrad`0`c`b");
    output("`n`2Langsam n�herst du dich dem Schicksalsrad und fragst dich warum es dir nicht schon vorher aufgefallen ist.
    Da es ja direkt neben dem Brunnen steht, sehr gro� und Alt ist, wunderst du dich ihn zum ersten Mal zu sehen.
    Neugierig schaust du dir das rad an und versuchst die Inschriften zu lesen, leider verstehst du kein Wort von dem was da steht.
    Du versuchst das Rad zu drehen aber irgendeine Geheimnisvolle Macht blockiert es ... oder ist es nur verrostet??
    Du �berlegst wo du ein wenig �l finden k�nntest oder irgendwas anderes das dir jetzt helfen k�nnte.`0");
    output("`n");
    output("`n`QWas m�chtest Du machen?`0");
    output("`n`n");
	viewcommentary("Schicksal","Hier reden",30,"sagt");
	
    addnav("Das Schicksalsrad");
   if ($session['user']['gold']<500 || $session[user]['gems']<2){ 
    addnav("`3Rad genauer untersuchen","schickrad.php?op=nein");
   }else{
    addnav("`3Rad genauer untersuchen","schickrad.php?op=such");
   }
    addnav("`7Am Rad versuchen noch mal zu drehen","schickrad.php?op=nochmal");
    addnav("`6dagegen Tr�tten","schickrad.php?op=geist");
    addnav("Nach �l im Dorf suchen","village.php");
}
else if ($HTTP_GET_VARS[op] == "such") {
   page_header("Das Schicksalsrad");
  if ($session['user']['sradsuch']>2 || $session[user]['turns']<1){
    output("`c`b`&Das Schicksalsrad`0`b`c");
    output("`nDu hast eigentlich keine Lust mehr zu suchen, �berlegst aber ob du nicht doch solltest.`n 
    Entscheidest dich aber dagegen.");
    addnav("zur�ck","schickrad.php");
  }else{
    $session['user']['sradsuch']+=1;
    output("`c`b`&Das Schicksalsrad`0`b`c");
    output("`n`@Du untersuchst das Rad genauer in der Hoffnung ein versteckten Knopf, Schloss oder Keil zu finden.
    An der rad Oberfl�che scheint nichts zu sein und auch auf der R�ckseite ist nicht mal ne �ffnung. `n`n");
    output("`n`9Du verbrauchst einen Waldkampf!`n`2");
    $session['user']['turns']-=1;
	switch(e_rand(1,8)){
	
	case 1: //Gold Verlieren
		if ($session['user']['gold']<10){ 
		output("`nDu bleibst mit deiner Jacke an einem scharfen Stein h�ngen.`n 
		Du ziehst kr�ftig an der Jacke und reist dir ein Loch rein.`n
		Da kein Gold in der Tasche ist, hast du noch mal gl�ck,
                denn du h�ttest es sicher durch das Loch verloren.`n");
	}else{
		$goldplu = round($session['user']['gold'] * 0.15);
		$sql = "UPDATE schicksalrad SET vergold= vergold+$goldplu";
		db_query($sql);
		output("`nDu bleibst mit deiner Jacke an einem scharfen Stein h�ngen und reist dir ein Loch in die Tasche.`n
		Ohne das du es merkst fallen dir `5$goldplu Goldst�cke `2durch das Loch raus!`n");
		$session['user']['gold']-=$goldplu;
		}
	break;

	case 2: //Gold finden
		$sql = db_query("SELECT vergold FROM schicksalrad");
		$result = db_fetch_assoc($sql) or die(db_error(LINK));
		output("`nGerade als du aufh�ren willst zu suchen bemerkst du auf dem Boden etwas glitzern.
		Auf dem Boden findest du `5".$result[vergold]." `2Gold!");
		$session['user']['gold']+=$result['vergold'];
		$sql = "UPDATE schicksalrad SET vergold= 100";
		db_query($sql);
		output("`n`2Gl�cklich �ber den Fund und m�de von der suche gibst du auf und etscheidest dich sp�ter weiter zu suchen.`n");
		addnews("`Q".$session[user][name]."`@ hat neben dem Schicksalsrad `^".$result[vergold]." `@Goldst�cke gefunden`@");
	break;
	
	case 3: //Edelsteine Verlieren
		if ($session['user']['gems']<1){ 
		output("`nDu bleibst mit deiner Jacke an einem scharfen Stein h�ngen.`n 
		Du ziehst kr�ftig an der Jacke und reist dir ein Loch rein.`n 
		Da in der Tasche keine Edelsteine sind, hast du noch mal gl�ck,
                denn du h�ttest sie sicher durch das Loch verloren.`n");
	}else{
		if ($session['user']['gems']<8){
		$gemplu = 1;
	    }else{	
		$gemplu = round($session['user']['gems'] * 0.22);
	    }	
		$sql = "UPDATE schicksalrad SET vergem= vergem+$gemplu";
		db_query($sql);
		output("`nDu bleibst mit deiner Jacke an einem scharfen Stein h�ngen und reist dir ein Loch in die Tasche.`n
		Ohne das du es merkst fallen dir `9$gemplu Edelsteine `2durch das Loch raus!`n");
		$session['user']['gems']-=$gemplu;
		}
	break;

	case 4: //Edelsteine finden
		$sql = db_query("SELECT vergem FROM schicksalrad");
		$result = db_fetch_assoc($sql) or die(db_error(LINK));
		output("`nGerade als du aufh�ren willst zu suchen bemerkst du auf dem Boden etwas glitzern.
		Auf dem Boden findest du `9".$result[vergem]." `2Edelsteine!");
		$session['user']['gems']+=$result['vergem'];
		$sql = "UPDATE schicksalrad SET vergem= 0";
		db_query($sql);
		output("`n`2Gl�cklich �ber den Fund und m�de von der suche gibst du auf und etscheidest dich sp�ter weiter zu suchen.`n");
		addnews("`Q".$session[user][name]."`@ hat neben dem Schicksalsrad `3".$result[vergem]." `@Edelsteine gefunden`@");
	break;
	case 5: //Krank werden
                output("`n`b`^Du findest einen Lutscher und da du S��igkeiten �ber alles liebst ... *schmatz* ... *ScHmAtZ*`n
		Der Lutscher wahr wohl nicht mehr so gut. Du hast dir Salmonellen Infektion zugezogen!!`n"); 
                $buff = array("name"=>"`8Sal`6mo`8nel`Qlen`0","rounds"=>160,"wearoff"=>"`5`bDeine Salmonellen lassen nach!.`b`0","atkmod"=>.55,"defmod"=>.55,"roundmsg"=>"Deine Salmonellen behindern deine Kampff�higkeit!","activate"=>"defense","activate"=>"offense"); 
                $session['bufflist']['schicksal']=$buff; 
                addnews("`Q".$session[user][name]."`@ konnte die Finger nicht von alten Lutschern lassen und hat sich die `8Sal`6mo`8nel`Qlen `@gefangen`@"); 
                break;
	case 6: //Extra Power
                addnews("`@Man hat beobachtet wie `Q".$session[user][name]."`@ neben einem alten Schicksalsrad von einem Blitz getroffen wurde!!`@"); 
                output("`n`b`^Nach paar minuten findes du dochnoch etwas ... es ist ein `b`7silberner `b`^Knopf`n
		In dem moment in dem du ihn dr�ckst verdunkelt sich der Himmel und ein Gewitter zieht auf.`n
		Auf der suche nach einem sch�tzendem Dach wirst du von einem Blitz getroffen.`n
		Der Blitz f�hlt sich zu deinem erstaunen ganz warm an und du f�hlst wie deine Muskel H�rter werden.`n
		Du schlie�t deine Augen um die macht zu geniessen.`n
		Als sie wieder offen sind ist das Gewitter vorbei, die Wirkung der Blitzenergie aber immer noch in dir erhalten.`n`n
		`3Du bist st�rker geworden.`n`n"); 
                $buff = array("name"=>"`6Blitzenergie`0","rounds"=>160,"wearoff"=>"`5`bDie Blitzenergie ist verbraucht!.`b`0","atkmod"=>2.3,"defmod"=>2.3,"roundmsg"=>"Deine Sinne sind an der Spitze und die Muskeln Hart wie STAHL!!","activate"=>"offense","activate"=>"defense"); 
                $session['bufflist']['schicksal']=$buff; 
                break;
	case 7:
        break;
	case 8:
        break;
	}
	addnav("weiter","schickrad.php");
	addnav("zur�ck ins Dorf","village.php");
    }
}
else if ($HTTP_GET_VARS[op] == "nochmal") {
	page_header("Das Schicksalsrad");
  if ($session['user']['sradnm']<2){
    output("`c`b`&Das Schicksalsrad`0`b`c");
    output("`nDu sammelst all deine Kraft um noch mal zu versuchen das Rad in bewegung zu setzen, `n
    legst deine Hand auf die Scheibe als pl�tzlich es aufblitzt und ein dir unbekanntes Wessen erscheint. `n
    Er schaut dich von oben bis unten an und spricht dich an: `1`b\"STOP!! `b Du kannst nicht einfach so am Schicksalsrad drehen. `n
    Es bedarf immer eines Einsatzes. Du kannst heuet um deine R�stung oder deine Waffe spielen, `n
    aber bedenke dass der Gewinn auch schlechter als der Einsatz sein kann. \"`n
    `0 er Atmet tief ein und spricht weiter: `1`b\"Noch eine sehr wichtige sache. `b `n
    Du kannst nur 2x mit mir spielen dann musst du mir beweisen das du w�rdig bist meine Zeit zu verschwenden, `n
    indem du z.b den Drachen t�test.\"`n`n
    `QWas m�chtest du tun??`n");
    addnav("Waffe setzen","schickrad.php?op=swaffe");
    addnav("R�stung setzen","schickrad.php?op=srust");
    addnav("lieber nicht ","schickrad.php");
  }else{
    output("`c`b`&Das Schicksalsrad`0`b`c");
    output("`n`7\"Ich Spiele mit dir nicht solange du den `2gr�nen `7Drachen nicht get�tet hast.\" `6erklingt eine Stimme als du am Rad drehen willst.`n");
    addnav("zur�ck ","schickrad.php");
  }
}
else if ($HTTP_GET_VARS[op] == "swaffe") {
	$session['user']['sradnm']+=1;
	$session['user']['attack']-=$session['user']['weapondmg'];
	$session['user']['weapondmg'] = 0;
	$session['user']['weaponvalue'] = 0;
	switch(e_rand(1,15)){
	case 1:
	$session['user']['weapondmg'] = 1;
	$session['user']['attack']+=$session['user']['weapondmg'];
	$session['user']['weaponvalue'] = 48;
	$session['user']['weapon'] = "Dolch";
	break;
	case 2:
	$session['user']['weapondmg'] = 2;
	$session['user']['attack']+=$session['user']['weapondmg'];
	$session['user']['weaponvalue'] = 225;
	$session['user']['weapon'] = "Armbrust";
	break;
	case 3:
	$session['user']['weapondmg'] = 3;
	$session['user']['attack']+=$session['user']['weapondmg'];
	$session['user']['weaponvalue'] = 585;
	$session['user']['weapon'] = "Katapult";
	break;
	case 4:
	$session['user']['weapondmg'] = 4;
	$session['user']['attack']+=$session['user']['weapondmg'];
	$session['user']['weaponvalue'] = 990;
	$session['user']['weapon'] = "Bogen";
	break;
	case 5:
	$session['user']['weapondmg'] = 5;
	$session['user']['attack']+=$session['user']['weapondmg'];
	$session['user']['weaponvalue'] = 1575;
	$session['user']['weapon'] = "Waldl�uferschwert";
	break;
	case 6:
	$session['user']['weapondmg'] = 6;
	$session['user']['attack']+=$session['user']['weapondmg'];
	$session['user']['weaponvalue'] = 2250;
	$session['user']['weapon'] = "Sword of Darkness";
	break;
	case 7:
	$session['user']['weapondmg'] = 7;
	$session['user']['attack']+=$session['user']['weapondmg'];
	$session['user']['weaponvalue'] = 2790;
	$session['user']['weapon'] = "Regenbogenschwert";
	break;
	case 8:
	$session['user']['weapondmg'] = 8;
	$session['user']['attack']+=$session['user']['weapondmg'];
	$session['user']['weaponvalue'] = 3420;
	$session['user']['weapon'] = "Roter Zweih�nder";
	break;
	case 9:
	$session['user']['weapondmg'] = 10;
	$session['user']['attack']+=$session['user']['weapondmg'];
	$session['user']['weaponvalue'] = 5040;
	$session['user']['weapon'] = "Claymore aus Schwarzmosaik";
	break;
	case 10:
	$session['user']['weapondmg'] = 12;
	$session['user']['attack']+=$session['user']['weapondmg'];
	$session['user']['weaponvalue'] = 6840;
	$session['user']['weapon'] = "Doppelschwerter aus Sternenstahl";
	break;
	case 11:
	$session['user']['weapondmg'] = 14;
	$session['user']['attack']+=$session['user']['weapondmg'];
	$session['user']['weaponvalue'] = 9000;
	$session['user']['weapon'] = "Poseidons Speer";
	break;
	case 12:
	$session['user']['weapondmg'] = 17;
	$session['user']['attack']+=$session['user']['weapondmg'];
	$session['user']['weaponvalue'] = 12540;
	$session['user']['weapon'] = "Zeus Zepter";
	break;
	case 13:
	$session['user']['weapondmg'] = 20;
	$session['user']['attack']+=$session['user']['weapondmg'];
	$session['user']['weaponvalue'] = 14690;
	$session['user']['weapon'] = "Troll-Zerst�rer";
	break;
	case 14:
	$session['user']['weapondmg'] = 22;
	$session['user']['attack']+=$session['user']['weapondmg'];
	$session['user']['weaponvalue'] = 17220;
	$session['user']['weapon'] = "�onen-Schwert";
	break;
	case 15:
	$session['user']['weapondmg'] = 25;
	$session['user']['attack']+=$session['user']['weapondmg'];
	$session['user']['weaponvalue'] = 19999;
	$session['user']['weapon'] = "Armagedon Schwert";
	break;
     }
    output("`n`7Er nimmt dir deine Waffe weg und dreht am Rad. Nach ein paar sekunden bleibt das Rad stehen.`n
    Sofort bekommst du deine neue Level `3".$session['user']['weapondmg']." `7Waffe mit dem Namen `3".$session['user']['weapon']." `7�berreicht`n");
   addnews("`0".$session[user][name]."`@ hat seine Waffe am Schicksalsrad eingetauscht. Ob das eine gute Idee wahr???`@"); 
   addnav("weiter","schickrad.php");
   addnav("zur�ck ins Dorf","village.php");
}
else if ($HTTP_GET_VARS[op] == "srust") {
	$session['user']['sradnm']+=1;
	$session['user']['defence']-=$session['user']['armordef'];
	$session['user']['armordef'] = 0;
	$session['user']['armorvalue'] = 0;
	switch(e_rand(1,15)){
	case 1:
	$session['user']['armordef'] = 1;
	$session['user']['defence']+=$session['user']['armordef'];
	$session['user']['armorvalue'] = 48;
	$session['user']['armor'] = "Jogginghose";
	break;
	case 2:
	$session['user']['armordef'] = 2;
	$session['user']['defence']+=$session['user']['armordef'];
	$session['user']['armorvalue'] = 225;
	$session['user']['armor'] = "Alter Lendenschurz";
	break;
	case 3:
	$session['user']['armordef'] = 3;
	$session['user']['defence']+=$session['user']['armordef'];
	$session['user']['armorvalue'] = 585;
	$session['user']['armor'] = "Nikes Siegerkranz";
	break;
	case 4:
	$session['user']['armordef'] = 4;
	$session['user']['defence']+=$session['user']['armordef'];
	$session['user']['armorvalue'] = 990;
	$session['user']['armor'] = "Verzauberte Knochenkette";
	break;
	case 5:
	$session['user']['armordef'] = 5;
	$session['user']['defence']+=$session['user']['armordef'];
	$session['user']['armorvalue'] = 1575;
	$session['user']['armor'] = "Brustschutz aus Zwergenerz";
	break;
	case 6:
	$session['user']['armordef'] = 6;
	$session['user']['defence']+=$session['user']['armordef'];
	$session['user']['armorvalue'] = 2250;
	$session['user']['armor'] = "Meistergewand";
	break;
	case 7:
	$session['user']['armordef'] = 7;
	$session['user']['defence']+=$session['user']['armordef'];
	$session['user']['armorvalue'] = 2790;
	$session['user']['armor'] = "Wei�er Harnisch";
	break;
	case 8:
	$session['user']['armordef'] = 8;
	$session['user']['defence']+=$session['user']['armordef'];
	$session['user']['armorvalue'] = 3420;
	$session['user']['armor'] = "Regenbogenr�stung";
	break;
	case 9:
	$session['user']['armordef'] = 10;
	$session['user']['defence']+=$session['user']['armordef'];
	$session['user']['armorvalue'] = 5040;
	$session['user']['armor'] = "�gide der Furcht";
	break;
	case 10:
	$session['user']['armordef'] = 12;
	$session['user']['defence']+=$session['user']['armordef'];
	$session['user']['armorvalue'] = 6840;
	$session['user']['armor'] = "Teklarpanzer";
	break;
	case 11:
	$session['user']['armordef'] = 14;
	$session['user']['defence']+=$session['user']['armordef'];
	$session['user']['armorvalue'] = 9000;
	$session['user']['armor'] = "Schild aus Ultimarith";
	break;
	case 12:
	$session['user']['armordef'] = 17;
	$session['user']['defence']+=$session['user']['armordef'];
	$session['user']['armorvalue'] = 12540;
	$session['user']['armor'] = " �onen-Panzer";
	break;
	case 13:
	$session['user']['armordef'] = 20;
	$session['user']['defence']+=$session['user']['armordef'];
	$session['user']['armorvalue'] = 14690;
	$session['user']['armor'] = "Verfluchter Sch�delhelm";
	break;
	case 14:
	$session['user']['armordef'] = 22;
	$session['user']['defence']+=$session['user']['armordef'];
	$session['user']['armorvalue'] = 17220;
	$session['user']['armor'] = "Asterias Sternenkleid";
	break;
	case 15:
	$session['user']['armordef'] = 25;
	$session['user']['defence']+=$session['user']['armordef'];
	$session['user']['armorvalue'] = 19999;
	$session['user']['armor'] = "Armagedon Platten R�stung";
	break;
     }
    output("`n`7Er nimmt dir deine R�stung weg und dreht am Rad. Nach ein paar sekunden bleibt das Rad stehen.`n
    Sofort bekommst du deine neue Level `3".$session['user']['armordef']." `7R�stung mit dem Namen klangvollen `3".$session['user']['armor']." `7�berreicht`n");
   addnews("`0".$session[user][name]."`@ hat seine R�stung am Schicksalsrad eingetauscht. Ob das eine gute Idee wahr???`@"); 
   addnav("weiter","schickrad.php");
   addnav("zur�ck ins Dorf","village.php");
}
else if ($HTTP_GET_VARS[op] == "nein") {
	page_header("Das Schicksalsrad");
	output("`n`7Als du dich dem Rad n�herst um es genauer zu untersuchen erscheint eine Geistige gestallt die dich am neher kommen hindert.`n
	Im n�chsten Moment ert�nt eine Stimme in deinem Kopf: `3\"Ich bin die W�chterin der Schicksalsrads. Ich darf dich erst durchlassen wenn deine Taschen gef�llt sind.\"`n`n
	`6Du musst mindestens `8500 Goldst�cke `6und `92 Edelsteine `6in deinen Taschen haben um hier was ausrichten zu k�nnen.`n`0");
	addnav("zur�ck zum Rad","schickrad.php");
	addnav("zur�ck ins Dorf","village.php");
}
else if ($HTTP_GET_VARS[op] == "geist") { 
	 output("`n`7Du trittst mit voller Kraft gegen das Rad, drehst dich um und willst wider gehen als auf ein mal jemand deinen Namen ruft.`n
	 		`4\" ".$session[user][name]." `4\" `7Schnell guckst du in die Richtung aus der die Stimme kam aber da ist niemand.`n
			`4\" ".$session[user][name]." `4\" `7 und wieder ert�nt die Stimme. Du reibst mit deinen H�nden die Augen und als du sie wieder �ffnest erkennst du einen kleinen Geist`n
			der neben dem Schicksalsrad schwebt.`n 
			`4\"".$session[user][name]." `4du hast gerufen!\" `n
			`7 V�llig verblufft schaust du den Geist an der weiter zu dir Spricht`n
			`4\"Hab leider wenig zeit also bringen wir es schnell hinter uns. Du weist ja dein Schicksal steht schon fest die frage ist nur ob du ihm folgen willst.`n
			Das Rad kann deine Entwicklung beschleunigen oder dich wieder zur�ckwerfen, dich `1St�rke `4oder `8Schw�chen`4.`n
			Es kann aber sein das du schon auf dem richtigen weg bist und es passiert nix.`n
			Die Entscheidung liegt bei dir, willst du das Risiko eingehen oder lieber dich schnell aus dem Staub machen? \"`n`n
			`Q Was machst du??");
		addnav("1-2-RISIKO","schickrad.php?op=letztefrage");
		addnav("zur�ck zum Rad","schickrad.php");
		addnav("zur�ck ins Dorf","village.php");
}
else if ($HTTP_GET_VARS[op] == "letztefrage") {
	 output("`n`4\"Bist du dir ganz sicher dass du es tun willst? Ich frage dich das LETZE mal dann setze ich das Rad in gang.
	 Bedenke das du im schlimmsten fall alles verlieren k�nntest, praktisch wie nach einem Drachensieg nur ohne Bonus.\"`7`n`n");
	addnav("Ja ich will es!!!","schickrad.php?op=machen");
	addnav("NE lieber doch nicht","village.php");
}
else if ($HTTP_GET_VARS[op] == "machen") {
	output("`n`7 Er dreht am Rad, deine Spannung steigt. `b`2Gr�n `6Gelb `9Blau, `2Gr�n `6Gelb `9Blau, `2Gr�n `6Gelb `9Blau,`b`n
	 `7 Das Rad wird immer langsamer bis es endlich stehen bleibt.`n
	 Der Geist schaut auf das Rad und sagt: `4\" So das wahr schon. Ich verabschiede mich und w�nsche dir alles Gute. Bis zum n�chsten mal. \"`n
	 `7 Dann ist er verschwunden. `n`n
	 Auf einmal sp�rst du ein merkw�rdiges kribbeln und f�llst in Ohnmacht.`7`n`n");
	addnav("weiter","schickrad.php?op=weiter");
}
else if ($HTTP_GET_VARS[op] == "weiter") {
	output("`n`7 Als du zu dir kommst siehst erstmal keine ver�nderungen aber eine dir bekannte stimme die du direkt in deinem kopf h�rst sagt dir:`n`n");
	 	switch(e_rand(1,3)){
	
		case 1: //alles verlieren
		$gemplu = round($session['user']['gems']);
		$sql = "UPDATE schicksalrad SET vergem= vergem+$gemplu";
		db_query($sql);
		$goldplu = round($session['user']['gold']);
		$sql = "UPDATE schicksalrad SET vergold= vergold+$goldplu";
		db_query($sql);
		$session['user']['gold']= 250;
		$session['user']['armor'] = "Topf";
		$session['user']['defence']-=$session['user']['armordef'];
		$session['user']['armordef'] = 0;
		$session['user']['armorvalue'] = 0;
		$session['user']['attack']-=$session['user']['weapondmg'];
		$session['user']['weapondmg'] = 0;
		$session['user']['weaponvalue'] = 0;
		$session['user']['weapon'] = "Stock";
		$session['user']['seenmaster']= 0;
		$session['user']['experience']= 0;
		$session['user']['goldinbank']= 0;
		if ($session['user']['level']==7){
			$session['user']['level']-=6;
			$session['user']['maxhitpoints']-=60;
			$session['user']['soulpoints']-=30;
			$session['user']['attack']-=6;
			$session['user']['defence']-=6;
			$session['user']['reputation']-=18;
		}
		else if ($session['user']['level']==8){
			$session['user']['level']-=7;
			$session['user']['maxhitpoints']-=70;
			$session['user']['soulpoints']-=35;
			$session['user']['attack']-=7;
			$session['user']['defence']-=7;
			$session['user']['reputation']-=21;
		} else {
			$session['user']['level']-=8;
			$session['user']['maxhitpoints']-=80;
			$session['user']['soulpoints']-=40;
			$session['user']['attack']-=8;
			$session['user']['defence']-=8;
			$session['user']['reputation']-=24;
			}
		output("`n`4\"Leider meint das Schicksal es nicht gut mit dir und will dass du wieder im `8`bLevel 1`4`b anfangen musst.\"`n
			`7Du bist dir nicht sicher was er damit meint, f�hlst dich aber irgendwie sehr geschw�cht.`n
			Da die Stimme und auch das Rad verschwunden sind gehst du zur�ck auf den Dorfplatz.`n`n");
	 	addnav("weiter","village.php");
		addnews("`0".$session[user][name]."`@ w�rde durch das Schicksalsrad zu einen `5Baby `@verwandelt`@"); 
   		break;
		case 2: // Nix
		output("`n`4\"Du Folgst bereits deinem Schicksal.\"
			`7Du bist dir nicht sicher was er damit meint und f�hlst keine Ver�nderungen an dir.`n
			Da die Stimme und auch das Rad verschwunden sind gehst du zur�ck auf den Dorfplatz.`n`n");
	 	addnav("weiter","village.php");
		break;
		case 3: // Gewninnen
		$session['user']['armor'] = "Geister R�stung";
		$session['user']['defence']-=$session['user']['armordef'];
		$session['user']['armordef'] = 20;
		$session['user']['defence']+=$session['user']['armordef'];
		$session['user']['armorvalue'] = 0;
		$session['user']['attack']-=$session['user']['weapondmg'];
		$session['user']['weapondmg'] = 20;
		$session['user']['attack']+=$session['user']['weapondmg'];
		$session['user']['weaponvalue'] = 0;
		$session['user']['weapon'] = "Geister Lanze";
		$session['user']['seenmaster']= 0;
		$session['user']['level']= 14;
		$session['user']['experience']= 36071;
		if (!$session['user']['level']==7){
			$session['user']['maxhitpoints']+=80;
			$session['user']['soulpoints']+=35;
			$session['user']['attack']+=7;
			$session['user']['defence']+=7;
			$session['user']['reputation']+=21;
		}
		else if (!$session['user']['level']==8){
			$session['user']['maxhitpoints']+=60;
			$session['user']['soulpoints']+=30;
			$session['user']['attack']+=6;
			$session['user']['defence']+=6;
			$session['user']['reputation']+=18;
		} else {
			$session['user']['maxhitpoints']+=50;
			$session['user']['soulpoints']+=25;
			$session['user']['attack']+=5;
			$session['user']['defence']+=5;
			$session['user']['reputation']+=15;
			}
		output("`n`4\"Du hast Gl�ck. Das Schicksal will das du der n�chste drachent�ter wirst und st�fft dich auf `8`bLevel 15`4`b auf.\"`n
			`7Du bist dir nicht sicher was er damit meint, f�hlst dich aber irgendwie sehr Stark und auch deine Ausr�stung hat sich ver�ndert.`n
			Da die Stimme und auch das Rad verschwunden sind gehst du zur�ck auf den Dorfplatz.`n`n");
	 	addnav("weiter","village.php");
		addnews("`0".$session[user][name]."`@ w�rde durch das Schicksalsrad zu einen `6�berkrieger `@verwandelt`@"); 
   		break;
	}
}
page_footer();
?>