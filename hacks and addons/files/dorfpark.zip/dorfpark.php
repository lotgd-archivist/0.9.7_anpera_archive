<?php
//Idee und Umsetzung
//Morpheus aka Apollon
//f�r LoGD.at 2006
//Gewitmet meiner �ber alles geliebten Blume
require_once("common.php");
addcommentary();
if ($session['user']['alive']){ }else{
	redirect("shades.php");
}
page_header("Der Dorfpark");
if($_GET['op']==""){
	output("`b`c`2Der Dorfpark`c`b`n");
	output("`2Du kommst durch einen kleine, steinernen Torbogen in den Dorfpark von Nollopa, der rundum ges�umt ist von hohen B�umen, durch die eine leichte Briese weht und die �ste sanft hin und her schauckelt.");
	output("Die Luft ist angenehm warm, die Wiesen sind saftig gr�n und �berall bl�hen Blumen in den sch�nsten Farben, weiter hinten kannst Du einen Bach erkennen, der sich quer durch den Park schl�ngelt und sich in einen See am Rande des Parks ergie�t.");
	output("Am blauen Firnament kannst Du kleine Feen erkennen, die ihre fr�hlichen T�nze auff�hren, w�hrend ein Chor von Bienen und Hummeln dazu eine wundervolle Melodie summt, die auch Deine Ohren verw�hnt.`n");
	output("In der Mitte der Wiese steht ein Brunnen, in dessen Mitte vier steinerne Engelsfiguren stehen, aus deren Trompeten lustig das Wasser ins Becken pl�tschert, aus dem ein Rehkitz grade seinen Durst stillt.`n");
	output("Direkt am Eingang steht ein Schild, auf dem darauf hin gewiesen wird, da� hier ein Ort des friedens, der Ruhe und Entspannung ist.");
	output("In der N�he kannst Du einige Leute sehen, die sichunterhalten:`n`n");
	viewcommentary("dorfpark","fl�stert leise:`n",25);
	addnav("Zum Brunnen","parkbrunnen.php");
	addnav("Zum Bach","dorfpark.php?op=bach");
	addnav("Zur�ck zum Dorfplatz","XXX.php");
}
if($_GET['op']=="bach"){
	output("Du gehst quer �ber die Wiese, hin�ber zu dem kleinen Bach und setzt Dich suchst Dir einen wundervollen, schattigen Platz an seinem Ufer, an dem Du Dich nieder l��t.");
	output("Seicht pl�tschert das Wasser �ber die Steine und erzaehlt Dir seine Geschichten aus fernen L�ndern, die es einst besuchte, von Riesen und Zwergen, von G�ttern und Teufeln, Geschichten von Liebe und Hass, vom Werden, Sein und Vergehen der Welt.`n");
		switch(e_rand(1,20)){
    			case 1:
    			case 2:
    			case 3:
    			case 4:
    			case 5:
    			case 6:
    			case 7:
    			case 8:
    			case 9:
    			case 10:
    			case 11:
    			case 12:
    			case 13:
    			case 14:
    			case 15:
    			case 16:
    			case 17:
			output("Du lehnst Dich zur�ck, schlie�t die Augen und lauscht and�chtig dem Pl�tschern.");
			addnav("Zur�ck zum Park","dorfpark.php");
			break;
    			case 18:
			output("Du lehnst Dich zur�ck, schlie�t die Augen, lauscht and�chtig dem Pl�tschern und beginnst zu tr�umen von wunervollen, fernen Welten.");
			output("Die tr�ume haben Dich so befl�gelt, da� Du einen Charmpunkt erh�lst.");
			$session['user']['charm']+=1;
			addnav("Zur�ck zum Park","dorfpark.php");
			break;
    			case 19:
			output("Du lehnst Dich zur�ck, schlie�t die Augen, lauscht and�chtig dem Pl�tschern und beginnst zu tr�umen von wunervollen, fernen Welten.");
			output("Die tr�ume haben Dich so befl�gelt und Du hast Dich so gut erholst, da� Du einen Charmpunkt erh�lst und Deine Lebensenergie gestiegen ist.");
			$session['user']['charm']+=1;
			($session['user']['hitpoints']*=1.1);
			addnav("Zur�ck zum Park","dorfpark.php");
			break;
    			case 20:
			output("Du lehnst Dich zur�ck, schlie�t die Augen, lauscht and�chtig dem Pl�tschern und beginnst zu tr�umen von wunervollen, fernen Welten.");
			output("Pl�tzlich springt ein Reh aus den B�schen am anderen Ufer, rennt auf Dich zu und an Dir vorbei, doch Du erschreckst Dich derart, da� Du einige Lebenspunkte verlierst.");
			if ($session['user']['hitpoints']>2){
				($session['user']['hitpoints']*=0.9);
				addnav("Zur�ck zum Park","dorfpark.php");
			}else{
				output("Dein Herz schl�gt immer schneller, bis es schlie�lich stehen bleibt.");
				$session['user']['alive']=false;
				$session['user']['hitpoints']=0;
				addnews($session['user']['name']." erschreckte sich heftigst und starb an einem Herzinfarkt.");
				addnav("T�gliche News","news.php");
			}
			break;
		}
}
page_footer();
?>