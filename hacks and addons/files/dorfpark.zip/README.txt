Dorfpark & Parkbrunnen
Idee & Umsetzung 
by Morpheus aka Apollon 2006
f�r LOGD.at
Mail to Morpheus@magic.ms or Apollon@magic.ms

INHALT: Ein kleiner Minipark f�r einen anderen Ort im Spiel, da die meisten ja doch mehr als nur das Urdorf besitzen. Der User kann in den Park gehen und sich dort unterhalten, an den Bach gehen, wo entweder nichts passiert, er ein paar LPs gewinnt oder verliert, wenn er schon wenig hatte, auch stirbt.
Er kann auch zum Brunnen gehen und dort einen Schluck trinken, und wenn er grade Lvl 5, 10 oder 14 hat stehen ihm noch andere Optionen offen...wer will kann, hier auch eine SQL Abfrage einbauen, da� er diese Optionenn nur 1x am Tag nutzen kann.

EINBAU: Wenn ihr einen zweiten Ort besitzt, einfach am Dorfplatz irgendwo verlinken, den Ortsnamen in der dorfpark.php noch �ndern und das ZUR�CK addnav noch entsprechend anpassen, beide Dateien ins Hauptverzeichnis laden, fertig!
Es k�nnen noch beliebig andere Sachen im Dorfpark verlinkt werden, so hab ich den mysthischen See dort angelegt (bei Anpera zu erhalten).