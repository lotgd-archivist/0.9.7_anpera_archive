<?php
//Idee und Umsetzung
//Morpheus aka Apollon
//f�r LoGD.at 2006
//Gewitmet meiner �ber alles geliebten Blume
require_once("common.php");
addcommentary();
if ($session['user']['alive']){ }else{
	redirect("shades.php");
}
page_header("Der Brunnen im Park");
if ($_GET[op]==""){
	output("`b`c`2Der Brunnen`c`b`n");
	output("`3Du gehst zu dem Brunnen in der Mitte der Wiese, aus dem gerade das Rehkitz trinkt, doch anstatt davon zu rennen, trinkt es in Ruhe fertig, blickt Dich an, zwinkert Dir zu und beginnt dann, sein Fell zu reinigen.");
	output("Du setzt Dich an den Brunnenrand, siehst ihm eine Weil zu und betrachtest dann den Brunnen genauer.");
	output("Die vier Engel haben alle liebliche Gesichtz�ge und einen Kranz aus Blumen auf dem Kopf und sehen so echt aus, da� Du fast ihre Trompeten h�ren kannst, doch ist es nur das sanfte pl�tschern des Wassers, da� in den Brunnen flie�t.`n");
	output("Vertr�umt lauscht Du der gleichm��igen Melodie des Wassers und entspannst Dich.`n");
	output("Auf einer Seite des Brunnens kannst Du ein Podest sehen, auf dem ein Buch und ein Stift liegen, an den Seiten des Podests h�ngen je 4 h�lzerne Becher.");
	output("Du gehst hin�ber und siehst, da� es so etwas wie ein G�stebuch ist:`n`n");
	viewcommentary("parkbrunnen","schreibt:`n",25);
	addnav("Zur�ck zum Park","dorfpark.php");
	addnav("Einen Schluck trinken","parkbrunnen.php?op=trinken");
	if ($session['user']['level']==5){
		addnav("In den Brunnen blicken","parkbrunnen.php?op=inblick");
	}
	elseif ($session['user']['level']==10){
		addnav("Die Engel genauer betrachten","parkbrunnen.php?op=engelblick");
	}
	elseif ($session['user']['level']==14){
		addnav("Das Podest untersuchen","parkbrunnen.php?op=podestblick");
	}
}
if ($_GET[op]=="trinken"){
	output("`7Du nimmst einen der Becher, f�llst ihn randvoll mit dem Wasser und trinkst.");
		switch(e_rand(1,20)){
    			case 1:
    			case 2:
    			case 3:
    			case 4:
    			case 5:
    			case 6:
    			case 7:
    			case 8:
    			case 9:
    			case 10:
    			case 11:
    			case 12:
    			case 13:
    			case 14:
    			case 15:
    			case 16:
    			case 17:
    			case 18:
			output("Das Wassser schmeckt einfach wunderbar k�hl und erfrischend.");
			addnav("Zur�ck zum Brunnen","parkbrunnen.php");
			break;
    			case 19:
			output("Das Wassser schmeckt einfach wunderbar k�hl und erfrischend, und es scheint eine besondere Wirkung zu haben, denn Du sp�rst, wie sich Deine Lebensgeister kr�ftigen.");
			($session['user']['hitpoints']*=1.1);
			addnav("Zur�ck zum Brunnen","parkbrunnen.php");
			break;
    			case 20:
			output("Das Wassser schmeckt einfach wunderbar k�hl und erfrischend, doch hast Du wohl etwas zu hastig getrunken, denn Du bekommst einen heftigen Hustanfall, der Dich einige Lebenspunkte kostet.");
			if ($session['user']['hitpoints']>2){
				($session['user']['hitpoints']*=0.9);
				addnav("Zur�ck zum Brunnen","parkbrunnen.php");
			}else{
				output("Du Hustest schlie�lich so stark, da� Du keine Luft mehr bekommst und erstickst.");
				$session['user']['alive']=false;
				$session['user']['hitpoints']=0;
				$session['user']['gold']=0;
				addnews($session['user']['name']." erstickte bei einem Hustanfall.");
				addnav("T�gliche News","news.php");
			}
			break;
		}
}
if ($_GET[op]=="inblick"){
	output("`7Du glaubst, im Brunnenwasser etwas zu erkennen, beugst Dich vor und greifst ins Wasser, wo Du etwas ertasten kannst.");
		switch(e_rand(1,2)){
    			case 1:
			output("Du ziehst die Hand wieder aus dem Wasser und haelst einen Beutel");
				switch(e_rand(1,2)){
    					case 1:
					output("mit 500 Gold in der Hand.");
					$session['user']['gold']+=500;
					break;
    					case 2:
					output("mit 2 Gems in der Hand.");
					$session['user']['gems']+=2;
					break;
				}
			addnav("Zur�ck zum Brunnen","parkbrunnen.php");
			break;
    			case 2:
			output("Als Du Deine Hand grade wieder hervor ziehen willst, merkst Du, wie Dich etwas packt und ins Wasser zieht, wo es Dich so lange unter Wasser h�lt, bis Du ertrinkst.");
				$session['user']['alive']=false;
				$session['user']['hitpoints']=0;
				$session['user']['gold']=0;
				addnews($session['user']['name']." wurde Opfer eines Wassermonsters.");
				addnav("T�gliche News","news.php");
			break;
		}
}
if ($_GET[op]=="engelblick"){
	output("`7Du betrachtest die Engelsfiguren genauer und Dir f�llt auf, da� ein von ihnen eine kleine Phiolle in der Hand h�lt.");
	output("`7Vorsichtig steigst Du durch das Wasser, nimmst die Phiole und betrachtest sie genau: der Inhalt ist ein `2g�ner `7Trank.");
	addnav("Den Inhalt trinken","parkbrunnen.php?op=etrinken");
	addnav("Den Inhalt nicht trinken","parkbrunnen.php?op=etrinken1");
}
if ($_GET[op]=="etrinken"){
	output("`7Du nimmst die Phiolle, �ffnest sie und leerst ihren Inhalt.");
		switch(e_rand(1,2)){
    			case 1:
			output("Du sp�rst, wie Dich eine Kraft durchdringt,");
				switch(e_rand(1,3)){
    					case 1:
					output("Du hast 1 permanenten Lebenspunkt dazu gewonnen.");
					$session['user']['maxhitponits']+=1;
					break;
    					case 2:
					output("Du hast 1 Angriffspunkt dazu gewonnen.");
					$session['user']['attack']+=1;
					break;
    					case 3:
					output("Du hast 1 Verteidigungspunkt dazu gewonnen.");
					$session['user']['defence']+=1;
					break;
				}
			addnav("Zur�ck zum Brunnen","parkbrunnen.php");
			break;
    			case 2:
			output("Du sp�rst, wie sich in Dir alles zusammen zieht und schnappst verzweifelt nach Luft, doch vergeblich, das Gift tut seine Wirkung....");
				$session['user']['alive']=false;
				$session['user']['hitpoints']=0;
				$session['user']['gold']=0;
            			$session['user']['experience']*0.95;
				addnews($session['user']['name']." starb an einer Vergiftung.");
				addnav("T�gliche News","news.php");
			break;
		}
}
if ($_GET[op]=="etrinken1"){
	output("`7Nein, das l��t Du doch lieber, wer wei�, was da drin ist....");
	addnav("W?Weiter","parkbrunnen.php");
}
if ($_GET[op]=="podestblick"){
	output("`7Neugierig gehst Du zu dem Poedest und betrachtest es.");
	output("`7Als Du das Buch anhebst, findest Du eine geheime Kammer, in der eine kleine Phiolle steckt, deren Inhalt eine `@gr�ne `7Fl�ssigkeit ist.");
	addnav("Den Inhalt trinken","parkbrunnen.php?op=ptrinken");
	addnav("Den Inhalt nicht trinken","parkbrunnen.php?op=ptrinken1");
}
if ($_GET[op]=="ptrinken"){
	output("`7Du nimmst die Phiolle, �ffnest sie und leerst ihren Inhalt.");
		switch(e_rand(1,2)){
    			case 1:
			output("Du sp�rst, wie Dich eine Kraft durchdringt,");
				switch(e_rand(1,3)){
    					case 1:
					output("Du hast 1 Anwendung in mysthischen Kr�ften erhalten.");
					$session[user][magicuses]++;
					break;
    					case 2:
					output("Du hast 1 Anwendung in dunklen Kr�ften erhalten.");
					$session[user][darkartuses]++;
					break;
    					case 3:
					output("Du hast 1 Anwendung in Diebesf�higkeiten erhalten.");
					$session[user][thieveryuses]++;
					break;
				}
			addnav("Zur�ck zum Brunnen","parkbrunnen.php");
			break;
    			case 2:
			output("Du sp�rst, wie sich in Dir alles zusammen zieht und schnappst verzweifelt nach Luft, doch vergeblich, das Gift tut seine Wirkung....");
				$session['user']['alive']=false;
				$session['user']['hitpoints']=0;
				$session['user']['gold']=0;
            			$session['user']['experience']*0.95;
				addnews($session['user']['name']." starb an einer Vergiftung.");
				addnav("T�gliche News","news.php");
			break;
		}
}
if ($_GET[op]=="ptrinken1"){
	output("`7Nein, das l��t Du doch lieber, wer wei�, was da drin ist....");
	addnav("W?Weiter","parkbrunnen.php");
}
page_footer();
?>
