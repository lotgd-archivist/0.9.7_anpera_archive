<? 
/***************************************
Sheriff's Office
Written by Robert for Maddnet.com LoGD
Belongs with Castle Gwen
22Feb2004
****************************************/

require_once "common.php"; 

page_header("Haus des Sheriffs"); 
output("`c<font size='+1'>`3Haus des Sheriffs</font>`c",true);
addnav("S?Zur�ck zur Stadt","village.php");

if ($session[user][drunkenness]>19)
	{
	output("`n`2Du betrittst das Haus des Sheriffs, welcher sofort bemerkt, dass Du bereits einiges getrunken hast.");
	output(" `n`n`3\"Glaubst Du nicht auch, Du hast heute etwas zuviel getrunken?");
	output(" Du l�sst mir keine Wahl, als Dich einzusperren, damit Du Deinen Rausch ausschlafen kannst,\" `2meint er achselzuckend.");
	output(" `n`n`2Er sperrt Dich in eine Zelle, in der Du einige Zeit schl�fst. Als Du erwachst, f�hlst Du Dich erholt und n�chtern.");
	$session[user][hitpoints] = $session[user][maxhitpoints];
	$session[user][drunkenness]=0;
	if ($session[user][turns]<1)
		{
		$session[user][turns]=0;
		}
	else
		{
		$session[user][turns]--;
		}
	}
else
	{
	if ($HTTP_GET_VARS[op]=="")
		{
		output(" `n`2Du betrittst das Haus des Sheriffs, in der momentan viel los ist.`n"); 
		output(" Du kannst sehen, wie ein `3Gef�ngnisw�rter `2versucht, einen wilden, betrunkenen Troll zu b�ndigen.`n"); 
		output("`nIn den Zellen sitzen einige `3Zwerge `2 und andere `3Krieger `2, die ihren Rausch ausschlafen.`n"); 
		output(" Hinter dem Tresen steht der Sheriff und bemerkt zufrieden, dass Du n�chtern bist.`n"); 
		output("`nEr fragt Dich, ob Du ein Kopfgeld, das auf Dich ausgesetzt wurde, wieder los werden m�chtest, denn"); 
		output(" wenn nicht, solltest Du schleunigst wieder gehen, da er genug zu tun hat heute.`n");
		if ($session[user][bounty]>0)
			{
			addnav("Kopfgeld aufheben"); 
			addnav("A?Aufheben - 2 Edelsteine","sheriffoffice.php?op=bounty");
			output("`n`2Der Sheriff wirft einen Blick auf die Kopfgeldliste und meint sp�ttisch: `3\"Hmmm, es ist also ein Kopfgeld von `^".$session[user][bounty]." Gold`3 auf Dich ausgesetzt, Du solltest wirklich besser auf Dich aufpassen!\"`n`n`2Er �berlegt einen Augenblick und f�gt mit fragendem Blick hinzu: `3\"Nun, ich k�nnte Dich von der Liste streichen, wenn du willst. Doch meine Dienste sind nicht umsonst, es kostet dich `#zwei Edelsteine.\"");
			}
		else
			{
			output("`n`2Der Sheriff blickt auf die Kopfgeldliste, sch�ttelt ver�rgert den Kopf und sagt mit schroffer Stimme: `3\"Auf Dich ist im Moment kein Kopfgeld ausgesetzt, also mach bitte Platz und geh wieder.\"");
			}
		}
	else if ($_GET[op]=="bounty")
		{ 
		if ($session[user][gems]>=2)
			{ 
			//$session[user][turns]--; 
			$session[user][gems]-=2;
			output("`n`2Der Sheriff gibt Dir ein Formular, das Du ausf�llst und ihm anschlie�end wieder zur�ck gibst."); 
			output(" `2Er nimmt `32 Deiner Edelsteine `2und versichert Dir, dass das Kopfgeld somit aufgehoben ist."); 
			addnews($session[user][name]." `2hat das Kopfgeld in der `3H�tte des Sheriffs `2aufheben lassen!!");
			$session[user][bounty]=0;
			debuglog("gab dem Sheriff 2 Edelsteine, um ein Kopfgeld aufheben zu lassen.");
			}
		else
			{ 
			output("`n`2Der Sheriff lacht laut auf, als er Deine leeren Taschen sieht.`3\"Mach Dich auf in den Wald und finde erst mal Edelsteine, bevor du meine Dienste in Anspruch nimmst,\" `2brummt er kopfsch�ttelnd!");
			} 
	   }
	}

page_footer();
?>
