<?php
/*
 *
 * Titeleditor by MySql
 *
 * www.arvalenzias.de/arvalenzia/index.php
 *
 * Vorraussetzung :
 * " Titel per Datenbank " by " Meteora "
 *
 *
*/
require_once 'common.php';

switch ($_GET['op'])
    {
        case '':
            page_header ('Titel-Editor');
                output('<table border=0 cellpadding=2 cellspacing=1 align="center" bgcolor="#999999">'.
                       '<tr class="trhead">'.
                       '<td>ID</td>'.
                       '<td>DK</td>'.
                       '<td>Maletitle</td>'.
                       '<td>Femaletitle</td>'.
                       '<td>Edit</td>'.
                       '<td>Loeschen</td>'.
                       '</tr>',true);
                $sql = 'SELECT * FROM titles';
                $sow = db_query($sql);

                     while ($row = db_fetch_assoc($sow))
                       {
                         output("<tr class='".($i%2?"trdark":"trlight")."'>".
                                "<td>{$row['t_id']}</td>".
                                "<td>{$row['neededdk']}</td>".
                                "<td>{$row['m_title']}</td>".
                                "<td>{$row['f_title']}</td>".
                                "<td>[<a href=\"titles.php?op=edit&title={$row['t_id']}\">Edit</a>]</td>".
                                "<td>[<a href=\"titles.php?op=dell&title={$row['t_id']}\">Loeschen</a></td>",true);
                         addnav("","titles.php?op=edit&title={$row['t_id']}");
                         addnav("","titles.php?op=dell&title={$row['t_id']}");
                       }
                         addnav('Zum Weltlichen','village.php');
                         addnav('Admin Grotte','superuser.php');
                         addnav('Titel erstellen','titles.php?op=add');


        break;
        case 'dell':
            page_header('Rase loeschen');
                $sql = "SELECT * FROM titles WHERE t_id='$_GET[title]'";
                $sow = db_query($sql);
                $row = db_fetch_assoc($sow);

                output("Du hast die [ID {$row[t_id]}] geloescht.");
                addnav('Titel auflisten','titles.php');

                $lqs = "DELETE FROM titles WHERE t_id='$_GET[title]'";
                $wos = db_query($lqs);
       break;
       case 'edit':
           page_header ('Titel Editieren');
               $sql = "SELECT * FROM titles WHERE t_id='$_GET[title]'";
               $sow = db_query($sql);
               $row = db_fetch_assoc($sow);

               output("<form action='titles.php?op=update&title={$row['t_id']}' method='post'>".
                      "<input name='neededdk' value='".$row[neededdk]."'>(DK)<br>".
                      "<input name='m_title' value='".$row[m_title]."'>(Maletitle)<br>".
                      "<input name='f_title' value='".$row[f_title]."'>(Femaletitle)<br>".
                      "<input type='submit' class='button' value='Titel editieren'>".
                      "<input type='reset' class='button' value='Eingaben zurueck setzten'>".
                      "</form>",true);
               addnav('Abbrechen','titles.php');
               addnav("","titles.php?op=update&title={$row['t_id']}");
       break;
       case 'update':
           page_header ('Titel editiert');
               $lqs = "UPDATE titles SET neededdk='".$_POST[neededdk]."',
                                           m_title='".$_POST[m_title]."',
                                           f_title='".$_POST[f_title]."'
                                     WHERE t_id='$_GET[title]'";
               db_query($lqs);
               addnav('Titel auslisten','titles.php');
               output('Titel editiert.');
       break;
       case 'add':
           page_header ('Titel erstellen');
               output("<form action='titles.php?op=save' method='post'>".
                      "<input name='neededdk' value='".$_POST[neededdk]."'>(DK)<br>".
                      "<input name='m_title' value='".$_POST[m_title]."'>(Maletitle)<br>".
                      "<input name='f_title' value='".$_POST[f_title]."'>(Femaletitle)<br>".
                      "<input type='submit' class='button' value='Titel erstellen'>".
                      "<input type='reset' class='button' value='Eingaben zurueck setzten'>".
                      "</form>",true);
               addnav('Abbrechen','titles.php');
               addnav('','titles.php?op=save');
       break;
       case 'save':
           page_header ('Titel gespeichert');
               $sql = "INSERT INTO titles (t_id, neededdk, m_title, f_title) VALUES ('','".$_POST[neededdk]."','".$_POST[m_title]."','".$_POST[f_title]."')";
               db_query($sql);
               output('Titel gespeichert.');
               addnav('Titel auslisten','titles.php');
       break;

    }
page_footer();
?>