<?php
//von Erenya

//ALTER TABLE `accounts` ADD `seenminx` tinyint(4) unsigned NOT NULL default '0';
//open newday.php und suche:
// $session ['user']['seenbard'] = 0;
//F�ge darunter ein
//$session['user']['seenminx'] = 0;

require_once("common.php");
page_header("Minx Tempel");

$hand = $session['user']['gold'];
$bank = $session['user']['goldinbank'];
$gesamt = $hand+$bank;



addnav("Weiter");
if ($gesamt<10000) addnav("Sterne deuten","Minx.php?op=deut");
addnav("Geh wieder","village.php");

output("Du betrittst das Heiligtum der Sternendeuterin Minx. Sie l�chelt, denn sie hat sich bereits erwartet. Du siehst dich um und bemerkts, das der Tempel eine magische Decke hat.");
output("Du siehst wie die Sterne dort zu jederzeit am Himmelszelt funkeln. Willst du Minx um die Deutung der Sterne bitten?");

if ($_GET[op]=="deut"){
//�session [user][seenminx] = 0;
if ($session ['user']['seenminx']){
output("`n`nMinx blickt dich an und sch�ttelt den Kopf um dir damit zu sagen, dass nur eine Deutung pro Tag m�glich ist.");
//addnav ("Zur�ck zum Dorf","village.php");
}else{
$rnd = e_rand(1,8);
output("`n`nMinx blickt herab und sieht dich genau an");
$session ['user']['seenminx']=1;
switch ($rnd){
case 1:
output("`n`n`^Minx r�t dir deine Finanzen gut zu �berwachen, als du den Tempel verl�sst, merkst du, dass du ein Loch in deinem Geldbeute hast.");
$session[user][gold]-=200;
break;
case 2:
output("`n`n`^Minx sagt dir, dass deine Zukunft gl�nzt, als du den Tempel verl�sst, findest du Yen.");
$session[user][gold]+=200;
break;
case 3:
output("`n`n`^Minx verspricht dir das du einen Schatz finden wirst, als du den Tempel verl�sst, steht vor dir eine gro�e Schatztruhe");
$session[user][gold]+=10000;
break;
case 4:
output("`n`n`^Minx erz�hlt dir das ein Stern vom Himmel fiel und dr�ckt dir einen Edelstein in die Hand.");
$session[user][gems]+=1;
break;
case 5:
output("`n`n`^ Minx ist verbl�fft dar�ber, dass sie in deinen Sternen kein klares Schicksal lesen kann und gibt dir ein paar Kisetsu Kristalle.");
$session [user][rubi]+=10;
break;
case 6:
output("`n`n`^ Minx ist verbl�fft dar�ber, dass sie in deinen Sternen kein klares Schicksal lesen kann und gibt dir ein paar Kisetsu Kristalle.");
$session [user][saphi]+=5;
break;
case 7:
output("`n`n`^ Minx ist verbl�fft dar�ber, dass sie in deinen Sternen kein klares Schicksal lesen kann und gibt dir ein paar Kisetsu Kristalle.");
$session [user][smaragd]+=10;
break;
case 8:
output("`n`n`^ Minx ist verbl�fft dar�ber, dass sie in deinen Sternen kein klares Schicksal lesen kann und gibt dir ein paar Kisetsu Kristalle.");
$session [user][rohdiamant]+=5;
break;
}
}
}

//addnav("zur�ck ins Dorf","village.php");
page_footer();

?>