<?
/*********************************************
*Diese Box darf nicht entfernt werden!       *
*-------------------------------------       *
*Brunnen from Luxx and Tarisa                *
*Idea from RPler of                          *
*www.duesterstein.de                         *
**********************************************/
require_once("common.php");
if ($session[user][locate]!=39){
	$session[user][locate]=39;
	redirect("brunnen.php");
}
   page_header("Brunnen von D�sterstein");
// This idea is from rpler from duestertein.de
// script from Luxx

if ($_GET[op]=="") {
    addcommentary();
    checkday();
    page_header("Brunnen von D�sterstein");
    output("`b`c`2Der steinernde Dorfbrunnen`0`c`b");
    output("`n`%Du kommt auf einen kleinen, von Hecken ums�umten, Platz,
    in dessen Mitte sich ein mit etwas Moos bewachsener steinerner Brunnen befindet.
    Daneben siehst Du in einer steinernen Gedenktafel. Ein paar steinerne B�nke
    laden Dich ein, etwas hier zu verweilen.`0");
	//output("`n");
    output("`n`QWas m�chtest Du machen?`0");
    output("`n`n");
	viewcommentary("brunnen","Hier reden",30,"sagt");
   
    addnav("Gehe zur Gedenktafel","brunnen.php?op=dank");
    addnav("Goldst�ck in den Brunnen werfen","brunnen.php?op=betrachte");
    addnav("Geist fordern","brunnen.php?op=spirit");
    addnav("Zur�ck zum Dorfplatz","village.php");
}
else if ($_GET[op]=="dank") {
    page_header("Die goldene Gedenktafel");
    output("`c`b`&Die Gedenktafel`0`b`c");
    output("`n`@Du n�herst dich der kleinen goldenen Gedenktafel. Je n�her du ihr kommst umso mehr erkennst du was auf ihr geschrieben steht.
    Ein paar Namen sind schon zu lesen. Du wunderst dich das an einem Brunnen solch eine Tafel angebracht ist. Mit schnellen Schrittes
    kannst du kaum erwarten die Inschriften zu lesen. Als du angekommen bist beginnst zu lesen: `n`n");
    output("`2`cGr�sse, `4".($session[user][name])."`2, diesen Brunnen erbauten:`c");
    output("`^`c`n`nS`6e`^s`6i`^o`6l`^u`6a`^g`c");
    output("`^`c`nA`6n`^n`6i`^e`c");
    output("`^`c`nV`6i`^p`6h`^e`6r`c");
    output("`^`c`nA`6y`^l`6a`^h`c");
    output("`^`c`nL`6a`^u`6r`^a`6n`^t`6e`^l`6a`c");
    output("`^`c`nL`6y`^s`6i`^a`6n`^a`c");
    output("`^`c`nY`6a`^n`6k`^a`c");
    output("`n`@Als du dich noch fragst woher der d�mmliche Brunnen deinen Namen kennt erkennst das unter der Gedenktafel noch jemand was
    in roter Schrift hingeschmiert hat: `4Wohl im Suff!!! `@Du fragst dich was das wohl heissen mag. Aber deine Neugirde bez�glich der
    Gedenktafel ist f�r heute gestillt. So setzt du deinen Weg weiter fort. `n`n");
    addnav("Zur�ck zum Platz","brunnen.php");
}
else if ($HTTP_GET_VARS[op] == "spirit"){
		if($session[user][turns] < 15){
    	output("`2Um einen Brunnengeist zu schlagen musst du schon ein wenig Zeit investieren. Das klappt nicht am Ende des Tages mal so nebenbei!!!
        Komm morgen wieder wenn du lecker gefr�hst�ckt hast und du neue Kraft gesch�pft hast.");
    	addnav("Zur�ck zum Platz","brunnen.php");
    	}else{
	    		page_header("Die Geister");
   				output("`7Du gehst zum Brunnen und sprichst einige Geheimnisvolle Formeln die du damals von der Zigeunerin aufgechnappt hast.");
   				output("Was wirklich geheimnisvoll ist wie du diese ganzen W�rter aussprechen kannst ohne einen Knoten in deine Zunge zu bekommen`n`n");
   				output("Je mehr du weiter das Ritual des Brunnen durchf�hrst...und das sieht wirklich lustig aus...�berlegst du ob es richtig ist.`n ");
   				output("Was k�nnte dir geschehen wenn wirklich ein Geist aus dem Brunnen springt. Beissen Geister? Haben geister Z�hne?`n");
   				output("Es sind nur noch wenige Formeln die zu sprechen gilt. Du �berlegst ein letztes mal");
   				addnav("weiter Formeln sprechen","brunnen.php?op=kampf");
   				addnav("Lieber aufh�ren","brunnen.php");
}
}
else if ($HTTP_GET_VARS[op] == "kampf"){
		    		page_header("Die Geister");
		    		                        switch(e_rand(1,8)){
                        case 1:
                        $session[user][turns]-=15;
$badguy = array(        "creaturename"=>"`5kleiner Wassergeist`0"
                                ,"creaturelevel"=>2
                                ,"creatureweapon"=>"Tropfenhauch"
                                ,"creatureattack"=>3
                                ,"creaturedefense"=>5
                                ,"creaturehealth"=>18
                                ,"creaturegold"=>100
                                ,"creatureexp"=>30
                                ,"diddamage"=>0);
                                $badguy[creaturehealth]+=e_rand(0,5);
                                $badguy[creatureexp]+=e_rand(1,25);
                                $badguy[creaturegold]+=e_rand(0,50);
                                $session[user][badguy]=createstring($badguy);
                                $HTTP_GET_VARS[op]="prefight";
                        break;
                        case 2:
                        $session[user][turns]-=13;
$badguy = array(        "creaturename"=>"`5Steingeist`0"
                                ,"creaturelevel"=>4
                                ,"creatureweapon"=>"Keule"
                                ,"creatureattack"=>6
                                ,"creaturedefense"=>7
                                ,"creaturehealth"=>45
                                ,"creaturegold"=>200
                                ,"creatureexp"=>75
                                ,"diddamage"=>0);
                                $badguy[creaturehealth]+=e_rand(1,7);
                                $badguy[creaturegold]+=e_rand(1,75);
                                $badguy[creatureexp]+=e_rand(1,50);
                                $session[user][badguy]=createstring($badguy);
                                $HTTP_GET_VARS[op]="prefight";
                        break;
                        case 3:
                        $session[user][turns]-=11;
$badguy = array(        "creaturename"=>"`5ausgewachsener Geisterfrosch`0"
                                ,"creaturelevel"=>7
                                ,"creatureweapon"=>"klebrige Zunge"
                                ,"creatureattack"=>12
                                ,"creaturedefense"=>14
                                ,"creaturehealth"=>69
                                ,"creaturegold"=>300
                                ,"creatureexp"=>100
                                ,"diddamage"=>0);
                                $badguy[creaturehealth]+=e_rand(0,15);
                                $badguy[creaturegold]+=e_rand(1,100);
                                $badguy[creatureexp]+=e_rand(1,75);
                                $session[user][badguy]=createstring($badguy);
                                $HTTP_GET_VARS[op]="prefight";
                        break;
                        case 4:
                        $session[user][turns]-=9;
$badguy = array(        "creaturename"=>"`5grosser Wassergeist`0"
                                ,"creaturelevel"=>8
                                ,"creatureweapon"=>"Meeresblick"
                                ,"creatureattack"=>16
                                ,"creaturedefense"=>17
                                ,"creaturehealth"=>99
                                ,"creaturegold"=>500
                                ,"creatureexp"=>125
                                ,"diddamage"=>0);
                                $badguy[creaturehealth]+=e_rand(1,15);
                                $badguy[creaturedefense]+=e_rand(1,5);
                                $badguy[creaturegold]+=e_rand(1,125);
                                $badguy[creatureexp]+=e_rand(1,100);
                                $session[user][badguy]=createstring($badguy);
                                $HTTP_GET_VARS[op]="prefight";
                        break;
                        case 5:
                        $session[user][turns]-=7;
$badguy = array(        "creaturename"=>"`5Piratengeist`0"
                                ,"creaturelevel"=>10
                                ,"creatureweapon"=>"S�bel"
                                ,"creatureattack"=>21
                                ,"creaturedefense"=>22
                                ,"creaturehealth"=>235
                                ,"creaturegold"=>600
                                ,"creatureexp"=>125
                                ,"diddamage"=>0);
                                $badguy[creaturehealth]+=e_rand(1,25);
                                $badguy[creaturedefense]+=e_rand(1,6);
                                $badguy[creaturegold]+=e_rand(1,150);
                                $badguy[creatureexp]+=e_rand(1,125);
                                $session[user][badguy]=createstring($badguy);
                                $HTTP_GET_VARS[op]="prefight";
                        break;
                        case 6:
                        $session[user][turns]-=6;
$badguy = array(        "creaturename"=>"`5Gorm der Gnom`0"
                                ,"creaturelevel"=>13
                                ,"creatureweapon"=>"Walzahn"
                                ,"creatureattack"=>25
                                ,"creaturedefense"=>29
                                ,"creaturehealth"=>245
                                ,"creaturegold"=>700
                                ,"creatureexp"=>175
                                ,"diddamage"=>0);
                                $badguy[creaturehealth]+=e_rand(1,31);
                                $badguy[creaturedefense]+=e_rand(0,5);
                                $badguy[creaturegold]+=e_rand(1,150);
                                $badguy[creatureexp]+=e_rand(1,100);
                                $session[user][badguy]=createstring($badguy);
                                $HTTP_GET_VARS[op]="prefight";
                        break;
                        case 7:
                        $session[user][turns]-=5;
$badguy = array(        "creaturename"=>"`5Luftgeist des Brunnens`0"
                                ,"creaturelevel"=>15
                                ,"creatureweapon"=>"Mundgeruch des Luftes"
                                ,"creatureattack"=>30
                                ,"creaturedefense"=>31
                                ,"creaturehealth"=>275
                                ,"creaturegold"=>750
                                ,"creatureexp"=>200
                                ,"diddamage"=>0);
                                $badguy[creatureattack]+=e_rand(1,5);
                                $badguy[creaturehealth]+=e_rand(1,50);
                                $badguy[creaturedefense]+=e_rand(1,5);
                                $badguy[creaturegold]+=e_rand(1,250);
                                $badguy[creatureexp]+=e_rand(1,200);
                                $session[user][badguy]=createstring($badguy);
                                $HTTP_GET_VARS[op]="prefight";
                        break;
                        case 8:
                        $session[user][turns]-=4;
$badguy = array(                "creaturename"=>"`5Brunnen Horror`0"
                                ,"creaturelevel"=>17
                                ,"creatureweapon"=>"t�tliche Luftschwerter*G*
                                "
                                ,"creatureattack"=>51
                                ,"creaturedefense"=>46
                                ,"creaturehealth"=>480
                                ,"creaturegold"=>500
                                ,"creatureexp"=>300
                                ,"diddamage"=>0);
                                $badguy[creatureattack]+=e_rand(1,10);
                                $badguy[creaturehealth]+=e_rand(1,75);
                                $badguy[creaturedefense]+=e_rand(1,15);
                                $badguy[creaturegold]+=e_rand(1,250);
                                $badguy[creatureexp]+=e_rand(1,200);
                                $session[user][badguy]=createstring($badguy);
                                $HTTP_GET_VARS[op]="prefight";
                         break;
  }
}
if ($HTTP_GET_VARS[op] == "prefight"){
		    page_header("Die Geister");
        output("`#Du bist beeindruckt als sich aus einer Wolke eine Shilouette bildet.`n");
        output("`#Das ist der Moment in dem du die Waffe greifst und dich kampfertig machst.`n");
        output("Der ".$badguy[creaturename]." `#bemerkt dich und st�rzt sich auf dich!`n`n");
        $HTTP_GET_VARS[op]="fight";
} 
if ($HTTP_GET_VARS[op] == "fight"){
$battle=true;
}
if ($battle){
        include_once("battle.php");
        if ($victory){

           addnews("`^".$session[user][name]."`8 hat den Brunnengeist ".$badguy[creaturename]." `8 besiegt und einen Brunnenpunkt erhalten!");
           $kaempfername=($session[user][name]);
           $session[user][brupoi]++;

             addnav("Zur�ck");
             addnav("Zur�ck zum Platz","brunnen.php");
             $badguy=array();

        }elseif ($defeat){
              addnews("`5".$session[user][name]."`8 wurde von Brunnengeist ".$badguy[creaturename]." niedergeschlagen und verliert einen Brunnenpunkt");
							if($session[user][brupoi] > 0){ $session[user][brupoi]--;}
              $session[user][hitpoints]=$session[user][maxhitpoints];
        			output("`n`^Du bist tot!");
        			output("`n`^Du verlierst all dein Gold und 55% deiner Erfahrung!");
        			output("`n`^Du verlierst alle Edelsteine, auch die auf der Bank");
        			output("`n`^Du verlierst nat�rlich auch dein Gold auf der Bank");
        			output("`n`^Du verlierst ausserdem 20 permanten Lebenspunkte");
        			output("`n`^Ach ja und du verlierst deine Waffen und nat�rlich all dein Charme");
        			output("`n`^Dein Mut setze ich gleich auf 0!"); 
        			output("`n`^Zufrieden?");
        			output("`n`2Ok war Spass, ich bin halt ein Spassvogel in Brunnengestalt. Du verlierst nur einen Brunnenpunkt");           			
              addnav("Zur�ck zum Platz","brunnen.php");
              $session[user][badguy]="";
        }else{
                        fightnav(true,false);
                        output("`n");
                        switch(e_rand(1,11)){
                        case 1:
                        output("`b".$badguy[creaturename]."`4 spricht einige geheimnisvolle Formeln.`b`n");
                        break;
                        case 2:
                        break;
                        case 3:
                        break;
                        case 4:
                        output("`b".$badguy[creaturename]."`4 macht dich nass und lacht.`b`n");
                        break;
                        case 5:
                        output("`b".$badguy[creaturename]."`4 versucht dich in den Brunnen zu schupsen!`b`n");
                        break;
                        case 6:
                        output("`b".$badguy[creaturename]."`4 versucht seine Freunde die Fr�sche zu rufen!`b`n");
                        break;
                        case 7:
                        break;
                        case 8:
                        output("`b".$badguy[creaturename]."`4 behauptet, das du aus Zucker bist und das Wasser gef�hrlich ist!`b`n");
                        break;
                        case 9:
                        output("`b".$badguy[creaturename]."`4 sagt, das deine Schn�rsenkel auf sind`b`n");
                        break;
                        case 10:
                        output("`b".$badguy[creaturename]."`4 will dich k�ssen um dich zu bet�ren`b`n");
                        break;
                        case 11:
                        break;
             			         	}
  						}
}
else if ($_GET[op]=="betrachte") {
    page_header("Der steinernde Brunnen");
    if($session[user][gold]==0){
    output("`2Du greifst in deinen Goldbeutel und `^suchst `2dann `^suchst `2du und danach `^suchst `2du und dann...man du hast kein Gold. Das wird auch nicht bei 100 mal suchen anders.
    Was k�nnte man nun tun? Genau, ab zur Bank und dein sauer verdientes Gold holen damit du das es in einen d�mmlichen Brunnen werfen kannst.");
    addnav("Zur�ck zum Platz","brunnen.php");
    }else{
	if($session[user][turns]==0){
    	output("`2Ja nat�rlich. Du hast den ganzen Tag gegen wiederliche Monster gek�mpft, Goldminen besucht, Drachen herrausgefordert, Ale getrunken und vieles mehr.
        Bist du nicht m�de? Ich glaube schon. Komm lieber wieder wenn du nicht so ersch�pft bist!");
    	addnav("Zur�ck zum Platz","brunnen.php");
    	}else{
	    if($session[user][brunnen] ==1){
       	    output("`2Du hast heute doch schon ein `6G`^o`6l`^d`6s`^t`^�`6c`^k `2in den Brunnen geworfen. Glaubst du nicht das es irgendwann mal reicht? Wom�glich wilst du dich hier
	    profilieren und allen zeigen wie reicht du bist. Aber nicht mit uns!!! Geh nach Hause und sch�m dich.");
    	    addnav("Zur�ck zum Platz","brunnen.php");
    	    }else{
        output("`n`n`2Du wirfst ein Goldst�ck in den Brunnen und wartest....`n`n");
        $session['user']['gold']--;
        $rand1 = e_rand(1,13);
        switch ($rand1){
        case 1:
            output("`^Jemand ruft von unten aus dem Brunnen: Danke du sein leichtgl�ubliges Tropf, `4".($session[user][race2])."s `^sein so d�mmlich. Ein Lachen ist zu h�ren");
            addnews("`%".$session[user][name]." `6Wurde von einem seelenlosen Brunnen reingelegt!!!");
            addnav("Zur�ck zum Platz","brunnen.php");
            $session[user][brunnen]++;
            break;
        case 2:
            output("`^Du beugst dich �ber den Brunnenrand und schaust hinunter ins Wasser. Das Gold im Brunnen glitzert so wundersch�n und verzaubert dich. `5Du bekommst einen Charmepunkt.");
	    $session[user][charm]++;
	    addnav("Zur�ck zum Platz","brunnen.php");
            $session[user][brunnen]++;
            break;
        case 3:
            output("`^Du schaust hinunter in den Brunnen dabei spiegelst du dich im Wasser. Du erschrickst vor dir selbst. `5Du verlierst einen Charmepunkt.");
	    $session[user][charm]--;
	    addnav("Zur�ck zum Platz","brunnen.php");
            $session[user][brunnen]++;            
	    break;
        case 4:
            output("`^Du beugst dich zu weit �ber den Brunnenrand und f�llst hinein. Da du nun zur�ck ins Wohnviertel musst, dir trockene Kleidung anziehen,`5vertr�delst du einen Waldkampf.");
            $session[user][turns]--;
            addnav("Zur�ck zum Platz","brunnen.php");
            $session[user][brunnen]++;            
	    break;
        case 5:
            output("`^Du schaust in den Brunnen , verlierst das Gleichgewicht und f�llst hinein. Leider kannst du nicht schwimmen und ertrinkst.");
            output("`n`5Du bist tot!");
            output("`n`5Du verlierst all dein Gold und 15% deiner Erfahrung!");
            output("`n`5Du kannst erst morgen wieder weiterk�mpfen!");
            $session[user][alive]=false;
            $session['user']['hitpoints']=0;
            $session['user']['gold'] = 0;
            $session['user']['experience'] *= 0.85;
            $session['user']['specialinc'] = '';
	    addnews("`%".$session[user][name]."`5 wollte sehen wie das Wasser im Brunnen von unten aussieht und ertrank dabei. `^Armes TukTuk");
            addnav("T�gliche News","news.php");
            $session[user][brunnen]++;
            break;
        case 6:
            output("`^Du wirfst dein Goldst�ck in den Brunnen. Es f�llt durch einen kleinen Ritz im Mauerwerk direkt zu Ramius. Weil er sich so �ber das begl�nzende Goldst�ck freut, `5schenkt er dir 10 Gefallen.");
	    $session[user][deathpower]+=10;
	    addnav("Zur�ck zum Platz","brunnen.php");
            $session[user][brunnen]++;
            break;
        case 7:
            output("`2Du wirfst ein Goldst�ck in den Brunnen, ein kleiner frecher Gnom erscheint und grinst dich an : Weil du so gro�z�gig warst, gew�hre ich dir eine Runde in der `6G`^o`6l`^d`6m`^i`6n`^e.");
	    $session[user][specialinc] = "goldmine.php";
	    addnav("Zur Goldmine","forest.php");
            $session[user][brunnen]++;
            break;
        case 8:
            output("`^Du wirfst ein Goldst�ck in den Brunnen und stellst fest,  dass es dein Gl�ckstaler war. Du versuchst vergeblich das Goldst�ck wiederzuholen. Leider musst du einsehen, dass es nicht geht und `5verlierst einen  Waldkampf.");
            $session[user][turns]--;
            addnav("Zur�ck zum Platz","brunnen.php");
            $session[user][brunnen]++;            
	    break;
        case 9:
            output("`^Du wirfst ein Goldst�ck in den Brunnen und erschreckst als ein Frosch herausspringt und das Goldst�ck vor deine F��e spuckt, doch dann beginnst du zu lachen und gehst weiter.");
            $session['user']['gold']++;
	    addnews("`%".$session[user][name]." `^bewirft kleine Fr�sche lieber mit Goldst�cken statt sie zu `4k�ssen. `^Hoffentlich meldet sich der Frosch nicht bei der Stadtwache");
    	    addnav("Zur�ck zum Platz","brunnen.php");
            $session[user][brunnen]++;           
	    break;
        case 10:
            output("`^Du wirfst eine Goldm�nze in den Brunnen, als du dich hin�berbeugst um hineinzusehen, springt ein Kobold heraus. Du verfolgst ihn und 
	    stellst ihn an der n�chsten Ecke. Dein b�ses Gesicht macht ihm Angst. Er schenkt dir `5einen Waldkampf `^und verschwindet");
            $session[user][turns]++;
            addnav("Zur�ck zum Platz","brunnen.php");
            $session[user][brunnen]++;            
	    break;
        case 11:
            output("`^ Du wirfst eine M�nze in den Brunnen, direkt in die H�nde einer Wasserfee. Du hast einen Wunsch frei. Du schliesst die Augen. Als du sie wieder �ffnest h�lst du `5einen Edelstein `^in den H�nden");
            $session['user']['gems']++;
            addnav("Zur�ck zum Platz","brunnen.php");
            $session[user][brunnen]++;
            break;
        case 12:
            output("`^Ui, das Goldst�ck f�llt aber tief... noch immer ist kein Aufprall zu h�ren. Dann h�rst Du nur ein leises 'Au', gefolgt von einem Fluchen. Wenige Augenblicke sp�ter kommt ein Stein aus dem Brunnen geflogen und
	    trifft Dich am Kopf. Sofort b�ckst Du Dich um dem Wesen im Brunnen den Stein wieder hinabzuwerfen, als Du bemerkst, da� es sich um `5einen Edelstein `^handelt");
            $session['user']['gems']++;
            addnav("Zur�ck zum Platz","brunnen.php");
            $session[user][brunnen]++;
            break;
        case 13:
            output("`^Du beugst Dich vor um dem Goldst�ck beim Fallen zuzusehen... und dabei f�llt Dein Goldbeutel gleich mit hinab. Du schliesst mit Dir eine Wette ab, da� der Goldbeutel zuerst unten ankommt --- und... Du gewinnst.
	    Leider hast Du nur mit Dir gewettet und somit hast Du nur die Gewi�heit, da� Du wieder einmal recht gehabt hast.");
    	    $session[user][gold]=0;
    	    addnav("Zur�ck zum Platz","brunnen.php");
            $session[user][brunnen]++;
            break;
				}
      }
    }
  }
}
page_footer();
?>