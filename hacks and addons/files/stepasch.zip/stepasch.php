<?php
/*
                                �@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@�
                                �                                                      �
                                �  Idee und Umsetzung                                  �
                                �  Morpheus aka Apollon                                �
                                �  2008 f�r www.Morpheus-Lotgd.de                      �
                                �  Mail to Morpheus@magic.ms or Apollon@magic.ms       �
                                �  gewidmet meiner �ber alles geliebten Blume          �
                                �                                                      �
                                @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
*/
require_once "common.php";
$name=$session['user']['name'];
checkday();
page_header("Stein Papier Schere");
if ($_GET['op']==""){
	output("`3Erfreut nichkt der Matrose und sagt:`n");
	output("`7\"Gerne spiele ich eine Runde mit Dir `%$name, `7aber nur gegen einen kleinen Einsatz, , `^10`7, `^50 `7oder `^100 Gold`7 je Runde, na, was meinst Du?\"`n");
	output("`3Du blickst ihn an und �berlegst, was Du machen willst.");
	addnav("R?Die Regeln anh�ren","stepasch.php?op=regel");
	if ($session['user']['gold']>=10){
		addnav("1?Spiele um 10 Gold","stepasch.php?op=spiel");
	}
	if ($session['user']['gold']>=50){
		addnav("5?Spiele um 50 Gold","stepasch.php?op=spiel1");
	}
	if ($session['user']['gold']>=100){
		addnav("0?Spiele um 100 Gold","stepasch.php?op=spiel2");
	}
	addnav("L?Lieber doch nicht","inn.php");
}
if ($_GET['op']=="regel"){
	output("`7\"Stein, Papier Schere ist ein sch�nes und sehr einfaches Spiel:`n`n");
	output("Jeder von uns beiden w�hlt eines aus, w�hlen wir beide das Selbe, ist es unentschieden, ansonsten gilt Stein zerbricht Schere, Schere schneidet Papier und Papier verdeckt den Stein, alles klar?\"");
	if ($session['user']['gold']>=10){
		addnav("1?Spiele um 10 Gold","stepasch.php?op=spiel");
	}
	if ($session['user']['gold']>=50){
		addnav("5?Spiele um 50 Gold","stepasch.php?op=spiel1");
	}
	if ($session['user']['gold']>=100){
		addnav("0?Spiele um 100 Gold","stepasch.php?op=spiel2");
	}
	addnav("L?Lieber doch nicht","inn.php");
}
if ($_GET[op]=="spiel"){
	output("`3Der `4Dunkelelfe`3 nickt erfreut, reibt sich die H�nde und sagt:`n`n");
	output("`7\"Nun den,`6 $name`7, dann legen wir mal los!\"`n`n");
	$es=10;
	addnav("S?Stein","stepasch.php?op=stein&es=$es");
	addnav("P?Papier","stepasch.php?op=papier&es=$es");
	addnav("e?Schere","stepasch.php?op=schere&es=$es");
}
if ($_GET[op]=="spiel1"){
	output("`3Der `4Dunkelelfe`3 nickt erfreut, reibt sich die H�nde und sagt:`n`n");
	output("`7\"Nun den,`6 $name`7, dann legen wir mal los!\"`n`n");
	$es=50;
	addnav("S?Stein","stepasch.php?op=stein&es=$es");
	addnav("P?Papier","stepasch.php?op=papier&es=$es");
	addnav("e?Schere","stepasch.php?op=schere&es=$es");
}
if ($_GET[op]=="spiel2"){
	output("`3Der `4Dunkelelfe`3 nickt erfreut, reibt sich die H�nde und sagt:`n`n");
	output("`7\"Nun den,`6 $name`7, dann legen wir mal los!\"`n`n");
	$es=100;
	addnav("S?Stein","stepasch.php?op=stein&es=$es");
	addnav("P?Papier","stepasch.php?op=papier&es=$es");
	addnav("e?Schere","stepasch.php?op=schere&es=$es");
}
if ($_GET[op]=="stein"){
	$es = (int) $_GET[es];
	output("`3Du w�hlst `7Stein `3und der Dunkelelfe w�hlt");
		switch(e_rand(1,3)){
			case 1:
			output("`7Stein`3, also ein unentschieden!");
			break;
			case 2:
			output("`&Papier`3, `&Papier `3verdeckt `7Stein`3, also hat er gesiegt, Du verlierst `6$es Gold`3!");
			$session['user']['gold']-=$es;
			break;
			case 3:
			output("`tSchere`3, `7Stein `3zerbricht `tSchere`3, also hast Du gesiegt, Du gewinnstst `6$es Gold`3!");
			$session['user']['gold']+=$es;
			break;
		}
	if ($session['user']['gold']>=10){
		addnav("1?Spiele um 10 Gold","stepasch.php?op=spiel");
	}
	if ($session['user']['gold']>=50){
		addnav("5?Spiele um 50 Gold","stepasch.php?op=spiel1");
	}
	if ($session['user']['gold']>=100){
		addnav("0?Spiele um 100 Gold","stepasch.php?op=spiel2");
	}
	addnav("L?Lieber doch nicht","inn.php");
}
if ($_GET[op]=="papier"){
	$es = (int) $_GET[es];
	output("`3Du w�hlst `&Papier `3und der Dunkelelfe w�hlt");
		switch(e_rand(1,3)){
			case 1:
			output("`7Stein`3, `&Papier `3verdeckt `7Stein`3, also hast Du gesiegt, Du gewinnstst `6$es Gold`3!");
			$session['user']['gold']+=$es;
			break;
			case 2:
			output("`&Papier`3, also ein unentschieden!");
			break;
			case 3:
			output("`tSchere`3, `tSchere `3schneidet `&Papier`3, also hat er gesiegt, Du verlierst `6$es Gold`3!");
			$session['user']['gold']-=$es;
			break;
		}
	if ($session['user']['gold']>=10){
		addnav("1?Spiele um 10 Gold","stepasch.php?op=spiel");
	}
	if ($session['user']['gold']>=50){
		addnav("5?Spiele um 50 Gold","stepasch.php?op=spiel1");
	}
	if ($session['user']['gold']>=100){
		addnav("0?Spiele um 100 Gold","stepasch.php?op=spiel2");
	}
	addnav("L?Lieber doch nicht","inn.php");
}
if ($_GET[op]=="schere"){
	$es = (int) $_GET[es];
	output("`3Du w�hlst `tSchere `3und der Dunkelelfe w�hlt");
		switch(e_rand(1,3)){
			case 1:
			output("`7Stein`3, `7Stein `3zerbricht `tSchere`3, also hat er gesiegt, Du verlierst `6$es Gold`3!");
			$session['user']['gold']-=$es;
			break;
			case 2:
			output("`&Papier`3, `tSchere `3schneidet `&Papier`3, also hast Du gesiegt, Du gewinnstst `6$es Gold`3!");
			$session['user']['gold']+=$es;
			break;
			case 3:
			output("`tSchere`3, also ein unentschieden!");
			break;
		}
	if ($session['user']['gold']>=10){
		addnav("1?Spiele um 10 Gold","stepasch.php?op=spiel");
	}
	if ($session['user']['gold']>=50){
		addnav("5?Spiele um 50 Gold","stepasch.php?op=spiel1");
	}
	if ($session['user']['gold']>=100){
		addnav("0?Spiele um 100 Gold","stepasch.php?op=spiel2");
	}
	addnav("L?Lieber doch nicht","inn.php");
}
page_footer();
?>