                                         STEIN-SCHERE-PAPIER - DAS SPIEL
                                         ===============================

                                �@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@�
                                �                                                      �
                                �  Idee und Umsetzung                                  �
                                �  Morpheus aka Apollon                                �
                                �  2008 f�r www.Morpheus-Lotgd.de                      �
                                �  Mail to Morpheus@magic.ms or Apollon@magic.ms       �
                                �  gewidmet meiner �ber alles geliebten Blume          �
                                �                                                      �
                                @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

EINBAU:
~~~~~~~

Die Datei an einem beliebigen Ort verlinken, die r�ckf�hrenden Links sind im Moment f�r die inn.php gemacht, die Datei in den Hauptordner verschieben und fertig! Die Goldwerte k�nnen von mir aus gerne ge�ndert werden, wenn Eure Spieler um mehr Gold spielen sollen, die Texte angepa�t werden, aber bitte das Copyright nicht �ndern. Stay fair!