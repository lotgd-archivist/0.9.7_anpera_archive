<?php
// Die Engelsmacherin von Yorlii Che'el  //
//von Newbi(Barra)  f�r das Kindersystem von DOM     //
//*************************

require_once "common.php";

page_header("Die Engelsmacherin");
if ($_GET['op']=="") { 

 output("`n`n`4`cDie Engelsmacherin`c`n`nDu betrittst eine dunkle Kammer, der Geruch von Tod wird �berlagert vom w�rzigen Geruch zahlloser Kr�uter und Tinkturen welche deine Aufmerksamkeit in Anspruch nehmen. `% Was...darf ich Euch bieten?`4 rauchig die alte Stimme welche zu dir spricht, Esmeralda..die Engelsmacherin ist  an dich herangetreten ohne das du es gemerkt hast. `n`nWas willst du nun tun?`n`n");
addnav("Tinktur erbitten (5 gems)","engel.php?op=tinktur");
addnav("Schnell gehen", "village.php");

}

if ($_GET['op']=="tinktur")
{
 page_header("Tinktur");
 output("`% Soso..einen Trank soll ich Dir brauen, der das Leben nimmt das in dir w�chst? Das kann ich tun, so du dir der Konsequenzen bewusst bist...");
    
            addnav("Best�tige ");
            addnav("JA","engel.php?op=engelconfirm");
   
        addnav("Nichts wie weg","village.php");
}elseif ($_GET['op']=="engelconfirm"){
       
                output("`4Du trinkst die Tinkur die Esmeralda die reicht und ein starkes Brennen breitet sich in dir aus. Mit einem Gef�hl der Desorientierung und starken Schmerzen, verl�sst du die Kammer, wissend das das Leben das in Dir wuchs, nicht mehr ist.`n`n`@Du bist nicht mehr schwanger!`n Du f�hlst dich durch diese tat unatraktiver. Du verlierst 10 Charmpunkte");
                $session['user']['ssstatus']=0;
                $session['user']['ssmonat']=0;
                $session[user][sserzeug] = 0;
		    $session[user][charm] -= 10;
		   $session[user][gems]-=5;
addnav("Weg hier","village.php");

        }
 
page_footer();
?>
        
