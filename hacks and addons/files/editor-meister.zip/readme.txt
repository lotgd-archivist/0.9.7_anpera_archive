Datei: editor-meister.php [NEU], superuser.php [EDIT], train.php [EDIT]
Beschreibung: Ermöglicht das Editieren der Meister über die Admin-Grotte
Kompatible Version: 0.9.7
Voraussetzungen: keine
Einbau-Schwierigkeit: leicht

Anleitung:
I. SQL ausführen:
ALTER TABLE `masters` ADD `picture` VARCHAR(100);
ALTER TABLE `masters` ADD `sex` TINYINT(1) DEFAULT 0;
ALTER TABLE `masters` ADD `town` TINYINT(1) DEFAULT 0;


II. train.php editieren

SUCHE:
$sql = "SELECT * FROM masters WHERE creaturelevel = ".$session[user][level];

ERSETZE MIT:
$sql = "SELECT * FROM masters WHERE town = 0 AND creaturelevel = ".$session['user']['level'];

SUCHE:
[code]$master = db_fetch_assoc($result);[/code]

DAHINTER EINFÜGEN:
[code]if ($master['picture']!="" && file_exists($master['picture'])) output("<img src='".$master['picture']."' title='' alt='' />`n",true);[/code]

Alle Stellen finden in denen von Meister die Rede ist und durch sowas wie ".($master ? "Meisterin" : "Meister")." ersetzen.

III. superuser.php editieren

SUCHE:
[code]if ($session[user][superuser]>=3) addnav("User Editor","user.php");[/code]

DAHINTER EINFÜGEN:
[code]if ($session[user][superuser]>=3) addnav("Meister-Editor","editor-meister.php"); // wer will kann das SU Level natürlich anpassen oder die Bedingung ganz rausnehmen[/code]


IV. editor-meister.php in das Root-Verzeichnis hochladen und fertig ^^

Wer möchte, kann natürlich auch noch weitere Trainingslager in anderen Dörfern / Städten / Orten anlegen und dann über den Parameter town andere Meister ziehen.
