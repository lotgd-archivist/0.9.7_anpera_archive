
                                �@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@�
                                �                                                      �
                                �  Idee und Umsetzung                                  �
                                �  Morpheus aka Apollon                                �
                                �  2008 f�r Morpheus.Lotgd(LoGD 0.9.7 +jt ext (GER) 3) �
                                �  Mail to Morpheus@magic.ms or Apollon@magic.ms       �
                                �  gewidmet meiner �ber alles geliebten Blume          �
                                �                                                      �
                                @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

Die Datei Zerberus stammt nicht von mir, wurde aber f�r das Ereignis modifiziert, Anfragen an den original Programmierer blieben leider unbeantwortet.
Die Datei mud1 ist auf die Schmuzfunktion ausgelegt, kann aber auch ohne diese genutzt werden, dann mu� nur die Zeile 

$session['user']['clean']+=5;

gel�scht bzw. mit // versehen werden, die Klasse Schmuck sollte, aufgrund des Baumhauselfen bereits existieren. Die Werte der Gems und des Goldes bzw. der Wert des Ringes darf gerne ge�ndert werden, aber bitte nicht das Copyright. Stay fair! ;) 

Einbau:
=======

Beide Ereignisse einfach in den Special Ordner verschieben.

Und nun Euch und Euren Usern viel Spa�...