<?php 
// Idee & Umsetzung
// Morpheus aka Apollon
// f�r logd.at
require_once "common.php"; 
page_header("Der Rittersaal");
addcommentary(); 
checkday();  
if ($_GET_VARS[op]==""){ 

output("`^`c`bDer Rittersaal`b`c`n"); 
output("`3Du gehst eine Treppe empor in das linke Geb�ude, die recht steil nach oben f�hrt und gelangst an eine massive `TEichent�r`3, deren T�rrahmen mit Ornamenten verziert ist."); 
output("`3Vorsichtig �ffnest Du die T�r und trittst ein in einen gro�en Saal. An den W�nden sind die `7Schilde `3m�chtiger `vKrieger `3vergangener Zeiten und `vWaffen `3zu sehen, dazwischen immer wieder `2Wandteppiche `3aus edlen `VStoffen`3, die Motive aus dem `\$Kampf `3gegen den `@GR�NEN `3zeigen.`n");
output("`3An der hinteren Wand ist ein gro�er `4Kamin`3, in dem ein `\$Feuer `3brennt und wohlige `qW�rme `3verstr�mt, `TTische `3und `TSt�hle `3stehen in U-Form zu einer gro�en `TTafel `3zusammen, an der bereits einige tapfere `vRecken `3sitzen, in der Mitte eine offene `\$Feuerstelle`3, �ber der ein gro�er `7Rost `3h�ngt, auf dem so manch Leckerei brutzelt.`n`n");
output("`gDies m��en die Reichsritter der `^G�tter `gsein `3denkst Du und verbeugst Dich ehrf�rchtig, worauf einer der `vRecken `3Dich heran winkt und Dir einen Platz an der Tafel anbietet.`n`n"); 

viewcommentary("rittersaal","Mit anderen unterhalten:",25,""); 

addnav("Zum Thronsaal","rittersaal.php?op=thron");   
addnav("Zur�ck in den Burghof","burgthetarion.php"); 
} 
if ($_GET_VARS[op]=="thron"){ 
page_header("Der Thronsaal"); 
output("`^`c`bDer Thronsaal`b`c`n"); 
output("`gEhrfurchtsvoll betrittst Du einen gro�en Saal, der pr�chtig ausgeschm�ckt ist."); 
output("An der rechten und linken Seite sind pr�chtige `\$Wandteppiche `gaus den edelsten Stoffen, die Motive aus dem `2Leben `gin unserer Welt zeigen sowie `4Kampfszenen`g. An der hinteren Seite kannst Du drei gro�e, `6pr�chtige `^Throne `gerkennen, auf denen die `^G�tter `gzu sitzen pflegen.");
output("Rechts und links dieser `6pr�chtigen `^Throne `gerkennst Du `7Waffen `gund `7R�stungen`g, wie Du sie noch nie zuvor gesehen hast und die eine unheimliche Macht ausstrahlen, die Dir in Erinnerung rufen, da� Du Dich hier im `^Thronsaal der G�tter `gbefindest.`n");
output("In der Mitte des Raumes steht ein gro�er, prachtvoll gekleideter `@Elfe `gvon muskul�ser Gestalt, der dich n�her winkt.`n`n");
output("`6H�re, oh Sterblicher, dies ist der Thronsaal der G�tter, ich bin `@Hermes`6, der Bote der G�tter.");
output("`6Wenn Du den `^G�ttern `6etwas mitzuteilen w�nscht, sei es ein Lob oder eine Kritik an unserer Welt, so kannst Du dies hier tun, ich werde Deine Worte aufschreiben und den `^G�ttern `6zutragen.`n");
output("`6Auch werden die`^ G�tter`6, oder einer der `^Ihren`6, hier Audienzen abhalten, die rechtzeitig bekannt gegeben werden, dann kannst Du es `^Ihnen `6pers�nlich mitteilen, so Du dies w�nscht.`n`n");

viewcommentary("thronsaal","Den G�ttern kund tun:",25);

addnav("Zur�ck zum Rittersaal","rittersaal.php");
if ($session[user][superuser]>=2){
addnav ("Wer ist alles on?","list.php");
} 
} 
page_footer(); 

?> 