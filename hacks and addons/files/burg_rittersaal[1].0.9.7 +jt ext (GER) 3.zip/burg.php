<?php
//Idee und Umsetzung
//Morpheus aka Apollon & Lilith
//2005 f�r logd.at(LoGD 0.9.7 +jt ext (GER) 3)
//Mail to Morpheus@magic.ms or Apollon@magic.ms
//Nicht vergessen, den Namen der eigenen Stadt ein zu f�gen, die Kommentierungen der Zeilen d�rfen gel�scht werden
//Die addnavs k�nnen beliebig erg�nzt werden, wir haben noch die Meister, das Gericht und einen Magieshop dort
require_once "common.php";
page_header("Burg XXX");
addcommentary();
if($_GET['op']==""){
output("`3`nHoch �ber XXX, auf einem m�chtigen Berg, liegt Burg XXX, der Sitz der G�tter von `6XXX `3und den umliegenden L�ndereien.`n");
output("`3Ein m�chtiges Tor, das von 2 gro�en, grimmig drein blickenden `4Trollkriegern `3bewacht wird, f�hrt in den Hof, der mit Pflastersteinen verkleidet ist.");
output("`3Die hohen Mauern der Burg scheinen un�berwindlich zu sein und der Turm scheint weit in den Himmel zu reichen, von dort mu� man einen wundervollen Blick haben.");
output("`n`n`3Neben dem Burgfried liegen, rechts und links, jeweils 2 Geb�ude, in denen verschiedene Institutionen untergebracht sind und in denen die G�tter wohnen. Auf dem Hof stehen einige Krieger und B�rger, die sich unterhalten:`n`n");
viewcommentary("burg","`3Hinzuf�gen:`0",25,"sagt");
addnav("Burg XXX");
addnav("Auf den Turm","burg.php?op=turm");
addnav("Zum Rittersaal","rittersaal.php");
addnav("In die Burgschenke","burg.php?op=schenk");
addnav("Vor dem Burgtor");
addnav("Zum Stadtplatz","village.php");
addnav("Zum Stadttor","stadttor.php");
}
if($_GET['op']=="turm")
{
	output("`3`nDu betrittst den Turm und gehst die Treppen hinauf, was sich als sehr anstrengend erweist. ");
	output("`3Du kommst an einem Fenster vorbei und der Blick nach drau�en zeigt Dir, das Du schon in enormer H�he bist, wie mu� der Blick erst von ganz oben sein.");
	switch(e_rand(1,12))
		{
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
		case 7:
		case 8:
		case 9:
		output("`n`n`3 Schlie�lich erreichst Du die Plattform und genie�t die wundervolle Aussicht, weit �ber das Dorf und den Wald.");
		output("`3 Du bleibst noch einen Moment stehen und begibst Dich dann zur�ck in den Burghof.");
		addnav("Zur�ck","burg.php");
		break;
		case 10:
		case 11:
		output("`n`n`3 Schlie�lich erreichst Du die Plattform und genie�t die wundervolle Aussicht, weit �ber das Dorf und den Wald, man kann sogar den Brunnen genau erkennen und die Blumen im Garten.`n`n");
		output("`^Das Ganze ist so inspirierend, dass Du an Charme gewinnst.");
		$session['user']['charm']+=1;
		addnav("Zur�ck","burg.php");
		break;
		case 12:
		output("`n`n`3 Fast bist Du oben, da tritst Du auf einen lockeren Stein und verlierst das Gleichgewicht.");
		output("`3 Im letzten Moment kannst Du Dich noch an einem kleinen Balken festhalten, bemerkst aber zu sp�t, dass dieser nur lose vor einem Fenster sitzt und st�rtzt den Bergfried hinab.`n`n`4Du bist tot.");
		$session['user']['alive']=false;
		$session['user']['deathpower']+=15;
		$session['user']['hitpoints']=0;
		$session['user']['gold']=0;
		$session['user']['experience']*=0.97;
		addnews($session['user']['name']." fiel sehr tief und schlug hart auf.");
		addnav("T�gliche News","news.php");
		break;
		}
}
if($_GET['op']=="schenk")
{
	page_header("Die Burgschenke");
	if($HTTP_GET_VARS['what']=="")
	{
	addnav("Zur�ck zur Burg","burg.php");
	output("`3`nAls Du die Burgschenke, einen gro�en, ger�umigen Gew�lbekeller mit Tischen und B�nken, betrittst, steigt Dir der Geruch von guten Speisen direkt in die Nase und kitzelt Deinen Gaumen. Auf der Tafel, die hinter dem Wirt an der Theke h�ngt, kannst Du folgendes lesen:`n`n");
	output("`7 SPEISEN`n`n");
	output("`6Maisbrei:`n`3Leckerer Brei aus frischem Mais, dazu frisches Obst aus dem eigenen `7Burg`2garten`3.`n`n");
	output("`qRebhuhn:`n`3Heute im `2Wald `3gejagt, gut durchgebraten, dazu frische `8Kn�del`3, auch aus eigenen Zutaten.`n`n");
	output("`TWildschwein:`n`3Wurde vorhin erst geliefert, ganz frisch und gut `tdur`qch`tgeb`qra`tten`3, dazu frisches `TBrot `3aus der Burgb�ckerei.`n`n");
	output("`7 GETR�NKE`n`n");
	output("`#Frisches Quellwasser:`n`3Direkt aus der burgeigenen `1Quelle`3, sch�n k�hl und erfrischend.`n`n");
	output("`5Traubensaft:`n`3Aus der letzten Ernte der burgeigenen `2W`5ein`2b`5erg`2e`3.`n`n");
	output("`&Frische Milch:`n`3Direkt aus den burgeigenen `TSt`4�ll`Ten`3.`n`n");
	$maiscost=$session[user][level]*11;
	$rebhuhncost=$session[user][level]*25;
	$schweincost=$session[user][level]*35;
	$wassercost=$session[user][level]*8;
	$saftcost=$session[user][level]*10;
	$milchcost=$session[user][level]*12;
	addnav("Speisen");
	addnav("`6Maisbrei `^($maiscost Gold)","burg.php?op=schenk&what=mais");
	addnav("`qRebhuhn `^($rebhuhncost Gold)","burg.php?op=schenk&what=braten");
	addnav("`TWildschwein `^($schweincost Gold)","burg.php?op=schenk&what=wild");
	addnav("Getr�nke");
	addnav("`#Quellwasser `^($wassercost Gold)","burg.php?op=schenk&what=wasser");
	addnav("`5Traubensaft `^($saftcost Gold)","burg.php?op=schenk&what=saft");
	addnav("`&Milch `^($milchcost Gold)","burg.php?op=schenk&what=milch");
	}
if($_GET['what']=="mais"){
	if ($session[user][gold] >= ($session[user][level]*11) && $session[user][turns]>0){
		switch(e_rand(1,3)){ 
			case 1:
			output("`n`3Du i�t den `6Maisbrei mit dem Obst `3voll Genu� und bis zum letzten Happen.");
			output("`3Du f�hlst dich satt und zufrieden, jetzt k�nntest glatt noch ein Monster erschlagen.`n`n"); 
			$session['user']['turns']+=1;
			$session['user']['gold']-=($session[user][level]*11);
			break;
			case 2:
			output("`n`3Du i�t den `6Maisbrei mit dem Obst `3voll Genu� und bis zum letzten Happen.");
			output("`3Du f�hlst dich satt und so voll, da� Du die Zeit f�r 1 Waldkampf verlierst.`n`n"); ; 
			$session['user']['turns']-=1; 
			$session['user']['gold']-=($session[user][level]*11);
			break;
			case 3:
			output("`n`3Du i�t den `6Maisbrei mit dem Obst `3voll Genu�.");
			output("`3Das war wirklich lecker!`n`n"); ; 
			$session['user']['gold']-=($session[user][level]*11);
			break;
		}
	}else if ($session[user][turns]<=0){
		output("`n`3 Der Wirt schaut Dich an und sagt: `#\"So kurz vor dem Schlafen solltest Du aber nichts mehr essen, das gibt nur Alptr�ume, komm morgen noch mal wieder.\"");
	}else {
		output("`n`3Der Wirt sieht Dich nur fragend an und sch�ttelt dann mit dem Kopf: `#\"Das kannst Du Dir wohl nicht leisten, mein Freund.\"");
	}
	addnav("Zur�ck","burg.php?op=schenk");
}
if($_GET['what']=="braten"){
	if ($session[user][gold] >= ($session[user][level]*25) && $session[user][turns]>0){
		switch(e_rand(1,4)){ 
			case 1:
			case 2:
			output("`n`3Du i�t das `qRebhuhn und die Kn�del `3mit Genu� und bis zum letzten Happen.");
			output("`3DU f�hlst dich satt und zufrieden, Deine Wunden beginnen zu heilen und Du k�nntest glatt noch ein Monster erschlagen.`n`n"); 
			$session['user']['turns']+=1;
			$session['user']['gold']-=($session[user][level]*25);
			$session['user']['hitpoints'] +=(2.5*($session['user']['level']));
			if ($session['user']['hitpoints'] > $session['user']['maxhitpoints']); 							$session['user']['hitpoints'] = $session['user']['maxhitpoints'];
			break;
			case 3:
			case 4:
			output("`n`3Du i�t das `qRebhuhn und die Kn�del `3mit Genu� und bis zum letzten Happen.");
			output("`3DU f�hlst dich satt und so voll, da� Du die Zeit f�r 1 Waldkampf verlierst, aber Deine Wunden beginnen zu heilen.`n`n"); ; 
			$session['user']['turns']-=1; 
			$session['user']['gold']-=($session[user][level]*25);
			$session['user']['hitpoints'] += (2.5*$session['user']['level']);
			if ($session['user']['hitpoints'] > $session['user']['maxhitpoints']); 							$session['user']['hitpoints'] = $session['user']['maxhitpoints'];
			break;
		}
	}else if ($session[user][turns]<=0){
		output("`n`3 Der Wirt schaut Dich an: \"`#So kurz vor dem Schlafen solltest Du aber nichts mehr essen, das gibt nur Alptr�ume, komm morgen noch mal wieder.\"");
	}else {
		output("`n`3Der Wirt sieht Dich nur fragend an und sch�ttelt dann mit dem Kopf: `#\"Das kannst Du Dir wohl nicht leisten, mein Freund.\"");
		}
	addnav("Zur�ck","burg.php?op=schenk");
}
if($_GET['what']=="wild"){
	if ($session[user][gold] >= ($session[user][level]*25) && $session[user][turns]>0){
		switch(e_rand(1,4)){ 
			case 1:
			output("`n`3Du i�t das `TWildschwein mit Brot `3voll Genu� und bis zum letzten Happen.");
			output("`3Du f�hlst dich satt und super gut, jetzt k�nntest Du glatt noch ein Monster erschlagen.`n`n"); 
			$session['user']['turns']+=1;
			$session['user']['gold']-=($session[user][level]*35);
			$session['user']['hitpoints'] = ($session['user']['maxhitpoints']*1.02);
			break;
			case 2:
			case 3:
			case 4:
			output("`n`3Du i�t das `TWildschwein mit Brot `3mit Genu� und bis zum letzten Happen.");
			output("`3Du f�hlst dich satt und so voll, da� Du die Zeit f�r 1 Waldkampf verlierst, aber Deine Wunden sind verheilt und Du f�hlst Dich super!`n`n"); ; 
			$session['user']['turns']-=1; 
			$session['user']['gold']-=($session[user][level]*35);
			$session['user']['hitpoints'] = ($session['user']['maxhitpoints']*=1.01);
			break;
		}
	}else if ($session[user][turns]<=0){
		output("`n`3 Der Wirt schaut Dich an: \"`#So kurz vor dem Schlafen solltest Du aber nichts mehr essen, das gibt nur Alptr�ume, komm morgen noch mal wieder.\"");
	}else {
		output("`n`3Der Wirt sieht Dich nur fragend an und sch�ttelt dann mit dem Kopf: `#\"Das kannst Du Dir wohl nicht leisten, mein Freund.\"");
	}
	addnav("Zur�ck","burg.php?op=schenk");
}
if($_GET['what']=="wasser"){
	if ($session[user][gold] >= ($session[user][level]*8) && $session[user][turns]>0){
		switch(e_rand(1,10)){ 
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
			case 6:
			case 7:
			case 8:
			output("`n`3Aaaaah, das `#Wasser `3war wirklich lecker und erfrischend!");
			$session['user']['gold']-=($session[user][level]*8);
			break;
			case 9:
			case 10:
			output("`n`3Aaaaah, das `#Wasser `3war wirklich lecker und erfrischend!");
			output("`3Du f�hlst Dich erholt und sp�rst, wie sich Deine Wunden schlie�en."); 
			$session['user']['gold']-=($session[user][level]*8);
			$session['user']['hitpoints'] += (2.5*$session['user']['level']);
			if ($session['user']['hitpoints'] > $session['user']['maxhitpoints']); 							$session['user']['hitpoints'] = $session['user']['maxhitpoints'];
			break;
		}
	}else if ($session[user][turns]<=0){
		output("`n`3 Der Wirt schaut Dich an: \"`#So kurz vor dem Schlafen solltest Du aber nichts mehr so Kaltes trinken, das gibt nur Alptr�ume, komm morgen noch mal wieder.\"");
	}else {
		output("`n`3Der Wirt sieht Dich nur fragend an und sch�ttelt dann mit dem Kopf: `#\"Das kannst Du Dir wohl nicht leisten, mein Freund.\"");
	}
	addnav("Zur�ck","burg.php?op=schenk");
}
if($_GET['what']=="saft"){
	if ($session[user][gold] >= ($session[user][level]*10) && $session[user][turns]>0){
		switch(e_rand(1,10)){ 
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
			case 6:
			case 7:
			case 8:
			output("`n`3Aaaaah, der `5Traubensaft `3war wirklich lecker und erfrischend!");
			$session['user']['gold']-=($session[user][level]*10);
			break;
			case 9:
			case 10:
			output("`n`3Aaaaah, der `5Traubensaft `3war wirklich lecker und erfrischend!");
			output("`3Deine Wunden schlie�en sich und Du f�hlst Dich super!"); 
			$session['user']['gold']-=($session[user][level]*10);
			$session['user']['hitpoints'] = ($session['user']['maxhitpoints']*=1.01);
			break;
		}
	}else if ($session[user][turns]<=0){
		output("`n`3 Der Wirt schaut Dich an: \"`#So kurz vor dem Schlafen solltest Du aber nichts mehr so Kaltes trinken, das gibt nur Alptr�ume, komm morgen noch mal wieder.\"");
	}else {
		output("`n`3Der Wirt sieht Dich nur fragend an und sch�ttelt dann mit dem Kopf: `#\"Das kannst Du Dir wohl nicht leisten, mein Freund.\"");
	}
	addnav("Zur�ck","burg.php?op=schenk");
}
if($_GET['what']=="milch"){
	if ($session[user][gold] >= ($session[user][level]*12) && $session[user][turns]>0){
		switch(e_rand(1,10)){ 
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
			case 6:
			case 7:
			case 8:
			output("`n`3Aaaaah, die `&Milch `3war wirklich lecker und erfrischend!");
			$session['user']['gold']-=($session[user][level]*12);
			break;
			case 9:
			case 10:
			output("`n`3Aaaaah, die `&Milch `3war wirklich lecker und erfrischend!");
			output("`3Du f�hlst Dich super und etwas n�chterner!"); 
			$session['user']['gold']-=($session[user][level]*12);
			$session[user][drunkenness]-=5;
			break;
		}
	}else if ($session[user][turns]<=0){
		output("`n`3 Der Wirt schaut Dich an: \"`#So kurz vor dem Schlafen solltest Du aber nichts mehr so Kaltes trinken, das gibt nur Alptr�ume, komm morgen noch mal wieder.\"");
	}else {
		output("`n`3Der Wirt sieht Dich nur fragend an und sch�ttelt dann mit dem Kopf: `#\"Das kannst Du Dir wohl nicht leisten, mein Freund.\"");
	}
	addnav("Zur�ck","burg.php?op=schenk");
}
}
page_footer();
?>
