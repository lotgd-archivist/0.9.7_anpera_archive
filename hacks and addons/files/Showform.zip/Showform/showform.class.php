<?php

class Showform {
	/**
	 *	A mod from "Basilius-Extensions"
	 *	
	 *	Basiert auf der originalen showform()-Funktion des Release 0.9.7+jt ext GER 3
	 *	Erweitert von Basilius "Wasili" Sauter
	 *
	 *	$layout-Format:
	 *		$layout = array(
	 *			fieldname => array(
	 *				0 => Text
	 *				1 =>  Typ ('text | int [...]')
	 *			
	 *			),
	 *		);
	 *
	 *	@Version: 1.0
	 */
	 
	const TABLE_DEFAULTATTRIBUT = ' border="0" cellpadding="2" cellspacing="1"';
	const VERSION = '-dev';
	
	protected $out;
	protected $save = false;
	protected $formname = '';
	
	protected $javascript = true; # Not implement yet
	
	public function __construct($formname, $layout, $row = array()) {
		$this->startForm($formname);
		$this->makeForm($layout, $row);
	}
	
	public function __destruct() {
		global $output;
		$this->endForm();
		$output .= $this->out;
	}
	
	public function enableSave() {
		$this->save = true;
	}
	
	public function disableJS() {
		$this->javascript = false;
	}
	
	public function getOut() {
		$this->endForm();
		return $this->out;
	}
	
	protected function startForm($formname) {
		$this->formname = $formname;
		$this->out = '<fieldset><legend class="h3">'.HTMLEntities($formname).'</legend>
			<table'.self::TABLE_DEFAULTATTRIBUT.'>';
	}
	
	protected function makeForm($layout, $row) {
		foreach($layout as $fieldname => $values) {
			if(is_array($values)) {
				# Felder
				switch(strtolower($values[1])) {
					case 'rpplacerange':
						$this->addRPPlacerangeLine($fieldname, $values[0], isset($row[$fieldname]) ? $row[$fieldname] : (isset($values['default']) ? $values['default'] : ''));
						break;
						
					case 'range':
					case 'from...to':
						$this->addRangeLine($fieldname, $values[0], $values[2], $values[3], isset($row[$fieldname]) ? $row[$fieldname] : (isset($values['default']) ? $values['default'] : ''));
						break;
						
					case 'textarea':
					case 'biobio':
					case 'bigtext':
					case 'iwillwritedownall':
						if(empty($values[2])) {
							$values[2] = 20;
						}
						if(empty($values[3])) {
							$values[3] = 5;
						}
						
						$this->addTextareaLine($fieldname, $values[0], $values[2], $values[3], isset($row[$fieldname]) ? $row[$fieldname] : (isset($values['default']) ? $values['default'] : ''));
						break;
						
					case 'set':
					case 'multiplichoice':
					case 'checkbox':
						$this->addSetLine($fieldname, $values[0], $values[2], ((isset($values[3]) ? $values[3] : 3)), (isset($row[$fieldname]) ? $row[$fieldname] : (isset($values['default']) ? $values['default'] : '')), (isset($values['checkbox']) ? $values['checkbox'] : false));
						break;
						
					case 'hiddenenum':
					case 'hiddenbigchoice':
						$this->addHiddenEnumLine($fieldname, $values[0], $values[2], (isset($row[$fieldname]) ? $row[$fieldname] : (isset($values['default']) ? $values['default'] : '')));
						break;
						
					case 'enum':
					case 'bigchoice':
						$this->addEnumLine($fieldname, $values[0], $values[2], (isset($row[$fieldname]) ? $row[$fieldname] : (isset($values['default']) ? $values['default'] : '')));
						break;
						
					case 'bool':
					case 'boolean':
					case 'yesorno':
					case 'nooryes':
					case 'icantdecide':
					case 'fiftypercentchance':
						$this->addBooleanLine($fieldname, $values[0], isset($row[$fieldname]) ? $row[$fieldname] : (isset($values['default']) ? $values['default'] : 0));
						break;
						
					case 'int':
					case 'integer':
					case 'zahl':
					case 'n':
						$this->addIntLine($fieldname, $values[0], isset($row[$fieldname]) ? $row[$fieldname] : (isset($values['default']) ? $values['default'] : ''));
						break;
						
					case 'hidden':
					case 'youcantseeme':
						$this->addHiddenLine($fieldname, $values[0], isset($row[$fieldname]) ? $row[$fieldname] : (isset($values['default']) ? $values['default'] : ''));
						break;
						
					case 'password':
					case 'mysecret':
					case 'thismustntseeanyone':
						$this->addPasswordLine($fieldname, $values[0]);
						break;
						
					case 'limitedtext':
						$this->addLimitedTextLine($fieldname, $values[0], $values[2], isset($row[$fieldname]) ? $row[$fieldname] : (isset($values['default']) ? $values['default'] : ''));
						break;
					
					case 'text':
					default:
						$this->addTextLine($fieldname, $values[0], isset($row[$fieldname]) ? $row[$fieldname] : (isset($values['default']) ? $values['default'] : ''));
						break;
				}
			}
			else {
				# �berschriften
				$this->out .= '<tr class="trhead">
					<th colspan="2">'.$values.'</th>
				</tr>';
			}
		}
	}
	
	protected function addTextLine($fieldname, $text, $value) {
		$id = $this->getRandomUID();
		$this->out .= '<tr>
			<td><label for="'.$id.'">'.HTMLEntities($text).'</label></td>
			<td><input id="'.$id.'" type="text" name="'.HTMLEntities($fieldname).'" value="'.HTMLEntities($value).'" size="50" /></td>
		</tr>';
	}
	
	protected function addLimitedTextLine($fieldname, $text, $maxlenght, $value) {
		$id = $this->getRandomUID();
		$this->out .= '<tr>
			<td><label for="'.$id.'">'.HTMLEntities($text).'</label></td>
			<td><input id="'.$id.'" type="text" name="'.HTMLEntities($fieldname).'" value="'.HTMLEntities($value).'" size="50" maxlength="'.$maxlenght.'" /></td>
		</tr>';
	}
	
	protected function addPasswordLine($fieldname, $text) {
		$id = $this->getRandomUID();
		$this->out .= '<tr>
			<td><label for="'.$id.'">'.HTMLEntities($text).'</label></td>
			<td><input id="'.$id.'" type="password" name="'.HTMLEntities($fieldname).'" size="50" /></td>
		</tr>';
	}
	
	protected function addHiddenLine($fieldname, $text, $value) {
		$id = $this->getRandomUID();
		$this->out .= '<tr>
			<td><label for="'.$id.'">'.HTMLEntities($text).'</label></td>
			<td>
				<div id="'.$id.'">'.HTMLEntities($value).'</div>
			</td>
		</tr>';
	}
	
	protected function addIntLine($fieldname, $text, $value) {
		$id = $this->getRandomUID();
		$this->out .= '<tr>
			<td><label for="'.$id.'">'.HTMLEntities($text).'</label></td>
			<td><input id="'.$id.'" type="text" name="'.HTMLEntities($fieldname).'" value="'.HTMLEntities($value).'" size="5" /></td>
		</tr>';
	}
	
	protected function addBooleanLine($fieldname, $text, $value) {
		$id = $this->getRandomUID();
		$this->out .= '<tr>
			<td><label for="'.$id.'">'.HTMLEntities($text).'</label></td>
			<td><select id="'.$id.'" name="'.HTMLEntities($fieldname).'" size="1">
				<option value="0" '.($value == 0 ? 'selected="selected"' : '').'>Nein</option>
				<option value="1" '.($value == 1 ? 'selected="selected"' : '').'>Ja</option>
			</select></td>
		</tr>';
	}
	
	protected function addEnumLine($fieldname, $text, $options, $value) {
		$id = $this->getRandomUID();
		$this->out .= '<tr>
			<td><label for="'.$id.'">'.HTMLEntities($text).'</label></td>
			<td><select id="'.$id.'" name="'.HTMLEntities($fieldname).'" size="1">
		';
				
		foreach($options as $optval => $optdesc) {
			$this->out .= '<option value="'.$optval.'" '.($optval == $value ? 'selected="selected"' : '').'>'.$optdesc.'</option>';
		}
		$this->out .= '	</select></td>
		</tr>';
	}
	
	protected function addHiddenEnumLine($fieldname, $text, $options, $value) {
		$id = $this->getRandomUID();
		$this->out .= '<tr>
			<td><label for="'.$id.'">'.HTMLEntities($text).'</label></td>
			<td><div id="'.$id.'">'.$options[$value].'</div></td>
		</tr>';
	}
	
	protected function addSetLine($fieldname, $text, $options, $size, $value, $checkbox) {
		$id = $this->getRandomUID();
		if($checkbox === false) {
			$this->out .= '<tr>
				<td><label for="'.$id.'">'.HTMLEntities($text).'</label></td>
				<td><select id="'.$id.'" name="'.HTMLEntities($fieldname).'" size="'.$size.'" multiple="multiple">
			';
					
			foreach($options as $optval => $optdesc) {
				$this->out .= '<option value="'.$optval.'" '.($optval == $value ? 'selected="selected"' : '').'>'.$optdesc.'</option>';
			}
			$this->out .= '	</select></td>
			</tr>';
		}
		else {
			$this->out .= '<tr>
				<td><label for="'.$id.'">'.HTMLEntities($text).'</label></td>
				<td><div id="'.$id.'">
			';
					
			foreach($options as $optval => $optdesc) {
				$this->out .= '<div><input type="checkbox" name="'.HTMLEntities($fieldname).'" value="'.$optval.'" '.($optval == $value ? 'checked="checked"' : '').' />'.$optdesc.'</div>';
			}
			$this->out .= '	</div></td>
			</tr>';
		}
	}
	
	protected function addTextareaLine($fieldname, $text, $cols, $rows, $value) {
		$id = $this->getRandomUID();
		$this->out .= '<tr style="vertical-align: top" >
			<td><label for="'.$id.'">'.HTMLEntities($text).'</label></td>
			<td><textarea id="'.$id.'" cols="'.$cols.'" rows="'.$rows.'" name="'.HTMLEntities($fieldname).'" >'.HTMLEntities($value).'</textarea></td>
		</tr>';
	}
	
	protected function addRangeLine($fieldname, $text, $from, $to, $value) {
		$id = $this->getRandomUID();
		$this->out .= '<tr>
			<td><label for="'.$id.'">'.HTMLEntities($text).'</label></td>
			<td><select id="'.$id.'" name="'.HTMLEntities($fieldname).'" size="1">
		';
		
		for($i = $from; $i<=$to; $i++) {
			$this->out .= '<option value="'.$i.'" '.($i == $value ? 'selected="selected"' : '').'>'.$i.'</option>';
		}
		
		$this->out .= '	</select></td>
		</tr>';
	}
	
	protected function addRPPlacerangeLine($fieldname, $text, $value) {
		$id = $this->getRandomUID();
		$this->out .= '<tr>
			<td><label for="'.$id.'">'.HTMLEntities($text).'</label></td>
			<td><select id="'.$id.'" name="'.HTMLEntities($fieldname).'" size="1">
		';
		
		$res = db_query('SELECT placeid, placename, villagename FROM `er_rpplaces`');
		if(db_num_rows($res) > 0) {
			while($row = db_fetch_assoc($res))  {
				$this->out .= '<option value="'.$row['placeid'].'" '.($row['placeid'] == $value ? 'selected="selected"' : '').'>'.$row['placename'].' ('.$row['villagename'].')</option>';
			}
		}
		else {
			$this->out .= '<option value="0" selected="selected"> Keine Pl�tze vorhanden? </option>';
		}
		
		$this->out .= '	</select></td>
		</tr>';
	}
	
	protected function addSaveButton() {
		$id = $this->getRandomUID();
		$this->out .= '<tr>
			<td><label for="'.$id.'">Speichern</label></td>
			<td><input id="'.$id.'" type="submit" value="Best�tigen" class="button" /></td>
		</tr>';
	}
	
	protected function endForm() {
		if($this->save === true) {
			$this->addSaveButton();		
		}
		$this->out .= '</table>
		</fieldset>';
	}
	
	protected function getRandomUID() {
		return 'x'.sha1(microtime());
	}
}
?>