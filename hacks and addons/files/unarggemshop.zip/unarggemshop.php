<?php
require_once "common.php";
//      Edelsteinschleiferei      \\
//    By Hadriel | 2005|03|11     \\
//       Idea by Eliwood          \\

//--------------------------------\\
//         INSTALLATION           \\
/*

open prefs.php
search:
$sql = "SELECT * FROM items WHERE owner=".$session[user][acctid]." AND (class='Schmuck') ORDER BY $_GET[sorti] AND class ASC LIMIT $limit";
replace:
$sql = "SELECT * FROM items WHERE owner=".$session[user][acctid]." AND (class='Schmuck') AND (class='Edelstein') ORDER BY $_GET[sorti] AND class ASC LIMIT $limit";

search:
addnav("Schmuck","prefs.php?op=items2");
replace:
addnav("Schmuck und Edelsteine","prefs.php?op=items2");

_______________

open dragon.php
search:
$sql = "DELETE FROM pvp WHERE acctid1=".$session[user][acctid]." OR acctid2=".$session[user][acctid];
    db_query($sql) or die(db_error(LINK));
add after:
    $sql = "DELETE FROM items WHERE class='Edelstein' AND owner='".$session[user][acctid]."'";
    db_query($sql) or die(db_error(LINK));

open forest.php
search:
if ($findit == 2) { //gem
...
}
replace it with:

//Gem addon, Hadriel
if ($findit == 2) { //gem
            output("`&Du findest EINEN ROHDIAMANTEN!`n`#");
               db_query("INSERT INTO items(name,class,owner,gold,gems,description) VALUES ('Rohdiamant','Edelstein',".$session[user][acctid].",1,0,'Ein kleiner, weiss leuchtender Rohdiamant')");
              
        }
		if ($findit == 18 && e_rand(1,24)==2) { //gem2
		output("`&Du findest EINEN AMETHYSTEN!`n`#");
               db_query("INSERT INTO items(name,class,owner,gold,gems,description) VALUES ('Amethyst','Edelstein',".$session[user][acctid].",1,0,'Ein kleiner, blau leuchtender Amethist')");
            
		}
		if ($findit == 19 && e_rand(1,16)==2) { //gem3
				output("`&Du findest EINEN RUBIN!`n`#");
               db_query("INSERT INTO items(name,class,owner,gold,gems,description) VALUES ('Rubin','Edelstein',".$session[user][acctid].",1,0,'Ein kleiner, rot leuchtender Rubin')");
        
		}
		if ($findit == 17 && e_rand(1,8)==2) { //gem4
				output("`&Du findest EINEN TOPAS!`n`#");
               db_query("INSERT INTO items(name,class,owner,gold,gems,description) VALUES ('Topas','Edelstein',".$session[user][acctid].",1,0,'Ein kleiner, gelb leuchtender Topas')");
      
		}
		//END

_______________

open /logd/special/*.php
search:
%output("Du findest einen Edelstein!");% <--- In etwa dieser Satz!
$session[user][gems]++;

replace it with:

output("`&Du findest einen Rohdiamanten!`n`#");
               db_query("INSERT INTO items(name,class,owner,gold,gems,description) VALUES ('Rohdiamant','Edelstein',".$session[user][acctid].",1,0,'Ein kleiner Rohdiamant')");
			   
_______________
			   
open /logd/*.php
search:
%output("Du bekommst einen Edelstein!");% <--- In etwa dieser Satz!
$session[user][gems]++;

replace it with:

output("`&Du bekommst einen Rohdiamanten!`n`#");
               db_query("INSERT INTO items(name,class,owner,gold,gems,description) VALUES ('Rohdiamant','Edelstein',".$session[user][acctid].",1,0,'Ein kleiner Rohdiamant')");
*/
//---------------------------------\\
//            SETTINGS             \\

$infos=array(
"owner"=>"Unargs Edelsteinschleiferei", 
"file" => "".basename(__FILE__),
"version"=> "2.0",
"homepg"=> "http://www.hadrielnet.ch",
"text" => "`2Du betrittst einen kleinen, mit `%Edelsteinen`2, `^Topasen`2, `4Rubinen `2und `!Amethysten `2geschm�ckten Laden. Auf einem kleinen Hinweisschild steht:`^ Unargs Edelsteinschleiferei`2.`nUnarg selbst, als bester Edelsteinhersteller des Landes bekannt, sitzt an seinem Schleiftisch und bereitet ein paar Edelsteine her.`nAls er dich bemerkt, fragt er: \"`qSei gegr�sst, ".$session[user][name]."`q! Kann ich etwas f�r dich tun?`2\"",
"creator" => "Hadriel"
);
//\\
$gempriced=3000; //Small price
$gempricet=4500;
$gempricer=6000;
$gempricea=7500; //Big price
//---------------------------------\\
$resd=db_query("SELECT count(id) AS c FROM `items` WHERE `name`='Rohdiamant' AND `owner`='".$session[user][acctid]."' GROUP BY id");
for($i=0;$i<db_num_rows($resd);$i++){
$row = db_fetch_assoc($resr);
}
if($row['c']=="") $row['c']=0;
$rest=db_query("SELECT count(id) AS c1 FROM `items` WHERE `name`='Topas' AND `owner`='".$session[user][acctid]."' GROUP BY id");
for($i=0;$i<db_num_rows($rest);$i++){
$row1 = db_fetch_assoc($rest);
}
if($row1['c1']=="") $row1['c1']=0;
$resr=db_query("SELECT count(id) AS c2 FROM `items` WHERE `name`='Rubin' AND `owner`='".$session[user][acctid]."' GROUP BY id");
for($i=0;$i<db_num_rows($resr);$i++){
$row2 = db_fetch_assoc($resr);
}
if($row2['c2']=="") $row2['c2']=0;
$resa=db_query("SELECT count(id) AS c3 FROM `items` WHERE `name`='Amethyst' AND `owner`='".$session[user][acctid]."' GROUP BY id");
for($i=0;$i<db_num_rows($resa);$i++){
$row3 = db_fetch_assoc($resa);
}
if($row3['c3']=="") $row3['c3']=0;
page_header("".$infos[owner]."");
if($_GET[op]==""){
output("".$infos[text]."");
output("`n`2Du hast `#".$row['c']." Rohdiamant(en)`2, `^".$row1['c1']." Topas(e)`2 , `4".$row2['c2']." Rubin(e)`2 und `!".$row3['c3']." Amethyst(en)`2 bei dir");
$res=db_query("SELECT id FROM items WHERE name='Rohdiamant' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelstein aus Rohdiamant herstellen (".$gempriced." Gold)","".$infos['file']."?op=diam&id=".$row[id]."");
}
$res=db_query("SELECT id FROM items WHERE name='Topas' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelsteine aus Topas herstellen (".$gempricet." Gold)","".$infos['file']."?op=topa&id=".$row[id]."");
}
$res=db_query("SELECT id FROM items WHERE name='Rubin' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelsteine aus Rubin herstellen (".$gempricer." Gold)","".$infos['file']."?op=ruby&id=".$row[id]."");
}
$res=db_query("SELECT id FROM items WHERE name='Amethyst' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelsteine aus Amethyst herstellen (".$gempricea." Gold)","".$infos['file']."?op=amet&id=".$row[id]."");
}
addnav("Zur�ck ins Dorf","village.php");
}
if($_GET[op]=="diam"){
if($session[user][gold]>$gempriced){
output("`n`n`2Du l�sst dir einen deiner Rohdiamanten in einen Edelstein 'verwandeln'");
$session[user][gold]-=$gempriced;
$session[user][gems]++;
db_query("DELETE FROM items WHERE id='".$_GET[id]."'");
$res=db_query("SELECT id FROM items WHERE name='Rohdiamant' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelstein aus Rohdiamant herstellen (".$gempriced." Gold)","".$infos['file']."?op=diam&id=".$row[id]."");
}
$res=db_query("SELECT id FROM items WHERE name='Topas' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelsteine aus Topas herstellen (".$gempricet." Gold)","".$infos['file']."?op=topa&id=".$row[id]."");
}
$res=db_query("SELECT id FROM items WHERE name='Rubin' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelsteine aus Rubin herstellen (".$gempricer." Gold)","".$infos['file']."?op=ruby&id=".$row[id]."");
}
$res=db_query("SELECT id FROM items WHERE name='Amethyst' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelsteine aus Amethyst herstellen (".$gempricea." Gold)","".$infos['file']."?op=amet&id=".$row[id]."");
}
addnav("Zur�ck zum Dorf","village.php");
}else{
output("`n`n`2Unarg sieht dich w�tend an: \"`qDu elender Wicht! Nicht mal genug Gold f�r meine Arbeit!`2\"");
$res=db_query("SELECT id FROM items WHERE name='Rohdiamant' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelstein aus Rohdiamant herstellen (".$gempriced." Gold)","".$infos['file']."?op=diam&id=".$row[id]."");
}
$res=db_query("SELECT id FROM items WHERE name='Topas' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelsteine aus Topas herstellen (".$gempricet." Gold)","".$infos['file']."?op=topa&id=".$row[id]."");
}
$res=db_query("SELECT id FROM items WHERE name='Rubin' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelsteine aus Rubin herstellen (".$gempricer." Gold)","".$infos['file']."?op=ruby&id=".$row[id]."");
}
$res=db_query("SELECT id FROM items WHERE name='Amethyst' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelsteine aus Amethyst herstellen (".$gempricea." Gold)","".$infos['file']."?op=amet&id=".$row[id]."");
}
addnav("Zur�ck zum Dorf","village.php");
}
}
if($_GET[op]=="topa"){
if($session[user][gold]>$gempricet){
output("`n`n`2Du l�sst dir einen deiner Topase in zwei Edelsteine 'verwandeln'");
$session[user][gold]-=$gempricet;
$session[user][gems]+=2;
db_query("DELETE FROM items WHERE id='".$_GET[id]."'");
$res=db_query("SELECT id FROM items WHERE name='Rohdiamant' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelstein aus Rohdiamant herstellen (".$gempriced." Gold)","".$infos['file']."?op=diam&id=".$row[id]."");
}
$res=db_query("SELECT id FROM items WHERE name='Topas' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelsteine aus Topas herstellen (".$gempricet." Gold)","".$infos['file']."?op=topa&id=".$row[id]."");
}
$res=db_query("SELECT id FROM items WHERE name='Rubin' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelsteine aus Rubin herstellen (".$gempricer." Gold)","".$infos['file']."?op=ruby&id=".$row[id]."");
}
$res=db_query("SELECT id FROM items WHERE name='Amethyst' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelsteine aus Amethyst herstellen (".$gempricea." Gold)","".$infos['file']."?op=amet&id=".$row[id]."");
}
addnav("Zur�ck zum Dorf","village.php");
}else{
output("`n`n`2Unarg sieht dich w�tend an: \"`qDu elender Wicht! Nicht mal genug Gold f�r meine Arbeit!`2\"");
$res=db_query("SELECT id FROM items WHERE name='Rohdiamant' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelstein aus Rohdiamant herstellen (".$gempriced." Gold)","".$infos['file']."?op=diam&id=".$row[id]."");
}
$res=db_query("SELECT id FROM items WHERE name='Topas' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelsteine aus Topas herstellen (".$gempricet." Gold)","".$infos['file']."?op=topa&id=".$row[id]."");
}
$res=db_query("SELECT id FROM items WHERE name='Rubin' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelsteine aus Rubin herstellen (".$gempricer." Gold)","".$infos['file']."?op=ruby&id=".$row[id]."");
}
$res=db_query("SELECT id FROM items WHERE name='Amethyst' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelsteine aus Amethyst herstellen (".$gempricea." Gold)","".$infos['file']."?op=amet&id=".$row[id]."");
}
addnav("Zur�ck zum Dorf","village.php");
}
}
if($_GET[op]=="ruby"){
if($session[user][gold]>$gempricer){
output("`n`n`2Du l�sst dir einen deiner Rubine in drei Edelsteine 'verwandeln'");
$session[user][gold]-=$gempricer;
$session[user][gems]+=3;
db_query("DELETE FROM items WHERE id='".$_GET[id]."'");
$res=db_query("SELECT id FROM items WHERE name='Rohdiamant' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelstein aus Rohdiamant herstellen (".$gempriced." Gold)","".$infos['file']."?op=diam&id=".$row[id]."");
}
$res=db_query("SELECT id FROM items WHERE name='Topas' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelsteine aus Topas herstellen (".$gempricet." Gold)","".$infos['file']."?op=topa&id=".$row[id]."");
}
$res=db_query("SELECT id FROM items WHERE name='Rubin' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelsteine aus Rubin herstellen (".$gempricer." Gold)","".$infos['file']."?op=ruby&id=".$row[id]."");
}
$res=db_query("SELECT id FROM items WHERE name='Amethyst' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelsteine aus Amethyst herstellen (".$gempricea." Gold)","".$infos['file']."?op=amet&id=".$row[id]."");
}
addnav("Zur�ck zum Dorf","village.php");
}else{
output("`n`n`2Unarg sieht dich w�tend an: \"`qDu elender Wicht! Nicht mal genug Gold f�r meine Arbeit!`2\"");
$res=db_query("SELECT id FROM items WHERE name='Rohdiamant' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelstein aus Rohdiamant herstellen (".$gempriced." Gold)","".$infos['file']."?op=diam&id=".$row[id]."");
}
$res=db_query("SELECT id FROM items WHERE name='Topas' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelsteine aus Topas herstellen (".$gempricet." Gold)","".$infos['file']."?op=topa&id=".$row[id]."");
}
$res=db_query("SELECT id FROM items WHERE name='Rubin' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelsteine aus Rubin herstellen (".$gempricer." Gold)","".$infos['file']."?op=ruby&id=".$row[id]."");
}
$res=db_query("SELECT id FROM items WHERE name='Amethyst' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelsteine aus Amethyst herstellen (".$gempricea." Gold)","".$infos['file']."?op=amet&id=".$row[id]."");
}
addnav("Zur�ck zum Dorf","village.php");
}
}
if($_GET[op]=="amet"){
if($session[user][gold]>$gempricea){
output("`n`n`2Du l�sst dir einen deiner Amethyste in vier Edelsteine 'verwandeln'");
$session[user][gold]-=$gempricea;
$session[user][gems]+=4;
db_query("DELETE FROM items WHERE id='".$_GET[id]."'");
$res=db_query("SELECT id FROM items WHERE name='Rohdiamant' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelstein aus Rohdiamant herstellen (".$gempriced." Gold)","".$infos['file']."?op=diam&id=".$row[id]."");
}
$res=db_query("SELECT id FROM items WHERE name='Topas' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelsteine aus Topas herstellen (".$gempricet." Gold)","".$infos['file']."?op=topa&id=".$row[id]."");
}
$res=db_query("SELECT id FROM items WHERE name='Rubin' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelsteine aus Rubin herstellen (".$gempricer." Gold)","".$infos['file']."?op=ruby&id=".$row[id]."");
}
$res=db_query("SELECT id FROM items WHERE name='Amethyst' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelsteine aus Amethyst herstellen (".$gempricea." Gold)","".$infos['file']."?op=amet&id=".$row[id]."");
}
addnav("Zur�ck zum Dorf","village.php");
}else{
output("`n`n`2Unarg sieht dich w�tend an: \"`qDu elender Wicht! Nicht mal genug Gold f�r meine Arbeit!`2\"");
$res=db_query("SELECT id FROM items WHERE name='Rohdiamant' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelstein aus Rohdiamant herstellen (".$gempriced." Gold)","".$infos['file']."?op=diam&id=".$row[id]."");
}
$res=db_query("SELECT id FROM items WHERE name='Topas' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelsteine aus Topas herstellen (".$gempricet." Gold)","".$infos['file']."?op=topa&id=".$row[id]."");
}
$res=db_query("SELECT id FROM items WHERE name='Rubin' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelsteine aus Rubin herstellen (".$gempricer." Gold)","".$infos['file']."?op=ruby&id=".$row[id]."");
}
$res=db_query("SELECT id FROM items WHERE name='Amethyst' AND owner='".$session[user][acctid]."'");
if(db_num_rows($res)>0){
$row=db_fetch_assoc($res);
addnav("Edelsteine aus Amethyst herstellen (".$gempricea." Gold)","".$infos['file']."?op=amet&id=".$row[id]."");
}
addnav("Zur�ck zum Dorf","village.php");
}
}
//COPYRIGHT, DON'T REMOVE!
output("`n`n`n`n`n ".$infos['name']." Version ".$infos['version']." by <a href='".$infos['homepg']."' target='_blank'>".$infos['creator']."</a>`n`n",true);
//COPYRIGHT, DON'T REMOVE!
page_footer();
?>