<?php

/*
* Jenova
* written by Squall
* www.omega-grotte.de
* THX on Tidus f�r die Abfrage
* ALTER TABLE `accounts` ADD `jenova` INT(5) NOT NULL DEFAULT '0'
* und in die newday.php $session['user']['jenova']=0; 
*/
require_once "common.php";
page_header("Jenova");
output('`c`b&copy; by <a href="http://www.omega-grotte.de" target="_blank">Squall</a>`b`c',true);
if($_GET['op']==""){
if ($session['user']['jenova']>=1){
output ("`SDu warst heute schon hier, verschwinde du Wurm!!!");
addnav("Zur�ck","ooc..php");
}else{
output("`c`n<img src='images/pro-jenova.jpg' width='272' height='270'>`c`n",true);
output("`n`c`b`9Jenovas Gruft der Schmerzen`b`c`n`n");
output("`&Du l�ufts durch den Geheimgang des OOC-Raumes und landest in einem dunklen Raum, kein Ton ist zuh�ren, nur wenige Lichtstrahlen sind zu erblicken, und nur ein kleiner Windzug, der dir um die Nase wedelt, ist zu sp�hren. Etwas angespannt von dieser Situation, l�ufst du den Windzug entgegen und erblickst nach einigen Metern vor dir eine gigantische Plasmah�lle, in Ihr liegt etwas komisches, es scheint, etwas gro�es und blaues zu sein, man k�nnte annehmen, es w�re weiblich. Solch eine Kreatur hast du noch nie in deinem Leben gesehen, ganz versteinert schauts du diese Kreatur an und glaubst, dass sie schon l�ngst Tot seie! Doch pl�tzlich �ffnet sie Ihre Augen und meint: `#Welcome Reisender, was verschafft mir die Ehre, deines Besuches, m�chtest du deine Mutter besuchen kommen oder warum bist du hier? `&Etwas starr vor Schrecken murmelst du nur einige unverst�ndliche Worte zu Ihr. `#Komm zu deiner Mutter und helf Ihr aus diesem Gef�ngniss, w�rdest du das tun? `&Du blickst sie verbl�fft an und �berlegts ob du sie befreien sollest oder nicht.`n`n`n");
    output("<a href='jenova.php?op=do'>Ja, ich helf Ihr.</a>`n`n",true);
    output("<a href='jenova.php?op=dont'>Nein, das ist mir zu riskant.</a>`n`n",true);
    addnav("","jenova.php?op=do");
    addnav("","jenova.php?op=dont");
    addnav("Helfen","jenova.php?op=do");
    addnav("Wegrennen","jenova.php?op=dont");
 }
}
if ($_GET['op']=="dont") {
output("Du hast zu grosse Angst Jenova zu helfen und rennst weg.");
addnav("Zur�ck","ooc..php");

}
if ($_GET['op']=="do") {
    output("`&Jenova murmelt etwas und scheint erfreut �ber deine Entscheidung zu sein. Du �ffnest die Plasmah�lle, Jenova steigt empor und meint: `#Du hast mich befreit und sollst belohnt werden, hier nimm diese seltende schwarze Substanz von mir, was sie bringt, das w�rdst du gleich herraus finden! MUHAAAAAAAA!! `&Jenova rennt lachend weg und du schaust dir das Geschenk genauer an.`n`n");

    output("`7Du r�ttels an der schwarzen Substanz und sie zerbricht dabei.");
        switch(e_rand(1,9)){
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':

            output("Du erh�lts einen Segen.");
            $session['user']['reputation']-=30;
            $buff = array("name"=>"`SZerbrochene Substanz`^","roundmsg"=>"`SDie zerbrochene Substanz steigert deine Kampfesfertigkeiten.","wearoff"=>"`SDie Aura verl�sst dich.","effectmsg" => "`SDie Aura verschafft dir einen Vorteil ","rounds"=>"50","atkmod"=>"1.3","defmod"=>"1.3","activate"=>"defense");
$session['bufflist']['dickefinger']=$buff;
$session['user']['jenova']=1;
            addnews($session['user']['name']."`S erhielt den Segen der legend�ren, schwarzen Substanz.");
            addnav("Verschwinden","ooc..php");
            break;
                case '6':
            output("Du bekommst die Macht der schwarzen Substanz zu sp�hren und der Raum, um dir herum, wird immer kleiner und kleiner, bist du den Ausgang finden konntest, wurdest du bereits zerquetscht.");
            $session['user']['alive']=false;
            $session['user']['hitpoints']=0;
            $session['user']['gold']=0;
            $session['user']['reputation']-=30;
            addnews($session['user']['name']."`S bekam die Macht der schwarzen Substanz zu sp�hren und wurde zerquetscht aufgefunden.");
            addnav("Nachrichtensender","news.php");
            $session['user']['jenova']=1;
            break;
                case '7':
                $session['user']['jenova']=1;
            output("Die zerbrochene Substanz, hat im Inneren einen wertvollen Stein, den du sofort an dich nimmst und bestimmt verkaufen kannst.");
                $sql="INSERT INTO items(name,class,owner,value1,gold,gems,description) VALUES ('Stein aus Destin','Beute',".$session['user']['acctid'].",0,500,1,'Ein Seltener Stein den du gut verkaufen kannst.')";
                $session['user']['reputation']-=30;
                addnav("Verschwinden","ooc..php");
                
                break;
                case '8':
                output("Du begutachtest die zerbrochene Substanz und bekommst leider nichts, du glaubst allm�hlich, Jenova hat dich veralbert, w�tend schmei�t du die Reste weg und l�ufts zum Ausgang, doch du kommst nicht weit, Jenova hat dich beobachtet und fand das nicht lustig, was du mit ihrem Geschenk getan hast, w�tend schmei�t sie dir den Zauber Kometenregen entgegen und du w�rdst bei lebendigem Leibe verbrannt.");
                $session['user']['alive']=false;
                $session['user']['hitpoints']=0;
                $session['user']['gold']=0;
                $session['user']['reputation']-=30;
                addnews($session['user']['name']."`S wurde von Jenovas Kometenzauber vernichtet!");
                addnav("Nachrichtensender","news.php");
                $session['user']['jenova']=1;
            break;
            case '9':
            $session['user']['jenova']=1;
            $badguy = array(
        "creaturename"=>"`6`7Jenova`0"
        ,"creaturelevel"=>15
        ,"creatureweapon"=>"`SKometenregen"
        ,"creatureattack"=>60
        ,"creaturedefense"=>60
        ,"creaturehealth"=>600
          ,"diddamage"=>0);
                  $session['user']['badguy']=createstring($badguy);
        $atkflux = e_rand(0,$session['user']['dragonkills']*2);
        $defflux = e_rand(0,($session['user']['dragonkills']*2-$atkflux));
        $hpflux = ($session['user']['dragonkills']*2 - ($atkflux+$defflux)) * 5;
        $badguy['creatureattack']+=$atkflux;
        $badguy['creaturedefense']+=$defflux;
        $badguy['creaturehealth']+=$hpflux;
        
            break;
            }
        }
        if ($_GET['op']=='run'){   // Flucht
    if (e_rand()%3 == 0){
  
        output ('`c`b`TDu konntest `7Jenova`T entkommen!`0`b`c`n');
        $_GET['op']='';
    }else{
        output('`c`b`$ Jenova war schneller als du!`0`b`c');
        $battle=true;
    }
}
if ($battle) {
    include("battle.php");
        if ($victory){
            $badguy=array();
            $session['user']['badguy']='';
            output('`n`TDu konntest nach einem schweren Kampf die gro�e `7Jenova`T besiegen! Da hast du aber nochmal gl�ck gehabt..');
             addnews($session['user']['name']."`That die m�chtige `7Jenova`T besiegt!!!!");
            debuglog("Jenova get�tet");
            //Navigation
            addnav("Zur�ck","ooc..php");

           
        } elseif ($defeat){
            $badguy=array();
            $session['user']['badguy']='';
            debuglog('wurde von Jenova Zerquetscht.');
            output('`n`TJenova hat dich umgebracht, kein wunder wenn du so schwach bist!!`n`nDu verlierst 10% Deiner Erfahrung.`0');
            output('`nDu kannst morgen wieder k�mpfen!`0');
            addnav('Nachrichtensender','news.php');
            addnews("`TJenova hat ".$session['user']['name']." `Tregelrecht niedergemetzelt!");
            $session['user']['alive']=false;
            $session['user']['hitpoints']=0;
            $session['user']['reputation']-=30;
            $session['user']['experience']=round($session['user']['experience']*.90,0);
        
        } else {
            fightnav(true,true);
        }

}
page_footer();
?>
