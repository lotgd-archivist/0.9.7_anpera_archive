<?php
 
/**
 *	Ein �berlebenskampf. Bek�mpfe relativ starke Engel und staube ein paar Gewinne ab.
 *	Anlehnung an das Spiel "Tales of Symphonia" von Namco Tales Studios.
 *
 *	Original aus dem Jahre 2005, �berarbeitet 2007 vom gleichen Autor
 *  Copyright: 2005-2007 Basilius Sauter (aka "Lord ELiwood")
 *	Texte: 2007 by Basilius Sauter
 *	Version 2.0-RC2 vom 6. Juli 2007
 *
 *
 * Einbau:
 *	�ffne village.php und f�ge an einer beliebigen Stelle der Navigation folgenden Navigationspunkt ein:
 *		if ($session['user']['level'] == 15)  { 
			addnav("Seltsame Lichtung","cruxis.php");
		}
 *
 */

Require_once 'common.php';
page_header("Seltsame Lichtung");

// Der erste Engel, eher schwacher Natur.
define('CRUXIS_ANGELx01_NAME', '`6Engelssp�her');
define('CRUXIS_ANGELx01_WEAPON', 'Kurzbogen mit goldener Sehne');
define('CRUXIS_ANGELx01_LEVEL', 16);
define('CRUXIS_ANGELx01_ATTACK', 31);
define('CRUXIS_ANGELx01_DEFENSE', 22);
define('CRUXIS_ANGELx01_HEALTH', 166);

// Der Engelskommandant. St�rker als der erste Engel.
define('CRUXIS_ANGELx02_NAME', '`6Engelskommandant');
define('CRUXIS_ANGELx02_WEAPON', 'Engelsschwert aus Zwergenschmiede');
define('CRUXIS_ANGELx02_LEVEL', 18);
define('CRUXIS_ANGELx02_ATTACK', 35);
define('CRUXIS_ANGELx02_DEFENSE', 24);
define('CRUXIS_ANGELx02_HEALTH', 205);

// Die Engelschar. Offensichtlich hat der User einfach kein Gl�ck...
define('CRUXIS_ANGELx03_NAME', '`6Engelsschar');
define('CRUXIS_ANGELx03_WEAPON', 'Verschiedenste Waffen');
define('CRUXIS_ANGELx03_LEVEL', 25);
define('CRUXIS_ANGELx03_ATTACK', 49);
define('CRUXIS_ANGELx03_DEFENSE', 32);
define('CRUXIS_ANGELx03_HEALTH', 470);

// Der faule Engel.
define('CRUXIS_ANGELx04_NAME', '`6Fauler Engel');
define('CRUXIS_ANGELx04_WEAPON', 'Dolch aus Zwergenschmiede');
define('CRUXIS_ANGELx04_LEVEL', 14);
define('CRUXIS_ANGELx04_ATTACK', 27);
define('CRUXIS_ANGELx04_DEFENSE', 20);
define('CRUXIS_ANGELx04_HEALTH', 145);

// Ihre Lordschaft, Lord Yggdrasil
define('CRUXIS_ANGELx05_NAME', '`^Lord Yggdrasil`0');
define('CRUXIS_ANGELx05_WEAPON', '`^Judgement.`0');
define('CRUXIS_ANGELx05_LEVEL', 30);
define('CRUXIS_ANGELx05_ATTACK', 54);
define('CRUXIS_ANGELx05_DEFENSE', 40);
define('CRUXIS_ANGELx05_HEALTH', 5000);

// Sonstige Vorbereitungen
$session['user']['specialmisc'] = unserialize($session['user']['specialmisc']);

if(isset($_GET['op']) AND $_GET['op'] == 'fight') {
	$battle = true;
	$_GET['q'] = 'fight';
}

switch(isset($_GET['q']) ? $_GET['q'] : '') {
	// Prolog
	case '': {
		rawoutput('<h2>Prolog</h2>
		<p>Etwas abseits der Stadt findest du einen Weg, dem du intressiert folgst. Nachdem du um eine Kurve gegangen bist, erkennen deine Augen eine Lichtung, die, sch�tzungsweise, etwa 30 Meter breit ist. Ein Lichtkegel, ein Strahl eher, durchbricht die merkw�rdige, dunkle Wolkendecke, die sich �ber diesen Abschnitt des Waldes ausgebreitet hat. Dir ist das ganze nicht geheuer, doch deine Neugierde erwachst.</p>
		
		<p>Was wirst du nun tun?</p>');
		
		addnav('Ansehen', 'cruxis.php?q=seeitandgodie');
		addnav('Davon schleichten', 'village.php');
		}
		break;
	
	// Erstes Kapitel: Licht
	case 'seeitandgodie': {
		output('<h2>Erstes Kapitel</h2>
		<h3>Licht</h3>
		
		<p>Du hast dich entschlossen, dir die Lichtung n�her anzusehen. Langsam schreitest du �ber den steinigen Weg, der aussieht, als ob er k�nstlich erschaffen wurde. Zumindest ist er merkw�rdig gerade, und die B�ume sehen an manchen Stellen zurecht gestutzt aus.</p>
		
		<p>Auf der Lichtung, die etwas kleiner ist, als du gedacht hast, bemerkst du nichts. Ausser den Lichtstrahl, der wohl genau die Mitte der Lichtung markiert. Du �berpr�fst zuerst die Umgebung, ob wirklich nichts hier ist, das dir Schaden k�nnte. Dann trittst du in den Lichtstrahl. �`6Licht kann ja nicht weh tun`0�, denkst du, wie es deine naive Art nun mal ist. Und wie man sich irren kann, erfahst du nur Millisekunden sp�ter.</p>
		
		<p>Ein Pfeil, aus sch�nstem Holz, reich verziert mit Adlerfedern und Gold, zischt durch die Luft und bleibt vor deinen F�ssen im Boden stecken. �ngstlich blickst du in die Richtung, aus der er zu kommen schien: Hoch in den Himmel. Und was du dort siehst, verschl�gt dir die Sprache.</p>
		
		<p>Ein Wesen mit riesigen Fl�geln st�rzt sich vom Himmel geradewegs auf dich zu. Es sind weisse Fl�gel. In der linken h�lt dieses Wesen einen Bogen. Und du weisst im selben Augenblick, wer den Pfeil geworfen hatte. Und du weisst auch, dass dir das Wesen nicht freundlich gesinnt ist.</p>', true);
		
		$badguy = array(
			'creaturename' => CRUXIS_ANGELx01_NAME,
			'creatureweapon' => CRUXIS_ANGELx01_WEAPON,
			'creaturelevel' => CRUXIS_ANGELx01_LEVEL,
			'creatureattack' => CRUXIS_ANGELx01_ATTACK,
			'creaturedefense' => CRUXIS_ANGELx01_DEFENSE,
			'creaturehealth' => CRUXIS_ANGELx01_HEALTH,
		);
		
		// Modifiziere die Werte der Kreatur, um auch Drachenkillreicheren Wesen eine Herausforderung zu geben.
		$badguy['creatureattack'] += $session['user']['dragonkills'] / 3;
		$badguy['creaturedefense'] += $session['user']['dragonkills'] / 3;
		$badguy['creaturehealth'] += ($session['user']['dragonkills'] / 3) * 7;
		
		$badguy['creatureattack'] = round($badguy['creatureattack']);
		$badguy['creaturedefense'] = round($badguy['creaturedefense']);
		$badguy['creaturehealth'] = round($badguy['creaturehealth']);
		
		$session['user']['badguy']=createstring($badguy);
		$session['user']['specialmisc']['angel'] = 1;
		$battle = true;
		}
		break;
	
	// Zweites Kapitel: Die Festung
	case 'hasdefeatedthefirstangelandcannotgoawaybecauseiwillitso': {
		output('<h2>Zweites Kapitel</h2>
		<h3>Die Festung</h3>
		
		<p>Die schwarze Wolkendecke, die das St�ck Wald �bergeben hat, stellt sich als begehbare Plattform heraus. Du bist gerade eben angekommen, die Wendeltreppe hinauf, und betrachtest nun das St�ck Land, dessen Boden aus Wolken ist. Eine riesige Festung erhebt sich unweit von dir entfernt. Schwarze Mauern. Unheilverk�ndete Zinnen, welche die Spitze der vier T�rme bildet. Mordg�nge rund um die Festung. Doch es ist niemand zu sehen. Kein Engel. Weit und breit.</p>
		
		<p>Vorsichtig schleichst du dich, abseits des Weges, an die Festung heran. Du weisst, dass du nicht durch den Haupteingang eintreten kannst. Oder willst du von tausenden Engeln erschlagen werden? Schon nach kurzer Zeit werden deine Augen schliesslich f�ndig. Auf einer Seite der Festung scheint eine T�re offen zu sein, die wohl entweder als Botenein-, oder als Notausgang dient. Du atmtest tief durch, und �ffnest die T�re. Trittst ein.</p>', true);
		
		addnav('Weiter...', 'cruxis.php?q=herunsindeathbuthedontknowit');
		}
		break;
		
	case 'herunsindeathbuthedontknowit': {
		output('<p>Ein Gang f�hrt von der T�re hinweg, weiter, gen Herz der Festung. An den W�nden sind in gewissen Abst�nden, etwa 10 Schritte, Fackeln montiert, welche wohl als Lichtquelle dienen. �`6Der Arme, der die wechseln muss`0�, denkst du. Und ein gewisses Grinsen auf deinem Gesicht kannst du nicht leugnen.</p>
		
		<p>Dich bereits tot wissend schleichst du den Gang entlang. Wann immer du ein Ger�usch h�rst, haltest du inne und starrst nach vorne. Nach einer Weile kommst du an einer T�re an, welche einen Spalt breit offen steht. Und zu deinem Gl�ck h�rst du auch gleich eine Stimme, die gerade angefangen hat, zu sprechen. H�ttest du die Stimme nicht geh�rt, h�tte wohl der Sprechende dich gesehen. Oder zumindest der Zuh�rer. Den es ja fast geben muss.</p>
		
		<p>�`2Hast du schon geh�rt? Ihre Lordschaft Lord Yggdrasil will ein Dorf zerst�ren`0�, spricht eine Stimme. Und sp�testens hier wird dir klar, dass es zwei sein m�ssen.<br />
		�`5Ja, ich habe es bereits vernommen`0�, erklingt eine zweite, weibliche Stimme. �Thors Hammer soll jenen Fleck Erde zu nichts verwandeln. Damit er selbst residieren kann.�<br />
		�`2Schade, dass wir hier in der K�che sitzen und kochen m�ssen. Ich w�rde zu gerne wieder einmal mein Schwert durch einen schwachen K�rper bohren lassen!`0�<br />
		�`5Schhht!`0�, macht die weibliche Stimme darauf hin. Gerade denkst du dich erwischt, und bereitest dich auf das schlimmste vor. Jedoch scheint sich nur die T�re zu schliessen. Du gehst weiter. Mit einem Gef�hl im Magen, das man nicht als �belkeit bezeichnen kann. Bedeutungsschwanger waren jene Worte, gewiss. Und du ahnst, dass diese Engel hier bestimmt nichts gutes im Sinn haben.</p>', true);
		
		addnav('Weiter...', 'cruxis.php?q=gonowtothethreedoorsandhavealookwhatthisfoolisdoing');
		}
		break;
	
	// Drittes Kapitel: Die drei T�ren
	case 'gonowtothethreedoorsandhavealookwhatthisfoolisdoing': {
		output('<h2>Zweites Kapitel</h2>
		<h3>Die drei T�ren</h3>
		
		<p>Du schreitest den Weg entlang. Du hast inzwischen fest den Entschluss gefasst, dieses etwas, das sich Yggdrasil nennt, zu t�ten. Um dein Dorf zu besch�tzen. Jedoch hast du keine Ahnung, wohin du musst. Und schlussendlich bleibst du vor drei T�ren stehen. Die drei T�ren unterscheiden sich lediglich in ihrer Verzierung. Sie sind etwa zwei Mann hoch, ein Mann breit und aus geschw�rztem Holz. Die Rahmen der T�re sind offensichtlich aus Eisen. Jede T�re hat an der gleichen Seite einen T�rgriff, der zu deinem verwundern trotzdem auf der normalen H�he zu sehen ist. Doch bemerkst du auch jeweils weitere T�rgriffe, die sich im oberen Drittel befinden. �`6F�r was die wohl gebraucht werden`0�, denkst du still. Und entscheidest dich, durch welche T�re du schreiten m�chtest.</p>
		
		<p>Auf der T�re zu deiner Linken ist eine Schlacht zu sehen. Ein wahrer K�nstler, der das in die T�re geschnitzt hat. Es sind offenbar zwei verschiedene V�lker, die Gegeneinander k�mpfen. Und vom Himmel herab steigen vier Engel.</p>
		
		<p>Die T�re, die sich in der Mitte befindet, wird von einem stolzen Engel geziert. Er ist fast so gross wie die T�re selbst, und sieht aus, als bewache er etwas. Er tr�gt einen Schild und einen Speer.</p>
		
		<p>Die dritte T�re, zu deiner Rechten, zeigt einen Baum. Die Krone ist um ein vielfacher gr�sser als der Stamm, und die Figuren, die auf dem Boden zu sehen sind, lassen die Dimensionen jenes riesigen Baumes vermuten.</p>', true);
		
		addnav('Die linke T�re', 'cruxis.php?q=okayhechoosetheleftdoor');
		addnav('Die T�re geradeaus', 'cruxis.php?q=damnhechoosethemiddledoor');
		addnav('Die rechte T�re', 'cruxis.php?q=hechoostherightdoorandweillsee');
		}
		break;
	
	// Linke T�re
	case 'okayhechoosetheleftdoor': {
		output('<p>Vorsichtig �ffnest du die linke T�re. Gerade, als du durchschl�pfst, bereust du deine Tat. Du findest dich n�mlich im Hof der Festung wieder. Und wie es dein Gl�ck will, findet hier gerade eine �bungsstunde statt. Und, um den ganzen noch ein Sahneh�ubchen aufzusetzen, bemerkt dich der offensichtliche Anf�hrer.</p>
		
		<p>�`4Ein Eindringling!`0�, schreit er. Und sagt dann, im Anschluss: �`4Lasst mich zu �bungszwecken zeigen, wie man am einfachsten einen Feind t�tet�.</p>
		
		<p>�`6Das kann nicht sein Ernst sein!`0�, denkst du. Verzweifelt. Und wie ernst es ihm ist, bemerkst du, als er, mit gezogenem Schwert, auf dich zugeht.</p>', true);
		
		$badguy = array(
			'creaturename' => CRUXIS_ANGELx02_NAME,
			'creatureweapon' => CRUXIS_ANGELx02_WEAPON,
			'creaturelevel' => CRUXIS_ANGELx02_LEVEL,
			'creatureattack' => CRUXIS_ANGELx02_ATTACK,
			'creaturedefense' => CRUXIS_ANGELx02_DEFENSE,
			'creaturehealth' => CRUXIS_ANGELx02_HEALTH,
		);
		
		// Modifiziere die Werte der Kreatur, um auch Drachenkillreicheren Wesen eine Herausforderung zu geben.
		$badguy['creatureattack'] += $session['user']['dragonkills'] / 3;
		$badguy['creaturedefense'] += $session['user']['dragonkills'] / 3;
		$badguy['creaturehealth'] += ($session['user']['dragonkills'] / 3) * 7;
		
		$badguy['creatureattack'] = round($badguy['creatureattack']);
		$badguy['creaturedefense'] = round($badguy['creaturedefense']);
		$badguy['creaturehealth'] = round($badguy['creaturehealth']);
		
		$session['user']['badguy'] = createstring($badguy);
		$session['user']['specialmisc']['angel'] = 2;
		$battle = true;
		}
		break;
		
	case 'wellhehasdefeatedthesecondangelbutwhathappensatnext': {
			$hasluckoderhaventluck = e_rand(0, 255);
			$hasluckoderhaventluck = $hasluckoderhaventluck%2;
			
			if($hasluckoderhaventluck === 1 OR $_GET['force'] == 'true') {
				// Has luck :(
				output('<p>Da du dich beim Tot deines Gegners gerade bei der T�re befandest, kannst du ohne Probleme durch die T�re fl�chten. Das machst du auch. Du schl�pfst erneut durch die T�re. Und befindest dich wieder in diesem Raum. Rechts scheint der Weg zu sein, wo du hergekommen bist. Und da eine Flucht ohnehin nicht sinnvoll scheint, �berlegst du, durch welche T�re du als n�chstes gehen willst...</p>', true);
				
				addnav('Die linke T�re', 'cruxis.php?q=damnhechoosethemiddledoor');
				addnav('Die T�re geradeaus', 'cruxis.php?q=hechoostherightdoorandweillsee');
				$session['user']['specialmisc']['hasvisitedtheleftdoor'] = true;
			}
			else {
				// Has no luck :)
				output('<p>Doch dein Gl�ck meint es nicht gut mit dir. Die Schar an Engel, nun einem Mob nicht un�hnlich, greift pl�tzlich zu den Waffen. Es gibt keine Ordnung in diesem Haufen, und sie wollen nur eines: Deinen Tod.</p>', true);
				
				$badguy = array(
					'creaturename' => CRUXIS_ANGELx03_NAME,
					'creatureweapon' => CRUXIS_ANGELx03_WEAPON,
					'creaturelevel' => CRUXIS_ANGELx03_LEVEL,
					'creatureattack' => CRUXIS_ANGELx03_ATTACK,
					'creaturedefense' => CRUXIS_ANGELx03_DEFENSE,
					'creaturehealth' => CRUXIS_ANGELx03_HEALTH,
				);
				
				// Modifiziere die Werte der Kreatur, um auch Drachenkillreicheren Wesen eine Herausforderung zu geben.
				$badguy['creatureattack'] += $session['user']['dragonkills'] / 3;
				$badguy['creaturedefense'] += $session['user']['dragonkills'] / 3;
				$badguy['creaturehealth'] += ($session['user']['dragonkills'] / 3) * 7;
				
				$badguy['creatureattack'] = round($badguy['creatureattack']);
				$badguy['creaturedefense'] = round($badguy['creaturedefense']);
				$badguy['creaturehealth'] = round($badguy['creaturehealth']);
				
				$session['user']['badguy'] = createstring($badguy);
				$session['user']['specialmisc']['angel'] = 3;
				$battle = true;
			}
		}
		break;
	
	// Mittlere T�re
	case 'damnhechoosethemiddledoor': {
		output('<p>Vorsichtig �ffnest du die T�re, die gerade aus lag. Und du findest dich in einem Gemach wieder. Du h�rst Schnachger�usche aus einer Ecke. Vorsichtig schleichst du durch den Raum. Und siehst die Quelle der Ger�usche.</p>
		
		<p>Ein Engel, der nicht gerade fit aussieht, schl�ft seelenruhig auf seinem Bett. �`6Den k�nnte ich t�ten!`0�, denkst du. Doch bevor du dies tun willst, siehst du dich hier noch ein wenig mehr um.</p>
		
		<p>Auf einem Tischchen steht eine Teekanne, aus der wollig warmer Tee dampft. Daneben scheint eine Notiz zu legen, die du aber, aufgrund der fremden Sprache, nicht lesen kannst. Ist es eine Warnung? Oder ein bedeutungsloser Zettel? Eine Inhaltsangabe? Ein Becher, der neben der Kanne steht, l�dt auf jeden Fall zum trinken ein...</p>
		
		<p>Was wirst du tun?</p>', true);
		
		if(empty($session['user']['specialmisc']['hasdrunkentee'])) {
			addnav('Tee trinken', 'cruxis.php?q=hewilldrinkingacupofftee');
		}
		if(empty($session['user']['specialmisc']['haskilledthefoolangel'])) {
			addnav('Engel t�ten', 'cruxis.php?q=heisoverstrangeandwillkillthisangel');
		}
		addnav('Gar nichts tun', 'cruxis.php?q=gobacktotheroomwithdedoors');
		}
		break;
	#<!-- �� -->
	case 'hewilldrinkingacupofftee': {
		output('<p>Du schenkst dir in aller Ruhe etwas Tee ein. Dann legst du die Tasse an deinen Mund und beginnst, den Tee in vollen Z�gen zu geniessen. Und du versp�rst auch sofort eine Wirkung: Du f�hlst dich wieder vollkommen fit f�r einen neuen Kampf.</p>
		
		<p>Ob der Tee wohl Nebenwirkungen hat?</p>
		
		<p>Deine Lebenspunkte wurden aufgef�llt!</p>', true);
		
		if( (e_rand(0, 99) % 3) === 0) {
			$session['user']['specialmisc']['teehasunknownsideeffects'] = true;
			$session['user']['specialmisc']['hasdrunkentee'] = true;
		}
		else {
			$session['user']['specialmisc']['teehasunknownsideeffects'] = false;
			$session['user']['specialmisc']['hasdrunkentee'] = true;
		}
		
		if(empty($session['user']['specialmisc']['haskilledthefoolangel'])) {
			addnav('Engel t�ten', 'cruxis.php?q=heisoverstrangeandwillkillthisangel');
		}
		addnav('Gar nichts tun', 'cruxis.php?q=gobacktotheroomwithdedoors');
		}
		break;
		
	case 'heisoverstrangeandwillkillthisangel': {
		output('<p>�berm�tig, wie du bist, willst du deine Waffe in den Leib deines Gegners bohren. Doch jener schl�gt sofort die Augen auf, als er die Gefahr sp�rt, und springt aus dem Bett. Hast du wirklich gedacht, dass das so einfach geht?</p>
		
		<p>Die Blutlust steht ihm geradewegs in das Gesicht geschrieben. Er will dich t�ten. Dein Blut sehen.</p>', true);
		
		$badguy = array(
			'creaturename' => CRUXIS_ANGELx04_NAME,
			'creatureweapon' => CRUXIS_ANGELx04_WEAPON,
			'creaturelevel' => CRUXIS_ANGELx04_LEVEL,
			'creatureattack' => CRUXIS_ANGELx04_ATTACK,
			'creaturedefense' => CRUXIS_ANGELx04_DEFENSE,
			'creaturehealth' => CRUXIS_ANGELx04_HEALTH,
		);
		
		// Modifiziere die Werte der Kreatur, um auch Drachenkillreicheren Wesen eine Herausforderung zu geben.
		$badguy['creatureattack'] += $session['user']['dragonkills'] / 3;
		$badguy['creaturedefense'] += $session['user']['dragonkills'] / 3;
		$badguy['creaturehealth'] += ($session['user']['dragonkills'] / 3) * 7;
		
		$badguy['creatureattack'] = round($badguy['creatureattack']);
		$badguy['creaturedefense'] = round($badguy['creaturedefense']);
		$badguy['creaturehealth'] = round($badguy['creaturehealth']);
		
		$session['user']['badguy'] = createstring($badguy);
		$session['user']['specialmisc']['angel'] = 4;
		
		$battle = true;
		}
		break;
		
	case 'gobacktotheroomwithdedoors': {
		output('<p>Und du befindest dich erneut im Raum mit den drei T�ren. Gegen�ber von dir bemerkst du den Gang, den du schon einmal entlang gegangen warst.</p>', true);
		
		if(empty($session['user']['specialmisc']['hasvisitedtheleftdoor'])) {
			addnav('Die rechte T�r', 'cruxis.php?q=okayhechoosetheleftdoor');
		}
		addnav('Zur�ck gehen', 'cruxis.php?q=damnhechoosethemiddledoor');
		addnav('Die linke T�r', 'cruxis.php?q=hechoostherightdoorandweillsee');
		}
		break;
		
	// Die rechte T�re, und die einzige, richtige Wahl
	case 'hechoostherightdoorandweillsee': {
		output('<p>Mutig, wie du bist, �ffnest du die T�re mit dem Baum darauf. Vorsichtig schl�pfst du durch. Erneut befindest du dich in einem Gang. Der jedoch etwas ger�umiger wirkt, als der vorige. Mutig schreitest du weiter.</p>', true);
		
		if(empty($session['user']['specialmisc']['haskilledthefoolangel'])) {
			// Der Diamant, der man beim vierten Engel findet, sch�tzt einem vor dieser Falle. Aber im jetzigen Fall hat der User keinen. Gl�ck?
			$userwilldieinthetrap = e_rand(0, 2300) % 3;
			if($userwilldieinthetrap === 0) {
				// Ja, der liebe User ist am Sterben. Sorry :)
				output('<p>Du merkst jedoch zu sp�t, dass der Gang nur f�r Engel gemacht zu sein scheint. Denn du trittst auf eine lose Bodenplatte und l�st damit eine Falle aus. Pfeile schiessen pl�tzlich als allen Richtungen durch den Gang. Und du hast absolut keine �berlebenschance.</p>
				
				<p>Du bist gestorben. Du verlierst all dein Gold. Auch deine Edelsteine wirst du los. Selbst Schuld, wenn du dich mit Engel anlegen m�chtest. Doch immerhin verlierst du nicht an Erfahrung. Denn das, was du gelernt hast, relativiert den Verlust wieder.</p>');
				
				$session['user']['hitpoints'] = 0;
				$session['user']['alive'] = false;
				$session['user']['gold'] = 0;
				$session['user']['gems'] = 0;
				$session['user']['experience'] = 0;
				
				addnav('T�gliche News', 'news.php');
			}
			else {
				// Gl�ck gehabt. Oder doch nicht? Lassen wir immerhin die Nebenwirkungen vom Tee erscheinen. Falls er welche gehabt hatte.
				
				output('<p>Du schreitest durch die G�nge. Du bemerkst auch manche Bodenplatten, die merkw�rdig hervorgehoben erscheinen. Gl�ck f�r dich, dass die Architekten so schwach geplant haben. Auf diese Fallen f�llst du auf jeden Fall nicht rein.</p>', true);
				
				if(!empty($session['user']['specialmisc']['teehasunknownsideeffects'])) {
					// Nebenwirkungen. Gibt verschiedene... Aber auch keine
					$sideeffects = e_rand(0, 2300) % 63;
					switch($sideeffects) {
						case 59:
						case 45:
						case 31:
						case 17:
						case 3:
							// Maximale Lebenspunkte -1
							output('<p>Allerdings versp�rst du ein leichtes Unwohlsein. Sollte das eine Nebenwirkkung des Tees sein?</p>
							
							<p>Du verlierst einen maximalen Lebenspunkt.</p>', true);
							
							$session['user']['maxhitpoints']--;
							
							$sideeffect = true;
							break;
						
						case 44:
						case 43:
						case 42:
							// Lebenspunkte -10
							output('<p>Allerdings versp�rst du ein leichtes Unwohlsein. Sollte das eine Nebenwirkkung des Tees sein?</p>
								
								<p>Du verlierst Lebenspunkte.</p>', true);
								
							if($session['user']['hitpoints'] > 10) {								
								$session['user']['hitpoints']-=10;
							}
							else {
								$session['user']['hitpoints'] = 1;
							}
							
							$sideeffect = true;
							break;
							
						case 0:
							// Tod.
							output('<p>Pl�tzlich verschwimmt deine Sicht. Kr�mpfe breiten sich aus deiner Magengegend aus, und du merkst, wie du deine Extremit�ten als wie weniger sp�rst. Blut tritt aus deiner Nase, aus deinem Mund. Schlussendlich verschwindet auch dein Bewusstsein. Und dein Leben.</p>
							<p>Du bist gestorben. Du verlierst an die raffgierigen Engel all den Gold und deine Edelsteine.</p>');
							
							$session['user']['hitpoints'] = 0;
							$session['user']['alive'] = false;
							$session['user']['gold'] = 0;
							$session['user']['experience'] = 0;
							$session['user']['gems'] = 0;
							
							addnav('T�gliche News', 'news.php');
							
							$sideeffect = true;
							break;
					}
					
					
				}
				
				if($session['user']['hitpoints'] > 0) {
					// Nichts passiert.
					output('<p>Schliesslich kommst du an einem Tor an. Es ist identisch mit dem, das du zu Begin des Ganges durchschritten hast. Aber sie steht offen. Voller Abenteuerlust, und auch mit ein wenig Wut im Bauch, schreitest du durch das Tor...</p>', true);
					
					addnav('Weiter...', 'cruxis.php?q=finaldestinationorhowstupidcanaplayerbe');
				}
			}
		}
		else {
			output('<p>Du schreitest durch die G�nge. Pl�tzlich beginnt dein Diamant zu schimmern, und erleuchtet den dunklen Gang. So bemerkst du ohne Probleme die Bodenplatten, die Ausl�ser f�r Fallen sind, und schreitest, darauf achtend, keine der Platten zu treffen, durch den Gang. </p>
			<p>Schliesslich kommst du an einem Tor an. Es ist identisch mit dem, das du zu Begin des Ganges durchschritten hast. Aber sie steht offen. Voller Abenteuerlust, und auch mit ein wenig Wut im Bauch, schreitest du durch das Tor...</p>', true);
			
			addnav('Weiter...', 'cruxis.php?q=finaldestinationorhowstupidcanaplayerbe');
		}
		}
		break;
	
	// Letztes Kapitel: Lord Yggdrasil
	case 'finaldestinationorhowstupidcanaplayerbe': {
		output('<h2>Letztes Kapitel</h2>
		<h3>Lord Yggdrasil</h3>
		
		<p>Schliesslich findest du dich in einem ger�umigen Saal wieder. Auf einem reich verzierten Stuhl, der selbst auf einem Podium steht (soll wohl einen Thron symbolisieren), sitzt ein Engel. Gekleidet in weisser Kleidung. Die blonden Haare fallen �ber seine Schultern, hinab zum Kreuz. Sein Kopf liegt aufgest�tzt auf seiner rechten Hand. Gelangweilt starrt er dich an.</p>
		
		<p>�`3Ich habe dich erwartet`0�, spricht der Engel. Er steht auf, und geht langsam auf dich zu. Und w�hrend den Schritten spricht er mit dir. �`3Ich bin Lord Yggdrasil. Anf�hrer dieser Organisation`0�. Er bleibt stehen. Etwa 10 Meter von dir entfernt. �`3Hast du wirklich gedacht, du k�nntest unbemerkt in meine Festung eindringen? Hast du dir nie die Frage gestellt, warum jene Treppe auf der Lichtung erschien? Ich brauche deinen K�rper. Als Puppe. Du bist bekannt. Und wer kann besser ins Dorf gelangen, als jemand, der wie ein Dorfbewohner aussieht?<br />
		Genau. Du. Wir werden aus dem Dorf hinaus den Weg des Lichtes leuchten, und Thors Hammer los lassen. Die st�rkste Magie.`0�</p>
		
		<p>Der Mann, Yggdrasil, schliesst schliesslich die Augen. Ergeben schaut er mit geschlossenen Augen gen Decke, dorthin, wo ein Bild einer wundersch�nen Frau gezeichnet ist. Seine Geliebte? Du wirst es wohl nie erfahren. Sein K�rper beginnt zu zittern. Um seinen K�rper herum erscheint ein weisses Licht, kreisf�rmig. Seine Haare werden hochgewirbelt. Und in seinen H�nden b�ndelt sich Energie.</p>
		
		<p>Dann, auf einmal, verschwindet die Energie. Und der Mann, der Yggdrasil genannt und einen Lord geschimpft wird, wirft eine Kugel aus reinstem Licht gegen dich. Der Kampf hat begonnen.</p>', true);
		
		$badguy = array(
			'creaturename' => CRUXIS_ANGELx05_NAME,
			'creatureweapon' => CRUXIS_ANGELx05_WEAPON,
			'creaturelevel' => CRUXIS_ANGELx05_LEVEL,
			'creatureattack' => CRUXIS_ANGELx05_ATTACK,
			'creaturedefense' => CRUXIS_ANGELx05_DEFENSE,
			'creaturehealth' => CRUXIS_ANGELx05_HEALTH,
		);
		
		// Modifiziere die Werte der Kreatur, um auch Drachenkillreicheren Wesen eine Herausforderung zu geben.
		$badguy['creatureattack'] += $session['user']['dragonkills'] / 3;
		$badguy['creaturedefense'] += $session['user']['dragonkills'] / 3;
		$badguy['creaturehealth'] += ($session['user']['dragonkills'] / 3) * 10;
		
		$badguy['creatureattack'] = round($badguy['creatureattack']);
		$badguy['creaturedefense'] = round($badguy['creaturedefense']);
		$badguy['creaturehealth'] = round($badguy['creaturehealth']);
		
		$session['user']['badguy']=createstring($badguy);
		$session['user']['specialmisc']['angel'] = 5;
		$battle = true;
		}
		break;
}




if ($battle === true) {
	Include 'battle.php';
	if($victory) {
		switch($session['user']['specialmisc']['angel']) {
			case 1:
				output('<p>Das Wesen ist tot. Du entreisst ihm ein Amulett, das ihm um den Hals h�ngt. Darauf abgebildet siehst du den grossen Buchstaben "A" in einem Kreis abgebildet, welcher Engelsfl�gel hat. "`6Engel?`0", fragst du dich still, denn als du etwas nachdenkst, fallen dir Geschichten ein, die von Wesen mit riesigen, weissen Fl�geln berichten und Engel genannt werden. Ob dies hier so einer war?</p>
				
				<p>Pl�tzlich, wie von Zauberhand, erscheint eine Wendeltreppe rund um jenen Lichtstrahl, oder Lichtkegel, was es schlussendlich auch sein mag. Die Lichttreppe scheint nicht nat�rlich zu sein, denn sie besteht aus Lichtstrahlen. Vorsichtig setzt du deinen Fuss auf den ersten Tritt. Zu deinem Verwundern scheint die Treppe dein Gewicht tats�chlich tragen zu k�nnen... Was das wohl bedeutet?</p>
				
				<p>Voller Tatendrang erklimmst du die Wendeltreppe. Denn ein Zur�ck gibt es nicht mehr. Du hast einen Engel get�tet, und das bedeutet die Todesstrafe. Das Judgement. Das heilige Urteil. Und wer weiss. Vielleicht findest du auch Reichtum?</p>', true);
				
				addnav('Weiter...', 'cruxis.php?q=hasdefeatedthefirstangelandcannotgoawaybecauseiwillitso');
				break;
				
			case 2:
				output('<p>Und auch der Engelskommandant ist tot. Aber ob das eine gute Idee war? Denn dort stehen noch mehr Engel. Und sie sehen nicht gerade freundlich aus. Nein, wirklich nicht.</p>', true);
				
				addnav('Weiter...', 'cruxis.php?q=wellhehasdefeatedthesecondangelbutwhathappensatnext');
				break;
				
			case 3:
				output('<p>Du hast auch die Engelsschar nieder geschlagen. Ersch�pft schwankst du zur T�re, von der du gekommen bist. Oder willst du im Ernst warten, bis noch mehr Engel kommen und dein Blut wollen? Du bist bereits ihr Todfeind.</p>', true);
				
				addnav('Weiter...', 'cruxis.php?q=wellhehasdefeatedthesecondangelbutwhathappensatnext&force=true');
				break;
				
			case 4:
				output('<p>Auch den faulen Engel hast du get�tet. Beim durchsuchen jenes Gegners findest du einen merkw�rdig schimmernden Diamanten. �`6Den nimm ich wohl besser mit`0�, denkst du. Und tust es auch.</p>');
				
				$session['user']['specialmisc']['haskilledthefoolangel'] = true;
				
				if(empty($session['user']['specialmisc']['hasdrunkentee'])) {
					addnav('Tee trinken', 'cruxis.php?q=hewilldrinkingacupofftee');
				}
				addnav('Gar nichts tun', 'cruxis.php?q=gobacktotheroomwithdedoors');
				break;
				
			case 5:
				output('<p>Die erstarrten Augen des Engels blicken dich �berrascht an. Er hat nicht damit gerechnet, dass du ihn t�test. R�chelnd sinkt er auf die Knie. Und dann f�llt er ganz um. Ersch�pft wischst du dir das Blut aus dem Gesicht. Dann durchsuchst du den Engel, und findest ein S�ckchen. Du �ffnest es, und findest zehn Edelsteine.</p>
				
				<p>Dann, auf einmal, verschwimmen die Farben. Es wird schwarz, und in der n�chsten Sekunde wachst du auf der Lichtung wieder auf. Hast du etwa alles nur getr�umt? Hat dir das Licht die Sinne geraubt?</p>
				
				<p>Vielleicht. Wahrscheinlich. Aber woher sonst das S�ckchen mit den Edelsteinen kommt, weisst du nicht. Aber wer weiss. Vielleicht hat sich auch dein Ruf verbessert.</p>', true);
				
				$session['user']['gems']+=10;
				$session['user']['reputation']+=50;
				
				addnav('Zum Dorf', 'village.php');
				break;
		}
	}
	elseif($defeat) {
		if($session['user']['specialmisc']['angel'] == 5) {
			output('<p>Mit letzter Kraft schneidest du dir selbst in deinen Bauch. Wenn er deinen K�rper bekommen soll, dann nur zerst�rt. Denn die Art, wie er dich angreift, mit Licht in reinster Form, zeugt davon, dass er deinen K�rper unverletzt braucht. Mit einem letzten Grinsen ziehst du schliesslich die Klinge aus deinem Bauch, und legst es an deinem Hals an. Du h�rst nur noch, wie der Engel, Lord Yggdrasil, schreit. Was er schreit, verstehst du nicht mehr. Schw�rze �berkommt dich...</p>
			
			<p>Du bist gestorben. Du verlierst all dein Gold. Auch deine Edelsteine wirst du los. Selbst Schuld. Wenn du dich mit Engel anlegen m�chtest. Doch immerhin verlierst du nicht an Erfahrung. Denn das, was du gelernt hast, relativiert den Verlust wieder.</p>');
				
			$session['user']['hitpoints'] = 0;
			$session['user']['alive'] = false;
			$session['user']['gold'] = 0;
			$session['user']['gems'] = 0;
			$session['user']['experience'] = 0;
			
			addnav('T�gliche News', 'news.php');
		}
		else {
			output('<p>Du bist gestorben. Kl�glich, ohne Zeugen. In einer Welt, die merkw�rdiger nicht sein kann. Du verlierst all dein Gold. Auch deine Edelsteine wirst du los. Selbst Schuld. Wenn du dich mit Engel anlegen m�chtest. Doch immerhin verlierst du nicht an Erfahrung. Denn das, was du gelernt hast, relativiert den Verlust wieder.</p>');
			
			$session['user']['hitpoints'] = 0;
			$session['user']['alive'] = false;
			$session['user']['gold'] = 0;
			$session['user']['gems'] = 0;
			$session['user']['experience'] = 0;
			
			addnav('T�gliche News', 'news.php');
		}
	}
	else {
		fightnav(true, false);
	}
}

page_footer();
?>
