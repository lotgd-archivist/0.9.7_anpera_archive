<?php

//14122007

/**********************************************
*Diese Box darf nicht entfernt werden!        *
*---------------------------------------------*
*Regatta von Takeo bzw. Knightnike            *
*Version 1.8 - Niko.Berkmann@gmx.de           *
*Das Copyright am Ende bitte bestehen lassen. *
*(Ist ja nur ein HTML-Kommentar!)             *
**********************************************/
/*
!!! geschrieben f�r ein LotGD der Version 0.9.7+jt ext (GER) - ob es bei h�heren Versionen auch l�uft wei� ich nicht !!!
__________________________________________
---ben�tigte Dateien: regatta.php---
__________________________________________
Source�nderungen:
___In einer beleibigen Datei - z.B. village.php folgende Zeile einf�gen:___
addnav("Der See","regatta.php");
__________________________________________
Datenbank�nderungen:
KEINE!
*/

require_once "common.php";
addcommentary();
checkday();

page_header("Die Regatta");
output("`c`b`^---Die Regatta---`b`c `n`n`0");

// Interne Variablen:
$p31pos1="0";
$p31pos2="0";
$p31pos3="0";
$p31pos4="0";
$rekordsteps="0";

//Die Werte zwischen den Anf�hrungszeichen k�nnen beliebig veraendert werden um die Preise festzulegen!
$gold3v1="100"; //Teilnahmekosten f�r den 3-gegen-1-Modus: muss gerade sein
$gain3v1="250"; //Preisgeld f�r den 3-gegen-1-Modus: muss gerade sein
$goldrekord="100"; //Teilnahmekosten f�r den Rekordmodus: muss gerade sein
$runden="3"; //Anzahl der Runden, die die Teilnahme fordert - mindestens 2 sind aber empfohlen

clearnav();

// OP-Switch START
switch($_GET['op']){
case "":
	output("`8 An einen kleinen See sind ein paar Trib�hnen aufgebaut.`nHier findet eine Segelregatta statt.`nDu willst dich gerade wieder umdrehen da f�llt dir ein, dass es bei einem Wettkampf wie diesem nat�rlich auch`@ Preise`8 gibt. Vielleicht solltest du doch einmal schauen ob du nicht auch teilnehmen m�chtest!");
	addnav("Aktionen");
	addnav("Zu den Trib�hnen","regatta.php?op=tribuene");
	addnav("Teilnehmen","regatta.php?op=renntypwahl");
	addnav("Zur�ck zum Dorf","village.php");

break;
case "tribuene":
	addnav("Wieder gehen","regatta.php");
	output("`g Auf den Trib�hnen sitzen ein paar Menschen und ab und zu l�uft ein Essensverk�ufer durch die Reihen. Du l�sst dich einem Sitz nieder und beobachtest, was so um dich herum passiert. �berall wird geredet und die Schiedsrichter schreien die Rennergebnisse in die Menge.`n`n");
	viewcommentary("regattatribuene","Hinzuf�gen",20);

break;
case "renntypwahl":
	output("`8 W�hle einen Renntyp!`n`nIm`^ 3 gegen 1`8 Rennen musst du vor deinen 3 Gegnern im Ziel sein. Zu gewinnen gibt es hier das zweieinhalbfache des Einsatzes.`n`nIm`^ Rekordmodus`8 bekommst du jenachdem wie schnell du es ins Ziel schaffst unterschiedlich viel Preisgeld. Da dies nat�rlich sehr kraftraubend ist kostet dich ein Rennen`Q ".$runden." Waldk�mpfe`8 !`n`n");
	if (($session['user']['turns']>=$runden) And (($session['user']['gold']>=$gold3v1) Or ($session['user']['gold']>=$goldrekord))) {
		if ($session['user']['gold']>=$gold3v1) addnav("3 gegen dich (".$gold3v1." Gold)","regatta.php?op=3gegendich"); 
		if ($session['user']['gold']>=$goldrekord) addnav("Rekordmodus (".$goldrekord." Gold)","regatta.php?op=rekord");
	} else {
		if ($session['user']['turns']<$runden) output("`$ Du bist zu ersch�pft, um heute noch teilzunehmen!`0`n");
		if (($session['user']['gold']<$gold3v1) And ($session['user']['gold']<$goldrekord)) output("`$ Du hast nicht genug Geld, um teilzunehmen!`0`n");
	}
	addnav("Doch nicht teilnehmen","regatta.php");

break;
case "3gegendich":
	$session['user']['gold']-=$gold3v1;
	$session['user']['turns']-=$runden;
	output("`& Mach dich bereit, es geht los!`n");
	addnav("Anfangen","regatta.php?op=rennen&modus=3gegen1&anzeige=zeigen&pos1=1&pos2=1&pos3=1&pos4=1");

break;
case "rekord":
	$session['user']['gold']-=$goldrekord;
	$session['user']['turns']-=$runden;
	output("`& Mach dich bereit, es geht los!`n");
	addnav("Anfangen","regatta.php?op=rennen&modus=rekord&anzeige=zeigen&pos1=1&steps=0");

// Rennen START
break;
case "rennen":

	// 3 gegen 1 Modus START
	switch($_GET['modus']){

	case "3gegen1":
		//einlesen der �berreichten vari's
		$p31pos1=$_GET['pos1'];
		$p31pos2=$_GET['pos2'];
		$p31pos3=$_GET['pos3'];
		$p31pos4=$_GET['pos4'];

		//random f�r den Spieler
		$wegrandom=e_rand(1,3); 
		switch($wegrandom){  
		case '1':
			output("`$ Du kommst langsam voran.");
		break;
		case '2':
			output("`^ Du kommst z�gig voran.");
		break;
		case '3':
			output("`@ Du kommst sehr schnell voran.");
		break;
		}
		$p31pos1+=$wegrandom;

		//random f�r die NPC's
		$p31pos2+=e_rand(1,3); 
		$p31pos3+=e_rand(1,3); 
		$p31pos4+=e_rand(1,3); 

		// Anzeige KLAMMERSTART
		if ($_GET['anzeige']=="zeigen"){

			// Fehler�berpr�fung & Overflow verhindern
			if ($p31pos1>20) $p31pos1=20;
			if ($p31pos2>20) $p31pos2=20;
			if ($p31pos3>20) $p31pos3=20;
			if ($p31pos4>20) $p31pos4=20;
	
			output("`n`n`t|`9 ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ `t|`n`0");

			//Spieler-Anzeige
			output("`t|");
			$vorne=($p31pos1-1);
			$hinten=(20-$p31pos1);
			while ($vorne>0){
				output("`9~");
				$vorne-=1;
			}
			output("`&O");
			while ($hinten>0){
				output("`9~");
				$hinten-=1;
			}
			output("`t|  `&Spieler`n");

			//Gegner1-Anzeige
			output("`t|");
			$vorne=($p31pos2-1);
			$hinten=(20-$p31pos2);
			while ($vorne>0){
				output("`9~");
				$vorne-=1;
			}
			output("`tO");
			while ($hinten>0){
				output("`9~");
				$hinten-=1;
			}
			output("`t|  `&Gegner 1`n");
	
			//Gegner2-Anzeige
			output("`t|");
			$vorne=($p31pos3-1);
			$hinten=(20-$p31pos3);
			while ($vorne>0){
				output("`9~");
				$vorne-=1;
			}
			output("`^O");
			while ($hinten>0){
				output("`9~");
				$hinten-=1;
			}
			output("`t|  `&Gegner 2`n");

			//Gegner3-Anzeige
			output("`t|");
			$vorne=($p31pos4-1);
			$hinten=(20-$p31pos4);
			while ($vorne>0){
				output("`9~");
				$vorne-=1;
			}
			output("`VO");
			while ($hinten>0){
				output("`9~");
				$hinten-=1;
			}
			output("`t|  `&Gegner 3`n");
		
			output("`t|`9 ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ `t|`n`0");

		} // Anzeige KLAMMERENDE

		//Gewinnpr�fung

		$win=0;
		if ($p31pos1>=20) $win+=1;
		if ($p31pos2>=20) $win+=1;
		if ($p31pos3>=20) $win+=1;
		if ($p31pos4>=20) $win+=1;

		switch ($win){
		case '0':
			addnav("Weitersegeln","regatta.php?op=rennen&modus=3gegen1&anzeige=zeigen&pos1=".$p31pos1."&pos2=".$p31pos2."&pos3=".$p31pos3."&pos4=".$p31pos4);
		break;
		case '1':
			if ($p31pos1>=20){
				output("`n`n`# SUPER! Du hast den ersten Platz gemacht, das war eine Spitzenleistung.`n`@Du bekommst das Preisgeld von ".$gain3v1." Gold!");
				$session['user']['gold']+=$gain3v1;

				$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'regattatribuene',".$session['user']['acctid'].",'/me `\@ hat ein Rennen gewonnen.')";
				db_query($sql) or die(db_error(LINK));

				clearnav();
				addnav("Weiter","regatta.php");
			} else {
				output("`n`n`# SCHADE! Leider Pech gehabt, dein Gegner war schneller als du. Vielleicht schaffst du es ja beim n�chsten Mal...");
				clearnav();
				addnav("Weiter","regatta.php");
			}
		break;
		default:
			if ($p31pos1>=20){
				output("`n`n`# NICHT SCHLECHT! Du warst gleichzeitig mit jemand anderem im Ziel.`n`@Du bekommst das halbe Preisgeld von ".($gain3v1/2)." Gold!");
				$session['user']['gold']+=($gain3v1/2);
				clearnav();
				addnav("Weiter","regatta.php");
			} else {
				output("`n`n`# SCHADE! Leider Pech gehabt, dein Gegner war schneller als du. Vielleicht schaffst du es ja beim n�chsten Mal...");
				clearnav();
				addnav("Weiter","regatta.php");
			}
		break;
		}

	// 3 gegen 1 Modus ENDE
	// Rekordmodus START
	break;
	case "rekord":

		//einlesen der �berreichten vari's
		$p31pos1=$_GET['pos1'];
		$rekordsteps=$_GET['steps'];

		//random f�r den Spieler
		$wegrandom=e_rand(1,5); 
		switch($wegrandom){  
		case '1': case '2':
			output("`$ Du kommst langsam voran.");
			$zufallsweg=1;
		break;
		case '3':
			output("`^ Du kommst z�gig voran.");
			$zufallsweg=2;
		break;
		case '4': case '5':
			output("`@ Du kommst sehr schnell voran.");
			$zufallsweg=3;
		break;
		}
		$p31pos1+=$zufallsweg;
		$rekordsteps=$rekordsteps+1;
		output(" `&(Zug ".$rekordsteps.")");

		// Anzeige KLAMMERSTART
		if ($_GET['anzeige']=="zeigen"){

			// Fehler�berpr�fung & Overflow verhindern
			if ($p31pos1>20) $p31pos1=20;

			output("`n`n");
			output("`t|`9 ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ `t|`n`0");

			//Spieler-Anzeige
			output("`t|");
			$vorne=($p31pos1-1);
			$hinten=(20-$p31pos1);
			while ($vorne>0){
				output("`9~");
				$vorne-=1;
			}
			output("`&O");
			while ($hinten>0){
				output("`9~");
				$hinten-=1;
			}
			output("`t|  `&Spieler`n");

			output("`t|`9 ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ `t|`n`0");

		} // Anzeige KLAMMERENDE

		//Gewinnpr�fung

		if($p31pos1<20){
			addnav("Weitersegeln","regatta.php?op=rennen&modus=rekord&anzeige=zeigen&pos1=".$p31pos1."&steps=".$rekordsteps);
		} else {

			if ($rekordsteps==10){
				$gewinnsumme=$goldrekord;
			} elseif ($rekordsteps<10){
				$gewinnsumme=$goldrekord*1.5;
			} else {
				$gewinnsumme=$goldrekord*0.4;
			}
			output("`n`n`^Geschafft, du schie�t �ber die Ziellinie. Dazu hast du `&".$rekordsteps."`^ Z�gen gebraucht.`nDu bekommst `&".$gewinnsumme." Gold `^f�r deine Zeit.");
			$session['user']['gold']+=$gewinnsumme;
			addnav("Weiter","regatta.php");
		}

	} // Rekordmodus ENDE

} // OP-Switch ENDE

rawoutput("<!-- Regatta (1.8): Copyright by Takeo (Knightnike) -->"); //Dies bitte nicht entfernen!

page_footer();
?>