<?php

/*
 * Darstellung der K�mpferliste erneuert by 'MySQL' [User from anpera.net]. :-)
*/

require_once 'common.php';

if ($session[user][loggedin]) {
	checkday();
	if ($session[user][alive]) {
		addnav('Zur�ck zum Dorf','village.php');
	} else {
		addnav('Zur�ck zu den Schatten','shades.php');
	}
	addnav('Gerade Online','list.php');
}else{
	addnav('Login Seite','index.php');
	addnav('Gerade Online','list.php');
}

page_header('Die K�mpferliste');

$select = db_query('SELECT count(acctid) AS c FROM accounts WHERE locked=0');
$return = db_fetch_assoc($select);

$totalplayers = $return['c'];
$playersperpage = 15;

switch ($_GET['op']) {
	
	case 'search':
		
		$search = '%';
		for ($x = 0;$x < strlen($_POST['name']);$x++){
			
			$search .= substr($_POST['name'],$x,1).'%';
		
		}
		$search = ' AND name LIKE "'.addslashes($search).'" ';
	
	break;
	default:
		
		$pageoffset = (int)$_GET['page'];
		if ($pageoffset>0) $pageoffset--;
		$pageoffset*=$playersperpage;
		$from = $pageoffset+1;
		$to = min($pageoffset+$playersperpage,$totalplayers);
	
		$limit=' LIMIT '.$pageoffset.','.$playersperpage.' ';
	
	break;

}

addnav('Seiten');

for ($i = 0;$i < $totalplayers;$i += $playersperpage){
	
	addnav('Seite '.($i/$playersperpage+1).' ('.($i+1).'-'.min($i+$playersperpage,$totalplayers).')','list.php?page='.($i/$playersperpage+1));

}

if ($_GET['op'] == '' && $_GET['page'] == '') {
	
	output('`c`bFolgende Krieger sind gerade im Land online:`b`c');
	$sql = 'SELECT * FROM accounts WHERE locked=0 AND loggedin=1 AND laston>"'.date('Y-m-d H:i:s',strtotime(date('r').'-'.getsetting('LOGINTIMEOUT',900).' seconds')).'" ORDER BY level DESC, dragonkills DESC, login ASC';
	
} else {
	
	output('`c`bKrieger in dieser Welt (Spieler '.$from.'-'.$to.')`b`c');
	$sql = 'SELECT * FROM accounts WHERE locked=0 '.$search.' ORDER BY level DESC, dragonkills DESC, login ASC '.$limit;

}

if ($session[user][loggedin]) {
	
	output('`n<div align="center">'.
		   '<form action="list.php?op=search" method="POST">'.
		   '<fieldset style="width: 40%;">'.
		   '<legend> Krieger-Suche </legend>'.
		   '<label for="name"> Name </label>'.
		   '<input type="text" name="name" value="Name des Kriegers?" onclick="this.value=\'\'">'.
		   '<label for="search"> <input class="button" type="submit" value="Spieler suchen!"</label>'.
		   '</fieldset>'.
		   '</form>'.
		   '</div>`n',true);
	addnav('','list.php?op=search');

}

$result = db_query($sql) or die(sql_error($sql));
$max = db_num_rows($result);

if ($max > 100) {
	output('`\$Es treffen zu viele Namen auf diese Suche zu. Nur die ersten 100 werden angezeigt.`0`n');
}

$sex_arr = array(0 => 'M�nnlich',1 => 'Weiblich');

if ($session['user']['prefs']['list_standard'] == 1) {
	
	output('<table border=0 cellpadding=0 cellspacing=1 align="center"'.
		   '<tr class="trhead">'.
		   '<td align="center"><b>Level</b></td>'.
		   '<td align="center"><b>Name</b></td>'.
		   '<td align="center"><b>Rasse</b></td>'.
		   '<td align="center"><b>Geschlecht</b></td>'.
		   '<td align="center"><b>Ort</b></td>'.
		   '<td align="center"><b>Status</b></td>'.
		   '<td align="center"><b>Letzter Login</b></td>'.
		   '</tr>',true);
	
	for($i = 0;$i < $max;$i++) {
		
		$row = db_fetch_assoc($result);
		
		if ($session[user][loggedin]) {
			
			$mail_link = '<a href="mail.php?op=write&to='.rawurlencode($row['login']).'" target="_blank" onClick="'.popup('mail.php?op=write&to='.rawurlencode($row['login']).'').';return false;"><img src="images/newscroll.gif" width="16" height="16" alt="Schreibe '.$row['login'].' eine YoM!" border="0"></a>';
			$bio_link = '<a href="bio.php?char='.rawurlencode($row['login']).'">`'.($row['acctid'] == getsetting('hasegg',0)?'^':'&').$row['name'].'`0</a>';
		
		} else {
			
			$mail_link = '';
			$bio_link = '`'.($row['acctid'] == getsetting('hasegg',0)?'^':'&').$row['name'].'`0';
		
		}
		
		$loggedin = (date('U') - strtotime($row[laston]) < getsetting('LOGINTIMEOUT',900) && $row[loggedin]);
		
		switch ($row['location']) {
			
			case 0:
				
				$loc = ''.($loggedin?'`#Online`0':'`3Die Felder`0').'';
			
			break;
			case 1:
				
				$loc = '`3Zimmer in der Kneipe`0';
			
			break;
			case 2:
				
				$loc = '`3Im Haus`0';
			
			break;
		}
		
		$laston=round((strtotime(date('r'))-strtotime($row[laston])) / 86400,0).' Tage';
		if (substr($laston,0,2)=='1 ') $laston='1 Tag';
		if (date('Y-m-d',strtotime($row[laston])) == date('Y-m-d')) $laston='Heute';
		if (date('Y-m-d',strtotime($row[laston])) == date('Y-m-d',strtotime(date('r').'-1 day'))) $laston='Gestern';
		if ($loggedin) $laston='Jetzt';
		
		output('<tr class="'.($i%2?'trdark':'trlight').'">'.
			   '<td>'.$row[level].'</td>'.
			   '<td>'.$mail_link.' '.$bio_link.'</td>'.
			   '<td>'.$colraces[$row['race']].'</td>'.
			   '<td>'.$sex_arr[$row['sex']].' ('.($row['sex']?'<img src="images/female.gif">':'<img src="images/male.gif">').')</td>'.
			   '<td>'.$loc.'</td>'.
			   '<td>'.($row['alive']?'`1Lebt`0':'`4Tot`0').'</td>'.
			   '<td>'.$laston.'</td>'.
			   '</tr>',true);
		addnav('','mail.php?op=write&to='.rawurlencode($row['login']));
		addnav('','bio.php?char='.rawurlencode($row['login']));
	
	}
	
output("</table>",true);
} else {
	
	for($i = 0;$i < $max;$i++) {
		
		$row = db_fetch_assoc($result);
		
		if ($row['avatar'] == '') {
			
			$avatar = '<img src="images/no_avatar.gif" width="100" height="100">';
		
		} else {
			
			$avatar = '<img src="'.$row['avatar'].'" width="100" height="100">';
		
		}
		
		if ($session[user][loggedin]) {
			
			$mail_link = '<a href="mail.php?op=write&to='.rawurlencode($row['login']).'" target="_blank" onClick="'.popup('mail.php?op=write&to='.rawurlencode($row['login']).'').';return false;"><img src="images/newscroll.gif" width="16" height="16" alt="Schreibe '.$row['login'].' eine YoM!" border="0"></a>';
			$bio_link = '<a href="bio.php?char='.rawurlencode($row['login']).'">'.$row['login'].'\'s Biographie anzeigen!</a>';
		
		} else {
			
			$mail_link = '';
			$bio_link = '`'.($row['acctid'] == getsetting('hasegg',0)?'^':'&').$row['name'].'`0';
		
		}
		
		$loggedin = (date('U') - strtotime($row[laston]) < getsetting('LOGINTIMEOUT',900) && $row[loggedin]);
		
		switch ($row['location']) {
			
			case 0:
				
				$loc = ''.($loggedin?'`#Online`0':'`3Die Felder`0').'';
			
			break;
			case 1:
				
				$loc = '`3Zimmer in der Kneipe`0';
			
			break;
			case 2:
				
				$loc = '`3Im Haus`0';
			
			break;
		}
		
		$laston=round((strtotime(date('r'))-strtotime($row[laston])) / 86400,0).' Tage';
		if (substr($laston,0,2)=='1 ') $laston='1 Tag';
		if (date('Y-m-d',strtotime($row[laston])) == date('Y-m-d')) $laston='Heute';
		if (date('Y-m-d',strtotime($row[laston])) == date('Y-m-d',strtotime(date('r').'-1 day'))) $laston='Gestern';
		if ($loggedin) $laston='Jetzt';
		
		output('<div align="center"><fieldset style="width: 60%;text-align: left;">'.
			   '<legend>Info zu '.$row['login'].'</legend>'.
			   '<table>'.
			   '<tr>'.
			   '<td>'.$avatar.'</td>'.
			   '<td><pre> </pre></td>'.
			   '<td>Name:<br />Geschlecht:<br />Rasse:<br />Momentan:<br />Status:<br />Letzter Login:</td>'.
			   '<td><pre> </pre></td>'.
			   '<td>'.$row['name'].' '.$mail_link.'<br />'.$sex_arr[$row['sex']].' ('.($row['sex']?'<img src="images/female.gif">':'<img src="images/male.gif">').')<br />'.
			   ''.$colraces[$row['race']].'<br />'.$loc.'<br />'.($row['alive']?'`@Im Reich der Lebenden`0':'`4Im Reich der Toten.`0').'<br />'.$laston.'</td>'.
			   '</tr>'.
			   '</table>'.
			   '`c'.$bio_link.'`c'.
			   '</fieldset></div>',true);
		addnav('','mail.php?op=write&to='.rawurlencode($row['login']));
		addnav('','bio.php?char='.rawurlencode($row['login']));
	}
}

page_footer();
?>