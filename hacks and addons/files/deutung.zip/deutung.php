<?php

/*
Einbauanleitung f�r LoGD 0.97

�ffne, wenn die Deutung �ber den DK gespeichert bleiben soll, die dragon.php

suche 2x:
,"name"=>1

f�ge in die Auflistung dazu:
,"deutung"=>1

�ffne gypsy.php
		
		suche:

addnav("Edelsteine");

		f�ge davor ein:

if($session[user][deutung]==0){
	addnav("Die Kugel");
	addnav("Blicke in die Zukunft (1 Edelstein)","gypsy.php?op=deuten");
	}

		suche:
}elseif($_GET[op]=="sell"){
		
		
		f�ge davor ein:
		
	}elseif($_GET[op]=="deuten"){
	//ALTER TABLE `accounts` ADD `deutung` INT( 10 ) NOT NULL DEFAULT '0' COMMENT 'Deutung der Zigeunerin'
	
	page_header("Zigeunerzelt");
	checkday();
	
	
	output("	`5Du n�herst dich der guten `6Vessa`5, setzt dich an einen kleinen runden Tisch ihr gegen�ber. Auf dem Tisch steht eine Kristallkugel`n
				`6Vessa`5 Blickt dir in die Augen, tief in die Augen, dann senkt sie den Blick auf die Kristallkugel.`n
				`6Hmm. `5Sie runzelt die Stirn, dann beginnen ihre Augen in der Kugel zu sehen, etwas �ber deine Zukunft zu sehen.
			");
	output("`n`n`n");
	
					$session['user']['gems']--;
	
	switch(e_rand(1,10)){
	case 1:
	
	
	output("	`6Du wirst im Wald einen Troll begnen, er wird dich zuerst nicht sehen. Du schleichst dich n�her an ihn herran. Dann bemerkt er dich. Du Rennst `bNICHT`b weg .... 
				`nDu besiegst den Troll leichtfertig. Hinter dem Troll befindet sich ein kleiner Schatz, ein paar Edelsteine die du dir einsteckst und wieder weiter ziehst.
			");
	
	
	
				
					$session['user']['deutung']=1; // Troll Kampf Sieg

		break;
		
	case 2:
	
	
	output("	`6Du wirst im Wald einen Troll begnen, er wird dich zuerst nicht sehen. Du schleichst dich n�her an ihn herran. Dann bemerkt er dich. Du Rennst `bNICHT`b weg ....
				Der Troll schwingt seine Keule direkt gegen deinen Kopf und bef�rdert dich zu `7Santino`6 Das sind Schmerzen. Du solltest lieber fl�chten.
			");
	
				
					$session['user']['deutung']=2; // Troll Kampf Niederlage
					
		break;
		
	case 3:
	output("	`6Du wirst einen steinigen Pfad folgen, du wirst ihm lange folgen bis du an eine alte H�ngebr�cke kommst. Die Br�cke sieht noch ganz gut aus, du betritts die Br�cke, aber als
				auf der h�lfte angekommen bist, h�rst du ein knacken und die Pfeiler auf der anderen Seite brechen durch. Die Br�cke st�rzt mit dir in die Tiefe, dabei verlierst du alles Gold.
			");
					$session['user']['deutung']=3; //Br�cke St�rzt ein
	
	
		break;

	case 4:
	
	output("	`6Du wirst einen steinigen Pfad folgen, du wirst ihm lange folgen bis du an eine alte H�ngebr�cke kommst. Die Br�cke sieht noch ganz gut aus, du betritts die Br�cke, aber als
				auf der h�lfte angekommen bist, beginnen die Bretter zu knarzen. Du traust dich weiter zu gehen und kommst auf der anderen Seite an und findest dort einen gro�en Goldschatz.
			");
	
					$session['user']['deutung']=4; //Br�cke h�lt
			break;

	case 5:
	
	output("	`6Du wirst einen Pfad folgen. Du triffst auf ein M�dchen in einem blauen Kleid. Sie erz�hlt dir unter Tr�nen von einer R�uberbande die hinter der n�chsten Abbiegung Rechst ihr Lager haben.`n 
				Sie erz�hlt auch, das all ihr Gold abgenommen wurde und rennt dann in richtung Dorf davon. Du gehst weiter und kommst an die Weggablung, du gehst den Rechten Weg und triffst auf die R�uber. 
				Du besiegst sie leichtfertig und nimmt ihnen das Gestohlene Gold wieder ab.
			");
	
					$session['user']['deutung']=5; //Das M�dchen spricht die Wahrheit
			break;
	
	case 6:
	
	output("	`6Du wirst einen Pfad im folgen. Du triffst auf ein M�dchen in einem blauen Kleid. Sie erz�hlt dir unter Tr�nen von einer R�uberbande die hinter der n�chsten Abbiegung Rechst ihr Lager haben.
				`n Sie erz�hlt auch, das all ihr Gold abgenommen wurde und rennt dann in richtung Dorf davon. Du gehst weiter und kommst an die Weggablung, du gehst den Rechten Weg und der Boden gibt mitten 
				auf dem Weg nach. Du f�llst in ein Loch und wirst von den R�ubern �berw�ltigt, sie nehmen dir Gold und Edelsteine ab, du h�rst dabei das M�dchen wie es lacht.
			");
	
	
					$session['user']['deutung']=6; //Das M�dchen l�gt
			break;
	
	case 7:
	
	output("	`6Auf einer Lichtung wirst du auf einen Kobolt treffen. Er bietet dir eine Schwarze hei�e fl��gkeit zum Trinken an, du trinkst wirst feststellen das du kurz nach dem Verzehr sch�ner werden wirst.
			");
	
					$session['user']['deutung']=7; //Der Kaffee macht sch�ner
			break;

	case 8:
	
	output("	`6Auf einer Lichtung wirst du auf einen Kobolt treffen. Er bietet dir eine Schwarze hei�e fl��gkeit zum Trinken an, du trinkst wirst feststellen das du sterben wirst. 
				In dem Getr�nk wird ein Gift gewesen sein.
			");
	
	
					$session['user']['deutung']=8; //Der Kaffee t�tet
			break;
			
			
			
	case 9:
	
	output("	`6Du triffst auf den Herr der Unterwelt `7Santino`6 er wird an eine art Altar stehen. Er hat mehre Pergamente ausgebreitet und scheint in �berlegeungen vertieft zu sein. 
				Du n�hrst dich ihm und und er bemerkt dich nicht. Du sprichst ihn auf die Pl�ne an und wirst ihm helfen, er wird dir dankbar sein.
			");
	
					$session['user']['deutung']=9;//Santinos Plan - Belohnung
					
			break;
			
	case 10:
	
	output("	`6Du triffst auf den Herr der Unterwelt `7Santino`6 er wird an eine art Altar stehen. Er hat mehre Pergamente ausgebreitet und scheint in �berlegeungen vertieft zu sein. 
				Du n�hrst dich ihm und und er bemerkt dich. Bevor du etwas sagen kannst wirst du dich im Rech der Schatten befinden.
			");
					$session['user']['deutung']=10;//Santinos Plan - Bestrafung
	
			break;
		}

	output("	`n`5Langsam erhebt `6Vessa`5 ihren Blick von der Kristallkugel und sieht dich wieder an. `6Die Sitzung ist vorbei, kommt wieder, wenn die Deutung sich erf�llt hat. `5 `n
				Vessa nimmt dir noch einen deiner Edelsteine ab und geleitet dich dann wieder in nach draussen.
			");
					
			addnav("Zur�ck");
			addnav("Ins Dorf","village.php");
	
Die Datei ins Rootverzeichniss hochladen, wie auch die dragon.php wenn ver�ndert.
Die datei deutung.php in den specials ordner kopieren

SQL:
ALTER TABLE `accounts` ADD `deutung` INT( 10 ) NOT NULL DEFAULT '0' COMMENT 'Deutung der Zigeunerin';
ausf�hren und der Einbau ist fertig.

    ########################################################################
    ########################################################################
    ###                                                                  ###
    ###  ####    ######  ######  ####    ######  ###   #  ######  #####  ###
    ###  ## ##   ##  ##  ##  ##  ## ##   ##  ##  ####  #  ##  ##  ##     ###
    ###  ##  ##  ######  #####   ##  ##  ######  ## ## #  ##  ##  #####  ### 
    ###  ## ##   ##  ##  ##  ##  ## ##   ##  ##  ##  ###  ##  ##     ##  ###
    ###  ####    ##  ##  ##  ##  ####    ##  ##  ##   ##  ######  #####  ###
    ###                                                                  ###
    ########################################################################
    ########################################################################  //By Andarrius �Andarrius2010
	
	
Da auf dem Server Dardanos kein Ramius das Werk verrichtet, solltet ihr noch nach `7Santino`2 suchen und es mit `4Ramius`2 ersetzten!
*/
require_once "common.php";


page_header("Die Deutung");
if (!isset($session)) exit();
if ($_GET[op]==""){

output("`c`b`2Der Wald`b`c");
	$session['user']['specialinc'] = "deutung.php";
	if($session[user][deutung]==0){
	$deutung = e_rand(1,10);
	
	}else{
		$deutung = ($session[user][deutung]);}
		switch ($deutung)
		{
		case 1:
		case 2:
	output("	`2Du schleichst durch den Wald, als dich ein Ger�usch zum Stillstand ermahnt. Du blickst dich um und kannst erkennen das einer der B�sche eingeknickt ist.
				Du n�hrst duch dem Busch und sp�hst in den Wald, dort siehst du einen kr�ftigen `GTroll`2 der sich grade den R�cken an einem Baum kratzt. Er hat dich nicht bemerkt.
				`nWas tust du?
			");

			break;
				
		case 3:
		case 4:
	output("	`2Du streifst durch den Wald und st��t auf einen steinigen Pfad. Du fragst dich wo dieser wohl hinf�hrt und beginnst diesen zu folgen, bis dieser zu einer `GH�ngebr�cke`2 f�hrt.
				`nDie Br�cke sieht noch gut aus, wenn auch schon etwas �lter.
				`nWas tust du?
			");

			break;
			
		case 5:
		case 6:
	output("	`2Du folgst einen Pfad. Als du ein Weinen h�hrst drehst du dich um,.da steht ein `GM�dchen in einem blauen Kleid`2. Sie erz�hlt dir unter Tr�nen von einer R�uberbande die hinter der n�chsten 
				Abbiegung Rechst ihr Lager haben. Sie erz�hlt auch, das all ihr Gold abgenommen wurde und rennt dann in richtung Dorf davon. Du gehst weiter und kommst an die Weggablung.
				`nWas rust du?
			");

		
			break;
		case 7:
		case 8:
		
	output("	`2Als du durch den Wald streifst f�llt dir eine Lichtung auf, du betrittst diese und am Rande sitzt ein `GKobolt`2. Er ruft dich n�her und reicht dir eine Tasse mit einem schwarzen Getr�nk, 
				es ist sehr hei�.
				`nWas tust du?
			");
	
			break;
			
		case 9:
		case 10:
		
	output("	`2Als du durch den Wald strefist f�llt dir eine Gestalt auf einer Lichtung auf. Du fragst dich ob du dich der Gestalt n�hern solltest oder lieber doch gehen solltest. 
				Diese `GGestalt`2 scheint an einer art Altar zu stehen, wo einige Pergamente drauf liegen.
				`nWas tust du?
			");
		
	}
		
		addnav("Der Wald");
		addnav("Sich trauen","forest.php?op=deuten$deutung");
		addnav("Schnell verschwinden","forest.php?op=fluechten");
	
	

	}else if ($_GET[op]=="fluechten"){
	
	output("`2Dir ist das ganze nicht geheur und du gehst lieber wieder den Weg weiter.");
	
		addnav("In den Wald zur�ck","forest.php");
			$session['user']['specialinc']="";
if($session[user][deutung]>0){
			$session['user']['deutung'] = 0;}
}else if ($_GET[op]=="deuten1"){
	
	$gems = e_rand(10,30);
	
	output("	`2Du ziehst deine Waffe und tritts dem Troll gegen�ber, schnell und leichfertig hast du ihn besiegt. Dein Blick schweift weiter und hinter dem Troll liegt ein kleines Leinenb�ndel 
				`nDu �ffnest das Beutelchen und findest da drin `b`v".$gems."`2`b Edelsteine.
			");
	
			$session['user']['specialinc']="";
			$session['user']['gems']+=$gems;
			$session['user']['deutung'] = 0;
	
	
		addnav("In den Wald zur�ck","forest.php");
		
}else if ($_GET[op]=="deuten2"){


	output("	`2Du ziehst deine Waffe und tritts dem Troll gegen�ber, doch er sieht dich zu fr�h, greift nach seiner Keule die er hinter dem Baum hatte und schl�gt dich binnen einen Augenschlages zu Brei.
			");

			
			$session['user']['specialinc']="";
			$session['user']['deutung'] = 0;
			$session['user']['alive']=false; 
			$session['user']['hitpoints']=0; 
            
			
		addnav("`4T�gliche News`0","news.php");


}else if ($_GET[op]=="deuten3"){

	output("	`2Du trittst auf die Br�cke, sie scheint noch immer gut zu halten und beschlie�t die Br�cke zu �berqueren. Auf der h�lfte deines Weges h�rst du ein lautes knacken und du siehst wie 
				die Haltepfeiler der Br�cke auf der gegen�berliegenden Seite wegbrechen. Die Br�cke f�llt in sich zusammen und zieht dich mit in die Tiefe. Du Stirbst und verlierst all dein Gold.
			");
	
			$session['user']['specialinc']="";
			$session['user']['deutung'] = 0;
			$session['user']['alive']=false; 
			$session['user']['hitpoints']=0;
			$session['user']['gold']=0;

		addnav("`4T�gliche News`0","news.php");
		
		
}else if ($_GET[op]=="deuten4"){

	$gold = e_rand(1000,20000);
		output("	`2Du trittst auf die Br�cke, sie scheint noch immer gut zu halten und beschlie�t die Br�cke zu �berqueren. Auf der h�lfte deines Weges h�rst du ein lautes knacken und dir wird mulmig 
					doch die Bretter und Pfeiler halten. Du kommst heil auf der anderen Seite an und erst jetzt kannst eine Truhe erkennen die leicht absch�ssig an einem H�gel steht. 
					`n Du �ffnest die Truhe und bekommst `v".$gold." `2Goldst�cke.
				");

			$session['user']['specialinc']="";
			$session['user']['gold']+=$gold;
			$session['user']['deutung'] = 0;
	
	
		addnav("In den Wald zur�ck","forest.php");
		
		}else if ($_GET[op]=="deuten5"){
		
		$gold = e_rand(1000,20000);
		output("	`2Du gehst den Rechten Weg und triffst nur wenig marsch weiter auf das Lager der R�uber. Du besiegst sie leichtfertig und nimmst ihnen das gestohlene Gold wieder ab. 
					Du gehst deinen Weg nun etwas reicher weiter, du hast `b`v".$gold."`2`b Goldst�cke bekommen.
				");
		
			$session['user']['specialinc']="";
			$session['user']['gold']+=$gold;
			$session['user']['deutung'] = 0;
	
	
		addnav("In den Wald zur�ck","forest.php");
		
		
		}else if ($_GET[op]=="deuten6"){
		
		output("	`2Du gehst den Rechten Weg und nur wenig marsch sp�ter beginnt der Boden unter deinen F��en wegzusacken. Du bist eine falle der R�uber gefallen. Die Bande raubt dich aus und du verlierst 
					alles Gold und alle Edelsteine die du bei dir hattest. Du h�rst noch wie das M�dchen lacht, naja zumindest Lebst du noch.
				");
		
			$session['user']['specialinc']="";
			$session['user']['gold']=0;
			$session['user']['gems']=0;
			$session['user']['deutung'] = 0;
	
	
		addnav("In den Wald zur�ck","forest.php");
		
		}else if ($_GET[op]=="deuten7"){
		
		$charm = e_rand(50,200);
		output("	`2Du nimmst einen Schluck von diesem seltsamen Getr�nk. `vEs ist Kaffee`2 sagt der Kobolt zu dir und du f�hlst dich als w�rst du sch�ner geworden, um `b`v".$charm."`b`2 Charmepunkten. 
				");
		
			$session['user']['specialinc']="";
			$session['user']['charm']+=$charm;
			$session['user']['deutung'] = 0;
	
	
		addnav("In den Wald zur�ck","forest.php");
		
		
		}else if ($_GET[op]=="deuten8"){
		
		output("	`2Du nimmst einen Schluck von diesem Getr�nk als der Kobolt zu lachen anf�ngt, es ist ein s�ndhaftes Lachen. Als du schon merkst wie dir vor den Augen Schwarz wird, du bist gestorben.
				");
		
			$session['user']['specialinc']="";
			$session['user']['deutung'] = 0;
			$session['user']['alive']=false; 
			$session['user']['hitpoints']=0;

		addnav("`4T�gliche News`0","news.php");
		
		}else if ($_GET[op]=="deuten9"){
		
		$gefallen = e_rand(30,110);
		output("	`2Du tritts n�her an die Gestalt, es ist `7Santino`2 Herr der Unterwelt. Du sp�hst ihm �ber die Schulter und erkennst Pl�ne wo der Name Binky und Prain durchgestrichen sind und Santino dr�ber geschrieben 			 					wurde, du hilfst `7Santino`2 bei den Pl�nen und er erstattet dir `b`v".$gefallen."`b`2 Gefallen
				");
		
			$session['user']['specialinc']="";
			$session['user']['deathpower']+=$gefallen;
			$session['user']['deutung'] = 0;
	
	
		addnav("In den Wald zur�ck","forest.php");
		
		}else if ($_GET[op]=="deuten10"){
		
		output("	`2Du tritts n�her an die Gestalt, es ist `7Santino`2 Herr der Unterwelt. Du sp�hst ihm �ber die Schulter doch schon im n�chsten moment sp�rst wie `7Santino`2 dir das Leben aus deinem K�rper zieht.
				");
		
			$session['user']['specialinc']="";
			$session['user']['deutung'] = 0;
			$session['user']['alive']=false; 
			$session['user']['hitpoints']=0;

		addnav("`4T�gliche News`0","news.php");
}	
page_footer();
?>