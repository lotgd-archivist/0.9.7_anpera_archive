<?php
// translator ready
// mail ready
// addnews ready
// mail ready
rawoutput("<script language='JavaScript' src='lib/e_dom.js'></script>");
?>
