<?php
/**********************************************
*Diese Box darf nicht entfernt werden!        *
*-------------------------------------        *
*Geheime Karte von Hadriel                    *
*www.anaras.ch                                *
*Ben�tigt Waldspecialeditor von deZent|draKarr*
**********************************************/

if($_GET[op]=="" || $_GET[op]=="search"){
  $session[user][specialinc]="";
  output("Auf deinen Streifz�gen durch den Wald entdeckst du eine Karte des Waldes.");
  $sql_="SELECT"
       ." filename,name"
       ." FROM"
       ." waldspecial"
       ." WHERE"
       ." filename!='specmap.php'"
       ." AND"
       ." name!='kein Name vorhanden'"
       ." ORDER BY"
       ." name ASC;";
  $sql=db_query($sql_);
  if(db_num_rows($sql)){
      output(" Du entdeckst einige Kreuze auf der Karte.");
    output("`nWohin soll der Weg gehen?`n`n");
        while($row = db_fetch_assoc($sql)){
          output("<a href='forest.php?specialinc=".$row[filename]."'>".$row[name]."</a>`n",true);
          addnav("","forest.php?specialinc=".$row[filename]."");
          }
     }else{
       output(" Leider ist die Karte so zerfleddert, dass du nichts entdecken kannst");
  }
addnav("Zur�ck in den Wald","forest.php");
}

?>