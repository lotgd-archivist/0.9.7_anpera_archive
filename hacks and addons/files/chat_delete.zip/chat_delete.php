<?php
/**
 *	chat_delete.php
 * 	by Auric @ Tharesia.de
 *	Wird f�r "Letzten Post L�schen"-Hack ben�tigt.
 *	Im LotgD-Root abzulegen.
 */
require_once "common.php";
$nsql = "
			SELECT commentid,`comment`
			FROM `commentary`
			WHERE `author` = ".$session[user][acctid]."
			AND `section` = '$_GET[section]'
			ORDER BY postdate DESC
			LIMIT 1
			";
$ausgabe=db_fetch_assoc(db_query($nsql));
$nsql2 = "DELETE FROM `commentary` WHERE commentid = ".$ausgabe['commentid'];
db_query($nsql2);
$return = $_GET["return"];
redirect($return);
?>