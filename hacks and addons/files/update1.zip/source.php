<?php
/**
 * @desc Quellcode Ansicht von Alucard
 * @longdesc Die Source.php zeigt nur noch explizit freigegebene Dateien an und sieht h�bscher aus als das Original.
 * @author Alucard
 * @version V1.0 for DS v2.5
 * @copyright Alucard for Atrahor.de (2006)
 */

/**
 * Standard File einbinden
 */
require_once 'common.php';

/**
 * Erlaubte Dateien
 */
$legal_files = array(
	'about.php',
	'academy.php',
	'alchemie.php',
	'armor.php',
	'avatars.php',
	'badnav.php',
	'bank.php',
	'barber.php',
	'battle.php',
	'battlesimulator.php',
	'battlearena.php',
	'beggar.php',
	'bordello.php',
	'bullfight.php',
	'castle.php',
	'coffeehouse.php',
	'dag.php',
	'demouser.php',
	'dorfamt.php',
	'dragonmind.php',
	'dressmaker.php',
	'flowers.php',
	'forest.php',
	'friedhof.php',
	'frogs.php',
	'gardens.php',
	'graveyard.php',
	'gypsy.php',
	'healer.php',
	'hexe.php',
	'hof.php',
	'immo_board.php',
	'index.php',
	'inn.php',
	'invhandler.php',
	'library.php',
	'list.php',
	'logdnet.php',
	'login.php',
	'logs.php',
	'lottery.php',
	'mail.php',
	'mazemonster.php',
	'memory.php',
	'motd.php',
	'namegenerator.php',
	'nerwen.php',
	'newgiftshop.php',
	'news.php',
	'olddrawl.php',
	'ooc.php',
	'outhouse.php',
	'petition.php',
	'pool.php',
	'pranger.php',
	'pressarm.php',
	'pvp.php',
	'pvparena.php',
	'racesspecial.php',
	'rebirth.php',
	'referers.php',
	'referral.php',
	'registratur.php',
	'reload_stop.php',
	'rock.php',
	'rundreise.php',
	'schnapper.php',
	'setnewday.php',
	'shades.php',
	'shades_bonestacker.php',
	'shrine.php',
	'slums.php',
	'stables.php',
	'stonesgame.php',
	'styx.php',
	'tempel.php',
	'tittytwister.php',
	'todolist.php',
	'train.php',
	'treeoflife.php',
	'user.php',
	'vacation.php',
	'village.php',
	'virgator.php',
	'waldlichtung.php',
	'weapons.php',
	'weihnachtskalender.php',
	'weihnachtsmarkt.php',
	'well.php',
	'whitewall.php',
	'wolkeninsel.php',

	//////////
	//Specials
	//////////

	'alter.php',
	'aphrodite.php',
	'audrey.php',
	'beleidgterpirat.php',
	'bellerophontes.php',
	'bregomil.php',
	'bridge.php',
	'bumpiness.php',
	'bushes.php',
	'cairn.php',
	'calevents.php',
	'castle.php',
	'charlie.php',
	'cliff.php',
	'cookies.php',
	'cruxis.php',
	'darkhorse.php',
	'deadmask.php',
	'derfremde.php',
	'distress.php',
	'donation.php',
	'eaoden.php',
	'edelsteinbrunnen.php',
	'fairy1.php',
	'findgem.php',
	'findgold.php',
	'findtreasure.php',
	'flowerfield.php',
	'forest_portal.php',
	'forestchurch.php',
	'forestlake.php',
	'frogger.php',
	'gardens_gardensea.php',
	'gladiator.php',
	'glowingstream.php',
	'goblin.php',
	'goldenegg.php',
	'goldmine.php',
	'graeultat.php',
	'grassyfield.php',
	'gruft.php',
	'hase.php',
	'healer_special.php',
	'herdsman.php',
	'jewelrymaker.php',
	'kleineswesen.php',
	'kubus.php',
	'kudzu.php',
	'lake.php',
	'liana.php',
	'magicdoor.php',
	'may.php',
	'moocher.php',
	'mud.php',
	'necromancer.php',
	'ogre.php',
	'oldmanbet.php',
	'oldmanpretty.php',
	'oldmantown.php',
	'oldmanugly.php',
	'pig.php',
	'poisen.php',
	'race.php',
	'randdragon.php',
	'randomyom.php',
	'ranger.php',
	'remains.php',
	'riddles.php',
	'riverbath.php',
	'sacrificealtar.php',
	'schimaere.php',
	'searchdwarfs.php',
	'skillmaster.php',
	'slump.php',
	'smith.php',
	'statue.php',
	'stiefel.php',
	'stonehenge.php',
	'stumble.php',
	'surprise.php',
	'tarot.php',
	'tempel.php',
	'terronville.php',
	'time.php',
	'towel.php',
	'trapper.php',
	'trunktrap.php',
	'uhr.php',
	'vampire.php',
	'waldmaer.php',
	'wanderleute.php',
	'wannabe.php',
	'waterfall.php',
	'weather.php',
	'whitelilies.php',
	'wolves.php',
);

$illegal_files = array('dbconnect.php','su_sourceedit.php','source.php');

$url=$_GET['url'];
if(strpos($url,'://')!=0)
{
	redirect('index.php','Cheatversuch in Source.php');
}
$dir = str_replace("\\","/",dirname($url)."/");

$subdir='/';

$legal_dirs = array(
	array('dir'=>$subdir,'td'=>1),
	array('dir'=>$subdir.'special/','td'=>1),
);

//User die den Sourcecode sehen d�rfen, bekommen noch ein paar andere Ordner angezeigt
if($access_control->su_check(access_control::SU_RIGHT_SOURCEVIEW))
{
	$legal_dirs[] = array('dir'=>$subdir.'lib/','td'=>0);
	$legal_dirs[] = array('dir'=>$subdir.'item_modules/','td'=>0);
	$legal_dirs[] = array('dir'=>$subdir.'houses_modules/extensions/','td'=>0);
	$legal_dirs[] = array('dir'=>$subdir.'houses_modules/builds/','td'=>0);
	$legal_dirs[] = array('dir'=>$subdir.'module/specialty_modules/','td'=>0);
	$legal_dirs[] = array('dir'=>$subdir.'module/boss_modules/','td'=>0);
	$legal_dirs[] = array('dir'=>$subdir.'lib/classes/','td'=>0);
}


//popup_header('Quellcode der Dragonslayer-Edition');
$str_out = '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html><head><title>Quellcode der Dragonslayer-Edition</title><link href="./templates/atrahor_main_styles.css" rel="stylesheet" type="text/css"><style type="text/css">
					@import url(templates/colors.css);
				</style></head><body bgcolor="#000000" text="#CCCCCC"><table cellpadding=5 cellspacing=0 width="100%"><tr><td class="popupheader"><b>Quellcode der Dragonslayer-Edition</b></td></tr><tr><td valign="top" width="100%">';

$str_out .= '`c`b`&Quellcode der Dragonslayer-Edition: '.GAME_VERSION.'`0`b`c`n`n';
$str_out .= 'Anmerkung: Dies ist nur ein Auszug aus dem Source. Ein etwas �lteres, abgespecktes Release der Dragonslayer-Edition ist f�r jeden Interessenten frei zum <a href="http://www.atrahor.de/source/">Download</a> verf�gbar. 
Was wir uns unbedingt verbitten, ist Diebstahl unserer Arbeit
ohne Nennung des Copyrights.`n
Falls beim Lesen des Source ein Bug entdeckt werden sollte, bitten wir um sofortige Meldung per Anfrage!`n`n';

if($session['message'] != '') {
	output('`n`b'.$session['message'].'`b`n`n');
	$session['message'] = '';
}

function in_dir( $dir ){
	global $legal_dirs;
	foreach($legal_dirs as $d){
		if( $d['dir'] == $dir ){
			return 1;
		}
	}
	return 0;
}

switch($_GET['op'])
{
	case 'show':
		$file = urldecode($_GET['file']);
		$subdir = str_replace("\\","/",dirname($_SERVER['SCRIPT_NAME'])."/");
		$file = str_replace($subdir,'/',$file);
		$check = preg_replace('/(.*?)\//','',$file);
		$dir = str_replace( $check, '', $file );
		$file = '.'.$file;


		$str_out .= '`n`c`&`b'.$file.'`b`c`n';
		$str_out .= '<a href="source.php">zur�ck</a>`n';
		if(($access_control->su_check(access_control::SU_RIGHT_SOURCEVIEW) == true || (in_array($check, $legal_files )) && in_dir( $dir )) && !in_array( $check, $illegal_files ))
		{
			$buffer = highlight_file( $file, true );

			$buffer = str_mask_email($buffer);

			$rows = count(explode('<br />',$buffer));
			$znr = '';
			for($i=1; $i <= $rows; $i++) {
				$znr .= "$i:<br />";
			}
			$buffer = '<code><nobr>'.$buffer.'</nobr></code>';
			$str_out .= '<table style="width: 100%;padding:0px;margin:0px;" cellspacing="0">
							<tr>
								<td style="text-align: right; width: 25px; background: #AFAFAF; border-right: 1px solid #000000;">
									<code><nobr>'.$znr.'</nobr></code>
								</td>
								<td style="background: #EFEFEF;" valign="top">';
			output($str_out);
			$output .= $buffer;
			$str_out =			'</td>
							</tr>
						</table>';
		}
		else
		{
			$str_out .= '`4`b<big><big>Datei kann nicht angezeigt werden!</big></big>`b`n';
		}
	break;



	// Standardansicht, Auswahl
	default:
		$session['disablevital'] = false;
		$files = array();
		foreach( $legal_dirs as $curr_dir ){
			$d 		  = dir('./'.$curr_dir['dir']);
			$files[$curr_dir['dir']] = array();
			while (false !== ($entry = $d->read())) {
				$end = substr($entry,strrpos($entry,"."));
				if( $end != '.php' && $end != '.lib.php' && $end != '.inc.php' ){
					continue;
				}
				if( in_array( $entry, $illegal_files ) ){
					continue;
				}
				array_push($files[$curr_dir['dir']],$entry);

			}
			sort($files[$curr_dir['dir']]);
		}


		$str_out .= '`c<table cellspacing="2" cellpadding="2"><tr>';
		$lasttd = 1;
		foreach( $legal_dirs as $curr_dir ){
			if( $lasttd ){
				$str_out .= '<td valign="top"><table cellspacing="2" cellpadding="2">';
			}
			$str_out .= '<tr class="trhead"><th colspan="2">.'.$curr_dir['dir'].'</th></tr>';
			$style='';
			foreach( $files[$curr_dir['dir']] as $file ){
				if($access_control->su_check(access_control::SU_RIGHT_SOURCEVIEW) == false)
				{
					if( !in_array( $file, $legal_files ) )
					{
						continue;
					}
				}
				$style = ($style == 'trlight' ? 'trdark' : 'trlight');

				$showlink = 'source.php?op=show&amp;file='.urlencode($curr_dir['dir'].$file);


				$str_out .= '<tr class="'.$style.'">
								<td nowrap><a href="'.$showlink.'">'.$file.'</a></td>
							</tr>';
			}
			//$str_out .= '';
			if( $curr_dir['td'] ){
				$str_out .= '</table></td>';
			}
			$lasttd = $curr_dir['td'];
		}
		$str_out .= '</tr></table>`c';

		break;

}
$str_out .= '</td></tr>
		</table>
		<center>'.GAME_VERSION.'</center>
	</body>
</html>';
output($str_out);
echo $output;
?>