<?php
/*
Weihnachtsmarkt
Urspr�nglich f�r: isarya-logd.de.vu von Naria Talcyr
Idee: Nymh, Inistha, Rhao
Texte: Jezebel, Nymh

Features:
- Geb�ck kaufen
- Getr�nke kaufen
- Schlittschuhe ausleihen, um zum gefrorenem See zu kommen (neuer RP Ort)
- Geb�ck verschicken (+Nachricht)
- Geschenk vom Weihnachtsbaum nehmen

Geplant:
-/-

Auszuf�hrende SQL:
ALTER TABLE `accounts` ADD `special_taken` TINYINT ( 1 ) UNSIGNED NOT NULL DEFAULT '0';

*/
require_once "common.php";

addcommentary();

//Sachen f�r den Gl�hweinstand, einfach eintragen, f�gen sich selber hinzu
$drinks=array(
                'gluh'=> array('name'=>'Gl�hwein','price'=>150)
                ,'apfel'=>array('name'=>'hei�en Apfelwein','price'=>200)
                ,'met'=>array('name'=>'warmes Met','price'=>100)
                );

//Sachen f�r den Geb�ckstand, einfach eintragen, f�gen sich selber hinzu         
$kekse=array(
                'lebherz'=> array('name'=>'Lebkuchenherzen','price'=>50,'send'=>'ein Lebkuchenherz')
                ,'zimt'=>array('name'=>'Zimtsterne','price'=>50,'send'=>'eine Packung Zimtsterne')
                ,'lebhaus'=>array('name'=>'ein Lebkuchenhaus','price'=>200,'send'=>'ein Lebkuchenhaus')
                ,'schokokeks'=>array('name'=>'Schokoladenkekse','price'=>75,'send'=>'eine Packung Schokoladenkekse')                
                ,'printen'=>array('name'=>'Printen','price'=>60,'send'=>'eine Handvoll Printen')       
                ,'mandel'=>array('name'=>'gebrannte Mandeln','price'=>30,'send'=>'ein Beutel gebrannter Mandeln')
                ,'zucker'=>array('name'=>'eine Zuckerstange','price'=>20,'send'=>'eine Zuckerstange')          
                );
                
//Preis f�rs Schlittschuhlaufen
$schlittschuh=10; 

//Spieler pro Seite
$player=20;

//Geschenkmenge
$gold=3000;
$gems=10;
$charme=100;

switch($_GET['op']){
case 'see':
    page_header('Der gefrorene See');
    output('`c`b`9De`�r g`Wef`ororene `kSee`b`c`n`n`oFr�hlich fast glitzert die Eisdecke auf dem Gro�en See des Dorfes. Auf der festen Schicht sind kleine Linien zu sehen, verursacht durch '
                .'Eisenschienen, befestigt an ledernen Schuhen, die die Kinder tragen, wenn sie sich auf das Eis wagen um ihre Runden zu fahren.`nDoch ihr irrt euch, denkt ihr, dass nur '
                .'Kinder sich diesen Spa� erlauben. So manches Liebespaar zieht gemeinsam seine Kreise aber auch Freunde sind zusammen auf dem spiegelglatten Eis unterwegs, '
                .'lachen ausgelassen. Schlie� dich doch ihnen an!');
    viewcommentary('gefrorener See','`n`n`n`�Lachen und Scherzen:`n`n',15);
    addnav('Wege');
    addnav('Weihnachtsmarkt','weihnachten.php');
    addnav('Zur�ck ins Dorf','village.php');
    addnav('');
    addnav('+?Aktualisieren','weihnachten.php?op=see');

break;
case 'schlittschuh':
    page_header('Schlittschuhe');
    switch($_GET['act']){
    case 'ausleihen':
             if($session['user']['gold']>=$schlittschuh){
            output("`kDu suchst dir ein Paar aus und bezahlst die Verleihgeb�hr von `^".$schlittschuh." `0direkt. Du l�ufst mit dem Paar zum See, setzt dich auf eine Bank und ziehst sie an. "
            ."Ein wenig wackelig kommst du dir vor, doch wagst du dich dennoch aufs Eis`n");
            $session['user']['gold']-=$schlittschuh;
            addnav('Zum See','weihnachten.php?op=see');     
            }else{
            output("`kDu suchst dir ein Paar aus,doch als du bezahlen sollst, f�llt dir auf, dass du zu wenig Gold dabei hast. Das war wohl nichts mit einer Runde "
            ."Runde Schlittschuhlaufen.");
            addnav('Wege');     
            addnav('Weihnachtsmarkt','weihnachten.php');
            addnav('Zur�ck ins Dorf','village.php'); 
            }

    break;
    default:
        output('`c`b`&Sc`khl`Sit`)ts`7ch`Kuhe`b`c`n`n`kKinder dr�ngen sich an dir vorbei, lachend und ausgelassen rennend, in den H�nden Schlittschuhe haltend, mit  denen sie in Richtung '
                    .'des gefrorenen Sees davon laufen um darauf, wie es bereits schon viele andere tun, ihre  Runden zu drehen. L�chelnd siehst du ihnen dabei zu, wie sie sich die Schuhe anziehen '
                    .'und dann auf dem Eis erst  wackelig zum stehen kommen um sogleich flink ihre Runden zu drehen.`n"Wollt Ihr auch Eure Runden auf dem Eis drehen?" Eine rauhe Stimme l�sst '
                    .'dich den Blick abwenden und auf eine kleine Holzh�tte blicken, in der ein Zwerg steht, an der Wand hinter ihm h�ngen Schlittschuhe, in allen erdenklichen Gr��en.  "F�r ein kleines '
                    .'Entgeld leihe ich dir eines meiner Schlittschuhpaare!" Die Stirn gerunzelt �berlegst du, ob du das Angebot annehmen sollst.');
        addnav('Ausleihen - `^'.$schlittschuh.' Gold`0','weihnachten.php?op=schlittschuh&act=ausleihen');
            //Navigation
        addnav('Wege');
        addnav('Weihnachtsmarkt','weihnachten.php');
        addnav('Zur�ck ins Dorf','village.php');
    break;    
    }//switch act end
break;
case 'geback':
    page_header('Geb�ckstand');
    switch($_GET['act']){
    case 'send':
            if(isset($_POST['message'])){
                if($session['user']['gold']>=$kekse[$_GET['eat']]['price']){
                   output("Du suchst dir ".$kekse[$_GET['eat']]['name'] ." aus und bezahlst direkt. Dann wird es schon einem Boten �bergeben, der sich aufmacht das Paket zum Empf�nger zu bringen.`n");
                   $session['user']['gold']-=$kekse[$_GET['eat']]['price'];
                   $message='Ein in goldene Papier eingeschlagenes Paket wird dir von einem Boten �berreicht. Neugierig geworden, packst du es aus. Es ist etwas vom '
                                         .'Weihnachtsmarkt,'.$kekse[$_GET['eat']]['send'].'.'; 
                   if($_GET['eat']!='lebherz')$message .=  '`n`nEinige Worte sind auf einem Zettel dabei geschrieben: `n`n';
                   else $message .=  '`n`nEinige Worte sind mit Zuckerschrift auf diese geschrieben.: `n`n';
                   $message .= strip_tags(trim($_POST['message']));
                   $message .= '`n`nFrohes Fest';
                   $to=(int)$_GET['to'];
                   $from = $session['user']['acctid'];
                   systemmail($to,'`4Etwas vom Weihnachtsmarkt',$message,$from);
                   addnav('Zum Markt','weihnachten.php');
                }else{
                    output("Du suchst dir ".$kekse[$_GET['eat']]['name']." aus,doch als du bezahlen sollst, f�llt dir auf, dass du zu wenig Gold dabei hast. Das war wohl nichts mit einem "
                    ."leckeren Geb�ckst�ck.");
                    addnav('Zum Markt','weihnachten.php');
                }    
            }else{
                if($_GET['eat']=='lebherz') output('Willst du etwas auf dein Lebkuchenherz schreiben lassen?');
                else output('Willst du eine Nachricht mitschicken?');
                output('`n`nNachricht(max. 50 Zeichen):');
                rawoutput('<br><br><form action="weihnachten.php?op=geback&act=send&eat='.$_GET['eat'].'&to='.$_GET['to'].'" method="POST">'
                             .'<input name="message" class="input" maxlength=50><input type="submit" class="button" value="Verschicken"></form><br>');
                addnav('',"weihnachten.php?op=geback&act=send&eat=".$_GET['eat'].'&to='.$_GET['to']);
                addnav('Zum Markt','weihnachten.php');
            }//$_POST['message'] end
    break;
    case 'ask':
            output("Du suchst dir ".$kekse[$_GET['eat']]['name']." aus. Was willst du nun damit tun? Jemandem schicken oder selber essen? `n`n");
            rawoutput('<br><br><form action="weihnachten.php?op=geback&act=ask&eat='.$_GET['eat'].'&to='.$_GET['to'].'" method="POST">'
                             .'<input name="name" class="input"><input type="submit" class="button" value="Suchen"></form><br>');
           addnav('',"weihnachten.php?op=geback&act=ask&eat=".$_GET['eat'].'&to='.$_GET['to']);
            //Gesamtzahl aller angemeldeter Spieler bestimmen
            $anzahl=db_query("SELECT `acctid` FROM `accounts`");
            $ges=db_num_rows($anzahl);
        	$search="%";
	        for ($x=0;$x<strlen($_POST['name']);$x++){
		        $search .= substr($_POST['name'],$x,1)."%";
	        }
	        $search=" AND name LIKE '".addslashes($search)."' ";
            $result = db_query($sql) or die(sql_error($sql));
            $max = db_num_rows($result);  

            if($_GET['offset']!='' && ($_POST['name']=='' || $max<=0)){            
                $result=db_query("SELECT `name`,`acctid`,`login` FROM `accounts` WHERE locked=0 ORDER BY name,acctid ASC LIMIT ".$_GET['offset']." , ".$player);
            }else{
                $result=db_query('SELECT `name`,`acctid`,`login` FROM `accounts` WHERE locked=0 '.$search.' ORDER BY name,acctid ASC LIMIT 0,'.$player);
            }
            $zahl = db_num_rows($result);

            if($zahl>0){
                rawoutput('<table><tr class="trhead"><td>Name</td><td>Biographie</td></tr>');
                  //Spieler auflisten
                for($i=0;$i<$zahl;$i++){
                     $row=db_fetch_assoc($result);
                     rawoutput('<tr class="'.($i%2?"trdark":"trlight").'"><td>');
                     output("<a href='weihnachten.php?op=geback&act=send&eat=".$_GET['eat']."&to=".$row['acctid']."'>`&".$row['name']."`0</a>",true);
                     rawoutput('</td><td>');
                     output("<a href='bio.php?char=".urlencode($row['login'])."' target='_blank'>`6Biographie`0</a>",true);
                     rawoutput('</td></tr>');
                     addnav('',"weihnachten.php?op=geback&act=send&eat=".$_GET['eat']."&to=".$row['acctid']);
                }
                rawoutput('<table><br><br>'); 

                  
                 // Zur�ck Link                  
                if($_GET['offset']>0){
                     $offset=$_GET['offset']-$player;
                     if($offset<1)$offset=0;
                     rawoutput("<a href='weihnachten.php?op=geback&act=ask&eat=".$_GET['eat']."&offset=".$offset."'><|Vorherige Seite</a>");

                     addnav('',"weihnachten.php?op=geback&act=ask&eat=".$_GET['eat']."&offset=".$offset);
                }            
                  output('`& |----|`0');                
                 $offset=$_GET['offset']+$player;
                 //Vor Link
                if($_GET['offset']!='' && ($offset+1)<=$ges){
                     rawoutput("<a href='weihnachten.php?op=geback&act=ask&eat=".$_GET['eat']."&offset=".$offset."'>N�chste Seite|></a>");
                     addnav('',"weihnachten.php?op=geback&act=ask&eat=".$_GET['eat']."&offset=".$offset);
                }elseif(($offset+1)<=$ges){
                     rawoutput("<a href='weihnachten.php?op=geback&act=ask&eat=".$_GET['eat']."&offset=".$player."'>N�chste Seite|></a>");
                     addnav('',"weihnachten.php?op=geback&act=ask&eat=".$_GET['eat']."&offset=".$player);
                }                    
            }else{ //Keine Spieler gefunden $zahl<=0
                output('`4Keine Spieler gefunden, bitte dem Admin Bescheid geben');
            }        
            //Navigation
            addnav('Alle anzeigen',"weihnachten.php?op=geback&act=ask&eat=".$_GET['eat']);
            addnav('Selber essen',"weihnachten.php?op=geback&act=essen&eat=".$_GET['eat']);
           
    break;
    case 'essen':
            if($session['user']['gold']>=$kekse[$_GET['eat']]['price']){
                output("Du suchst dir ".$kekse[$_GET['eat']]['name'] ." aus und bezahlst direkt. Sorgf�ltig eingepackt wendest du dich wieder dem Markt zu, w�hrend du gen�sslich "
                ."beginnst zu essen.`n");
                $session['user']['gold']-=$kekse[$_GET['eat']]['price'];
            }else{
                output("Du suchst dir ".$kekse[$_GET['eat']]['name']." aus,doch als du bezahlen sollst, f�llt dir auf, dass du zu wenig Gold dabei hast. Das war wohl nichts mit einem "
                ."leckeren Geb�ckst�ck.");
            }    
                //Navigation
            addnav('Wege');
            addnav('Geb�ckstand','weihnachten.php?op=geback');    
            addnav('Weihnachtsmarkt','weihnachten.php');
            addnav('Zur�ck ins Dorf','village.php');
    break;
    default:  
    output('`c`b`sWe`wih`tna`Fch`6ts`^ge`Pb�`qck`b`c`n`n`F"Lebkuchenh�uschen, Pl�tzchen, oder einen Zimtstern?" Der Ruf erreicht dein Ohr noch bevor der feine Duft der K�stlichkeiten deine '
     .'Nase kitzeln k�nnen. Du h�lst bei deinem Streifzug �ber den Markt inne und schlenderst an den kleinen Verkaufsstand um vertr�umt die vielen K�stlichkeiten zu betrachten. ' 
     .'Lebkuchenh�uschen stehen da, mit wei�em Zuckerguss bedeckt und gar wunderbar verziert. Aber auch die Pl�tzchen, deren s��er Geruch nach Schokolade und Zimt in deine ' 
     .'Nase steigt, haben es dir angetan. Oder doch ein St�ck Gewurzkuchen, der gar lieblich angerichtet auf einem Teller auch dem Auge einen herrlichen Anblick bietet? Wenn du '
     .'etwas Geld in deiner Tasche hast, dann greif doch zu und kauf eines der k�stlichen Geb�cke.');
    addnav('Was suchst du dir aus?');
    //Auflistung der m�glichen Optionen
    foreach($kekse as $key=> $val){
    addnav("{$val['name']} - `^{$val['price']} Gold`0","weihnachten.php?op=geback&act=ask&eat=".$key);
    }
    //Navigation
    addnav('Wege');
    addnav('Weihnachtsmarkt','weihnachten.php');
    addnav('Zur�ck ins Dorf','village.php');
    break;
    }//switch act end
break;
case 'gluh':
    page_header('Gl�hweinstand');
    switch($_GET['act']){
    case 'trinken':
        if($session['user']['gold']>=$drinks[$_GET['drink']]['price']){
            output("Du bestellst dir ".$drinks[$_GET['drink']]['name'] ." und schon wird dir ein Becher gereicht mit dem Gew�nschten. Du legst das Gold auf die Theke und wendest dich "
            ." den anderen Leuten hier zu, um mit ihnen zu reden.`n");
            $session['user']['gold']-=$drinks[$_GET['drink']]['price'];
            }else{
            output("Du bestellst dir ".$drinks[$_GET['drink']]['name']." ,doch als du bezahlen sollst, f�llt dir auf, dass du zu wenig Gold dabei hast. Das war wohl nichts mit einem "
            ."leckeren Getr�nk.");
            }
            //Navigation
        addnav('Wege');
        addnav('Gl�hweinstand','weihnachten.php?op=gluh');    
        addnav('Weihnachtsmarkt','weihnachten.php');
        addnav('Zur�ck ins Dorf','village.php');

    break;
    default:
    output('`b`c`$Gl`4�h`Lwe`4in`$st`Na`Ind`c`b`n`n`IFein liegt der Duft nach Orangen, Zimt und Zitrone in der Luft, als du dich dem kleinen Stand n�herst, um welchen sich bereits eine '
                .'kleine Menschenmenge versammelt hat. Die Menschen halten T�nerne Becher in den H�nden. Dampf steigt aus ihnen hervor, der herrlich weihnachtlich duftet und deine '
                .'Nase kitzelt. Zu schmecken scheint das hei�e Gebr�u auch, nippen die Menschen doch gar gen�sslich an ihren Kr�gen.`nMit flinken Schritten schl�ngelst du dich an ein paar '
                .'der Menschen vorbei und trittst an die Theke des kleinen Standes. Der Verk�ufer l�chelt dir zu und schnappt sich einen der Kr�ge, wobei er dich erwartungsvoll ansieht. "Was '
                .'darf ich dir zu trinken anbieten. Ich habe vieles, was bei dem kalten Winterwetter den K�rper w�rmt." Mit einem Nicken wei�t er auf ein Schild, auf welchem mit wei�er '
                .'Kreide die verschiedenen Getr�nke geschrieben stehen, die im Angebot sind. Frohlockend betrachtest du die Liste und �berlegst, was du dir einverleiben sollst, '
                .'klingt doch alles wahrlich k�stlich.`0');
    addnav('Was willst du bestellen?');
    //Auflistung der m�glichen Optionen
    foreach($drinks as $key=> $val){
    addnav("{$val['name']} - `^{$val['price']} Gold`0","weihnachten.php?op=gluh&act=trinken&drink=".$key);
    }
        //Navigation
    addnav('Wege');
    addnav('Weihnachtsmarkt','weihnachten.php');
    addnav('Zur�ck ins Dorf','village.php');
    addnav('');
    addnav('+?Aktualisieren','weihnachten.php?op=gluh');
    
	viewcommentary('gluhweinstand','`n`n`6Ausgelassen reden:`n',15);
	break;
	}//switch act end
break;
case 'take':
    page_header('Der Weihnachtsbaum');
    if($session['user']['special_taken']!=1){
        output("`tDu n�herst dich dem Baum, streckst die H�nde nach einem Paket aus und nimmst es von dem Zweig, an dem es h�ngt. Einen Augenblick lang betrachtest du es noch "
                    ."beinahe ehrf�rchtig, dann packst du es aber auch schon aus.`n Es liegen `^".$gold." `0Goldst�cke darin und `#".$gems." `0Edelsteine.`n Deine Augen leuchten und "
                    ."zufrieden packst du dein Geschenk ein. Du f�hlst dich aus irgendeinem Grund wesentlich ansehnlicher nun, als ob dein Charme um `4".$charme."`0 Punkte gestiegen sei. "
                    ."Wenn sich sowas in Punkten messen lie�e.");
        $session['user']['gold']+= $gold;
        $session['user']['gems']+= $gems;
        $session['user']['charm']+= $charme;
        $session['user']['special_taken']=1;
    }else{
        output('`tJemand klopft dir auf die Finger, als du ein weiteres Paket nehmen willst. Nur ein warnender Blick von einer Wache und du wei�t, dass du es lieber unterl�sst.');
    }
    addnav('Wege');
    addnav('Zum Weihnachtsmarkt','weihnachten.php');
    addnav('Zur�ck','village.php');
break;
default:
    page_header('Weihnachtsmarkt');
    output('`c`b`lWe`pih`2na`ec`8h`Dts`Ima`Nrk`4t`b`c`n`n`2'
                .'Schon beim Betreten des Weihnachtsmarktes bemerkst du den edlen Baum, der wohlgeschm�ckt die Mitte des Platzes ziert, auf welchem sich die kleinen Buden dicht '
                .'aneinander dr�ngen. Engelshaar glitzer silbern im Licht, gro�e rote Kugeln, saftige �pfel und lebkuchenherzen sind an die Nadelbesetzten �ste gebunden, w�hrend rote '
                .'Kerzen das Tannengr�n in ein edles Licht tauchen. Viele Kindern haben sich hier versammelt, betrachten mit gro�en Augen den pr�chtigen Baum. Und jetzt, wo du n�her '
                .'herangetreten bist, entdeckst du die kleinen Pakete, die in dem Baum versteckt sind.`nTief atmest du die kalte Luft ein, w�hrend deine Schuhe knirschende Ger�usche im '
                .'Schnee verursachen. Von weitem dringt der Gesang von einem Kinderchor an deine Ohren. Doch deine Augen bleiben an dem Baum h�ngen. Einem jedem ist es erlaubt hier '
                .'ein Geschenk heraus zu nehmen. Aber streng nur eines!');
     //Navigation
    addnav('Aktionen');
    addnav('Geschenk vom Baum nehmen','weihnachten.php?op=take');
    addnav('Wege');
    addnav('Gl�hweinstand','weihnachten.php?op=gluh');
    addnav('Geb�ckstand','weihnachten.php?op=geback');
    addnav('Schlittschuhe leihen','weihnachten.php?op=schlittschuh');
    addnav('');
    addnav('Zur�ck','village.php');
break;
}//switch op end

rawoutput('<br><br><br><br><span style="font-size:x-small;  text-align: center;"><a href="http://www.isarya-logd.de.vu" target="_blank">&copy; Naria Talcyr (isarya-logd.de.vu)</a></span>');
checkday();
page_footer();
?>