<?php
/*
* Version:	20.09.2008
* Author:	Linus
* Email:	webmaster@alvion-logd.de
* Zweck:	Admintool f�r das Kindermod
*
*/

require_once("common.php");
isnewday(3);

function analyse(){
	$accts=array();
	$sql="SELECT `acctid` FROM `accounts`";
	$result=db_query($sql);
	while ($row = db_fetch_assoc($result)) {
		$accts[$i]=(int)$row['acctid'];
		$i++;
	}
	$sql="SELECT `mama`, `papa` FROM `kinder`";
	$result=db_query($sql);
	while ($row = db_fetch_assoc($result)) {
		if(in_array((int)$row['mama'],$accts) && in_array((int)$row['papa'],$accts)){
			$gut++;
		}elseif (in_array((int)$row['mama'],$accts)){
			if((int)$row['papa']>0) $fehler++;
			$fehlp++;
		}elseif (in_array((int)$row['papa'],$accts)){
			if((int)$row['mama']>0) $fehler++;
			$fehlm++;
		}else{
			if((int)$row['mama']>0 || (int)$row['papa']>0) $fehler++;
			$fehl++;
		}
		$j++;
	}

	return array($j, $gut, $fehl, $fehlp, $fehlm, $fehler );
}

page_header("Waise oder nicht?");

switch($_GET['op']){
	case "clean":
		$accts=array();
		$sql="SELECT `acctid` FROM `accounts`";
		$result=db_query($sql);
		while ($row = db_fetch_assoc($result)) {
			$accts[$i]=(int)$row['acctid'];
			$i++;
		}

		$sql="SELECT `id`, `mama`, `papa` FROM `kinder`";
		$result=db_query($sql);
		while ($row = db_fetch_assoc($result)) {
			if(in_array((int)$row['mama'],$accts) && in_array((int)$row['papa'],$accts)){
				$gut++;
			}elseif (in_array((int)$row['mama'],$accts)){
				if((int)$row['papa']>0){
					$fehler++;
					$fehlp++;
					db_query("UPDATE `kinder` SET `papa`=0 where `id`=".$row['id'].";");
				}
			}elseif (in_array((int)$row['papa'],$accts)){
				if((int)$row['mama']>0){
					$fehler++;
					$fehlm++;
					db_query("UPDATE `kinder` SET `mama`=0 where `id`=".$row['id'].";");
				}
			}else{
				if((int)$row['mama']>0 || (int)$row['papa']>0){
					$fehler++;
					$fehl++;
					db_query("UPDATE `kinder` SET `mama`=0, `papa`=0 where `id`=".$row['id'].";");
				}
			}
			$j++;
		}

		output("`@".$fehler." `7Fehler wurden korrigiert, bei `@$fehl `7Vollwaisen, `@$fehlm `7Kindern ohne Mutter und `@$fehlp `7Kindern ohne Vater!`n");
		addnav('Zur�ck','waisen_statistik.php');
	break;

	default:
		list($j, $gut, $fehl, $fehlp, $fehlm, $fehler)=analyse();
		if($fehler>0) addnav('Aufr�umen','waisen_statistik.php?op=clean');

		output("`@`b`cDie Kinderstatistik`c`b`n`n`7Anzahl Kinder gesamt: `@".$j."`n`7Kinder mit zwei Eltern: `@".$gut."`n`7Halbwaisen ohne Mutter: `@".$fehlm."`n`7Halbwaisen ohne Vater: `@".$fehlp."`n`7Vollwaisen`@".$fehl."`n`n`7Fehler in DB (IDs von gel�schten Spielern): `@".$fehler."`n");
	break;
}

addnav("G?Zur�ck zur Grotte","superuser.php");
addnav("W?Zur�ck zum Weltlichen","village.php");

output("`n<div align='right'>`72008 by Linus for alvion-logd.de/logd</div>",true);
page_footer();
?>