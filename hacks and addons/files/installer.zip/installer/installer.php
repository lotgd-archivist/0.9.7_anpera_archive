<?php
/* LoGD-Installer
2007 by Basilius Sauter
Version 0.1c
*/
header('Content-type: text/html; charset=UTF-8');
if(file_exists('dbconnect.php')) {
	die('Die Datei dbconnect.php existiert bereits. Lösche sie, um den Installer erneut laufen zu lassen.');
}

if(!is_writable('./')) {
	echo '<b style="color: red";>Das aktuelle Verzeichnis ist für PHP nicht Beschreibbar. Die generierte Datei ist deshalb als "dbconnect.php" im LoGD-Root abzuspeichern.</b>';
	$cannotwrite = true;
} else $cannotwrite = false;

if(!empty($_POST)) {
	if($_POST['dbpass'] !== $_POST['dbpassvalid']) {
		$force = true;
		echo "<br />Passwörter stimmen nicht überrein!";
	}
	else {
		$force = false;
	
	$DBNAME = $_POST['dbname'];
	$DBHOST = $_POST['dbhost'];
	$DBUSER = $_POST['dbuser'];
	$DBPASS = $_POST['dbpass'];
	$FILEGENERATED = date('Y-m-d H:i:s');
	
	$file = <<<PHPF
<?php
	// Automatisch generiert vom Installationsscript
	\$DB_NAME = "$DBNAME";
	\$DB_HOST = "$DBHOST";
	\$DB_USER = "$DBUSER";
	\$DB_PASS = "$DBPASS";
	\$FILEGENERATED = "$FILEGENERATED";
?>
PHPF;

	if($cannotwrite === true) {
		echo "<pre>".HTMLEntities($file)."</pre>";
	}
	else {
		$fp = fopen('dbconnect.php', 'w');
		fwrite($fp, $file);
		fclose($fp);
		
		echo "Datei erstellt!";
	}
	}
}
else $force = true;

if($force === true) {
	?>
	
	<form action="installer.php" method="POST">
		<label for="dbname">Name der Datenbank</label> <input type="text" id="dbname" name="dbname" /><br />
		<label for="dbhost">Host der Datenbank (Für gewöhnlich "localhost")</label> <input type="text" id="dbhost" name="dbhost" /><br />
		<label for="dbuser">Datenbankuser</label> <input type="text" id="dbuser" name="dbuser" /><br />
		<label for="dbpass">Passwort für den Datenbankuser</label> <input type="password" id="dbpass" name="dbpass" /><br />
		<label for="dbpassvalid">Passwort wiederhohlen</label> <input type="password" id="dbpassvalid" name="dbpassvalid" /><br /><br />
		
		<input type="submit" value="Weiter" />
	</form>
	<?php
}
?>