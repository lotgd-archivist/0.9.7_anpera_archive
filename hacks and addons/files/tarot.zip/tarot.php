<?php

//tarot.php
//(c) Sangreal
//Bankvorteil 2,098% - Es wird damit etwas Gold aus dem Spiel gezogen

//Wichtig Wichtig Wichtig

//Farben der Karten: Kreuz schwarz/anthrazit Pik gr�n Herz rot Karo orange
//Trumpf wei� Der Narr alle 5 Farben
//Farbcodes entsprechend anpassen - Text kann farblich beliebig gestaltet werden
//Text kann ge�ndert werden - interssante Varianten k�nnen gerne bei anpera in den
//passenden thread gestellt werden

//Ist das maximale Charlevel nicht 15, so ist der entsprechende Wert in dieser Formel
//$g=floor($session[user][gold]*log($session[user][level])/log(15));
//an Stelle der "15" einzutragen!!!

$value=array(
   0=>"1",
   1=>"2",
   2=>"3",
   3=>"4",
   4=>"5",
   5=>"6",
   6=>"7",
   7=>"8",
   8=>"9",
   9=>"10",
   10=>"Bube",
   11=>"Reiter",
   12=>"Dame",
   13=>"K�nig"
);
$color=array(
   0=>"�rKreuz",
   1=>"`@Pik",
   2=>"`$Herz",
   3=>"`QKaro"
);
$tarot=array(
   0=>"I",
   1=>"II",
   2=>"III",
   3=>"IV",
   4=>"V",
   5=>"VI",
   6=>"VII",
   7=>"VIII",
   8=>"IX",
   9=>"X",
   10=>"XI",
   11=>"XII",
   12=>"XIII",
   13=>"XIV",
   14=>"XV",
   15=>"XVI",
   16=>"XVII",
   17=>"XVIII",
   18=>"XIX",
   19=>"XX",
   20=>"XXI"
);

if (!isset($session)) exit();
$session[user][specialinc]="tarot.php";
if ($_GET[op]==""){
   output("Du streifst durch den Wald und kommst an der Dorfpallisade vorbei.`n");
   output("Dabei f�llt dir ein dunkler Durchgang auf, welchem Du dich neugirig n�herst.`n");
   output("Als Du vor diesem Durchgang stehst zieht dich, bevor Du reagieren kannst, ein starker Arm in einen dunklen Raum hinein.`n");
   output("Du siehst mehrere M�nner an Tischen in Kartenspiele vertieft sitzen.`n");
   output("Der T�rsteher, der dich in den Raum gezogen hat, mustert dich und deinen Goldbeutel".�n);
   addnav("Weiter","forest.php?op=1");
}elseif ($_GET[op]=="1"){
   $g=floor($session[user][gold]*log($session[user][level])/log(15));
   if($g=0){
   output("Der T�rsteher st�sst dich wieder aus dem dunkeln Raum.`n");
   output("Deine Erfahrung und dein Goldbeutel erlauben es Dir nicht hier eine Runde zu spielen!`n");
   output("Hinter dir schl�gt eine T�r zu. Du wirfst noch ein Blick auf die Palisade, nur kannst Du die Stelle, wo die T�r war nicht mehr erkennen.`n");
   addnav("Weiter","forest.php?op=0");
   }else{
   $session['user']['gold']-=$g;
   output("Der T�rsteher zieht dir`^ $g Gold `&aus deinem Beutel und legt es auf einen Tisch, wo ein Mann Karten mischt.`n");
   $g*=4;
   output("Danach dr�ckt er dich auf einen Stuhl an dem Tisch und sagt:`n");
   output("Du ziehst 2 Karten. Hast Du 2 gleiche Farben, 2 gleiche Werte, 2 Tr�mpfe oder den Joker unter den beiden Karten, dann gewinnst Du $g Gold.`n");
   addnav("Weiter","forest.php?op=2&op1=$g");
   };
}elseif ($_GET[op]=="2"){
   $g=$_GET['op1'];
   $a=mt_rand(0,77);
   $b=mt_rand(0,76);
   if ($b>=$a){
      $b++;
      };
   output("Du greifst zum Kartenstapel und ziehst diese 2 Karten:`n");
   if ($a<=55){
   $a1=0;
   $a2=$a%14;
   $a3=($a-$a2)/14;
   output("$color[a3] $value[a2]`n");
   }elseif ($a<=76){
   $a1=1;
   $a2=$a-56;
   output("`&Trumpf $tarot[a2]`n");
   }else{
   $a1=2;
   output("`&Der `rN`@a`$r`Qr`n");
   };
   if ($b<=55){
   $b1=0;
   $b2=$b%14;
   $b3=($b-$b2)/14;
   output("$color[b3] $value[b2]`n");
   }elseif ($b<=76){
   $b1=1;
   $b2=$b-56;
   output("`&Trumpf $tarot[b2]`n");
   }else{
   $b1=2;
   output("`&Der `rN`@a`$r`Qr`n");
   };
   if (($a1==2)||($b1==2)){
   output("Du hast $g Gold gewonnen");
   output("Der Mann am Tisch legt auf dein Goldhaufen dein Gewinn.`n");
   output("Dann nimmt der T�rsteher das Gold und f�llt es dir in deinen Beutel.`n");
   output("Er zieht dich hoch, schiebt die aus dem Raum heraus und schliesst hinter dir die T�re. Bei einem Blick auf die Palisade verschwindet die T�r unsichtbar in dieser - eine Zwergengeheimt�r!");
   $session['user']['gold']+=$g;
   }elseif (($a1==1) && ($b1==1)){
   output("Du hast $g Gold gewonnen");
   output("Der Mann am Tisch legt auf dein Goldhaufen dein Gewinn.`n");
   output("Dann nimmt der T�rsteher das Gold und f�llt es dir in deinen Beutel.`n");
   output("Er zieht dich hoch, schiebt die aus dem Raum heraus und schliesst hinter dir die T�re. Bei einem Blick auf die Palisade verschwindet die T�r unsichtbar in dieser - eine Zwergengeheimt�r!");
   $session['user']['gold']+=$g;
   }elseif (($a1==0) && ($b1==0)){
      if (($a2==$b2) || ($a3==$b3)){
      output("Du hast $g Gold gewonnen");
      output("Der Mann am Tisch legt auf dein Goldhaufen dein Gewinn.`n");
      output("Dann nimmt der T�rsteher das Gold und f�llt es dir in deinen Beutel.`n");
      output("Er zieht dich hoch, schiebt die aus dem Raum heraus und schliesst hinter dir die T�re. Bei einem Blick auf die Palisade verschwindet die T�r unsichtbar in dieser - eine Zwergengeheimt�r!");
      $session['user']['gold']+=$g;
      }else{
      output("Du hast verloren!");
      output("Der Mann am Tisch nimmt sich das Gold auf dem Tisch und steckt es weg.`n");
      output("Der T�rsteher zieht dich hoch und schiebt dich unsanft aus dem Raum.`n");
      output("Du h�rst ein leise Klicken. Als Du dich umdrehst, siehst Du eine l�ckenlose Dorfpalisade.`n");
      output("Anscheinende hat der Raum eine Zwergengeheimt�r.");
      };
   }else{
   output("Du hast verloren!");
   output("Der Mann am Tisch nimmt sich das Gold auf dem Tisch und steckt es weg.`n");
   output("Der T�rsteher zieht dich hoch und schiebt dich unsanft aus dem Raum.`n");
   output("Du h�rst ein leise Klicken. Als Du dich umdrehst, siehst Du eine l�ckenlose Dorfpalisade.`n");
   output("Anscheinende hat der Raum eine Zwergengeheimt�r.");
   };
addnav("Weiter","forest.php?op=0");
}elseif ($_GET[op]=="0"){
output("Du wendest dich wieder dem Wald zu.");
$session[user][specialinc]="";
$session[user][specialmisc]="";
forest();
}

?>