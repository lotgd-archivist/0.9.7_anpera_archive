<?php

// Das kleine Wesen im Wald, Version 1.16
//
// Was ist das blo� f�r ein nerviges Ger�usch ...
//
// Erdacht und umgesetzt von Oliver Wellinghoff.
// E-Mail: wellinghoff@gmx.de
// Erstmals erschienen auf: http://www.green-dragon.info
//
// Vorbereitungen:
//
// *** *** ***
//
/*
 ALTER TABLE `accounts` ADD `zertreten` VARCHAR(5) NOT NULL DEFAULT '0';
 ALTER TABLE `accounts` ADD `gerettet` VARCHAR(5) NOT NULL DEFAULT '0';
 CREATE TABLE `kleineswesen` ( `verkleinert` VARCHAR(50) NOT NULL DEFAULT '' );
 INSERT INTO `kleineswesen` ( `verkleinert` ) VALUES ('Violet');
*/
// Suche in newday.php die Zeile:
// $config = unserialize($session['user']['donationconfig']);
// 
// F�ge davor ein:
/*

//Kleines Wesen: Bonus und Malus
if ($session['user']['zertreten']>="1"){ 
   output("`n`)`\$Weil Du einen schlimmen Alptraum hattest, verlierst Du `^".$session['user']['zertreten']."`\$ Runden f�r heute!`n"); 
   $session['user']['turns']-="".$session['user']['zertreten'].""; 
   $session['user']['zertreten']="0"; 
}
if ($session['user']['gerettet']>="1"){ 
   output("`n`)`@Weil Du einen fantastischen Traum hattest, erh�ltst Du `^".$session['user']['gerettet']."`@ zus�tzliche Runden f�r heute!`n"); 
   $session['user']['turns']+="".$session['user']['gerettet'].""; 
   $session['user']['gerettet']="0"; 
}

*/
// Suche in dragon.php die Zeile: 
// //Handle custom titles
// if ($session[user][ctitle] == "") {
//
// F�ge davor ein:
/*

//Kleines Wesen
 $sql = db_query("SELECT verkleinert FROM kleineswesen");
 $klein = db_fetch_assoc($sql) or die(db_error(LINK));

 if($session[user][name]== $klein[verkleinert]){
 db_query("UPDATE kleineswesen SET verkleinert = 'Violet'");
 }else

*/
// *** *** ***
//
//  - Version vom 10.10.2004 -

if (!isset($session)) exit();
$session[user][specialinc] = "kleineswesen.php";
switch($HTTP_GET_VARS[op]){

case "":
$sql = db_query("SELECT verkleinert FROM kleineswesen");
$result = db_fetch_assoc($sql) or die(db_error(LINK));

if ($session[user][name] == "".$result[verkleinert].""){
output("`@Ist das nicht ... doch, das ist der Ort, an dem Du neulich verkleinert wurdest! Du erschauderst und gehst mit schnellen Schritten weiter.`n`n Wobei, jetzt bist Du ja gar nicht mehr klein ... war das alles wom�glich nur eine Illusion? Ein Traum? Wer wei� ...`n`nAuf jeden Fall m�chtest Du hier nicht l�nger verweilen.");
$session[user][specialinc] = "";
break;
}else
    output("`@Du ziehst durch den Wald und schwelgst in der selbstbewussten Gewissheit zuk�nftiger Heldentaten. In Gedanken schon fast beim Gr�nen Drachen angelangt, bleibst Du pl�tzlich genervt stehen. Dieses Piepen! Wie von einer Maus! Schon seit geraumer Zeit verfolgt es Dich ... Also jetzt reicht's aber!");
    output("`n`@Du b�ckst Dich, um den Boden abzusuchen. Das Piepen verstummt f�r einen Moment - woher kommt es? Dann wird es lauter und hektischer als je zuvor. Dort, zwischen den Bl�ttern: ein niedliches, kleines Wesen, kaum einen Fingernagel hoch, das Dir seltsam bekannt vorkommt. Dem Aussehen nach k�nnte es `#".$result[verkleinert]."`@ sein ... Aber ist das denn m�glich?!`n`nWas wirst Du jetzt tun?");
    output("`n`n`@<a href='forest.php?op=mitnehmen'>Wie s��! Ich nehme es mit.</a>", true);
    output("`@`n`n<a href='forest.php?op=zertreten'>Jetzt reicht's! Ich zertrete es.</a>", true);
    output("`@`n`n<a href='forest.php?op=ruhe'>Ich lasse es in Ruhe - so schlimm ist sein Piepen nun auch wieder nicht.</a>", true);
    addnav("","forest.php?op=mitnehmen");
    addnav("","forest.php?op=zertreten");
    addnav("","forest.php?op=ruhe");
    addnav("Mitnehmen.","forest.php?op=mitnehmen");
    addnav("Zertreten.","forest.php?op=zertreten");
    addnav("In Ruhe lassen.","forest.php?op=ruhe");
    $session[user][specialinc] = "kleineswesen.php";

case "mitnehmen":
if ($HTTP_GET_VARS[op]=="mitnehmen"){
    output("`#'Ein Kinderspiel!'`@ denkst Du Dir. Aber weit gefehlt! Das kleine Wesen erweist sich als schnell und wendig. Du musst Dein ganzes Geschick aufbringen, um ihm bei seinen rasanten Haken zu folgen. Geb�ckt eilst Du von einem Busch zum n�chsten - und von einem Baum zum anderen. `n`nDein Ehrgeiz ist geweckt!");
       output("`@`n`n<a href='forest.php?op=mitnehmen2'>Weiter.</a>", true);
    addnav("","forest.php?op=mitnehmen2");
       addnav("Weiter.","forest.php?op=mitnehmen2");
}

case "mitnehmen2":
if ($HTTP_GET_VARS[op]=="mitnehmen2"){
    switch(e_rand(1,10)){ 
            case 1: 
            case 2: 
            case 3:
            case 4:
            $sql = db_query("SELECT verkleinert FROM kleineswesen");
            $result = db_fetch_assoc($sql) or die(db_error(LINK));
               output("`@Minuten werden Stunden, Meter werden zu Kilometern ... In Deiner Euphorie ist Dir nicht aufgefallen, dass Du immer kleiner geworden bist - und das kleine Wesen immer gr��er! `n`#".$result[verkleinert]."`@ steht nun �ber Dir und lacht. `n`n`#'Tja, was soll ich sagen? Wage es ja nicht, mir zu folgen und mich mit Deinen Hilfeschreien zu bel�stigen!'`n`n`@Das Lachen geht Dir nicht mehr aus dem Kopf ..."); 
            output("`n`@Jetzt bist Du allein.`nIm Wald.`nKlein.`nAber niedlich!`nMm, dar�ber musst Du erst mal in Ruhe nachdenken ...");
            output("`n`n`@Weil Du so niedlich geworden bist, erh�ltst Du `^1`@ Charmepunkt!");
if ($session[user][turns]<=4){
               output("`n`nDu bekommst `^".$session[user][experience]*0.08."`@ Erfahrungspunkte hinzu, verlierst aber `\$4`@ Waldk�mpfe!");
            $session[user][experience]=$session[user][experience]*1.08;
}else{         output("`n`nDu bekommst `^".$session[user][experience]*0.05."`@ Erfahrungspunkte hinzu, verlierst aber `\$4`@ Waldk�mpfe!");
			$session[user][experience]=$session[user][experience]*1.05;
}
 			$session[user][turns]-=4;
            $session[user][charm]+=1;
            addnav("T�gliche News","news.php");
            addnav("Zur�ck in den Wald","forest.php");
            addnews("`\$Von nun an muss sich `b".$session[user][name]."`\$ `bim Wald vor K�fern in Acht nehmen!");
            db_query("UPDATE kleineswesen SET verkleinert = '".$session[user][name]."'");
            $session[user][specialinc]="";
            break;
            case 5:
            case 6:
            case 7:
            case 8:
            $sql = db_query("SELECT verkleinert FROM kleineswesen");
            $result = db_fetch_assoc($sql) or die(db_error(LINK));
            output("`@Du jagst und jagst ... ein Gr�ner Drache ist nichts dagegen! Endlich bekommst Du das Wesen zu fassen. In dem Moment, in dem Du es ber�hrst, wirst Du zur�ckgeschleudert.`n`n Aus einer verpuffenden roten Wolke geht `#".$result[verkleinert]."`@ hervor!"); 
            $gems = e_rand(2,3); 
            output("`n`n`@Als Du die verlorengeglaubte Seele bis zum Dorfrand geleitet hast, bekommst Du f�r Deine ehrvolle Tat eine Belohnung in H�he von `^".$gems."`@ Edelsteinen!");
            $session[user][gems]+=$gems;
            $session[user][reputation]+=2;
            output("`n`nDu bekommst `^".$session[user][experience]*0.02."`@ Erfahrungspunkte hinzu und verlierst einen Waldkampf!");
            $session[user][experience]=$session[user][experience]*1.02;
            $session[user][turns]-=1; 
            addnav("T�gliche News","news.php");
            addnav("Zur�ck in den Wald","forest.php");
            addnews("`@`b".$session[user][name]."`b `@kehrte mit der verlorengeblaubten Seele `#".$result[verkleinert]."`@ aus dem Wald zur�ck!");
if ($result[verkleinert]=="Violet"){
           $session[user][specialinc]="";
        break;    
}else if ($result[verkleinert]=="Dag Durnick"){
           $session[user][specialinc]="";
        break;
}else if ($result[verkleinert]=="Seth"){
           $session[user][specialinc]="";
        break;
}else if ($result[verkleinert]=="Wanderh�ndler Aeki"){
           $session[user][specialinc]="";
        break;
}else if ($result[verkleinert]=="Pegasus"){
           $session[user][specialinc]="";
        break;
}else if ($result[verkleinert]=="MightyE"){
           $session[user][specialinc]="";
        break;    
}else if ($result[verkleinert]=="Merick"){
           $session[user][specialinc]="";
        break;    
}else if ($result[verkleinert]=="Cedrik"){
           $session[user][specialinc]="";
        break;    
}else
        $sql="SELECT acctid, gerettet FROM accounts WHERE name like '".$result[verkleinert]."' LIMIT 1";
        $result = db_query($sql) or die(db_error(LINK));
        $rowgerettet = db_fetch_assoc($result);
        $sch�nertraum = (e_rand(2,4));
        $sql = "UPDATE accounts SET gerettet=".$sch�nertraum." WHERE acctid=".$rowgerettet[acctid]."";
        db_query($sql);
		$mailmessage1 = "`@Als Du heute erwachst, f�hlst Du Dich �u�erst erholt. In Deinem Traum warst Du ein kleines Wesen, kaum einen Fingernagel hoch und riefst verzweifelt um Hilfe. Niemand, dem Du im Wald begegnetest reagierte auf Dich ...`n Doch dann - endlich! - blieb jemand stehen. Es war `^".$session[user][name]."`@! Stundenlang versuchte ".($session[user][sex]?"sie":"er").", Dich zu ber�hren, doch Du konntest nicht anders - irgendetwas zwang Dich, immer wieder wegzulaufen. Aber `^".$session[user][name]."`@ lie� sich nicht beirren, ber�hrte Dich schlie�lich und errettete Dich damit. Als wenn das noch nicht genug gewesen w�re, geleitete ".($session[user][sex]?"sie":"er")." Dich sogar noch bis zum Dorf zur�ck. `n`nWenn das kein Traum gewesen w�re, m�sstest Du ".($session[user][sex]?"ihr":"ihm")." nun �u�erst dankbar sein. Es war doch nur ein Traum, oder?`n`nWeil Du besonders gut geschlafen hast, wirst Du morgen `^".$sch�nertraum."`@ zus�tzliche Waldk�mpfe erhalten!`n`n";
        systemmail($rowgerettet[acctid],"`@Du hattest einen fantastischen Traum!",$mailmessage1);
switch(e_rand(1,8)){
        case 1:
        db_query("UPDATE kleineswesen SET verkleinert = 'Violet'");
        break;
        case 2:
        db_query("UPDATE kleineswesen SET verkleinert = 'Seth'");
        break;
        case 3:
        db_query("UPDATE kleineswesen SET verkleinert = 'Dag Durnick'");
        break;
        case 4:
        db_query("UPDATE kleineswesen SET verkleinert = 'Cedrik'");
        break;
        case 5:
        db_query("UPDATE kleineswesen SET verkleinert = 'Wanderh�ndler Aeki'");
        break;
        case 6:
        db_query("UPDATE kleineswesen SET verkleinert = 'Pegasus'");
        break;
        case 7:
        db_query("UPDATE kleineswesen SET verkleinert = 'MightyE'");
        break;
        case 8:
        db_query("UPDATE kleineswesen SET verkleinert = 'Merick'");
        break;
}
        $session[user][specialinc]="";
        break;            
        case 9:
        output("`@Du jagst und jagst ... ein Gr�ner Drache ist nichts dagegen! Es wird immer sp�ter ... aber Dein Ehrgeiz ist - einmal entfacht - nicht aufzuhalten. Viele Stunden sind vergangen, als Deine k�rperlichen Kr�fte Dich verlassen. Du sinkst ersch�pft zu Boden - und siehst das kleine Wesen auf dem Baumstumpf vor Dir stehen. Es zu greifen w�re nun ein Kinderspiel, aber dazu reicht Deine Kraft nicht mehr aus ... Zum ersten Mal h�rst Du genau hin, was es Dir zu sagen hat:"); 
        output("`#'Du hast Dich eifrig bem�ht, mich zu ber�hren - wer mich ber�hrt, macht mich frei! Leider darf ich es Dir nicht zu einfach machen ... Aber daf�r, dass Du es versucht hast, m�chte ich Dir etwas zeigen.'");
        output("`n`@Das kleine Wesen h�pft dreimal im Kreis auf dem Baumstumpf herum, woraufhin dieser in einer roten Wolke verpufft. Es bleibt keine Spur von dem seltsamen Wesen - daf�r l�sst es aber ein kleines S�ckchen zur�ck!");
        $gold =  e_rand(200,700) * e_rand(3,7);
        output("`n`n`@In dem S�ckchen befinden sich `^".$gold."`@ Goldst�cke!");
        $turns = e_rand(1,2);
        output("`n`n`^Du verlierst ".$turns." Waldk�mpfe!");
        $session[user][gold]+=$gold;
        $session[user][turns]-=$turns; 
        $session[user][specialinc]="";
        break;
        case 10:
        output("`@Du jagst und jagst ... ein Gr�ner Drache ist nichts dagegen! Es wird immer sp�ter ... aber Dein Ehrgeiz ist - einmal entfacht - nicht aufzuhalten. Viele Stunden sind vergangen, als Deine k�rperlichen Kr�fte Dich verlassen. Du sinkst ersch�pft zu Boden - und siehst das kleine Wesen auf dem Baumstumpf vor Dir stehen. Es zu greifen w�re nun ein Kinderspiel, aber dazu reicht Deine Kraft nicht mehr aus ... Zum ersten Mal h�rst Du genau hin, was es Dir zu sagen hat:"); 
        output("`#'Du hast Dich eifrig bem�ht, mich zu ber�hren - wer mich ber�hrt, macht mich frei! Leider darf ich es Dir nicht zu einfach machen ... Na ja. Damit Du beim n�chsten Mal etwas wendiger bist, nimm diese Hilfe!'");
        output("`n`@Das kleine Wesen h�pft dreimal im Kreis auf dem Baumstumpf herum, woraufhin dieser in einer roten Wolke verpufft. Es bleibt keine Spur von dem seltsamen Wesen - aber Du f�hlst Dich frischer als je zuvor!");
        $turns = (e_rand(1,3));
        $leben = (e_rand(1,2));
        output("`n`n`@Du bekommst `^".$leben."`@ permanente(n) Lebenspunkt(e)!");
        output("`n`n`^Du verlierst ".$turns." Waldk�mpfe!");
        $session[user][turns]-=$turns;
        $session[user][maxhitpoints]+=$leben;
        $session[user][hitpoints]+=$leben;
        $session[user][specialinc]="";
        break;
}}

case "zertreten":
if ($HTTP_GET_VARS[op]=="zertreten"){
    output("`@Schweren Herzens hebst Du Deinen Fu�, schaust hinauf zu den Baumwipfeln und`n- trittst mit einem kr�ftigen Ruck zu!");
       output("`@`n`n<a href='forest.php?op=zertreten2'>Weiter.</a>", true);
    addnav("","forest.php?op=zertreten2");
       addnav("Weiter.","forest.php?op=zertreten2");
}

case "zertreten2":
if ($HTTP_GET_VARS[op]=="zertreten2"){
    switch(e_rand(1,10)){ 
        case 1: 
        output("`@Als Du den Fu� wieder hebst, stellst Du mit Erstaunen fest, dass das kleine Wesen verschwunden ist. Offenbar hat er es mit der Angst bekommen und ist geflohen. Dir f�llt ein Stein vom Herzen - so ist es f�r alle Beteiligten besser. Erf�llt von neuer Frische setzt Du Deinen Weg fort."); 
        output("`n`n`^Du erh�ltst einen zus�tzlichen Waldkampf!");
        $session[user][turns]+=1; 
		$session[user][reputation]-=4;
        $session[user][specialinc]="";
        break;
        case 2:
        case 3:
        case 4:
        case 5: 
        case 6:
        case 7:
        output("`@Als Du den Fu� wieder hebst, stellst Du angewidert fest, dass Du ganze Arbeit geleistet hast: von dem kleinen Wesen ist nur noch Matsch �brig geblieben. War das wirklich n�tig? Na ja, immerhin hat das Piepen aufgeh�rt. Aber Du brauchst eine Weile, um diesen Vorfall zu vergessen."); 
        output("`n`n`^Du verlierst einen Waldkampf!");
        $session[user][reputation]-=10;
        $session[user][turns]-=1; 
        addnav("T�gliche News","news.php");
        addnav("Zur�ck in den Wald","forest.php");
        $sql = db_query("SELECT verkleinert FROM kleineswesen");
        $result = db_fetch_assoc($sql) or die(db_error(LINK));
        addnews("`b`\$".$session[user][name]."`b `\$hat die Hilfeschreie von `b".$result[verkleinert]."`\$`b leider `bv�llig`b missverstanden ...");
if ($result[verkleinert]=="Violet"){
           $session[user][specialinc]="";
        break;    
}else if ($result[verkleinert]=="Dag Durnick"){
           $session[user][specialinc]="";
        break;
}else if ($result[verkleinert]=="Seth"){
           $session[user][specialinc]="";
        break;
}else if ($result[verkleinert]=="Wanderh�ndler Aeki"){
           $session[user][specialinc]="";
        break;
}else if ($result[verkleinert]=="Pegasus"){
           $session[user][specialinc]="";
        break;
}else if ($result[verkleinert]=="MightyE"){
           $session[user][specialinc]="";
        break;    
}else if ($result[verkleinert]=="Merick"){
           $session[user][specialinc]="";
        break;    
}else if ($result[verkleinert]=="Cedrik"){
           $session[user][specialinc]="";
        break;    
}else
        $sql="SELECT acctid, zertreten FROM accounts WHERE name like '".$result[verkleinert]."' LIMIT 1";
        $result = db_query($sql) or die(db_error(LINK));
        $rowdead = db_fetch_assoc($result);
        $alptraum = (e_rand(3,5));
        $sql = "UPDATE accounts SET zertreten=".$alptraum." WHERE acctid=".$rowdead[acctid]."";
        db_query($sql);
        $mailmessage1 = "`@Heute nach wachst Du schwei�gebadet auf. In Deinem Traum warst Du ein kleines Wesen, kaum einen Fingernagel hoch und riefst verzweifelt um Hilfe. Niemand, dem Du im Wald begegnetest reagierte auf Dich ...`n Doch dann - endlich! - blieb jemand stehen. Es war `^".$session[user][name]."`@! Aber ".($session[user][sex]?"sie":"er")." blieb nicht stehen, um Dir zu helfen ...`n`n Es graut Dir noch immer bei der Erinnerung daran, wie es sich anf�hlte, als ".($session[user][sex]?"ihr":"sein")." Fu� niederraste und Dich zermatschte. Aber zum Gl�ck war das alles ja nur ein Traum ... war es doch, oder?`n`nWeil Du schlecht geschlafen hast, wirst Du morgen `\$".$alptraum."`@ Waldk�mpfe einb��en!`n`n";
           systemmail($rowdead[acctid],"`\$Du hattest einen schrecklichen Alptraum!",$mailmessage1);
switch(e_rand(1,8)){
        case 1:
        db_query("UPDATE kleineswesen SET verkleinert = 'Violet'");
        break;
        case 2:
        db_query("UPDATE kleineswesen SET verkleinert = 'Seth'");
        break;
        case 3:
        db_query("UPDATE kleineswesen SET verkleinert = 'Dag Durnick'");
        break;
        case 4:
        db_query("UPDATE kleineswesen SET verkleinert = 'Cedrik'");
        break;
        case 5:
        db_query("UPDATE kleineswesen SET verkleinert = 'Wanderh�ndler Aeki'");
        break;
        case 6:
        db_query("UPDATE kleineswesen SET verkleinert = 'Pegasus'");
        break;
        case 7:
        db_query("UPDATE kleineswesen SET verkleinert = 'MightyE'");
        break;
        case 8:
        db_query("UPDATE kleineswesen SET verkleinert = 'Merick'");
        break;
}
        $session[user][specialinc]="";
        break;            
        case 8:
		case 9: 
        case 10:
        output("`@Erschrocken stellst Du fest, dass Dein Tritt kurz vor dem Boden gestoppt wurde. Von diesem kleinen Wesen?! - Zumindest ist es nicht so klein, als dass es Dich nicht gegen einen Baum schleudern k�nnte! Du rappelst Dich auf und rennst schreiend davon."); 
        output("`n`n`^Du verlierst die meisten Deiner Lebenspunkte!");
        output("`n`^Du verlierst einen Waldkampf!");
		$session[user][reputation]-=20;
        $session[user][hitpoints]=1;
        $session[user][turns]-=1; 
        addnav("T�gliche News","news.php");
        addnav("Zur�ck zum Wald.","forest.php");
		addnews("`\$`b".$session[user][name]."`b `\$wurde im Wald von einem D�umling erniedrigt.");
        $session[user][specialinc]="";
        break;
}}

case "ruhe":
if ($HTTP_GET_VARS[op]=="ruhe"){
    switch(e_rand(1,10)){ 
            case 1: 
            case 2: 
            case 3:
            case 4:
            case 5:
            output("`@Du rei�t Dich zusammen und musst das Piepen noch etliche Stunden ertragen. Aber letzten Endes war es wirklich nicht so schlimm."); 
            output("`n`n`^Du erh�ltst einen zus�tzlichen Waldkampf!");
			$session[user][specialinc]="";
            break;
            case 6: 
            case 7: 
            case 8: 
            output("`@Du rei�t Dich zusammen und musst das Piepen noch etliche Stunden ertragen. Letzten Endes war es aber wirklich nicht so schlimm.`n`n`^Du b��t nur einen einzigen Waldkampf ein!"); 
            $session[user][turns]-=1; 
			$session[user][specialinc]="";
            break;            
            case 9: 
            case 10:
            output("`@Du rei�t Dich zusammen und musst das Piepen noch etliche Stunden ertragen. Arrrrrrgh! Wenn es doch blo� aufh�rte! Es bringt Dich beinahe um den Verstand.`n`n`^Weil Du Dich nicht konzentrieren kannst, b��t Du gleich zwei Waldk�mpfe ein!"); 
            $session[user][turns]-=2; 
			$session[user][specialinc]="";
            break;
}}
}
?>