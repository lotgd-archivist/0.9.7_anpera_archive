<?php

// Krieg und Frieden
// Version 0.9.2

require_once "common.php";
checkday();
page_header("~~~~~~ Krieg und Frieden ~~~~~~~");
output("`^`c`b~~~~~~ Krieg und Frieden ~~~~~~~`b`c`6`n");
output("`cDu begibst Dich zu Bett und schl�fst ein! Morgen ist auch wieder ein Tag, denkst Du Dir, an dem man die Staatsgesch�fte weiterf�hren kann!`c`n`n");
addnav("Weiter");
addnav("Zur�ck ins Dorf","village.php");
addnav("ODER");
addnav("Weiterspielen","kf_anfang.php");
if ($session[user][superuser]>=2){
	addnav("Administration");
	addnav("Einstellungen","kf_admin.php");
}
page_footer();
?>
