<?php

// Krieg und Frieden
// Version 0.9.2

require_once "common.php";
require_once "kf_functions.php";

page_header("~~~~~~ Krieg und Frieden ~~~~~~~");
output("`^`c`b~~~~~~ Krieg und Frieden ~~~~~~~`b`c`^`n");

checkday();

//Berechnung des Tages!!
if($session[user][kf_newday]==1){
	$session[user][kf_day]++;																					//Regierungstage
	$wetter_string=unserialize(kf_get_setting('wetter_string'));
	$count_wetter_string=count($wetter_string)-1;
	$session[user][kf_tagrelation]=e_rand(0,$count_wetter_string);		//DER WIRTSCHAFTSFAKTOR!!!!
	$session[user][kf_land_kauf]=0; 																	//Land darf wieder gekauft werden
	$session[user][kf_krieg]=0; 																			//Es darf wieder Krieg gef�hrt werden
	calculate_day();
}

output("`c`b`6Es ist der ".$session[user][kf_day]." Tag eurer Regentschaft!`b`c");
$wetter_string = unserialize(kf_get_setting(wetter_string));
output("`c`b`6Heute ist ein ".$wetter_string[$session[user][kf_tagrelation]]." Tag!`b`c`n");

if ($HTTP_GET_VARS[op]==""){
		output("`c`6Du sitzt auf Deinem Thron und studierst die Ergebnisse des heutigen Tages:`&`c`n`");
		
		output("`c`b`&Besonderes Ereigniss:`b`n");
		output("----------------------------------------`c");
		day_event();
		
		if($session[user][kf_newday]==1){
			output($session[user][kf_tagesbericht],true);
			$session[user][kf_newday]=0;
		}
		
		output("`n`n`&`cDeine Berater in allen Lebenslagen stehen neben Dir`nund warten auf Deine Anweisung!`n");
		output("Entscheide nun, was Du gerne als n�chstes tun m�chtest.`c`n`n");
		
		addnav("Aktionen");
		addnav("An/Verkauf von Land","kf_land.php");
		addnav("Staatsgesch�fte","kf_staat.php");
		addnav("Geb�ude","kf_gebaeude.php");
		addnav("Handel","kf_handel.php");
		addnav("Milit�r","kf_militaer.php");
		addnav("Statistik");
		addnav("Tagesbericht","kf_mainmenu.php?op=tagesbericht");
		addnav("�bersicht","kf_mainmenu.php?op=status");
		addnav("Pers. Bed�rfnisse");
		addnav("Nahrung","kf_mainmenu.php?op=essen");
		addnav("Waschen","kf_mainmenu.php?op=wash");
		addnav("Toilette","kf_mainmenu.php?op=piss");
		addnav("Neuigkeiten lesen","news.php");
		addnav("Spielanleitung","kf_anleitung.php");
		addnav("Runde beenden");
		if($session[user][turns]>0){
			addnav("Neuer Tag","kf_mainmenu.php?op=newday");
		}else{
			addnav("Du bist zu m�de`nf�r einen neuen Tag!","");
		}
		addnav("Ende");
		addnav("Spiel beenden","kf_ende.php");
		if ($session[user][superuser]>=2){
			addnav("Administration");
			addnav("Einstellungen","kf_admin.php");
		}
}else if ($_GET[op]=="tagesbericht"){
	output($session[user][kf_tagesbericht],true);
	addnav("Sonstiges");
	addnav("Zur�ck","kf_mainmenu.php");
}else if ($_GET[op]=="status"){
	output("`&`c`bDein derzeitiger Status:`b`c`n");
	show_details();
	addnav("Sonstiges");
	addnav("Zur�ck","kf_mainmenu.php");
}else if ($_GET[op]=="essen"){
	output("`c`n`&Du haust Dir schnell einen Happen rein, bevor du weiter spielst!`c`n");
	$session['user']['hunger']-=50;
	addnav("Sonstiges");
	addnav("Zur�ck","kf_mainmenu.php");
}else if($_GET[op]=="wash"){
	output("`c`n`&Du w�schst Dich und duftest nun wunderbar, um weiter zu spielen!`c`n");
	$session['user']['clean']=0;
	addnav("Sonstiges");
	addnav("Zur�ck","kf_mainmenu.php");
}else if($_GET[op]=="piss"){
	output("`c`n`&Erleichtert kannst Du nun weiterspielen!`c`n");
	$session[user][bladder]=0;
	addnav("Sonstiges");
	addnav("Zur�ck","kf_mainmenu.php");
}else if($_GET[op]=="newday"){
	output("`c`n`&Du beschlie�t zu Bett zu gehen! Gut erholt wachst Du am n�chsten Tag wieder auf und bist gespannt auf die neuesten Ereignisse!`c`n");
	$session[user][turns]--;
	$session[user][hunger]+=10;
	$session[user][bladder]+=10;
	$session[user][clean]+=2;
	$session[user][kf_newday]=1;
	addnav("Sonstiges");
	addnav("Weiter","kf_mainmenu.php");
}
	
page_footer();
?>
