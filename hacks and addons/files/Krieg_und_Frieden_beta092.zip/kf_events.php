<?php

require_once "common.php";
require_once "kf_functions.php";

// Krieg und Frieden
// Version 0.9.2
// Besondere Ereignisse

global $session;
	
//Hole Settings
$building=unserialize(kf_get_setting('building'));


//Welchem Geb�ude/Gegenstand passiert was
$zufall_building=e_rand(1,$building_total);

//je gr��er, desto seltener passieren besondere Ereignisse
$zufall=50;

switch(e_rand(1,$zufall)){
	case 1:
		if($session[user][$building[$zufall_building][5]]>=2){
			$event = "`b`c`$ Ein Gro�brand vernichtet ein(e/en) ".$building[$zufall_building][0]."`nAlle L�schversuche waren zwecklos!`n`b`c";
			$session[user][kf_land]=$session[user][kf_land]+$session[user][$building[$zufall_building][4]];
			$session[user][kf_landnutzung]=$session[user][kf_landnutzung]-$session[user][$building[$zufall_building][4]];
			$session[user][$building[$zufall_building][5]]=$session[user][$building[$zufall_building][5]]-1;
			addnews("`^`cKrieg und Frieden:`n`0".$session[user][name]."`@ hat bei einem Gro�brand ein ".$building[$zufall_building][0]." verloren.`nAlle L�schversuche waren zwecklos!`c"); 
		}
		break;	
	case 2:
		if($building[$zufall_building][7]>0 && $session[user][$building[$zufall_building][10]]>0){
			$wieviel = e_rand(1,$session[user][$building[$zufall_building][10]]);
			$event = "`b`c`$ Ein Gro�brand in einer Deiner Lagerhallen vernichtet ".$wieviel." ".$building[$zufall_building][9]."`nAlle L�schversuche waren zwecklos!`n`b`c";
			$session[user][$building[$zufall_building][10]]=$session[user][$building[$zufall_building][10]]-$wieviel;
			addnews("`^`cKrieg und Frieden:`n`0".$session[user][name]."`@ hat bei einem Gro�brand ".$wieviel." ".$building[$zufall_building][9]." verloren.`nAlle L�schversuche waren zwecklos!`c"); 
		}
		break;
	case 3:
		if($building[$zufall_building][7]>0){
			if($session[user][kf_scout]>0){
				$wieviel = e_rand(1,10);
				$event = "`b`c`6 Deine Scouts finden Ureinwohner und handeln ".$wieviel." ".$building[$zufall_building][9]." mit Ihnen!`n`b`c";
				$session[user][$building[$zufall_building][10]]=$session[user][$building[$zufall_building][10]]+$wieviel;
				addnews("`^`cKrieg und Frieden:`n`@Die Scouts von `0".$session[user][name]."`@ haben Ureinwohner gefunden`nund ".$wieviel." ".$building[$zufall_building][9]." gehandelt!`c"); 
			}else{
				$event = "`b`c`$ Leider besitzt Du keine Scouts, die f�r Dich Land und Umgebung erforschen!`nSonst w�re vielleicht etwas Tolles zu entdecken gewesen!`n`b`c";
			}
		}
		break;
	case 4:
		$wieviel = e_rand(1,1000);
		$event = "`b`c`6 Einer Deiner G�nner unterst�tzt Dich mit ".$wieviel." Talern!`nL�chelnd �berreicht er Dir den Beutel.`nDu �berlegst noch, ob er Dir nicht lieber ein Messer in den R�cken stechen will, aber verwirfst den Gedanken schnell wieder!`n`b`c";
		$session[user][kf_taler]=$session[user][kf_taler]+$wieviel;
		addnews("`^`cKrieg und Frieden:`n`@Ein G�nner von `0".$session[user][name]."`@ hat ihm ".$wieviel." Talern gespendet!`c");
		break;
	case 5:
		if($session[user][kf_scout]>=10){
			$event = "`b`c`6 Einer Deiner Scouts entdeckt eine Goldmine und stellt den Besitz f�r euch sicher!`n`b`c";
			$session[user][kf_goldmine]=$session[user][kf_goldmine]+1;
			addnews("`c`^Krieg und Frieden:`n`@Die Scouts von `0".$session[user][name]."`@ haben eine Goldmine entdeckt!`c");
		}else{
			$event = "`b`c`$ Leider besitzt Du nicht soviele Scouts, die f�r Dich Land und Umgebung erforschen!`nSonst w�re vielleicht etwas Tolles zu entdecken gewesen!`n`b`c";
		}
		break;
	case 6:
		if($session[user][kf_scout]>=12){
			$event = "`b`c`6 Einer Deiner Scouts entdeckt eine Edelsteinmine und stellt den Besitz f�r euch sicher!`n`b`c";
			$session[user][kf_edelsteinmine]=$session[user][kf_edelsteinmine]+1;
			addnews("`^`cKrieg und Frieden:`n`@Die Scouts von `0".$session[user][name]."`@ haben eine Edelsteinmine entdeckt!`c");
		}else{
			$event = "`b`c`$ Leider besitzt Du nicht soviele Scouts, die f�r Dich Land und Umgebung erforschen!`nSonst w�re vielleicht etwas Tolles zu entdecken gewesen!`n`b`c";
		}
		break;
	case 7:
		if($session[user][kf_scout]>=5){
			$event = "`b`c`6 Einer Deiner Scouts entdeckt eine Kohlenmine und stellt den Besitz f�r euch sicher!`n`b`c";
			$session[user][kf_kohlenmine]=$session[user][kf_kohlenmine]+1;
			addnews("`^`cKrieg und Frieden:`n`@Die Scouts von `0".$session[user][name]."`@ haben eine Kohlenmine entdeckt!`c");
		}else{
			$event = "`b`c`$ Leider besitzt Du nicht soviele Scouts, die f�r Dich Land und Umgebung erforschen!`nSonst w�re vielleicht etwas Tolles zu entdecken gewesen!`n`b`c";
		}
		break;
	case 8:
		if($session[user][kf_scout]>=8){
			$event = "`b`c`6 Einer Deiner Scouts entdeckt eine Eisenmine und stellt den Besitz f�r euch sicher!`n`b`c";
			$session[user][kf_eisenmine]=$session[user][kf_eisenmine]+1;
			addnews("`^`cKrieg und Frieden:`n`@Die Scouts von `0".$session[user][name]."`@ haben eine Eisenmine entdeckt!`c");
		}else{
			$event = "`b`c`$ Leider besitzt Du nicht soviele Scouts, die f�r Dich Land und Umgebung erforschen!`nSonst w�re vielleicht etwas Tolles zu entdecken gewesen!`n`b`c";
		}
		break;
	case 9:
		$wieviel = e_rand(1,1000);
		$event = "`b`c`6 Einer Deiner G�nner schenkt Dir ".$wieviel."ha Land!`nL�chelnd �berreicht er Dir die Besitzerurkunde.`nDu �berlegst noch, was er damit wohl bezwecken will, aber verwirfst den Gedanken schnell wieder!`n`b`c";
		$session[user][kf_land]=$session[user][kf_land]+$wieviel;
		addnews("`^`cKrieg und Frieden:`n`@Ein G�nner von `0".$session[user][name]."`@ schenkt ihm ".$wieviel."ha Land!`c");
		break;
	case 10:
		$event = "`b`c`6 Einer Deiner G�nner unterst�tzt Dich mit einer Milizeinheit!`nDu �berlegst noch, ob diese Einheit Dich nicht infiltrieren will, aber Du verwirfst den Gedanken schnell wieder!`n`b`c";
		$session[user][kf_miliz]=$session[user][kf_miliz]+1;
		addnews("`^`cKrieg und Frieden:`n`@Ein G�nner von `0".$session[user][name]."`@ unterst�zt ihn mit einer Milizeinheit!`c");
		break;
	case 11:
		$event = "`b`c`6 Einer Trapper aus dem Wald bietet Dir seine Dienste als Scout an!`nDankend nimmst Du sein Angebot an!`n`b`c";
		$session[user][kf_scout]=$session[user][kf_scout]+1;
		addnews("`^`cKrieg und Frieden:`n`@Eine Scouteinheit bietet `0".$session[user][name]."`@ seine Dienste an!`c");
		break;
	case 12:
		//erst ab Level 4
		if($session[user][kf_lvl]>=4){
			$wieviel = e_rand(1,$session[user][kf_einwohner]*0.3);
			$event = "`b`c`$ Die Pest! Die Pest!!!`nTraurig musst Du mit ansehen, wie ".$wieviel." Einwohner qualvoll sterben!`n`b`c";
			$session[user][kf_einwohner]=$session[user][kf_einwohner]-$wieviel;
			addnews("`^`cKrieg und Frieden:`n`$ Die Pest! Die Pest!!!`n`0".$session[user][name]."`@ verliert dadurch ".$wieviel." Einwohner!`c");
			break;
		}
	case 13:
	case 14:
	case 15:
	case 16:
	case 17:
	case 18:
	case 19:
	case 20:
	case 21:
	case 22:
	case 23:
	case 24:
	case 25:
	case 26:
	case 27:
	case 28:
	case 29:
	case 30:
	case 31:
	case 32:
	case 33:
	case 34:
	case 35:
	case 36:
	case 37:
	case 38:
	case 39:
	case 40:
	case 41:
	case 42:
	case 43:
	case 44:
	case 45:
	case 46:
	case 47:
	case 48:
	case 49:
	case 50:
}
if($event==""){
	output("`b`c`6Derzeit keine besonderen Vorkommnisse.`nAlles l�uft ruhig und geregelt!`n`b`c");
}else{
	output($event);
}

?>