<?php

// Krieg und Frieden
// Version 0.9.2

require_once "common.php";
require_once "kf_functions.php";

page_header("~~~~~~ Krieg und Frieden ~~~~~~~");

//Hole Settings
$x=unserialize(kf_get_setting('x'));
$y=unserialize(kf_get_setting('y'));
$land_grundpreis=kf_get_setting('land_grundpreis');

$taler_verkauf = $land_grundpreis*$x[$session[user][kf_tagrelation]];
$taler_kauf = $land_grundpreis*$y[$session[user][kf_tagrelation]];


if ($HTTP_GET_VARS[op]==""){
	output("`c`b`^Land An- und Verkauf:`n`b`^");
	output("`n`&`bDerzeit besitzt Du ".$session[user][kf_land]."ha Land!`b`n");
	output("`&`bDerzeit ben�tigen Deine Geb�ude ".$session[user][kf_landnutzung]."ha Land!`b`n");
	output("`&`bDu hast derzeit ".$session[user][kf_taler]." Taler!`c`b`n");
	output("Hier an der Landb�rse stehen die Landherren, die ihr Land zu Geld machen oder L�ndereien erwerben wollen!`n");
	output("Einer der Landherren beugt sich zu Dir herr�ber und fl�stert Dir ins Ohr: `#Ihr seid neu, darum beachtet, dass ihr nur einmal pro Tag Land kaufen oder verkaufen k�nnt!");
	output("`n`&Was m�chtest Du tun?");
	if(!$session[user][kf_land_kauf]){
		addnav("Aktionen");
		addnav("Land kaufen","kf_land.php?op=kaufen");
		addnav("Land verkaufen","kf_land.php?op=verkaufen");
	}
	addnav("Sonstiges");
	addnav("Zur�ck","kf_mainmenu.php");
	if ($session[user][superuser]>=2){
		addnav("Administration");
		addnav("Einstellungen","kf_admin.php");
	}
}else if($_GET['op']=="kaufen"){
	output("`c`6Option: Land kaufen`c`6`n");
	output("`&Der Preis f�r einen Hektar Land liegt derzeit bei ".$taler_kauf." Taler!`n`n");
	output("<form action='kf_land.php?op=kaufen2' method='POST'>Wieviel Land m�chtest Du erwerben?
					<input name='amount' id='amount' width='5'>"
				,true);
	output("<input type='submit' class='button' value='OK'></form>",true);
	addnav("","kf_land.php?op=kaufen2");
	addnav("Sonstiges");
	addnav("Zur�ck","kf_land.php");
}else if($_GET['op']=="kaufen2"){
	output("`c`6Option: Land kaufen`c`6`n");
	$land=abs((int)$_POST['amount']);
	output("`&Du m�chtest gerne ".$land." Hektar Land zum Preis von ".$taler_kauf." Talern kaufen!`n`n");
	$geld=$session[user][kf_taler]-$land*$taler_kauf;
	if($geld>=0){
		output("`&Nach �berpr�fung Deines Verm�gens konnte der Kauf abgeschlossen werden!`nHerzlichen Gl�ckwunsch!");
		$session[user][kf_taler]=$session[user][kf_taler]-$land*$taler_kauf;
		$session[user][kf_land]=$session[user][kf_land]+$land;
		$session[user][kf_land_kauf]=1;
	}else{
		output("`&Nach �berpr�fung Deines Verm�gens l�chelt Dich der Verk�ufer nur m�de an...`nKomm wieder, wenn Du das Geld auch hast!!!`n");
	}
	output("`n`n`c`&`bDerzeit besitzt Du ".$session[user][kf_land]."ha Land!`b`n");
	output("`&`bDerzeit ben�tigen Deine Geb�ude ".$session[user][kf_landnutzung]."ha Land!`b`n");
	output("`&`bDu hast derzeit ".$session[user][kf_taler]." Taler!`c`b`n");
	addnav("Aktionen");
	addnav("Land kaufen","kf_land.php?op=kaufen");
	addnav("Sonstiges");
	addnav("Zur�ck","kf_land.php");
}else if($_GET['op']=="verkaufen"){
	output("`c`6Option: Land verkaufen`c`6`n");
	$taler = $land_grundpreis*$x[$session[user][kf_tagrelation]];
	output("`&Der Verkaufspreis f�r einen Hektar Land liegt derzeit bei ".$taler_verkauf." Taler!`n`n");
	output("<form action='kf_land.php?op=verkaufen2' method='POST'>Wieviel Land m�chtest Du verkaufen?
					<input name='amount' id='amount' width='5'>"
				,true);
	output("<input type='submit' class='button' value='OK'></form>",true);
	addnav("","kf_land.php?op=verkaufen2");
	addnav("Sonstiges");
	addnav("Zur�ck","kf_land.php");
}else if($_GET['op']=="verkaufen2"){
	output("`c`6Option: Land verkaufen`c`6`n");
	$land=abs((int)$_POST['amount']);
	output("`&Du m�chtest gerne ".$land." Hektar Land zum Preis von ".$taler_verkauf." Talern verkaufen!`n`n");

	if($land<=$session[user][kf_land]-$session[user][kf_landnutzung]){
		output("`&Nach �berpr�fung Deiner ben�tigten Landkapazit�ten konnte der Kauf abgeschlossen werden!`nHerzlichen Gl�ckwunsch!");
		$session[user][kf_taler]=$session[user][kf_taler]+$land*$taler_verkauf;
		$session[user][kf_land]=$session[user][kf_land]-$land;
		$session[user][kf_land_kauf]=1;
	}else{
		output("`&Nach �berpr�fung der ben�tigten Landkapazit�ten (".$session[user][kf_landnutzung]." ha) f�r Deine Geb�ude l�chelt Dich der Verk�ufer nur m�de an...`nKomm wieder, wenn Du auch L�ndereien hast, die Du nicht ben�tigst!!!`nVerkauf doch erst ein paar Geb�ude!!`n");
	}
	output("`n`n`c`&`bDerzeit besitzt Du ".$session[user][kf_land]."ha Land!`b`n");
	output("`&`bDerzeit ben�tigen Deine Geb�ude ".$session[user][kf_landnutzung]."ha Land!`b`n");
	output("`&`bDu hast derzeit ".$session[user][kf_taler]." Taler!`c`b`n");
	addnav("Aktionen");
	addnav("Land verkaufen","kf_land.php?op=verkaufen");
	addnav("Sonstiges");
	addnav("Zur�ck","kf_land.php");
}

page_footer();

?>