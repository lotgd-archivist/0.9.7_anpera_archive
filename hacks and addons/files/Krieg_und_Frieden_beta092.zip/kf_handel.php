<?php

// Krieg und Frieden
// Version 0.9.2

require_once "common.php";
require_once "kf_functions.php";

page_header("~~~~~~ Krieg und Frieden ~~~~~~~");
output("`c`b`^Warenhandel`^`b`n`c");

$x=unserialize(kf_get_setting('x'));
$y=unserialize(kf_get_setting('y'));
$building=unserialize(kf_get_setting('building'));
$building_total=count($building);
$preis_faktor=kf_get_setting('preis_faktor');

if($_GET['op']==""){
	output("`n`c`b`6Hier kannst Du nun Waren kaufen / verkaufen.`6`c`b");
	
}else if ($_GET['op']=='kaufen'){
	output("`n`c`b`6Aktion: Kaufen`b`n`c");
	$anzahl=abs($_POST['amount']);
	$art=$_GET['id'];
	$bedarf=($building[$art][8]*$session[user][kf_einwohner]/1000)+1;
	$haben=$session[user][$building[$art][10]];
	if($haben==0){
		$haben=1;
	}
	$kaufwert=round($building[$art][11]*$y[$session[user][kf_tagrelation]]*($bedarf/($haben+$preis_faktor)));
	$wert=$anzahl*$kaufwert;
	if($session[user][kf_taler]>=$wert){
		output("`n`b`@`cDer Deal ist perfekt.`nDu kaufst ".$anzahl." ".$building[$art][9]." f�r ".$wert." Taler`c`b");
		$session[user][$building[$art][10]]=$session[user][$building[$art][10]]+$anzahl;
		$session[user][kf_taler]=$session[user][kf_taler]-$wert;
	}else{
		output("`n`b`$`cDer H�ndler l�chelt Dich m�de an.`n`#Komm wieder, wenn Du auch das Geld besitzt, um ".$anzahl." ".$building[$art][9]." zukaufen!!`c`b");
	}
	$_GET['op']="";
}else if($_GET['op']=="verkaufen"){
	output("`n`c`b`6Aktion: Verkaufen`b`n`c");
	$anzahl=abs($_POST['amount']);
	$art=$_GET['id'];

	$bedarf=($building[$art][8]*$session[user][kf_einwohner]/1000)+1;
	$haben=$session[user][$building[$art][10]];
	if($haben==0){
		$haben=1;
	}
	$verkaufswert=round($building[$art][11]*$y[$session[user][kf_tagrelation]]*($bedarf/($haben+$preis_faktor)));
	$wert=$anzahl*$verkaufswert;
	if($anzahl<=$session[user][$building[$art][10]]){
		output("`n`b`@`cDer Deal ist perfekt.`nDu verkaufst ".$anzahl." ".$building[$art][9]." f�r ".$wert." Taler`c`b");
		$session[user][$building[$art][10]]=$session[user][$building[$art][10]]-$anzahl;
		$session[user][kf_taler]=$session[user][kf_taler]+$wert;
	}else{
		output("`n`b`$`cDer H�ndler l�chelt Dich m�de an.`n`#Komm wieder, wenn Du auch ".$anzahl." ".$building[$art][9]." besitzt, um sie zu verkaufen!!`c`b");
	}
	$_GET['op']="";
}

output("`n`n`&Du hast derzeit ein Verm�gen von ".$session[user][kf_taler]." Taler.");
output("`n`&Hier nun die Warenauswahl:`n`n");
output("<table border='0' cellpadding='8' cellspacing='1' bgcolor='#999999'>",true);
output("<tr class='trhead'>",true);
output("<td><b>Art</b></td><td><b>Preis</b></td><td><b>Du besitzt</b></td><td><b>Kaufen</b></td><td><b>Verkaufen</b></td>",true);

for($a=0;$a<$building_total;$a++){
	if($building[$a][7]>0){
		if($session[user][$building[$a][10]]>0 || $building[$a][6]<=$session[user][kf_lvl]){
			$bedarf=($building[$a][8]*$session[user][kf_einwohner]/1000)+1;
			$haben=$session[user][$building[$a][10]];
			if($haben==0){
				$haben=1;
			}
			$verkaufswert=round($building[$a][11]*$y[$session[user][kf_tagrelation]]*($bedarf/($haben+$preis_faktor)));
			output("<tr class='".($a%2?"trlight":"trdark")."'>",true);
			output("<td>1 ".$building[$a][9]."</td><td>".$verkaufswert."</td><td>".$session[user][$building[$a][10]]."t</td>",true);		
			output("<td>",true);
			output("<form action='kf_handel.php?op=kaufen&id=$a' method='POST'><input name='amount' id='amount' size='2'>"
			,true);
			output("<input type='submit' class='button' value='OK'></form>",true);
			output("</td>",true);
			addnav("","kf_handel.php?op=kaufen&id=$a");
			output("<td>",true);
			output("<form action='kf_handel.php?op=verkaufen&id=$a' method='POST'><input name='amount' id='amount' size='2' value='1'>"
						,true);
			output("<input type='submit' class='button' value='OK'></form></td>",true);
			output("</td>",true);
			addnav("","kf_handel.php?op=verkaufen&id=$a");
			output("</tr>",true);
		}
	}
}
output("</tr>",true);
output("</table>",true);
addnav("Sonstiges");
addnav("Zur�ck","kf_mainmenu.php");
if ($session[user][superuser]>=2){
	addnav("Administration");
	addnav("Einstellungen","kf_admin.php");
}

page_footer();

?>