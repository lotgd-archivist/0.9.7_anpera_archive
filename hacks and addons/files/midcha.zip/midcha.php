<?
// Idee und Umsetzung
// Morpheus in 2007 f�r www.morpheus-lotgd.de.vu 
// Mail to morpheus@magic.ms
// Gewidmet meiner �ber alles geliebten Blume
// Dank an Magier12, der mich darauf aufmerksam machte, da� ich geschlafen und unvollst�ndig geprogt habe
require_once "common.php";
page_header("Midas Charmshop");
$charm=$session['user']['charm'];
$name=$session['user']['name'];
if ($_GET['op']==""){
	output("`c`bMidas Charmshop`c`b`n`n");
	output("`3Du betrittst einen Ladenraum, der recht freundlich auf Dich wirkt und in dem, au�er einer Theke, hinter der ein Troll steht, und einem Regal hinter der Theke, in dem geschlossene Gl�ser und Flaschen stehen, die teils voll mit einer merkw�rdig `^s`\$t`2r`%a`th`gl`Qe`6n`#d`&e`qn `5Fl�ssigkeit`3, teils aber auch leer sind, nichts zu sehen ist.`n");
	output("`3Erstaunt gehst Du zur Theke, wobei Du den Troll von oben bis unten musterst und nicht schlecht zu staunen beginnt, denn f�r gew�hnlich sind Trolle von Natur aus h��lich, dieser jedoch, bei dem es sich, offenbar, um `6Midas`3 handelt, wirkt ungemein sch�n.");
	output("`3Als Du vor der Theke stehst, noch immer dar�ber gr�belnd, wieso `6Midas `3nur so sch�n sein kann, spricht er Dich an:`n`n");
	output("`7\"Sei willkommen, `^$name`7, in meinem bescheidenen Charmshop, bei mir kannst Du Deinen Charm in bare `@Gems `7 umsetzen oder umgekehrt!\"`n`n");
	output("`3Erstaunt blickst Du ihn an und dann an ihm vorbei auf die Flaschen, und, als ob er Deine Frage geahnt h�tte, sagt er zu Dir:`n`n");
	output("`7\"Was Du dort im Regal stehen siehst, sind Flaschen angef�llt mit dem Charm anderer Krieger, die bereits bei mir waren, den ich in dieser Form aufbewahre.");
	output("`7Da jeder Krieger seinen eigene Charm hat, strahlen die Flaschen in diesen vielen, verschiedenen Farben\"`3 erl�utert er und sieht Dich dann genau an, als k�nne er in Deine Seele blicken.`n");
	output("`7\"Wie ich sehe, `^$name`7, besitzt Du `^$charm Charmpunkte`7, sag, m�chtest Du mir welchen verkaufen oder Charm erwerben?");
	output("`7Mein Angebot sieht wie folgt aus:`n");
	output("`7F�r `^1 Charmpunkt`7, den Du `^kaufen `7willst, mu�t Du `@2 Gems `7bezahlen, f�r `^5 Charmpunkte`7, die Du mir `^verkaufst`7, erh�lst Du `@1 Gem`7.`n`n");
	output("`3Immer noch staunend �ber die Sch�nheit der `^s`\$t`2r`%a`th`gl`Qe`6n`#d`&e`qn `5Fl�ssigkeit`3 �berlegst Du, was Du tun m�chtest.");
	addnav("k?Charmpunkte kaufen","midcha.php?op=kauf");
	addnav("v?Charmpunkte verkaufen","midcha.php?op=verkauf");
	addnav("Z?Zur�ck zum Ort","village.php");
}
if($_GET['op']=="kauf"){
	$gem=$session['user']['gems'];
        if ($gem<1){
		output("`7Tja, `6$name`7, Du hast leider im Moment keine `@Gems`7, um Dir Charm kaufen zu k�nnen`n");
	}else{
		output("`7Du hast im Moment `^$gem `@Gems `7bei Dir, wieviel davon m�chtest Du in Charmpunkte investieren?`n");
		output("<form action='midcha.php?op=kauf2' method='POST'><input name='buy' id='buy'><input type='submit' class='button' value='kaufen'></form>",true);
		output("<script language='JavaScript'>document.getElementById('bet').focus();</script>",true);
		addnav("","midcha.php?op=kauf2");
	}
	addnav("v?Charm verkaufen","midcha.php?op=verkauf");
	addnav("Zur�ck zum Haus","village.php");
}
if ($_GET[op]=="kauf2"){
	$buy=$_POST[buy];
	$gem=$session['user']['gems'];
        if ($gem<$buy){
		output("`6Midas `3lacht schallend und sch�ttelt den Kopf:`7\"Ich f�rchte, Du hast nicht genug `@Gems`7 bei Dir, komm besser sp�ter noch einmal wieder!\"`n");
        }else{
		if ($buy > 0){  
			if ($buy % 2 == 0){
				$cp=$buy/2;
				output("`6Midas `3nimmt Deine `^$buy `@Gems `3,nickt zufrieden und wendet sich dann zum Regal, wo er eine Flasche aussucht, deren Gr��e der Gemmenge angemessen ist, die er Dir dann reicht.`n");
				output("`3Du setzt die Flasche an, leerst ihren Inhalt und sp�rst, wie Dich eine `QW`2�`\$r`&m`ge `3durchstr�mt und Du um `^$cp `3Punkte sch�ner wirst`n");
				$session['user']['gems']-=$buy;
				$session['user']['charm']+=$cp;
			}else{
				$nbuy=$buy-1;
				$cp=$nbuy/2;
				$session['user']['gems']+=1;
				output("`6Midas `3grinst und gibt Dir `@einen Gem`3 zur�ck, denn Du hast Dich offenbar verz�hlt, wendet sich dann um, sucht eine passende Flasche, deren Inhalt dem Gegenwert der `@Gems`3 entspricht und reicht sie Dir.`n");
				output("`3Du setzt die Flasche an, leerst ihren Inhalt und sp�rst, wie Dich eine `QW`2�`\$r`&m`ge `3durchstr�mt und Du um `^$cp `3Punkte sch�ner wirst`n");
				$session['user']['gems']-=$nbuy;
				$session['user']['charm']+=$cp;
			}
		}else{ 
        		output("`6Midas `3lacht und meint, dass dir bei der Anzahl der Edelsteine wohl ein Fehler unterlaufen ist.");
		} 
	}
	addnav("k?Charmpunkte kaufen","midcha.php?op=kauf");
	addnav("v?Charmpunkte verkaufen","midcha.php?op=verkauf");
	addnav("Z?Zur�ck zum Ort","village.php");
}
if($_GET['op']=="verkauf"){
	$charm=$session['user']['charm'];
        if ($charm<5){
		output("`7Du hast hast im Moment nicht genug Charm, um mir welchen verkaufen zu k�nnen.`n");
	}else{
		output("`7Du hast im Moment `^$charm Charmpunkte`3, wie viele davon willst Du mir verkaufen?`n");
		output("<form action='midcha.php?op=verkauf2' method='POST'><input name='sell' id='sell'><input type='submit' class='button' value='verkaufen'></form>",true);
		output("<script language='JavaScript'>document.getElementById('bet').focus();</script>",true);
		addnav("","midcha.php?op=verkauf2");
	}
	addnav("v?Charmpunkte verkaufen","midcha.php?op=verkauf");
	addnav("k?Charmpunkte kaufen","midcha.php?op=kauf");
	addnav("Z?Zur�ck zum Ort","village.php");
}
if ($_GET[op]=="verkauf2"){
	$sell=$_POST[sell];
	$charm=$session['user']['charm'];
        if ($charm<$sell){ 
		output("`6Midas `3lacht schallend:`7\" Du kannst nicht mehr Charm verkaufen, als Du besitzt!\"`n");
	}else{
		if ($sell > 0){ 
			if ($sell % 5 == 0){
				$gem=($sell/5);
				output("`6Midas `3nickt zufrieden, bittet Dich hinter die Theke und durch eine T�r in einen Nachbarraum, in dem ein recht bequem wirkender Sessel steht, in dem er Dich bittet, Platz zu nehmen, daneben ein kleiner, runder Tisch.");
				output("`3Er stllt sich vor Dich, in der Hand eine Kugel, die an einer Kette h�ngt und seltsam `2l`@e`Tu`#c`&h`%t`Qe`6t`3 und die er vor Deinen Augen, langsam und gleichm��ig, hin und her schwenkt w�hrend er Dich auffordert, auf sie zu blicken und Dich zu konzentrieren.");
				output("`3Du folgst seiner Anweisung und bald werden Deine Augenlider so schwer, da� Du sie nicht mehr offen halten kannst und kurz einschlummerst.`n");
				output("`3Als Du wieder erwachst, steht neben Dir auf dem Tisch ein Glas mit `#Wasser `3 und `6Midas `3ist bereits wieder im Laden verschwunden.");
				output("`3Du trinkst das `#Wasser `3und gehst in den Laden, wo `6Midas `3bereits die Flasche mit Deinem Charm, den er auf `&mag`7is`&che `3Weise von Dir genommen hat, in den Regalen hat verschwinden lassen.");
				output("`3Als er Dich sieht, beginnt er zu L�cheln und reicht Dir ein kleines `gS�ckchen`3, in dem sich Deine `@Gems `3befinden.`n`n");
				output("`7\"Du hast einen besonders sch�n strahlenden Charm, `6$name`3, es war mir eine Freude, mit Dir Gesch�fte zu machen\"`3 sagt er l�chelnd, w�hrend Du Deine `@Gems `3in Deinem eigenen Beutel verstaust.");
				$session['user']['charm']-=$sell;
				$session['user']['gems']+=$gem;
				$session['user']['thirsty']+=1;
        		}else{
				output("`6Midas `3lacht schallend laut und sch�ttelt den Kopf:`7\"Lerne erst einmal, Zahlen durch 5 zu teilen, dann versuche es noch einmal!\"`n");
			}
		}else{ 
        		output("`6Midas lacht und meint, dass dir bei der Anzahl der Charmpunkte wohl ein Fehler unterlaufen ist.");
		} 
	}
	addnav("v?Charmpunkte verkaufen","midcha.php?op=verkauf");
	addnav("k?Charmpunkte kaufen","midcha.php?op=kauf");
	addnav("Z?Zur�ck zum Ort","village.php");
}
page_footer();
?>