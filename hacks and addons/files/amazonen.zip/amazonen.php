<?php
/*
 -------------------------
|     amazonen.php        |
|       Idee by           |
|       Erenya            |
|      Script by          |
|       Erenya            |
|erenattarath@hotmail.com |
 -------------------------
 */
 if (!isset($session)) exit();
 if ($_GET[op]==""){
 output("`4Du begegnest einer Amazone im Wald, die dich bedrohlich ansieht. \"`^Gib mir 100 deiner Donationspunkte, ich will meinen Namen einf�rben`4\" fordert sie schroff.Was tust du nun?");
 addnav("Gib ihr die Donatiosnpunkte","forest.php?op=give");
 addnav("Gib ihr keine Donationspunkte","forest.php?op=dont");
 $session[user][specialinc]="amazonen.php";
 }else if ($_GET[op]=="give"){
if(($session['user']['donation']-$session['user']['donationspent']) >= 100){
 output("`nDu gibst der Amazone 100 deiner hart erk�mpften Donationspunkte, wor�ber diese sehr erfreut schmunzelt.");
 output("`nSie verspricht dir eine angemessene Gegenleisung f�r deine Dienste.");
 output("`nOhne einem Wort Wort des Dankes geht sie, erst als sie weg ist, schie�t ein Pfeil an dir vorbei der mit einem baumelnden S�ckschen h�ngen bleibt.");
 $session[user][donationspent]-=100;
 //debuglog("gave 100 Donationspoints to a amazone");
 switch(e_rand(1,6)){
 case 1:
 output("`nIn dem Sack befindet sich 20 Haru");
 $session[user][rubi]+=20;
  break;
 case 2:
 output("`nin dem Sack befinden sich 20 Natsus");
 $session[user][saphi]+=20;
 break;
 case 3:
 output("`nIn dem Sack befinden sich 20 Akis");
 $session[user][smaragd]+=20;
 break;
 case 4:
 output("`nIn dem Sack befinden sich 20 Fuyus");
 $session[user][rohdiamant]+=20;
 break;
 case 5:
 output("`nIn dem Sack ist eine Karte, durch die du 2 Runden gewinnst.");
 $session[user][turns]+=2;
 break;
 case 6:
 output("`nIn dem Sack sind ein paar Yen");
 $session[user][gold]+=1000;
  break;
 }
 }
 else{
 output("`nDu willst ihr einen Check mit deinen Donationspunkten ausstellen. Freudig geht die Amazone weg, doch kommt sie wieder und sieht dich erbost an.");
 output("`nBevor du etwas tun kannst, schl�gt sie dich KO");
 $session[user][turns]-=4;
 }
 }else{
 output("`nDu bist doch nicht dumm und trennst dich von deinen hart verdienten Donationspunkten. W�tend stapfst du an der Amazone vorbei, doch bevor du gehst, sagst du ihr, dass sie doch selbst daf�r arbeiten soll.");
 }
 
?>
