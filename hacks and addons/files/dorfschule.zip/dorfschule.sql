-- -------------------------------------------
-- 
-- Tabellenstruktur f�r Tabelle `questions` --
-- 

CREATE TABLE `questions` (
`id` int(11) unsigned NOT NULL auto_increment,
`section` varchar(20) NOT NULL,
`question` varchar(200) NOT NULL default '',
`answer1` varchar(200) NOT NULL default '',
`answer2` varchar(200) NOT NULL default '',
`answer3` varchar(200) NOT NULL default '',
`answer4` varchar(200) NOT NULL default '',
`answer5` varchar(200) NOT NULL default '',
`grad` int(4) NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=MyISAM ;


-- ---------------------------------------------------------------------------------
-- 
-- Fragen aus der original Dorfschule von Darkness (m�ssen nicht genommen werden) --
-- 

INSERT INTO questions (section,question,answer1,answer2,answer3,answer4,answer5,grad) VALUES (
1,
"Auf welchem Level kann man den Gr�nen Drachen suchen?",
"Nur auf Level 15",
"Ab level 10",
"Garnicht, man wird vom Drachen gesucht",
"Egal auf welchem level",
"Ab Level 20",
1);

INSERT INTO questions (section,question,answer1,answer2,answer3,answer4,answer5,grad) VALUES (
1,
"Ab wie vielen Drachenkills ist man Gott/G�ttin?",
"Ab 49 DK",
"Ab 30 DK",
"Ab 50 DK",
"Ab 99 DK",
"Garnicht",
1);

INSERT INTO questions (section,question,answer1,answer2,answer3,answer4,answer5,grad) VALUES (
1,
"Wie viele Rassen gibt es hier?",
"12 Rassen",
"5 Rassen",
"4 Rassen",
"10 Rassen",
"15 Rassen",
1);

INSERT INTO questions (section,question,answer1,answer2,answer3,answer4,answer5,grad) VALUES (
1,
"Wie viele Kampfstile gibt es?",
"6 Stile",
"5 Stile",
"12 Stile",
"8 Stile",
"10 Stile",
2);

INSERT INTO questions (section,question,answer1,answer2,answer3,answer4,answer5,grad) VALUES (
1,
"Mit welcher Drachenkill-Zahl k�nnte man zum ersten Mal einen Kampfstil ausw�hlen?",
"Mit 4 DK",
"Mit 9 DK",
"Mit 5 DK",
"Mit 10 DK",
"Mit 49 DK",
2);

INSERT INTO questions (section,question,answer1,answer2,answer3,answer4,answer5,grad) VALUES (
1,
"Wie viele Spezialit�ten gibt es hier?",
"5 Spezialit�ten",
"3 Spezialit�ten",
"4 Spezialit�ten",
"8 Spezialit�ten",
"6 Spezialit�ten",
2);

INSERT INTO questions (section,question,answer1,answer2,answer3,answer4,answer5,grad) VALUES (
1,
"Auf welche Weise kann man sich NICHT wiedererwecken lassen?",
"Ein Krieger bezahlt den Nekromagier im Wald",
"Ein Krieger zahlt 300 Gefallen",
"Ein Krieger benutzt das Goldene Ei",
"Der Ehepartner bezahlt 150 Gefallen",
"Ein Krieger opfert sich",
3);

INSERT INTO questions (section,question,answer1,answer2,answer3,answer4,answer5,grad) VALUES (
1,
"Wie viele Schl�ssel hat ein Haus am Anfang?",
"9 Schl�ssel",
"6 Schl�ssel",
"7 Schl�ssel",
"8 Schl�ssel",
"10 Schl�ssel",
3);

INSERT INTO questions (section,question,answer1,answer2,answer3,answer4,answer5,grad) VALUES (
1,
"Was kostet das Ersetzen eines Schl�ssels?",
"10 Donationpoints",
"1000 Gold und 1 Edelstein",
"50 Donationpoints3 Edelsteine",
"2 Edelsteine",
"3 Edelsteine",
3);

INSERT INTO questions (section,question,answer1,answer2,answer3,answer4,answer5,grad) VALUES (
1,
"Wie hei�t der meister im Tempel der Kampfk�nste?",
"Takusa",
"Siruma",
"Naruto",
"Evendim",
"Celith",
4);

INSERT INTO questions (section,question,answer1,answer2,answer3,answer4,answer5,grad) VALUES (
1,
"Wie hei�t der Meister im Tempel des Geistes?",
"Takusa",
"Siruma",
"Naruto",
"Evendim",
"Celith",
4);

INSERT INTO questions (section,question,answer1,answer2,answer3,answer4,answer5,grad) VALUES (
1,
"Wie hei�t der Meister im Tempel der Magie?",
"Naruto",
"Siruma",
"Takusa",
"Evendim",
"Celith",
4);

INSERT INTO questions (section,question,answer1,answer2,answer3,answer4,answer5,grad) VALUES (
1,
"Wie wird man zu einem Murmeltier?",
"Vom Weisen der Zeit get�tet werden",
"Vom Drachen gefressen werden",
"Vom W�chter der Grotte get�tet werden",
"Verflucht werden",
"Vom Diamantgolem get�tet werden",
5);

INSERT INTO questions (section,question,answer1,answer2,answer3,answer4,answer5,grad) VALUES (
1,
"Wann ist der Diamantgolem so stark wie du?",
"Wenn du 3 Lebenspuntke einsetzt",
"Wenn du 10 Lebenspuntke einsetzt",
"Wenn du 15 Lebenspuntke einsetzt",
"Wenn du 5 Lebenspuntke einsetzt",
"Zufall",
5);

INSERT INTO questions (section,question,answer1,answer2,answer3,answer4,answer5,grad) VALUES (
1,
"Welchen Gegenstand kann man beim Altar NICHT w�hlen?",
"Schwert",
"Sch�del",
"Stein",
"Federn",
"Stab",
5);

-- ------------------------------------------------------ --