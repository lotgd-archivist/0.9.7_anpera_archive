<?php 

/**************************************** 
* Editor f�r:                           * 
* Schule mit Datenbank by               * 
* Welv: ibeg18@sms.at / anpera.net      * 
*                                       * 
****************************************/ 

require_once "common.php"; 
page_header("Fragen Editor"); 
if(empty($_GET['op'])) $_GET['op']="";
switch($_GET['op']){ 
  default: 
    output("`bHier kannst du eine neue Frage hinzuf�gen`b`n`n"); 
    rawoutput("
      <form action='frageneditor.php?op=save' method='POST'> 
        <table> 
          <tr> 
            <td> 
              Kategorie: 
            </td> 
            <td> 
              <select name='schule' size=1> 
                <option value='0'>Gel�scht</option> 
                <option value='1'>Dorfschule</option> 
              </select> 
            </td> 
          </tr> 
          <tr> 
            <td> 
              Frage: 
            </td> 
            <td> 
              <input name='frage' type='text'> 
            </td> 
          </tr> 
          <tr> 
            <td> 
              Richtige Antwort: 
            </td> 
            <td> 
              <input name='a1' type='text'> 
            </td> 
          </tr> 
          <tr> 
            <td> 
              2. Antwort: 
            </td> 
            <td> 
              <input name='a2' type='text'> 
            </td> 
          </tr> 
          <tr> 
            <td> 
              3. Antwort: 
            </td> 
            <td> 
              <input name='a3' type='text'> 
            </td> 
          </tr> 
          <tr> 
            <td> 
              4. Antwort: 
            </td> 
            <td> 
              <input name='a4' type='text'> 
            </td> 
          </tr> 
          <tr> 
            <td> 
              5. Antwort: 
            </td> 
          <td> 
            <input name='a5' type='text'> 
          </td> 
        </tr> 
        <tr> 
          <td> 
            Schwierigkeit: 
          </td> 
          <td> 
            <input type=checkbox name='grad' value='1'>Leicht 
            <input type=checkbox name='grad' value='2'>Mittel 
            <input type=checkbox name='grad' value='3'>Schwehr 
            <input type=checkbox name='grad' value='4'>Unl�sbar 
            <input type=checkbox name='grad' value='5'>G�ttlich 
          </td> 
        </tr> 
      </table> 
      <input type=submit value='Speichern'> 
    </form>"); 
    addnav("","frageneditor.php?op=save"); 
    addnav("Fragen Editieren","frageneditor.php?op=edit"); 
  break; 
  
  case"save": 
    $id = $_POST['id']; 
    $kat = $_POST['schule']; 
    $frage = $_POST['frage']; 
    $antwort1 = $_POST['a1']; 
    $antwort2 = $_POST['a2']; 
    $antwort3 = $_POST['a3']; 
    $antwort4 = $_POST['a4']; 
    $antwort5 = $_POST['a5']; 
    $grad = $_POST['grad']; 

    $check=array("","","","","","");
    $check[$grad]="CHECKED"; 

    $sel[0]=""; 
    $sel[1]=""; 
    //Falls es andere Schulen gibt:// 
    //$sel[2]=""; 
    //$sel[3]=""; 
    //$sel[4]=""; 
    $sel[$kat]="SELECTED"; 

    if(($kat=="") || ($frage=="") || ($antwort1=="") || ($antwort2=="") || ($antwort3=="") || ($antwort4=="") || ($antwort5=="") || ($grad=="")){ 
      output("`b`4FEHLER!`4`b`n`n"); 
      if($_GET['update']==1){ 
        rawoutput("<form action='frageneditor.php?op=save&update=1' method='POST'>"); 
      }else{ 
        rawoutput("<form action='frageneditor.php?op=save' method='POST'>"); 
      } 
      rawoutput("<table><tr><td>"); 
      if($_GET['update']==1){ 
        output("`@ID:`0</td><td><input name='id' READONLY value='".$id."'></td></tr><tr><td>",true); 
      } 
      if($kat==""){ 
        output("`4Keine Kategorie gew�hlt:`0</td>",true); 
        rawoutput("
          <td>
            <select name='schule' size=1> 
              <option value='0'>Gel�scht</option> 
              <option value='1'>Dorfschule</option> 
            </select>
          </td>
        "); 
      }else{ 
        output("`@Kategorie:`0</td>",true); 
        rawoutput("
          <td>
            <select name='schule' size=1> 
              <option value='0' ".$sel[0].">Gel�scht</option> 
              <option value='1' ".$sel[1].">Dorfschule</option> 
            </select>
          </td>
        "); 
      } 
      rawoutput("</tr><tr><td>"); 
      if($frage==""){ 
        output("`4Keine Frage:`0</td>",true); 
        rawoutput("<td><input name='frage' type='text'></td>"); 
      }else{ 
        output("`@Frage:`0</td>",true); 
        rawoutput("<td><input name='frage' type='text' value='".$frage."'></td>"); 
      } 
      rawoutput("</tr><tr><td>"); 
      if($antwort1==""){ 
        output("`4Keine richtige Antwort:`0</td>",true); 
        rawoutput("<td><input name='a1' type='text'></td>"); 
      }else{ 
        output("`@Richtige Antwort:`0</td>",true); 
        rawoutput("<td><input name='a1' type='text' value='".$antwort1."'></td>"); 
      } 
      rawoutput("</tr><tr><td>"); 
      if($antwort2==""){ 
        output("`4Keine 2. Antwort:`0</td>",true); 
        rawoutput("<td><input name='a2' type='text'></td>"); 
      }else{ 
        output("`@2. Antwort:`0</td>",true); 
        rawoutput("<td><input name='a2' type='text' value='".$antwort2."'></td>"); 
      } 
      rawoutput("</tr><tr><td>"); 
      if($antwort3==""){ 
        output("`4Keine 3. Antwort:`0</td>",true); 
        rawoutput("<td><input name='a3' type='text'></td>"); 
      }else{ 
        output("`@3. Antwort`0</td>",true); 
        rawoutput("<td><input name='a3' type='text' value='".$antwort3."'></td>"); 
      } 
      rawoutput("</tr><tr><td>"); 
      if($antwort4==""){ 
        output("`4Keine 4. Antwort:`0</td>",true); 
        rawoutput("<td><input name='a4' type='text'></td>"); 
      }else{ 
        output("`@4. Antwort:`0</td>",true); 
        rawoutput("<td><input name='a4' type='text' value='".$antwort4."'></td>"); 
      } 
      rawoutput("</tr><tr><td>"); 
      if($antwort5==""){ 
        output("`4Keine 5. Antwort:`0</td>",true); 
        rawoutput("<td><input name='a5' type='text'></td>"); 
      } else { 
        output("`@5. Antwort:`0</td>",true); 
        rawoutput("<td><input name='a5' type='text' value='".$antwort5."'></td>"); 
      } 
      rawoutput("</tr><tr><td>"); 
      if($grad==""){ 
        output("`4Kein Schwierigkeitsgrad:`0</td>",true); 
        rawoutput("
          <td> 
            <input type=checkbox name='grad' value='1'>Leicht 
            <input type=checkbox name='grad' value='2'>Mittel 
            <input type=checkbox name='grad' value='3'>Schwehr 
            <input type=checkbox name='grad' value='4'>Unl�sbar 
            <input type=checkbox name='grad' value='5'>G�ttlich 
          </td>
        "); 
      }else{ 
        output("`@Schwierigkeitsgrad:`0</td>",true); 
        rawoutput("
          <td> 
            <input type=checkbox name='grad' value='1' ".$check[1].">Leicht 
            <input type=checkbox name='grad' value='2' ".$check[2].">Mittel 
            <input type=checkbox name='grad' value='3' ".$check[3].">Schwehr 
            <input type=checkbox name='grad' value='4' ".$check[4].">Unl�sbar 
            <input type=checkbox name='grad' value='5' ".$check[5].">G�ttlich 
          </td>
        "); 
      } 
      rawoutput("</tr></table>"); 
      rawoutput("<INPUT TYPE=SUBMIT VALUE='Speichern'>"); 
      if($_GET['update']==1){ 
        addnav("","frageneditor.php?op=save&update=1"); 
      }else{ 
        addnav("","frageneditor.php?op=save"); 
      } 
    }else{ 
      $schule[0] = "Gel�scht"; 
      $schule[1] = "Dorfschule"; 
      //$schule[2] = ""; 
      //$schule[3] = ""; 
      $schule = $schule[$kat]; 

      if($_GET['update']==1){ 
        output("
          Update f�r Frage ID: ".$id." f�r ".$schule." `n 
          Frage: ".$frage." `n 
          Richtige Antwort: ".$antwort1." `n 
          2. Antwort: ".$antwort2." `n 
          3. Antwort: ".$antwort3." `n 
          4. Antwort: ".$antwort4." `n 
          5. Antwort: ".$antwort5." `n
        "); 

        $sql = "UPDATE questions SET section=".$kat.",question='".addslashes($frage)."',answer1='".addslashes($antwort1)."',answer2='".addslashes($antwort2)."',answer3='".addslashes($antwort3)."',answer4='".addslashes($antwort4)."',answer5='".addslashes($antwort5)."',grad=".$grad." WHERE id=".$id; 
        db_query($sql); 
        addnav("Noch eine Frage editieren","frageneditor.php?op=edit"); 
      }else{ 
        output("
          Speichere Frage f�r ".$schule." `n`n 
          Frage: ".$frage." `n 
          Richtige Antwort: ".$antwort1." `n 
          2. Antwort: ".$antwort2." `n 
          3. Antwort: ".$antwort3." `n 
          4. Antwort: ".$antwort4." `n 
          5. Antwort: ".$antwort5." `n
        "); 

        $sql = "INSERT INTO questions (section,question,answer1,answer2,answer3,answer4,answer5,grad) VALUES (".$kat.",\"".$frage."\",\"".$antwort1."\",\"".$antwort2."\",\"".$antwort3."\",\"".$antwort4."\",\"".$antwort5."\",".$grad.")"; 
        db_query($sql); 
        addnav("Nochmal","frageneditor.php"); 
      } 
    } 
  break; 
  
  case"edit": 
    $sql = "SELECT id,section,question,answer1,answer2,answer3,answer4,answer5,grad FROM questions ORDER BY id,section"; 
    $result = db_query($sql); 
    $max = db_num_rows($result); 
    rawoutput("
    <table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999'>
      <tr class='trhead'>
        <td><b>Schule</b></td>
        <td><b>Frage</b></td>
        <td><b>Richtige Antwort</b></td>
        <td><b>2. Antwort</b></td>
        <td><b>3. Antwort</b></td>
        <td><b>4. Antwort</b></td>
        <td><b>5. Antwort</b></td>
        <td><b>Schwierigkeitsgrad</b></td>
        <td><b>Edit</b></td>
      </tr>
    "); 
    for($i=0;$i<$max;$i++){ 
      $row = db_fetch_assoc($result); 

      $schule[0] = "Deaktiviert"; 
      $schule[1] = "Dorfschule"; 
      //$schule[2] = ""; 
      //$schule[3] = ""; 
      $row['section'] = $schule[$row['section']]; 

      output("
        <tr class='".($i%2?"trdark":"trlight")."'>
          <td>`^".$row['section']."`0</td>
          <td>".$row['question']."</td>
          <td>".$row['answer1']."</td>
          <td>".$row['answer2']."</td>
          <td>".$row['answer3']."</td>
          <td>".$row['answer4']."</td>
          <td>".$row['answer5']."</td>
          <td>".$row['grad']."</td>
          <td>
            <a href='frageneditor.php?op=edit2&frage=".$row['id']."'>`@Edit`0</a><br><br>
            <a href='frageneditor.php?op=del&frage=".$row['id']."'>`\$DEL`0</a>
          </td>
        </tr>
      ",true); 
      addnav("","frageneditor.php?op=edit2&frage=".$row['id']);
      addnav("","frageneditor.php?op=del&frage=".$row['id']); 
    } 
    rawoutput("</table>"); 
  break; 
  
  case"edit2": 
    $sql = "SELECT id,section,question,answer1,answer2,answer3,answer4,answer5,grad FROM questions WHERE id=".$_GET['frage']." ORDER BY id,section"; 
    $result = db_query($sql); 
    $row = db_fetch_assoc($result); 
    $check=array("","","","","","");
    $a = $row['grad']; 
    $check[$a]="CHECKED"; 

    $sel[0]=""; 
    $sel[1]=""; 
    //$sel[2]=""; 
    //$sel[3]=""; 
    //$sel[4]=""; 
    $b = $row['section']; 
    $sel[$b]="SELECTED"; 
    rawoutput("
      <form action='frageneditor.php?op=save&update=1' method='POST'> 
        <table> 
          <tr> 
            <td> 
              ID: 
            </td> 
            <td> 
              <input name='id' READONLY value='".$row['id']."'> 
            </td> 
          </tr> 
          <tr> 
            <td> 
              Kategorie: 
            </td> 
            <td> 
              <select name='schule' size=1> 
                <option value='0' ".$sel[0].">Gel�scht</option> 
                <option value='1' ".$sel[1].">Dorfschule</option> 
              </select> 
            </td> 
          </tr> 
          <tr> 
            <td> 
              Frage: 
            </td> 
            <td> 
              <input name='frage' type='text' value='".$row['question']."'> 
            </td> 
          </tr> 
          <tr> 
            <td> 
              Richtige Antwort: 
            </td> 
            <td> 
              <input name='a1' type='text' value='".$row['answer1']."'> 
            </td> 
          </tr> 
          <tr> 
            <td> 
              2. Antwort: 
            </td> 
            <td> 
              <input name='a2' type='text' value='".$row['answer2']."'> 
            </td> 
          </tr> 
          <tr> 
            <td> 
              3. Antwort: 
            </td> 
            <td> 
              <input name='a3' type='text' value='".$row['answer3']."'> 
            </td> 
          </tr> 
          <tr> 
            <td> 
              4. Antwort: 
            </td> 
            <td> 
              <input name='a4' type='text' value='".$row['answer4']."'> 
            </td> 
          </tr> 
          <tr> 
            <td> 
              5. Antwort: 
            </td> 
            <td> 
              <input name='a5' type='text' value='".$row['answer5']."'> 
            </td> 
          </tr> 
          <tr> 
            <td> 
              Schwierigkeit: 
            </td> 
            <td> 
              <input type=checkbox name='grad' value='1' ".$check[1].">Leicht 
              <input type=checkbox name='grad' value='2' ".$check[2].">Mittel 
              <input type=checkbox name='grad' value='3' ".$check[3].">Schwehr 
              <input type=checkbox name='grad' value='4' ".$check[4].">Unl�sbar 
              <input type=checkbox name='grad' value='5' ".$check[5].">G�ttlich 
            </td> 
          </tr> 
        </table> 
        <input type=submit value='Speichern'> 
      </form>
    "); 
    addnav("","frageneditor.php?op=save&update=1"); 
  break; 
  
  case"del":
    if(isset($_GET['killit'])){
      db_query("DELETE FROM questions WHERE id=".$_GET['frage']." LIMIT 1");
      output("Frage wurde gel�scht");
    }else{
      $sql = "SELECT id,section,question,answer1,answer2,answer3,answer4,answer5,grad FROM questions WHERE id=".$_GET['frage']; 
      $result = db_query($sql); 
      if(db_num_rows($result)==1){ 
        $row=db_fetch_assoc($result);
        output("
          Schule: ".$row['section']."`0`n
          Frage: ".$row['question']."`n
          A1: ".$row['answer1']."`n
          F1: ".$row['answer2']."`n
          F2: ".$row['answer3']."`n
          F3: ".$row['answer4']."`n
          F4: ".$row['answer5']."`n
          Grad: ".$row['grad']."
        ");
        addnav("Diese Frage L�schen","frageneditor.php?op=del&killit=1&frage=".$_GET['frage']);
      }else{
        output("Keine oder zu viele �bereinstimmungen!");
      }
    }
  break;
} 
addnav("Zur�ck zur Grotte","superuser.php"); 
addnav("Zur�ck zu allem Weltlichen","village.php"); 
page_footer(); 
?> 