<?php
/**************************************** 
*                                       * 
* Dorfschule mit Datenbank by           * 
* Welv: ibeg18@sms.at / anpera.net      * 
* v.0.9.7                               *    
*                                       * 
***************************************** 
*                                       * 
* Original dorfdorfschule.php by        * 
* Darkness                              * 
* http://darkness.logd.cwsurf.de/logd/  * 
*                                       * 
****************************************/ 

require_once "common.php"; 
page_header("Die Dorfschule"); 
$lesson = $session['user']['schoollesson']; 
$test = $session['user']['schooltest']; 
$wks = $session['user']['turns']; 

// Schule (section) f�r Fragen w�hlen // 
$schule = 1; 

if(empty($_GET['op'])) $_GET['op']="";
switch($_GET['op']){ 
  default: 
    addcommentary(); 
    output("`tDu betrittst die schlichte Dorfschule von Midgard. "); 
    if($session['user']['dragonkills']<1 || $session['user']['experience']<500){ 
      output("Du bist noch zu jung und zu unerfahren, um in der Schule zu lernen.`n`n"); 
      addnav("Zur�ck zum Dorf","village.php"); 
    }else{ 
      addnav("Unterricht nehmen (5 Runden)","dorfschule.php?op=lesson"); 
      addnav("An Pr�fung teilnehmen (1 Runde)","dorfschule.php?op=test"); 
      addnav("Zur�ck zum Dorf","village.php"); 
      output("Hier kannst du entweder etwas lernen, oder dein Wissen unter Beweis stellen.`n`n"); 
      output("Hier unterhalten sich einige andere Besucher der Schule:`n"); 
    } 
    viewcommentary("school","Unterhalten:",10,"spricht"); 
  break; 
  
  case"lesson": 
    switch($_GET['ans']) { 
      default: 
        if($lesson>0 && $wks>=5){ 
          addnav("Ja","dorfschule.php?op=lesson&ans=yes"); 
          addnav("Nein","village.php"); 
          output("`tDu betritts den Unterrichts-Raum. Eine Elfendame l�uft auf dich zu und fragt dich, ob du am Unterricht teilnehmen m�chstest.`n"); 
          output("Sie erkl�rt dir, dass du noch `^".$lesson." `tStunden nehmen kannst.`n`n"); 
          output("`9M�chtest du jetzt Unterricht nehmen? Dies kostet dich 5 Waldk�mpfe"); 
        }else{ 
          addnav("Zur�ck zur Schule","dorfschule.php"); 
          addnav("Zur�ck zum Dorf","village.php"); 
          output("`tDie Elfendame erkl�rt dir freundlich, dass du leider keinen Unterricht mehr nehmen kannst"); 
        } 
      break; 
      
      case"yes": 
        output("`t"); 
        $session['user']['turns']-=5; 
        $session['user']['schoollesson']--; 
        switch(rand(1,15)) { 
          case 1: 
            output("Du hast im Unterricht sehr viel �ber den Kampf gelernt. Du erh�ltst `^1 `tAngriffspunkt!"); 
            $session['user']['attack']++; 
          break; 
          
          case 2: 
            output("Du hast im Unterricht sehr viel �ber den Kampf gelernt. Du erh�ltst `^1 `tVerteidigungspunkt!"); 
            $session['user']['defence']++; 
          break; 
          
          case 3: 
            output("Du hast im Unterricht sehr viel �ber Magie gelernt!`n"); 
            increment_specialty(); 
          break; 
          
          case 4: 
            output("Du hast im Unterricht sehr viel mehr gelernt, als gew�hnlich! "); 
            $erf=$session['user']['experience']; 
            $exp=rand($erf*0.05,$erf*0.1); 
            $session['user']['experience']+=$exp; 
            output("Du erh�ltst ".$exp." Erfahrungspunkte!"); 
          break; 
          
          case 5: 
            output("Du f�hlst dich nun viel kultivierter und gebildeter! Du erh�ltst `^1 `tCharmepunkt!"); 
            $session['user']['charm']++; 
          break; 
          
          default: 
            output("Du hast einige Zeit mit lernen verbracht und f�hlst dich intelligenter!"); 
            $lv=$session['user']['level']; 
            $exp=rand($lv*40,$lv*60); 
            $session['user']['experience']+=$exp; 
          break; 
        } 
        $iq = e_rand(1,14); 
        if($iq==7 || $iq==14) $session['user']['iq']++; 
        addnav("Zur�ck zur Schule","dorfschule.php"); 
        addnav("Zur�ck zum Dorf","village.php"); 
      break; 
    } 
  break; 
  
  case"test": 
    if(($_GET['ans']=="") && ($_GET['que']=="")){ 
      if(($test>0) && ($wks>=1)){ 
        addnav("Ja","dorfschule.php?op=test&ans=yes"); 
        addnav("Nein","village.php"); 
        output("`tDu betritts den Pr�fungs-Raum. Eine Elfendame l�uft auf dich zu und fragt dich, ob du nun bereit f�r die Pr�fung bist.`n`n"); 
        output("`9M�chtest du die Pr�fung beginnen? Dies kostet dich 1 Waldkampf"); 
      }else{ 
        addnav("Zur�ck zur Schule","dorfschule.php"); 
        addnav("Zur�ck zum Dorf","village.php"); 
        output("`tDie Elfendame erkl�rt dir freundlich, dass du leider nicht an der Pr�fung teilnehmen kannst"); 
      } 
    } 
    elseif($_GET['ans']=="yes"){ 
      $session['user']['turns']--; 
      $session['user']['schooltest']--; 
      addnav("Weiter...","dorfschule.php?op=test&que=1"); 
      output("`tDu wirst 5 zuf�llige Fragen beantworten m�ssen. Beantwortest du mehr als 1 Frage falsch, f�llst du durch!"); 
    } 
    //--Beginn des Tests--// 
    elseif($_GET['que']<6){ 
      $q=$_GET['que']; 

      //--Zuf�llige Frage aus der Datenbank--// 
      $sql="SELECT * FROM questions WHERE section=".$schule." AND grad=".$q." ORDER BY rand() LIMIT 1"; 
      $result=db_query($sql); 
      $row=db_fetch_assoc($result); 
      //-------------------------------------// 

      //--Wenn keie Frage f�r diesen Schwierigkeitsgrad vorhanden--// 
      $min = db_num_rows($result); 
      if($min<1){ 
        $sql="SELECT * FROM questions WHERE section=".$schule." ORDER BY rand() LIMIT 1"; 
        $result=db_query($sql); 
        $row = db_fetch_assoc($result); 
      } 
      //-----------------------------------------------// 

      //--Wenn �berhaupt keine Frage vorhanden (ev. section pr�fen)--// 
      $min=db_num_rows($result); 
      if($min<1){ 
        output("`tDie Elfendame erkl�rt dir dass der Admin zu geizig war um ein paar Frageb�gen zur Verf�gung zu stellen. Entt�uscht l�sst du deinen Bleistift fallen, aber du verlierst wenigstens keine Pr�fungszeit. Du h�rst beim gehen noch wie die Elfendame was �ber M�ngel im Bildungssystem murmelt. Vielleicht bleibst du ja vorerst nur zum Unterricht. "); 
        $session['user']['schooltest']++; 
        addnav("Zur�ck zur Schule","dorfschule.php"); 
        addnav("zur�ck zum Dorf","village.php"); 
      }else{ 
        //----------------------------------------// 

        //--Zuf�llige Reihenfolge der Antworten--// 
        $ques = array( 
          0 =>"", 
          1 =>$row['answer2'], 
          2 =>$row['answer3'], 
          3 =>$row['answer4'], 
          4 =>$row['answer5'] 
        ); 
        shuffle($ques); 
        //---------------------------------------// 

        //--Das Herzst�ck. Auflisten der Fragen--// 
        $weiter = $q + 1; 
        if($_GET['ans']==""){ 
          output("`t".$row['question']."`0"); 
          for($i=0;$i<5;$i++){ 
            if($ques[$i]==""){ 
              addnav($row['answer1'],"dorfschule.php?op=test&que=".$q."&ans=".$i); 
              $session['user']['specialmisc']=$i; 
            }else{ 
              addnav($ques[$i],"dorfschule.php?op=test&que=".$q."&ans=".$i); 
            } 
          } 
        } 
        //---------------------------------------// 

        //--Kontrolle der Antworten--// 
        elseif($_GET['ans']==$session['user']['specialmisc']){ 
          $session['user']['testright']++; 
          addnav("Weiter...","dorfschule.php?op=test&que=".$weiter); 
          if($q==5) output("Der Test ist zuende! Bist du bereit f�r das Ergebnis?"); 
          else output("Bereit f�r die n�chste Frage?"); 
        } 
        elseif($_GET['ans']!=$session['user']['specialmisc']){ 
          $session['user']['testfalse']++; 
          addnav("Weiter...","dorfschule.php?op=test&que=".$weiter); 
          if($q==5) output("Der Test ist zuende! Bist du bereit f�r das Ergebnis?"); 
          else output("Bereit f�r die n�chste Frage?"); 
        } 
        //---------------------------// 
      } 
      //--Ende des Tests und Auswertung--// 
    }else{ 
      $right=$session['user']['testright']; 
      $false=$session['user']['testfalse']; 
      $points=($right-$false); 
      $rword="Fragen"; 
      if($right==1) $rword="Frage"; 
      $fword="Fragen"; 
      if($false==1) $fword="Frage"; 
      output("`tDu hast `^".$right." `t".$rword." richtig beantwortet und `\$".$false." `t".$fword." falsch beantwortet!`n"); 
      if($points>=3){ 
        output("Gl�ckwunsch! Damit hast du den Test bestanden!`n"); 
        $erf=$session['user']['experience']; 
        $exp=rand($erf*0.05,$erf*0.1); 
        $session['user']['experience']+=$exp; 
        output("Du f�hlst dich viel intelligenter als zuvor! Du erh�ltst ".$exp." Erfahrungspunkte!"); 
        addnews("`%".$session['user']['name']." `3hat ".($session['user']['sex']?"ihre":"seine")." Pr�fung in der Dorfschule glanzvoll gemeistert!"); 
      }else{ 
        output("Oh, tut mir Leid... Du hast leider nicht bestanden.`n"); 
        $session['user']['charm']--; 
        output("Das ist dir schrecklich peinlich und du l�ufst mit roten Kopf davon. Du verlierst einen Charmepunkt!"); 
        addnews("`%".$session['user']['name']." `5hat bei ".($session['user']['sex']?"ihrer":"seiner")." Pr�fung in der Dorfschule kl�glich versagt!"); 
      } 
      $session['user']['iq']+=$points; 
      $session['user']['testright']=0; 
      $session['user']['testfalse']=0; 
      addnav("Zur�ck zur Schule","dorfschule.php"); 
      addnav("Zur�ck zum Dorf","village.php"); 
    } 
  break; 
} 
page_footer(); 
?>