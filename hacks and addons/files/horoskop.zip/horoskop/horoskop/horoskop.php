<?php
/* coded by Ithil dae (alias Abraxas)
* Email: questbraxel@web.de
* April 2005
* www.zum-tanzenden-troll.de ; www.tanzender-troll.de
* v 0.02
* Wer einen Rhechtschraibfeler findet darf in behalten.
*/

require_once("common.php");
addcommentary();
page_header("Horoskope"); 
output("`c`bDer Horoskop Automat`b`c`n`n");

// Verzichte hier absichtlich auf Zufallszahlen da der Spieler den Eindruck gewinnen soll,
// es handle sich wirklich um eine berechenbare Sache. In der Zeitung hei�t es ja auch nicht,
// w�rfle eine 4 damit dir der gro�e, dunkle Unbekannte begegnet.

if ($_GET[op]==""){
addnav("Automat bedienen");
if ($session['user']['gold']>=5) addnav("Horoskop kaufen (`^5`0)","horoskop.php?op=horoskop");
if ($session['user']['gold']>=20) addnav("Gutes Wort (`^20`0) ","horoskop.php?op=wort");
if ($session['user']['gold']<5)  addnav("Kostenloses Horoskop ziehen","horoskop.php?op=kostenlos");

addnav("Zur�ck");
addnav("Zur�ck ins Dorf","village.php");

output("`7 Alt, etwas zerdellt und dennoch irgendwie magisch... `n
Mit einem seltsamen Gef�hl im Magen trittst du vor den seltsamen Horoskop-Automaten.`n`n
Ein bronzenes Schild besagt `2'Wer die Zukunft kennt, dem geh�rt die Gegenwart.'
`n`7 und ein anderes
`2'Ein Zwerge u. R�der (c) Produkt. Defekte an Schmiede-Weg 19, Gargrim Flammensohn'`7...`n`n`n
`^ 5 M�nzen f�r den Blick in die Zukunft.`n
20 M�nzen f�r ein Gutes Wort bei den Geistern");
}


else if ($_GET[op]=="horoskop"){
addnav("Zur�ck");
addnav("Zur�ck ins Dorf","village.php");
$session[user][gold]-=5;
output("`7 Etwas skeptisch wirfst du dein Gold in den schmalen Schlitz des Aparats.`n
Kurz darauf h�rst du ein lautes Klacken, dann ein Ratten und Krachen. Rauch dringt aus dem Ausgabeschlitz...`n
Und Stille.`n Schon glaubst du dein Gold verloren, ja verschwendet und willst dich zum gehen wenden,
da ert�nt ein leises Gl�ckchen...`n Und ein kleiner Zettel erscheint im Ausgabeschacht. Darauf ist zu lesen:`n`n`n");

// Liebe
{output("`\$Liebe:`n`n");}

$lvl=$session[user][level];
$drag=$session['user']['dragonkills'];
$age=$session['user']['age'];
if ($session['user']['dragonkills']>=21) {$drag=-20;}
if ($session['user']['dragonkills']>=41) {$drag=-20;}
if ($session['user']['dragonkills']>=61) {$drag=-20;}
if ($session['user']['dragonkills']>=81) {$drag=-20;}
if ($session['user']['dragonkills']>=101) {$drag=-20;}

if ($lvl+$drag <=2 ) {output("`\$Schlank und blond wird deine Liebe sein...`n`n");}
else if ($lvl+$drag <= 4) {output("`\$Du wirst herausfinden, dass Zwerge nicht nur Gold lieben... Dein Gl�ck ist 1,20 m gro�.`n`n");}
else if ($lvl+$drag <=6 ) {output("`\$Ein gro�er Unbekannter wird in dein Leben treten... Er wird dir n�her kommen...
Wird dich ber�hren... Seine Lippen ber�hren dein Ohr und er sagt: 'Gold oder Leben, und wehe du schreist!'`n`n");}
else if ($lvl+$drag <=8 ) {output("`\$Heute wirst du dein Gl�ck finden!`n`n");}
else if ($lvl+$drag <=10 ) {output("`\$Nutze den Tag, sei mutig und offen, dann wird sich deine Liebe offenbaren.`n`n");}
else if ($lvl+$drag <=12) {output("`\$Sie achtet nicht auf �u�erlichkeiten, deine innere Gr��e ist f�r sie entscheidend.
Na'Kra die Trollfrau sehnt sich nach dir...`n`n");}
else if ($lvl+$drag <=14) {output("`\$Tief-Purpurne Augen, dunkelblond und ein h�bsches Gesicht... Halte Ausschau!`n`n");}
else if ($lvl+$drag <=16) {output("`\$Heute steht es schlecht um deine Liebe... Vieleicht solltest du ein Bad nehmen...`n`n");}
else if ($lvl+$drag <=18) {output("`\$Es gibt viele Wege in ein liebendes Herz. Deiner hei�t Seife!`n`n");}
else if ($lvl+$drag <=20) {output("`\$Geheimnissvoll und sch�n...`n`n");}
else if ($lvl+$drag >20) {output("`\$Du wirst deine wahre Liebe nicht heute finden.`n`n");}

// Wetter
{output("`^Das Wetter:`n`n");}
output(" `^Das Wetter ist heute `^".$settings['weather']."`^.`n`n");

// Beruf
{output("`@Beruf:`n`n");}
output(" `@");

if ($age+$drag <=2 ) {output("`@Ein Gnom wird mit einem �u�erst dubiosen Gesch�ft an dich herantreten. Lehne ab!");}
else if ($age+$drag <=4 )  {output("`@Du wirst heute in den Feldern Erfolg haben!");}
else if ($age+$drag <=6 )  {output("`@Ein Ale w�rde deine Angriffskraft heben.");}
else if ($age+$drag <=8 )  {output("`@Der lezte Goblin den du erschlagen hast war ein naher Verwandter. Du solltest dich sch�men!");}
else if ($age+$drag <=10 )  {output("`@Habe keine Bedenken, wenn du heute eine R�stung stiehlst wird man dich nicht erwischen.");}
else if ($age+$drag <=12 )  {output("`@Du solltest heute nicht mehr in den Wald gehen. Es k�nnte sein dass man dich t�tet!");}
else if ($age+$drag <=14 )  {output("`@Du solltest heute nicht in den Feldern �bernachten...");}
else if ($age+$drag <=16 )  {output("`@Lasse dein Gold nicht mehr auf der Bank, sonst wird es dir gestohlen!");}
else if ($age+$drag <=18 )  {output("`@Sei heute freigiebig mit deinem Gold, es wird sich sp�ter f�r dich lohnen!");}
else if ($age+$drag <=20 )  {output("`@Die Farbe ist verwischt...");}
else if ($age+$drag >20 )  {output("`@Du solltest heute in ein neues Reittier investieren!");}

// Weisheit
{output("`#`n`nHeutige Weisheit:`n`n");}
output(" `#");

if ($age+$drag+$lvl-2 <=2 ) {output("`#Wenn es nachts im Bette kracht der Bauer seine Erben macht.");}
else if ($age+$drag+$lvl-2 <=4 )  {output("`#Dreht der Hahn sich auf dem Grill, macht das Wetter was es will.");}
else if ($age+$drag+$lvl-2 <=6 )  {output("`#Das Ale im Glase ist besser als der Tropfen im Fass.");}
else if ($age+$drag+$lvl-2 <=8 )  {output("`#Es ist des Zwergen Eigenart, dass er die Frauen mag behaart.");}
else if ($age+$drag+$lvl-2 <=10 )  {output("`#Elfen sind doof!");}
else if ($age+$drag+$lvl-2 <=12 )  {output("`#Weib ist jener, der sich badet aus freiem Willen.");}
else if ($age+$drag+$lvl-2 <=14 )  {output("`#Sieht die Magd den Bauern nackt, wird vom Brechreiz sie gepackt.");}
else if ($age+$drag+$lvl-2 <=16 )  {output("`#Ein Ale kaufen ist gut, ein Ale spendiert bekommen besser, es trinken das Beste!");}
else if ($age+$drag+$lvl-2 <=18 )  {output("`#Steht im Winter noch das Korn, ists bestimmt vergessen worn.");}
else if ($age+$drag+$lvl-2 <=20 )  {output("`#Wenn du aufwachst mit der Flasche im Arm und nichts an, dann war es ein gutes Bes�ufniss.");}
else if ($age+$drag+$lvl-2 >20 )  {output("`#Wenn der Bauer zum Waldrand hetzt, war der Abort wohl besetzt.");}
}

else if ($_GET[op]=="wort"){
addnav("Zur�ck");
addnav("Zur�ck ins Dorf","village.php");
$session[user][gold]-=20;
output("`7 Etwas skeptisch wirfst du dein Gold in den schmalen Schlitz des Aparats.`n
Kurz darauf h�rst du ein lautes Klacken, dann ein Ratten und Krachen. Rauch dringt aus dem Ausgabeschlitz...`n
Und Stille.`n Schon glaubst du dein Gold verloren, ja verschwendet und willst dich zum gehen wenden,
da ert�nt ein leises Gl�chen...`n Und ein kleiner Zettel erscheint im Ausgabeschacht. Darauf ist zu lesen:`n
'Die Geister sind mit dir...'`n`n");

$wort = e_rand(1,30);
if($wort==1) {
$session[user][drunkenness] *= .9;
output("`2 Du f�hlst dich jetzt n�chterner...");}
if($wort==2) {
$session[user][charm]++;
output("`2 Du f�hlst dich jetzt sch�ner...");}
if($wort==3){
output("`2Die Geister sind jetzt auf deiner Seite!`0`n");
$session['bufflist']['segen'] = array("name"=>"`9Gute Geister","rounds"=>8,"wearoff"=>"Die Geister unterst�tzen dich nicht l�nger....","defmod"=>1.1,"roundmsg"=>"`9Die Geister sind auf deiner Seite!.","activate"=>"offense");
}
if($wort>=4) {output("`2 Du weist zwar nicht warum, doch du f�hlst dich jetzt besser..."); }

}else if ($_GET[op]=="kostenlos"){
addnav("Nein, lieber nicht","horoskop.php");
addnav("Zur�ck");
addnav("Zur�ck ins Dorf","village.php");
output("`7 Etwas skeptisch wirfst du dein Gold in den schmalen Schlitz des Aparats.`n
Kurz darauf h�rst du ein lautes Klacken, dann ein Ratten und Krachen. Rauch dringt aus dem Ausgabeschlitz...`n
Und Stille.`n Schon glaubst du dein Gold verloren, ja verschwendet und willst dich zum gehen wenden,
da ert�nt ein leises Gl�chen...`n Und ein kleiner Zettel erscheint im Ausgabeschacht. Darauf ist zu lesen:`n`n
'Nichts im Leben ist umsonst, nur der Tod und selbst der kostet das Leben... M�chtest du wirklich ein kostenloses
Horoskop? Es wird dann auch mit Sicherheit in Erf�llung gehen...?'`n`n");
}
page_footer();
?>

