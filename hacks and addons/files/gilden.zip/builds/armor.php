<?php

$request_filename = basename($_SERVER['SCRIPT_NAME']);
if($request_filename!="gildenverwalt.php")
{
  //print($request_filename);
  print highlight_string(join("",file($request_filename)),true);
  exit();
}
/* Navigation */
          addnav("�bersicht","gildenverwalt.php?op=verwaltbuild&action=armor");
          addnav("R�stung hinzuf�gen","gildenverwalt.php?op=verwaltbuild&action=armor&do=add");
          switch($_GET['do'])
          {
            case "":
              output("`3In diesem Men� kannst du R�stungen schmieden lassen (Maximal sind `^".maxarmors."`3 R�stungen erlaubt. Eine R�stung wird automatisch, wenn keine Exemplare mehr vorhanden sind, von der Liste genommen).");
              showarmors(false);
              break;
            case "add":
              armorform("gildenverwalt.php?op=verwaltbuild&action=armor&do=add2");
              break;
            case "add2":
              $counter_ = db_query("SELECT COUNT(value1) AS c FROM gilden_data WHERE gildenid='".$session['guild']['gildenid']."' AND name='amor'");
              $counter = db_fetch_assoc($counter_);
              db_Free_Result($counter_);
              if($counter['c']>=maxarmors)
              {
                output("`\$Deine Gilde hat schon zuviele R�stungen schmieden lassen. Das Lager ist voll, noch eine R�stung und jedes Mitglied m�sste zus�tzlich Gold f�r die Unterhaltung eines gr�sses Lagerhauses aufbringen.");
              }
              elseif($session['guild']['gold'] < ($cost_values[$_POST['damage']]*$_POST['piece']))
              {
                output("`\$Deine Gilde hat nicht gen�gend Gold zur Verf�gung, um sich das Material leisten zu k�nnen.`n");
              }
              else
              {
                insertarmor($_POST['name'],$_POST['damage'],$_POST['piece']);
                $goldcosts = ($cost_values[$_POST['damage']]*$_POST['piece']);
                // die($goldcosts);
                guild_update("gold",$session['guild']['gold']-$goldcosts);
              }
              break;
            /* Weapon edit by Hadriel */
            case "edit":
              editarmor($_GET['armorid'],"gildenverwalt.php?op=verwaltbuild&action=armor&do=editfin");
              break;
            case "editfin":
              update_armor($_POST['id']);
              break;
            /* Weapon edit end */
            default:
              redirect("gildenverwalt.php?op=verwaltbuild&action=weapon");
          }
?>
