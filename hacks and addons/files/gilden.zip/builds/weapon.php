<?php

$request_filename = basename($_SERVER['SCRIPT_NAME']);
if($request_filename!="gildenverwalt.php")
{
  //print($request_filename);
  print highlight_string(join("",file($request_filename)),true);
  exit();
}

/* Navigation */
          addnav("�bersicht","gildenverwalt.php?op=verwaltbuild&action=weapon");
          addnav("Waffe hinzuf�gen","gildenverwalt.php?op=verwaltbuild&action=weapon&do=add");
          switch($_GET['do'])
          {
            case "":
              output("`3In diesem Men� kannst du Waffen schmieden lassen (Maximal sind `^".maxweapons."`3 Waffen erlaubt. Eine Waffe wird automatisch, wenn keine Exemplare mehr vorhanden sind, von der Liste genommen).");
              showweapons(false);
              break;
            case "add":
              weaponform("gildenverwalt.php?op=verwaltbuild&action=weapon&do=add2");
              break;
            case "add2":
              $counter_ = db_query("SELECT COUNT(value1) AS c FROM gilden_data WHERE gildenid='".$session['guild']['gildenid']."' AND name='weapon'");
              $counter = db_fetch_assoc($counter_);
              // db_Free_Result($counter_);
              
              if($counter['c']>=maxweapons)
              {
                output("`\$Deine Gilde hat schon zuviele Waffen schmieden lassen. Das Lager ist voll, noch eine Waffe und jedes Mitglied m�sste zus�tzlich Gold f�r die Unterhaltung eines gr�sses Lagerhauses aufbringen.");
              }
              elseif($session['guild']['gold'] < ($cost_values[$_POST['damage']]*$_POST['piece']))
              {
                output("`\$Deine Gilde hat nicht gen�gend Gold zur Verf�gung, um sich das Material leisten zu k�nnen.`n");
              }
              else
              {
                insertweapon($_POST['name'],$_POST['damage'],$_POST['piece']);
                $goldcosts = ($cost_values[$_POST['damage']]*$_POST['piece']);
                // die($goldcosts);
                guild_update("gold",$session['guild']['gold']-$goldcosts);
              }
              break;
            /* Weapon edit by Hadriel */
            case "edit":
              editweapon($_GET['weaponid'],"gildenverwalt.php?op=verwaltbuild&action=weapon&do=editfin");
              break;
            case "editfin":
              update_weapon($_POST['id']);
              break;
            /* Weapon edit end */
            default:
              redirect("gildenverwalt.php?op=verwaltbuild&action=weapon");
          }
          
?>
