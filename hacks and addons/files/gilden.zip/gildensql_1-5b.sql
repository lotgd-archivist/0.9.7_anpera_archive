--
-- Tabellenstruktur f�r Tabelle `gilden`
-- 

CREATE TABLE `gilden` (
  `gildenid` int(11) NOT NULL auto_increment,
  `gildenname` varchar(100) NOT NULL default '',
  `gildenname_b` varchar(100) NOT NULL default '',
  `gildenprefix` varchar(18) NOT NULL default '',
  `gildenprefix_b` varchar(5) NOT NULL default '',
  `gildendesc` text NOT NULL,
  `gildenstory` text NOT NULL,
  `gildenregeln` text NOT NULL,
  `gildenpunkte` int(11) NOT NULL default '0',
  `gold` int(11) NOT NULL default '0',
  `gems` int(11) NOT NULL default '0',
  `leaderid` int(11) unsigned NOT NULL default '0',
  `active` enum('0','1') NOT NULL default '1',
  PRIMARY KEY  (`gildenid`)
) TYPE=MyISAM COMMENT='Gilden-Tabelle';

-- 
-- Tabellenstruktur f�r Tabelle `gildenranks`
-- 

CREATE TABLE `gildenranks` (
  `rankid` int(11) NOT NULL auto_increment,
  `gildenid` int(11) NOT NULL default '0',
  `sortid` int(11) NOT NULL default '1',
  `rankname` varchar(200) NOT NULL default '',
  PRIMARY KEY  (`rankid`)
);

-- 
-- Tabellenstruktur f�r Tabelle `bewerbungen`
-- 

CREATE TABLE `bewerbungen` (
  `bewerbid` int(11) NOT NULL auto_increment,
  `bewerberid` int(11) unsigned NOT NULL default '0',
  `gildenid` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`bewerbid`)
);

-- 
-- Tabellenstruktur f�r Tabelle `gilden_ausbau`
-- 

CREATE TABLE `gilden_ausbau` (
  `ownerguild` int(11) NOT NULL default '0',
  `name` varchar(50) NOT NULL default '',
  `stufe` int(5) NOT NULL default '0',
  `value1` int(11) NOT NULL default '0',
  `value2` int(11) NOT NULL default '0',
  `goldcost` int(7) NOT NULL default '0',
  `gemcost` int(7) NOT NULL default '0',
  `givepoint` int(7) NOT NULL default '0',
  `link` varchar(50)  NOT NULL default '',
  PRIMARY KEY  (`ownerguild`,`name`,`stufe`)
);

-- 
-- Daten f�r Tabelle `gilden_ausbau`
-- 

INSERT INTO `gilden_ausbau` VALUES (0, 'Marktplatz', 1, 2, 0, 20000, 20, 50, 'marktplatz');
INSERT INTO `gilden_ausbau` VALUES (0, 'Marktplatz', 2, 5, 0, 30000, 35, 0, 'marktplatz');
INSERT INTO `gilden_ausbau` VALUES (0, 'Waffenshop', 1, 0, 0, 25000, 30, 70, 'weapon');
INSERT INTO `gilden_ausbau` VALUES (0, 'R�stungshop', 1, 0, 0, 25000, 30, 70, 'armor');


-- 
-- Tabellenstruktur f�r Tabelle `gilden_data`
--

CREATE TABLE `gilden_data` (
  `gildenid` int(11) NOT NULL default '0',
  `name` varchar(50) NOT NULL default '',
  `value1` int(11) NOT NULL default '0',
  `value2` int(11) NOT NULL default '0',
  `value3` int(11) NOT NULL default '0',
  `value4` int(11) NOT NULL default '0',
  `value5` int(11) NOT NULL default '0',
  `data` longtext NOT NULL,
  PRIMARY KEY  (`gildenid`,`name`,`value1`)
);


-- 
-- Zus�tzliche Felder f�r die Tabelle `accounts` 
--

ALTER TABLE accounts
ADD `memberid` int(11) NOT NULL default '0',
ADD `gildenactive` enum('0','1') NOT NULL default '0',
ADD `rankid` int(11) NOT NULL default '0',
ADD `isleader` int(3) default '0',
ADD `gildengold` int(11) NOT NULL default '0',
ADD `gildengems`int(11) NOT NULL default '0'; 