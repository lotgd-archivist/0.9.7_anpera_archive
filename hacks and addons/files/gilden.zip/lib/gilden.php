<?php
#-----------------------------------------#
#   Gildensystem Version: 1.5b            #
#   ~~ Funktionen ~~                      #
#   Autor: Eliwood                        #
#   Mit Unterst�zung von: Nephilea        #
#-----------------------------------------#

/* Struktur zus�tzlicher Accounts-Felder:
-------------------------------------------------------------------
|   Feldname       Typus           SIGNED || Charset    Null?  default
|   memberid   	    int(11)  	   	   UNSIGNED  	        Nein   	0
|	  gildenactive  	enum('0', '1') 	latin1_german1_ci 	Nein  	0
|	  rankid  	      int(11) 	  	  	                  Nein  	0
|	  isleader  	    int(3) 	  	     UNSIGNED 	        Nein  	0
|	  gildengold  	  int(11) 	  	  	                  Nein  	0
|	  gildengems  	  int(11) 	  	  	                  Nein  	0
-------------------------------------------------------------------
*/

/* Einstellungen laden */

/* Define Settings */
define("dkrequired",(int)getsetting("gilden_dkrequired",10)); // Ben�tigte Drachenkills
define("goldprice",(int)getsetting("gilden_goldprice",25000)); // Goldpreis der Gilde
define("gemprice",(int)getsetting("gilden_gemprice",20)); // Edelsteinpreis der Gilde
define("bewerbpreis",(int)getsetting("gilden_bewerbpreis",1000)); // Preis zum Bewerben
define("maxgold",(int)getsetting("gilden_maxgold",1000000)); // Goldlagergr�sse
define("maxgems",(int)getsetting("gilden_maxgems",1000)); // Edelsteinlagergr�sse
define("minchar",(int)getsetting("gilden_minchar",10)); // Mindestl�nge das Gildennamens, ohne Farbcodes
define("highestleader",(int)getsetting("gilden_highestleader",2)); // H�chste leaderid (Leaderkennungszahl)
define("buildactive",(bool)getsetting("gilden_buildactive",TRUE)); // Ausbau aktiv?
define("goldperlevel",(int)getsetting("gilden_goldperlevel",1000)); // Goldtransfer pro Level
define("gemsperlevel",(int)getsetting("gilden_gemsperlevel",2)); // Edelsteintransfer pro Level
define("maxweapons",(int)getsetting("gilden_maxweapons",5)); // Maximale Waffen pro Gilde
define("maxarmors",(int)getsetting("gilden_maxarmors",5)); // Maximale R�stungen pro Gilde

DEFINE("SQL_CACHE",(bool)getsetting("gilden_SQL_CACHE",FALSE)); // Bitte, nur aktivieren, wenn garantiert wegen dem keine Fehlermeldungen kommen!

/* Define Functions */

/* Gilde laden */
function loadguild($id)
{
   global $session,$SQL_CACHE;
   if($id > 0)
   {
    $sql = "SELECT ".(SQL_CACHE==true?"SQL_CACHE":"")." * FROM gilden WHERE gildenid= '".$id."'";
    $result = db_query($sql);
    $session['guild'] = db_fetch_assoc($result);
    db_free_result($result);
    $session['guild']['gildenname'] = stripslashes($session['guild']['gildenname']);
    $session['guild']['gildenprefix'] = stripslashes($session['guild']['gildenprefix']);
    $sql = "SELECT rankname FROM gildenranks WHERE rankid='".$session['user']['rankid']."'";
    $rank = db_fetch_assoc(db_unbuffered_query($sql));
    $session['rank'] = $rank['rank'];
   }
}

/* Gilde speichern, eigentlich nicht mehr n�tig, aber ich lass es mal drinne */
function saveguild($id)
{
  global $session;
  if($id>0)
  {
    $sql="UPDATE `gilden` SET ";
    // unset($session['house']['houseid']);
    reset($session[house]);
  	while(list($key,$val)=each($session[house])){
  		if (is_array($val)){
				$sql.="`".$key."` = '".addslashes(serialize($val))."', ";
			}else{
				$sql.="`".$key."` = '".addslashes($val)."', ";
			}
  	}
  	$sql = substr($sql,0,strlen($sql)-2);
  	$sql.=" WHERE `gildenid` = '".$id."' LIMIT 1";
    db_unbuffered_query($sql,LINK);
  }
}

/* Zeige Gilden */
function showguilds($id=false,$withlink=false,$detaillink=false)
{
  global $session,$output,$SQL_CACHE;
  if($id === false)
  {
    $output.="<table align='center' bgcolor='#999999' cellpadding='2' cellspacing='1'>";
    $output.="<tr class='trhead'><td>";
    output("K�rzel");
    $output.="</td><td>";
    output("Name der Gilde");
    $output.="</td><td>";
    output("Leader");
    $output.="</td><td>";
    output("Punkte");
    if($withlink !== false || $detaillink!==false)
    {
      $output.="</td><td>";
      output("Ops");
    }
    $output.="</td></tr>";
    $sql = "SELECT ".(SQL_CACHE==true?"SQL_CACHE":"")." * FROM gilden WHERE active='1' ORDER BY gildenpunkte DESC";
    $result = db_query($sql);
    $i = 0;
    while($row = db_fetch_assoc($result))
    {
      $sql = "SELECT ".(SQL_CACHE==true?"SQL_CACHE":"")." name FROM accounts WHERE acctid='".$row['leaderid']."'";
      $row2 = db_fetch_assoc(db_unbuffered_query($sql));
      $bgcolor = ($i%2==1?"trdark":"trlight");
      $output.="<tr class='$bgcolor'><td>";
      output(stripslashes($row['gildenprefix']));
      $output.="</td><td>";
      output(stripslashes($row['gildenname']));
      $output.="</td><td>";
      output($row2['name']);
      $output.="</td><td align='center'>";
      output("`&".$row['gildenpunkte']."`0");
      if($withlink !== false || $detaillink===true)
      {
        $output.="</td><td>";
        if($withlink !== false)
        {
          output("`&[<a href='".$withlink."&id=".$row['gildenid']."'> `xBewerben </a>`&] |",true);
          addnav("",$withlink."&id=".$row['gildenid']);
        }
        /* Details (PopUp) */
        if($withlink !== false || $detaillink===true) output(" `&[<a href='showdetail.php?id=".$row['gildenid']."' target='window_popup' onClick=\"".popup("showdetail.php?id=".$row['gildenid'])."; return false;\"> `xDetails </a>`&]",true);
      }
      $output.="</td></tr>";
      $i++;
    }
    db_free_result($result);
  }
  else
  {
    $sql = "SELECT ".(SQL_CACHE==true?"SQL_CACHE":"")." * FROM gilden WHERE active='1' AND gildenid='$id'";
    $result = db_query($sql);
    $row = db_fetch_assoc($result);
    output("<p align='center'>",true);
    output("`b".stripslashes($row['gildenname'])."`b`n`n");
    output("`3~~ Beschreibung `3~~`n`n");
    output(stripslashes($row['gildendesc']),true);
    output("`n`n`3~~ Geschichte `3~~`n`n");
    output(stripslashes($row['gildenstory']),true);
    output("`n`n`3~~ Regeln `3~~`n`n");
    output(stripslashes($row['gildenregeln']),true);
    output("</p>",true);
  }
}

/* Preistafel */
function preistafel()
{
  global $bewerbpreis,$goldprice,$gemprice;
  rawoutput("<pre>");
  output("");
  output("`2#----------------------------------------------------------------------#");
  output("`2# - `3Bewerbungskosten: `^".bewerbpreis." Gold                                        `2#");
  output("`2# - `3Goldkosten f�r gegr�ndete Gilde: `^".goldprice." Gold                        `2#");
  output("`2# - `3Edelsteinkosten f�r gegr�ndete Gilde: `%".gemprice." Edelsteine                `2#");
  output("`2#----------------------------------------------------------------------#");
  rawoutput("</pre>");
}

/* Zeilen, 1 Zeile, 2 Spalten */
function rowform($title=false,$input=false)
{
  global $output;
  if($title===false)
  {
    $output.= "<tr><td colspan='2' align='center'>";
    $output.= $input;
    $output.= "</td></tr>";
  }
  else
  {
    $output.= "<tr><td>";
    $output.= $title;
    $output.= "</td><td>";
    $output.= $input;
    $output.= "</td></tr>";
  }
}

/* Formular f�r die Gr�ndung */
function grundform($action,$tool=false)
{
  global $output;
  $output.="<form action='$action' method='POST'><table>";
  rowform("Name der Gilde (Ohne Farbcodes)","<input type='text' size='30' value='{$_POST['gildenname_b']}' maxlength='100' name='gildenname_b'>");
  rowform("Name der Gilde (Mit Farbcode","<input type='text' size='30' value='{$_POST['gildenname']}' maxlength='100' name='gildenname'>");
  rowform("Prefix (Ohne Farbcodes)","<input type='text' size='5' value='{$_POST['gildenprefix_b']}' maxlength='5' name='gildenprefix_b'>");
  rowform("Prefix (Mit Farbcodes)","<input type='text' size='5' value='{$_POST['gildenprefix']}' maxlength='18' name='gildenprefix'>");
  if($tool===true)
  {
    rowform("Besitzer","<input type='text' size='10' value='{$_POST['leaderid']}' maxlength='10' name='leaderid'>");
  }
  rowform(false,"<input class='button' type='submit' value='Best�tigen'>");
  $output.="</table></form>";
  addnav("",$action);
}

/* Eingabe �berpr�fen */
function check_input($var)
{
  global $error,$minchar;
  if($_POST['gildenname_b']!=striptag($_POST['gildenname']))
  {
    $error = "ERROR! Verwende bitte gleiche Namen, danke.";
    $allow = false;
  }
  elseif($_POST['gildenprefix_b']!=striptag($_POST['gildenprefix']))
  {
    $error = "ERROR! Verwende bitte gleiche Prefixe, danke.";
    $allow = false;
  }
  elseif($_POST['gildenname_b']=="" || strlen($_POST['gildenname_b'])<minchar)
  {
    $error = "ERROR! Name leer oder zu kurz.";
    $allow = false;
  }
  elseif($_POST['gildenprefix_b']=="")
  {
    $error = "ERROR! Prefix leer!";
    $allow = false;
  }
  else $allow = true;
  return $allow;
}

/* Links erlauben (Funktionsgleich mit addnav("",$link) */
if(!function_exists("allownav"))
{  
  function allownav($link)
  {
    global $session;
    $session['allowednavs'][$link.$extra]=true;
    $session['allowednavs'][str_replace(" ", "%20", $link).$extra]=true;
    $session['allowednavs'][str_replace(" ", "+", $link).$extra]=true;
  }
}

/* Tribut checken */
function check_tribut()
{
  global $session,$errorart,$error,$maxgold,$maxgems,$gold,$gems;
  if($session['user']['gold']<$gold)
  {
    $errorart = 1;
    $error .= "`\$Du kannst nicht mehr Gold einzahlen, als du bei dir hast!";
    return false;
  }
  elseif($session['user']['gems']<$gems)
  {
    $errorart = 2;
    $error .= "`\$Du kannst nicht mehr Edelsteine einzahlen, als du bei dir hast!";
    return false;
  }
  elseif(!is_numeric($gold) || !is_numeric($gems))
  {
    $errorart = 3;
    $error .= "`\$Gib eine Zahl ein!";
    return false;
  }
  elseif(($gold+$session['guild']['gold'])>maxgold)
  {
    $errorart = 4;
    $error .= "`\$Goldspeicher voll!";
    return false;
    continue;
  }
  elseif(($gems+$session['guild']['gems'])>maxgems)
  {
    $errorart = 5;
    $error .= "`\$Edelsteinspeicher voll!";
    return false;
  }
  elseif($gold < 0 || $gems < 0)
  {
    $errorart = 6;
    $error .= "`\$Argh... Cheater! Negative Zahlen z�hlen nicht!";
  }
  else return true;
}

if(!function_exists("page_title"))
{
  function page_title($data)
  {
    output("`c`b$data`b`c`n",true);
  }
}

if(!function_exists("db_unbuffered_query"))
{
  function db_unbuffered_query($sql) {
  global $session,$dbqueriesthishit,$dbtimethishit;
  	$dbqueriesthishit++;
  $dbtimethishit -= getmicrotime();
  	$fname = DBTYPE."_unbuffered_query";
  	$r = $fname($sql) or die(($session[user][superuser]>=3 || 1?"<pre>".HTMLEntities($sql)."</pre>":"").db_error(LINK));
  $dbtimethishit += getmicrotime();
  	return $r;
  }
}

function showuser_public()
{
  global $output,$session;
  $sql = "SELECT acctid,name,login,isleader,rankid FROM accounts WHERE memberid='".$session['guild']['gildenid']."' ".page("acctid","accounts","gilden.php?op=members","WHERE memberid='".$session['guild']['gildenid']."'")."";
  $result = db_query($sql);
  rawoutput("<table align='center' bgcolor='#999999' cellpadding='1' cellspacing='1'>");
  rawoutput("<tr class='trhead'>");
  rawoutput("<td>");
  output("Name");
  rawoutput("</td><td>");
  output("Aktueller Rang");
  rawoutput("</td></tr>");
  while($row = db_fetch_assoc($result))
  {
    $result_2 = db_unbuffered_query("SELECT rankname FROM gildenranks WHERE rankid='{$row[rankid]}'");
    $raw = db_fetch_assoc($result_2);
    $bgcolor = ($i%2?"trdark":"trlight");
    rawoutput("<tr class='$bgcolor'><td>");
    output($row['name']);
    rawoutput("</td><td>");
    output($raw['rankname']);
    rawoutput("</td></tr>");
    $i++;
  }
  rawoutput("</table>");
}

if(!function_exists("page"))
{
  function page($callfield,$table,$site,$whereclause,$perpage=30)
  {
    // Seitenfunktion 2005 by Eliwood
      $sql = "SELECT count($callfield) AS c FROM $table ".$whereclause."";
      ///output($sql);
    $result = db_unbuffered_query($sql);
    $row = db_fetch_assoc($result);
    $total = $row['c'];
    $perpage=30;
    if ($_GET['page']=="") $_GET['page']=1;
    $pageoffset = (int)$_GET['page'];
    	if ($pageoffset>0) $pageoffset--;
    	$pageoffset*=$perpage;
    	$from = $pageoffset+1;
    	$to = min($pageoffset+$perpage,$total);
    $limit=" LIMIT $pageoffset,$perpage ";
    /* Seiten verlinken */
        addnav("Seiten");
    for ($i=0;$i<$total;$i+=$perpage){
    	addnav("Seite ".($i/$perpage+1)." (".($i+1)."-".min($i+$perpage,$total).")","$site&page=".($i/$perpage+1));
    }
    return $limit;
  }
}

function guild_update($field,$value)
{
  global $session,$link;
  $sql = "UPDATE gilden SET `$field`='".addslashes($value)."' WHERE gildenid='{$session['guild']['gildenid']}'";
  db_query($sql) or die(db_error(LINK));
  $session['guild'][$field] = $value;
}

function show_builded_navs()
{
  global $session;
  $sql = "SELECT * FROM gilden_ausbau WHERE ownerguild='".$session['guild']['gildenid']."' AND name='marktplatz'";
  $result = db_query($sql);
  if(db_num_rows($result)==1)
  {
    addnav("Marktplatz");
    $sql = "SELECT * FROM gilden_ausbau WHERE ownerguild='".$session['guild']['gildenid']."' AND name!='marktplatz'";
    $result = db_unbuffered_query($sql);
    while($row = db_fetch_assoc($result))
    {
      addnav($row['name'],"gilden.php?op=build&action=$row[link]");
    }
  }
}

function is_buildet($what)
{
  global $session;
  $result = db_query("SELECT * FROM `gilden_ausbau` WHERE link='$what' AND ownerguild='".$session['guild']['gildenid']."'");
  if(db_num_rows($result)==1)
    return true;
  else
    return false;
}

function drop_me($my_acctid,$my_name,$my_leaderid)
{
  global $highestleader,$session;
  if($my_leaderid >= highestleader)
  {
    output("`\$Du darfst die Gilde SO nicht verlassen.");
  }
  else
  {
    db_unbuffered_query("UPDATE accounts SET isleader='0',memberid='0',gildenactive='0',rankid='0' WHERE acctid='$my_acctid'");
    $session['user']['isleader'] = 0;
    $session['user']['memberid'] = 0;
    $session['user']['gildenactive'] = '0';
    $session['user']['rankid'] = 0;
    systemmail($session['guild']['leaderid'],"K�ndigung","`^".$my_name."`# hat die fristlose K�ndigung eingereicht!");
    unset($session['guild']);
    addnav("Zur�ck zur Gildenstrasse","gildenstrasse.php");
    page_header("Gildenstrasse");
    page_footer();
    exit();
  }
}
?>
