<?php
#---------------------------------#
#   Gildenadmintool - Version 1   #
#   ~~ Funktionen~~               #
#   Autor: Eliwood - 2005         #
#---------------------------------#

/* Op-Checker */
function check_op($op,$link,$key="op")
{
  return ($_GET[$key]==$op?"":$link);
}

/* Eingabe �berpr�fen */
function check_input_su()
{
  global $error,$minchar;
  $owner = db_fetch_assoc(db_unbuffered_query("SELECT SQL_CACHE acctid,name,login,gildenactive FROM accounts WHERE acctid='".$_POST['leaderid']."'"));
  $allow = false;
  if($_POST['gildenname_b']!=striptag($_POST['gildenname']))
    $error = "ERROR! Verwende bitte gleiche Namen, danke.";
  elseif($_POST['gildenprefix_b']!=striptag($_POST['gildenprefix']))
    $error = "ERROR! Verwende bitte gleiche Prefixe, danke.";
  elseif($_POST['gildenname_b']=="" || strlen($_POST['gildenname_b'])<minchar)
    $error = "ERROR! Name leer oder zu kurz.";
  elseif($_POST['gildenprefix_b']=="")
    $error = "ERROR! Prefix leer!";
  elseif($owner['name'] == "" || $owner['acctid']<=0)
    $error = "ERROR! Unbekannter Besitzer";
  elseif($owner['gildenactive'] == '1')
    $error = "ERROR! Besitzer ist bereits Gildenaktiv!";
  else $allow = true;
  return $allow;
}

function showguilds_su($prelink)
{
  global $session,$SQL_CACHE,$highestleader;
  $sql['all'] = "SELECT ".(SQL_CACHE===true?"SQL_CACHE":"")." gilden.*,accounts.acctid,accounts.login FROM gilden INNER JOIN accounts ON gilden.leaderid=accounts.acctid AND gilden.gildenid!='".$session['user']['memberid']."'";
  $result['all'] = db_query($sql['all']);
  output(
    "<table><tr>".
    "<td>Name</td>".
    "<td>K�rzel</td>".
    "<td>Gr�nder</td>".
    "<td>`^Gold</td>".
    "<td>`%Edelsteine</td>".
    "<td>Punkte</td>".
    "<td>Mitglieder</td>".
    "<td>Aktiviert?</td>".
    "</tr>".
    "<tr><td colspan='8'><hr></td></tr>",true
  );
  while($row['all'] = db_fetch_assoc($result['all']))
  {
    $row['counter'] = db_fetch_assoc(db_query("SELECT ".(SQL_CACHE===true?"SQL_CACHE":"")." COUNT(acctid) AS members FROM accounts WHERE memberid='".$row['all']['gildenid']."' AND isleader!='".highestleader."'"));
    output(
      "<tr>".
      "<td>".$row['all']['gildenname']."</td>".
      "<td>".$row['all']['gildenprefix']."</td>".
      "<td>".$row['all']['login']."</td>".
      "<td>`^".$row['all']['gold']."</td>".
      "<td>`%".$row['all']['gems']."</td>".
      "<td>".$row['all']['gildenpunkte']."</td>".
      "<td>".$row['counter']['members']."</td>".
      "<td>".($row['all']['active']?"Ja":"Nein")."</td>".
      "</tr>",true
    );
    $nav = array(
      $prelink."op=edit&id=".$row['all']['gildenid'],
      $prelink."op=activate&id=".$row['all']['gildenid']."&active=".$row['all']['active'],
      $prelink."op=drop&id=".$row['all']['gildenid']
    );
    allownav($nav[0]);
    allownav($nav[1]);
    allownav($nav[2]);
    output(
      "<tr><td colspan='2'>Optionen:</td>".
      "<td colspan='6'>`0`&[ ".
      "`0<a href='".$nav[0]."'>`2Bearbeiten</a> `&| ".
      "`0<a href='".$nav[1]."'>`^".($row['all']['active']?"Dea":"A")."ktivieren</a> `&| ".
      "`0<a href='".$nav[2]."'>`\$L�schen</a>".
      " `&]`0</td>".
      "</tr>".
      "<tr><td colspan='8'><hr></td></tr>",true
    );
  }
}

function dropguild_su($id)
{
  global $session,$SQL_CACHE;
  $drop_guild = db_fetch_assoc(db_unbuffered_query("SELECT ".(SQL_CACHE===true?"SQL_CACHE":"")." * FROM gilden WHERE gildenid = '$id'"));
  addnews("`#Die Gilde `@{$drop_guild['gildenname']}`# wurde von `@{$session['user']['name']}`# aufgel�st.");
  db_query("DELETE FROM gilden WHERE gildenid='$id' LIMIT 1"); // Gilde l�schen
  db_query("DELETE FROM gildenranks WHERE gildenid='$id' LIMIT 1"); // R�nge l�schen
  db_query("DELETE FROM gilden_ausbau WHERE ownerguild='$id' LIMIT 1"); // Geb�ude l�schen
  db_query("DELETE FROM gilden_data WHERE gildenid='$id' LIMIT 1"); // Ausbau-Daten l�schen
  db_query("UPDATE accounts SET isleader='0',memberid='0',gildenactive='0',rankid='0' WHERE memberid='$id'"); // User entlassen
}

function edit_form($id,$formlink)
{
  global $session,$SQL_CACHE;
  $input = new input();
  $edit_guild = db_fetch_assoc(db_unbuffered_query("SELECT ".(SQL_CACHE===true?"SQL_CACHE":"")." * FROM gilden WHERE gildenid = '$id'"));
  allownav($formlink);
  output(
     "<table><form action='$formlink' method='POST'>"
    ."<tr><td colspan='2'>Bearbeite: ".$edit_guild['gildenname']."</td></tr>"
  ,true);
  rawoutput(
     "<tr><td>Name der Gilde (Inkl. Farbcodes)</td>"
    ."<td><input type='text' size='30' name='gildenname' maxlength='100' value='".$edit_guild['gildenname']."'/></td></tr>"
    ."<tr><td>Name der Gilde (Ohne Farbcodes)</td>"
    ."<td><input type='text' size='30' name='gildenname_b' maxlength='100' value='".$edit_guild['gildenname_b']."'/></td></tr>"
    ."<tr><td>K�rzel (Inkl. Farbcodes)</td>"
    ."<td><input type='text' size='5' maxlength='18' name='gildenprefix' value='".$edit_guild['gildenprefix']."'/></td></tr>"
    ."<tr><td>K�rzel (Ohne Farbcodes)</td>"
    ."<td><input type='text' size='5' maxlength='5' name='gildenprefix_b' value='".$edit_guild['gildenprefix_b']."'/></td></tr>"
    ."<tr><td>Gold</td>"
    ."<td><input type='text' size='5' name='gold' value='".$edit_guild['gold']."'/></td></tr>"
    ."<tr><td>Edelsteine</td>"
    ."<td><input type='text' size='5' name='gems' value='".$edit_guild['gems']."'/></td></tr>"
    ."<tr><td>Punkte</td>"
    ."<td><input type='text' size='5' name='gildenpunkte' value='".$edit_guild['gildenpunkte']."'/></td></tr>"
    ."<tr><td>Geschichte</td>"
    ."<td>".$input->textarea("gildenstory",5,30,stripslashes($edit_guild['gildenstory']))."</td></tr>"
    ."<tr><td>Beschreibung</td>"
    ."<td>".$input->textarea("gildendesc",5,30,stripslashes($edit_guild['gildendesc']))."</td></tr>"
    ."<tr><td>Regeln</td>"
    ."<td>".$input->textarea("gildenregeln",5,30,stripslashes($edit_guild['gildenregeln']))."</td></tr>"
    ."<tr><td>Aktiviert?</td>"
    ."<td>".$input->select("active",$edit_guild['active'],1,array("value"=>0,"name"=>"Nein"),array("value"=>1,"name"=>"Ja"))."</td></tr>"
    ."<tr><td align='center' colspan='2'>".$input->button("�nderungen �bernehmen")."</td></tr>"
  );
}

function update_guild_su($id)
{
  $edit_guild = db_fetch_assoc(db_unbuffered_query("SELECT ".(SQL_CACHE===true?"SQL_CACHE":"")." gildenname FROM gilden WHERE gildenid = '$id'"));
  db_query(
    "UPDATE `gilden` SET "
    ."`gildenname` = '".addslashes($_POST['gildenname'])."', "
    ."`gildenname_b` = '".addslashes($_POST['gildenname'])."', "
    ."`gildenprefix` = '".addslashes($_POST['gildenprefix'])."', "
    ."`gildenprefix_b` = '".addslashes($_POST['gildenprefix_b'])."', "
    ."`gold` = '".(is_numeric($_POST['gold'])?$_POST['gold']:0)."', "
    ."`gems` = '".(is_numeric($_POST['gems'])?$_POST['gems']:0)."', "
    ."`gildenpunkte` = '".(is_numeric($_POST['gildenpunkte'])?$_POST['gildenpunkte']:0)."', "
    ."`gildenstory` = '".addslashes($_POST['gildenstory'])."', "
    ."`gildendesc` = '".addslashes($_POST['gildendesc'])."', "
    ."`gildenregeln` = '".addslashes($_POST['gildenregeln'])."', "
    ."`active` = '".$_POST['active']."'"
    ."WHERE `gildenid`='$id' LIMIT 1"
  );
  output("`c".$edit_guild['gildenname']." ge�ndert!`c`n");
}

function activateguild($id,$active)
{
  if($active == 1)
  {
    db_unbuffered_query("UPDATE gilden SET active='0' WHERE gildenid='$id'");
  }
  else
  {
    db_unbuffered_query("UPDATE gilden SET active='1' WHERE gildenid='$id'");
  }
  output("Die Gilde wurde ".($active==1?"Dea":"A")."ktiviert.");
}
?>
