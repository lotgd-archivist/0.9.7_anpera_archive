<?php
#-----------------------------------------#
#   Gildensystem Version: 1.5b            #
#   ~~ Funktionen f�r die Verwaltung ~~   #
#   Autor: Eliwood                        #
#   Mit Unterst�zung von: Nephilea        #
#-----------------------------------------#

function aufnehm($id,$name)
{
  global $session;
  output("`#Du nimmst `^$name`# in die Gilde auf.`n");
  $body = "`#Du wurdest in der Gilde `^{$session['guild']['gildenname']}`# aufgenommen.";
  $subject = "`@Aufgenommen!";
  systemmail($id,$subject,$body);
  $sql = "UPDATE accounts SET memberid='{$session['guild']['gildenid']}' WHERE acctid='$id'";
  db_query($sql);
  $sql = "DELETE FROM bewerbungen WHERE bewerberid='$id'";
  db_query($sql);
}

function ablehn($id,$name)
{
  global $session;
  output("`#Du verweigerst `^$name`# die Aufnahme in die Gilde.`n");
  $body = "`#Der eintritt in die Gilde `^{$session['guild']['gildenname']}`# wurde dir verweigert.";
  $subject = "`\$Abgelehnt!";
  systemmail($id,$subject,$body);
  $sql = "DELETE FROM bewerbungen WHERE bewerberid='$id'";
  db_query($sql);
  $sql = "UPDATE accounts SET gildenactive='0' WHERE acctid='$id'";
  db_query($sql);
}

function showbewerber()
{
  global $session;
  $sql = "SELECT bewerbungen.*, "
                   ."accounts.name, "
                   ."accounts.acctid, "
                   ."accounts.login "
                   ."FROM bewerbungen "
                   ."INNER JOIN accounts "
                   ."ON accounts.acctid = bewerbungen.bewerberid "
                   ."WHERE gildenid='".$session['guild']['gildenid']."'"
                   ."ORDER BY bewerbid ASC";
      $result = db_query($sql) or die(db_errno($sql,LINK).": ".db_error($sql,LINK));
      $i = 0;
      rawoutput("<table align='center' bgcolor='#999999' cellpadding='1' cellspacing='1'>");
      rawoutput("<tr class='trhead'>");
      rawoutput("<td>");
      output("Bewerbername");
      rawoutput("</td><td>");
      output("Optionen");
      rawoutput("</td></tr>");
      while($row = db_fetch_assoc($result))
      {
        $bgcolor = ($i%2?"trdark":"trlight");
        $login = RawUrlEncode($row['login']);
        $link = array(1=>"gildenverwalt.php?op=nimm&id=$row[acctid]&login=$login",2=>"gildenverwalt.php?op=ablehn&id=$row[acctid]&login=$login");
        rawoutput("<tr class='$bgcolor'><td>");
        output($row['name']);
        rawoutput("</td><td>");
        output("<a href='$link[1]'>`0[`2Annehmen`0]</a> &nbsp; <a href='$link[2]'>`0[`^Ablehnen`0]</a>",true);
        rawoutput("</td></tr>");
        allownav($link[1]);
        allownav($link[2]);
        $i++;
      }
      if($i == 0)
      {
        output("<tr><td align='center' colspan='2'>`~`b`iKeine Bewerbungen vorhanden`i`b</td></tr>",true);
      }
      rawoutput("</table>");
}

function showtitles($link = "gildenverwalt.php?op=ranks")
{
  global $session,$output;
  $sql = "SELECT * FROM gildenranks WHERE gildenid='".$session['guild']['gildenid']."' ORDER BY sortid,rankname DESC  ".page("rankid","gildenranks","gildenverwalt.php?op=ranks","WHERE gildenid='{$session['guild']['gildenid']}'")."";
  $result = db_unbuffered_query($sql);
  $output .= "<table align='center' bgcolor='#999999' cellpadding='1' cellspacing='1'>";
  $output .= "<tr class='trhead'>";
  $output .= "<td>";
  output("Rangname");
  $output .= "</td><td>";
  output("Optionen");
  $output .= "</td>";
  $output .= "</tr>";
  $i = 0;
  while($row = db_fetch_assoc($result))
  {
    $bgcolor = ($i%2?"trlight":"trdark");
    $output .= "<tr class='$bgcolor'>";
    $output .= "<td>";
    output("`&".stripslashes($row['rankname']));
    $output .= "</td><td>";
    $linkb = $link."&id=".$row['rankid'];
    $link1 = $linkb."&subop=edit";
    $link2 = $linkb."&subop=del";
    output("`0<a href='$link1'>`&[`2Rename`&]</a> `0<a href='$link2'>`&[`\$L�schen`&]</a>",true);
    $output .= "</td>";
    $output .= "</tr>";
    allownav($link1);
    allownav($link2);
    $i++;
  }
  $output .= "</table>";
  $linkb = $link."&subop=add";
  output("`n`n`c<a href='$linkb'>[ Rang hinzuf�gen ]</a>`c",true);
  allownav($linkb);
  
}

function createtitle($id=false)
{
  global $output,$session;
  if(!isset($_POST['rankname']))
  {
    if($id!==false)
    {
      $sql = "SELECT * FROM gildenranks WHERE rankid='$id'";
      $row = db_fetch_assoc(db_query($sql));
    }
    $output .= "<form action='gildenverwalt.php?op=ranks&subop=save' method='POST'><table>";
    allownav("gildenverwalt.php?op=ranks&subop=save");
    $output .= "<tr><td>";
    $output .= "Titelname: ";
    $output .= "</td><td>";
    $output .= "<input type='text' name='rankname' value='".stripslashes($row[rankname])."'>";
    $output .= "</td></tr>";
    $output .= "<tr><td>";
    $output .= "<input type='hidden' name='rankid' value='".($id===false?"not":$id)."'>";
    $output .= "</td><td>";
    $output .= "<input type='submit' value='Best�tigen'>";
    $output .= "</td></tr>";
    $output .= "</table";
  }
  elseif($id===false)
  {
    $sql = "INSERT INTO gildenranks (`rankname`,`gildenid`) VALUES ('".addslashes($_POST['rankname'])."','".$session['guild']['gildenid']."')";
    db_query($sql);
    output("`2Rang hinzugef�gt!`n");
  }
  else
  {
    $sql = "UPDATE gildenranks SET rankname='".addslashes($_POST[rankname])."' WHERE rankid='$id'";
    db_query($sql);
    output("`2Rang aktualisiert!`n");
  }
}

function deletetitle($id)
{
  global $output;
  output("`4`cTitel gel�scht`c`n");
  if(db_query("DELETE FROM gildenranks WHERE rankid='$id' LIMIT 1")) return true; else return false;
}

function showuser()
{
  global $output,$session;
  $sql = "SELECT acctid,name,login,isleader,rankid FROM accounts WHERE memberid='".$session['guild']['gildenid']."' ".page("acctid","accounts","gildenverwalt.php?op=members","WHERE memberid='".$session['guild']['gildenid']."'")."";
  $result = db_query($sql);
  rawoutput("<table align='center' bgcolor='#999999' cellpadding='1' cellspacing='1'>");
  rawoutput("<tr class='trhead'>");
  rawoutput("<td>");
  output("Name");
  rawoutput("</td><td>");
  output("Aktueller Rang");
  rawoutput("</td><td>");
  output("Optionen");
  rawoutput("</td></tr>");
  while($row = db_fetch_assoc($result))
  {
    /* R�nge laden */
    $result_2 = db_query("SELECT * FROM gildenranks WHERE gildenid='{$session[guild][gildenid]}' ORDER BY rankid");
    $ranklist.="<option value='0' ".($row['rankid']==0?"selected='selected'":"").">Kein Titel\n";
    while($ranks = db_fetch_assoc($result_2))
    {
      $ranklist.="<option ".($ranks['rankid']==$row['rankid']?" selected='selected' ":" ")."value='{$ranks[rankid]}'>{$ranks[rankname]}\n";
      if($ranks['rankid'] == $row['rankid']) $acrank = $ranks['rankname'];
    }
    $bgcolor = ($i%2?"trdark":"trlight");
    rawoutput("<tr class='$bgcolor'><td>");
    output($row['name']);
    rawoutput("</td><td>");
    output($acrank);
    rawoutput("</td><td>");
    $links = array(
      1=>"gildenverwalt.php?op=members&action=leader",
      2=>"gildenverwalt.php?op=members&action=rank",
      3=>"gildenverwalt.php?op=members&action=dropmember&dropid=".$row['acctid']
    );
    allownav($links[1]);
    allownav($links[2]);
    allownav($links[3]);
    /* Verwalterid zuweisen lassen */
    output(" <form action='$links[1]' method='POST'><input type='hidden' name='acctid' value='$row[acctid]'><input name='id' type='text' size='2' value='$row[isleader]'><input class='button' type='submit' value='Verwalterid zuweisen'></form> ",true);
    /* Rang zuweisen lassen */
    output(" <form action='$links[2]' method='POST'>"
          ."<select type='hidden' value='$row[acctid]' name='rank'>"
          .$ranklist
          ."</select>"
          ."<input name='acctid' type='hidden' value='$row[acctid]'>"
          ."<input class='button' type='submit' value='Rangzuweisen'>"
          ."</form>`n",true);
    output("`0[`0<a href='$links[3]'>`\$Entlassen</a>`0]",true);
    rawoutput("</td></tr>");
    $i++;
    unset($ranklist);
    unset($acrank);
    unset($links);
  }
  rawoutput("</table>");
}

function showuser_pay()
{
  global $output,$session;
  $sql = "SELECT acctid,name,login,isleader,rankid FROM accounts WHERE memberid='".$session['guild']['gildenid']."' AND acctid!='".$session['user']['acctid']."' ".page("acctid","accounts","gildenverwalt.php?op=belohnen","WHERE memberid='".$session['guild']['gildenid']."' AND acctid!='".$session['user']['acctid']."'")."";
  $result = db_query($sql);
  rawoutput("<table align='center' bgcolor='#999999' cellpadding='1' cellspacing='1'>");
  rawoutput("<tr class='trhead'>");
  rawoutput("<td>");
  output("Name");
  rawoutput("</td><td>");
  output("Optionen");
  rawoutput("</td></tr>");
  while($row = db_fetch_assoc($result))
  {
    $bgcolor = ($i%2?"trdark":"trlight");
    rawoutput("<tr class='$bgcolor'><td>");
    output($row['name']);;
    rawoutput("</td><td>");
    $links = array(1=>"gildenverwalt.php?op=belohnen&action=gold","gildenverwalt.php?op=belohnen&action=gems");
    allownav($links[1]);
    allownav($links[2]);
    /* Gold */
    output(" <form action='$links[1]' method='POST'>"
          ."<input type='hidden' name='acctid' value='$row[acctid]'>"
          ."<input type='hidden' name='art' value='gold'>"
          ."<input name='value' type='text' size='5' value='0'>"
          ."<input class='button' type='submit' value='Gold auszahlen'>"
          ."</form> ",true);
    /* Edelsteine */
    output(" <form action='$links[2]' method='POST'>"
          ."<input type='hidden' name='acctid' value='$row[acctid]'>"
          ."<input type='hidden' name='art' value='gems'>"
          ."<input name='value' type='text' size='5' value='0'>"
          ."<input class='button' type='submit' value='Edelsteine auszahlen'>"
          ."</form> ",true);
    rawoutput("</td></tr>");
    $i++;
  }
  rawoutput("</table>");
}

fuNcTiOn show_text($art)
{
  GlObAl $session;
  switch ($art):
    case "desc": $field = "gildendesc"; $ptitle = "Beschreibung �ndern"; break;
    case "story": $field = "gildenstory"; $ptitle = "Geschichte �ndern"; break;
    case "regeln":  $field = "gildenregeln"; $ptitle = "Regeln �ndern"; break;
  endswitch;
  page_title($ptitle);
  rawoutput("<p align='center'>");
  output("`#Aktuell:`n`n");
  output(stripslashes($session['guild'][$field]),true);
  output("`#`n`n�ndern:`n`n");
  $link = "gildenverwalt.php?op=texte&text=".$art."";
  allownav($link);
  rawoutput("<form action='$link' method='POST'>");
  rawoutput("<textarea class='input' rows='20' cols='50' name='text'>".stripslashes($session['guild'][$field])."</textarea><br />");
  rawoutput("<input type='submit' class='button' value='�nderungen �bernehmen'>");
  rawoutput("<input type='hidden' value='$field' name='field'>");
  rawoutput("</form>");
  output("`\$HTML erlaubt, f�r Abs�tze ``n oder <br> verwenden.");
  rawoutput("</p>");
}

function show_build_navs()
{
  global $session;
  /* Marktplatz Stufe 1 (N�tig)*/
  $result = db_query("SELECT * FROM `gilden_ausbau` WHERE `ownerguild`='".$session['guild']['gildenid']."' AND `name`='Marktplatz'") or die(db_error(LINK));
  if(db_num_rows($result)==0)
  {
    $row = db_fetch_assoc($result);
    addnav("Marktplatz bauen (Stufe `^1`0)","gildenverwalt.php?op=build&action=marktplatz&stufe=1");
  }
  /* Sonstiges */
  else
  {
    $row = db_fetch_assoc($result);
    $count = db_fetch_assoc(db_unbuffered_query("SELECT COUNT(name) AS count FROM gilden_ausbau WHERE name!='Marktplatz' AND ownerguild='".$session['guild']['gildenid']."'"));
    $count = $count['count'];
    $freeplaces = ($row['value1']-$count);
    // $freeplaces = 0;
    addnav("Noch ".($freeplaces)." Pl�tze frei","");
    if($freeplaces == 0)
    {
      $sql = "SELECT * FROM gilden_ausbau WHERE name='Marktplatz' AND stufe>'$row[stufe]' ORDER BY stufe ASC LIMIT 1";
      $result2 = db_query($sql) or die(db_error(LINK));
      if(db_num_rows($result2)>0)
      {
        $row2 = db_Fetch_Assoc($result2);
        addnav($row['name']." ausbauen (Stufe `^$row2[stufe]`0)","gildenverwalt.php?op=build&action=$row2[link]&stufe=$row2[stufe]&value=$row2[value1]");
      }
      else {addnav("Marktplatz nicht weiter ausbaubar","");}
    }
    else
    {
      $sql_ = "SELECT * FROM gilden_ausbau WHERE ownerguild='0' AND name!='Marktplatz'";
      $result2_ = db_query($sql_);
      while($row2 = db_fetch_assoc($result2_))
      {
        $check_sql = db_query("SELECT * FROM gilden_ausbau WHERE ownerguild='{$session[guild][gildenid]}' AND name='$row2[name]'");
        if(db_num_rows($check_sql)==0)
        {
          $navlink = "";
          if($row2['goldcost']<$session['guild']['gold'] && $row2['gemcost']<$session['guild']['gems'])
            $navlink = "gildenverwalt.php?op=build&action=".$row2['link']."&stufe=".$row2['stufe'];
          addnav($row2['name'],$navlink);
        } // end if
      } // end while
    } // end else
  } // end else
} // end function

function build_something($what)
{
  global $session;
  $sql = "SELECT * FROM gilden_ausbau WHERE ownerguild='0' AND link='$what'";
  $row = db_fetch_assoc(db_unbuffered_query($sql));
}

/* User entlassen */
function drop_member($id)
{
  global $session,$highestleader;
  $drop_user = db_fetch_assoc(db_unbuffered_query("SELECT name,isleader FROM accounts WHERE acctid='$id'"));
  if($drop_user['isleader']>=highestleader)
  {
    output("`\$ERROR! Du darfst den Gr�nder nicht entlassen!");
  }
  elseif($session['user']['isleader']<highestleader && $session['user']['isleader']>0 && $drop_user['isleader']>0)
  {
    output("`\$ERROR! Nur der Gr�nder kann eingesetzte Verwalter entlassen!");
  }
  elseif($id === $session['user']['acctid'])
  {
    output("`\$ERROR! Du KANNST dich nicht entlassen, du musst schon deine K�ndigung einreichen ;D");
  }
  else
  {
    db_unbuffered_query("UPDATE accounts SET isleader='0',memberid='0',gildenactive='0' WHERE acctid='$id'");
    output("`c`b`2User ".$drop_user['name']."`2 entlassen!`b`n`c;: ".$highestleader);
  }
}

function renameform($action)
{
  global $output,$session;
  $output.="<form action='$action' method='POST'><table>";
  rowform("Name der Gilde (Ohne Farbcodes)","<input type='text' size='30' value='{$session['guild']['gildenname_b']}' maxlength='100' name='gildenname_b'>");
  rowform("Name der Gilde (Mit Farbcode","<input type='text' size='30' value='{$session['guild']['gildenname']}' maxlength='100' name='gildenname'>");
  rowform("Prefix (Ohne Farbcodes)","<input type='text' size='5' value='{$session['guild']['gildenprefix_b']}' maxlength='5' name='gildenprefix_b'>");
  rowform("Prefix (Mit Farbcodes)","<input type='text' size='5' value='{$session['guild']['gildenprefix']}' maxlength='18' name='gildenprefix'>");
  rowform(false,"<input type='submit' class='button' value='Best�tigen'>");
  $output.="</table></form>";
  addnav("",$action);
}

function dropguild($id)
{
  global $session;
  addnews("`#Die Gilde `@{$session['guild']['gildenname']}`# wurde von `@{$session['user']['name']}`# aufgel�st.");
  db_query("DELETE FROM gilden WHERE gildenid='$id' LIMIT 1"); // Gilde l�schen
  db_query("DELETE FROM gildenranks WHERE gildenid='$id' LIMIT 1"); // R�nge l�schen
  db_query("DELETE FROM gilden_ausbau WHERE ownerguild='$id' LIMIT 1"); // Geb�ude l�schen
  db_query("DELETE FROM gilden_data WHERE gildenid='$id' LIMIT 1"); // Ausbau-Daten l�schen
  db_query("UPDATE accounts SET isleader='0',memberid='0',gildenactive='0',rankid='0' WHERE memberid='$id'"); // User entlassen
  $session['user']['memberid'] = 0;
  $session['user']['gildenactive'] = '0';
  $session['user']['isleader'] = 0;
  $session['user']['rankid'] = 0;
  saveuser();
  redirect("gildenstrasse.php");
}
?>
