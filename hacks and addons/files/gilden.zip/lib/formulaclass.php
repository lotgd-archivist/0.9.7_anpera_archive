<?php
/*
    Formularklasse, 2005 by Eliwood
*/
class input
{
  function start_form($formlink,$method="POST")
  {
    return ("<form action=\"$formlink\" method=\"$method\">");
  }
  
  function textarea($name="",$rows=5,$cols=30,$value="")
  {
    return ("<textarea name=\"$name\" rows=\"$rows\" cols=\"$cols\">$value</textarea>");
  }

  function button($value="",$type="submit")
  {
    return ("<input type=\"submit\" class=\"button\" value=\"$value\" />");
  }

  function input($name="",$value="",$size="30",$maxlength="100")
  {
    return ("<input type='text' name='$name' value='$value' size='$size' maxlength='$maxlength' />");
  }

  function select($name="",$value="",$size=1)
  {
    $numargs = func_num_args();
    // $arg_list = func_get_args();
    $return = "<select name=\"$name\" size=\"$size\"";
    $i = 4;
    while($i <= $numargs)
    {
      $arg = func_get_arg($i-1);
      // die(print_r($arg)."|".$i);
      $return.= "<option ".(isset($arg['value'])?"value=\"".$arg['value']."\"":"");
      if($value == $arg['value'] || $value == $arg['name']) $return.= "selected=\"selected\"";
      $return.=" />".$arg['name'];
      $i++;
    }
    $return.= "</select>";
    return $return;
  }
}

?>
