<?php
#-----------------------------------------#
#   Gildensystem Version: 1.5b            #
#   ~~ Funktionen f�r die Geb�ude ~~      #
#   Autor: Eliwood                        #
#   Mit Unterst�zung von: Nephilea        #
#-----------------------------------------#


$cost_values = array(1=>48,225,585,990,1575,2250,2790,3420,4230,5040,5850,6840,8010,9000,10350);

/* Invhandlerfuncs 2005 by Eliwood */
function give_new_weapon($name,$description,$attack=0,$gold=0)
  {
    // Gives Users a New Waepon
    global $session;
    if (!is_numeric($attack)) $defence = 0;
    if (!is_numeric($gold)) $gold = 0;
    $sql="INSERT INTO items (name,class,owner,value1,gold,description) VALUES ('$name','Waffe','".$session['user']['acctid']."','$attack','$gold','$description')";
    db_query($sql) or die("Ach, so nen Mist, schon wieder verbockt!");
  }

function give_new_armor($name,$description,$defence=0,$gold=0)
  {
    // Gives Users a New Armor
    global $session;
    if (!is_numeric($defence)) $defence = 0;
    if (!is_numeric($gold)) $gold = 0;
    $sql="INSERT INTO items (name,class,owner,value1,gold,description) VALUES ('$name','R�stung','".$session['user']['acctid']."','$defence','$gold','$description')";
    db_query($sql) or die("Ach, so nen Mist, schon wieder verbockt!");
  }
/* End Invhandlerfuncs */

/* Waffenshop */
function showweapons($withlink=true)
{
  global $session;
  $result = db_unbuffered_query("SELECT * FROM gilden_data WHERE gildenid='".$session['guild']['gildenid']."' AND name='weapon' AND value4>0 ORDER BY value1 ASC");
  addnav("Waffen");
  rawoutput("<table align='center' bgcolor='#999999'>");
  rawoutput("<tr class='trhead'><td>Name</td><td>Schaden</td><td>Goldkosten</td><td>St�ckzahl im Lager</td>");
  if($session['user']['acctid']==$session['guild']['leaderid']){

  rawoutput("<td>Bearbeiten</td></tr>");

  }
  $i = 0;
  while($row = db_fetch_assoc($result))
  {
    $tableclass = ($i%2==1?"trlight":"trdark");
    $mylink = "";
    if($row['value3']<=$session['user']['gold']) $mylink = "gilden.php?op=build&action=weapon&weaponid=".$row['value1'];
    if($withlink===true) addnav($row['data'],$mylink);
    rawoutput("<tr class='$tableclass'>"
             ."<td>".appoencode($row['data'])."</td>"
             ."<td>".$row['value2']."</td>"
             ."<td>".$row['value3']."</td>"
             ."<td>".$row['value4']."</td>");
             if($session['user']['acctid']==$session['guild']['leaderid'])
             {
              rawoutput("<td><a href='gildenverwalt.php?op=verwaltbuild&action=weapon&do=edit&weaponid=".$row['value1']."'>Bearbeiten</a></td>");
               addnav("","gildenverwalt.php?op=verwaltbuild&action=weapon&do=edit&weaponid=".$row['value1']."");
             }
             rawoutput("</tr>");
    $i++;
  }
  rawoutput("</table>");
  if($withlink===true) output("`\$`n`n--->Wenn du eine Waffen kaufen willst, klicke rechts oben auf den Navpunkt.");
}

function editweapon($id,$formlink)
{
  /* Function by Hadriel */
  global $session;
  $weapon = db_fetch_assoc(db_unbuffered_query("SELECT * FROM gilden_data WHERE gildenid='".$session['guild']['gildenid']."' AND name='weapon' AND value1='$id'"));
  allownav($formlink);
  rawoutput("<form method='POST' action='$formlink'><table>");
  rawoutput("<input type='hidden' name='id' value='$id'>");
  rawoutput("<tr><td>Name der Waffe</td>");
  rawoutput("<td><input type='text' name='name' value='$weapon[data]' /></td></tr>");
  rawoutput("<tr><td colspan='2' rowspan='2' align='center' valign='middle'><input class='button' type='submit' value='Waffe bearbeiten' /></td></tr><tr></tr>");
  rawoutput("</table></form>");
}

function update_weapon($id)
{
  /* Function by Hadriel */
  global $session;
  db_query("UPDATE gilden_data SET data='".$_POST['name']."' WHERE value1=".$id." AND gildenid=".$session['guild']['gildenid']." AND name='weapon'");
}

function buyweapon($id)
{
  global $session;
  $weapon = db_fetch_assoc(db_unbuffered_query("SELECT * FROM gilden_data WHERE gildenid='".$session['guild']['gildenid']."' AND name='weapon' AND value1='$id'"));
  give_new_weapon($weapon['data'],"Eine Waffe, von der Gilde gekauft",$weapon['value2'],$weapon['value3']);
  if(($weapon['value4']-1)==0) // Wenn keine St�ckzahlen mehr vorhanden sind, Waffe aus der Datenbank l�schen
    db_query("DELETE FROM gilden_data WHERE gildenid='".$session['guild']['gildenid']."' AND name='weapon' AND value1='$id'");
  else // Wenn es noch was von der Waffe hat => St�ckzahl verringern
    db_query("UPDATE gilden_data SET value4=value4-'1' WHERE gildenid='".$session['guild']['gildenid']."' AND name='weapon' AND value1='$id'");
  guild_update("gold",$session['guild']['gold']+$weapon['value3']);
  $session['user']['gold']-=$weapon['value3'];
}

function insertweapon($name,$attack,$piece)
{
  global $session,$cost_values;
  $result = db_unbuffered_query("SELECT MAX(value1) AS maxid FROM gilden_data WHERE gildenid='".$session['guild']['gildenid']."' AND name='weapon'");
  $a = db_fetch_assoc($result);
  $id = ($a['maxid']+1);
  db_unbuffered_query("INSERT INTO gilden_data (gildenid,name,value1,data,value2,value3,value4) VALUES ('".$session['guild']['gildenid']."','weapon','$id','$name','$attack','".$cost_values[$attack]."','$piece')");
}

function weaponform($formlink)
{
  global $session,$cost_values;
  allownav($formlink);
  rawoutput("<form method='POST' action='$formlink'><table>");
  rawoutput("<tr><td>Name der Waffe</td>");
  rawoutput("<td><input type='text' name='name' /></td></tr>");
  rawoutput("<tr><td>Schaden</td>");
  rawoutput("<td><select name='damage'>");
  for($i=1;$i<=15;$i++)
  {
    rawoutput("<option value='$i'>$i (Goldkosten: ".$cost_values[$i].")");
  }
  rawoutput("</select></td></tr>");
  rawoutput("<tr><td>Wieviel davon herstellen?</td>");
  rawoutput("<td><select name='piece'>");
  for($i=1;$i<=20;$i++)
  {
    rawoutput("<option value='$i'>$i");
  }
  rawoutput("</select></td></tr>");
  rawoutput("<tr><td colspan='2' rowspan='2' align='center' valign='middle'><input class='button' type='submit' value='Waffe schmieden' /></td></tr><tr></tr>");
  rawoutput("</table></form>");
}


/* R�stungsshop */
function showarmors($withlink=true)
{
  global $session;
  $result = db_unbuffered_query("SELECT * FROM gilden_data WHERE gildenid='".$session['guild']['gildenid']."' AND name='armor' AND value4>0 ORDER BY value1 ASC");
  addnav("R�stungen");
  rawoutput("<table align='center' bgcolor='#999999'>");
  rawoutput("<tr class='trhead'><td>Name</td><td>Defensivkraft</td><td>Goldkosten</td><td>St�ckzahl im Lager</td>");
  if($session['user']['acctid']==$session['guild']['leaderid']){

  rawoutput("<td>Bearbeiten</td></tr>");

  }
  $i = 0;
  while($row = db_fetch_assoc($result))
  {
    $tableclass = ($i%2==1?"trlight":"trdark");
    $mylink = "";
    if($row['value3']<=$session['user']['gold']) $mylink = "gilden.php?op=build&action=armor&armorid=".$row['value1'];
    if($withlink===true) addnav($row['data'],$mylink);
    rawoutput("<tr class='$tableclass'>"
             ."<td>".appoencode($row['data'])."</td>"
             ."<td>".$row['value2']."</td>"
             ."<td>".$row['value3']."</td>"
             ."<td>".$row['value4']."</td>");
             if($session['user']['acctid']==$session['guild']['leaderid'])
             {
              rawoutput("<td><a href='gildenverwalt.php?op=verwaltbuild&action=armor&do=edit&armorid=".$row['value1']."'>Bearbeiten</a></td>");
              addnav("","gildenverwalt.php?op=verwaltbuild&action=armor&do=edit&armorid=".$row['value1']."");
             }
             rawoutput("</tr>");
    $i++;
  }
  rawoutput("</table>");
  if($withlink===true) output("`\$`n`n--->Wenn du eine R�stung kaufen willst, klicke rechts oben auf den Navpunkt.");
}

function editarmor($id,$formlink)
{
  /* Function by Hadriel */
  global $session;
  $armor = db_fetch_assoc(db_unbuffered_query("SELECT * FROM gilden_data WHERE gildenid='".$session['guild']['gildenid']."' AND name='armor' AND value1='$id'"));
  allownav($formlink);
  rawoutput("<form method='POST' action='$formlink'><table>");
  rawoutput("<input type='hidden' name='id' value='$id'>");
  rawoutput("<tr><td>Name der R�stung</td>");
  rawoutput("<td><input type='text' name='name' value='$armor[data]' /></td></tr>");
  rawoutput("<tr><td colspan='2' rowspan='2' align='center' valign='middle'><input class='button' type='submit' value='Waffe bearbeiten' /></td></tr><tr></tr>");
  rawoutput("</table></form>");
}

function update_armor($id)
{
  /* Function by Hadriel */
  global $session;
  db_query("UPDATE gilden_data SET data='".$_POST['name']."' WHERE value1=".$id." AND gildenid=".$session['guild']['gildenid']." AND name='armor'");
}

function buyarmor($id)
{
  global $session;
  $armor = db_fetch_assoc(db_unbuffered_query("SELECT * FROM gilden_data WHERE gildenid='".$session['guild']['gildenid']."' AND name='armor' AND value1='$id'"));
  give_new_armor($armor['data'],"Eine R�stung, von der Gilde gekauft",$armor['value2'],$armor['value3']);
  if(($armor['value4']-1)==0) // Wenn keine St�ckzahlen mehr vorhanden sind, Waffe aus der Datenbank l�schen
    db_query("DELETE FROM gilden_data WHERE gildenid='".$session['guild']['gildenid']."' AND name='armor' AND value1='$id'");
  else // Wenn es noch was von der Waffe hat => St�ckzahl verringern
    db_query("UPDATE gilden_data SET value4=value4-'1' WHERE gildenid='".$session['guild']['gildenid']."' AND name='armor' AND value1='$id'");
  guild_update("gold",$session['guild']['gold']+$armor['value3']);
  $session['user']['gold']-=$armor['value3'];
}

function insertarmor($name,$attack,$piece)
{
  global $session,$cost_values;
  $result = db_unbuffered_query("SELECT MAX(value1) AS maxid FROM gilden_data WHERE gildenid='".$session['guild']['gildenid']."' AND name='armor'");
  $a = db_fetch_assoc($result);
  $id = ($a['maxid']+1);
  db_unbuffered_query("INSERT INTO gilden_data (gildenid,name,value1,data,value2,value3,value4) VALUES ('".$session['guild']['gildenid']."','armor','$id','$name','$attack','".$cost_values[$attack]."','$piece')");
}

function armorform($formlink)
{
  global $session,$cost_values;
  allownav($formlink);
  rawoutput("<form method='POST' action='$formlink'><table>");
  rawoutput("<tr><td>Name der R�stung</td>");
  rawoutput("<td><input type='text' name='name' /></td></tr>");
  rawoutput("<tr><td>Defensive</td>");
  rawoutput("<td><select name='damage'>");
  for($i=1;$i<=15;$i++)
  {
    rawoutput("<option value='$i'>$i (Goldkosten: ".$cost_values[$i].")");
  }
  rawoutput("</select></td></tr>");
  rawoutput("<tr><td>Wieviel davon herstellen?</td>");
  rawoutput("<td><select name='piece'>");
  for($i=1;$i<=20;$i++)
  {
    rawoutput("<option value='$i'>$i");
  }
  rawoutput("</select></td></tr>");
  rawoutput("<tr><td colspan='2' rowspan='2' align='center' valign='middle'><input class='button' type='submit' value='R�stung schmieden' /></td></tr><tr></tr>");
  rawoutput("</table></form>");
}

/* Diplomatie */
function diplomatie_show_guilds()
{
  global $session;
  $sql = "SELECT gildenid,gildenname,gildenname_b,gildenprefix,gildenprefix_b,leaderid FROM gilden "
        ."WHERE gildenid!='".$session['guild']['gildenid']."'";
  $result = db_query($sql);
  if(db_num_rows($result)==0)
    output("`c`b`\$ Keine andere Gilden vorhanden!`b`c");
  else
  {
    rawoutput("<table align='center' cellspacing=1 cellpadding=1 bgcolor='#999999'><tr class='trhead'>"
              ."<td>Gildenname</td>"
              ."<td>Prefix</td>"
              ."<td>Leader</td>"
              ."<td>Beziehung</td>"
              ."</tr>");
    $i = 0;
    while($row = db_fetch_assoc($result))
    {
      $leaderr = db_unbuffered_query("SELECT acctid,name FROM accounts WHERE acctid='".$row['leaderid']."' LIMIT 1");
      $leaderr = db_fetch_assoc($leaderr);
      $bez = load_diplomatie_array();
      $dipr = db_query("SELECT * FROM gilden_data "
                      ."WHERE name='diplomatie' "
                      ."AND gildenid='".$session['guild']['gildenid']."'"
                      ."AND value2='".$row['gildenid']."' LIMIT 1");
      if(db_num_rows($dipr)) $dipr = db_fetch_assoc($dipr); else $dipr = false;
      if(!db_num_rows(db_query("SELECT name FROM gilden_ausbau WHERE ownerguild='{$row['gildenid']}' AND name='Diplomat' LIMIT 1"))) $diprow['value3'] = -1;
      if($dipr === false) $diprow['value3'] = 0;
      $class = $i%2?"trlight":"trdark";
      output("<tr class='$class'><td>"
            .$row['gildenname']
            ."</td><td>"
            .$row['gildenprefix']
            ."</td><td>"
            .$leaderr['name']
            ."</td><td>"
            .$bez[$diprow['value3']]
            ."</td></tr>",true);
      $i++;
    }
    rawoutput("</table>");
  }
}

function load_diplomatie_array()
{
  $array = array(
    -1=>"Nicht m�glich",
    0=>"Neutral",
    1=>"Frieden",
    2=>"B�ndnis",
    3=>"Verfeindet",
    3=>"Kriegszustand",
  );
  return $array;
}

/*
    Eine Liste mit den Wichtigen Informationen �ber die Tabelle gilden_data:
    
    Waffen:
    name => weapon
    value1 => Waffenprim�rschl�ssel
    data => Waffenname
    value2 => Angriffspunkte
    value3 => Waffenwert in Gold
    value4 => St�ckzahl
    // Die Waffen werden ins Inventar �bertragen!
    
    R�stungen:
    name => armor
    value1 => R�stungsprim�rschl�ssel
    data => R�stungsname
    value2 => Defensivpunkte
    value3 => R�stungswert in Gold
    value4 => St�ckzahl
    // Die R�stungen werden ins Inventar �bertragen!
    
    Diplomatie:
    name => diplomatie
    value1 => Vertragsid
    value2 => Antragspartner
    value3 => Art des Verh�ltnisses:
              0 => Neutral
              1 => Frieden
              2 => B�ndnis
              3 => Verfeindet
              4 => Kriegszustand
    value4 => Unterzeichnet (Partner) [Falls Kriegserkl�rung oder bei Verfeindung wird das Einverst�ndnis nicht gebraucht!]
    data => Optionaler Text
    // Um diplomatische Beziehungen aufzubauen, wird das Diplomatenzentrum ben�tigt (Geb�ude)

*/
?>
