/*
*
* Copyright (c) 2009 Basilius Sauter
* Version: 1.0 2009-06-04
* 
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use, copy,
* modify, merge, publish, distribute, sublicense, and/or sell copies
* of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
* 
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
* 
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
* BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
* ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
* CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
* * 
*/

var keyevents = {}
var usedkeys = {}

function doActionOnPressedKey(keyEvent) {
	// Based on Standard-LoGD-Function keyevent, hardly modified
	// 2009 by Basilius,
	var pressedKey;
	var altKey;
	var ctrlKey;
	var target;
	var focussedElementName;
	
	// pressedKey = String.fromCharCode(keyEvent.charCode).toUpperCase();
	pressedKey = keyEvent ? (keyEvent.charCode ? keyEvent.charCode : keyEvent.which) : window.event.keyCode;
	pressedKey = String.fromCharCode(pressedKey).toUpperCase();
	altKey = keyEvent.altKey ? keyEvent.altKey : false;
	ctrlKey = keyEvent.ctrlKey ? keyEvent.ctrlKey : false;
	
	if(document.activeElement) {
		focussedElementName = document.activeElement.nodeName.toUpperCase();
	}
	else {
		focussedElementName = window.event.srcElement.nodeName.toUpperCase();
	}
	
	// Wenn das Knöpfedrücken im Input- oder in einer Textarea geschieht...
	// ODER es eine Tastenkombination mit Alt ist...
	// ODER es eine Tastenkombination mit Ctrl ist...
	// ... DANN tue... nichts.
	if (focussedElementName == 'INPUT' || focussedElementName == 'TEXTAREA' || altKey || ctrlKey) {}
	else {
		// Wenn, und nur wenn der Keyevent registriert ist, führe den registrierten Code aus.
		if (keyevents[pressedKey] != null) {
			eval(keyevents[pressedKey]);
		}
	}
}

function registerKeyEvent(key, action) {
	keyevents[key] = action;
}

function setAccessKeys() {
	$$("a.accesskey").each(function(s){
		setAccessKey(s)
	});
}

function setAccessKey(e) {
	var value = ''
	var ignoreuntil = ''
	var found = ''
	var foundPosition = 0
	
	value = e.innerHTML
	valueLength = value.length
	
	// Analysiere jedes Zeichen...
	for(var i = 0; i < valueLength; i += 1) {
		chara = value.substr(i, 1)
		
		if (found == '') {
			if (ignoreuntil == '') {
				if (chara == '<') {
					ignoreuntil = '>'
				}
				else if (chara == '&') {
					ignoreuntil = ';'
				}
				else if (usedkeys[chara]) {
					// Do nothing
				}
				else {
					found = chara
					foundPosition = i
					// Register character
					usedkeys[found] = true
				}
			}
			else if(ignoreuntil == chara) {
				ignoreuntil = ''
			}
		}		
	}
	
	// Insert Highlight
	text = value.substr(0, foundPosition) + '<span class="highlight">'+found+'</span>' + value.substr(foundPosition+1)
	e.innerHTML = text
	
	if (e.href.substr(0, 7) == 'http://') {
		evalString = "window.location='" + e.href + "';"
	}
	else {
		evalString = e.href
	}
	
	registerKeyEvent(found.toUpperCase(), evalString)
}

if (typeof document.activeElement == "undefined" && document.addEventListener) {
	document.addEventListener("focus", function (e) {
		document.activeElement = e.target;
	}, true);
}

document.onkeypress = doActionOnPressedKey;
document.observe("dom:loaded", setAccessKeys);