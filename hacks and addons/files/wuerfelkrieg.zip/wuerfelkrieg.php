<?php
/*
                                �@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@�
                                �                                                      �
                                �  Idee und Umsetzung                                  �
                                �  Morpheus aka Apollon                                �
                                �  2007 f�r Morpheus.Lotgd(LoGD 0.9.7 +jt ext (GER) 3) �
                                �  Mail to Morpheus@magic.ms or Apollon@magic.ms       �
                                �  gewidmet meiner �ber alles geliebten Blume          �
                                �                                                      �
                                @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
*/
require_once "common.php";
$name=$session['user']['name'];
checkday();
page_header("W�rfelkrieg");
if ($_GET[op]==""){
	output("`3Du gehst zum Tisch, an dem \'W�felkrieg\' gespielt wird und siehst Dich erst einmal um.");
	output("`3Hinter dem Tisch sitzt ein `4Dunkelelfe`3, der Dich mit seinen `~du`4nk`~le`4n A`~ug`4en `3ansieht, vor ihm liegt ein Kasten, in dem wohl die `&6 W�rfel`3 liegen und an der Wand h�ngt ein Schild, auf dem Du folgendes lesen kannst:`n`n");
	output("`%Eins�tze:`n");
	output("`^10`%, `^50 `%oder `^100 Gold`0`n");
	output("`%Runden zum Sieg: `^3`0`n`n");
	output("`%W�hrend Du noch liest, spricht Dich der `4Dunkelelfe `3an:`n`n");
	output("`3\"`7Willkommen, `6$name`7, nimm nur Platz und versuche Dein Gl�ck im W�rfelkrieg.");
	output("`7Wenn Du gewinnst, werde ich Deinen Einsatz verdoppeln, wenn Du verlierst, gewinnt das Haus.`n`n");
	output("`3Du blickst ihn an und �berlegst, was Du machen willst.");
	addnav("R?Die Regeln anh�ren","wuerfelkrieg.php?op=regel");
	if ($session['user']['gold']>=10){
		addnav("1?Spiele um 10 Gold","wuerfelkrieg.php?op=spiel");
	}
	if ($session['user']['gold']>=50){
		addnav("5?Spiele um 50 Gold","wuerfelkrieg.php?op=spiel1");
	}
	if ($session['user']['gold']>=100){
		addnav("0?Spiele um 100 Gold","wuerfelkrieg.php?op=spiel2");
	}
	addnav("Z?Zur�ck","casino.php");
}
if ($_GET[op]=="regel"){
	output("`3Der `4Dunkelelfe `3l�chelt und erkl�rt:`n`n");
	output("`3\"`7Die Regeln sind sehr simpel, jeder von uns beiden nimmt `&3 W�rfel `7zur Hand und wirft.");
	output("`7Das Ergenbnis dieser W�rfe wird dann abgeglichen, und zwar werden `%die h�schten Zahlen `7immer gegeneinander abgewogen.`n");
	output("`7Hast `^Du mehr`7 hohe Zahlen als ich, hast `6Du `7gewonnen, habe `^ich mehr`7 hohe Zahlen als Du, habe `6ich`7 gewonnen.");
	output("`7Es kann auch zu einem unentschieden kommen, dann wird die Runde wiederholt und wir spielen, bis einer von uns beiden 3 Runden gewonnen hat.`n");
	output("`7Du siehst, es ist nichts kompliziertes daran...`3\"");
	if ($session['user']['gold']>=10){
		addnav("1?Spiele um 10 Gold","wuerfelkrieg.php?op=spiel");
	}
	if ($session['user']['gold']>=50){
		addnav("5?Spiele um 50 Gold","wuerfelkrieg.php?op=spiel1");
	}
	if ($session['user']['gold']>=100){
		addnav("0?Spiele um 100 Gold","wuerfelkrieg.php?op=spiel2");
	}
	addnav("Z?Zur�ck","casino.php");
}
if ($_GET[op]=="spiel"){
	output("`3Der `4Dunkelelfe`3 greift zum K�stchen, in dem die `&6 W�rfel `3liegen, nimmt sich 3 und reicht Dir die anderen 3:`n`n");
	output("`3\"Nun den,`6 $name`3, Du hast den ersten Wurf!`3\"`n`n");
	$rs=0;
	$rm=0;
	$es=10;
	addnav("W?Weiter","wuerfelkrieg.php?op=wurf&rs=$rs&rm=$rm&es=$es");
}
if ($_GET[op]=="spiel1"){
	output("`3Der `4Dunkelelfe`3 greift zum K�stchen, in dem die `&6 W�rfel `3liegen, nimmt sich 3 und reicht Dir die anderen 3:`n`n");
	output("`3\"Nun den,`6 $name`3, Du hast den ersten Wurf!`3\"`n`n");
	$rs=0;
	$rm=0;
	$es=50;
	addnav("W?Weiter","wuerfelkrieg.php?op=wurf&rs=$rs&rm=$rm&es=$es");
}
if ($_GET[op]=="spiel2"){
	output("`3Der `4Dunkelelfe`3 greift zum K�stchen, in dem die `&6 W�rfel `3liegen, nimmt sich 3 und reicht Dir die anderen 3:`n`n");
	output("`3\"Nun den,`6 $name`3, Du hast den ersten Wurf!`3\"`n`n");
	$rs=0;
	$rm=0;
	$es=100;
	addnav("W?Weiter","wuerfelkrieg.php?op=wurf&rs=$rs&rm=$rm&es=$es");
}
if ($_GET[op]=="wurf"){
	$rs = (int) $_GET[rs];
	$rm = (int) $_GET[rm];
	$es = (int) $_GET[es];
	output("`3Du nimmst Deine `&W�rfel`3, sch�ttelst sie in der Hand und wirfst:`n`n");
	$ws1=e_rand(1,6);
	$ws2=e_rand(1,6);
	$ws3=e_rand(1,6);
	if (($ws2<$ws1)&&($ws3<$ws2)){
		output("`b`c`^$ws1 - $ws2 - $ws3`c`b");
		$gs1=$ws1;
		$gs2=$ws2;
		$gs3=$ws3;
	}elseif (($ws2<$ws1)&&($ws2<$ws3)&&($ws3<$ws1)){
		output("`b`c`^$ws1 - $ws3 - $ws2`c`b");
		$gs1=$ws1;
		$gs2=$ws3;
		$gs3=$ws2;
	}elseif (($ws2<$ws1)&&($ws2<$ws3)&&($ws1<$ws3)){
		output("`b`c`^$ws3 - $ws1 - $ws2`c`b");
		$gs1=$ws3;
		$gs2=$ws1;
		$gs3=$ws3;
	}elseif (($ws1<$ws2)&&($ws3<$ws2)&&($ws1<$ws3)){
		output("`b`c`^$ws2 - $ws3 - $ws1`c`b");
		$gs1=$ws2;
		$gs2=$ws3;
		$gs3=$ws1;
	}elseif (($ws1<$ws2)&&($ws3<$ws2)&&($ws3<$ws1)){
		output("`b`c`^$ws2 - $ws1 - $ws3`c`b");
		$gs1=$ws2;
		$gs2=$ws1;
		$gs3=$ws3;
	}elseif (($ws1<$ws2)&&($ws2<$ws3)&&($ws1<$ws3)){
		output("`b`c`^$ws3 - $ws2 - $ws1`c`b");
		$gs1=$ws3;
		$gs2=$ws2;
		$gs3=$ws1;
	}elseif (($ws1==$ws2)&&($ws3<$ws1)){
		output("`b`c`^$ws1 - $ws2 - $ws3`c`b");
		$gs1=$ws1;
		$gs2=$ws2;
		$gs3=$ws3;
	}elseif (($ws1==$ws2)&&($ws1<$ws3)){
		output("`b`c`^$ws3 - $ws1 - $ws2`c`b");
		$gs1=$ws3;
		$gs2=$ws1;
		$gs3=$ws2;
	}elseif (($ws1==$ws3)&&($ws2<$ws1)){
		output("`b`c`^$ws1 - $ws3 - $ws2`c`b");
		$gs1=$ws1;
		$gs2=$ws3;
		$gs3=$ws2;
	}elseif (($ws1==$ws3)&&($ws1<$ws2)){
		output("`b`c`^$ws2 - $ws1 - $ws3`c`b");
		$gs1=$ws2;
		$gs2=$ws1;
		$gs3=$ws3;
	}elseif (($ws2==$ws3)&&($ws1<$ws2)){
		output("`b`c`^$ws2 - $ws3 - $ws1`c`b");
		$gs1=$ws2;
		$gs2=$ws3;
		$gs3=$ws1;
	}else{
		output("`b`c`^$ws1 - $ws2 - $ws3`c`b");
		$gs1=$ws1;
		$gs2=$ws2;
		$gs3=$ws3;
	}
	output("`3Der `4Dunkelelfe`3 nickt:`n`n`3\"`7Gut geworfen,`6 $name`7, nun bin ich dran!`3\"`n`n");
	addnav("W?Weiter","wuerfelkrieg.php?op=wurf1&gs1=$gs1&gs2=$gs2&gs3=$gs3&rs=$rs&rm=$rm&es=$es");
}
if ($_GET[op]=="wurf1"){
	$rs = (int) $_GET[rs];
	$rm = (int) $_GET[rm];
	$gs1 = (int) $_GET[gs1];
	$gs2 = (int) $_GET[gs2];
	$gs3 = (int) $_GET[gs3];
	$es = (int) $_GET[es];
	output("`^Dein Wurf:`n`n");
	output("`c`b`^$gs1 - $gs2 - $gs3`c`b`n`n");
	output("`n`n`3Der `4Dunkelelfe `3nimmt die `&W�rfel`3 und wirft:`n`n");
	$wm1=e_rand(1,6);
	$wm2=e_rand(1,6);
	$wm3=e_rand(1,6);
	if (($wm2<$wm1)&&($wm3<$wm2)){
		output("`b`c`^$wm1 - $wm2 - $wm3`c`b");
		$gm1=$wm1;
		$gm2=$wm2;
		$gm3=$wm3;
	}elseif (($wm2<$wm1)&&($wm2<$wm3)&&($wm3<$wm1)){
		output("`b`c`^$wm1 - $wm3 - $wm2`c`b");
		$gm1=$wm1;
		$gm2=$wm3;
		$gm3=$wm2;
	}elseif (($wm2<$wm1)&&($wm2<$wm3)&&($wm1<$wm3)){
		output("`b`c`^$wm3 - $wm1 - $wm2`c`b");
		$gm1=$wm3;
		$gm2=$wm1;
		$gm3=$wm3;
	}elseif (($wm1<$wm2)&&($wm3<$wm2)&&($wm1<$wm3)){
		output("`b`c`^$wm2 - $wm3 - $wm1`c`b");
		$gm1=$wm2;
		$gm2=$wm3;
		$gm3=$wm1;
	}elseif (($wm1<$wm2)&&($wm3<$wm2)&&($wm3<$wm1)){
		output("`b`c`^$wm2 - $wm1 - $wm3`c`b");
		$gm1=$wm2;
		$gm2=$wm1;
		$gm3=$wm3;
	}elseif (($wm1<$wm2)&&($wm2<$wm3)&&($wm1<$wm3)){
		output("`b`c`^$wm3 - $wm2 - $wm1`c`b");
		$gm1=$wm3;
		$gm2=$wm2;
		$gm3=$wm1;
	}elseif (($wm1==$wm2)&&($wm3<$wm1)){
		output("`b`c`^$wm1 - $wm2 - $wm3`c`b");
		$gm1=$wm1;
		$gm2=$wm2;
		$gm3=$wm3;
	}elseif (($wm1==$wm2)&&($wm1<$wm3)){
		output("`b`c`^$wm3 - $wm1 - $wm2`c`b");
		$gm1=$wm3;
		$gm2=$wm1;
		$gm3=$wm2;
	}elseif (($wm1==$wm3)&&($wm2<$wm1)){
		output("`b`c`^$wm1 - $wm3 - $wm2`c`b");
		$gm1=$wm1;
		$gm2=$wm3;
		$gm3=$wm2;
	}elseif (($wm1==$wm3)&&($wm1<$wm2)){
		output("`b`c`^$wm2 - $wm1 - $wm3`c`b");
		$gm1=$wm2;
		$gm2=$wm1;
		$gm3=$wm3;
	}elseif (($wm2==$wm3)&&($wm1<$wm2)){
		output("`b`c`^$wm2 - $wm3 - $wm1`c`b");
		$gm1=$wm2;
		$gm2=$wm3;
		$gm3=$wm1;
	}else{
		output("`b`c`^$wm1 - $wm2 - $wm3`c`b");
		$gm1=$wm1;
		$gm2=$wm2;
		$gm3=$wm3;
	}
	output("`3Der `4Dunkelelfe`3 l�chelt:`n`n`3\"`7Und jetzt,`6 $name`7, ist es Zeit zu vergleichen!`3\"`n`n");
	addnav("W?Weiter","wuerfelkrieg.php?op=vergleich&gs1=$gs1&gs2=$gs2&gs3=$gs3&gm1=$gm1&gm2=$gm2&gm3=$gm3&rs=$rs&rm=$rm&es=$es");
}
if ($_GET[op]=="vergleich"){
	$rs = (int) $_GET[rs];
	$rm = (int) $_GET[rm];
	$gs1 = (int) $_GET[gs1];
	$gs2 = (int) $_GET[gs2];
	$gs3 = (int) $_GET[gs3];
	$gm1 = (int) $_GET[gm1];
	$gm2 = (int) $_GET[gm2];
	$gm3 = (int) $_GET[gm3];
	$es = (int) $_GET[es];
	output("`^Dein Wurf:`n`n");
	output("`c`b`^$gs1 - $gs2 - $gs3`c`b`n`n");
	output("`6Des `4Dunkelelfen `6Wurf:`n`n");
	output("`c`b`6$gm1 - $gm2 - $gm3`c`b`n`n");
	if ($gm1<$gs1){
		output("`^Deine erste Zahl `3ist gr��er als die des `4Dunkelelfen`3!`n");
		$ps=1;
		$pm=0;
	}elseif ($gs1<$gm1){
		output("`4Die erste Zahl `3des `4Dunkelelfen `3ist gr��er als Deine!`n");
		$ps=0;
		$pm=1;
	}else{
		output("`3Die erste Zahl des `4Dunkelelfen`3 und Deine sind `6gleich gro�`3!`n");
		$ps=0;
		$pm=0;
	}
	if ($gm2<$gs2){
		output("`^Deine zweite Zahl `3ist gr��er als die des `4Dunkelelfen`3!`n");
		$ps1=$ps+1;
		$pm1=$pm+0;
	}elseif ($gs2<$gm2){
		output("`4Die zweite Zahl `3des `4Dunkelelfen `3ist gr��er als Deine!`n");
		$ps1=$ps+0;
		$pm1=$pm+1;
	}else{
		output("`3Die zweite Zahl des `4Dunkelelfen`3 und Deine sind `6gleich gro�`3!`n");
		$ps1=$ps+0;
		$pm1=$pm+0;
	}
	if ($gm3<$gs3){
		output("`^Deine dritte Zahl `3ist gr��er als die des `4Dunkelelfen`3!`n`n");
		$ps2=$ps1+1;
		$pm2=$pm1+0;
	}elseif ($gs3<$gm3){
		output("`4Die dritte Zahl `3des `4Dunkelelfen `3ist gr��er als Deine!`n`n");
		$ps2=$ps1+0;
		$pm2=$pm1+1;
	}else{
		output("`3Die dritte Zahl des `4Dunkelelfen`3 und Deine sind `6gleich gro�`3!`n`n");
		$ps2=$ps1+0;
		$pm2=$pm1+0;
	}
	if ($pm2<$ps2){
		output("`^Diese Runde geht an Dich!`n`n");
		$rs=($rs+1);
	}elseif ($ps2<$pm2){
		output("`4Diese Runde geht an den Dunkelelfen!`n`n");
		$rm=($rm+1);
	}else{
		output("`6Diese Runde endet unentschieden!`n`n");
	}
	if ($rs==3){
		output("`3Der `4Dunkelelfe `3nickt anerkennend:`n`n");
		output("`3\"`7Gut gemacht, `6$name`7, Du hast mich besiegt,nun sollst Du Deine Belohnung erhalten!`3\"`n`n");
		output("`3Mit diesen Worten greift er hinter sich, holt ein 2 `TK�stchen`3 hervor, aus dem er `^$es Gold `3entnimmt, die er Dir aush�ndigt.");
		output("`3Erfreut nimmst Du das `^Gold`3 und steckst es ein.`n");
		$session['user']['gold']+=$es;
		if ($session['user']['gold']>=10){
			addnav("1?Spiele um 10 Gold","wuerfelkrieg.php?op=spiel");
		}
		if ($session['user']['gold']>=50){
			addnav("5?Spiele um 50 Gold","wuerfelkrieg.php?op=spiel1");
		}
		if ($session['user']['gold']>=100){
			addnav("0?Spiele um 100 Gold","wuerfelkrieg.php?op=spiel2");
		}
		addnav("Z?Zur�ck","casino.php");
	}elseif ($rm==3){
		output("`3Der `4Dunkelelfe `3l�chelt sarkastisch:`n`n");
		output("`3\"`7Tja, `6$name`7, das war es dann f�r Dich, Du schuldest mir `^$es Gold`7!`3\"`n`n");
		output("`3Mit diesen Worten greift er sich Deinen Einsatz und packt ihn in ein 2 `TK�stchen`3, da� er hinter sich hervor holt.`n");
		$session['user']['gold']-=$es;
		if ($session['user']['gold']>=10){
			addnav("1?Spiele um 10 Gold","wuerfelkrieg.php?op=spiel");
		}
		if ($session['user']['gold']>=50){
			addnav("5?Spiele um 50 Gold","wuerfelkrieg.php?op=spiel1");
		}
		if ($session['user']['gold']>=100){
			addnav("0?Spiele um 100 Gold","wuerfelkrieg.php?op=spiel2");
		}
		addnav("Z?Zur�ck","casino.php");
	}else{
		output("`3Der `4Dunkelelfe `3nickt anerkennend:`n`n");
		output("`3\"`7Okay, `6$name`7, weiter geht es!`3\"");
		addnav("W?Weiter","wuerfelkrieg.php?op=wurf&rs=$rs&rm=$rm&es=$es");
	}
}
page_footer();
?>