<?php 

//Idee by theKlaus 

if (!isset($session)) exit(); 

output("<img src='images/orkploerre.jpg' width='250' height='173' alt='Orkpl�rre' align='right'>",true); 

output("`^Du entdeckst eine Lederflasche mit Orkpl�rre, die �ber einem Baumstumpf h�ngt.  Es ist auf ihr vermerkt, dass sie aus der Haut eines K�mpfer gefertigt ist, den du als sehr starken Krieger kanntest. Du beschlie�t, dass es nicht schaden kann, einen Schluck daraus zu nehmen.`n`n`nMann, ist das ein geiles Zeugs!  Du f�hlst dich `!super`^.`n`n`%Du erh�ltst einen extra Waldkampf!`^ `0"); 

$session[user][thirsty]+=2;
$session[user][turns]++; 
?>