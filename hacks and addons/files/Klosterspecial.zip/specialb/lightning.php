<?php
// idea of gargamel @ www.rabenthal.de
if (!isset($session)) exit();

if($_GET['op'] == '' || $_GET['op']== 'search'){ 
    $session[user][hitpoints] = round($session[user][hitpoints]*0.75);
    output("`6Ein Liedchen tr�llernd gehst Du durch die Berge, immer wachsam auf
    der Suche nach Monstern. Du bist gerade in einem absolut dunklen Teil des Bergwaldes, wo
    besonders hohe und dichte B�ume stehen. Als Du wieder zu einer Lichtung kommst, f�llt Dir auf, dass es immer
    noch dunkel ist.`n`nDu schaust zum Himmel und siehst die Bescherung.`n`7Es sind
    schwarze Gewitterwolken aufgezogen.`^ \"F�ngt bestimmt gleich an zu regnen\" `6denkst
    Du, als Du aus der Ferne auch schon das tiefe Grollen des Donners h�rst.`n`nDu stehst immer noch auf der kleinen
    Lichtung, als ganz pl�tzlich ein enormer `^Blitz `6einschl�gt.`n`nDer gewaltige Schlag
    wirft Dich um und Du `\$verlierst einige Lebenspunkte`6.`n`n`^Aber war das ein normaler Blitzschlag?`6`n`n
    Du vermutest, dass eine h�here Macht dahinter steckt, denn genauso pl�tzlich wie
    der Blitz eingeschlagen ist, sind die dunklen Wolken wieder verschwunden.`n`n`0");

    switch(e_rand(1,4)){
        case 1:
        output("`8Du bekommst 6 Level zu den Dunklen K�nsten gutgeschrieben.`0");
        $session[user][darkarts]+=6;
        $session[user][darkartuses]+=2;
        break;
         
        case 2:
        output("`8Du beherrscht die Mystik nun 6 Level besser.`0");
        $session[user][magic]+=6;
        $session[user][magicuses]+=2;
        break;
         
        case 3:
        output("`8Deine Diebesf�higkeiten verbessern sich um 6 Level.`0");
        $session[user][thievery]+=6;
        $session[user][thieveryuses]+=2;
        break;
         
        case 4:
        output("`8Gr�belnd setzt Du Deinen Weg fort.`0");
        break;
    }
    $session[user][specialinc] = "";
}
?>