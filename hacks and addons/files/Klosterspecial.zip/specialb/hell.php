<?php
/*
Todesh�hle 0.00000000000000000000000000001 *lol*
by Hadriel
abgekuckt(oder auch ver�ndert) in stonehenge.php
Leichte Balance und Textverbesserungen by Blanidur
*/
if ($_GET[op]=="" || $_GET[op]=="search"){
  output("`#Du wanderst auf der Suche, nach etwas zum Bek�mpfen, ziellos durch die Berge. Pl�tzlich stehst du mitten vor einem gro�en Felsen mit einem Eingang.");
    output("Um diesen Eingang liegen �berall schrecklich zugerichtete Leichen. Ist dies die legend�re");
    output("Todesh�hle? Du hast die Leute in Nollopa �ber diesen mystischen Ort reden h�ren, aber");
    output(" du hast nicht einmal im Traum daran geglaubt, dass sie wirklich existiert. Es heisst, die H�hle habe gro�e magische ");
    output("Kr�fte und dass diese Kr�fte unberechenbar seien. Was wirst du tun?");
    output("`n`n<a href='berge.php?op=hell'>Betrete die H�hle</a>`n<a href='berge.php?op=leavehell'>Lasse sie in Ruhe</a>",true);
    addnav("B?Betrete die H�hle","berge.php?op=hell");
    addnav("Lasse sie in Ruhe","berge.php?op=leavehell");
    addnav("","berge.php?op=hell");
    addnav("","berge.php?op=leavehell");
    $session[user][specialinc]="hell.php";
}else{
  $session[user][specialinc]="";
    if ($_GET[op]=="hell"){
      $rand = e_rand(1,22);
        output("`#Obwohl du wei�t, da� die Kr�fte der H�hle unvorhersagbar wirken, nimmst du diese Chance wahr. Du ");
        output("l�ufst in das Innere der legend�ren H�hle und bist bereit, die fantastischen Kr�fte dieses Ortes zu erfahren. ");
        output("Als du die Mitte erreichst, gleicht die Decke einem Himmel bei schwarzer, sternenklarer Nacht. Du bemerkst, dass der Boden unter ");
        output("deinen F��en in einem schwachen Licht, lila zu gl�hen scheint, fast so, als ob sich der Boden selbst in Nebel ");
        output("verwandeln will. Du f�hlst ein Kitzeln, das sich durch deinen gesamten K�rper ausbreitet. Pl�tzlich umgibt ein ");
        output("helles, intensives Licht die H�hle und dich. Als das Licht verschwindet, ");
        switch ($rand){
          case 1:
          case 2:
                output("bist du nicht mehr l�nger in der H�hle.`n`n�berall um dich herum sind die Seelen derer, die ");
                output("in alten Schlachten und bei bedauerlichen Unf�llen umgekommen sind. ");
                output("Jede tr�gt Anzeichen der Niedertracht, durch welche sie ihr Ende gefunden haben. Du bemerkst mit steigender Verzweiflung, da� ");
                output("die H�hle dich direkt ins Land der Toten transportiert hat!");
                output("`n`n`^Du wurdest aufgrund deiner d�mmlichen Entscheidung in die Unterwelt geschickt.`n");
                output("Da du physisch dorthin transportiert worden bist, hast du noch dein ganzes Gold.`n");
                output("Du verlierst aber 5% deiner Erfahrung.`n");
                output("Du kannst morgen wieder spielen.");
                $session[user][alive]=false;
                $session[user][hitpoints]=0;
                $session[user][experience]*=0.95;
                addnav("T�gliche News","news.php");
                addnews($session[user][name]." liegt in den Bergen und k�nnte nun mit Hackfleich verwechselt werden.");
                break;
            case 3:
                     output(" liegt dort nur noch der K�rper eines Kriegers, der die Kr�fte der H�hle herausgefordert hat.");
                output("`n`n`^Dein Geist wurde aus deinem K�rper gerissen!`n");
                output("Da dein K�rper in der H�hle liegt, verlierst du all dein Gold.`n");
                output("Du verlierst 10% deiner Erfahrung.`n");
                output("Du kannst morgen wieder spielen.");
                $session[user][alive]=false;
                $session[user][hitpoints]=0;
                $session[user][experience]*=0.9;
                $session['user']['donation']+=1;
                $session[user][gold] = 0;
                addnav("T�gliche News","news.php");
                addnews($session[user][name]." wurde gepf�hlt im Gebirge gefunden!");
                break;
            case 4:
            case 5:
            case 6:
                output("f�hlst du eine zerrende Energie durch deinen K�rper zucken, als ob deine Muskeln verbrennen w�rden. Als der schreckliche Schmerz nachl�sst, bemerkst du, dass deine Muskeln VIEL gr�sser geworden sind.");
                  $reward = round($session[user][experience] * 0.3);
                output("`n`n`^Du bekommst `7$reward`^ Erfahrungspunkte!");
                $session[user][experience] += $reward;
                break;
            case 7:
            case 8:
            case 9:
            case 10:
                $reward = e_rand(1, 3);         // original value: 1,4
                 if ($reward == 3) $rewardn = "DREI`^ Edelsteine";
                else if ($reward == 2) $rewardn = "ZWEI`^ Edelsteine";
                else if ($reward == 1) $rewardn = "EINEN`^ Edelstein";
                output("...`n`n`^bemerkst du `%$rewardn vor deinen F��en!`n`n");
                $session[user][gems]+=$reward;
                //debuglog("found gems from Stonehenge");  // said 3 gems ... can be less!!
                break;
            
            case 11:
            case 12:
            case 13:            
                output("hast du viel mehr Vertrauen in deine eigenen F�higkeiten.`n`n");
//                output("`^You gain four charm!");    // whoooohaa ... slow down a bit ;)
    output("`^Dein Charme steigt!");
                $session[user][charm] += 2;
                break;
            case 14:
            case 15:
            case 16:
            case 17:
            case 18:
                output("f�hlst du dich pl�tzlich extrem gesund.");
                output("`n`n`^Deine Lebenspunkte wurden vollst�ndig aufgef�llt.");
                if ($session[user][hitpoints]<$session[user][maxhitpoints]) $session[user][hitpoints]=$session[user][maxhitpoints];
                break;
            case 19:
            case 20:
              output("f�hlst du deine Ausdauer in die H�he schiessen!");
             //     $reward = $session[user][maxhitpoints] * 0.5;
                  $reward = 1;
                output("`n`n`^Deine Lebenspunkte wurden `bpermanent`b um `7$reward `^erh�ht!");
                $session[user][maxhitpoints] += $reward;
                $session[user][hitpoints] = $session[user][maxhitpoints];
                break;
            case 21:
            case 22:
                $prevTurns = $session[user][turns];
                if ($prevTurns >= 5) $session[user][turns]-=5;    // original value 5 - but i only offer 20 ff a day
                else if ($prevTurns < 5) $session[user][turns]=0;
                $currentTurns = $session[user][turns];
                $lostTurns = $prevTurns - $currentTurns;
                
                output("ist der Tag vergangen. Es scheint, als h�tte die H�hle dich f�r die meiste Zeit des Tages in der Zeit eingefroren.`n");
                output("Mit dem Ergebnis, da� du leider $lostTurns Waldk�mpfe verlierst!");                
                break;
        }
    }else{
      output("`#Du f�rchtest die unglaublichen Kr�fte dieses Ortes und beschliesst, die kalten G�nge der H�hle lieber in Ruhe zu lassen. Du gehst zur�ck in den Wald.");
    }
}
?>