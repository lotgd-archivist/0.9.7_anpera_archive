<?php 
//Fary 2 
//by Neppar 
// 
//Modyficated by Hadriel 
output("`2Als du durch den Bergwald gehst, gelangst du auf eine `@Lichtung.`n`n`2Pl�tzlich erscheint vor dir eine `^Fee`2 und spricht ...`#'Oh tapferer Krieger! Du bist hergekommen, um Ruhe zu finden nach all deinen Abenteuern! Hier hast du sie, ruh dich nur aus!'`n`n `2Danach streut sie etwas Feenstaub �ber dir aus. Dir wird wohl zu Mute und du schl�fst ein. "); 
output("`n`@Du verlierst zwei Waldk�mpfe beim Schlafen! Als du aufwachst, bemerkst du jedoch, dass du `5sch�ner `@geworden bist und du f�hlst dich sehr `4kr�ftig!"); 
$session[user][hitpoints]+=round($session[user][maxhitpoints]*.1,0); 
$session[user][charm] += 3; 
$session['user']['turns']-=2; 
addnav("Zur�ck in den Wald","berge.php"); 
addnews($session[user][name]." wurde im Bergwald, von einem merkw�rdigen Licht umgeben, schlafend auf einer Lichtung gesehen."); 
?>