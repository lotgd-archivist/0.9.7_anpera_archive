<?php
/*------------------------------------------------------------
/ Wild Magic
/
/ 2004-04-11 The only original thing BlackEdgeMine ever wrote
/            (With thanks to Mortimer & Strider's Druid Forest Special)
/            Coded for www.tqfgames.com
Translated by ???
------------------------------------------------------------*/
if (!isset($session)) exit();
if ($_GET[op]==""){
    output("`7Als du durch die Berge gehst, siehst du in einiger Entfernung ein `^grelles Licht`7.`n");
    output("Du gehst �ber einen Bergkamm und n�herst dich vorsichtig dem Licht.`n");
    output("Pl�tzlich kommt ein starker Wind auf und `&wirft`7 dich zu Boden!`n`n");
    output("Eine schwarze `b`&Spalte`7`b, umgeben von einem rasenden, `!F`@A`#R`^B`%I`!G`@E`#N`7 Wirbelwind erscheint vor deinen Augen.`n`n");
    output("Du hast nur einen Moment dich zu entscheiden. `b`&Was tust du?`b");
    addnav("Geh in den Wirbel","berge.php?op=enter");
    addnav("Schau in die Spalte","berge.php?op=stare");
    addnav("Flieh in Sicherheit","berge.php?op=flee");
    $session[user][specialinc]="wildmagic.php";
}else if ($_GET[op]=="enter"){
        output("`n`7Nichts B�ses f�rchtend gehst du in den Wirbelwind..`n`n");
        switch(e_rand(1,5)){
            case 1:
                output(" `6Du beginnst zu zittern und f�llst zu Boden. Dir wird schwarz vor den Augen..`n");
                $session[bufflist]['Wilde Magie'] = array("name"=>"`#Scharfe K�lte","rounds"=>20,"wearoff"=>"Du f�hlst dich wieder st�rker.","atkmod"=>0.8,"roundmsg"=>"`#Dir l�uft es eiskalt den R�cken runter.","activate"=>"offense");
                break;
            case 2:
                output(" `6Ohne erkennbaren Grund, f�hlst du dich auf einmal gl�cklich. Dich �berkommt die Freud und deine Augen f�llen sich mit Tr�nen.`n");
                $session[bufflist]['Wilde Magie'] = array("name"=>"`#Mit Freude verzaubert","rounds"=>30,"wearoff"=>"Du f�hlst dich wieder normal.","atkmod"=>1.2,"roundmsg"=>"`#Du k�mpfst mit einem Gl�cksgef�hl im Herzen!","activate"=>"offense");
                break;
            case 3:
                output(" `6Nach ein paar Minuten in dem Wirbel wird dir langweilig..`n");
                break;
            case 4:
                output(" `6Du kannst nichts erkennen. Ziemlich schnell wird dir langweilig und du verl�sst den Wirbel.`n");

                output(" `#Du bekommst nicht mit, da� dir etwas aus dem Wirbel folgt...`n");
                $session[bufflist]['Wilde Magie'] = array("name"=>"`#Wirbel G�nstling","rounds"=>30,"wearoff"=>"Der G�nstling verschwindet genauso mysteri�s wie er erschien.","atkmod"=>1.1,"minioncount"=>1,"minbadguydamage"=>1,"maxbadguydamage"=>10,"effectmsg"=>"Ein Wirbel trifft deinen Gegner mit {damage} Schaden!","activate"=>"offense");
                break;
            case 5:
                output(" `6Nachdem du nichts erkennen kannst wird dir schnell langweilig und du gehst.`n");
                output(" `#Du bekommst nicht mit, da� dir etwas aus dem Wirbel folgt...`n");
                $session[bufflist]['Wilde Magie'] = array("name"=>"`#Wirbel G�nstling","rounds"=>10,"wearoff"=>"Der G�nstling verschwindet genauso mysteri�s wie er erschien.","atkmod"=>1.1,"minioncount"=>1,"mingoodguydamage"=>1,"maxgoodguydamage"=>$session['user']['level'],"effectmsg"=>"Ein Wirbel trifft deinen Gegner mit {damage} Schaden!","activate"=>"roundstart");
                break;
        }
}else if ($_GET[op]=="stare"){
        output("`n`7Du starrst in die Spalte..`n`n");
        switch(e_rand(1,4)){
            case 1:
                output(" `6Die `bSPALTE`b starrt ZUR�CK!`n");
                output(" `6Du verlierst Waldk�mpfe!`n");
                if ($session['user']['turns']<4) {$session['user']['turns']=0;}
                else {$session['user']['turns']-=4;}
                break;
            case 2:
                output(" `6Die `bSPALTE`b fl�chtet vor deinem harten Blick!`n");
                output(" `6Du bekommst Waldk�mpfe!`n");
                $session['user']['turns']+=4;
                break;
            case 3:
                output(" `6Du kannst nichts erkennen. Ziemlich schnell wird dir langweilig und du verl�sst den Wirbel.`n");
                output(" `#Du bekommst nicht mit, da� dir etwas aus dem Wirbel folgt...`n");
                $session[bufflist]['Wilde Magie'] = array("name"=>"`#Wirbel G�nstling","rounds"=>30,"wearoff"=>"Der G�nstling verschwindet genauso mysteri�s wie er erschien.","atkmod"=>1.1,"minioncount"=>1,"minbadguydamage"=>1,"maxbadguydamage"=>10,"effectmsg"=>"Der G�nstling verschwindet genauso mysteri�s wie er erschien.","atkmod"=>1.1,"minioncount"=>1,"minbadguydamage"=>1,"maxbadguydamage"=>10,"effectmsg"=>"Ein Wirbel trifft deinen Gegner mit {damage} Schaden!","activate"=>"offense");
                break;
            case 4:
                output(" `6Du kannst nichts erkennen. Ziemlich schnell wird dir langweilig und du verl�sst den Wirbel.`n");
                output(" `#Du bekommst nicht mit, da� dir etwas aus dem Wirbel folgt...`n");
                $session[bufflist]['Wilde Magie'] = array("name"=>"`#Wirbel G�nstling","rounds"=>10,"wearoff"=>"Der G�nstling verschwindet genauso mysteri�s wie er erschien.","atkmod"=>1.1,"minioncount"=>1,"mingoodguydamage"=>1,"maxgoodguydamage"=>$session['user']['level'],"effectmsg"=>"Der G�nstling verschwindet genauso mysteri�s wie er erschien.","atkmod"=>1.1,"minioncount"=>1,"minbadguydamage"=>1,"maxbadguydamage"=>10,"effectmsg"=>"Ein Wirbel trifft deinen Gegner mit {damage} Schaden!","activate"=>"roundstart");
                break;
        }
} else {
    output("`n`@Du fliehst vor dem Wirbel!`n");
}

?>