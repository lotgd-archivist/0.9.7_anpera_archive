<?php
// idea of gargamel @ www.rabenthal.de
if (!isset($session)) exit();

if ($_GET[op]==""){
    output("Inmitten einer kleinen Buchengruppe steht ein altes `QEichenfass`0. Genau
    solche F�sser sind es, in denen Waren transportiert werden. Vielleicht ist dies
    hier einem Kutscher heruntergefallen? Dann lohnt doch ein genauerer Blick...`n`n`0");
    addnav("Fass untersuchen","berge.php?op=examine");
    addnav("Weitergehen","berge.php?op=cont");
    $session[user][specialinc] = "barrel.php";
}
else if ($_GET[op]=="examine"){   //
    output("Du trittst ans Fass heran und nimmst den morschen Deckel ab.`n`n`0");
    $was = e_rand(1,7);
    switch ( $was ) {
        case 1:
        output("Im Fass funkelt ein `^Edelstein`0, den Du gleich einsteckst.`n
        Pfeiffend gehst Du weiter...`n`0");
        $session[user][gems]++;
        break;
        case 2: case 3:
        output("Das Fass ist fast randvoll mit Salz gef�llt. Du w�hlst mit Deinen
        H�nden drin, um nach etwas Wertvollem zu suchen. Leider findest Du nichts.
        Aber die Haut an Deinen H�nden ist ger�tet. Das Salz muss sie ver�tzt haben.`n`n
        `$ Du kannst Deine Waffe nicht mehr so sicher halten, was Dich einige Runden
        im Kampf behindert.`0");
        $session[bufflist]['salzfass'] = array("name"=>"`4Salzbrand",
                                        "rounds"=>8,
                                        "wearoff"=>"Deine H�nde sind verheilt.",
                                        "defmod"=>1,
                                        "atkmod"=>0.65,
                                        "roundmsg"=>"Deine H�nde sp�ren Salz und keine Waffe.",
                                        "activate"=>"offense");
        break;
        case 4:
        output("Du schaust hinein, siehst aber schlicht gar nichts.`n`n`QEin bisschen
        entt�uscht gehst Du weiter.`0");
        break;
        case 5: case 6:
        output("Das Fass ist bis oben voll mit Wein. Sofort probierst Du einen
        Schluck. Der Wein ist etwas verw�ssert. Aber definitiv ist das ein einheimischer Wein.`n`n
        Als Bewohner von Tetharion hat er auf Dich eine ganz besondere Wirkung.`n`n`QDu
        nimmst den Weingeist wahr, der Dich einige Runden unterst�tzt.`0");
        $session[bufflist]['salzfass'] = array("name"=>"`4Weingeist",
                                        "rounds"=>12,
                                        "wearoff"=>"Der Weingeist verfl�chtigt sich.",
                                        "defmod"=>1.1,
                                        "atkmod"=>1.25,
                                        "roundmsg"=>"Der Weingeist ist Dir wohl gesonnen.",
                                        "activate"=>"offense");
        break;
        case 7:
        output("Du schaust hinein, kannst aber nichts erkennen. Das Fass scheint
        tiefer zu sein, als es den Anschein hat. Du beugst Dich �ber den Rand...`n`n
        Leider verlierst du das Gleichgewicht und st�rzt kopf�ber in das Fass.`n
        `$ Am Boden st��t Du Dir gewaltig den Kopf und ertrinkst in dem Regenwasser, dass
        sich dort angesammelt hat.`n`n
        Du kannst morgen weiter k�mpfen.`0");
        $session[user][alive]=false;
        $session[user][gold]=0;
        $session[user][hitpoints]=0;
        addnews("`^".$session[user][name]."`2 ist in einem Fass ertrunken. `@In einem Fass!");
        addnav("T�gliche News","news.php");
        break;
    }
    $session[user][specialinc]="";
}
else if ($_GET[op]=="cont"){   // einfach weitergehen
    output("`QDu l�sst das Fa� stehen und gehst lieber weiter. Ale ist da wohl eh nicht drin...`0");
    $session[user][specialinc]="";
}
?>