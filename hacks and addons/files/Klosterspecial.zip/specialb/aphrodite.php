<?php 

// 22062004

// translation found at http://logd.ist-hier.de
// small ... BIG ... modifications by anpera

if (!isset($session)) exit();

if ($_GET[op]=="do"){
	$session[user][reputation]--;
	if ($session['user']['sex']>0){
		output("`%Du folgst dem Gott in die B�sche. Wenige Minuten sp�ter, sind "); 
		output("nur noch leise Ger�usche zu h�ren. "); 
		output("Als du erwachst, stellst du fest ...`n`n`^"); 
		switch(e_rand(1,10)){ 
			case 1: 
			case 2: 
			output("`%dass er verschwunden ist ohne sich zu verabschieden.`n`n`^Aufgrund deiner Ersch�pfung, verlierst du einen Waldkampf.`0"); 
			$session[user][turns]-=1; 
			$session[user][experience]+=150; 
			break; 
			case 3: 
			case 4: 
			output("`%dass er verschwunden ist ohne sich zu verabschieden.`n`n`^Du f�hlst dich gut und k�nntest jetzt einen Kampf vertragen.`0"); 
			$session[user][turns]+=1; 
			$session[user][experience]+=150; 
			break; 
			case 5: 
			output("`%dass er dir einen Beutel mit Edelsteinen da gelassen hat.`n`n`^Du f�hlst dich benutzt, akzeptierst aber die Bezahlung!`0"); 
			$session[user][gems]+=3; 
			$session[user][experience]+=150; 
			break; 
			case 6: 
			output("`%dass er einen goldenen Apfel da gelassen hat.`n`n`^Als du in den Apfel bei�t, f�hlst du zus�tzliche Lebenskraft in dir!`0"); 
			$session[user][maxhitpoints]+=1; 
			$session[user][experience]+=150; 
			break; 
			case 7: 
			case 8: 
			case 9: 
			case 10: 
			increment_specialty(); 
			break; 
		} 
		addnews($session[user][name]." hatte einen Quicky mit einem Gott im Gebirge.");
		$session[user][specialinc]="";
		//addnav("Zur�ck in die Berge","berge.php");
	}else{ 
		output("`%Du folgst der G�ttin in die B�sche. Wenige Minuten sp�ter, sind "); 
		output("nur noch leise Ger�usche zu h�ren. "); 
		output("Als du erwachst, stellst du fest ...`n`n`^"); 
		switch(e_rand(1,10)){ 
			case 1: 
			case 2: 
			output("`%dass sie verschwunden ist ohne sich zu verabschieden.`n`n`^Aufgrund deiner Ersch�pfung, verlierst du einen Waldkampf.`0"); 
			$session[user][turns]-=1; 
			$session[user][experience]+=150; 
			break; 
			case 3: 
			case 4: 
			output("`%dass sie verschwunden ist ohne sich zu verabschieden.`n`n`^Du f�hlst dich gut und k�nntest jetzt einen Kampf vertragen.`0"); 
			$session[user][turns]+=1; 
			$session[user][experience]+=150; 
			break; 
			case 5: 
			output("`%dass sie dir einen Beutel mit Edelsteinen da gelassen hat.`n`n`^Du f�hlst dich benutzt, akzeptierst aber die Bezahlung!`0"); 
			$session[user][gems]+=3; 
			$session[user][experience]+=150; 
			break; 
			case 6: 
			output("`%dass sie einen goldenen Apfel da gelassen hat.`n`n`^Als du in den Apfel beisst, f�hlst du zus�tzliche Lebenskraft in dir!`0"); 
			$session[user][maxhitpoints]+=1; 
			$session[user][experience]+=150; 
			break; 
			case 7: 
			case 8: 
			case 9: 
			case 10: 
			increment_specialty(); 
			break; 
		} 
		addnews($session[user][name]." hatte einen Quicky mit einer G�ttin im Gebirge.");
		$session[user][specialinc]="";
		//addnav("Zur�ck in die Berge","berge.php");
	}
}else if ($_GET[op]=="dont"){
	output("`%In Gedanken an ".($session[user][sex]?"deinen Geliebten":"deine Geliebte")." rennst du weg. Die Gottheit lacht auf und verschwindet in den Schatten des Waldes.`0");
	$session[user][specialinc]="";
	$session[user][reputation]+=2;
	//addnav("Zur�ck in die Berge","berge.php");
}else{
	if ($session['user']['sex']>0){
		output("`%Als du durch die Berge wanderst, spricht dich ein stattlicher Mann an: `^\"Ich bin der Gott Fexez. Ich habe von dir geh�rt. Komm mit mir.\"`n`n`%Was tust du ?`0"); 
	}else{
		output("`%Als du durch die Berge wanderst, erscheint Dir eine wundersch�ne Frau: `^\"Ich bin die G�ttin Aphrodite. Ich habe sogar in Athen von deiner Manneskraft geh�rt. Ich will es ausprobieren. Komm mit mir.\"`n`n`%Was tust du?`0"); 
	}
		addnav("Gehe mit","berge.php?op=do"); 
		addnav("Laufe weg","berge.php?op=dont"); 
		$session[user][specialinc]="aphrodite.php"; 
}
?>