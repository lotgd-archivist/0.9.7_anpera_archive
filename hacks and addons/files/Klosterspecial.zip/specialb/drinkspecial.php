<?php
//Trankspecial by Neppar
//Modificated by Hadriel
//small adjustments by gargamel @ www.rabenthal.de

if (!isset($session)) exit();


if ($_GET[op]==""){
    output("`6Als Du durch den Bergwald l�ufst, bemerkst Du etwas abgelegen vom Weg
    in der Erde etwas `@Schimmerndes.`6 Du beschlie�t, es n�her anzuschauen, aber
    kannst nichts erkennen, da alles voll mit Erde ist. Du wischst vorsichtig
    die `TErde `6weg und bemerkst, dass es eine `g gef�llte Flasche `6ist!!! Als
    Du sie genauer untersuchst, bemerkst Du eine `#etwas zerrissene Etikette.
    `6Du kannst nicht genau erkennen, was auf ihr steht, doch ein Wort kannst Du
    entziffern:''`^Lebenskraft`6.''`0");
    if ((int)$session[user][race] == 3)
    {
        output("`n`n`6Dein gesunder Menschenverstand l�sst Dich ahnen, dass dies
        Deine Lebenskraft auch negativ beeinflussen k�nnte. `n`n
        `7M�chtest Du trotzdem die merkw�rdige Fl�ssigkeit trinken?`0");
    }
    else
    {
        output("`n`7Trinkst du die Fl�ssigkeit in der Hoffnung, dass dadurch
        Deine Lebenskraft erh�ht wird? Oder l�sst Du sie liegen, da das Risiko bei
        etwas im Wald gefundenen gross ist?`0");
    }
    //abschluss intro
    addnav("Fl�ssigkeit trinken","berge.php?op=drink");
    addnav("Die Finger davon lassen","berge.php?op=nodrink");
    $session[user][specialinc]="drinkspecial.php";
}
else if ($_GET[op]=="drink"){
    $rand = e_rand(1,5);
    output("`6Du beschliesst, trotz allen Gefahren die Fl�ssigkeit zu trinken. Danach ");
    switch ($rand) {
        case 1: case 2: case 3:
        output("wird Dir sehr wohl zumute! Eine angenehme W�rme umgibt deinen ganzen
        K�rper und du merkst, wie dein K�rper `bregeneriert`b! Und dann f�hlst du,
        wie `^Energie `6in deinen K�rper str�mt! `n`n
        Der Trank hat dir
        einen `^`bpermanenten`b `6Lebenspunkt beschert!`n`nGl�cklich �ber die positive
        Auswirkung des Trankes gehst du zur�ck in den Wald.`0");
        $session[user][maxhitpoints]++;
        $session[user][hitpoints]++;
        break;
        case 4: case 5:
        output("`6sp�rst Du ein komisches Gef�hl in Deinem Magen. Dir wird schlecht
        und Du musst brechen. W�hrend Du erbrichst, merkst Du, wie die Energie aus
        Deinem K�rper schwindet. Dir wird schwindlig und Du f�llst in Ohnmacht. Auch
        nachdem Du wieder aufgewacht bist, f�hlst Du Dich schwach. Du h�ttest lieber
        die Finger von diesem Trank lassen sollen.`n`n`0");
        $session[user][maxhitpoints]--;
        output("`4Du verlierst `bpermanent`b einen Lebenspunkt!!!`0");
        break;
     }
    $session[user][specialinc]="";
}
else if ($_GET[op]=="nodrink"){
    output("`@Du traust dem Braten, ehm, dem Trank nicht und l�ufst lieber weiter.
    Wer weiss, was da drin sein k�nnte?! Soll das doch ein anderer ausprobieren...");
    $session[user][specialinc]="";
}
?>