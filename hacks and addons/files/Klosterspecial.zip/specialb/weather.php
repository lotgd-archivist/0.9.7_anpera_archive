<?php
// idea of gargamel @ www.rabenthal.de
if (!isset($session)) exit();

if($_GET['op'] == '' || $_GET['op']== 'search'){ 
    output("Sag mal, ".$session[user][name].", hast Du eigentlich heute schon zum
    Himmel geschaut?`nDas Wetter ist `^".$settings['weather']."`0!!`n`n");

    if ( $settings['weather'] == "bew�lkt" ) {
        output("`&\"K�nnte besser sein\",`0 denkst Du Dir und gehst weiter.");
    }
	else if ( $settings['weather'] == "windig" ) {
        output("`&\"K�nnte besser sein\",`0 denkst Du Dir und gehst weiter.");
    }
	else if ( $settings['weather'] == "aufgelockert und etwas w�rmer" ) {
        output("`&\"K�nnte besser sein\",`0 denkst Du Dir und gehst weiter.");
    }
    else if ( $settings['weather']=="warm und schw�l" ) {
        output("Du bist hier ganz in der N�he von einem kleinen Bergsee. Und so
        wundert es nicht, dass bei diesem Wetter eine wahre M�ckenplage herrscht.`n`n`0");
        $case = e_rand(1,2);
        switch ( $case ) {
            case 1:
            output("Du musst die Plagegeister st�ndig wegscheuchen, was Dich etwas
            Aufmerksamkeit im n�chsten Kampf kostet. `n`n`^Deine Verteidigung wird schw�cher.`n`0");
            $session[bufflist]['muecken'] = array("name"=>"`4M�cken",
                                        "rounds"=>10,
                                        "wearoff"=>"Die M�cken haben sich verzogen.",
                                        "defmod"=>0.92,
                                        "atkmod"=>1,
                                        "roundmsg"=>"Die M�cken behindern Dich.",
                                        "activate"=>"defense");
            break;

            case 2:
            output("Bei dem st�ndigen Geschwirre kannst Du Dich kaum auf den n�chsten
            Kampf konzentrieren. `n`n`^Deine Angriffsf�higkeit ist daher eingeschr�nkt.`0");
            $session[bufflist]['muecken'] = array("name"=>"`4M�cken",
                                        "rounds"=>10,
                                        "wearoff"=>"Die M�cken haben sich verzogen.",
                                        "defmod"=>1,
                                        "atkmod"=>0.92,
                                        "roundmsg"=>"Die M�cken behindern Dich.",
                                        "activate"=>"offense");
            break;
        }
    }else if ( $settings['weather']=="sehr warm" ) {
        output("Du bist hier ganz in der N�he von einem kleinen Bergsee. Und so
        wundert es nicht, dass bei diesem Wetter eine wahre M�ckenplage herrscht.`n`n`0");
        $case = e_rand(1,2);
        switch ( $case ) {
            case 1:
            output("Du musst die Plagegeister st�ndig wegscheuchen, was Dich etwas
            Aufmerksamkeit im n�chsten Kampf kostet. `n`n`^Deine Verteidigung wird schw�cher.`n`0");
            $session[bufflist]['muecken'] = array("name"=>"`4M�cken",
                                        "rounds"=>10,
                                        "wearoff"=>"Die M�cken haben sich verzogen.",
                                        "defmod"=>0.92,
                                        "atkmod"=>1,
                                        "roundmsg"=>"Die M�cken behindern Dich.",
                                        "activate"=>"defense");
            break;

            case 2:
            output("Bei dem st�ndigen Geschwirre kannst Du Dich kaum auf den n�chsten
            Kampf konzentrieren. `n`n`^Deine Angriffsf�higkeit ist daher eingeschr�nkt.`0");
            $session[bufflist]['muecken'] = array("name"=>"`4M�cken",
                                        "rounds"=>10,
                                        "wearoff"=>"Die M�cken haben sich verzogen.",
                                        "defmod"=>1,
                                        "atkmod"=>0.92,
                                        "roundmsg"=>"Die M�cken behindern Dich.",
                                        "activate"=>"offense");
            break;
        }
    }
	else if ( $settings['weather']=="warm mit Sommergewitter" ) {
        output("Du bist hier ganz in der N�he von einem kleinen Bergsee. Und so
        wundert es nicht, dass bei diesem Wetter eine wahre M�ckenplage herrscht.`n`n`0");
        $case = e_rand(1,2);
        switch ( $case ) {
            case 1:
            output("Du musst die Plagegeister st�ndig wegscheuchen, was Dich etwas
            Aufmerksamkeit im n�chsten Kampf kostet. `n`n`^Deine Verteidigung wird schw�cher.`n`0");
            $session[bufflist]['muecken'] = array("name"=>"`4M�cken",
                                        "rounds"=>10,
                                        "wearoff"=>"Die M�cken haben sich verzogen.",
                                        "defmod"=>0.92,
                                        "atkmod"=>1,
                                        "roundmsg"=>"Die M�cken behindern Dich.",
                                        "activate"=>"defense");
            break;

            case 2:
            output("Bei dem st�ndigen Geschwirre kannst Du Dich kaum auf den n�chsten
            Kampf konzentrieren. `n`n`^Deine Angriffsf�higkeit ist daher eingeschr�nkt.`0");
            $session[bufflist]['muecken'] = array("name"=>"`4M�cken",
                                        "rounds"=>10,
                                        "wearoff"=>"Die M�cken haben sich verzogen.",
                                        "defmod"=>1,
                                        "atkmod"=>0.92,
                                        "roundmsg"=>"Die M�cken behindern Dich.",
                                        "activate"=>"offense");
            break;
        }
    }
    else if ( $settings['weather']=="regnerisch" ) {
        if ( $session['user']['specialty'] == 1 ) {
            output("Als Du nun bei dem miesen Wetter durch die Berge stapfst, wird
            Deine Stimmung nochmal schlechter.`n`n
            Deinen F�higkeiten tut dies jedoch gut und `^Du steigst eine Stufe auf.`n`0");
            increment_specialty();
        } else {
            output("Als nun ein weiteres Schauer niedergeht, ziehst Du Dir erstmal
            schnell Deinen Regenschutz �ber.`n`n
            `^Leider behindert er Dich etwas beim K�mpfen...`0");
            $session[bufflist]['regenjacke'] = array("name"=>"`4Regenschutz",
                                        "rounds"=>25,
                                        "wearoff"=>"Gut! Der Regenschauer ist vorbei.",
                                        "defmod"=>0.96,
                                        "atkmod"=>0.92,
                                        "roundmsg"=>"Der Regenschutz behindert Dich.",
                                        "activate"=>"defense");
        }
    }
    else if ( $settings['weather']=="neblig" ) {
        if ( $session['user']['specialty'] == 3 ) {
            output("Das kommt Dir mit Deinen Diebesf�higkeiten nat�rlich entgegen.`n`n
            `^Du erh�ltst einen zus�tzlichen Waldkampf!`0");
            $session['user']['turns']++;
        } else {
            output("Da ist es noch schwieriger, sich im Gebirge zurechtzufinden. Und
            prompt nimmst Du eine falsche Abzweigung vom Bergpfad.`n`n
            `^Du verlierst einen Waldkampf.`0");
            $session['user']['turns']--;
        }
    }
    else if ( $settings['weather']=="k�hl bei klarem Himmel" ) {
       output("Meinst Du wirklich, deine R�stung ist da die richtige
        Kleidung?`n`0");
        $case = e_rand(1,2);
        switch ( $case ) {
            case 1:
            output("`^Du handelst Dir einen Schnupfen ein und verlierst ein paar
            Lebenspunkte.`0");
            $session[user][hitpoints]=round($session[user][hitpoints]*0.95);
            break;
             
            case 2:
            output("Du sammelst etwas Reisig im Unterholz und w�rmst Dich erstmal
            an einem kleinen Feuerchen.`n`n
            `^Die Pause kostet Dich einen Waldkampf.`0");
            $session['user']['turns']--;
        }
    }else if ( $settings['weather']=="windig und frisch" ) {
       output("Meinst Du wirklich, deine R�stung ist da die richtige
        Kleidung?`n`0");
        $case = e_rand(1,2);
        switch ( $case ) {
            case 1:
            output("`^Du handelst Dir einen Schnupfen ein und verlierst ein paar
            Lebenspunkte.`0");
            $session[user][hitpoints]=round($session[user][hitpoints]*0.95);
            break;
             
            case 2:
            output("Du sammelst etwas Reisig im Unterholz und w�rmst Dich erstmal
            an einem kleinen Feuerchen.`n`n
            `^Die Pause kostet Dich einen Waldkampf.`0");
            $session['user']['turns']--;
        }
    }
	else if ( $settings['weather']=="kalt mit Schneefall" ) {
       output("Meinst Du wirklich, deine R�stung ist da die richtige
        Kleidung?`n`0");
        $case = e_rand(1,2);
        switch ( $case ) {
            case 1:
            output("`^Du handelst Dir einen Schnupfen ein und verlierst ein paar
            Lebenspunkte.`0");
            $session[user][hitpoints]=round($session[user][hitpoints]*0.95);
            break;
             
            case 2:
            output("Du sammelst etwas Reisig im Unterholz und w�rmst Dich erstmal
            an einem kleinen Feuerchen.`n`n
            `^Die Pause kostet Dich einen Waldkampf.`0");
            $session['user']['turns']--;
        }
    }
	else if ( $settings['weather']=="klirrend kalt bei klarem Himmel" ) {
       output("Meinst Du wirklich, deine R�stung ist da die richtige
        Kleidung?`n`0");
        $case = e_rand(1,2);
        switch ( $case ) {
            case 1:
            output("`^Du handelst Dir einen Schnupfen ein und verlierst ein paar
            Lebenspunkte.`0");
            $session[user][hitpoints]=round($session[user][hitpoints]*0.95);
            break;
             
            case 2:
            output("Du sammelst etwas Reisig im Unterholz und w�rmst Dich erstmal
            an einem kleinen Feuerchen.`n`n
            `^Die Pause kostet Dich einen Waldkampf.`0");
            $session['user']['turns']--;
        }
    }
	else if ( $settings['weather']=="kalt" ) {
       output("Meinst Du wirklich, deine R�stung ist da die richtige
        Kleidung?`n`0");
        $case = e_rand(1,2);
        switch ( $case ) {
            case 1:
            output("`^Du handelst Dir einen Schnupfen ein und verlierst ein paar
            Lebenspunkte.`0");
            $session[user][hitpoints]=round($session[user][hitpoints]*0.95);
            break;
             
            case 2:
            output("Du sammelst etwas Reisig im Unterholz und w�rmst Dich erstmal
            an einem kleinen Feuerchen.`n`n
            `^Die Pause kostet Dich einen Waldkampf.`0");
            $session['user']['turns']--;
        }
    }
	else if ( $settings['weather']=="kalt bei flockigem Weihnachtsschneefall" ) {
       output("Meinst Du wirklich, deine R�stung ist da die richtige
        Kleidung?`n`0");
        $case = e_rand(1,2);
        switch ( $case ) {
            case 1:
            output("`^Du handelst Dir einen Schnupfen ein und verlierst ein paar
            Lebenspunkte.`0");
            $session[user][hitpoints]=round($session[user][hitpoints]*0.95);
            break;
             
            case 2:
            output("Du sammelst etwas Reisig im Unterholz und w�rmst Dich erstmal
            an einem kleinen Feuerchen.`n`n
            `^Die Pause kostet Dich einen Waldkampf.`0");
            $session['user']['turns']--;
        }
    }
	else if ( $settings['weather']=="bew�lkt bei leichtem Schneefall" ) {
       output("Meinst Du wirklich, deine R�stung ist da die richtige
        Kleidung?`n`0");
        $case = e_rand(1,2);
        switch ( $case ) {
            case 1:
            output("`^Du handelst Dir einen Schnupfen ein und verlierst ein paar
            Lebenspunkte.`0");
            $session[user][hitpoints]=round($session[user][hitpoints]*0.95);
            break;
             
            case 2:
            output("Du sammelst etwas Reisig im Unterholz und w�rmst Dich erstmal
            an einem kleinen Feuerchen.`n`n
            `^Die Pause kostet Dich einen Waldkampf.`0");
            $session['user']['turns']--;
        }
    }
	else if ( $settings['weather']=="saukalt bei klarem Himmel" ) {
       output("Meinst Du wirklich, deine R�stung ist da die richtige
        Kleidung?`n`0");
        $case = e_rand(1,2);
        switch ( $case ) {
            case 1:
            output("`^Du handelst Dir einen Schnupfen ein und verlierst ein paar
            Lebenspunkte.`0");
            $session[user][hitpoints]=round($session[user][hitpoints]*0.95);
            break;
             
            case 2:
            output("Du sammelst etwas Reisig im Unterholz und w�rmst Dich erstmal
            an einem kleinen Feuerchen.`n`n
            `^Die Pause kostet Dich einen Waldkampf.`0");
            $session['user']['turns']--;
        }
    }
	else if ( $settings['weather']=="kalt bei Schneeregen" ) {
       output("Meinst Du wirklich, deine R�stung ist da die richtige
        Kleidung?`n`0");
        $case = e_rand(1,2);
        switch ( $case ) {
            case 1:
            output("`^Du handelst Dir einen Schnupfen ein und verlierst ein paar
            Lebenspunkte.`0");
            $session[user][hitpoints]=round($session[user][hitpoints]*0.95);
            break;
             
            case 2:
            output("Du sammelst etwas Reisig im Unterholz und w�rmst Dich erstmal
            an einem kleinen Feuerchen.`n`n
            `^Die Pause kostet Dich einen Waldkampf.`0");
            $session['user']['turns']--;
        }
    }
	else if ( $settings['weather']=="kalt mit Schneegest�ber" ) {
       output("Meinst Du wirklich, deine R�stung ist da die richtige
        Kleidung?`n`0");
        $case = e_rand(1,2);
        switch ( $case ) {
            case 1:
            output("`^Du handelst Dir einen Schnupfen ein und verlierst ein paar
            Lebenspunkte.`0");
            $session[user][hitpoints]=round($session[user][hitpoints]*0.95);
            break;
             
            case 2:
            output("Du sammelst etwas Reisig im Unterholz und w�rmst Dich erstmal
            an einem kleinen Feuerchen.`n`n
            `^Die Pause kostet Dich einen Waldkampf.`0");
            $session['user']['turns']--;
        }
    }
    else if ( $settings['weather']=="sonnig und hei�" ) {
        output("Im Nollopa hast Du es sogar als schw�l empfunden und genie�t daher
        die Zeit im schattigen, k�hlen Bergwald.`n`n
        `^Du bekommst einen Waldkampf.`0");
        $session['user']['turns']++;
    }
	else if ( $settings['weather']=="sehr, sehr hei�" ) {
        output("In Nollopa hast Du es sogar als schw�l empfunden und genie�t daher
        die Zeit im schattigen, k�hlen Bergwald.`n`n
        `^Du bekommst einen Waldkampf.`0");
        $session['user']['turns']++;
    }
    else if ( $settings['weather']=="stark windig mit vereinzelten Regenschauern" ) {
        output("Die gro�en alten B�ume hier biegen sich unter der Wucht einzelner
        Windb�en. Ein gro�er Ast kann dem Wind nicht mehr standhalten und kracht zu
        Boden.`n`0");
        $case = e_rand(1,2);
        switch ( $case ) {
            case 1:
            output("Du hast mehr Gl�ck als Verstand! Der m�chtige Ast schl�gt nur
            wenige Schritte von Dir entfernt auf. Dir ist nichts passiert.`n`n
            `^Etwas eingesch�chtert gehst Du weiter.`0");
            break;
             
            case 2:
            output("Zum Gl�ck schl�gt der Ast neben Dir ein, aber ein paar kleinere
            �ste treffen Dich doch.`n`n `^Du b�sst Lebenspunkte ein!`0");
            $hp = e_rand(1,$session[user][hitpoints]);
            $session[user][hitpoints]=$hp;
            break;
        }
    }
	else if ( $settings['weather']=="stark windig, aber warm" ) {
        output("Die gro�en alten B�ume hier biegen sich unter der Wucht einzelner
        Windb�en. Ein gro�er Ast kann dem Wind nicht mehr standhalten und kracht zu
        Boden.`n`0");
        $case = e_rand(1,2);
        switch ( $case ) {
            case 1:
            output("Du hast mehr Gl�ck als Verstand! Der m�chtige Ast schl�gt nur
            wenige Schritte von Dir entfernt auf. Dir ist nichts passiert.`n`n
            `^Etwas eingesch�chtert gehst Du weiter.`0");
            break;
             
            case 2:
            output("Zum Gl�ck schl�gt der Ast neben Dir ein, aber ein paar kleinere
            �ste treffen Dich doch.`n`n `^Du b�sst Lebenspunkte ein!`0");
            $hp = e_rand(1,$session[user][hitpoints]);
            $session[user][hitpoints]=$hp;
            break;
        }
    }
    else if ( $settings['weather']=="regnerisch mit Gewitterst�rmen" ) {
        if ( $session['user']['specialty'] == 2 ) {
            output("Um Dich herum zucken die Blitze durch den verdunkelten Himmel.
            Genau richtig, um die magischen Kr�fte aufzuladen.`n`n
            `^Du kannst Deine F�higkeiten wieder einsetzen.`0");
            //-> f�higkeiten aktivieren
            $session[user][darkartuses]=floor ( $session[user][darkarts]/3 );
            $session[user][magicuses]=floor ( $session[user][magic]/3 );
            $session[user][thieveryuses]=floor ( $session[user][thievery]/3 );
        } else {
            output("Gerade im Gebirge ist das nicht ungef�hrlich!`n`n
            Um Dich vor Blitzschlag zu sch�tzen, stellst Du Dich in einer H�hle
            unter.`n`n
            `^Du verlierst einen Waldkampf.`0");
            $session['user']['turns']--;
        }
    }
}
?>