<?php
// Grundidee der Affenj�ger von logd.de
// Affenj�germodifikation � by Hecki f�r http://www.cop-logd.de
// Hexenj�ger und Diebesj�ger � by Hecki f�r http://www.cop-logd.de
// 27.02.05 - 02.03.05
// Special Modifikationen � by Hecki, danke an Alle Autoren der Original Specials :o)

require_once"common.php";
page_header("Der Affe");

if($_GET['op'] == '' || $_GET['op']== 'search'){ 
$session[user][specialinc]="affenspecial2.php";

        $session[user][specialinc] = "affenspecial2.php";
         if ($session[user][gems]>0){
                $session[user][gems]--;
                addnav("Affen jagen","berge.php?op=attacke");
	        addnav("Affen leben lassen","berge.php?op=leave");
		output(" Du sp�rst einen Ruck an deiner Edelsteinsammlung und Kurz darauf siehst du ein �ffchen mit einem deiner Edelsteine im Bergwald verschwinden.`0");
	        output("`^VERFLUCHTER AFFE! Deine Affenj�gerinstinkte werden wach, willst du versuchen ihn zu erwischen?");

        }else{
                output("Du sp�rst einen Ruck an deiner Edelsteinsammlung aber gl�cklicherweise hast du keine Edelsteine dabei und machst dir darum auch keine Sorgen wegen dem �ffchen, das scheinbar entt�uscht zur�ck in den Bergwald l�uft.`0");
                $session[user][specialinc] = "";


            }
}

else if ($_GET[op]=="attacke"){
	$erfolg=0;
	if ($session[user][attack] > 10)
	{
		if (e_rand(1,3) >1) {$erfolg=1;}
	}
	else
	{	if (e_rand(1,2)==1) {$erfolg=1;}
	
	}
        if ($erfolg==1){ output("`@ Du erwischst den Affen im Geb�sch und erledigst ihn mit deiner Waffe: `\$".$session[user][weapon]."`@!`n");
                            output("`@ Du bekommst deinen Edelstein zur�ck und findest in der anderen Hand des erschlagenen Affen noch einen weiteren.`n");
                            $session[user][gems]+=2;
        }else{
        output("`@ Leider entkommt dir das �ffchen mit deinem Edelstein.");
        $session[user][specialinc] = "";

         }

}

else if ($_GET[op]=="leave")
{	addnav("Weiter","berge.php");
      output("Du kehrst in den Wald zur�ck");
      $session[user][specialinc] = "";
      
}

?>