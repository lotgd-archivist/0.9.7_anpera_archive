<?php
// Gypsy Camp - special by Robert for Maddnet LoGD 
// translation by gargamel @ www.rabenthal.de 
// Adjustments and modifications by gargamel @ www.rabenthal.de 

if (!isset($session)) exit(); 

if ($_GET[op]==""){ 
    //output("`n`3`c`bZigeuner-Lager`b`c `n `n"); 
    output("`2Auf Deinem Weg durch die Berge wirst Du auf eine kleine Lichtung in einem Tal aufmerksam. 
    Angezogen von fremden Ger�uschen steuerst Du auf ein buntes Treiben zu.`n"); 
    output("Du hast das `3Zigeuner-Lager`2 entdeckt! `n`n"); 
    output("`2Du siehst bunte Planwagen und einige Eselskarren. Inmitten des Lagers 
    flackert ein gro�es Lagerfeuer und an jedem Wagen brennt ein buntes Licht. Viele 
    Gestalten laufen gesch�ftig durch das Lager, es wird getrunken, gegessen und bei 
    typischer Zigeunermusik gefeiert.`n`n 
    Dann bemerken Dich die Zigeuner in ihrem Lager. Einige gehen schnell in ihre Wagen, 
    w�hrend Du von anderen freundlich angel�chelt wirst. Eine alte Zigeunerin winkt 
    Dich heran zu ihrem Tisch und bietet Dir Speise und Trank an.`0"); 
    //abschluss intro 
    addnav("Essen"); 
    addnav("Brot","berge.php?op=bread"); 
    addnav("Trinken"); 
    addnav("Eimer Wasser","berge.php?op=water"); 
    addnav("Karaffe Wein","berge.php?op=wine"); 
    addnav("Spanischer Lik�r","berge.php?op=fly"); 
    addnav("Sonstiges"); 
    addnav("Blinder Zigeuner","berge.php?op=blind"); 
    addnav("T�nzer","berge.php?op=dancer"); 
    addnav("Myra","berge.php?op=myra"); 
    addnav("Vlad","berge.php?op=vlad"); 
    addnav("Lager verlassen"); 
    addnav("Zur�ck in den Wald","berge.php?op=leave"); 
    $session[user][specialinc] = "gypsycamp.php"; 


}else if ($_GET[op]=="bread"){ 
    if (e_rand(0,1)==0) { 
        output("`2Du nimmst Dir Brot vom Tisch. Hungrig isst Du das ganze St�ck 
        auf und sp�rst, wie eine fremde Kraft Deinen Geist st�rkt!`n`n 
        `&Du erh�ltst 2 Anwendungen in Diebesk�nsten. `n 
        `#Aber Du weisst, dass diese Kraft morgen wieder vergangen ist."); 
        $session[user][thieveryuses] = $session[user][thieveryuses] + 2; 
    } 
    else { 
        output("`2Du nimmst Dir Brot vom Tisch. Hungrig isst Du das ganze St�ck 
        auf und denkst, dass Du zuviel gegessen hast! `n 
        \"Mit vollem Magen k�mpft man schlecht!\"`n`n 
        `&Du verlierst zwei Waldk�mpfe."); 
        $session[user][turns]-=2; 
    } 
    $session[user][specialinc]=""; 
} 
else if ($_GET[op]=="water"){ 
    if (e_rand(0,1)==0) { 
        output("`#Du greift Dir eine Sch�pfkelle und f�llst Dein Wasserglas aus 
        dem grossen Eimer, der neben dem Tisch steht. Nachdem Dein Durst gestillt 
        ist, f�hlst Du Dich erfrischt!`n`n 
        `&Deine Lebenskraft ist wieder vollst�ndig."); 
        if ($session['user']['hitpoints']<$session['user']['maxhitpoints']) 
            $session[user][hitpoints]=$session[user][maxhitpoints]; 
    } 
    else { 
        output("`#Du greift Dir eine Sch�pfkelle und f�llst Dein Wasserglas aus 
        dem grossen Eimer, der neben dem Tisch steht. Nachdem Du Dein Glas in einem 
        Zug geleert hast, bemerkst Du einen komsichen Nachgeschmack.`n 
        Man hat Dir altes Badewasser angeboten!`n`n 
        `&Du verlierst einige Lebenspunkte.`0"); 
        $session[user][hitpoints]= round($session[user][hitpoints]*0.92); 
    } 
    $session[user][specialinc]=""; 
} 
else if ($_GET[op]=="wine"){ 
    if (e_rand(0,1)==0) { 
        output("`2Du nimmst Dir die `3Karaffe mit Wein`2 vom Tisch und f�llst Dein Glas. 
        Du stillst Deinen Durst und f�hlst neue Kraft in Dir.`n`n 
        `&Deine Lebenspunkte steigen."); 
        $session[user][hitpoints]+=8; 
        $session[user][drunkenness]=50; 
    } 
    else { 
        output("`2Du nimmst Dir die `3Karaffe mit Wein`2 vom Tisch und f�llst Dein Glas. 
        W�hrend Du es in einem Zug leerst, sp�rst Du etwas Schleimiges Deine Kehle hinunter 
        rinnen. Du f�hlst Dich krank.`n`n 
        `&Du verlierst einige Lebenspunkte.`0"); 
        if ( $session[user][hitpoints] > 8 ) { 
            $session[user][hitpoints]-= 8; 
        } 
        else { 
            $session[user][hitpoints]=1; 
        } 
        $session[user][drunkenness]=50; 
    } 
    $session[user][specialinc]=""; 
} 
else if ($_GET[op]=="dancer"){ 
    if (e_rand(0,1)==0) { 
        output("`2Du bemerkst ". 
        ($session[user][sex]?"einen wundersch�nen T�nzer, der " 
         :"eine wundersch�ne T�nzerin, die "). 
        "voller Anmut und Grazie um das Lagerfeuer tanzt. Du gehst hin�ber und schaust 
        mit Glanz in den Augen zu. Dein Interesse f�llt ". 
        ($session[user][sex]?"ihm ":"ihr ")."auf und ".($session[user][sex]?"er ":"sie "). 
        "schaut liebevoll zur�ck.`n`n 
        `&Du bekommst 2 Charmepunkte."); 
        $session[user][charm]+=2; 
    } 
    else { 
        output("`2Du bemerkst ". 
        ($session[user][sex]?"einen wundersch�nen T�nzer, der " 
         :"eine wundersch�ne T�nzerin, die "). 
        "voller Anmut und Grazie um das Lagerfeuer tanzt. Du gehst hin�ber, schaust 
        zu und kippst Deinen bitter schmeckenden Wein ins Lagerfeuer. Sofort sticht 
        eine hohe Flamme aus dem Lagerfeuer. ". 
        ($session[user][sex]?"Er ":"Sie ")."erschreckt sich und wirft Dir einen 
        `3`ib�sen Blick`2`i zu. 
        `&`n`n Du verlierst etwas an Charme!"); 
        $session[user][charm]-=2; 
    } 
    $session[user][specialinc]=""; 
} 
else if ($_GET[op]=="vlad") { 
    if (e_rand(0,1)==0) { 
        output("`3Vlad`2 begehrt das Halstuch, dass du tr�gst. Er bietet Dir 
        `^200 Gold `2daf�r an. 
        `nDa das Halstuch eh alt ist, nimmst Du sein Angebot an!`n`n 
        `&Du hast Dein Halstuch f�r `^200 Gold `&verkauft."); 
        $session[user][gold]+=200; 
    } 
    else { 
        output("`3Vlad`2 begehrt das Halstuch, dass du tr�gst. Er bietet Dir 
        `^200 Gold `2daf�r an. 
        `nDa das Halstuch eh alt ist, nimmst Du sein Angebot an!`n`n
        W�hrend Du das Halstuch ablegst, ger�tst Du ins Straucheln und trittst 
        aus Versehen ins Lagerfeuer.`n`n 
        `&Du verletzt Dich leicht und verlierst einige Lebenspunkte."); 
        if ( $session[user][hitpoints] > 8 ) { 
            $session[user][hitpoints]-= 8; 
        } 
        else { 
            $session[user][hitpoints]=1; 
        } 
    } 
    $session[user][specialinc]=""; 
} 
else if ($_GET[op]=="myra") { 
    if (e_rand(0,1)==0){ 
        output("`3Myra `2bietet Dir ein hei�es Bad an. Nachdem Du schon eine Weile 
        im Wald warst, kannst du ein Bad gut gebrauchen und nimmst ihr Angebot an.`n`n 
        Nach dem Bad in einem Holzzuber f�hlst Du Dich erfrischt.`n`n 
        `&Du bekommst 5 Lebenspunkte."); 
        $session[user][hitpoints]+=50; 
    } 
    else { 
        output("`3Myra `2bietet Dir ein hei�es Bad an. Nachdem Du schon eine Weile 
        im Wald warst, kannst du ein Bad gut gebrauchen und nimmst ihr Angebot an.`n`n 
        Als Du nach dem Bad aus dem Holzzuber steigst, rutscht Du aus und f�llst 
        schmerzhaft auf Deinen Hintern.`n`n 
        `&Du verlierst ein paar Lebenspunkte."); 
        if ( $session[user][hitpoints] > 50 ) { 
            $session[user][hitpoints]-= 50; 
        } 
        else { 
            $session[user][hitpoints]=1; 
        } 
    } 
    $session[user][specialinc]=""; 
} 
else if ($_GET[op]=="blind"){ 
    if (e_rand(0,1)==0){ 
          output("`3Ein blinder Zigeuner `2am Tisch bietet Dir die Kraft des Schicksals 
          an, wenn er Dein Gesicht ber�hren darf. Du siehst darin keine Gefahr und 
          n�herst Dich noch ein St�ck, so dass er Dich ber�hren kann.`n`n 
          Er f�hrt mit seinen alten, knochigen H�nden durch Dein Gesicht und sagt: 
          \"`3Du bist ein Gl�ckskind!`2\"`n`n
          `&Etwas Mystisches geht in Dir vor und pl�tzlich bist Du mit frischer Kraft 
          gesegnet!`0"); 
          if ($session['user']['hitpoints']<$session['user']['maxhitpoints']) 
             $session[user][hitpoints]=$session[user][maxhitpoints]; 
          $session[user][turns]+=10; 
          $session[user][drunkenness]-=20; 
          $session['user']['usedouthouse'] = 0; 
          $session['user']['seenmaster'] = 0; 
          $session['user']['seenlover'] = 0; 
          $session['user']['seenbard'] = 0; 
    } 
    else { 
          output("`3Ein blinder Zigeuner `2am Tisch bietet Dir die Kraft des Schicksals 
          an, wenn er Dein Gesicht ber�hren darf. Du siehst darin keine Gefahr und 
          n�herst Dich noch ein St�ck, so dass er Dich ber�hren kann.`n`n 
          Er f�hrt mit seinen alten, knochigen H�nden durch Dein Gesicht und sagt: 
          \"`3Du hast einen schlechten Tag!`2\"`n`n
          `&Etwas Mystisches geht in Dir vor und pl�tzlich f�hlst Du Dich m�de und 
          ausgelaugt!`n`n`^DU wirst heute etwas k�rzer treten m�ssen!`0"); 
          $session[user][hitpoints]=1; 
	  $session[user][turns]-=10;
          $session[user][drunkenness]+=20; 
          $session['user']['usedouthouse'] = 1; 
          $session['user']['seenmaster'] = 1; 
          $session['user']['seenlover'] = 1; 
          $session['user']['seenbard'] = 1; 
    } 
    $session[user][specialinc]=""; 
} 
else if ($_GET[op]=="fly") { 
    if (e_rand(0,1)==0){ 
        output("`2Du beugst Dich �ber den Tisch und siehst eine Ampulle mit \"Spanischer 
        Best Lik�r\". Du schaust Dich um und als Du Dich kurz unbeobachtet f�hlst, trinkst Du 
        hastig die Ampulle leer.`n`n 
        Als Du die Ampulle wieder weglegst, schaust Du nochmal auf das Etikett. Verdammt!`n 
        Da steht `b Spanischer Pest Lik�r `bnicht `i Best`i. Du erkrankst und kannst nicht 
        mehr so gut k�mpfen.`0"); 
        if ( $session[user][hitpoints] > 5 ) { 
            $session[user][hitpoints]-= 5; 
        } 
        else { 
            $session[user][hitpoints]=1; 
        } 
        $session[bufflist]['gypsycamp'] = array("name"=>"`4Spanische Pest", 
                                        "rounds"=>35, 
                                        "wearoff"=>"Du f�hlst Dich besser.", 
                                        "defmod"=>0.7, 
                                        "atkmod"=>0.7, 
                                        "roundmsg"=>"Die Pest schw�cht Dich.", 
                                        "activate"=>"defense"); 
    } 
    else { 
        output("`2Du beugst Dich �ber den Tisch und siehst eine Ampulle mit \"Spanischer 
        Best Lik�r\". Du schaust Dich um und als Du Dich kurz unbeobachtet f�hlst, trinkst Du 
        hastig die Ampulle leer.`n 
        Sofort f�hlt Du Dich viel st�rker. Ein Teufelszeug!`0"); 
        $session[user][hitpoints] += 5; 
        $session[bufflist]['gypsycamp'] = array("name"=>"`#Spanischer Lik�r", 
                                        "rounds"=>35, 
                                        "wearoff"=>"Deine Kr�fte schwinden.", 
                                        "defmod"=>1.3, 
                                        "atkmod"=>1.3, 
                                        "roundmsg"=>"Deine Kr�fte sind belebt.", 
                                        "activate"=>"defense"); 
    } 
    $session[user][specialinc]=""; 
} 
else if ($_GET[op]=="leave"){ 
    output("`n`2Die Zigeuner kommen Dir spanisch vor, Du verl�sst das Lager schnellstens und setzt Deinen Weg im Wald fort."); 
    $session[user][specialinc]=""; 
}
if ($session[user][turns] < 0)  {$session[user][turns] = 0;}
?>