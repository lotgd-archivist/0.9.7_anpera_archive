<?

// Code by Draza�ar - http://logd.legend-of-vinestra.de - drazaar@legend-of-vinestra.de
// Idee first seen @ Anpera Board by Ray

require_once 'common.php';
page_header('Der Rassenpavillon');
addcommentary();
checkday();

$u = &$session['user'];
$races = array(1=>"`2Trolle`0"          # Falls n�tig erweitern!
              ,2=>"`^Elfen`0"
              ,3=>"`&Menschen`0"
              ,4=>"`#Zwerge`0"
              ,5=>"`5Echsen`0");

switch($_GET['op']){
    case 'pavillion':
        if($_GET['race']==$u['race'] || $u['superuser']>=1){         # Ggf. Superusergrad ver�ndern!
                $out .= '`bDer Pavillon der '.$race[$_GET['race']].'`b`n`n';
                $out .= '--Beschreibung--';
                output($out);
                viewcommentary('rassenpav_'.$_GET['race'],'Hinzuf�gen',20);
                addnav('Umkehren');
                addnav('Zur�ck','rassenpav.php');
        }else{
                output('Wie kommst du �berhaupt hier rein? Du wei�t, dass du hier nicht reingeh�rst!');
                addnav('Umkehren');
                addnav('Zur�ck','rassenpav.php');
        }
    break;
    default:
        output('--Beschreibung--`n`n');         # �NDERN!
        if($u['superuser']>=1){
                addnav('Rassenpavillons');
                for($i=1;$i<=count($races);$i++){
                    addnav('Pavillon der '.$races[$i],'rassenpav.php?op=pavillon&race='.$i);
                }
        }else{
                addnav('Auswahl');
                addnav('Pavillon der '.$races[$u['race']],'rassenpav.php?op=pavillon&race='.$u['race']);
        }        
        addnav('Umkehren');
        addnav('Zur�ck in den Garten','gardens.php');
}
page_footer();
?>