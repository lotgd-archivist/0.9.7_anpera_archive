<?php
/*_________________________________________________________
  |Juwelier von Eliwood.                                  |
  |Hier kann man Rubine, Saphire von Smargde verkaufen,   |
  |Rohdiamanten schleifen lassen.                         |
  |Es dient dazu, Edelsteine wieder seltener zu machen    |
  |Deshalb hab ich den Wald modifiziert, d.h.             |
  |Im Wald kann man nun anstatt Gems Rohdiamanten finden.|
  |_______________________________________________________|
  SQL:
  ALTER TABLE `accounts` ADD `rubi` INT( 10 ) UNSIGNED NOT NULL ; 
  ALTER TABLE `accounts` ADD `saphi` INT( 10 ) UNSIGNED NOT NULL ; 
  ALTER TABLE `accounts` ADD `smaragd` INT( 10 ) UNSIGNED NOT NULL ; 
  ALTER TABLE `accounts` ADD `rohdiamant` INT( 10 ) UNSIGNED NOT NULL ; 
  ______________________________________________________________________
  Nun nur noch den Juwelier im Dorf verlinken, schon kann er verwendet werden
*/
/*UPDATE:
  Version 1.3 Letzte Fehler behoben, sollte nun Buglos laufen
*/


require_once "common.php";
page_header("Der Juwelier");
output("`c`b`tDer Juwelier`b`c`0`n`n");
$juw = "Harken";
$rubicost=5000;
$smaragdcost=7500;
$saphicost=2500;
//output("Wegen Korruption geschlossen.`nDie Dorfverwaltung.");
//addnav("Zur�ck zum Dorf","village.php");

//Der Laden
if ($_GET[op]=="")
{
	output("Du betritts den Juwelier und siehst dich dich um. Du siehst verschiedene sch�ne Edelsteine");
	if ((($session[user][rubi]>=1)||($session[user][saphi]>=1)||($session[user][smaragd]>=1)))
	{
		output(" und du betrachtest dein kleiner Schatz.`n");
		output("Du siehst einen Schild, bei dem verschiedene Angebote sehen. Doch du bist dir nicht sicher, ob du dich von deinen");
		output("edlen Steine trennen willst, denn wer weiss, vielleicht kannst du die ja doch noch brauchen. $juw, der Juwelier  bietet dir f�r deine Rubine, Saphire und Smaragde je einen Edelsteine,");
		output("sofern du gewillt bist, ihn zu bezahlen, denn Edelsteine sind nicht billig.`n");
		output("Ebenfalls bietet er dir an, f�r 1000 Gold einer deiner Rohdiamanten zu schleifen, so dass dieser den vollen Wert eines Edelsteins haben wird.");
		addnav("Edelsteinhandel");
	}
	else
	{
		output(". Da du aber nicht im Besitz von solchen Steinen bist, solltest du schleunigst den Laden verlassen.`n");
	}
	if (($session[user][rubi]>=1) && ($session[user][gold]>=$rubicost))
	{
		addnav("Rubine verkaufen ($rubicost)","juwelier.php?op=rv");
	}
	if (($session[user][saphi]>=1) && ($session[user][gold]>=$saphicost))
	{
		addnav("Saphire verkaufen ($saphicost)","juwelier.php?op=sv");
	}
	if (($session[user][smaragd]>=1) && ($session[user][gold]>=$smaragdcost))
	{
		addnav("Smaragde verkaufen ($smaragdcost)","juwelier.php?op=smv");
	}
	if (($session[user][rohdiamant]>=1) && ($session[user][gold]>=1000))
	{
	addnav("Rohdiamant schleifen","juwelier.php?op=rdv");
	}
	addnav("Sonstiges");
	addnav("Verlasse den Juwelier","village.php");
}
//Rubine verkaufen
if ($_GET[op]=="rv")
{
	output("Du gibst $juw einen Rubin, den er sofort in ein schliessfach legt, dann gibt er dir den");
	output("versprochenen Edelstein.");
	$session[user][rubi]--;
	$session[user][gems]++;
	$session[user][gold]-=$rubicost;
	addnav("Edelsteinhandel");
	if (($session[user][rubi]>=1) && ($session[user][gold]>=$rubicost))
	{
		addnav("Rubine verkaufen ($rubicost)","juwelier.php?op=rv");
	}
	if (($session[user][saphi]>=1) && ($session[user][gold]>=$saphicost))
	{
		addnav("Saphire verkaufen ($saphicost)","juwelier.php?op=sv");
	}
	if (($session[user][smaragd]>=1) && ($session[user][gold]>=$smaragdcost))
	{
		addnav("Smaragde verkaufen ($smaragdcost)","juwelier.php?op=smv");
	}
	if (($session[user][rohdiamant]>=1) && ($session[user][gold]>=1000))
	{
	addnav("Rohdiamant schleifen","juwelier.php?op=rdv");
	}
	addnav("Sonstiges");
	addnav("Verlasse den Juwelier","village.php");
}
//Saphire verkaufen
if ($_GET[op]=="sv")
{
	output("Du gibst $juw einen Saphir, den er sofort in ein schliessfach legt, dann gibt er dir den");
	output("versprochenen Edelstein.");
	$session[user][saphi]--;
	$session[user][gems]++;
	$session[user][gold]-=$saphicost;
	addnav("Edelsteinhandel");
	if (($session[user][rubi]>=1) && ($session[user][gold]>=$rubicost))
	{
		addnav("Rubine verkaufen ($rubicost)","juwelier.php?op=rv");
	}
	if (($session[user][saphi]>=1) && ($session[user][gold]>=$saphicost))
	{
		addnav("Saphire verkaufen ($saphicost)","juwelier.php?op=sv");
	}
	if (($session[user][smaragd]>=1) && ($session[user][gold]>=$smaragdcost))
	{
		addnav("Smaragde verkaufen ($smaragdcost)","juwelier.php?op=smv");
	}
	if (($session[user][rohdiamant]>=1) && ($session[user][gold]>=1000))
	{
	addnav("Rohdiamant schleifen","juwelier.php?op=rdv");
	}
	addnav("Sonstiges");
	addnav("Verlasse den Juwelier","village.php");
}
//Smaragde verkaufen
if ($_GET[op]=="smv")
{
	output("Du gibst $juw einen Smaragd, den er sofort in ein schliessfach legt, dann gibt er dir den");
	output("versprochenen Edelstein.");
	$session[user][smaragd]--;
	$session[user][gems]++;
	$session[user][gold]-=$smaragdcost;
	addnav("Edelsteinhandel");
	if (($session[user][rubi]>=1) && ($session[user][gold]>=$rubicost))
	{
		addnav("Rubine verkaufen ($rubicost)","juwelier.php?op=rv");
	}
	if (($session[user][saphi]>=1) && ($session[user][gold]>=$saphicost))
	{
		addnav("Saphire verkaufen ($saphicost)","juwelier.php?op=sv");
	}
	if (($session[user][smaragd]>=1) && ($session[user][gold]>=$smaragdcost))
	{
		addnav("Smaragde verkaufen ($smaragdcost)","juwelier.php?op=smv");
	}
	if (($session[user][rohdiamant]>=1) && ($session[user][gold]>=1000))
	{
	addnav("Rohdiamant schleifen","juwelier.php?op=rdv");
	}
	addnav("Sonstiges");
	addnav("Verlasse den Juwelier","village.php");
}
//Rohdiamanten schleifen
if ($_GET[op]=="rdv")
{
	output("Du gibst $juw einen Rohdiamant sowie die 1000 Gold und er beginnt zu schleifen.");
	output("Nach einer Weile gibt er dir einen wundersch�nen Edelstein, den du sofort in ein S�kchen packst.");
	$session[user][rohdiamant]--;
	$session[user][gems]++;
	$session[user][gold]-=1000;
	addnav("Edelsteinhandel");
	if (($session[user][rubi]>=1) && ($session[user][gold]>=$rubicost))
	{
		addnav("Rubine verkaufen ($rubicost)","juwelier.php?op=rv");
	}
	if (($session[user][saphi]>=1) && ($session[user][gold]>=$saphicost))
	{
		addnav("Saphire verkaufen ($saphicost)","juwelier.php?op=sv");
	}
	if (($session[user][smaragd]>=1) && ($session[user][gold]>=$smaragdcost))
	{
		addnav("Smaragde verkaufen ($smaragdcost)","juwelier.php?op=smv");
	}
	if (($session[user][rohdiamant]>=1) && ($session[user][gold]>=1000))
	{
	addnav("Rohdiamant schleifen","juwelier.php?op=rdv");
	}
	addnav("Sonstiges");
	addnav("Verlasse den Juwelier","village.php");
}
//Script Ende
page_footer();
?>