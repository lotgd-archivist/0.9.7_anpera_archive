CREATE TABLE fast_nav (
   id INT( 11 ) unsigned NOT NULL auto_increment,
   link VARCHAR( 55 ) NOT NULL default '#',
   name VARCHAR( 100 ) NOT NULL,
   PRIMARY KEY (id)
) Type=MyISAM;

INSERT INTO fast_nav (id, link, name) VALUES (1, 'academy.php', 'Akademie');
INSERT INTO fast_nav (id, link, name) VALUES (2, 'armor.php', 'R�stungsladen');
INSERT INTO fast_nav (id, link, name) VALUES (3, 'armoreditor.php', 'Editor: R�stungen');
INSERT INTO fast_nav (id, link, name) VALUES (4, 'avatars.php', 'Editor: Avatare');
INSERT INTO fast_nav (id, link, name) VALUES (5, 'badword.php', 'BadWord-Editor');
INSERT INTO fast_nav (id, link, name) VALUES (6, 'bank.php', 'Die alte Bank');
INSERT INTO fast_nav (id, link, name) VALUES (7, 'battlearena.php', 'Die Arena');
INSERT INTO fast_nav (id, link, name) VALUES (8, 'beggar.php', 'Der Bettelstein');
INSERT INTO fast_nav (id, link, name) VALUES (9, 'bios.php', 'Editor: Biographien');
INSERT INTO fast_nav (id, link, name) VALUES (10, 'configuration.php', 'Spieleinstellungen');
INSERT INTO fast_nav (id, link, name) VALUES (11, 'creatures.php', 'Editor: Kreaturen');
INSERT INTO fast_nav (id, link, name) VALUES (12, 'dag.php', 'Dag Durnicks');
INSERT INTO fast_nav (id, link, name) VALUES (13, 'donators.php', 'Editor: Donation');
INSERT INTO fast_nav (id, link, name) VALUES (14, 'dragon.php', 'Der Drachen');
INSERT INTO fast_nav (id, link, name) VALUES (15, 'forest.php', 'Der Wald');
INSERT INTO fast_nav (id, link, name) VALUES (16, 'gardens.php', 'Die G�rten');
INSERT INTO fast_nav (id, link, name) VALUES (17, 'graveyard.php', '(R) Der Friedhof');
INSERT INTO fast_nav (id, link, name) VALUES (18, 'gypsy.php', 'Die Zigeunerin');
INSERT INTO fast_nav (id, link, name) VALUES (19, 'healer.php', 'Der Heiler');
INSERT INTO fast_nav (id, link, name) VALUES (20, 'hexe.php', 'Die Hexe');
INSERT INTO fast_nav (id, link, name) VALUES (21, 'hof.php', 'Die Ruhmeshalle');
INSERT INTO fast_nav (id, link, name) VALUES (22, 'houses.php', 'Das Wohnviertel');
INSERT INTO fast_nav (id, link, name) VALUES (23, 'inn.php', 'Die Schenke');
INSERT INTO fast_nav (id, link, name) VALUES (24, 'innboard.php', 'Editor: Schwarzes Brett');
INSERT INTO fast_nav (id, link, name) VALUES (25, 'invhandler.php', 'Das Inventar');
INSERT INTO fast_nav (id, link, name) VALUES (26, 'itemeditor.php', 'Editor: Items');
INSERT INTO fast_nav (id, link, name) VALUES (27, 'list.php', 'Die K�mpferliste');
INSERT INTO fast_nav (id, link, name) VALUES (28, 'lodge.php', 'Die J�gerh�tte');
INSERT INTO fast_nav (id, link, name) VALUES (29, 'logs.php', 'Editor: Logs & Mail');
INSERT INTO fast_nav (id, link, name) VALUES (30, 'lottery.php', 'Die Lottery');
INSERT INTO fast_nav (id, link, name) VALUES (31, 'mounts.php', 'Editor: Stalltiere');
INSERT INTO fast_nav (id, link, name) VALUES (32, 'newday.php', 'Neuer Tag');
INSERT INTO fast_nav (id, link, name) VALUES (33, 'newgiftshop.php', 'Der Geschenckeladen');
INSERT INTO fast_nav (id, link, name) VALUES (34, 'olddrawl.php', 'Old Drawls Tisch');
INSERT INTO fast_nav (id, link, name) VALUES (35, 'outhouse.php', 'Das Plumpsklo');
INSERT INTO fast_nav (id, link, name) VALUES (37, 'prefs.php', 'Dein Profil');
INSERT INTO fast_nav (id, link, name) VALUES (38, 'pvp.php', 'Die Felder');
INSERT INTO fast_nav (id, link, name) VALUES (39, 'pvparena.php', 'K�mpferarena');
INSERT INTO fast_nav (id, link, name) VALUES (40, 'rebirth.php' 'Schrein der Erneuerung');
INSERT INTO fast_nav (id, link, name) VALUES (41, 'referers.php', 'Referers');
INSERT INTO fast_nav (id, link, name) VALUES (42, 'referral.php', 'Empfehlungen');
INSERT INTO fast_nav (id, link, name) VALUES (43, 'retitle.php', 'Retitiler');
INSERT INTO fast_nav (id, link, name) VALUES (44, 'rock.php', 'Club der Veteranen');
INSERT INTO fast_nav (id, link, name) VALUES (45, 'shades.php', '(R) Die Schatten');
INSERT INTO fast_nav (id, link, name) VALUES (46, 'shrine.php', 'Schrein des Ramius');
INSERT INTO fast_nav (id, link, name) VALUES (47, 'stables.php', 'Merricks St�lle');
INSERT INTO fast_nav (id, link, name) VALUES (48, 'stats.php', 'Stats');
INSERT INTO fast_nav (id, link, name) VALUES (49, 'stonesgame.php', 'Steinchengl�ckspiel');
INSERT INTO fast_nav (id, link, name) VALUES (50, 'styx.php', '(R) Fluss der Seelen');
INSERT INTO fast_nav (id, link, name) VALUES (51, 'suhouses.php', 'Hausmeister');
INSERT INTO fast_nav (id, link, name) VALUES (52, 'superuser.php', 'Admin Grotte');
INSERT INTO fast_nav (id, link, name) VALUES (53, 'taunt.php', 'Editor: Spott');
INSERT INTO fast_nav (id, link, name) VALUES (54, 'train.php', 'Das Trainingslager');
INSERT INTO fast_nav (id, link, name) VALUES (55, 'user.php', 'Editor: User');
INSERT INTO fast_nav (id, link, name) VALUES (56, 'vendor.php', 'Der Wandlerh�ndler');
INSERT INTO fast_nav (id, link, name) VALUES (57, 'viewpetition.php', 'Editor: Anfragen');
INSERT INTO fast_nav (id, link, name) VALUES (58, 'village.php', 'Der Stadtplatz');
INSERT INTO fast_nav (id, link, name) VALUES (59, 'weaponeditor.php', 'Editor: Waffen');
INSERT INTO fast_nav (id, link, name) VALUES (60, 'weapons.php', 'Waffenladen');
INSERT INTO fast_nav (id, link, name) VALUES (61, 'well.php', 'Der Dorfbrunnen');