<?php

##
 #
 # Fast-Nav Editor by MySQL!
 # Idea by MySQL!
 # Copyright by MySQL!
 # SQL - fast_nav.sql!
 #
##

Require_Once 'common.php';

Switch ($_GET['op']):

        case '':
            page_header ('Fast Nav-Editor');
                output('<table border=0 cellpadding=2 cellspacing=1 align="center" bgcolor="#999999">'.
                       '<tr class="trhead">'.
                       '<td>ID</td>'.
                       '<td>Name</td>'.
                       '<td>Link</td>'.
                       '<td>Edit</td>'.
                       '<td>Loeschen</td>'.
                       '</tr>',true);
                $sql = 'SELECT * FROM fast_nav ORDER BY name ASC';
                $sow = db_query($sql);

                     while ($row = db_fetch_assoc($sow))
                       {
                         output("<tr class='".($i%2?"trdark":"trlight")."'>".
                                "<td>{$row['id']}</td>".
                                "<td>{$row['name']}</td>".
                                "<td>{$row['link']}</td>".
                                "<td>[<a href=\"fast_nav.php?op=edit&nav={$row['id']}\">Edit</a>]</td>".
                                "<td>[<a href=\"fast_nav.php?op=dell&nav={$row['id']}\">Loeschen</a></td>",true);
                         addnav("","fast_nav.php?op=edit&nav={$row['id']}");
                         addnav("","fast_nav.php?op=dell&nav={$row['id']}");
                       }
                         addnav('Zum Weltlichen','village.php');
                         addnav('Admin Grotte','superuser.php');
                         addnav('Nav hinzuf�gen','fast_nav.php?op=add');


        break;
        case 'dell':
            page_header('Nav loeschen');
                $sql = "SELECT * FROM fast_nav WHERE id='$_GET[nav]'";
                $sow = db_query($sql);
                $row = db_fetch_assoc($sow);

                output("Du hast die [ID {$row[id]}] geloescht.");
                addnav('Fast Nav\'s auflisten','fast_nav.php');

                $lqs = "DELETE FROM fast_nav WHERE id='$_GET[nav]'";
                db_query($lqs);
       break;
       case 'edit':
           page_header ('Nav Editieren');
               $sql = "SELECT * FROM fast_nav WHERE id='$_GET[nav]'";
               $sow = db_query($sql);
               $row = db_fetch_assoc($sow);

               output("<form action='fast_nav.php?op=update&nav={$row['id']}' method='post'>".
                      "<input name='name' value='".$row[name]."'>Name..<br>".
                      "<input name='link' value='".$row[link]."'>Link..<br>".
                      "<input type='submit' class='button' value='Nav editieren'>".
                      "<input type='reset' class='button' value='Eingaben zurueck setzten'>".
                      "</form>",true);
               addnav('Abbrechen','fast_nav.php');
               addnav("","fast_nav.php?op=update&nav={$row['id']}");
       break;
       case 'update':
           page_header ('Nav editiert');
               $lqs = "UPDATE fast_nav SET name='".$_POST[name]."',
                                           link='".$_POST[link]."'
                                     WHERE id='$_GET[nav]'";
               db_query($lqs);
               addnav('Navs auslisten','fast_nav.php');
               output('Nav editiert.');
       break;
       case 'add':
           page_header ('Nav erstellen');
               output("<form action='fast_nav.php?op=save' method='post'>".
                      "<input name='name'>Name..<br>".
                      "<input name='link'>Link..<br>".
                      "<input type='submit' class='button' value='Nav erstellen'>".
                      "<input type='reset' class='button' value='Eingaben zurueck setzten'>".
                      "</form>",true);
               addnav('Abbrechen','fast_nav.php');
               addnav('','fast_nav.php?op=save');
       break;
       case 'save':
           page_header ('Nav gespeichert');
               $sql = "INSERT INTO fast_nav (id, name, link) VALUES ('','".$_POST[name]."','".$_POST[link]."')";
               db_query($sql);
               output('Nav gespeichert.');
               addnav('Nav\'s auslisten','fast_nav.php');
       break;
       
Endswitch;

Page_Footer();

?>