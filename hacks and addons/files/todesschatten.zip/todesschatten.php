<?php
//erstellt wurde dieses Script von Garlant
// Support bekommt ihr bei Anpera.net und bei garlant@timeofmagic.de
// ich gebe keine Garnatie auf funktionalit�t dieses Events.
// Dieses Event geh�rt in den Ordner "Specials" bei LogD

$session['user']['specialinc'] = "todesschatten.php";
if ($_GET['op']=="" || $_GET['op']=="search"){
output("`n`b Die Toten Schatten`b");
output("`n`n Voller Kampfbegier bist du durch den Wald gest�rzt um wieder einmal den Wald von diesen Kreaturen zu bereinigen.
Als du kurz stehen bleibst, bemerkst du ein au�ergew�hnliches Monster. `@\"So eines fehlt mir noch in meiner Sammlung!\"`0
Meinst du und st�rmst sofort los. Als diese Kreatur dies bemerkt, beginnt sie zu fliehen und du rennst ohne auf den Weg zu achten hinterher.`n");
output("Diese Kreatur ist dir entkommen und du wei�t nicht was dies f�r ein Ort ist. Alles ist dunkel, auch die Pflanzen und Tiere in diesem Waldst�ck.
Ein St�ck weiter weg von dir, bemerkst du einige aufragenden Steine, die jedoch schon teilweise �berwuchert sind.");
output("`n`b Was wirst du machen?`b`n");
addnav("Die Steine Untersuchen","forest.php?op=ansehen");
addnav("Weiter ziehen","forest.php?op=weggehen");
}
if ($_GET['op']=="ansehen"){
switch(e_rand(1,5)){
case 1: //Trolle
  if ($session['user']['race'] != 1){
      switch(e_rand(1,12)){
      case 1:case 2: case 3: case 4:
      output("`nDu hast kein gutes Gef�hl bei der Sache, denn du hast schon einmal davon geh�rt das es in den W�ldern auch Friedh�fe der Trolle geben soll.
      `^Du �berwindest deine Neugier und kehrst lieber schnell wieder um.`n`4Du verlierst einen Waldkampf, da du den Weg zur�ck suchen must!`0");
      $session['user']['turns']--;
      $session['user']['specialinc'] = "";
      break;
      case 5:case 6: case 7: case 8:
      output("`n Vorsichtig n�herst du dich diesem Steinen. Als du vor diesen stehst, entdeckst du eine Inschrift �ber die du mit deinen H�nden f�hrst.
      Ganz pl�tzlich f�llst du um.`n `$ Du wurdest f�r das betreten des Friedhofes der Trolle niedergeschmettert.`nDu wei�t nun was dieser Ort ist
      und wirst das n�chste mal sicherlich vorsichtiger sein.`n Du verlierst zum Gl�ck nur dein Leben und kannst morgen weiterspielen!`0");
      $session['user']['hitpoints'] = 0;
      addnav("Zu den Schatten","shades.php");
		  addnav("Zu den News","news.php");
      addnews($session[user][name]." `0starb in einer dunklen Ecke im Wald.");
      $session['user']['specialinc'] = "";
      break;
      case 9:case 10: case 11: case 12:
      Output("Hastig l�ufst du zu den Steinen hin. Pl�tzlich trifft dich ein Blitz und du wirst kurzzeitig bewusstlos .In einen Traum siehst
      du unter diesen Steinen die Gebeine von einigen Trollen");
      $lvl = $session[user][level];
		    $hurt = e_rand(5*$lvl,10*$lvl);
		    $session[user][hitpoints]-=$hurt;
		  output("`n`n`^Du verlierst $hurt Lebenspunkte!`n Du wei�t nun das dies ein Friedhof der Trolle ist.`0`n");
		  $session['user']['specialinc'] = "";
		  if ($session[user][hitpoints]<=0) {
      addnav("Zu den Schatten","shades.php");
		  addnav("Zu den News","news.php");
      addnews($session[user][name]." `0starb in einer dunklen Ecke im Wald.");
      $session['user']['specialinc'] = "";
      }
      break;
      }
  } else {
output("Dir ist bekannt, dass es ein Friedhof deiner Rasse, der Trolle ist. Seit Jahrhunderten m�ssen hier nun schon die Gebeine von
Generationen vor dir ruhen. Ehrw�rdig, gehst du zu den heiligen Gedenksteinen, welche hier ebenfalls seit Generationen vor dir ruhen und kniest nieder.");
    switch(e_rand(1,10)){
    case 1:case 2:
    output("`n`^Als du wieder aufstehst bemerkst du, dass du nun ein paar Edelsteine mehr mitf�hrst.`0");
    $session['user']['gems']+=2;
    $session['user']['specialinc'] = "";
    break;
    case 3:case 4:case 5:case 6:
    output("`n`^ Als du wieder aufstehst f�hlst du dich wieder frisch. Du wurdest vollst�ndig geheilt.`0");
    $session['user']['hitpoints'] = $session['user']['maxhitpoints'];
    $session['user']['specialinc'] = "";
    break;
    case 7: case 8:
    output("`n`^ Als du wieder aufstehst f�hlst du dich um einiges sch�ner, als vorher.`0");
    $session['user']['charm']++;
    $session['user']['specialinc'] = "";
    break;
    case 9:
    output("`n`^Kurz nachdem du aufgestanden bist, f�hlst du dich st�rker.`0");
    $session['user']['attack']++;
    $session['user']['specialinc'] = "";
    break;
    case 10:
    output("`n`^ Nachdem du aufgestanden bist glaubst du, dass dich nun keiner mehr besiegen kann.`0");
    $session['user']['defence']++;
    $session['user']['specialinc'] = "";
    break;
    }
}
break;
case 2: //Elfen
  if ($session['user']['race'] != 2){
      switch(e_rand(1,12)){
      case 1:case 2: case 3: case 4:
      output("`nDu hast kein gutes Gef�hl bei der Sache, denn du hast schon einmal davon geh�rt das es in den W�ldern auch Friedh�fe der Elfen geben soll.
      `^Du �berwindest deine Neugier und kehrst lieber schnell wieder um.`n`4Du verlierst einen Waldkampf, da du den Weg zur�ck suchen must!`0");
      $session['user']['turns']--;
      $session['user']['specialinc'] = "";
      break;
      case 5:case 6: case 7: case 8:
      output("`n Vorsichtig n�herst du dich diesem Steinen. Als du vor diesen stehst, entdeckst du eine Inschrift �ber die du mit deinen H�nden f�hrst.
      Ganz pl�tzlich f�llst du um.`n `$ Du wurdest f�r das betreten des Friedhofes der Elfen niedergeschmettert.`nDu wei�t nun was dieser Ort ist
      und wirst das n�chste mal sicherlich vorsichtiger sein.`n Du verlierst zum Gl�ck nur dein Leben und kannst morgen weiterspielen!`0");
      $session['user']['hitpoints'] = 0;
      addnav("Zu den Schatten","shades.php");
		  addnav("Zu den News","news.php");
      addnews($session[user][name]." `0starb in einer dunklen Ecke im Wald.");
      $session['user']['specialinc'] = "";
      break;
      case 9:case 10: case 11: case 12:
      Output("Hastig l�ufst du zu den Steinen hin. Pl�tzlich trifft dich ein Blitz und du wirst kurzzeitig bewusstlos .In einen Traum siehst
      du unter diesen Steinen die Gebeine von einigen Elfen");
      $lvl = $session[user][level];
		    $hurt = e_rand(5*$lvl,10*$lvl);
		    $session[user][hitpoints]-=$hurt;
		  output("`n`n`^Du verlierst $hurt Lebenspunkte!`n Du wei�t nun das dies ein Freidhof der Elfen ist.`0`n");
		  $session['user']['specialinc'] = "";
		  if ($session[user][hitpoints]<=0) {
      addnav("Zu den Schatten","shades.php");
		  addnav("Zu den News","news.php");
      addnews($session[user][name]." `0starb in einer dunklen Ecke im Wald.");
      $session['user']['specialinc'] = "";
      }
      break;
      }
  } else {
output("Dir ist bekannt, dass es ein Friedhof deiner Rasse, der Elfen ist. Seit Jahrhunderten m�ssen hier nun schon die Gebeine von
Generationen vor dir ruhen. Ehrw�rdig, gehst du zu den heiligen Gedenksteinen, welche hier ebenfalls seit Generationen vor dir ruhen und kniest nieder.");
    switch(e_rand(1,10)){
    case 1:case 2:
    output("`n`^Als du wieder aufstehst bemerkst du, dass du nun ein paar Edelsteine mehr mitf�hrst.`0");
    $session['user']['gems']+=2;
    $session['user']['specialinc'] = "";
    break;
    case 3:case 4:case 5:case 6:
    output("`n`^ Als du wieder aufstehst f�hlst du dich wieder frisch. Du wurdest vollst�ndig geheilt.`0");
    $session['user']['hitpoints'] = $session['user']['maxhitpoints'];
    $session['user']['specialinc'] = "";
    break;
    case 7: case 8:
    output("`n`^ Als du wieder aufstehst f�hlst du dich um einiges sch�ner, als vorher.`0");
    $session['user']['charm']++;
    $session['user']['specialinc'] = "";
    break;
    case 9:
    output("`n`^Kurz nachdem du aufgestanden bist, f�hlst du dich st�rker.`0");
    $session['user']['attack']++;
    $session['user']['specialinc'] = "";
    break;
    case 10:
    output("`n`^ Nachdem du aufgestanden bist glaubst du, dass dich nun keiner mehr besiegen kann.`0");
    $session['user']['defence']++;
    $session['user']['specialinc'] = "";
    break;
    }
}
break;
case 3: //Menschen
  if ($session['user']['race'] != 3){
      switch(e_rand(1,12)){
      case 1:case 2: case 3: case 4:
      output("`nDu hast kein gutes Gef�hl bei der Sache, denn du hast schon einmal davon geh�rt das es in den W�ldern auch Friedh�fe der Menschen geben soll.
      `^Du �berwindest deine Neugier und kehrst lieber schnell wieder um.`n`4Du verlierst einen Waldkampf, da du den Weg zur�ck suchen must!`0");
      $session['user']['turns']--;
      $session['user']['specialinc'] = "";
      break;
      case 5:case 6: case 7: case 8:
      output("`n Vorsichtig n�herst du dich diesem Steinen. Als du vor diesen stehst, entdeckst du eine Inschrift �ber die du mit deinen H�nden f�hrst.
      Ganz pl�tzlich f�llst du um.`n `$ Du wurdest f�r das betreten des Friedhofes der Menschen niedergeschmettert.`nDu wei�t nun was dieser Ort ist
      und wirst das n�chste mal sicherlich vorsichtiger sein.`n Du verlierst zum Gl�ck nur dein Leben und kannst morgen weiterspielen!`0");
      $session['user']['hitpoints'] = 0;
      addnav("Zu den Schatten","shades.php");
		  addnav("Zu den News","news.php");
      addnews($session[user][name]." `0starb in einer dunklen Ecke im Wald.");
      $session['user']['specialinc'] = "";
      break;
      case 9:case 10: case 11: case 12:
      Output("Hastig l�ufst du zu den Steinen hin. Pl�tzlich trifft dich ein Blitz und du wirst kurzzeitig bewustlos. In einen Traum siehst
      du unter diesen Steinen die Gebeine von einigen Menschen");
      $lvl = $session[user][level];
		    $hurt = e_rand(5*$lvl,10*$lvl);
		    $session[user][hitpoints]-=$hurt;
		  output("`n`n`^Du verlierst $hurt Lebenspunkte!`n Du wei�t nun das dies ein Friedhof der Menschen ist.`0`n");
		  $session['user']['specialinc'] = "";
		  if ($session[user][hitpoints]<=0) {
      addnav("Zu den Schatten","shades.php");
		  addnav("Zu den News","news.php");
      addnews($session[user][name]." `0starb in einer dunklen Ecke im Wald.");
      $session['user']['specialinc'] = "";
      }
      break;
      }
  } else {
output("Dir ist bekannt, dass es ein Friedhof deiner Rasse, der Menschen ist. Seit Jahrhunderten m�ssen hier nun schon die Gebeine von
Gernerationen vor dir ruhen. Ehrw�rdig, gehst du zu den heiligen Gedenksteinen, welche hier ebenfals seit Generationen vor dir ruhen und kniest nieder.");
    switch(e_rand(1,10)){
    case 1:case 2:
    output("`n`^Als du wieder aufstehst bemerkst du, dass du nun ein paar Edelsteine mehr mitf�hrst.`0");
    $session['user']['gems']+=2;
    $session['user']['specialinc'] = "";
    break;
    case 3:case 4:case 5:case 6:
    output("`n`^ Als du wieder aufstehst f�hlst du dich wieder frisch. Du wurdest vollst�ndig geheilt.`0");
    $session['user']['hitpoints'] = $session['user']['maxhitpoints'];
    $session['user']['specialinc'] = "";
    break;
    case 7: case 8:
    output("`n`^ Als du wieder aufstehst f�hlst du dich um einiges sch�ner, als vorher.`0");
    $session['user']['charm']++;
    $session['user']['specialinc'] = "";
    break;
    case 9:
    output("`n`^Kurz nachdem du aufgestanden bist, f�hlst du dich st�rker.`0");
    $session['user']['attack']++;
    $session['user']['specialinc'] = "";
    break;
    case 10:
    output("`n`^ Nachdem du aufgestanden bist glaubst du, dass dich nun keiner mehr besiegen kann.`0");
    $session['user']['defence']++;
    $session['user']['specialinc'] = "";
    break;
    }
}
break;
case 4: //Zwerge
  if ($session['user']['race'] != 4){
      switch(e_rand(1,12)){
      case 1:case 2: case 3: case 4:
      output("`nDu hast kein gutes Gef�hl bei der Sache, denn du hast schon einmal davon geh�rt das es in den W�ldern auch Friedh�fe der Zwerge geben soll.
      `^Du �berwindest deine Neugier und kehrst lieber schnell wieder um.`n`4Du verlierst einen Waldkampf, da du den Weg zur�ck suchen must!`0");
      $session['user']['turns']--;
      $session['user']['specialinc'] = "";
      break;
      case 5:case 6: case 7: case 8:
      output("`n Vorsichtig n�herst du dich diesen Steinen. Als du vor diesen stehst, entdeckst du eine Inschrift �ber die du mit deinen H�nden f�hrst.
      Ganz pl�tzlich f�llst du um.`n `$ Du wurdest f�r das betreten des Friedhofes der Zwerge niedergeschmettert.`nDu wei�t nun was dieser Ort ist
      und wirst das n�chste mal sicherlich vorsichtiger sein.`n Du verlierst zum Gl�ck nur dein Leben und kannst morgen weiterspielen!`0");
      $session['user']['hitpoints'] = 0;
      addnav("Zu den Schatten","shades.php");
		  addnav("Zu den News","news.php");
      addnews($session[user][name]." `0starb in einer dunklen Ecke im Wald.");
      $session['user']['specialinc'] = "";
      break;
      case 9:case 10: case 11: case 12:
      Output("Hastig l�ufst du zu den Steinen hin. Pl�tzlich trifft dich ein Blitz und du wirst kurzzeitig bewusstlos. In einen Traum siehst
      du unter diesen Steinen die Gebeine von einigen Zwergen");
      $lvl = $session[user][level];
		    $hurt = e_rand(5*$lvl,10*$lvl);
		    $session[user][hitpoints]-=$hurt;
		  output("`n`n`^Du verlierst $hurt Lebenspunkte!`n Du wei�t nun das dies ein Friedhof der Zwerge ist.`0`n");
		  $session['user']['specialinc'] = "";
		  if ($session[user][hitpoints]<=0) {
      addnav("Zu den Schatten","shades.php");
		  addnav("Zu den News","news.php");
      addnews($session[user][name]." `0starb in einer dunklen Ecke im Wald.");
      $session['user']['specialinc'] = "";
      }
      break;
      }
  } else {
output("Dir ist bekannt, dass es ein Friedhof deiner Rasse, den Zwergen ist. Seit Jahrhunderten m�ssen hier nun schon die Gebeine von
Generationen vor dir ruhen. Ehrw�rdig, gehst du zu den heiligen Gedenksteinen, welche hier ebenfalls seit Generationen vor dir ruhen und kniest nieder.");
    switch(e_rand(1,10)){
    case 1:case 2:
    output("`n`^Als du wieder aufstehst bemerkst du, dass du nun ein paar Edelsteine mehr mitf�hrst.`0");
    $session['user']['gems']+=2;
    $session['user']['specialinc'] = "";
    break;
    case 3:case 4:case 5:case 6:
    output("`n`^ Als du wieder aufstehst f�hlst du dich wieder frisch. Du wurdest vollst�ndig geheilt.`0");
    $session['user']['hitpoints'] = $session['user']['maxhitpoints'];
    $session['user']['specialinc'] = "";
    break;
    case 7: case 8:
    output("`n`^ Als du wieder aufstehst f�hlst du dich um einiges sch�ner, als vorher.`0");
    $session['user']['charm']++;
    $session['user']['specialinc'] = "";
    break;
    case 9:
    output("`n`^Kurz nachdem du aufgestanden bist, f�hlst du dich st�rker.`0");
    $session['user']['attack']++;
    $session['user']['specialinc'] = "";
    break;
    case 10:
    output("`n`^ Nachdem du aufgestanden bist glaubst du, dass dich nun keiner mehr besiegen kann.`0");
    $session['user']['defence']++;
    $session['user']['specialinc'] = "";
    break;
    }
}
break;
case 5: //Echse
  if ($session['user']['race'] != 5){
      switch(e_rand(1,12)){
      case 1:case 2: case 3: case 4:
      output("`nDu hast kein gutes Gef�hl bei der Sache, denn du hast schon einmal davon geh�rt das es in den W�ldern auch Friedh�fe der Echsen geben soll.
      `^Du �berwindest deine Neugier und kehrst lieber schnell wieder um.`n`4Du verlierst einen Waldkampf, da du den Weg zur�ck suchen musst!`0");
      $session['user']['turns']--;
      $session['user']['specialinc'] = "";
      break;
      case 5:case 6: case 7: case 8:
      output("`n Vorsichtig n�herst du dich diesem Steinen. Als du vor diesen stehst, entdeckst du eine Inschrift �ber die du mit deinen H�nden f�hrst.
      Ganz pl�tzlich f�llst du um.`n `$ Du wurdest f�r das betreten des Friedhofes der Echsen niedergeschmettert.`nDu wei�t nun was dieser Ort ist
      und wirst dich das n�chste mal sicherlich vorsichtiger sein.`n Du verlierst zum Gl�ck nur dein Leben und kannst morgen weiterspielen!`0");
      $session['user']['hitpoints'] = 0;
      addnav("Zu den Schatten","shades.php");
		  addnav("Zu den News","news.php");
      addnews($session[user][name]." `0starb in einer dunklen Ecke im Wald.");
      $session['user']['specialinc'] = "";
      break;
      case 9:case 10: case 11: case 12:
      Output("Hastig l�ufst du zu den Steinen hin. Pl�tzlich trifft dich ein Blitz und du wirst kurzzeitig bewustlos. In einen Traum siehst
      du unter diesen Steinen die Gebeine von einigen Echsen");
      $lvl = $session[user][level];
		    $hurt = e_rand(5*$lvl,10*$lvl);
		    $session[user][hitpoints]-=$hurt;
		  output("`n`n`^Du verlierst $hurt Lebenspunkte!`n Du wei�t nun das dies ein Friedhof der Echsen ist.`0`n");
		  $session['user']['specialinc'] = "";
		  if ($session[user][hitpoints]<=0) {
      addnav("Zu den Schatten","shades.php");
		  addnav("Zu den News","news.php");
      addnews($session[user][name]." `0starb in einer dunklen Ecke im Wald.");
      $session['user']['specialinc'] = "";
      }
      break;
      }
  } else {
output("Dir ist bekannt, dass es ein Friedhof deiner Rasse, den Echsen ist. Seit Jahrhunderten m�ssen hier nun schon die Gebeine von
Generationen vor dir ruhen. Ehrw�rdig, gehst du zu den heiligen Gedenksteinen, welche hier ebenfalls seit Generationen vor dir ruhen und kniest nieder.");
    switch(e_rand(1,10)){
    case 1:case 2:
    output("`n`^Als du wieder aufstehst bemerkst du, dass du nun ein paar Edelsteine mehr mitf�hrst.`0");
    $session['user']['gems']+=2;
    $session['user']['specialinc'] = "";
    break;
    case 3:case 4:case 5:case 6:
    output("`n`^ Als du wieder aufstehst f�hlst du dich wieder frisch. Du wurdest vollst�ndig geheilt.`0");
    $session['user']['hitpoints'] = $session['user']['maxhitpoints'];
    $session['user']['specialinc'] = "";
    break;
    case 7: case 8:
    output("`n`^ Als du wieder aufstehst f�hlst du dich um einiges Sch�ner, als vorher.`0");
    $session['user']['charm']++;
    $session['user']['specialinc'] = "";
    break;
    case 9:
    output("`n`^Kurz nachdem du aufgestanden bist, f�hlst du dich st�rker.`0");
    $session['user']['attack']++;
    $session['user']['specialinc'] = "";
    break;
    case 10:
    output("`n`^ Nachdem du aufgestanden bist glaubst du, dass dich nun keiner mehr besiegen kann.`0");
    $session['user']['defence']++;
    $session['user']['specialinc'] = "";
    break;
        }
    }
  break;
  }
}
if ($_GET['op']=="weggehen"){
Output("`nDu ziehst weiter in den n�chsten Abschnitt des Waldes.");
$session['user']['specialinc'] = "";
}
?>
