<?
// Grundidee der Affenj�ger von logd.de
// Affenj�germodifikation � by Hecki f�r http://www.cop-logd.de
// Hexenj�ger und Diebesj�ger � by Hecki f�r http://www.cop-logd.de
// 27.02.05 - 02.03.05
// Special Modifikationen � by Hecki, danke an Alle Autoren der Original Specials :o)
require_once "common.php";
page_header("Die Diebesj�ger");
//hof function
$result = db_query($sql);
$row = db_fetch_assoc($result);
$totalplayers = $row['c'];

function display_table($title, $sql, $none=false, $foot=false, $data_header=false, $tag=false){
        global $session, $from, $to, $page;
        output("`c`b`^$title`0`b `7(Seite $page: $from-$to)`0`c`n");
        output('<table cellspacing="0" cellpadding="2" align="center"><tr class="trhead">',true);
        output("<td>`bRang`b</td><td>`bName`b</td>", true);
        if ($data_header !== false) {
                for ($i = 0; $i < count($data_header); $i++) {
                        output("<td>`b".$data_header[$i]."`b</td>", true);
                }
        }
        $result = db_query($sql) or die(db_error(LINK));
        if (db_num_rows($result)==0){
                $size = ($data_header === false) ? 2 : 2+count($data_header);
                //echo $size;
                if ($none === false) $none = "Keine Spieler gefunden";
                output('<tr class="trlight"><td colspan="'. $size .'" align="center">`&' . $none .'`0</td></tr>',true);
        } else {
                for ($i=0;$i<db_num_rows($result);$i++){
                        $row = db_fetch_assoc($result);
                        if ($row[name]==$session[user][name]){
                                //output("<tr class='hilight'>",true);
                                output("<tr bgcolor='#005500'>",true);
                        } else {
                                output('<tr class="'.($i%2?"trlight":"trdark").'">',true);
                        }
                        output("<td>".($i+$from).".</td><td>`&{$row[name]}`0</td>",true);
                        if ($data_header !== false) {
                                for ($j = 0; $j < count($data_header); $j++) {
                                        $id = "data" . ($j+1);
                                        $val = $row[$id];
                                        if ($tag !== false) $val = $val . " " . $tag[$j];
                                        output("<td align='right'>$val</td>",true);
                                }
                        }
                        output("</tr>",true);
                }
        }
        output("</table>", true);
        if ($foot !== false) output("`n`c$foot`c");
}

$order = "DESC";
if ($_GET[subop] == "least") $order = "ASC";
$sexsel = "IF(sex,'<img src=\"images/female.gif\">&nbsp; &nbsp;','<img src=\"images/male.gif\">&nbsp; &nbsp;')";
$racesel = "CASE race WHEN 1 THEN '`2Troll`0' WHEN 2 THEN '`^Elf`0' WHEN 3 THEN '`&Mensch`0' WHEN 4 THEN '`#Zwerg`0' WHEN 5 THEN '`5Echse`0' WHEN 6 THEN '`3Druide`0' WHEN 7 THEN '`6Goblin`0' WHEN 8 THEN '`4Orc`0' WHEN 9 THEN '`#Vampir`0' WHEN 10 THEN '`4Dieb`0'WHEN 11 THEN '`4D�mon`0' ELSE '`7Unbekannt`0' END";
//ENDE

if ($HTTP_GET_VARS[op] == ""){
if ($session['user']['diebe']==1 || $session['user']['superuser']>4){
   output("`\$Du betrittst das Haus der Diebesj�ger!`n`n");
   output("`\$Da du bereits Mitglied bist kannst du dir deine bisherigen Erfolge hier anschaun:`n`n");
   output("`qDu hast bereits ".$session[user][diebespu]." Diebe erledigt!`n`n");
addcommentary();
                viewcommentary("diebe","Gru� an die Diebesj�ger",15,"sagt",true);
addnav("Zur�ck zur Gildengasse","gildengasse.php");
addnav("`\$Gildenrangliste", "diebe.php?op=diebe&subop=$subop&page=$page");
addnav("Austreten","diebe.php?op=austritt1");
}else if ($session['user']['hexe']==1 || $session['user']['affe']==1){
      output("`\$Du kannst leider nur einer Gilde zur selben Zeit angeh�ren, komm wieder wenn du bei deiner Gilde ausgetreten bist.");
addnav("Zur�ck zur Gildengasse","gildengasse.php");
}else{
      output("`\$Du betrittst das Haus der Diebesj�ger!`n`n");
      output("`\$Hier kannst du Mitglied werden und auf Diebesjagt gehen, wenn dir einer im Wald �ber den Weg l�uft.`n Die Anmeldegeb�hr betr�gt einmalig `^20.000 Gold`\$`n");
addnav("Beitreten","diebe.php?op=beitritt");
addnav("Zur�ck zur Gildengasse","gildengasse.php");
}
//GILDENRANGLISTE
} elseif ($_GET[op]=="diebe"){
        $sql = "SELECT name,diebespu AS data1,$racesel AS data2 FROM accounts WHERE locked=0 AND diebe>0 ORDER BY data1 $order, level $order, experience $order";
        $title = "Krieger mit Diebesj�gerPunkten.";
        $headers = array("DiebesPunkte");
        display_table($title, $sql, false, false, $headers, false);
        addnav("Zur�ck","diebe.php");   
//ENDE
}else if ($HTTP_GET_VARS[op] == "beitritt"){
    page_header("Diebesj�ger beitreten");
if ($session['user']['gold']>19999){
    $session['user']['gold'] -= 20000;
    $session['user']['diebe'] = 1;
    $session['user']['pics'] = 3;
     $session['user']['gilde'] = '`$ Diebesj�ger';
    output(" `n`n`2`b`cDu bist jetzt ein `\$DIEBESJ�GER!`c`n");
     output("`q Viel spass beim Jagen!");
    addnav("Zur�ck zur Gildengasse","gildengasse.php");
    addnav("Zu den Diebesj�ger","diebe.php");
    }else{
    output("`n`n`2Leider hast du nicht genug Gold dabei, komm doch sp�ter wieder vorbei!`n");
    output("`n`n");
    addnav("Zur�ck zur Gildengasse","gildengasse.php");
    }
}else if ($HTTP_GET_VARS[op] == "austritt1"){
    output("`\$Sicher das du aussteigen willst?!`n");
    addnav("Ja");
    addnav("Ja","diebe.php?op=austritt");
    addnav("Nein");
    addnav("Nein","diebe.php");

}else if ($HTTP_GET_VARS[op] == "austritt"){
    page_header("Diebesj�ger austreten");

    $session['user']['diebe'] = 0;
    $session['user']['pics'] = 0;
    $session['user']['gilde'] = 'Keine';
    output(" `n`n`2`b`cDu bist bei den `\$ DIEBESJ�GERN`2 ausgetreten!`c`n");
     output("`\$Dir werden die H�lfte deiner DiebesPunkte abgezogen!`n");
      $session['user']['diebespu'] = $session['user']['diebespu']/2;
    addnav("Zur�ck zur Gildengasse","gildengasse.php");
   // addnav("Zu den Diebesj�ger","diebe.php");
     }
page_footer();
?>