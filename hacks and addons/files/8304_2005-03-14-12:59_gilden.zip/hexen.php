<?
// Grundidee der Affenj�ger von logd.de
// Affenj�germodifikation � by Hecki f�r http://www.cop-logd.de
// Hexenj�ger und Diebesj�ger � by Hecki f�r http://www.cop-logd.de
// 27.02.05 - 02.03.05
// Special Modifikationen � by Hecki, danke an Alle Autoren der Original Specials :o)
require_once "common.php";
page_header("Die Hexenj�ger");
$result = db_query($sql);
$row = db_fetch_assoc($result);
$totalplayers = $row['c'];

function display_table($title, $sql, $none=false, $foot=false, $data_header=false, $tag=false){
        global $session, $from, $to, $page;
        output("`c`b`^$title`0`b `7(Seite $page: $from-$to)`0`c`n");
        output('<table cellspacing="0" cellpadding="2" align="center"><tr class="trhead">',true);
        output("<td>`bRang`b</td><td>`bName`b</td>", true);
        if ($data_header !== false) {
                for ($i = 0; $i < count($data_header); $i++) {
                        output("<td>`b".$data_header[$i]."`b</td>", true);
                }
        }
        $result = db_query($sql) or die(db_error(LINK));
        if (db_num_rows($result)==0){
                $size = ($data_header === false) ? 2 : 2+count($data_header);
                //echo $size;
                if ($none === false) $none = "Keine Spieler gefunden";
                output('<tr class="trlight"><td colspan="'. $size .'" align="center">`&' . $none .'`0</td></tr>',true);
        } else {
                for ($i=0;$i<db_num_rows($result);$i++){
                        $row = db_fetch_assoc($result);
                        if ($row[name]==$session[user][name]){
                                //output("<tr class='hilight'>",true);
                                output("<tr bgcolor='#005500'>",true);
                        } else {
                                output('<tr class="'.($i%2?"trlight":"trdark").'">',true);
                        }
                        output("<td>".($i+$from).".</td><td>`&{$row[name]}`0</td>",true);
                        if ($data_header !== false) {
                                for ($j = 0; $j < count($data_header); $j++) {
                                        $id = "data" . ($j+1);
                                        $val = $row[$id];
                                        if ($tag !== false) $val = $val . " " . $tag[$j];
                                        output("<td align='right'>$val</td>",true);
                                }
                        }
                        output("</tr>",true);
                }
        }
        output("</table>", true);
        if ($foot !== false) output("`n`c$foot`c");
}

$order = "DESC";
if ($_GET[subop] == "least") $order = "ASC";
$sexsel = "IF(sex,'<img src=\"images/female.gif\">&nbsp; &nbsp;','<img src=\"images/male.gif\">&nbsp; &nbsp;')";
$racesel = "CASE race WHEN 1 THEN '`2Troll`0' WHEN 2 THEN '`^Elf`0' WHEN 3 THEN '`&Mensch`0' WHEN 4 THEN '`#Zwerg`0' WHEN 5 THEN '`5Echse`0' WHEN 6 THEN '`3Druide`0' WHEN 7 THEN '`6Goblin`0' WHEN 8 THEN '`4Orc`0' WHEN 9 THEN '`#Vampir`0' WHEN 10 THEN '`4Dieb`0'WHEN 11 THEN '`4D�mon`0' ELSE '`7Unbekannt`0' END";
//ENDE

if ($HTTP_GET_VARS[op] == ""){
if ($session['user']['hexe']==1 || $session['user']['superuser']>4){
   output("`^Du betrittst das Haus der Hexenj�ger!`n`n");
   output("`^Da du bereits Mitglied bist kannst du dir deine bisherigen Erfolge hier anschaun:`n`n");
   output("`\$Du hast bereits ".$session[user][hexenpu]." Hexen erledigt!`n`n");
addcommentary();
                viewcommentary("hexen","Gru� an die Hexenj�ger",15,"sagt",true);
addnav("Zur�ck zur Gildengasse","gildengasse.php");
addnav("`^Gildenrangliste", "hexen.php?op=hexe&subop=$subop&page=$page");

addnav("Austreten","hexen.php?op=austritt1");
}else if ($session['user']['affe']==1 || $session['user']['diebe']==1){
      output("`^Du kannst leider nur einer Gilde zur selben Zeit angeh�ren, komm wieder wenn du bei deiner Gilde ausgetreten bist.");
addnav("Zur�ck zur Gildengasse","gildengasse.php");
}else{
      output("`^Du betrittst das Haus der Hexenj�ger!`n`n");
      output("`^Hier kannst du Mitglied werden und auf Hexnejagt gehen, wenn dir eine im Wald �ber den Weg l�uft.`n Die Anmeldegeb�hr betr�gt einmalig `^20.000 Gold`n");
addnav("Beitreten","hexen.php?op=beitritt");
addnav("Zur�ck zur Gildengasse","gildengasse.php");
}
//GILDENRANGLISTE
} elseif ($_GET[op]=="hexe"){
        $sql = "SELECT name,hexenpu AS data1,$racesel AS data2 FROM accounts WHERE locked=0 AND hexe>0 ORDER BY data1 $order, level $order, experience $order";
        $title = "Krieger mit Hexenj�gerPunkten.";
        $headers = array("HexenPunkte");
        display_table($title, $sql, false, false, $headers, false);
        addnav("zur�ck","hexen.php");   
//ENDE

}else if ($HTTP_GET_VARS[op] == "beitritt"){
    page_header("Hexenj�ger beitreten");
if ($session['user']['gold']>19999){
    $session['user']['gold'] -= 20000;
    $session['user']['hexe'] = 1;
    $session['user']['pics'] = 2;
    $session['user']['gilde'] = '`^Hexenj�ger';
    output(" `n`n`2`b`cDu bist jetzt ein `^HEXENJ�GER!`c`n");
     output("`q Viel spass beim Jagen!");
    addnav("Zur�ck zur Gildengasse","gildengasse.php");
    addnav("Zu den Hexenj�gern","hexen.php");
    }else{
    output("`n`n`2Leider hast du nicht genug Gold dabei, komm doch sp�ter wieder vorbei!`n");
    output("`n`n");
    addnav("Zur�ck zur Gildengasse","gildengasse.php");
    }
}else if ($HTTP_GET_VARS[op] == "austritt1"){
    output("`^Sicher das du aussteigen willst?!`n");
    addnav("Ja");
    addnav("Ja","hexen.php?op=austritt");
    addnav("Nein");
    addnav("Nein","hexen.php");

}else if ($HTTP_GET_VARS[op] == "austritt"){
    page_header("Hexenj�ger austreten");

    $session['user']['hexe'] = 0;
    $session['user']['pics'] = 0;
    $session['user']['gilde'] = 'Keine';
    output(" `n`n`2`b`cDu bist bei den `^HEXENJ�GERN`2 ausgetreten!`c`n");
     output("`^Dir wird die H�lfte deiner HexenPunkte abgezogen!`n");
      $session['user']['hexenpu'] = $session['user']['hexenpu']/2;
    addnav("Zur�ck zur Gildengasse","gildengasse.php");
   // addnav("Zu den Hexenj�ger","hexen.php");
     }





page_footer();
?>