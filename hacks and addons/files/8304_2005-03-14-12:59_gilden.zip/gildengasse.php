<?
// Grundidee der Affenj�ger von logd.de
// Affenj�germodifikation � by Hecki f�r http://www.cop-logd.de
// Hexenj�ger und Diebesj�ger � by Hecki f�r http://www.cop-logd.de
// 27.02.05 - 02.03.05
// Special Modifikationen � by Hecki, danke an Alle Autoren der Original Specials :o)
require_once "common.php";
page_header("Die Gildengasse");


if ($session['user']['dragonkills']>4 || $session['user']['superuser']>2){
output("`QDu betrittst die Gildengasse, eine kleine Gasse mit 3 T�ren auf der ersten steht geschrieben:`@ Die Affenj�ger!`n`n");
output("`QAuf der zweiten kannst du `^ Die Hexenj�ger `Q lesen!`n`n");
output("`QUnd auf der letzten steht schliesslich geschrieben:`$ Die Diebesj�ger!`n`n");
output("`q F�r welche Gilde entscheidest du dich? Bedenke das du nur EINER Gilde zur selben Zeit angeh�ren kannst!");

addnav("Die Gilden");
addnav("`@Die Affenj�ger","affen.php");
addnav("`^Die Hexenj�ger","hexen.php");
addnav("`\$Die Diebesj�ger","diebe.php");
addnav("Zur�ck");
addnav("Zur�ck nach Myranor","myranor.php");
}else{
output("`%Du bist leider noch zu schwach um einer Gilde beizutreten, du musst den Drachen mindestens 5 mal besiegt haben!`n");
output("Komm wieder wenn du st�rker geworden bist.");
addnav("Zur�ck");
addnav("Zur�ck nach Myranor","myranor.php");


}
page_footer();
?>