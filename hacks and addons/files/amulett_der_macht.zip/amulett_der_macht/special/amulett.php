<?php
// Ursprung des Specials ist "golden egg"
// Ich machte mir daraus etwas �hnliches und schrieb es mir um. Bei Problemen bei
// http://www.anpera.net/forum/index.php?c=12 oder Garlant-T@web.de melden.

/*
 *	Letzte Aktualisierung 16.04.2007
 */

$session['user']['specialinc'] = "amulett.php";
switch($_GET['op']) {
	case 'takeit':
		output("`3Du bemerkst vor dir etwas pulsieren. Vorsichtig schleichst du dich heran um heraus zu finden was es ist. Als du nahe genug dran bist, erkennt du das es ein Amulett mit g�ttlicher Macht sein.`n`n");
		if (e_rand(1,5)==4) {
			output("Die G�tter meinen es nicht gut mit dir. Sie verwehren dir dieses Amulett auf zu heben und schicken einen Blitz auf dich hinab...");
			$lvl = $session['user']['level'];
			$hurt = e_rand(5*$lvl,10*$lvl);
			$session['user']['hitpoints']-=$hurt;
			output("`n`n`^Du verlierst $hurt Lebenspunkte!`n");
			if ($session['user']['hitpoints']<=0) {
				$session['user']['alive'] = false;
				output("`4Du bist `bTOT`b!!!`nDu verlierst gl�cklicherweise weder Gold noch Erfahrungspunkte.`nDu kannst morgen wieder k�mpfen.");
				addnav("Zu den Schatten","shades.php");
				addnav("Zu den News","news.php");
				addnews($session['user']['name']." `0starb mit dem Amulett der Macht in der Hand.");
			}
		} 
		else if (getsetting("hasamulett",0)!=0) {
			output("Gerade als du das Amulett aufheben m�chtest, kommt ein Fremder angerannt und schnappt sich vor deinen Augen `bdein`b Amulett...");
		}
		else {
			output("`3Nach kurzem Z�gern, l�ufst du vorsichtig auf das Amulett zu und hebst es geschwind auf ");
			output("Du sp�rst ein pulsieren, das nun deinen K�rper erfasst. Dir ist nun bewusst, weche macht das Amulett besitzt.");
			output("Als du dir das Amulett genauer anschaust, bemerkst du einige Einkerbungen, die du f�r Zeichen halst. Als du dir das Amulett umgelegt hast, h�rt das pulsieren ganz pl�tzlich auf und wird golden.");
			addnews("`V".$session['user']['name']."`V hat das Amulett der Macht im Wald gefunden!`0");
			$session['user']['reputation']++;
			savesetting("hasamulett",stripslashes($session['user']['acctid']));
		}
		$session['user']['specialinc']="";
		break;
	case 'abhaun':
		output("`3Du hast zu viel Ehrfurcht vor dem Amulett. Du glaubst, das es sicherer ist zu warten, bis eine andere Person das Amulett hat und es ihr zu stehlen.");
		$session['user']['specialinc']="";
		break;
	default:
		// pvp is not active 
		if (getsetting("pvp",1)==0) {
			output("`3Mitten im dichten Wald entdeckst du eine Ruine eines l�ngt vergessenens Altars, auf dem etwas liegt und zu leuchten beginnt, was einem Amulett �hnelt.`n");
			output("Du schaust dich um , um dich zu vergewissern, das du hier allein bist.`n`n ");
			$session['user']['specialinc']="";
		}
		// lets start the event... there is no owner
		else if (getsetting("hasamulett",0)==0) {
			output("`3Mitten im dichten Wald bemerkst du eine Ruine eines l�ngst vergessenen Altar. Auf dem etwas pulsiert! In deiner Neugier kommst du n�her.");
			output(" Du siehst auf einer gro�en lederten steinernen Platte ein Amulett, welches pulsiert!`n");
			output("Da du nicht an G�tter glaubst, aber das Amulett pulsiert und der Altar sicherlich einem Gott geweiht war bist du unschl�ssig, ob du den Altar betreten kannst und das Amulett nehmen solltest, ");
			output("oder es doch lieber auf der Altarruine lassen solltest. Einerseits k�nnte das Amulett einen hohen preis f�r dich haben, oder sogar ein Geheimnis Preis geben, welches die G�tter hier vor langer zeit versteckt  - andererseits aber k�nntest du ");
			output(" f�r die Entweihung und Entdeckung des Geheimnisses gestraft werden...");
			addnav("Nimm das Amulett mit","forest.php?op=takeit");
			addnav("Lieber nicht","forest.php?op=abhaun");
		}
		else {
			$ownerId = intval(getsetting("hasamulett", 0));
			if ($ownerId == $session['user']['acctid'])	{
				output("`3Du kommst an eine Stelle im Wald, die dir mehr als bekannt vorkommt. Als du dich genauer umsiehst, siehst du die Alte Ruine, aus der das Amulett stammt.");
				output(" Noch bevor du einen Gedanken hegen kannst, wirst du von hinten Niedergeschlagen.");
				$lvl = $session['user']['level'];
				$hurt = e_rand(4*$lvl,9*$lvl);
				$session['user']['hitpoints']-=$hurt;
				output("`n`n`^Du verlierst $hurt Lebenspunkte!`n");
				$text ="`V".$session['user']['name']."`V hat das Amulett der Macht im Wald verloren`0";
				if ($session['user']['hitpoints']<=0)
				{
					output("`4Du bist `bTOT`b!!!`nDu verlierst gl�cklicherweise weder Gold noch Erfahrungspunkte.`nDu kannst morgen wieder k�mpfen.");
					addnav("Zu den Schatten","shades.php");
					addnav("Zu den News","news.php");
					$text = $text." und starb dabei";
				}
				addnews($text.".");
				savesetting("hasamulett",stripslashes(0));
			}
			else {
				$sql = "SELECT acctid,name,sex FROM accounts WHERE acctid = {$ownerId}";
				$result = db_query($sql) or die(db_error(LINK));
				$row = db_fetch_assoc($result);
		
				output("`3Mitten im dichten Wald entdeckst du eine Ruine eines l�ngst vergessenen Altars.`n");
				output("Du siehst schon vom weiten, das der Altar leer ist und wendest dich wieder ab.`n`n ");
				output("`VDas Amulett der Macht befindet sich zur Zeit im Besitz von ".$row['name']."`^!`n`3Willst du es ".($row['sex']?"ihr":"ihm")." nicht mal abnehmen?`n");
			}
			$session['user']['specialinc']="";
		}
}
?>