<?php
/*
 * /##################### Copyright Informations ####################\
 *  #																#
 *  # Author: Garlant - Thomas Mann <Garlant-T@web.de>				#
 *  # Version: 2.1									  				#
 *  # Copyright 2009 by Thomas Mann									#
 *  # �berarbeitete Version des "Amulett der Macht"					#
 *  #																#
 * /#################################################################\
 * 
 */

require_once('common.php');
page_header("In der Festungsgrotte");
switch ($_GET['op']) {
	case "ruins":
		page_header("Festungsruine");
		
		addnav("Festungsgrotte betreten","festungsgrotte.php");
		addnav("Das ist mir zu unheimlich","village.php");
		
		output("`b `4Die Festungsruine`b `n`n
		`$ Du bist gerade beim Durchqueren einer tiefen Schlucht. �ber dir ist eine alte und �beraus gro�e Festungsanlage, der Zwerge.
		Du wei�t, das diese Festungsanlage einst, w�hrend der gro�en Kriege, Schutz vor �berf�llen und den Bestien der W�der bot 
		Doch Heute ist sie nur noch eine Ruine, vom Drachen gepl�ndert und zerst�rt. Viele Geschichten hast du �ber diesen Ort schon geh�rt. Unter anderem, dass hier etwas geheimnisvolles verborgen sein soll.
		Dies aber sind alles nur Mythen, so glaubst und setzt deinen Weg fort ohne der Ruine weitere Beachtung zu schenken.`n
		`n Doch als du eine bestimmte Stelle der Schlucht erreichst, beginnt das Amulett pl�tzlich wieder zu pulsieren. 
		`n Du bleibst stehen und siehst dich sogleich um. Als du alles genau beobachtest, bemerkst du neben dir eine unauff�llige stelle, die die form deines Amulettes hat.`n
		`n Sofort nimmst du dein Amulett ab und steckst es in das gleichf�rmige Loch.
		Ein lautes Ger�usch ert�nt, welches von der Bewegung der versteckten steineren T�r herkommt, die sich vor dir auftut.
		Nun beginnst du dich zu hinterfragen, ob an dem Mythos etwas wahres dran sei und was dich in der Grotte erwarten k�nnte.
		Was wirst du nun machen? Zur�ck ins Dorf laufen oder mutig die Grotte betreten und dein Gl�ck herausfordern?`0");
		page_footer();
		break;	
	case 'reward':
		addnav("Nimm Gold","festungsgrotte.php?op=gold");
		addnav("Nimm Edelsteine","festungsgrotte.php?op=gems");
		addnav("Waffe mitnehmen","festungsgrotte.php?op=weapon");
		addnav("R�stung mitnehmen","festungsgrotte.php?op=armor");
		addnav("Buch durchlesen","festungsgrotte.php?op=experience");
		
		output("`^ Mit letzter Kraft schleift sich der W�chter an eine Wand, um sich daran zu st�tzen. Unmengen an Blut sind auf dem Boden zu sehen und mit letzter Kraft spricht er, an er Wand lehnend, zu dir:".
		"`# Ihr habt mich besiegt. Nun m�chte ich mit meinen letzten Worten, euch die Geschichte dieser Festung erz�hlen.`^ Der W�chter mach eine Kurze Pause und beginnt schwer zu atmen. Blut rinnt ihm aus seinem Mund.".
		"`# Einst war diese Festungsanlage m�chtig. Sie bot allen Schutz uns strotzte gen Himmel. Der Handel bl�hte und unsere Widersacher wurden zerschmettert. Zu dieser Zeit entstand das Amulett, das `vAmulett der Macht`# wie".
		" es von uns genannt wurde. Es sollte unsere Macht und unser Wohlergehen darstellen. Doch weckte es nur Neid, Hass und Missgunst bei unseren Nachbarn. Wir mussten in den Krieg ziehen.`^ F�r einem Moment ist der W�chter ruhig und spricht nicht weiter.".
		"Doch du bist so neugierig und so gespannt, das du Fragst:`2Was ist passiert? Wer hat gewonnen?!`# Niemand hat gewonnen!`^, fuhr der W�chter herum.`# Viele verloren ihr Leben. Tapfere Krieger, arme Bauern sowie auch gro�e K�nige. Auch die R�stungen der Geschicken Zwerge boten keinen".
		"Schutz vor dem Hass in uns selbst. Unsere Widersacher und Nachbarn waren geschlagen. Wir jedoch hassten weiter. Bald darauf kam ein B�sartiges Wesen, das wir Drachen nennen. Es zerst�rte die Festungsanlage und fra� jeden den es bekam. Der k�mmerliche Rest wurde verbrannt.".
		"Nur sehr wenige m�chtige Magier �berlebten dies und schufen diese Grotte, dessen W�chter ich bin und dessen Schl�ssel du hast. Ich bitte dich darum, du musst diesen Bann brechen und aufh�ren zu hassen!`n`n".
		"`^Kurz bevor der W�chter dann verstirbt, spricht er mit seinen aller letzten Worten zu dir:`# Macht daraus etwas. Ich schenke euch nun was ihr begehrt, so sucht euch etwas aus.`^ Vor dir siehst du den reichen Schatz der alten Festungsanlage.".
		"Es sind Berge von Gold. Neben dir siehst du Wundervoll gearbeitete Waffen und R�stungen der Zwerge h�ngen, welche den Ruf haben besonders gut gerarbeitet zu sein. Gleich daneben, steht ein Tisch auf diesem liegen einige B�cher.`0");	
		break;
	case 'gold':
		$gold = e_rand(2000, 7000);
		$session['user']['gold'] += $gold;
		Output("`0Du nimmst dir so viel Gold wie du tragen kannst von dem Berg weg und gehst zum Ausgang. `^{$gold} Gold`0 hast du mitnehmen k�nnen!");
		savesetting("hasamulett",0);
		addnav("Zum Ausgang","village.php");
		break;
	case 'gems':
		$gems = e_rand(3, 6);
		$session['user']['gems'] += $gems;
		Output("`0W�hrend du dich umsiehst, stoplerst du �ber etwas. Ehe du dich versiehst, hast du dir`^ {$gems} ".($gems > 1? "Edelsteine":"Edelstein")." `0 eingesteckt!");
		savesetting("hasamulett",0);
		addnav("Zum Ausgang","village.php");
		break;
	case 'weapon':
		output("`0Du schaust dir eine Waffe ganz genau an. Sie gef�llt dir mehr als alle anderen, die da h�ngen und liegen. Aber sie ist schwer, sehr schwer. Doch als du damit ein paar mal ausholst bermekst du, das du dich irgendwie verbessert hast.".
			" Du hast nun `^1 Angriffspunkt`0 mehr und eine neue Waffe!");
		$session['user']['weapon'] = 'W�chterlangschwert';
		$session['user']['attack'] -= $session['user']['weapondmg'];
		$session['user']['weapondmg']++;
		$session['user']['attack'] += (1 + $session['user']['weapondmg']);
		savesetting("hasamulett",0);
		addnav("Zum Ausgang","village.php");
		break;		
	case 'armor':
		$session['user']['defence']++;
		$session['user']['armor'] = 'W�chterharnisch';
		$session['user']['defence'] -= $session['user']['armordef'];
		$session['user']['armordef'] ++;
		$session['user']['defence']+=$session['user']['armordef'];
		output("`0Schnell findest du eine R�stung, die dir besonders gut gef�llt. Du ersetzt deine R�stung sogleich durch die hier gefundene. Nun hasst du `^1 Verteidigungspunkt`0 mehr!");
		savesetting("hasamulett",0);
		addnav("Zum Ausgang","village.php");
		break;		
	case 'experience':
		output("`0Wahlos �ffnest du eines der auf dem Tisch liegenden B�cher und bl�tterst dieses durch.`n");
		switch (e_rand(1, 3)) {
			case 1:
				$exp = e_rand($session['user']['level']*55, $session['user']['level']*150);
				output("Du hast die alten Chroniken der Festungsanlage gefunden, welche die letzten Worte des W�chters zu erg�nzen scheinen. ".
					   "Du nimmst das Wissen vergangener Tage in dir auf und erh�lst {$exp} Erfahrungspunkte.`0");
				$session['user']['experience'] += $exp;
				break;
			case 2:
				output("Du hast ein altes Buch �ber die Kunst der Verf�hrung gefunden. Ob dir dieses Wissen Heute noch etwas bringen wird?");
				$charme = e_rand(1, 4);
				$session['user']['charm'] += $charme;
				break;
			case 3:
				output("Es ist dir ein Buch zur �berlebenskunst in die H�nde gefallen. Nat�rlich willst du das neu erworbene Wissen gleich in die Tat umsetzen.");
				$session['user']['turns'] ++;
				break;
		}
		savesetting("hasamulett",0);
		addnav("Zum Ausgang","village.php");
		break;		
	default:
		if(!isset($_GET['op'])) {
			if($session['user']['w�chterkills'] < 1) {
				$text = " Du hast keine Ahnung was dich hier erwarten wird und blickst dich neugierung, aber mindestens genauso ehrf�rchtig um. `n";
			}
			else {
				switch(e_rand(1, 2)) {
					case 1:
						$text = " Du hast das Gef�hl schon einmal hier gewesen zu sein. Du sagst dir dass, das nicht sein kann, wirfst das Gef�hl von dir ab gehst weiter.`n";
						break;
					case 2:
						$text = " Schemenhaft erinnerst du dich an diesen Ort. Du glaubst dies hier schon einmal in einem Traum gesehen zu haben. ...`n";
						break;
				}
			}
			output("`\$Kaum hast du den dunklen Eingang der Grotte betreten, entz�ndet sich eine eine in das Gestein eingelassene Halterung auf welcher eine Fackel steckt. ".
				"Hastig nimmst du die Fackel aus der Halterung und beginnst dich auf den Weg ins innere zu machen.`n".
				$text.
				" Nach einem kurzen Fu�marsch, findest du dich vor einer gro�en steinernen T�r wieder. Du brauchst nicht lange um dich daf�rzu entscheiden diese zu �ffnen.".
				" Schlie�lich, so glaubst du, wirst du hinter dieser T�r gro�e Reicht�mer finden, welche dann nat�rlich alle dir geh�ren.".
				" Leider ist dem nicht ganz so. Kurz nachdem dein Weg dich durch die �ffnung schreiten l�sst, beginnt sich die T�r wieder zu schlie�en. `n".
				" Eine Gestalt in einer prunkvollen R�stung erscheint vor deinen Augen und beginnt sich auf dich zu st�rzen.");
				
			// setup the badguy
			$points = 0;
			while(list($key,$val)=each($session['user']['dragonpoints'])){
				if ($val=="at" || $val == "de") $points++;
			}
			$points = ceil($points*0.75);
			$atkflux = e_rand(0, $points);
			$defflux = e_rand(0,$points-$atkflux);
			$hpflux = ($points - ($atkflux+$defflux)) * 5;
						
			$badguy = array();
			$badguy['creaturename'] = '`VW�chter der Grotte';
			$badguy['creatureweapon'] = 'Geweihtes W�chterlangschwert';
			$badguy['creaturelevel'] = $session['user']['level'];
			$badguy['creaturehealth'] = ((10*$session['user']['level'])*2 + $hpflux);
			$badguy['creatureattack'] = (e_rand((15 + $atkflux),  (15 + round(2.75*$session['user']['level'], 0)) + $atkflux));
			$badguy['creaturedefense'] = (e_rand((15 + $defflux),  (15 + round(2.75*$session['user']['level'], 0)) + $defflux));
			$session['user']['badguy']=createstring($badguy);
			$battle=true;
		}
	
		if($_GET['op'] == 'fight' || $_GET['op'] == 'run'){
			if($_GET['op'] == 'run') output("Die steinerne T�r hat sich geschlossen, du kannst nicht fliehen!");	
			$battle=true;
		}
		
	// fight...
		if ($battle){
			require_once("battle.php");
			if ($victory){
				$badguy=array();
				$session['user']['badguy']="";
				$session['user']['w�chterkills']++;
				$session['user']['reputation']+=2;
				output("`n`&Du parrierst einen gewaltigen Schlag des W�chters und rammst ihm deine Waffe, durch seine starke R�stung in die Brust. Der W�chter sackt t�dlich verwundet zu boden. ...");
				addnews("`&".$session['user']['name']."`& hat den `VW�chter der Grotte`& t�dlich verwundet!`n");
				addnav("Weiter","festungsgrotte.php?op=reward");
			}
			else {
				if($defeat){
					addnav("T�gliche News","news.php");
		
					$session['user']['reputation']--;
					addnews("`%".$session['user']['name']."`5 hat das Amulett der Macht verloren, als ".($session['user']['sex']?"sie":"er").
							" sich dem `VW�chter der Grotte`5 stellte und dabei t�dlich verwundet wurde!!! ");
						
					$session['user']['alive']=false;
					debuglog("lost {$session['user']['gold']} gold when they were slain");
			
					$session['user']['gold']=0;
					$session['user']['hitpoints']=0;
					$session['user']['badguy']="";
					savesetting("hasamulett",stripslashes(0));
					output("`b`%".$badguy['creaturename']."`& hat, dich get�tet!!!`n`b");
					output("`4Du hast dein ganzes Gold verloren!`n");
					output("`4Du hast das Amulett in der Grotte verloren!`n");
					output("Du kannst morgen wieder k�mpfen.`0");
					page_footer();
				}
				else{
					fightnav(true,false);
				}
			}
	}
}
page_footer();
?>