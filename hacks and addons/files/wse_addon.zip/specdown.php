<?php
/**********************************************
*Diese Box darf nicht entfernt werden!        *
*-------------------------------------        *
*Specials Download von Hadriel                *
*www.anaras.ch                                *
*Ben�tigt Waldspecialeditor von deZent|draKarr*
**********************************************/
require_once "common.php";
page_header("Special-Download");
define("special_dir","special");
if($_GET[op]==""){

   $sql="SELECT"
       ." *"
       ." FROM"
       ." waldspecial"
       ." WHERE"
       ." download=1"
       ." ORDER BY"
       ." filename ASC;";
  $result=db_query($sql);
  if(db_num_rows($result)){
      $ausgabe="<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999'>";
    $ausgabe.="<tr class='trhead'>
               <td>Specialname</td>
               <td>Download</td>
             </tr>`n";
             while($row=mysql_fetch_assoc($result)){
             $ausgabe.="<tr class='".($i%2?"trdark":"trlight")."'>";
             $ausgabe.="<td>$row[name]</td>";
             $ausgabe.="<td><a href=\"specdown.php#\" onClick=\"".popup("specdown.php?op=download&filename=$row[filename]")."; return false;\">$row[filename]</td></tr>";
  }
  $ausgabe.="</tr></table>";
  output($ausgabe,true);
  }else{
  $ausgabe='<h1>Keine Specials zum Download!</h1>';
  output($ausgabe,true);
 
  } 
  if(!$session[user][loggedin]){
  addnav("Index","index.php");
  }else{
  }
  page_footer();
  }
  else if($_GET[op]=="download"){
  if (substr($_GET[filename],0,1)=="/") $_GET[filename]=substr($_GET[filename],1);
  show_source("./".special_dir."/".$_GET[filename]."");
}
?>