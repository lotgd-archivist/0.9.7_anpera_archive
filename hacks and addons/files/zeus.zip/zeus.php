<?php
/*_____________________________________________________________
  |Zeus' Thron                                                |
  |von Lord Eliwood                                           |
  |___________________________________________________________|
*/
//SQL
//ALTER TABLE `accounts` ADD `zeus` INT( 10 ) UNSIGNED NOT NULL ;
require_once "common.php";
page_header("Zeus Thron");
//////////////////////////////////////////////////////////////////////////////////////////////
output("`c`b`vZeus' Trohn`c`b`n`n");
//////////////////////////////////////////////////////////////////////////////////////////////
if($_GET['op']=="")
{
        addnav("Kneifen","olymp.php");
        if($session['user']['zeus']==0)
        {
        output("Du gehst dem Weg zu Zeus' Trohn entlang und und triffst endlich auf Zeus, den G�ttervater.");
        output("Er mustert dich mit Erfahrenem Blick und sagt dann: \"`Vich hab schon viel von dir geh�rt.");
        output("Ich gew�hre dir eine �berraschung.\"`0.`n`nDu kannst dich nun entscheiden. Nimmst du das Angebot an, oder kneifst du?");
        addnav("�berraschung","zeus.php?op=we");
        }
        else
        {
        output("Du bist heute schon einmal bei Zeus gewesen und du willst dein Gl�ck nicht nochmal herausfordern");
        }
}
//////////////////////////////////////////////////////////////////////////////////////////////
if($_GET['op']=="we")
{
        $session['user']['zeus']=1;
        ///////////////////
        switch(e_rand(1,11))
        {
                        case 1:
                        output("Zeus nimmt einer seiner Blitze und wirft ihn auf dich. Du erschrickst und rennst davon.`n");
                        output("Wegen deiner Flucht verlierst du an Ehrenhaftigkeit.");
                        addnav("Zur�ck zum Olymp","olymp.php");
                        $session['user']['reputation']-=5;
                        break;
                        ///////////////
                        case 2:
                        case 3:
                        output("Zeus nimmt einer seiner Blitze und wirft ihn auf dich. Mutig bleibst du stehen und der Blitz schl�gt neben dir in den Boden ein.`n");
                        output("Dank deinem Mut gewinnst du an Ehrenhaftigkeit.");
                        addnav("Zur�ck zum Olymp","olymp.php");
                        $session['user']['reputation']+=5;
                        break;
                        //////////////
                        case 4:
                        case 5:
                        case 6:
                        output("Zeus schl�gt dich, doch du f�hlst dich noch immer wie vor dem Schlag. Zeus erkl�rt dir, dass du die Wirkung des Schlags");
                        output("erst in der J�gerh�tte merken w�rdest. Was er wohl damit gemeint hat?");
                        addnav("Zur�ck zum Olymp","olymp.php");
                        $session['user']['donation']+=100;
                        break;
                        //////////////
                        case 7:
                        case 8:
                        case 9:
                        output("Zeus gibt dir einen Trank, den du sofort leerst. Erst nach einer weile merkst du, dass du einen permanenten Lebenspunkt dazu gewonnen hast.");
                        addnav("Zur�ck zum Olymp","olymp.php");
                        $session['user']['maxhitpoints']+=1;
                        break;
                        /////////////
                        case 10:
                        case 11:
                        output("Zeus gibt dir einen Trank, den du sofort leerst. Erst nach einer weile merkst du, dass du einen permanenten Lebenspunkt verloren hast.");
                        addnav("Zur�ck zum Olymp","olymp.php");
                        $session['user']['maxhitpoints']-=1;
                        break;
        }
}


page_footer();
?>