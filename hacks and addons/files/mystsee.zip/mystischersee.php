<?php
//Erstellt von Tidus (http://web1.w039.white.fastwebserver.de/logdonline/)
//Copyright by Tidus und darf nicht Entfernt werden.
require_once "common.php";
addcommentary();
page_header ("Mystischer See");

output("`&Du kommst an den `~Mystischen See`& an dem es immer Dunkel ist da ein Zauber auf ihm liegt, der Mond und die");
output("Sterne strahlen auf den See. Es liegt eine Mystisch Romantische Stimmung in der Luft, hier w�re der ");
output("Perfekte ort um mit deiner Freundin zu reden. Auf dem `~Mystischen See`& liegt ein zauberhafter schimmer...");

output("`n`n `$ Eine Fee erinnert dich daran das hier Rollenspiel pflicht herrscht.");
output("`n`n`n");
if($session['user']['marriedto']>0) { 
    if($session['user']['sex']==0) { 
        $male=$session['user']['acctid']; 
        $female=$session['user']['marriedto']; 
    } else { 
        $male=$session['user']['marriedto']; 
        $female=$session['user']['acctid']; 
    } 
    $gesammt="mystischersee_".$male."_".$female; 
    viewcommentary($gesammt,"Mit deinem Schatz reden",20,"Fl�stert"); 
    //addnav("Geheimgrotte","Paare.php");
}else{
output("Da auf dem `~Mystischen See`& ein Zauber liegt k�nnen ihn nur diejenigen betreten die Verheiratet ");
output("sind oder kurz vor der Verm�hlung stehen.");
}
addnav("Dorfplatz","village.php");
page_footer();
?>