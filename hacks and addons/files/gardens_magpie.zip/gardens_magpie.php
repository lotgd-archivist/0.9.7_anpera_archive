<?php

/**
* Special im Garten: Die Elster, 26.05.2007
* @author Fingolfin f�r Dragonslayer
* auf Edelsteine  ge�ndet von Salator
*/

page_header('Die Elster');

$session['user']['specialinc'] = basename(__FILE__);
$str_filename = basename($_SERVER['SCRIPT_FILENAME']);
$str_backlink = 'gardens.php';

$str_output = '';

switch($_GET['op'])
{
	case 'give':

		$what=$_GET['what']=='gems'?'gems':'gold';
		if($session['user'][$what]>0)
		{
			if($what=='gems')
			{
				$str_output .= '`0Du kramst einen Edelstein aus deiner Tasche heraus und wirfst ihn der Elster hin. Sofort schnappt diese danach und ist so schnell wieder davon geflogen, wie sie gekommen ist.`n`n
				`&Du f�hlst dich besser und k�nntest wieder ein wenig Aufregung gebrauchen.';

				$session['user']['gems'] --;
				$session['user']['turns'] ++;
			}
			else
			{
				$str_output .= '`0Du kramst ein Goldst�ck aus deiner Tasche heraus und wirfst es der Elster hin. Sofort schnappt diese danach und ist so schnell wieder davon geflogen, wie sie gekommen ist.
				`nDu verfolgst die Elster mit deinen Blicken und siehst, wie die Elster das Goldst�ck in den Dorfbrunnen wirft. Dieses merkw�rdige Verhalten kennst du sonst nur von Neuank�mmlingen...`n`n';
				$session['user']['gold'] --;
				savesetting('gold_in_well',getsetting('gold_in_well',0)+1);
			}
		}
		else
		{
			$str_output .= '`0Du suchst in deinen Taschen nach etwas Glitzerndem, doch du kannst nichts au�er ein paar Brotkr�meln finden, die du der Elster hinwirfst. Diese scheint dich nur noch schiefer anzuschauen und verschwindet flatternd.`n`n
			`&Du gehst etwas entt�uscht weiter in den Garten.';
		}
		addnav('Weiter',$str_backlink);

		$session['user']['specialinc'] = '';
	break;

	case 'scare':

		$str_output .= '`0Du verscheuchst die Elster r�cksichtslos mit wilden Bewegungen und lautem Geschrei. Anschlie�end gehst du weiter durch den Garten.';

		if($session['user']['turns']>0 && e_rand(1,8) == 2)
		{
			$str_output .= '`&Du verlierst einen Waldkampf.';

			$session['user']['turns'] -= 1;
		}

		addnav('Weiter',$str_backlink);

		$session['user']['specialinc'] = '';
		break;

	default:

	$str_output .= '`0Du betrittst den Garten und gehst ein paar Schritte, als vor dir pl�tzlich eine Elster auf den Weg geh�pft kommt und dich mit schiefem Kopf anschaut. Du gehst einige Schritte weiter doch die Elster weicht kein bischen zur�ck.`n`n
	`&Was wirst du tun?';

	addnav('G?Ein `^Goldst�ck`0 hergeben',$str_filename.'?op=give&what=gold');
	addnav('Einen `#Edelstein`0 hergeben',$str_filename.'?op=give&what=gems');
	addnav('Verscheuchen',$str_filename.'?op=scare');
	break;

}
output($str_output);

page_footer();

?>