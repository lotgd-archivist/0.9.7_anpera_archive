<?

/*
		______________________
		
		code, text and idea by Draza�ar
		
		made for Vinestra
		http://logd.legend-of-vinestra.de
		drazaar@legend-of-vinestra.de
		
		Feedback und Verbesserungsvorschl�ge sind erw�nscht! ^^
		
		______________________
		
*/

switch($_GET['op']) {
	/**
	 * Special zu Beginn gleich verlassen
	 */
	case 'leave':
		$str_out = '`&Anderen Leuten helfen? Du bist hier ja nicht der g�ldene Samariter, au�erdem hast du auch wirklich
				    Besseres zu tun!! `n
				    Du ziehst dich in den Wald zur�ck.';
		
		$session['user']['specialinc'] = '';
		break;
	
	/**
	 * Der Person helfen
	 */
	case 'help':
		$str_out = '`&Edlen Gem�ts st�rmst du nat�rlich sofort los um de'.($session['user']['sex']?'m Hilfeschreienden':'r Hilfeschreienden').' 
				    heldenhaft beizustehen. `n`n
				    Du schl�gst dich durch die B�sche und entdeckst schlie�lich wie drei Goblins '.($session['user']['sex']?'einen jungen Edelmann':'eine wundersch�ne, junge, anmutige Prinzessin').' 
				    mit ihren spitzen Messern bedrohen. Das reicht dir auch schon! Wild mit deiner Waffe rumfuchtelnd und einem Kampfschrei auf den Lippen brichst du durchs Unterholz. `n`n';
		
		switch(mt_rand(0, 5)) {
			/**
			 *	Kerker
			 */
			case 0: case 1: case 2:
				$str_out .= 'Und du musst feststellen, dass das Geschrei und das gekonnte Spiel mit deiner Waffe seine Wirkung nicht verfehlt. 
							 Die Goblins rennen alle samt querfeldein in verschiedene Richtungen, was dir nun auch gerade recht ist. `n`n
							 Gerade willst du dein Wort an '.($session['user']['sex']?'den Prinzen':'die Prinzessin').' richten, als ziemlich viele Reiter 
							 um dich herum zum stehen kommen. `n
							 `$"Ahhhja, da haben wir Dich ja! '.($session['user']['sex']?'Den Prinzen':'Die Prinzessin').' entf�hren wollen, das haben wir ja gern!!"`&, ruft dir der Kommandant entgegen. `n
							 `9"Waren es vorher nicht mehrere und irgendwie kleinere?"`&, fragt einer der Soldaten etwas leiser gen Kommandant. `n
							 `$"Egal, hauptsache einen Entf�hrer." `&ist die knappe Antwort, wobei dich einer der anderen Soldaten mit einem wuchtigen Schlag auf den Hinterkopf ins Reich der Tr�ume schickt... `n
							 '.($session['user']['sex']?'Der Prinz':'Die Prinzessin').' steht unterdessen unt�tig herum, anscheinend steht '.($session['user']['sex']?'er':'sie').' unter Schock...';
				
				$session['user']['specialinc'] = 'kerker.php';
				
				addnav('Aktionen');
				addnav('Weiter', 'forest.php?op=injail');
				break;
			
			/**
			 *	Belohnung
			 */
			case 3: case 4:
				$gems = mt_rand(2, 3);
				
				$extragold = mt_rand(1, ($session['user']['level']*100));
				if($gems == 2)
					$gold = $session['user']['level'] > 5 ? 5000 : ($session['user']['level'] * 1000);
				elseif($gems == 3)
					$gold = $session['user']['level'] > 5 ? 3750 : ($session['user']['level'] * 750);
				
				$gold = $gold + $extragold;
					
				$str_out .= '`&Und du musst feststellen, dass das Geschrei und das gekonnte Spiel mit deiner Waffe seine Wirkung nicht verfehlt. 
							 Die Goblins rennen alle samt querfeldein in verschiedene Richtungen, was dir nun auch gerade recht ist. 
							 '.($session['user']['sex']?'Der Prinz':'Die Prinzessin').' steht w�hrenddessen zwar etwas geschafft, aber gl�cklich strahlend neben dir. `n
							 `g"Danke f�r deine Hilfe! Ich dachte schon, ich w�re verloren..."`&, spricht '.($session['user']['sex']?'er':'sie').'. Pl�tzlich sind Pferdehufe 
							 auf dem Waldboden zu h�ren und ehe du dich versiehst stehen bei euch auch schon einige in schwere R�stungen geh�llte Reiter, samt einer Kutsche. `n
							 `$"Ahh, ich sehe schon, Ihr habt '.($session['user']['sex']?'den Prinzen':'die Prinzessin').' schon befreit. Hier nehmt das als Lohn f�r Eure gute Tat!!!"`&, spricht der Kommandant 
							 und wirft dir ein S�ckchen zu. `n
							 Jeder bedankt sich noch einmal bei dir und schlie�lich wird '.($session['user']['sex']?'der Prinz':'die Prinzessin').' in die Kutsche verfrachtet und zur�ck zu '.($session['user']['sex']?'seinem':'ihrem').' Schloss gebracht. `n`n`n
							 `^Du bekommst `%'.$gems.' `^Edelsteine und `%'.$gold.' `^Gold!';
				
				$session['user']['gold'] += $gold;
				$session['user']['gems'] += $gems;
				
				$session['user']['specialinc'] = '';
				break;
			
			/**
			 *	Absolut schlimmster Fall
			 */
			case 5:
				$str_out .= '`&Doch irgendwie musst du feststellen, dass sich so eine Gruppe Goblins nicht so leicht beeindrucken l�sst. `n';
				
				if($session['user']['dragonkills'] < 20) {
					$str_out .= 'Schneller als du gucken kannst, hast du keine Waffe mehr in der Hand, daf�r hat einer der Goblins nun zwei.
							     Dich auslachend macht der gr��te von ihnen eine fortscheuchende Bewegung mit seiner Hand. 
								 `2"'.($session['user']['sex']?'Die is': 'ders').' ja noch so klein, lohnt ja gar nich!"`&, h�hnt er. `n`n
								 In Anbetracht dessen, dass das gerade ein ziemlicher Griff ins Plumpsklo war, befolgst du lieber den Rat des Goblins und ziehst dich zur�ck. `n`n';
					
					if($session['user']['level'] < 10) {
						$str_out .= 'Gerade als du drei Schritte gegangen bist, trifft dich etwas Hartes am Hinterkopf. 
								    `2"Vergiss nich dein Ding hier!" `&h�rst du noch den Goblin nachrufen. Du gehst bewusstlos zu Boden, ausgeknocked von deiner eigenen Waffe!! `n`n`n
									`^Du verlierst fast alle Lebenspunkte.`n
									Du verlierst `%'.($session['user']['turns']>=2?'2':$session['user']['turns']).' `^Waldk�mpfe!';
						
						$session['user']['hitpoints'] == 1;
						$session['user']['turns'] -= $session['user']['turns'] >= 2 ? 2 : $session['user']['turns'];
						
						$session['user']['specialinc'] = '';
					}
					else {
						$str_out .= 'Zu bl�d, dass der kleine Kerl noch deine Waffe hat. Jetzt stehst du wieder mit leeren H�nden da und musst dir wohl eine neue kaufen! `n`n`n
									 `^Du verlierst deine Waffe!';
						
						$session['user']['attack'] -= $session['user']['weapondmg'];
						$session['user']['weapon'] = 'F�uste';
						$session['user']['weaponvalue'] = 0;
						$session['user']['weapondmg'] = 0;
						
						$session['user']['specialinc'] = '';
					}
					break;
				}
				elseif($session['user']['dragonkills'] < 75) {
					$str_out .= 'Und so kommt es zum Kampf. Du schl�gst dich gut, doch gegen drei Gegner ist es schwer und Goblins sind nicht gerade daf�r ber�hmt, faire K�mpfer zu sein. `n
								 Ein unbedachter Moment und du wirst hinterr�cks niedergestochen und gehst tot zu Boden. Weil die Goblins aber Angst haben, dass du doch noch 
								 einmal aufstehen k�nntest, verschwinden sie samt '.($session['user']['sex']?'Prinz':'Prinzessin').'. `n`n`n
								 `^Du bist TOT! `n
								 `^Du verlierst `%10% `^Erfahrung!';
					
					$session['user']['alive'] = false;
					$session['user']['hitpoints'] = 0;
					$session['user']['experience'] -= round($session['user']['experience'] * 0.1);
					
					addnav('Zu den Schatten', 'shades.php');
					
					$session['user']['specialinc'] = '';
				}
				else {
					$str_out .= 'Und so kommt es zum Kampf. Du schl�gst dich gut, doch gegen drei Gegner ist es schwer und Goblins sind nicht gerade daf�r ber�hmt, faire K�mpfer zu sein. `n
								Ein unbedachter Moment und du wirst hinterr�cks niedergestochen und gehst tot zu Boden. Da die Goblins dich doch als recht gef�hrlich betrachtet haben, gehen sie 
								auf Nummer sicher, dass du auch wirklich tot bist. Dabei nehmen sie auch noch all dein Gold an sich! `n`n`n
								`^Du bist TOT! `n
								Du verlierst all dein  Gold! `n
								Du verlierst `%10% `^Erfahrung!';
					
					$session['user']['alive'] = false;
					$session['user']['hitpoints'] = 0;
					$session['user']['gold'] = 0;
					$session['user']['experience'] -= round($session['user']['experience'] * 0.1);
					
					addnav('Zu den Schatten', 'shades.php');
					
					$session['user']['specialinc'] = '';
				}
				break;
		}
		break;
	
	/**
	 * Im Kerker
	 */
	case 'injail':
		if(!isset($_GET['count']))
			$count = 0;
		else {
			$count = $_GET['count'];
		}
		
		switch($count) {
			case 0:
				$str_out = '`&Du wachst im Kerker wieder auf. Die Luft ist feucht und riecht nach allem M�glichen, was du dir lieber gar nicht so
							genau vorstellen willst. In einer Ecke steht ein Krug Wasser und eine Sch�ssel mit irgendeinem Brei samt L�ffel. `n
							Nicht sehr dankbar die Kerle, immerhin hast du '.($session['user']['sex']?'ihren Prinzen':'ihre Prinzessin').' befreit... `n`n
							Was willst du nun tun? `n`n
							<a href="forest.php?op=spoon&count='.$count.'">Den L�ffel benutzen um einen Gang nach drau�en zu graben.</a> `n
							<a href="forest.php?op=cry&count='.$count.'">Nach Hilfe schreien und um Gnade winseln.</a>';
				
				addnav('', 'forest.php?op=spoon&count='.$count);
				addnav('', 'forest.php?op=cry&count='.$count);
				
				addnav('Aktionen');
				addnav('Gang graben', 'forest.php?op=spoon&count='.$count);
				addnav('Um Gnade winseln', 'forest.php?op=cry&count='.$count);
				break;
			
			case 1:
				$str_out = '`&Du sitzt noch immer im Kerker, was Deine Laune nicht gerade verbessert. 
							Angestrengt �berlegst Du Dir, was Du nun tun k�nntest um hier herauszukommen. `n
							Doch au�er `n`n
							<a href="forest.php?op=spoon&count='.$count.'">den L�ffen benutzen um einen Gang zu graben</a> `n`n
							oder `n`n
							<a href="forest.php?op=cry&count='.$count.'">nach Hilfe schreien und um Gnade winseln.</a> `n`n
							f�llt Dir beim besten Willen nichts ein...';
				
				addnav('', 'forest.php?op=spoon&count='.$count);
				addnav('', 'forest.php?op=cry&count='.$count);
				
				addnav('Aktionen');
				addnav('Gang graben', 'forest.php?op=spoon&count='.$count);
				addnav('Um Gnade winseln', 'forest.php?op=cry&count='.$count);	
				break;
				
			case 2:
				$str_out = '`&Langsam aber sicher fragst du dich, ob dieser Kerker Deine letzte Ruhest�tte wird. 
							Doch von diesem Gedanken bist du nicht sonderlich begeistert, weshalb du dir �berlegst, was du 
							nun probieren sollst. `n`n
							<a href="forest.php?op=spoon&count='.$count.'">Den L�ffel benutzen um einen Gang nach drau�en zu graben.</a> `n
							<a href="forest.php?op=cry&count='.$count.'">Nach Hilfe schreien und um Gnade winseln.</a>';
				
				addnav('', 'forest.php?op=spoon&count='.$count);
				addnav('', 'forest.php?op=cry&count='.$count);
				
				addnav('Aktionen');
				addnav('Gang graben', 'forest.php?op=spoon&count='.$count);
				addnav('Um Gnade winseln', 'forest.php?op=cry&count='.$count);
				break;
		}
		
		$session['user']['specialinc'] = 'kerker.php';
		break;
		
	case 'spoon':
		$count = $_GET['count'];
		$count++;
		
		if($count == 3) {
			$str_out .= '`&Gerade willst du dich daran machen mit dem L�ffel im Boden herumzubuddeln um "irgendwann"
						 einen Gang nach drau�en gegraben zu haben, da wird auch schon deine Zellent�re aufgesto�en. 
						 Hastig wirfst du den L�ffel weg und blickst den Kommandanten von vorher erstaunt an. `n
						 Dieser sagt nicht viel, sondern gibt seinen M�nnern ein Handzeichen, woraufhin diese dich 
						 wieder einmal unsanft packen und einige Minuten sp�ter unsanft vor dem Burgtor absetzen. Du willst 
						 schon fragen, was das Ganze zu bedeuten hat, doch da sind alle au�er dir auch schon wieder verschwunden.
						 Ganz sch�n undankbar, das muss man doch sagen. Wenigstens hast du aus dieser Aktion etwas gelernt...`n`n`n
						 '.($session['user']['turns']>0?'`^Du verlierst `%'.($session['user']['turns']>=3?'3':$session['user']['turns']).' `^Waldk�mpfe! `n':'').'
						 `^Du bekommst `%5% `^Erfahrung!';
			
			$session['user']['experience'] += round($session['user']['experience'] * 0.05);
			if($session['user']['turns']>0)
				$session['user']['turns'] -= $session['user']['turns'] >= 3 ? 3 : $session['user']['turns'];
			
			$session['user']['specialinc'] = '';
		}
		else {
			switch(e_rand(1,6)) {
				case 1: case 2:
					$str_out = '`&Du schnappst dir den kleinen L�ffel von der Schale in der Ecke und f�ngst 
								damit an wie wild im Boden herumzustochern. Nach ungef�hr zwei Stunden hast du es geschafft 10 cm tief zu graben.
								mit sehr unfreundlichen Gedanken gegen�ber dem Kommandanten und seinen M�nnern rechnest du hoch,
								wie lange du wohl noch hier sitzen wirst um nach drau�en zu gelangen, sollte es mit dieser
								Geschwindigkeit weiter gehen. Schlie�lich gibst du ersch�pft auf.
								'.($session['user']['turns']>0?'`nDas ganze hat dennoch ziemlich viel Zeit gekostet. `n`n`n
								`^Du verlierst einen Waldkampf!':'');
					
					if($session['user']['turns'] > 0)
						$session['user']['turns']--;			
				
					$session['user']['specialinc'] = 'kerker.php';
					addnav('Weiter', 'forest.php?op=injail&count='.$count);
					break;
					
				case 3: case 4: case 5:
					$str_out = '`&Du schnappst dir den kleinen L�ffel von der Schale in der Ecke und f�ngst 
								damit an wie wild im Boden herumzustochern. Nach ungef�hr zwei Stunden hast du es geschafft 10 cm tief zu graben.
								mit sehr unfreundlichen Gedanken gegen�ber dem Kommandanten und seinen M�nnern rechnest du hoch,
								wie lange du wohl noch hier sitzen wirst um nach drau�en zu gelangen, sollte es mit dieser
								Geschwindigkeit weiter gehen. Als du nach einer weiteren Stunde schon Blasen an den H�nden hast und sich immer
								noch nicht all zu viel an der Tiefe ge�ndert hat, gibst du auf. `n
								Die Blasen an den H�nden tun wirklich weh
								'.($session['user']['turns']>0?' au�erdem hat das Ganze ziemlich viel Zeit gekostet. `n`n`n
								`^Du verlierst einen Waldkampf!`n':'. `n`n`n').'
								`^Du verlierst `%10% `^deiner Lebenspunkte!';
								
					$session['user']['hitpoints'] -= round($session['user']['hitpoints'] * 0.1);			
					if($session['user']['turns'] > 0)
						$session['user']['turns']--;
						
					$session['user']['specialinc'] = 'kerker.php';
					addnav('Weiter', 'forest.php?op=injail&count='.$count);
					break;
					
				case 6:
					$gems = mt_rand(2, 3);
					
					$str_out = '`&Du schnappst dir den kleinen L�ffel von der Schale in der Ecke und f�ngst 
								damit an wie wild im Boden herumzustochern. Nach ungef�hr zwei Stunden hast du es geschafft 10 cm tief zu graben.
								mit sehr unfreundlichen Gedanken gegen�ber dem Kommandanten und seinen M�nnern rechnest du hoch,
								wie lange du wohl noch hier sitzen wirst um nach drau�en zu gelangen, sollte es mit dieser
								Geschwindigkeit weiter gehen. Mit einem resignierenden Seufzer st��t du noch einmal mit dem L�ffel
								auf den Erdboden. Ein lautes `iKRACKS`i ist zu h�ren und ein relativ gro�es Loch unter dem Boden wird frei. `n
								Du blinzelst ungl�ubig und springst dann hinein. Viel kannst du nicht erkennen, doch ganz am Ende des Ganges, 
								welcher sich dir nun zeigt, scheint ein Licht zu sein. Wie verr�ckt rennst du auf das Licht zu, doch bevor du es
								erreichst stolperst du und landest unsanft auf dem Boden. `n`n
								Gl�cklich bemerkst du, dass es wohl '.$gems.' Edelsteine waren, �ber die du gestolpert bist.`n
								Wie es aussieht hat schon einmal vor dir wer einen Gang gegraben und die Edelsteine hier verloren.
								Zufrieden steckst du sie ein und machst dich aus dem Staub, obwohl dir nach deinem Sturz echt alles weh tut!
								'.($session['user']['turns']>0?'`nDas hat alles ziemlich viel Zeit gekostet!':'').' `n`n`n
								`^Du verlierst `%25% `^deiner Lebenspunkte! `n
								`^Du bekommst `%'.$gems.' `^Edelsteine!
								'.($session['user']['turns']>0?'`n`^Du verlierst `%'.($session['user']['turns']>=3?'3':$session['user']['turns']).' `^Waldk�mpfe!':'');
								
					$session['user']['gems'] += $gems;
					$session['user']['hitpoints'] -= round($session['user']['hitpoints'] * 0.25);
					if($session['user']['turns'] > 0)
						$session['user']['turns'] -= $session['user']['turns'] >= 3 ? 3 : $session['user']['turns'];
					
					$session['user']['specialinc'] = '';
					break;
			}
		}
		break;
		
	case 'cry':
		$count = $_GET['count'];
		$count++;
		
		if($count == 3) {
			$str_out .= '`&Du willst gerade mit schreien und jammern anfangen, 
						 als deine Zellent�re auch schon weit aufgesto�en wurde. Vor dir steht der Kommandant, welcher dich vorher gefangen genommen 
						 hatte. Er verzieht kurz sein Gesicht, schaut auf dich herab und meint dann. `n
						 `$"Ok '.($session['user']['sex']?'M�del, der Prinz':'Bursche, die Prinzessin').' hat uns gesagt was passiert ist. Also raus hier." `n
						 `&Wieder wirst du unsanft gepackt und einige Augenblicke sp�ter stehst du vor der Burg, wo du anscheinend hinverfrachtet wurdest. `n
						 Dankbarkeit wird bei dir zwar anders definiert, aber du willst auch nicht wieder zur�ck in den Kerker, au�erdem hast du aus der Sache wenigstens etwas gelernt. `n`n
						 '.($session['user']['turns']>0?'Der Weg zum Wald ist allerdings weit und so wird es eine ganze Weile dauern, bis du unbeschadet zur�ck bist... `n`n`n
						 `^Du verlierst `%'.($session['user']['turns']>=3?'3':$session['user']['turns']).' `^Waldk�mpfe!':'').'
						 `n`^Du bekommst `%5% `^Erfahrung!';
			
			$session['user']['experience'] += round($session['user']['experience'] * 0.05);
			if($session['user']['turns'] > 0)
				$session['user']['turns'] -= $session['user']['turns'] >= 3 ? 3 : $session['user']['turns'];
			
			$session['user']['specialinc'] = '';
		}
		else {
			switch(e_rand(1, 6)) {
				case 1: case 2:
					// LP-Verlust + WK-Verlust
					$str_out = '`&Du r�ttelst an den St�ben deiner Zellent�re und schreist aus vollem Hals, dass du hier raus willst, 
								und sowieso zu unrecht eingesperrt wurdest. Eine ganze Weile rufst du schon und nichts tut sich, bis schlie�lich 
								ein lautes Stampfen aus einem Ende des Kerkerganges zu h�ren ist. Ein wenig sp�ter baut sich ein riesiger Troll vor 
								deiner Zellent�re auf. `n
								`2"Warum gefangene Menschlein immer so laaauuut??"`&, gr�hlt er dir entgegen und verteilt dabei m�chtig Spucke �ber dein
								Gesicht. `2"Grombargh will RUUHEE!!" `&Und damit du auch wirklich ruhig bist, klopft dir der Troll gleich einmal mit der flachen Seite 
								seiner Hellebarde kr�ftig auf die Finger, mit denen du noch immer das Gitter festh�lst. `n
								So etwas tut weh'.($session['user']['turns']>0?' und die Aktion hat Zeit gekostet. `n`n`n
								`^Du verlierst `%1 `^Waldkampf! `n':'. `n`n`n').'
								`^Du verlierst `%10% `^deiner Lebenspunkte! `n';
					
					$session['user']['hitpoints'] -= round($session['user']['hitpoints'] * 0.1);
					if($session['user']['turns'] > 0)
						$session['user']['turns']--;
					break;
				
				case 3: case 4: case 5:
					// WK-Verlust
					$str_out = '`&Du r�ttelst an den St�ben deiner Zellent�re und schreist aus vollem Hals, dass du hier raus willst, 
								und sowieso zu unrecht eingesperrt wurdest. Eine ganze Weile rufst du schon und nichts tut sich, bis schlie�lich 
								ein lautes Stampfen aus einem Ende des Kerkerganges zu h�ren ist. Ein wenig sp�ter baut sich ein riesiger Troll vor 
								deiner Zellent�re auf. `n
								`2"Warum gefangene Menschlein immer so laaauuut??"`&, gr�hlt er dir entgegen und verteilt dabei m�chtig Spucke �ber dein
								Gesicht. `2"Grombargh will RUUHEE!!" `&Du widersprichst dem Troll lieber nicht und ziehst dich erst einmal etwas ruhiger 
								ins Zelleninnere zur�ck. `n`n
								'.($session['user']['turns']>0?'Die Aktion hat doch Zeit gekostet. `n`n`n
								`^Du verlierst einen Waldkampf':'');
					
					if($session['user']['turns'] > 0)
						$session['user']['turns']--;
					break;
				
				case 6:
					// Edelstein-Gewinn + LP-Verlust + WK-Verlust
					$str_out = '`&Du r�ttelst an den St�ben deiner Zellent�re und schreist aus vollem Hals, dass du hier raus willst, 
								und sowieso zu unrecht eingesperrt wurdest. Eine ganze Weile rufst du schon und nichts tut sich, bis schlie�lich 
								ein lautes Stampfen aus einem Ende des Kerkerganges zu h�ren ist. Ein wenig sp�ter baut sich ein riesiger Troll vor 
								deiner Zellent�re auf. `n
								`2"Warum gefangene Menschlein immer so laaauuut??"`&, gr�hlt er dir entgegen und verteilt dabei m�chtig Spucke �ber dein
								Gesicht. `2"Grombargh will RUUHEE!!" `&Und damit du auch wirklich ruhig bist, wirft dir der Troll etwas verdammt Hartes an 
								den Kopf. Du gehst erst einmal K.O., doch als du wieder aufwachst bemerkst du, dass das Harte ein Edelstein war! Leider tut 
								so ein Edelstein auch ziemlich weh'.($session['user']['turns']>0?' und die Aktion hat Zeit gekostet. `n`n`n
								`^Du verlierst `%1 `^Waldkampf! `n':'. `n`n`n').'
								`^Du verlierst `%25% `^deiner Lebenspunkte! `n
								`^Du bekommst `%1 `^Edelstein!';
							
					
					if($session['user']['turns'] > 0)
						$session['user']['turns']--;
					$session['user']['gems']++;
					$session['user']['hitpoints'] -= round($session['user']['hitpoints'] * 0.25);
 					
					break;
			}
			
			$session['user']['specialinc'] = 'kerker.php';
			addnav('Weiter', 'forest.php?op=injail&count='.$count);
		}
		break;
						   
	/**
	 * Specialanfang
	 */
	default:
		$str_out = '`&Gem�tlich schlenderst du durch den Wald, als pl�tzlich Hilfeschreie zu h�ren sind. 
				   Als gro�artig'.($session['user']['sex']?'e Heldin':'er Held').' �berlegst du dir nat�rlich, 
				   ob du der Sache nachgehst... `n`n
				   <a href="forest.php?op=help">Der Person nat�rlich helfen!</a> `n`n
				   <a href="forest.php?op=leave">Hilfeschreie sind dir definitiv zu hei�! Lieber gehen....</a> `n`n';
		addnav('', 'forest.php?op=help');
		addnav('', 'forest.php?op=leave');
		
		addnav('Aktionen');
		addnav('Helfen', 'forest.php?op=help');
		addnav('Zur�ckziehen', 'forest.php?op=leave');
		
		$session['user']['specialinc'] = 'kerker.php';
}

output($str_out, true);
?>