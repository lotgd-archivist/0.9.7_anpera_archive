<?
//Idee,Texte und Umsetzung � von Hecki
//Erstmals erschienen auf http://www.cop-logd.de
//Anleitung:
//In der shades.php folgenden Link an beliebiger stelle einf�gen:
//   addnav("Die H�lle","thehell.php");
//
// Da der Kiosk des Todes nich von mir ist,werde ich ihn auch nicht hier mitreinstellen.
// Demn�chst kommen noch ein paar weitere Geb�ude rein!
// Die Einbauanleitung f�r den Baum des Todes, steht in selbiger.
require_once "common.php";
if (e_rand(1,15)==1) redirect("thehell.php?op=magma");
output("`qDu verl�sst das Schattenreich durch einen dunklen Tunnel, am Ende des Tunnel erkennst du ein helles Licht... Das wird doch nicht etwa??...`n`n");
output("Doch deine Euphorie verfliegt als du bemerkst das das Licht nicht wei� ist, sondern gelb, r�tlich. Du stehst jetzt mitten in der H�lle und die Hitze ist schier unertr�glich.");
output("Du siehst einen reissenden Fluss aus Magma, von der Decke tropft ebenfalls Magma, du solltest aufpassen wo du hintrittst.");
output("Aber all das h�llt dich nicht ab, dich hier umzuschauen.`n`n");

addnav("Die H�lle");
addnav("Baum des Todes","treeofdeath.php");
//addnav("Kiosk des Todes","dink.php");

addnav("Tunnelwege");
addnav("`@Zur�ck zu den Schatten","shades.php");

if ($HTTP_GET_VARS[op]=="magma"){
      output("`$ Abgelenkt und unvorsichtig wie du bist siehst du nicht das sich ein Tropfen heisser Magma von der Decke l�st und auf dich zu rast.`n Erst als es zusp�t ist f�hlst du die Hitze die durch deinen toten K�rper wandert.`n`n`8 Du verlierst 5 Seelepunkte und solltest dich schleunigst vom Fleck bewegen!`n`n");
        $session[user][soulpoints] -= 5;
        //addnav("Zur�ck in die H�lle","thehell.php");
   if ( $session[user][soulpoints] <= 0 ) {
        output("`$ Dieser Tropfen hat dir den Rest gegeben!`n`8 Du verlierst alle restlichen Grabk�mpfe!`n`n`0");
        $session[user][gravefights] = 0;
        //addnav("Zur�ck in die H�lle","thehell.php");
        }
        }
addcommentary();
                viewcommentary("thehell","Gequ�lte Laute",10,"spricht gequ�lt",true);



if ($session[user][superuser]>=2){
addnav("Adminbereich");
addnav("@?Admin Grotte","superuser.php");
}
if ($session[user][superuser]) addnav("$?Neuer Tag","newday.php");

page_header("Die H�lle");
page_footer();
?>