<?php
/*################################################################
Skript : dragonmind.php
Ersteller: deZent / draKarr / Charon von www.plueschdrache.de
Version: 0.4
Beschreibung : siehe Regeln im Spiel ;-)
Gr�nde f�r den Chaoscode : Eigentlich sollte das Skript nur ein kleiner $_POST[]-Test werden... Am Ende wurds halt Mastermind.
				--> also nicht motzen --> besser machen 
Install:
1. dragonmind.php in root Ordner kopieren
2. neuen Ordner "dragonmind" im "images" Ordner erstellen und die beigef�gten Bilder rot.gif/gruen.gif hineinkopieren
3. checken ob die Datei "trans.gif" im "images" Ordner ist (im 0.97 LoGD standardm��ig enthalten)
3.1 JA --> gut so
3.2 Nein --> also reinkopieren

in "inn.php"
--------------------
addnav("DragonMind","dragonmind.php");

DATENBANK:
--------------------
Ich habe absichtlich auf $session['user'] Felder weitesgehend verzichtet.
Darum nutze ich das Feld "pqtemp" , das bereits in diversen Skripten angezogen wird.

Falls noch nicht vorhanden:
ALTER TABLE `accounts` ADD `pqtemp` TEXT NOT NULL


Viel Spa�,
deZent

P.S. WER W�RDE MAL EIN PAAR EINTR�GE F�R DIE TAUNTS TABELLE BEI ANPERA POSTEN!?! *Verdammt!*

#################################################################
Hinweise zu Version 0.4 (Charon):
- Code umfassend �berarbeitet und Cheatm�glichkeiten gefixt
- Anzahl der Positionen der Farbkombination ist jetzt einstellbar
#################################################################
*/

require_once "common.php";
page_header("Dragonmind");

output("`c`b`&Dragonmind V0.4 `0`b`c`n`n");

   $__anzahl_versuche 	= 10;		// Anzahl der erlaubten Rate-Versuche pro Spiel
   $__anzahl_farben	= 10;		// Anzahl der unterschiedlichen Farben, aus denen die Kombination bestehen kann [1-10]
   $__anzahl_positionen	= 4;		// Anzahl der Stellen der Farbkombination, Achtung: darf nicht gr��er $__anzahl_farben sein!!!
   $__einsatz		= 250;   	// Einsatz Gold
   $__gewinn		= 500;   	// Gewinn (wird zuz�glich Einsatz ausgezahlt), Achte darauf, dass der Gewinn nicht zu extrem wird, da es 
						//	Programme gibt, die Mastermind in 5 Z�gen l�sen. Somit Cheat-Gefahr...
   $farbe[0]['farbe']="#800000";
   $farbe[0]['name']="dunkelrot";

   $farbe[1]['farbe']="#008000";
   $farbe[1]['name']="gr�n";

   $farbe[2]['farbe']="#E6E629";
   $farbe[2]['name']="gelb";

   $farbe[3]['farbe']="#0000F0";
   $farbe[3]['name']="blau";

   $farbe[4]['farbe']="#800080";
   $farbe[4]['name']="lila";

   $farbe[5]['farbe']="#FF0000";
   $farbe[5]['name']="rot";

   $farbe[6]['farbe']="#14EAD3";
   $farbe[6]['name']="t�rkis";

   $farbe[7]['farbe']="#F26A10";
   $farbe[7]['name']="orange";

   $farbe[8]['farbe']="#00A8FF";
   $farbe[8]['name']="hellblau";

   $farbe[9]['farbe']="#FFFFFF";
   $farbe[9]['name']="wei�";


if ($_GET['op']=='')
{
	addnav("Dragonmind");
	output("`7Du betrittst einen etwas abgeschiedenen Bereich der Kneipe.`nIn feurig roten Lettern steht an der Wand `n`n
			<font size=+1>`b`\$D`4ragon`\$M`4ind`b </font>`n`n`7 geschrieben.`n`n",true);
			
	if (($__anzahl_farben<$__anzahl_positionen)||($__anzahl_farben>count($farbe))){
		output("Der Barkeeper sch�ttelt den Kopf: `7\"`9Hier k�nntest du spielen, wenn der Admin die Hinweise gelesen und das Spiel richtig konfiguriert h�tte....`7\"");
	} elseif ($session['user']['gold']<$__einsatz){
		output("Der Barkeeper raunzt dich an: `7\"`9Hier kannst du um ein paar Goldst�cke spielen. Der Spieleinsatz ist jedoch $__einsatz Gold.`n Soviel Gold hast du wohl nicht! *HARHAR*`7\"");
	} else {
		output("Der Barkeeper raunzt dich an: `7\"`9Hier kannst du um ein paar Goldst�cke spielen. Der Spieleinsatz ist jedoch $__einsatz Gold.`7\"");
		addnav("Spiel Spielen","dragonmind.php?op=new");
	}
	addnav("Regeln","dragonmind.php?op=regeln");
	addnav("Zur�ck");
	addnav("Zur Kneipe","inn.php");
}
elseif($_GET['op']=='new')
{
	$session['user']['gold']-=$__einsatz;
	
	addnav("<center>Du hast noch</center>","",true);
	addnav("<center><b>$__anzahl_versuche</b> Versuche</center>","",true);

	// farbkombi festlegen
	$zuf=array();
	for ($i=0;$i<$__anzahl_positionen;$i++){
		while(true){
			$check=mt_rand(0,($__anzahl_farben-1));
			if(array_search($check,$zuf)===false){
				$zuf[$i]=$check;
				break;
			}
		}
		$zufall[$i]['farbe']=$farbe[$check]['farbe'];
		$zufall[$i]['name']=$farbe[$check]['name'];
	}
	$session['user']['pqtemp']=serialize($zufall);

	output("`7 W�hle Deine Farben:`n`n<form action='dragonmind.php?op=play&try=0' method='post' name='f1'>",true);
		
	for ($i=0;$i<$__anzahl_positionen;$i++){
		output("<select name='auswahl[".$i."]'>",true);
		for ($j=0;$j<$__anzahl_farben;$j++){
			output("<option value='".$farbe[$j]['farbe']."' style='background-color:".$farbe[$j]['farbe']."'>".$farbe[$j]['name']."</option>",true);
		}
		output("</select>",true);
	}

	output("<br><br><input type='submit' name='rate' value='Tipp abgeben'></form>",true);
	addnav("","dragonmind.php?op=play&try=0");
}
elseif($_GET['op']=='play')
{
	// erstmal die gesuchten farben wieder auslesen
	$farben=unserialize($session['user']['pqtemp']);
	
	// mal schauen ob er was erraten hat.
	$rs=0; // richtige stelle  + richtige Farbe
	$rf=0; // richtige farbe
	
	// check ob richtige farbe an richtiger stelle
	for ($i=0;$i<$__anzahl_positionen;$i++){
		for ($j=0;$j<$__anzahl_positionen;$j++){
			if ($_POST['auswahl'][$i]==$farben[$j]['farbe']){
				if ($i==$j){
					$rs++;
					$farben[$j]['farbe']='';
				}
			}
		}
	}
   
	// richtige farbe aber falsche stelle
	for ($i=0;$i<$__anzahl_positionen;$i++){
		for ($j=0;$j<$__anzahl_positionen;$j++){
			if ($_POST['auswahl'][$i]==$farben[$j]['farbe']){
				$rf++;
				$farben[$j]['farbe']='';
			}	
		}
	}
	
	$farben=unserialize($session['user']['pqtemp']);
   
	// Farbpunkte f�r aktuellen rateversuch zusammenbauen
	for ($i=0;$i<$rs;$i++){
		$bilder_aktuell.='<img src="./images/dragonmind/gruen.gif" alt="Richtige Farbe an richtiger Stelle">';
	}
	for ($i=0;$i<$rf;$i++){
		$bilder_aktuell.='<img src="./images/dragonmind/rot.gif" alt="Richtige Farbe an falscher Stelle">';
	}

	if ($rs==$__anzahl_positionen){
		$gewonnen=true;
	}  // player hat gewonnen
   
	$nexttry=$_GET['try']+1;
	
	if (($nexttry<$__anzahl_versuche) && ($gewonnen!=true)){
		addnav("","dragonmind.php?op=play&try=$nexttry");
	}
	output("<form action='dragonmind.php?op=play&try=$nexttry' method='post' name='f1'>",true);
	
	// L�sung anzeigen, wenn gewonnen oder zu viele Versuche
	if (($nexttry>=$__anzahl_versuche) || $gewonnen){
		output("<table>
			   <tr><td colspan='".($__anzahl_positionen+1)."' align='center' style='background-color:#AFDB02;color:#000000;font-weight:bold;'>L�SUNG</td></tr>
			   <tr>",true);	   
		for ($k=0;$k<$__anzahl_positionen;$k++){
			output("<td bgcolor=".$farben[$k]['farbe']."><img src='./images/trans.gif' width='83' height='10'></td>",true);
		}
		output("<td>L�sung</td>
			   </tr><tr>",true);
	}
	else{
		output("<table><tr>",true);
	}
	
	// Tabellenkopf
	for ($k=0;$k<$__anzahl_positionen;$k++){
		output("<td style='background-color:#AFDB02;color:#000000;font-weight:bold;' align='center'>Farbe ".($k+1)."</td>",true);
	}
	output("<td style='background-color:#AFDB02;color:#000000;font-weight:bold;' align='center'>Info</td></tr>",true);
   
	// vorherige Versuche anzeigen
	for ($i=0;$i<$_GET['try'];$i++)
	{
		// letzte auswertung auslesen und Bilder -code schreiben.
		$auswertung = explode("-",$_POST['tip'][$i]);
		$bilder='';
		
		for ($k=0;$k<$auswertung[0];$k++){
			$bilder.='<img src="./images/dragonmind/gruen.gif" alt="Richtige Farbe an richtiger Stelle">';
		}
		for ($k=0;$k<$auswertung[1];$k++){
			$bilder.='<img src="./images/dragonmind/rot.gif" alt="Richtige Farbe an falscher Stelle">';
		}

		output("<tr>",true);
		for ($k=0;$k<$__anzahl_positionen;$k++){
			output("<td bgcolor=".$_POST['versuche'][$i][$k].">&nbsp;</td>",true);
		}
		output("<td>$bilder</td></tr>",true);
			  
		for ($k=0;$k<$__anzahl_positionen;$k++){
			output("<input type='hidden' name='versuche[".$i."][".$k."]' value='".$_POST['versuche'][$i][$k]."'> ",true);
		}
		output("<input type='hidden' name='tip[".$i."]' value='".$_POST['tip'][$i]."'> ",true);
	}
      
	// aktuelle Auswertung anzeigen
	output("<tr>",true);
	for ($k=0;$k<$__anzahl_positionen;$k++){
		output("<td bgcolor=".$_POST['auswahl'][$k].">&nbsp;</td>",true);
	}
	output("<td>$bilder_aktuell</td></tr>",true);

	for ($k=0;$k<$__anzahl_positionen;$k++){
		output("<input type='hidden' name='versuche[".$i."][".$k."]' value='".$_POST['auswahl'][$k]."'>",true);
	}
	output("<input type='hidden' name='tip[".$i."]' value='".$rs."-".$rf."'> ",true);

	// Auswahlboxen anzeigen, wenn noch nicht gewonnen und noch Versuche offen
	if (($nexttry<$__anzahl_versuche) && ($gewonnen!=true))
	{
		output("<tr>",true);
		for ($i=0;$i<$__anzahl_positionen;$i++){
			output("<td><select name='auswahl[".$i."]'>",true);
			for ($j=0;$j<$__anzahl_farben;$j++){
				output("<option value='".$farbe[$j]['farbe']."' style='background-color:".$farbe[$j]['farbe']."' ".($_POST['auswahl'][$i] == $farbe[$j]['farbe']?"selected":"").">"
					.$farbe[$j]['name']."</option>",true);
			}
			output("</select></td>",true);
		}
		output("</tr></table><br><br>
			   <input type='submit' name='rate' value='Tipp abgeben'>
			   </form>",true);
   
		$versuche=$__anzahl_versuche-$nexttry;
		
		if ($versuche!=0){
			if ($versuche>1){
				addnav("<center>Du hast noch</center>","",true);
				addnav("<center><b>$versuche</b> Versuche</center>","",true);
			}else{
				addnav("<center>Dies ist deine <b>letzte Chance</b></center>","",true);
			}
		}
	}
	else //fertig
	{ 
		output("</table></form>",true);
		//schauen ob gewonnen oder Ende
		if ($gewonnen){
			output("<h1>DU HAST GEWONNEN</h1>",true);
			addnav("Gewinn abholen","dragonmind.php?op=gewinn");
		}
		else{
			output("<h1>DU HAST VERLOREN</h1>",true);
			if($session['user']['gold']>=$__einsatz){
				addnav("Dragonmind");
				addnav("Erneut spielen","dragonmind.php");
			}
			addnav("Zur�ck");
			addnav("Zur Kneipe","inn.php");
		}
		$session['user']['pqtemp']="";		
	}
}
elseif($_GET['op']=='gewinn')
{
	if($session['user']['gold']>=$__einsatz){
		addnav("Dragonmind");
		addnav("Erneut spielen","dragonmind.php");
	}
	
	$session['user']['gold']+= $__gewinn+$__einsatz;

	output("`$ Stolz gehst du zur�ck zur Kneipe.");

	addnav("Zur�ck");
	addnav("Zur Kneipe","inn.php");
}
elseif($_GET['op']=='regeln')
{
	addnav("Zur�ck","dragonmind.php");
	output("`c`b`&Dragonmind Regeln `0`b`c`n`n
		`Q ### `2allgemeiner Ablauf des Spiels `Q####`n`n
		`7Das Ziel des Spiels ist das Erraten der Farbkombination, die der Spielf�hrer ausgew�hlt hat.`n
		Jede Farbe kommt nur EINMAL vor!`n
		Du w�hlst in den Drop-Down Feldern deine Farbkombination aus und dr�ckst auf 'raten'.`n
		Daraufhin erscheint deine Auswahl. Dahinter erscheinen farbige Punkte.`n`n

		Ein `$ roter Punkt `7 gibt an, dass eine deiner Farben in der Farbkombination des Spielf�hrers vorkommt.`n
		Ein `@ gr�ner Punkt `7 gibt an, dass eine deiner Farben sogar an der richtigen Stelle ist.`n
		`qKein Punkt `7 hinter deiner Auswahl zeigt dir, dass keine deiner Farben in der Auswahl vorkommt.`n`n

		Die Reihenfolge der Punkte hat nichts mit der Reihenfolge deiner Auswahl zu tun!`n`n
		Du hast maximal $__anzahl_versuche Versuche die richtige Auswahl zu erraten.`n`n
		P.S.  Bei 10 Farben gibt es 5040 verschiedene Farbkombinationen... Nur durch probieren wirst du es wohl eher nicht schaffen.`n`n
		www.plueschdrache.de
		");
}

page_footer();
?>