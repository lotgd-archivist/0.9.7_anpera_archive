<?php
/*

         *  *         * *
      *  BY   *    * AND  *
    *  Mr edah  *  Zudu    *
  *     www.edahnien.de     *
  * www.gruebelz.com/logd  *
   *  Boindil und Zudus   *
    *     Abenteuer      *
      * Marshmallow's  *
        * im Kamin   *
          *  V 0.0 *
            *   *
              *

*/
$res = 1 ;   #  edahs Res mod vorhanden ( 0 =ja 1 = nein)
switch(isset($_GET['op']) ? $_GET['op'] : '')
{
    case '':
        $session['user']['specialinc']="Zubo_4.php";
        $out .='`2Gedankenverloren streifst du durch den Wald. Als du pl�tzlich wildes Geschrei h�rst, siehst du dich um. Nichts zu sehen. Nur das dumpfe Schreien ist zu h�ren. Als du einen Baum siehst, der etwas merkw�rdig ausschaut, bewegst du dich auf diesen zu. Komisch, denkst du. Der Baum hat einen Kamin! Jedoch ist dieser Kamin mit einer T�r verschlossen und daraus kommt dieses komische Geschrei... Willst du die T�r �ffnen?';
        addnav("Nicht �ffnen","forest.php?op=notopen");
        addnav("�ffnen","forest.php?op=open");
    break;
    case 'notopen':
        $session['user']['specialinc']='';
        $out .='Du entscheidest dich die T�r nicht zu �ffnen. Aus Charme, du k�nntest Jemanden in Stich gelassen zu haben, verlierst du jedoch 5 Charmepunkte.';
        $session['user']['charm']-=5;
        addnav("weiter","forest.php");
    break;
    case 'open':
        $session['user']['specialinc']="Zubo_4.php";
        $out .='Du nimmst all\' deinen Mut zusammen und �ffnest die T�r. Eine schwarze Rauchwolke kommt herrausgequollen und du beginnst wie wild zu husten. Als der Rauch sich verzogen hast, siehst du zwei Gestallten v�llig verrust dastehen mit St�ckern und verbrannten Marshmallow daran. `3Eine tolle Idee, Boindil `2sagt der Gr��ere von Beiden. Beim Namen Boindil f�llt es dir, wie Schuppen von den Augen. Vor dir stehen Zudu & Boindil! `tEs h�tte ja klappen k�nnen, die Marshmallow zu r�sten. Wusste ich, dass die T�r bei einem kleinen Windsto� zugeht? `2 Nun bekommst du es doch leicht mit der Angst zu tun. Du wei�t: Wer Zudu & Boindil begegnet lebt nicht gerade in Sicherheit, doch schon ist es zu sp�t: Zudu entdeckt dich und grinst dich freundlich an.';
        addnav("Weiter","forest.php?op=weiter&id=1");
    break;
    case 'weiter':
        switch($_GET['id'])
        {
            case '1':
                 $session['user']['specialinc']="Zubo_4.php";
                 $out .="`3Hallo ".$session['user']['name']." `3! Lange habe ich dich nicht mehr gesehen! `2Sagt Zudu zu dir. Du blickst zu Boindil, der versucht den z�hen Marshmallow von Stock zu beissen und reissen. Langsam richtest du deine Aufmerksamkeit wieder auf Zudu `3M�chtest du uns nicht helfen ein paar Marshmallows zu r�sten? Mit dem Depp von Zwerg komme ich nicht weiter! `2Sofort schreit der Zwerg auf `tDas ist ja wohl die H�he! `2Er ist so sauer, dass bei jedem Wort sein Bart erzittert und du dir ein Lachen verkneifen musst, da da ein St�ck vom Marshmallow h�ngt. `tIch und ein Depp? Du bist der unf�higste Elf, den ich jeh gesehen habe! Von wegen, bloss nicht schmutzig werden! `2 Ein paar Kopfn�sse sp�ter, fragt dich Zudu erneut `3Was ist nun? `2Du schaust die Beiden an... Und jetzt?";
                 addnav("Nicht helfen","forest.php?op=weiter&id=2");
                 addnav("Helfen","forest.php?op=weiter&id=3");
            break;
            case '2':
                 $out .="`2Du sch�ttelst den Kopf. Der kleine Boindil, der sowieso schon auf 180 ist, nimmt seinen Marshmallowst�ckchen und durchbohrt deinen Bauch";
                 switch(e_rand(1,4))
                 {
                     case '1':
                         $out .='Du bist nat�rlich nicht gleich tot, darfst aber schonmal Gefallen sammeln!';
                         $session['user']['alive'] = false;
                         $session['user']['hitpoints'] = 0;
                         addnav("Zu den News","news.php");
                         $session['user']['specialinc']="";
                         addnews("".$session['user']['name']."`z wurde von einem Marshmallowst�ckchen durchbohrt!");
                     break;
                     case '2':
                     case '3':
                         $out .='Du verlierst die H�lfte deiner Lebenspunkte. Weil du durch die gro�e Wunde viel Blut verloren hast, kannst du keine weiteren Waldk�mpfe mehr absolvieren.';
                         $hit = $session['user']['hitpoints'] / 2 ;
                         $session['user']['hitpoints'] = $hit;
                         $session['user']['turns'] = 0;
                         $session['user']['specialinc']="";
                         addnav("Weiter","forest.php");
                         addnews("".$session['user']['name']."`zsah man stark blutend und mit einem Marshmallowst�ckchen im Bauch im Wald herummirren.");
                     break;
                     case '4':
                         $out .='Du bist tot! Zu allem �berfluss nehmen Boindil & Zudu all\' dein Gold und '.($res?"dein Holz":"deine Edelsteine").' . `tKomm, wir kaufen neue Marshmallows und machen uns ein neues Feuer.';
                         addnews("".$session['user']['name']." wurde mit einem Marshmallowst�ckchen aufgespie�t.");
                         addnav("Zu den News","news.php");
                         $session['user']['alive'] = false;
                         $session['user']['hitpoints'] = 0;
                         $session['user']['gold'] = 0;
                         if ($res ==0 )
                         {
                               $acctid = $session['user']['acctid'];
                               $sql = "UPDATE res SET holz='0' WHERE acctid='$acctid'";
                               db_query($sql);
                         }else{
                               $session['user']['gems']=0;
                         }
                 }
            break;
            case '3':
                $out .='Du stimmst ein. Was ist an Marshmallow r�sten schon gef�hrlich?';
                 switch(e_rand(1,2))
                 {
                     case '1':
                         $out .='Du beginnst im Kamin ein Feuer zu entfachen. Von hinten dr�ngelt Boindil `tSchneller ich habe hunger. `2Du gibst dir M�he, doch der Zwerg h�rt einfach nicht auf dich zu dr�ngen. Als das Feuer entlich brennt, schubst er dich zur Seite um sein Marshmallow zu r�sten. Du verlierst das Gleichgewicht und f�llst ins Feuer';
                         switch(e_rand(1,2))
                         {
                             case '1':
                                  $out .='Du verbrennst j�mmerlich. Du verlierst KEIN Gold & Edelsteine. Boindil bedauert alles und du bekommst ein paar Erfahrungspunkte!`n Ab jetzt kannst du wenigstens von dir behaupten: Du kannst Feuer machen... Nur mit den Marshmallow r�sten... Das musst du nochmal �berpr�fen.';
                                  $gesamtwert = $session['user']['experience'];
                                  $grundwert = $gesamtwert * 20 / 100 ;
                                  $session['user']['experience']+= $grundwert;
                                  addnews("".$session['user']['name']."`zwurde vom gierigen Boindil ins Feuer geschubst. So schnell macht ".$session['user']['name']." kein Feuer mehr!");
                                  addnav("Zu den News","news.php");
                                  $session['user']['alive'] = false;
                                  $session['user']['hitpoints'] = 0;
                             break;
                             case '2':
                                  $out .='Du verlierst fast alle deine Lebenspunkte, beleibst jedoch am Leben! Du nimmst dir ein Marshmallow und r�stest diesen. Als du diesen isst, f�hlst du dich viel lebendiger! Die erh�lst 2 permanente Lebenspunkte und kriegst 5 Waldk�mpfe hinzu.';
                                  $session['user']['hitpoints'] = 1;
                                  $session['user']['maxhitpoints'] += 2;
                                  $session['user']['turns'] += 5;
                                  addnews("".$session['user']['name']."`z hat mit Boindil & Zudu Marshmallows gegessen.");
                                  addnav("Weiter","forest.php");
                                  $session['user']['specialinc']="";
                         }
                     break;
                     case '2':
                         $out .='Du beginnst im Kamin ein Feuer zu entfachen. Von hinten belastet dich Zudu mit seinen "schlauen" Ratschl�gen, wie du es angeblich besser machen kannst. Nach einiger Zeit bist du davon so genervt, dass du auf ihn h�rst. Pl�tzlich wird die Flamme so gro�, dass es Boindil seinen Bart versenkt. Auf den ersten Blick denkst du dir, dass er ohne Bart garnichtmal so schlecht aussieht, was aber Boindil anscheinent garnicht so findet. `tDamit ich den Bart so lange gekriegt habe, lebe ich schon 150 Jahre! `2sagt er grimmig `3Du siehst eher aus wie 300 `2sp�ttelt Zudu noch von hinten, was die Laune von Boindil nicht gerade verbesserte.';
                         switch(e_rand(1,2))
                         {
                             case '1':
                                  $out .='Du �berlegst einen Moment, ob du Boindil sagen solltest, wie gut er doch aussieht, als du dich doch entscheidest wegzulaufen. Zum Gl�ck ist Boindil nicht der Schnellst und du entkommst!
                                       `n Du bist aber so ersch�pft, dass du 5 Waldk�mpfe verlierst. Jedoch hat deine Angst Adrenalin freigesetzt, so erh�lst du 2 permanente Lebenspunkte.';
                                  $session['user']['turns'] -= 5;
                                  $session['user']['maxhitpoints'] += 2;
                                  addnews("".$session['user']['name']."`z hat Boindil seinen Bart abgebrannt und lief um sein Leben!");
                                  addnav("Weiter","forest.php");
                                  $session['user']['specialinc']="";
                             break;
                             case '2':
                                  $out .='Boindil packt dich und reisst dir deine Haare aus. Er klebt sie sich um den Mund. Es sah total verr�ckt aus! Boindil schien zufrieden. Du bist jedenfalls sauer und verpasst Boindil eine Kopfnuss um dann wegzugehen.
                                          `n Ohne Haare siehst du mies aus!
                                          `n Du verlierst 5 Charmepunkte, daf�r erh�lst du einen Angriffpunkt durch deine Wut. Du erh�lst Erfahrungspunkte. Das machst du nie wieder!';
                                  $session['user']['attack'] += 1;
                                  $gesamtwert = $session['user']['experience'];
                                  $grundwert = $gesamtwert * 10 / 100 ;
                                  $session['user']['experience']+= $grundwert;
                                  addnews("`z Boindil riss ".$session['user']['name']." all' seine Haare aus.");
                                  addnav("Weiter","forest.php");
                                  $session['user']['specialinc']="";
                         }
                 }
        }
}
output("$out");
?>
