<?php
/*
 New Code By Mr edah,Thealon & Rikkarda
 www.edahnien.de, www.gruebelz.com & www.silienta-logd.de
 Umsetzung altes skript by Tiger313
 Idee: Wolf
 Fragen / antworten von Monkey island edit by Tiger313
 Neue Fragen By Comunities of
   www.gruebelz.com
   www.edahnien.de
   www.radirap.de.vu
   www.fargoth.de

Changelog:
SQL nicht mehr ben�tigt! By Mr edah
�berarbeiteter Code! By Mr edah
geschlechtsspezifikation by Rikkarda@silienta-logd.de 28072007
*/
// Edahniens easy color edit
define ('WBEPICOLORSTANDART','`3'); #stadartfarbe
define ('WBEPICOLORPI','`4'); #farbe fuer priat
define ('WBEPICOLORPISAY','`9'); #farbe wenn pirat was sagt
define ('WBEPICOLORSTANDART2','`7'); #standart 2
define ('WBEPICOLORPUNKTE','`q'); #punkt emeldung
define ('WBEPICOLORZAHL','`4'); #farbe fuer zahlen

if (!isset($session)) exit();
switch(isset($_GET['op']) ? $_GET['op'] : '')
{
    case "";
       $_SESSION['session']['bpirat']='0';
       $_SESSION['session']['buser']='0';
       $out .=''.WBEPICOLORSTANDART.' Auf Deiner Suche kommt dir auf einmal ein '.WBEPICOLORPI.'Pirat '.WBEPICOLORSTANDART.'entgegen.`n';
       $out .='Er scheint ziemlich ver�rgert zu sein. Du versuchst, ihn nicht direkt anzuschauen.`n';
       $out .='Als du ihn aus Versehen beim Vorbeilaufen ganz leicht ber�hrst, dreht der Pirat durch.`n';
       $out .='Er fordert dich zu Kampf heraus und du ziehst sofort dein Schwert aber der '.WBEPICOLORPI.'Pirat '.WBEPICOLORSTANDART.'zeigt dir einen Vogel und meint.`n';
       $out .=''.WBEPICOLORPISAY.'"Was willst du mit dem Zahnstocher? Nur Schw�chlinge wie du brauchen Waffen. Die st�rkste Waffe sind `bW�RTER`b also k�mpfe mit denen oder garnicht.'.WBEPICOLORSTANDART.'"`n`n';
       $out .=''.WBEPICOLORSTANDART.' Was machst du?`n';
       addnav("K�mpfen","forest.php?op=kampf2");
       addnav("zur�ck in den Wald","forest.php?op=wald");
       $session['user']['specialinc']="beleidgterpirat.php";
       $_SESSION['session']['richtigeaw']='';
    break;
    case 'wald';
       $out .=''.WBEPICOLORSTANDART.'Du ignorierst den Piraten und gehst zur�ck in den Wald';
       addnav("weiter","forest.php");
       $session['user']['turns'] --;
       $session['user']['specialinc']='';
       addnews("".WBEPICOLORSTANDART2." ".$session['user']['name']."".WBEPICOLORSTANDART2." war zu FEIGE gegen den ".WBEPICOLORPISAY."Piraten ".WBEPICOLORSTANDART2.", in einem Kampf ohne Waffen, anzutreten");
    break;
    case 'kampf';
        if ($_SESSION['session']['richtigeaw']!=$_GET['id']){
                $_SESSION['session']['bpirat']++;
                $session['user']['specialinc']="beleidgterpirat.php";
                $out .=''.WBEPICOLORPISAY.'HaHaHA Punkt f�r mich!`n`n';
                $out .="".WBEPICOLORPUNKTE."Neuer stand:`n ".WBEPICOLORZAHL."".$_SESSION['session']['bpirat']."".WBEPICOLORPUNKTE." Punkte Pirat `n ".WBEPICOLORZAHL."".$_SESSION['session']['buser']."".WBEPICOLORPUNKTE." Punkte Du!`n`n";                if ($_SESSION['session']['bpirat'] <5)
                {
                    addnav("weiter","forest.php?op=kampf2");
                }else{
                    addnav("weiter","forest.php?op=ergebnis");
                }
        }else{
                $_SESSION['session']['buser']++;
                $session['user']['specialinc']="beleidgterpirat.php";
                $out .=''.WBEPICOLORPISAY.'Oh mist das war gemein, Punkt f�r dich!`n`n';
                $out .="".WBEPICOLORPUNKTE."Neuer stand:`n ".WBEPICOLORZAHL."".$_SESSION['session']['bpirat']."".WBEPICOLORPUNKTE." Punkte Pirat `n ".WBEPICOLORZAHL."".$_SESSION['session']['buser']."".WBEPICOLORPUNKTE." Punkte Du!`n`n";
                if ($_SESSION['session']['buser'] < 5)
                {
                     addnav("weiter","forest.php?op=kampf2");
                 } else {
                     addnav("weiter","forest.php?op=ergebnis");
                 }
     }
     break;
     case'kampf2';
          if ($_SESSION['session']['richtigeaw']==''){
               $out .=''.WBEPICOLORSTANDART.' Du packst dein Schwert wieder weg.`n';
               $out .=''.WBEPICOLORSTANDART.' Der Pirat stellt sich dir gegen�ber auf,r�uspet sich noch mal und f�ngt an!`n`n';
          }
          $session['user']['specialinc']="beleidgterpirat.php";

$fragen = array(1 =>'Mein Schwert wird dich aufspie�en wie ein Schaschlik!',
                       	2 =>'Deine Fuchtelei hat nichts mit Fechtkunst zu tun!',
                       	3 =>'Niemand wird mich verlieren sehen, auch du nicht.!',
                       	4 =>'Meine Gro�mutter hat mehr Kraft als du Wicht!',
                       	5 =>'Nach diesem Spiel tr�gst du den Arm in Gips.',
                       	6 =>'Aargh ... ich zerrei�e deine Hand in eine Million Fetzen.',
                       	7 =>'Aaagh ... hey, schau mal da dr�ben!',
                       	8 =>'Aargh ... ich werde deine Knochen zu Brei zermalmen.',
                       	9 =>'Ich kenne L�use mit st�rkeren Muskeln.',
                       	10 =>'Alle Welt f�rchtet die Kraft meiner Faust.',
                       	11 =>'Ungh ... gibt es auf dieser Welt eine gr��ere Memme als dich?',
                       	12 =>'Ungh ... du bist das h��lichste Wesen, da� ich jemals sah ... grr.',
                       	13 =>'Ungh ... viele Menschen sagen, meine Kraft ist unglaublich.',
                       	14 =>'Ungh ... Ich hab\' mit diesen Armen schon Kraken bezwungen.',
                       	15 =>'Ungh, ha ... sehe ich da Spuren von Angst in deinem Gesicht?',
                       	16 =>'Ich hatte mal einen Hund, der war kl�ger als du.',
                       	17 =>'Du hast die Manieren eines Bettlers.',
                       	18 =>'Jeder hier kennt dich als unerfahrenen Dummkopf.',
                       	19 =>'Du k�mpfst wie ein dummer Bauer.',
                       	20 =>'Meine Narbe im Gesicht stammt aus einem harten Kampf.',
                       	21 =>'Menschen fallen mir zu F��en, wenn ich komme.',
                       	22 =>'Dein Schwert hat schon bessere Zeiten gesehen.',
                       	23 =>'Du bist kein Gegner f�r mein geschultes Gehirn.',
                       	24 =>'Tr�gst du immer noch Windeln.',
                       	25 =>'An deiner Stelle w�rde ich zur Landratte werden.',
                       	26 =>'Alles, was du sagst, ist dumm.',
                       	27 =>'Hast du eine Idee, wie du hier lebend herauskommst?',
                       	28 =>'Mein Schwert wird dich in 1000 St�cke rei�en.',
                       	29 =>'Niemand wird sehen, da� ich so schlecht k�mpfe wie du.',
                       	30 =>'Nach dem letzten Kampf war meine Hand blut�berstr�mt.',
                       	31 =>'Kluge Gegner laufen weg, bevor sie mich sehen.',
                       	32 =>'�berall in der Gegend kennt man meine Klinge.',
                       	33 =>'Bis jetzt wurde jeder Gegner von mir eliminiert!',
                       	34 =>'Du bist so h��lich wie ein Affe im Neglig�!',
                       	35 =>'Dich zu t�ten w�re eine legale Beseitigung!',
                       	36 =>'Warst Du schon immer so h��lich oder bis Du mutiert?',
                       	37 =>'Ich spie�\' Dich auf wie eine Sau am Buffet!',
                       	38 =>'Wirst Du laut Testament einge�schert oder einbalsamiert?',
                       	39 =>'Ein jeder hat vor meiner Schwertkunst kapituliert!',
                       	40 =>'Ich werde Dich richten - und es gibt kein Pl�doyer!',
                       	41 =>'Himmel bewahre! F�r einen Hintern w�re dein Gesicht eine Beleidigung!',
                       	42 =>'F�hl ich den Stahl in der Hand, bin ich in meinem Metier!',
		       	43 =>'Haben sich Deine Eltern nach Deiner Geburt sterilisiert?',
		       	44 =>'En garde! Touch�!',
		       	45 =>'�berall im Drachental wird mein Name respektiert!',
		       	46 =>'Niemand kann mich stoppen: mich - den Schrecken der See!',
		       	47 =>'Mein Minenspiel zeigt Dir meine Mi�billigung!',
		       	48 =>'Ganze Inselreiche haben vor mir kapituliert',
		       	49 =>'Du hast soviel Sexappeal wie ein Croupier!',
		       	50 =>'Bist Du das? Es riecht hier so nach Jauche und Dung!',
		       	51 =>'Wurdest Du damals von einem Schwein adoptiert?',
		       	52 =>'Auch wenn Du es nicht glaubst, aus Dir mach\' ich Haschee!',
		       	53 =>'Ich la�\' Dir die Wahl: erdolcht, erh�ngt oder guillotiniert!',
		       	54 =>'Dein Gepl�nkel bringt mich richtig in Schwung!',
		       	55 =>'Ich wei� nicht, welche meiner Eigenschaften Dir am meisten imponiert!',
		       	56 =>'Jetzt werde ich Dich erstechen, da hilft kein Proteg�e!',
		       	57 =>'Ist ein Blick in den Spiegel nicht jeden Tag f�r Dich eine Erniedrigung?',
		       	58 =>'Ich lauf\' auf gl�henden Kohlen und barfu� im Schnee!',
		       	59 =>'Du bist eine Schande f�r Deine Gattung, so dilettiert!',
			60 =>'Deine Mutter tr�gt ein Toupet!',
			61 =>'Durch meine Fechtkunst bin ich zum Siegen pr�destiniert!',
			62 =>'Es mit mir aufzunehmen gleicht einer Odysse!',
			63 =>'Mein Antlitz zeugt von edler Abstammung!',
			64 =>'Ungh ... Memmen wie dich vernasch\' ich zum Fr�hst�ck.',
			65 =>'Ich habe Muskeln an Stellen, von denen du nichts ahnst.',
			66 =>'Gib auf oder ich zerquetsch\' dich wie eine l�stige M�cke.',
			67 =>'Allein mit meinem Bart bin ich so Adrett...',
			68 =>'Ich k�nnte dich besiegen!',
			69 =>'Du hast dein Maul aber sehr weit offen',
			70 =>'Deine Frau hat mich zum St�hnen gebracht!',
			71 =>'Ungh ... Du bist ein gro�er Eierkopf.',
			72 =>'Willst Du h�ren, wie ich drei M�nner zugleich besiegte?',
			73 =>'Mit meinem Taschentuch werde ich Dein Blut aufwischen!',
			74 =>'Hast du mal Feuer?',
			75 =>'Dich zu t�ten wird eine Erl�sung f�r mich sein',
			76 =>'Ich werf dich in den See und ertr�nke dich',
			77 =>'Dein Geschlecht ist doch nicht echt, du gibst nur vor so zu sein',
			78 =>'Ich verfolge dich �berallhin',
			79 =>'Ich hol gleich meine Br�der..ach was, meine ganze Familie',
			80 =>'Ich geh�re zu den oberen Zehntausend du Nichts',
			81 =>'Du bist nicht besonders nett zu mir',
			82 =>'Lass uns etwas zusammen machen was mir sehr gef�llt',
			83 =>'Du hast die Wahl, arbeite beim Bauern oder tanze mit mir',
			84 =>'Warum bist du immer anderer Ansicht als ich?',
			85 =>'Du hast wirklich Mut mir immer noch ins Gesicht zu sehen',
			86 =>'Kannst du eigentlich gar nichts?',
			87 =>'Ich kenne einige Affen, die haben mehr drauf als du.',
			88 =>'Mein Name ist in jeder dreckigen Ecke gef�rchtet.',
			89 =>'Dein verbogenes Schwert wird mich nicht ber�hren.',
			90 =>'Ich habe nur einmal einen Feigling wie dich getroffen.',
			91 =>'Jetzt gibt es keine Finten mehr, die dir helfen.',
			92 =>'Nach jedem Kampf war meine Hand blut�berstr�mt.',
			93 =>'Sind alle M�nner so? Dann heirate ich ein Schwein.'
);
$antworten = array(1 =>'Dann mach damit nicht rum wie mit dem Staubwedel.',
                       	2 =>'Doch, doch, du hast sie nur nie gelernt.',
                       	3 =>'Du kannst so schnell davonlaufen?',
                       	4 =>'Daf�r hab\' ich in der Hand nicht die Gicht!',
                       	5 =>'Das sind gro�e Worte f�r \'nen Kerl ohne Grips!',
                       	6 =>'Grrrgh! Ich wu�te gar nicht, da� du so weit z�hlen kannst. Aargh!',
                       	7 =>'Ja, ja, ich wei�, ein dreik�pfiger Affe!',
                       	8 =>'Ungh! Ich werde mich wehren, bis die Griffel dir qualmen!',
                       	9 =>'Aargh! Behalt sie f�r dich, sonst bekomm\' ich noch Pusteln!',
                       	10 =>'Ungh ... wobei mir vor allem vor deinem Atem graust.',
                       	11 =>'Ungh! Sie sitzt mir gegen�ber, also was fragst du mich?',
                       	12 =>'Ungh! Mit Ausnahme von deiner Frau, soviel ist klar!',
                       	13 =>'Aargh! Unglaublich erb�rmlich, das sag\' ab jetzt ich.',
                       	14 =>'Ungh! Und Babys wohl auch, na, der Witz ist gelungen.',
                       	15 =>'Das ist ein Lachen, du schw�chlicher Wicht!',
                       	16 =>'Er mu� dir das Fechten beigebracht haben.',
                       	17 =>'Ich wollte, da� du dich wie zuhause f�hlst.',
                       	18 =>'Zu schade, da� dich �berhaupt keiner kennt.',
                       	19 =>'Ich schaudere, ich schaudere.',
                       	20 =>'Aha mal wieder in der Nase gebohrt, wie?',
                       	21 =>'Auch bevor sie deinen Atem riechen.',
                       	22 =>'Und du wirst deine rostige Klinge nie wieder sehen.',
                       	23 =>'Vielleicht solltest du es endlich mal benutzen.',
                       	24 =>'Wieso, die k�nntest du viel eher brauchen.',
                       	25 =>'Hattest du das nicht vor kurzem getan.',
                       	26 =>'Ich wollte, da� du dich wie zuhause f�hlst.',
                       	27 =>'Wieso, die k�nntest du viel eher brauchen.',
                       	28 =>'Dann mach damit nicht rum wie mit dem Staubwedel.',
                       	29 =>'Du kannst so schnell davonlaufen?',
                       	30 =>'Also mal wieder in der Nase gebohrt, wie?',
                       	31 =>'Auch bevor sie deinen Atem riechen.',
                       	32 =>'Zu schade, da� dich �berhaupt keiner kennt.',
                       	33 =>'Das war ja auch leicht, Dein Atem hat sie paralysiert!',
                       	34 =>'Hoffentlich zerrst Du mich nicht ins Separ�e!',
                       	35 =>'Dich zu t�ten w�re dann eine legale Reinigung!',
                       	36 =>'Da hat sich wohl Dein Spiegelbild in meinem S�bel reflektiert!',
                       	37 =>'Wenn ich mit DIR fertig bin, bist Du nur noch Filet!',
                       	38 =>'Sollt\' ich in Deiner N�he sterben, m�cht\' ich, da� man mich desinfiziert!',
                       	39 =>'Dein Geruch allein reicht aus, und ich w�r\' kollabiert!',
                       	40 =>'Das ich nicht lache! Du und welche Armee?',
                       	41 =>'In Formaldehyd aufbewahrt tr�gest Du bei zu meiner Erheiterung.',
                       	42 =>'Ich glaub\', es gibt f�r Dich noch eine Stelle beim Variet�!',
		       	43 =>'Zumindest hat man meine identifiziert!',
		       	44 =>'Oh, das ist ein solch �bles Klischee!',
		       	45 =>'Zu schade, da� das hier niemand tangiert.',
		       	46 =>'Ich k�nnte es tun, h�ttest Du nur ein Atemspray!',
		       	47 =>'F�r Dein Gesicht bekommst Du \'ne Begnadigung.',
		       	48 =>'Das war ja auch leicht, Dein Atem hat sie paralysiert!',
		       	49 =>'Hoffentlich zerrst Du mich nicht ins Separ�e!',
		       	50 =>'ich zu t�ten w�re eine legale Reinigung!',
		       	51 =>'Da hat sich wohl Dein Spiegelbild in meinem S�bel reflektiert!',
		       	52 =>'Wenn ich mit Dir fertig bin, bist Du nur noch Filet!',
		       	53 =>'Sollt\' ich in Deiner N�he sterben, m�cht\' ich, da� man mich desinfiziert!',
		       	54 =>'Dann w�re koffeinfreier Kaffee ein erster Schritt zur L�uterung!',
		       	55 =>'Dein Geruch allein reicht aus, und ich w�r\' kollabiert!',
		       	56 =>'Das ich nicht lache! Du und welche Armee?',
		       	57 =>'In Formaldehyd aufbewahrt tr�gest Du bei zu meiner Erheiterung.',
		       	58 =>'Ich glaub\', es gibt f�r Dich noch eine Stelle beim Variet�!',
		       	59 =>'Zumindest hat man meine identifiziert!',
			60 =>'Oh, das ist ein solch �bles Klischee!',
			61 =>'Zu schade, da� das hier niemand tangiert!',
			62 =>'Ich k�nnte es tun, h�ttest Du nur ein Atemspray!',
			63 =>'F�r Dein Gesicht bekommst Du \'ne Begnadigung.',
			64 =>'Ungh ... wobei mir vor allem vor deinem Atem graust.',
			65 =>'Oooh. Zu schade, da� keine davon in diesen Armen ist.',
			66 =>'Wenn ich mit dir fertig bin, brauchst Du \'ne Kr�cke!',
			67 =>'Ja sogar deine Schwester findet ihn in der Nacht nett...',
			68 =>'Dann wird deine Frau dich kriegen!',
			69 =>'Dann wolln wir mal auf keine Maulsperre hoffen.',
			70 =>'Damit hat sie kein gro�es Wunder vollbracht',
			71 =>'Argh... und DU bist ein armer Tropf!',
			72 =>'Willst Du mich mit Deinem Geschwafel erm�den?',
			73 =>'Also hast Du doch den Job als Putze gekriegt.',
			74 =>'Piek dir ins Auge das brennt auch',
			75 =>'Und dich zu t�ten eine Erl�sung f�r alle',
			76 =>'Ich halt mich an dir fest, Fett schwimmt ja',
			77 =>'Frag doch deine Mutter, der weiss das',
			78 =>'Ich w�rd dich ja gern mitnehmen aber mein Vermieter erlaubt kein Ungeziefer',
			79 =>'Das ist keine Familie, das ist ein Laborexperiment',
			80 =>'Stimmt, du bist die letzte Null',
			81 =>'Das war Mutter Natur wohl auch nicht',
			82 =>'Ich will nicht im Ohr bohren und dabei grinsen wie ein Idiot',
			83 =>'Lieber eine Kuh melken als mit nem Ochsen ringen',
			84 =>'Weil wir sonst beide unrecht h�tten',
			85 =>'Man gew�hnt sich an alles',
			86 =>'Moment, das ist doch dein Spezialgebiet...',
			87 =>'Aha, du warst also beim letzten Familientreffen.',
			88 =>'Also hast du doch den Job als Putze gekriegt?',
			89 =>'Und du wirst deine rostige Klinge nie wieder sehen.',
			90 =>'Er mu� dir das Fechten beigebracht haben.',
			91 =>'Doch, doch, du hast sie nur nie gelernt.',
			92 =>'Aha, mal wieder in der Nase gebohrt, wie?',
			93 =>'Hattest du das nicht vor kurzem getan?'
 );

          //Thx to Eliwood
          $schonausgwaehlteaws_id = array();
          $schonausgwaehltefragenundantworten = array();
          $awtotal = count($antworten);
          $zustellendeaw = 4; # 3 Fragen stellen
          for($c = 1; $c <= $zustellendeaw; $c++) {
                    while(1) {
                        $fragennummer = mt_rand(0, $awtotal - 1);
                        $_SESSION['session']['richtigeaw'] = $fragennummer;
                        if(!isset($schonausgwaehlteaws_id[$fragennummer])) {
                            $schonausgwaehlteaws_id[$fragennummer] = true;
                            $schonausgwaehltefragenundantworten[$antworten[$fragennummer]] = "<a href=forest.php?op=kampf&id=$fragennummer>`z$antworten[$fragennummer]</a>";
                            addnav("","forest.php?op=kampf&id=$fragennummer");
                            break;
                        }
                    }
          }
          shuffle($schonausgwaehltefragenundantworten);
          $out .="`b $fragen[$fragennummer] `b `n";
          foreach($schonausgwaehltefragenundantworten as $antwort ) {
               $out .=" $antwort `n";
          }

          $session['user']['specialinc']="beleidgterpirat.php";
     break;
     case'ergebnis';
        $out .='`c'.WBEPICOLORSTANDART2.''.($session[user][sex]?"Die `6Siegerin ":"Der `6Sieger ").''.WBEPICOLORSTANDART2.'steht fest.`n Es ist .........`n`c ';
        addnav("zur�ck","forest.php");
        $session['user']['turns'] --;
        $session['user']['specialinc']="";
        if ($_SESSION['session']['bpirat']<5){
            debuglog('Pirat besiegt');
            $expplu = round($session['user']['experience'] * 0.15);
            $session['user']['experience']+=$expplu;
            $out .="`c`b ".$session['user']['name']."`b `n".WBEPICOLORSTANDART2."".($session[user][sex]?"Sie ":"Er ")." gewinnt somit ".WBEPICOLORZAHL."$expplu ".WBEPICOLORSTANDART2."Erfahrung`c`n";
            $buff = array("name"=>"`6Ego Wall`0","rounds"=>60,"wearoff"=>"`5`bDer Ego Wall ist verbraucht!.`b`0","defmod"=>1.8,"roundmsg"=>"Dich kann nichts umhauen dein EGO ist enorm!!","activate"=>"offense");
            $session['bufflist']['pirat']=$buff;
            addnews("".WBEPICOLORSTANDART2."".$session['user']['name']."".WBEPICOLORSTANDART2." hat die Begegnung mit dem ".WBEPICOLORPISAY."Piraten ".WBEPICOLORSTANDART2."gl�nzend �berstanden".WBEPICOLORSTANDART2."");
        } else {
            debuglog('Pirat verloren');
            $expplu = round($session['user']['experience'] * 0.10);
            $session['user']['experience']-=$expplu;
            $session['user']['hitpoints'] =1;
            $out .="`c".WBEPICOLORPISAY."`b`DER PIRAT`b `n".WBEPICOLORSTANDART2."Du verlierst deswegen ".WBEPICOLORZAHL."$expplu ".WBEPICOLORSTANDART2."Erfahrung und fast dein ".WBEPICOLORPI."Leben".WBEPICOLORSTANDART2."`c.`n";
            $buff = array("name"=>"`6Demoralisation`0","rounds"=>60,"wearoff"=>"`5`bDie Motivation kehrt zur�ck!.`b`0","defmod"=>0.7,"roundmsg"=>"Du hast einfach kein Bock mehr und willst nur nach hause","activate"=>"offense");
            $session['bufflist']['pirat']=$buff;
            addnews("".WBEPICOLORPISAY."Der Pirat ".WBEPICOLORSTANDART2."hat ".$session['user']['name']."".WBEPICOLORSTANDART2." fast zu Tode beleidigt".WBEPICOLORSTANDART2."");
        }
        $_SESSION['session']['bpirat']='0';
        $_SESSION['session']['buser']='0';
     break;
}
output("$out",true);
?>