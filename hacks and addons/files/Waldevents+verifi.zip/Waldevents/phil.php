<?php
/**********************************************************
* By Mr edah                                              *
* www.edahnien.de                                         * 
* V 0.8                                                   *
* Einbau: einfach in den spezial Ordner laden.            *
***********************************************************/



//letzZZzz Go
page_header("Phil und Bill");
if ($_GET[op]=="")
{

        output("Du gehst durch den Wald und triffst auf eine alte Mauerruine. Du runzelst die Stirn, als du Musik und ein seltsames Geschrei vernimmst. Du denkst, es sei jemand in Not und so eilst du zu der Stimme und der Musik. Du kommst auf eine kleine Lichtung hinter der Mauer, entdeckst dort 5 Wesen. 3 davon spielen auf, wie du findest, seltsamen Instrumenten. Die anderen beiden streiten sich. Du kannst nicht genau heraush�ren worum es geht.`n Du trittst aus den B�schen herraus und fragst laut, was denn los sei. Der eine, der sich als Phil vorstellt, erkl�rt dir kurz was das Problem ist:`t\"Dieses M�nschlein hiear zu mein�r recht�n, sein Nam� ist �brig�ns Schnucki.. �hh ich meint� Bill, will sich nicht die Haare schneiden laassen. Du kleines Schnucki Putzi, klein�s Weibchen, stimmst mir doch sicher zu, dass sein� Frisur zum Kotzen ausschaut, oder?`0\" Du schaust zu diesem Bill und stimmst Phil zu. Phil kommt ein paar Schritte auf dich zu und nimmt dich in den Arm.`t\"Sag, k�nnt�st du mir helfen ihn zu einem Fris�r zu bringen ?`0");
        $session['user']['specialinc']="phil.php";        
        addnav("Helfen","forest.php?op=help");        
        addnav("Nicht Helfen","forest.php?op=nhelp");

        addnav("Verschwinden","forest.php?op=weg");
}
if ($_GET[op]=="weg")
{
          $session['user']['specialinc']="";
          output("Du machst dich vom Acker");
          addnav("Weiter","forest.php");
}


if ($_GET[op]=="help")
{
        output("Du gehst zu diesem Bill und forderst ihn auf dir zu folgen. Er macht dir schnell klar, dass er dies nicht machen wird und so musst du wohl oder �bel Gewalt anwenden");
        $badguy = array(
                    "creaturename"=>"`% Bill`0",
                    "creaturelevel"=>$session[user][level]+2,
                    "creatureweapon"=>"Schrilles Geschrei",
                    "creatureattack"=>$session['user']['attack']-3,
                    "creaturedefense"=>$session['user']['defence']-2,
                    "creaturehealth"=>$session['user']['maxhitpoints']-20, 
                    "diddamage"=>0);
        $session['user']['badguy']=createstring($badguy);
        $session['user']['specialinc']="phil.php";
        $_GET['op']="fight";
        

}
if ($_GET[op]=="run"){
    
        output("`c`b`\$Es gelingt dir nicht zu entkommen.`0`b`c`n`n");
        $battle=true;
     $session[user][specialinc]="phil.php";
}

if ($_GET['op']=="fight"){
    $battle=true;
     $session[user][specialinc]="phil.php";
}

if ($battle) {
    include("battle.php");
        if ($victory){
             $badguy=array();
             output("`nDu hast `^Bill besiegt.`n Du bist einfach nur �bergl�cklich");
             $session[user][specialinc]="phil.php";
                              addnav("Weiter","forest.php?op=weiter");
                              
}
elseif($defeat)
        {
        $badguy=array();

                output("Du wurdest von ".$badguy['creaturename']." besiegt. Nun ist die Welt dem Untergang geweiht ");
                $session['user']['alive']=false;
                $session['user']['hitpoints']=0;
   
              



                addnav("T�gliche News","news.php");
}
else
{
fightnav(true,true);
  }
}

if ($_GET[op]=="nhelp")
{
        output("Du beschlie�t, Phil in seiner misslichen Lage nicht zu helfen, drehst dich um und willst gehen, als Phil dir so gewaltig eins �ber die R�be haut, dass du tot umf�llst");
        $session['user']['alive']=false; 
        $session['user']['hitpoints']=0; 
        addnav("News","news.php");
}

if ($_GET[op]=="weiter")
{
$session[user][specialinc]="phil.php";
        output("Ihr trampelt durch den Wald, irgendwann kommt ihr zu einer kleinen H�tte. Es ist der Fris�r und ihr geht rein. Der Fris�r verlangt 500 Gold f�r den neuen Haarschnitt. Phil ist das ziemlich peinlich, da er nicht genug Gold dabei hat. Er wird rot vor Scham. �bernimmst du die Kosten f�r Bills neuen Haarschnitt?");
        addnav("Ja","forest.php?op=haareja");
        addnav("Nein","forest.php?op=nhelp");
}

if ($_GET[op]=="haareja")
{
if ($session[user][gold]>=499){        

        output("Du bezahlst den neuen Haarschnitt f�r Bill. Hinterher findest du ihn zwar nicht sch�ner, aber immerhin sieht er nicht mehr aus wie eine Tunte. Phil ist (wie der Rest der Welt) �bergl�cklich! Du bekommst 10 Charmpunkte, verlierst jedoch 5 Waldk�mpfe. Du hast aber eine Menge an Erfahrung gewonnen.");
        $session['user']['turns']-=5; 
        $session['user']['charm']+=10;
        $session['user']['gold']-=500; 
        $session['user']['experience']+=2000;
        addnav("Ende","forest.php");
$session['user']['specialinc']="";
}else{
        output(" Du versuchst den Fris�r zu betr�gen. Als Dank daf�r erh�lst du eine kostenlose �berfahrt zu Ramius");
        $session['user']['alive']=false; 
        $session['user']['hitpoints']=0; 
        addnav("News","news.php");
}

}
page_footer();
?>