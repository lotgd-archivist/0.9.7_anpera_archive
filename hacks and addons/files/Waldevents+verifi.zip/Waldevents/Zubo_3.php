<?php
/*

         *  *         * *
      *  BY   *    * AND  *
    *  Mr edah  *  Zudu    *
  *     www.edahnien.de     *
  * www.gruebelz.com/logd  *
   *  Boindil und Zudus   *
    *     Abenteuer      *
      *   Boindils     *
        *Gro�e liebe *
          *  V 1.0 *
            *   *
              *

*/
page_header("Boindil und Zudus Abenteuer");
switch(isset($_GET['op']) ? $_GET['op'] : '')
{
    case '';
         $out .="Als du fr�hlich durch den Wald gehst, h�rst du ein paar aufgebrachte Stimmen, denen du folgst. Als du auf einer Lichtung drei Gestallten entdeckst, musterst du sie genauer.`n Der Eine, der ein wenig abseits steht und ein breites Grinsen aufwei�t ist der Elf Zudu. Nummer 2. der Gestallten ist die wundersch�ne Aphrodite und Nummer 3 h�ngt an Aphrodites Bein wie eine Klette: Der Zwerg Boindil.
               `tOh sch�ne Aphrodite `&Schw�rmt Boindil `tHast du nicht Lust im n�chsten Busch einen armen Zwerg zu verw�hnen?`& Man merkte an Aphrodites Gesichtsausdruck, dass dies nicht ihrer Lust entsprach. Zudu lachte nur noch lauter `3Ach Boindil, du hattest jetzt deine Spa� wir gehen!`& Zudu packt Boindil am Gewand und versucht ihn von Aphrodite zu l�sen, doch schaffte er dies nicht. Bei diesem Anblick musst du unwillk�rlich lachen so, dass Zudu dich bemerkte `3Hallo ".$session['user']['name']." willst du uns nicht helfen?";
         $session['user']['specialinc']="Zubo_3.php";
         addnav("Hilfst du Zudu, Boindil von Aphrodite zu l�sen","forest.php?op=hilfe");
         addnav("oder");
         addnav("Springst du Aphrodite ans andere Bein?","forest.php?op=bein");
    break;
    case 'hilfe';
        $session['user']['specialinc']="";
        switch(e_rand(1,2))
        {
          case 1:
            $out .="Du nickst nur und versuchst Boindil loszureissen. Nach ein wenig ziehen und zerren hast du Boindil erfolgreich von Aphrodite gel�st. Daf�r ist dir Aphrodite sehr dankbar und schenkt die 5 Charmepunkte.";
            $session['user']['charm']+=5;
            addnav("Weiter","forest.php");
            addnews(" ".$session['user']['name']." `0 hat Aphrodite von einem Zwerg befreit und wirkt viel charmanter seit dem. ");
          break;
          case 2:
            $out .="Du willigst Zudu ein zu helfen und gehst auf Boindil zu. `2Herr Zwerg? `&fragst du vorsichtig `2Ich w�rde Euch jetzt gerne von Aphrodite entfernen... `& Boindil schaut dich w�tend an `tWaaaas? Du willst mir meine Aphrodite wegnehmen? `&Er springt von Aphrodite ab und st�rzt sich auf dich. Mit voller Wucht haut er dir auf die Stirn. Du wankst und schwankst bis du schlie�lich ohnm�chtig umf�llst.`n Deine Aufgabe hast du zwar erledigt, wof�r du 5 Charmepunkte von Aphrodite und 8000 Gold von Zudu bekommst, aber verlierst alle Waldk�mpfe, da du erst am n�chsten Morgen wieder erwachst.";
            $session['user']['charm']+=5;
            $session['user']['gold']+=8000;
            $session['user']['turns']=0;
            addnav("Weiter","forest.php");
            addnews(" ".$session['user']['name']." traf die Faust eines Zwerges und die dankbarkeit eines Elfen und Aphrodite.");

        }
    break;
    case 'bein';
        $session['user']['specialinc']="";
        switch(e_rand(1,3))
        {
            case 1:
                $out .="Du h�rst Zudu garnicht nach seiner Hilfe fragen, sondern spirngst Aphrodite so gleich an. Zudu ist so auf dich w�tend, dass er sein japanisches Schwert z�ckt und es dir von hinten in den R�cken rammt.`nDu bist tot und verlierst all' dein Gold";
                $session['user']['alive']=false;
                $session['user']['hitpoints']=0;
                addnav("News","news.php");
                $session['user']['gold']=0;
                addnews(" ".$session['user']['name']." Wollte Zudu und Aphrodite nicht helfen und ist nun tot.");
            break;
            case 2:
                $out .="Du achtest nicht weiter auf Zudu und springst Aphrodite an. Diese rollt nur mit den Augen und spricht leise `%Was f�r ein Tag `& `nDa du den ganzen restlichen Tag an Aphrodite h�ngst verlierst du alle Waldk�mpfe, jedoch sehen dich alle Bewohner, die vorbeikommen und du verlierst durch die Peinlichkeit 10 Charmepunkte.";
                $session['user']['turns']=0;
                $session['user']['charm']-=10;
                addnav("Weiter","forest.php");
                addnews(" ".$session['user']['name']." hing den ganzen Tag an Aphrodites Bein");

            break;
            case 3:
                $out .="Du springst Aphrodite ebenfalls wie Boindil an. Boindil f�llt durch diesen Ruck von Aphrodite so, dass du sie in das n�chst beste Geb�sch ziehen kannst.
                        Du bekommst 10 Charmepunkte und durch den neuen Lebensfrohsinn kriegst du 5 Waldk�mpfe";
                addnav("Weiter","forest.php");
                $session['user']['charm']-=10;
                $session['user']['turns']+=5;
                addnews(" ".$session['user']['name']." hatte in einem Geb�sch seinen Spa�");
        }
}
output("$out");
?>