<?php
/*
         *  *         * *
      *  BY   *    * AND  *
    *  Mr edah  *  Zudu    *
  *     www.edahnien.de     *
  * www.gruebelz.com/logd  *
   *  Boindil und Zudus   *
    *     Abenteuer      *
      *   Der Yeti     *
        *            *
          * V 1.0  *
             *   *
               *
*/
    $testmodus = 0 ; # testnodus (1 = an) (0 = aus)
    $res = 1 ;   #  edahs Res mod vorhanden ( 0 =ja 1 = nein)
    $session['user']['specialinc'] = "Zubo_2.php";
page_header("Boindils und Zudus Abenteuer");
if ($_GET[op]=="")
{
     output("Fr�hlich gehst du durch den Wald. Hinter einem riesigen Geb�sch h�rst du eine aufgebrachte Stimme `3Du dummer Zwerg! Gib sie lieber mir! `&Schon schaltet sich die n�chste Stimme ein `tNein, ich bin mir sicher, dass das der richtige Weg ist! `3Boindil....! `&Deine Augen blitzen auf, Boindil? Dann musste die andere Stimme von Zudu kommen. `3... gib mir die Karte! `&Du fragst dich, was sie mit einer Karte vorhaben. So tritts du aus dem Geb�sch und stellst dich vor ihnen. Sofort erblickst du wie Zudu und Boindil um die Karte ziehen. Du musst gleich dran denken, dass die Karte eigentlich... Da passierte es auch schon! Die Karte war zerissen!
     Wie ein Blitz zuckt Zudu Faust hervor und verpasst Boindil eine Kopfnuss `3Dickkopf, du! `&Grummelt er. Boindil reibt sich seinen Kopf `tIch war mir sicher... `&Du schaltest dich ins Gespr�ch ein `@ Braucht Ihr Hilfe? `&Fragst du. Erst jetzt bemerken dich die Beiden.
     Erwartungsvoll schaust du sie an, bis Zudu spricht `3Wir wollen uns nach Edahnien begeben, doch Boindil, der Zwerg da, `&Er zeigt auf den genannten Zwerg `3Hat unsere Karte leider zerissen `&Boindil schaut vorwurfsvoll zur�ck `tDu wolltest mich nicht weiter navigieren lassen! `&Zudu meint dann `3Wir wollten doch nur zur DarkHorseTaverne und jetzt irren wir seit 2 Wochen hier rum, nur weil sie heraustellte, dass du garkeine Karten lesen kannst! `&Dir wird es zu bunt und wirfst ein `2 Ich bring Euch nach Hause!`&
     Welchen Weg wirst du nehmen?`n `n
     <a href='forest.php?op=wald'>
     Den durch den gef�hrlichen Wald?`n </a>
     <a href='forest.php?op=berge'>
     �ber die hohen Berge?`n </a>
     <a href='forest.php?op=fluss'>
     Oder mit dem Flo� �ber den Flu� entlang?
     `n </a>
     ",true);
     addnav("","forest.php?op=berge"); //fertig
     addnav("","forest.php?op=wald");  //fertig
     addnav("","forest.php?op=fluss"); //fertig
}
if ($_GET[op]=="berge")
{
    output("Du zeigst auf die Berge: `3Wir gehen �ber die Berge ins Dorf! Die beiden nicken und folgen dir.");
        switch(e_rand(1,2)){
           case 1:
             output("Ihr geht die schmalen Klippen entlang. Zudu und Boindil stritten sich dar�ber, dass es zu kalt war und dass jeweils immer der andere schuld, dass sie durch diese Situation gehen mussten. Pl�tzlich stolperte Boindil und fiel die Klippen hinab. gerade so konnte Zudu Boindil noch packen und festhalten. Breit grinsend meint er `3Ha, das war ja garnicht schwer! `&Nat�rlich kam es wie es kommen musste: Zudu rutschte Weg! Mit einem Hechtsprung hielst du ihn fest. Du versuchst die Beiden hochzuziehen bis du einen Eimer voller ".($res?"Eisenerz":"Gold")." siehst.Das mussten mindestens ".($res?"30":"5000")." sein!
             Was tust du?
             Hilfst du den Beiden?
             oder
             Schnappst du dir das  ".($res?"Eisenerz?":"Gold")."");
             addnav("helfen","forest.php?op=berghelfen");
             addnav("".($res?"Eisenerz":"Gold")." klauen","forest.php?op=eisenklau");
           break;
           case 2:
             output("Mit schweren Schritten geht ihr durch die Berge. Ein Br�llen l�sst euer R�ckenmark gefrieren. Sofort dreht ihr euch um. Boindil quietscht v�llig erschrocken: `tEs ist der Yeti! `&Zudu schluckt schwer und meint: `3Wir sollten mit ihm verhandeln. `&Boindil lacht. `tDu dummer Elf, `bANGRIFF!!!`b`&, schreit er und l�uft auf den Yeti zu. Ein kurzer Kampf und Boindil liegt K.O. am Boden. Zudu sch�ttelt nur den Kopf und geht auf den Yeti zu: `3Entschuldigt bitte! Wir sind auf der Durchreise und wollten Euch nicht bel�stigen. `&Der Yeti legt den Kopf schief und grunst. Anscheinend hat er kein Wort verstanden. Schulterzuckend legt er auch Zudu auf Eis.`n
             Nun liegt es an dir:`n
             L�ufst du weg oder k�mpfst du gegen das Ungeheuer?");
             addnav("Weglaufen","forest.php?op=leave");
             addnav("Auf in den Kampf","forest.php?op=fight&id=2");
           break;
      
   } // end switch
}
if ($_GET[op]=="berghelfen")
{
   output("Du entscheidest dich das Eisenerz zu verdr�ngen und ziehst die Beiden hoch. Dankbar begleiten sie dich den Rest des Weges zur�ck ins Dorf. Als ihr angekommen seid, hast du viel gelernt. Ausserdem schenken dir Zudu und Boindil zum dank".($res?" 5 Eisenerz!":"500 Gold")."`n
   Deine Heldentat verbreiten sie auch und du bekommst 3 Charmepunkte!");
   $session['user']['experience'] += 1500;
   $session['user']['charm'] += 3;
   if ($res ==0 )
   {
       $acctid = $session['user']['acctid'];
       $sql = "UPDATE res SET eisenerz=eisenerz+5 WHERE acctid='$acctid'";
       db_query($sql);
   }else{
       $session['user']['gold']+=500;
   }
    $session['user']['specialinc']="";
    addnav("Weiter","forest.php");
    addnews("".$session['user']['name']."`z war tapfer und hat Zudu und Boindil in den Bergen gerettet!");
}
if ($_GET[op]=="eisenklau")
{
    output("Durch deine gier zum ".($res?"Eisenerz":"Gold")."  l�sst du die Beiden herzlos fallen! Du h�rst die Schreie von den Beiden...Vorallem das Kreischen von Boindil...Doch es ist dir egal! Triumphierend h�lst du den Eimer Hoch! Der Boden unter dir bricht zusammen und du st�rzt in die Tiefe! Im fallen siehst du, dass Boindil und Zudu gl�ck hatten und auf einem Felsvorsprung, der nicht sehr tief von ihrem Fallort entfernt war, landeten und ohne Verletzungen davonkamen. Du f�llst leider den ganzen Berg hinunter und stribst. Ausserdem verlierst du durch deine Herzlosigkeit 10 Charmepunkte!");
   $gesamtwert = $session['user']['experience'];
   $grundwert = $gesamtwert * 10 / 100 ;
   $session['user']['experience']-= $grundwert;
   $session['user']['charm'] -= 10;
   $session['user']['gold'] = 0;
   $session['user']['gems'] = 0;
   $session['user']['alive'] = false;
   $session['user']['hitpoints'] = 0;
   addnav("Zu den News","news.php");
   $session['user']['specialinc']="";
   
}
if ($_GET[op]=="leave")
{
   output("Du drehst dich um und l�ufst davon. Da du auf Eis nicht sonderlich gut laufen kannst rutscht du weg und st�rzt die Klippen hinab. Du bist tot und hast Zudu und Boindil im Stich gelassen! Du verlierst 5 Charmepunkte und all' dein Gold und Edelsteine. Das n�chste Mal solltest du vielleicht nicht immer davonlaufen! Das war dumm und so verlierst du 5% deiner Erfahrung!");
   addnews(" ".$session['user']['name']." `z hat nicht gegen den Yeti gek�mpft und ist in den ewigen Gletschern nun der neue �tzi!");
   $gesamtwert = $session['user']['experience'];
   $grundwert = $gesamtwert * 5 / 100 ;
   $session['user']['experience']-= $grundwert;
   $session['user']['charm'] -= 5;
   $session['user']['gold'] = 0;
   $session['user']['gems'] = 0;
   $session['user']['alive'] = false;
   $session['user']['hitpoints'] = 0;
   addnav("Zu den News","news.php");
   $session['user']['specialinc']="";
   
}
if ($_GET[op]=="fight")
{
   $ID=$_GET['id'];
   if ($ID==1)
   {
    $badguy = array(
                    "creaturename"=>"`~ Schatten`0",
                    "creaturelevel"=>$session[user][level]+2,
                    "creatureweapon"=>"Dummes Grinsen",
                    "creatureattack"=>$session['user']['attack']-3,
                    "creaturedefense"=>$session['user']['defence']-2,
                    "creaturehealth"=>$session['user']['maxhitpoints']-20,
                    "diddamage"=>0);
    $session['user']['badguy']=createstring($badguy);
    }
    elseif ($ID==2) 
    {
         $badguy = array(
                    "creaturename"=>"`% Yeti`0",
                    "creaturelevel"=>$session[user][level]+2,
                    "creatureweapon"=>"flauschige F�uste",
                    "creatureattack"=>$session['user']['attack']-3,
                    "creaturedefense"=>$session['user']['defence']-2,
                    "creaturehealth"=>$session['user']['maxhitpoints']-20,
                    "diddamage"=>0);
    $session['user']['badguy']=createstring($badguy);
    }
    $session['user']['specialinc']="Zubo_2.php";
    $battle=true;
}
if ($_GET[op]=="run")
{
        output("`c`b`\$Es gelingt dir nicht zu entkommen.`0`b`c`n`n");
        $battle=true;
        $session[user][specialinc]="Zubo_2.php";
}
if ($battle) {
    include("battle.php");
        if ($victory)
        {
             
             output("`nDu hast ".$badguy['creaturename']." besiegt.");
             $session[user][specialinc]="";
             output("Der ".$badguy['creaturename']." f�llt tot vor dir zu F��en. Hinter dem ".$badguy['creaturename']." entdeckst du eine H�hle. Als du diese betrittst, findest du 3.000 Gold und 4 Edelsteine.");
             $session['user']['gold'] += 3000;
             $session['user']['gems'] += 4;
             addnav("Zur�ck in den Wald","forest.php");
$badguy=array();
        }
elseif($defeat)
        {
        $badguy=array();
                output("Du wurdest von ".$badguy['creaturename']." besiegt und bist nun tot.");
                $session[user][alive]=false;
                $session[user][hitpoints]=0;
                addnav("T�gliche News","news.php");
}
else
{
fightnav(true,true);
  }
}
if ($_GET[op]=="wald")
{
     output("Du zeigst gen Wald und meinst `3Wir gehen durch den Wald!`& Die Beiden stimmen dir zu und folgen dir.
     Ihr wandert durch den gro�en Wald an einer H�hle vorbei. Aus der H�hle kommen leise Zischlaute heraus. Irritiert blickst du hinein. Noch nie zuvor hast du solche Laute geh�rt... Aus der H�hle tritt ein gro�er Schatten heraus. Boindil z�ckt sofort seinen Zwergenhammer und holt damit aus. Ungl�cklicherweise verpasst er Zudu damit einen Knock out. `tUps...Das wird er mir die n�chsten Jahre noch �bel nehmen... `&Als Boindil dann dem Schatten gegen�bertritt, kriegt er es mit der Angst zu tun und verschwindet im Wald.
     Nun liegt es an dir den Schatten zu besiegen");
     addnav("K�mpfen","forest.php?op=fight&id=1");
}
if ($_GET[op]=="fluss")
{
     output("Du zeigst zum Flu�: `2Wir bauen ein Flo�! `&Die Beiden nicken und fangen an ihre Holzressourcen zu opfern. Legst du die n�tigen ".($res?"2 Holz":"500 Gold")."  dazu oder nicht?");
     addnav("Ja","forest.php?op=flosja");
     addnav("Nein","forest.php?op=flosnein");
}
if ($_GET[op]=="flosja")
{
   if ($res ==0 )
   {
     $acctid = $session[user][acctid];
     $suchen = db_query("SELECT holz FROM res WHERE acctid=$acctid");
     $res = db_fetch_assoc($suchen);
        if ($res['holz'] >= 2)
        {
             output("Du �bergibst den beiden dein Restholz. Fr�hlich schippert ihr �ber den Flu�. Ihr kommt ohne gro�e umschweife ins Dorf. Es war langweilig und gebracht es nichts! Boindil und Zudu sind eingeschlafen, warte nicht auf eine Belohnung!");
             $sql = "UPDATE res SET holz=holz-3 WHERE acctid='$acctid'";
             db_query($sql);
             addnews("".$session['user']['name']. "`zist langweilig.");
             addnav("Weiter","forest.php");
             $session['user']['specialinc']="";
        }
        else
        {
             $_GET[op]="flosnein" ;
        }
    }else{
        if ($session['user']['gold'] >= 500)
        {
             output("Du �bergibst den beiden dein ".($res?"Restholz":"500 Gold").". Fr�hlich schippert ihr �ber den Flu�. Ihr kommt ohne gro�e umschweife ins Dorf. Es war langweilig und gebracht es nichts! Boindil und Zudu sind eingeschlafen, warte nicht auf eine Belohnung!");
             $session['user']['gold']-=500;
             addnews("".$session['user']['name']. "`zist langweilig.");
             addnav("Weiter","forest.php");
             $session['user']['specialinc']="";
        }
        else
        {
             $_GET[op]="flosnein" ;
        }
    }
}
if ($_GET[op]=="flosnein")
{
      output("Fr�hlich schippert ihr den Flu� entlang. Doch irgendwie findest du es sehr nass auf dem Flo�. Du drehst dich um, um Zudu nach seiner Meinung zu fragen, doch die Beiden sa�en nicht mehr auf dem Flo�! Du ertrinkst! Die Beiden wussten wohl, dass das Flo� nicht halten w�rde. Du Geizhals hast dir dein eigenes Grab geschaufelt!");
      $gesamtwert = $session['user']['experience'];
      $grundwert = $gesamtwert * 5 / 100 ;
      $session['user']['experience']-= $grundwert;
      addnews("".$session['user']['name']."s `zFlo� hatte zu wenig Holz! Sucht seine Leiche doch im Flu� bei Edahnien!");
      $session['user']['alive'] = false;
      $session['user']['hitpoints'] = 0;
      addnav("Zu den News","news.php");
      $session['user']['specialinc']="";
}
?>