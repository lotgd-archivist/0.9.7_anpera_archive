<?php
/*

         *  *         * *
      *  BY   *    * AND  *
    *  Mr edah  *  Zudu    *
  *     www.edahnien.de     *
  * www.gruebelz.com/logd  *
   *  Boindil und Zudus   *
    *     Abenteuer      *
      * M�rchenstunde  *
        *G           *
          *  V 1.0 *
            *   *
              *

*/
page_header("Boindils und Zudus Abenteuer");
switch(isset($_GET['op']) ? $_GET['op'] : '')
{
    case '':
        $session[user][specialinc]="Zubo_1.php";
        $out .="Als du durch den Wald gehst, h�rst du 2 Stimmen wild miteinander reden und lachen. Als die Beiden vor dir stehen, erkennst du die Gestalten der `tS�ldner `@B`goi`8nd`&il und `4Ph`q�n`^ix`2eng`^el `qZu`4du`&. `nDie Beiden bieten dir an, dich zu setzen`nHast du die Zeit daf�r? ";
        addnav("hinsetzen","forest.php?op=hinsetzen");        
        addnav("weggehen","forest.php?op=weggehen");
    break;
    case 'weggehen':
        $out .="Du l�sst die Beiden einfach stehen, da du lieber Monster jagen willst. Du f�hlst dich aber mies dabei und verlierst 2 Charmepunkte.";
        $session['user']['charm']-=2;
        $session['user']['specialinc']="";
        addnav("Weiter","forest.php");
    break;
    case 'hinsetzen':
        $session[user][specialinc]="Zubo_1.php";
        $out .="Du entscheidest dich, den beiden komischen Gesellen ein wenig Gesellschaft zu leisten. `n`^Z`@u`^d`@u`& beginnt zu erz�hlen `3\"Wir trafen...\" `&`@B`goi`8nd`&il`& unterbricht `t\"In luftiger H�he wohlgemerkt!\" `^Z`@u`^d`@u`& verdreht die Augen und spricht weiter `3\"Einen 8-K�pfigen Drachen\" `&Wieder wirft `@B`goi`8nd`&il`& ein `t\"Mit �h...�h...�h... Sehr vielen Augen!\" `&`^Z`@u`^d`@u`& z�hlt an seinen Fingern ab `3\"�h...8 K�pfe mal 2 Augen...�h... 16 genau! `&Es meldet sich erneut `@B`goi`8nd`&il`& zu Wort `t\"Was ist dann mit dem riesigen Auge in der Mitte?\" `&`^Z`@u`^d`@u`& klatscht `@B`goi`8nd`&il`& gegen den Hinterkopf `3\"Das war der Schatz, du betrunkener Zwerg!\" `&`@B`goi`8nd`&il`& brummelt in seinen Bart `t\"Als betrunkener Zwerg kann man wenigstens n�chterne Elfen wie dich ertragen!\" ".$session['user']['name']." `0wirft ein `@\"Und der Drache?\"`& Der Zwerg `@B`goi`8nd`&il`& und der Elf `^Z`@u`^d`@u`& gucken sich kurz in die Augen. `@B`goi`8nd`&il`& meint `t\"Ganz recht\" `&Schaut zu `^Z`@u`^d`@u`& `t\"Was lenkst du auch vom Thema ab?\" `& `^Z`@u`^d`@u`& schaut ihn protestierend an `3\"Wie? Ich?\"`n`& Nach dem Streit erz�hlen die Beiden weiter ihre Geschichte.`nInteressiert hast du ihnen bis zum Schlu� zugeh�rt. `@B`goi`8nd`&il`& kratzt sich am Hals `t\"Mein Hals ist trocken. Ich glaube, ich brauche ein Ale!\"`& `^Z`@u`^d`@u`& stimmt zu und erkl�rt, dass ".$session['user']['name']." `0sowieso gerade einen ausgeben wollte, oder?";
        if($session['user']['gold']>=150)
        {
            addnav("Ale Ausgeben (150 Gold)","forest.php?op=aleaus");
        }
        addnav("Verschwinden","forest.php?op=vershwinden");
    break;
    case 'aleaus':
        switch(e_rand(1,2))
        {
            case 1:
               $exp=($session[user][level]*50);
               $out .="Nachdem `@B`goi`8nd`&il`& und `^Z`@u`^d`@u`& ihr Ale heruntergekippt haben, verabschieden sie sich freundlich von dir.`nDu gehst schulterzuckend weiter, nicht wissend, wie glaubhauft diese Geschichte ist, aber $exp Erfahrungspunkte ist sie dir wert.";
               $session['user']['experience']+=$exp;
               $session['user']['specialinc']="";
            break;
            case 2:
               $out .='Nachdem `@B`goi`8nd`&il`& und `^Z`@u`^d`@u`& ihr Ale heruntergekippt haben, r�cken Beide jeweils einen Edelstein heraus, so dass du 2 glitzernde Steinchen besitzt.';
               $session['user']['gems']+=2;
               $session['user']['specialinc']="";
        }
    break;
    case 'verschwinden':
        $out .='Du weigerst dich, den Beiden ein Ale zu spendieren. Die Beiden schauen dich w�tend an und zeigen dir ihre neue Geheimwaffe: `^Z`@u`^d`@u`& nimmt `@B`goi`8nd`&il`& auf und schleudert ihn am Fu� ein paar mal im Kreis. `@B`goi`8nd`&il`& schreit kreischend `t"Diesmal bitte nicht gegen den Baum!" `&Worauf `^Z`@u`^d`@u`& erwidert `3"Wenn du deinen Mund endlich h�lst, treff ich besser!" `&`^Z`@u`^d`@u`& schleudert `@B`goi`8nd`&il`& gegen dich. `@B`goi`8nd`&il`&s Kopf trifft dich mit voller Wucht gegen den Bauch, worauf du 5 Runden lang bewusstlos daliegst.';
        $session['user']['turns']-=5;
        $session['user']['specialinc']="";

}
output("$out");
?>