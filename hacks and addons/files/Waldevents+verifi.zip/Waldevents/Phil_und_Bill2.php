<?php
/**
           BY Mr edah & Silva
            www.edahnien.de
              V 1.0 FINAL
*/
//farben
$colorstandart = '`M';
$colormakieren = '`$' ;
$coloremote = '`R';
$colorspeak ='`z';
$colorspeaku ='`t';
$colorspeakbill ='`5';
$colorzahlen ='`C';
$colorwk ='`@';
$colorexp ='`!';
$colorcharm ='`4';
$colorgold ='`^';
$colorgems ='`#';
//�berschrift festlegen
page_header("Phil und Bill - Wie alles begann");
$out ='';
// "op"s
       $session['user']['specialinc']='Phil_und_Bill2.php';
switch($_GET['op'])
{
     case '':
         $_SESSION['session']['debug']='';
         $out .="".$colorstandart."Auf deiner Wanderung durch den Wald gelangst du an das Ufer eines breiten Flusses. Hier �ffnet sich das sonst recht dichte Bl�tterdach und gibt den Blick frei auf einen strahlend blauen Himmel. Die Sonne strahlt dir warm aufs Haupt und ihre Strahlen brechen sich etwas auf der beweglichen Wasseroberfl�che - ein traumhaft sch�ner Anblick! `n
                 Du bist vom Fu�marsch etwas m�de geworden, deswegen setzt du dich auf einen Stein nahe des Wassers. Doch gerade, als du dich hinsetzen willst, f�llt dir ein Lederbeutel auf, der neben dir im Gras liegt. Neugierig nimmst du ihn in die Hand.. deine Finger erf�hlen irgendetwas Eckiges.`n Willst du nicht nachschauen, was es ist?";
         addnav("Nachschauen","forest.php?op=look&id=0");
         addnav("Weitergehen","forest.php?op=leave&id=1");
     break;
     case 'leave':
         $id = $_GET['id'];
         $session['user']['specialinc']='';
         if ($id ==1){
              $out .="".$colorstandart."Der Beutel geh�rt nicht dir.. sicher hat ihn ein anderer Wanderer hier vergessen. Also legst du ihn dorthin zur�ck, wo du ihn gefunden hast, genie�t noch ein wenig das sch�ne Wetter und machst dich dann wieder auf den Weg.`n Du hast ".$colorzahlen." einen ".$colorwk." Waldkampf ".$colorstandart."verloren!";
              $session['user']['turns']-='1';
              $_SESSION['session']['debug'].='Wk-1,';
         }elseif($id ==2)
         {
             $out .= "".$colorstandart."Das wird dir nun aber doch zu pers�nlich... nicht dass du noch in Tr�nen ausbrichst. Schnell l�sst du das Buch ins Gras fallen, erhebst dich und setzt dich in Bewegung. Allerdings l�sst dich das, was du gerade gelesen hast, nicht los - du machst erstmal einen kleinen Spaziergang und verlierst dabei ".$colorzahlen." 10 ".$colorwk." Waldk�mpfe".$colorstandart.".`nDu f�hlst dich sch�big, weil du die Privatsph�re von Phil missachtet hast. Du sch�mst dich und verlierst dadurch ".$colorzahlen." 2 ".$colorcharm." Charmepunkte".$colorstandart.".";
             $session['user']['turns']-='10';
             $session['user']['charm']-='2';
             $_SESSION['session']['debug'].='Wk-10,charm-2,';
        }elseif($id == 3)
        {
             $out .="".$colorstandart."Naja, du hast zwar viel verloren, aber immerhin wei�t du nun, was du das n�chste Mal nicht machen solltest!";
        }elseif($id == 4)
        {
        
             $out .= "".$colorstandart."Du drehst dich um und versucht weg zu gehen ... tja das war wohl zuviel des Guten. Erst Bill, jetzt auch noch du... das reicht Phil. Wie ein dreik�pfiger Affe rennt er hinter dir her.. was du allerdings erst zu sp�t bemerkst. In Null-Komma-Nichts hat er dich eingeholt und br�llt so laut auf dich ein, dass man es selbst im fernen Edahnien h�ren kann. F�r dich ist das definitiv zu laut, dein Herz bleibt vor Schreck stehen.`nDu bist tot!";
             addnews("".$session['user']['name']." `0 starb durch laute Akkustik!");
             $session['user']['alive']=false;
             $session['user']['hitpoints']=0;
             $_SESSION['session']['debug'].="TOT,";
        }elseif($id == 5)
        {
             $werte = explode(",", $_SESSION['session']['zsave']);
             $wk = $werte[0];
             $exp = $werte[1];
             $gold = $werte[2];
             $es = $werte[3];
             $out .="".$colorstandart."Du entscheidest dich, Bill lieber nicht zu helfen und zu verschwinden. Auf dem R�ckweg findest du ".$colorzahlen." $es ".$colorgems."Edelsteine ".$colorstandart."und ".$colorzahlen." $gold ".$colorgold."Gold. ".$colorstandart."Du f�hlst dich wieder besser, sodass du ".$colorzahlen." $wk ".$colorwk."Waldk�mpfe".$colorstandart." mehr hast. Du hast viel �ber Phil und Bill gelernt und bekommst ".$colorzahlen." $exp ".$colorexp."Erfahrungspunkte.".$colorstandart."";
             $session['user']['turns']=$wk;
             $session['user']['experience']=$exp;
             $session['user']['gold']=$gold;
             $session['user']['gems']=$es;
        }
        if ($session['user']['alive']!=false) {
             addnav("Weiter",'forest.php');
        }else{
            addnav("Zu den News","news.php");
        }
     break;
     case 'look':
        $id = $_GET['id'];
        if ($id ==0)
        {
             $out .="".$colorstandart."Langsam n�herst du dich dem Lederriemen, nimmt ihn z�rtlich in die Hand und ziehst sachte daran - er �ffnet sich. Du greifst in den Beutel, voller Vorfreude.. wie viel Gold wird da wohl drin sein? .. Oder sind es Edelsteine?`nAls deine Blicke das Innere des Lederbeutels untersuchen, fallen deine Vorstellungen jedoch sofort in den Keller: Kein Gold, keine Edelsteine.. nur ein schlichtes, in Leder gebundenes Buch. Du willst es gerade frustriert wegwerfen, als dir in den Sinn kommt, zumindest einmal einen Blick hinein zu werfen. `nGleich auf der ersten Seite springt dir die Zeile ".$colormakieren."\"Phils Tagebuch\" ".$colorstandart."entgegen. `n Deine Neugier steigt und du wei�t genau: Wenn du es jetzt wegwirfst, wirst du dir dein ganzes Leben lang Vorw�rfe machen.. dich mit der Frage qu�len, was wohl in dem Tagebuch steht - also klappst du die n�chste Seite auf und beginnst zu lesen.`n
                      ".$coloremote." `c Ey Tagebuch,`n�hh also, ich wollt net st�ren, aber ey, du bist meins, also haste gelitten! Hahaha!`nMir geht es so verdammich schlecht, Alter.. Dieser eine Typ da, mit dem coolen Kopp da, der geht mir einfach nimmer ausm Herz weg. Des is voll doof und so...`n Naja, aber nun will ich dir erstma sagen, wat wa gemacht haben... Nichts.. einfach nichts, nur dumm angeguckt - voll phillig, oda?`n`n
                      ".$colorstandart." ~ N�chster Eintrag ~ `c ";
             addnav("Weiter","forest.php?op=look&id=1");
             addnav("Deprimiert verschwinden","forest.php?op=leave&id=2");
        }elseif($id == 1)
        {
             $out .= "".$coloremote."`c Wei�te, das hat so angefangen: Der Bill, der Geile, der wollt eigentlich meine Oma.. aber die war net da, also hat der mir nen Lied geschrieben.. und dat ging so:`n`n \"Hier kommt Phil,`n der mal Bills Mann werden will! `n Doch der Bill steht net auf den Phil, auch wenn der das so gerne haben will...`n`nUnd dann, ne, dann hab ich ihn in seinen.. na, du wei�t schon.. gebissen - und dann sagte der doch glatt: \"Schlampe!\" Joa, und seitdem bin ich Phil, die Schlampe.. Aber das macht mich ganz traurig, weil.. wei� auch nich... ".$colorstandart." `n`n~ N�chster Eintrag ~ `c ";
             addnav("Weiter","forest.php?op=look&id=2");
             addnav("Deprimiert verschwinden","forest.php?op=leave&id=2");
           
        }elseif($id == 2)
        {
             $out .= "".$colorstandart."Ganz gebannt von Phils Tagebuch f�llt dir gar nicht auf, wie die Zeit vergeht. Du bist so vertieft, dass du um dich herum alles ausblendest.. und nicht mitbekommst, wie dir dein Beutel mit Gold und Edelsteinen aus der Tasche f�llt. Du musst unbedingt wissen, wie es weitergeht... es ist wie eine Sucht. Alles, was du bisher gelernt hast, verschwindet aus deinen Gedanken.".$colormakieren." `nDu verlierst all deine ".$colorwk."Waldk�mpfe".$colorstandart.",".$colorexp." Erfahrungspunkte".$colorstandart.", ".$colorgold."Gold ".$colorstandart."und".$colorgems." Edelsteine".$colorstandart."!`n`n".$colorstandart."Gerade, als du dich dar�ber �rgern willst, packt dich eine Hand von hinten und rei�t dich hoch. Rasch drehst du dich um und blickst in das Gesicht eines dunkelrot angelaufenen und komisch anzusehenden Mannes. Er schreit dich an: ".$colorspeak." WAS MACHST DU DA MIT MEINEM TAGEBUCH?? WER HAT DIR DAS ERLAUBT, DARIN HERUM ZU SCHN�FFELN???".$colorstandart." Aalglatt antwortest du: ".$colorspeaku."Deine Oma!".$colorstandart.", woraufhin dein Gegen�ber lauthals anf�ngt zu fluchen: ".$colorspeak."WAS, MEINE OMA?? BOAH, WIE ICH SIE ... WARUM SAGT SIE DAS DENN ALLEN? SO EIN SCHWEINEMIST!! PAH! WENN DU JETZT SOWIESO SCHON ALLES WEISST, WILL ICH DIR DEN REST AUCH NOCH SAGEN: BILL LIEBT MICH NICHT MEHR!! SEID ICH IHM DIE HAARE HAB ABSCHNEIDEN LASSEN, WILL ER NUR NOCH...".$colorstandart." Phil rennt mit Tr�nen in den Augen von dannen.";
             $_SESSION['session']['zsave']="".$session['user']['turns'].",".$session['user']['experience'].",".$session['user']['gold'].",".$session['user']['gems']."";
             $session['user']['turns']='0';
             $session['user']['experience']='0';
             $session['user']['gold']='0';
             $session['user']['gems']='0';
             addnav("Verschwinden","forest.php?op=leave&id=3");
             addnav("Phil hinterher laufen","forest.php?op=look&id=3");
             
        }elseif($id == 3)
        {
           $out .="".$colorstandart."Bill? Haare schneiden?? Da musst du unbedingt mehr wissen! Schnell l�ufst du Phil hinterher.. oder versuchst es zumindest. Der Kerl ist allerdings ganz sch�n schnell, und du hast ziemliche Probleme, ihn zwischen den ganzen B�schen nicht aus den Augen zu verlieren. Schon kurze Zeit sp�ter bist du so aus der Puste, dass du bereits mit dem Gedanken spielst, die Verfolgung aufzugeben.. doch zu deinem Gl�ck stoppt Phil pl�tzlich und bleibt wie angewurzelt stehen. �berrascht machst auch du langsam, kommst - unter ziemlichem Keuchen - hinter dem Mann zum Stehen und willst ihn schon fragen, was seine Worte eben denn nun genau zu bedeuten haben.. doch l�sst du dieses Vorhaben gleich wieder fallen, als du merkst, dass Phil gar nicht in deine Richtung sieht. Stattdessen starrt er direkt vor sich.. von wo - wie du feststellst, als du seinem Blick folgst - ein ziemlich w�st aussehendes Weib zur�ckstarrt. Die Haare der Frau sind kurz geschnitten und vollkommen zerzaust.. kein Zweifel: Vor dir steht BILL von Tokio Hotel!
                  ".$colorspeakbill."DUUU!!!".$colorstandart.", kreischt Bill mit schriller Stimme und deutet anklagend auf Phil. ".$colorspeakbill."GEH BLOSS WEG! ICH WILL DICH NIIIE WIEDER SEHN!! ".$colorstandart."Phils Augen werden gro�. ".$colorspeak."Aber.. Schnucki Putzii... ".$colorspeakbill."Geh W��G!! ".$colorspeak."Aba.. aba wohin denn? ".$colorspeakbill."Zu deiner OMAA!!! ".$colorstandart."Und mit diesen Worten will Bill sich schon wieder herumdrehen und gehen. Hilfe suchend blickt Phil zu dir.. er scheint den Tr�nen nahe.`nWillst du ihm versuchen zu helfen?";
                  addnav("Phil helfen","forest.php?op=look&id=4");
                  addnav("Phil nicht helfen","forest.php?op=leave&id=4");
        }elseif($id == 4)
        {
           $out .= "".$colorstandart."Du siehst, wie Phil den Tr�nen nahe ist, und dir wird bewusst, dass lediglich du noch Schlimmeres verhindern kannst. Zum Gl�ck hast du das Tagebuch gelesen, so wei�t du wenigstens, dass es Phil ernst ist. Bill will gerade das Weite suchen, da liegt auch schon deine Hand auf seiner Schulter: ".$colorspeaku."Hey sei doch nicht so.. er kann doch nichts daf�r, dass er so ist, wie er ist. Geb ihm eine Chance... Au�erdem sehen deine Haare doch richtig schick aus! ".$colorstandart."Du knuffst ihn in die Seite.".$colorspeaku." Wie w�re es, wenn du ihm einfach in Frauensachen steckst und ihm �ber den Dorfplatz jagst?".$colorspeakbill." �h jahh, das is gut , aber ich.. kann das nicht, ich schaff das nicht alleine... Sieh mich doch an.. mit dieser Frisur kann ich mich doch nirgends blicken lassen... Bitte, mach du das f�r mich! Ich w�rde dir auch etwas daf�r geben!".$colorstandart." Willst du Bill helfen?";
           addnav("Bill helfen","forest.php?op=look&id=5");
           addnav("Bill nicht helfen","forest.php?op=leave&id=5");
        }elseif($id == 5)
        {
           $werte = explode(",", $_SESSION['session']['zsave']);
           $exp = $werte[1];
           $out .= "".$colorstandart."Du gehst auf Phil zu und packst ihn von hinten. Als h�tte er den Braten gerochen, haut er dir gegen deinen Kiefer. ".$colormakieren."AUTSCH! `n".$colorstandart."Noch mal wirst du das sicher nicht machen! `nDu fl�chtest in den Wald. Wenigstens wei�t du, was du in Zukunft nicht mehr machen wirst, und bekommst dadurch ".$colorzahlen." $exp ".$colorexp."Erfahrungspunkte.";
           $session['user']['experience']=$exp;
           $session[user][specialinc]="Phil_und_Bill2.php";
           addnav("Bills Auftrag noch mal versuchen","forest.php?op=kampf");
           addnav("In den Wald","forest.php");
        }elseif($id == 6)
        {
            $out .=''.$colorstandart.'Du ziehts Phil an dich heran was hast du zu bieten?'.$colorspeak.' Ich also ich erz�hle dir etwas �ber meine wahre liebe nicht diesen komsichen Bill,'.$colorstandart.'.. du schaust zu den Frauenkleidern'.$colorspeak.'.. aehh jaja .. ich geb dir alles was ich hab .. ich .. kenne .. einen Gott der gibt dir alles von schlechtem Sex bis Ramius ist alles drinne'.$colorstandart.' er z�hlt an seinen fingern ab .. kommt aber irgendwie nicht weiter als zwei..'.$colorspeak.' k�nnte ich nur weiter z�hlen'.$colorstandart.' huscht es �ber seine Lippen, dann ist es still nun ist deine Endscheidung gefragt';
            addnav("Phils Vorschlag annhemen","forest.php?op=look&id=7");
            addnav("Bills Auftrag beenden","forest.php?op=philfrau");
        }elseif($id == 7)
        {
             $werte = explode(",", $_SESSION['session']['zsave']);
             $wk = $werte[0];
             $exp = $werte[1];
             $gold = $werte[2];
             $es = $werte[3];
             $session['user']['turns']=$wk;
             $session['user']['experience']=$exp;
             $session['user']['gold']=$gold;
             $session['user']['gems']=$es;
             $session['user']['specialinc']=''; 
            $out .=''.$colorstandart.' Du hast Phils Vorschlag angenommen und so beginnt Phil zu erz�hlen '.$colorspeak.' damals als ich noch ein begeisterter �ttinger Trinker war fing alles an ich traf diesen Stefan der mir heute so viel bedeutet den ich mehr als mich selber, ach was sag ich da mehr als �ttinger Liebe mit dem ich immer und ewig haben will mit dem ich mehr Becks machen will als Sex zu haben, mit dem ich mehr, naja ist ja auch egal ich leibe ihn eben nur dieser Bill der is .. der l�sst mich nicht in ruhe .. es ist der Fluch .. des Reimes ... und ich weis nicht wie ich diesen loswerden kann ... niemand weis das ... vielleicht findest es jemand heraus .. das hoffe ich so sehr ... dann werde ich ihn endlich los ...';
            $out .="du bekommst ".$colorzahlen." $es ".$colorgems."Edelsteine ".$colorstandart."und ".$colorzahlen." $gold ".$colorgold."Gold. ".$colorstandart."Du f�hlst dich wieder besser, sodass du ".$colorzahlen." $wk ".$colorwk."Waldk�mpfe".$colorstandart." mehr hast. Du hast viel �ber Phil und Bill gelernt und bekommst ".$colorzahlen." $exp ".$colorexp."Erfahrungspunkte.".$colorstandart."";

             addnav("- The end -","forest.php");
        }
        
     break;
     case 'kampf':
//kampf
       $maxh = $session['user']['maxhitpoints'];
       $att = $session['user']['attack'];
       $def = $session['user']['defence'];
       $badguy = array(
               "creaturename"=>"`% Phil `0"
               ,"creaturelevel"=>$session['user']['level']
               ,"creatureweapon"=>"`4 �ttingerflasche`0"
               ,"creatureattack"=>$att +=2
               ,"creaturedefense"=>$def -=5
               ,"creaturehealth"=>$max +=50
               ,"diddamage"=>0);
       $session['user']['badguy']=createstring($badguy);
       $_GET['op']="fight";
        $battle=true;
        $session[user][specialinc]="Phil_und_Bill2.php";
     break;
     case 'run':
        output("`c`b`\$Es gelingt dir nicht zu entkommen.`0`b`c`n`n");
        $battle=true;
     break;
     case 'fight':
        $battle=true;
        $session[user][specialinc]="Phil_und_Bill2.php";
     break;
     break;
     case 'philfrau':
             $werte = explode(",", $_SESSION['session']['zsave']);
             $wk = $werte[0];
             $exp = $werte[1];
             $gold = $werte[2];
             $es = $werte[3];
             $session['user']['turns']=$wk;
             $session['user']['experience']=$exp;
             $session['user']['gold']=$gold;
             $session['user']['gems']=$es;
             $session['user']['specialinc']=''; 
        $out .= "".$colorstandard."So verlockend Phils Angebot auch klingt.. du hast Bill deine Hilfe versprochen. Au�erdem wolltest du schon immer mal einen Zwerg in Frauenkleidung herumlaufen sehen. Kurzerhand schnappst du dir deinen Gegen�ber, stattest ihn trotz lautem Protestgebr�ll mit einem schicken rosa Kleidchen, zwei Seidenhandschuhen und schwarzen Lackschuhen aus und schleifst ihn anschlie�end zur�ck ins Dorf. Die Blicke, die du dabei von den umstehenden Leuten erntest, steigern deine gute Laune um ein Vielfaches.. das Grinsen wirst du sicher noch eine Weile mit dir herumtragen.";
        $out .="du bekommst ".$colorzahlen." $es ".$colorgems."Edelsteine ".$colorstandart."und ".$colorzahlen." $gold ".$colorgold."Gold. ".$colorstandart."Du f�hlst dich wieder besser, sodass du ".$colorzahlen." $wk ".$colorwk."Waldk�mpfe".$colorstandart." mehr hast. Du hast viel �ber Phil und Bill gelernt und bekommst ".$colorzahlen." $exp ".$colorexp."Erfahrungspunkte.".$colorstandart."";

             addnav("- The end -","forest.php");
        $session['bufflist']['Phil'] = array("name"=>"`^Richtig gute Laune",
            "rounds"=>20,
            "wearoff"=>"`^Deine Laune normalisiert sich wieder.",
            "atkmod"=>2,
            "roundmsg"=>"`^Durch dein breites Grinsen ist dein Gegner derart verunsichert, dass du besser gegen ihn k�mpfen kannst!",
            "activate"=>"defense");
        if ($session['user']['sex']>0)
        {
            addnews("".$session['user']['name']." `0 wurde beobachtet, wie sie einen Zwerg in Frauenkleidern hinter sich herschleifte.");
        }
        else
        {
            addnews("".$session['user']['name']." `0 wurde beobachtet, wie er einen Zwerg in Frauenkleidern hinter sich herschleifte.");
        }
}
if ($battle) {
    include("battle.php");
        if ($victory){
             $badguy=array();
             $session['user']['badguy']="";
             $session[user][specialinc]="Phil_und_Bill2.php";
             $out .=''.$colorstandart.'Du gewinnst gegen Phil, aber so schnell gibt er nicht auf er macht dir einen vorschlag willst du darauf eingehen?';
             addnav("Bills Auftrag erledigen","forest.php?op=philfrau");
             addnav("Phils Vorschlag anh�ren","forest.php?op=look&id=6");
        }elseif($defeat)
        {
             $badguy=array();
             $out .=''.$colorstandart.'Phil macht dich kalt! Zu dumm.. nun musst du wohl in Phils Frauensachen rumlaufen...';
             $session['user']['weapon']='Gro�e Oberweite';
             $session['user']['armor']='String Tanga';
	     addnav("In den Wald","forest.php");
            addnews("".$session['user']['name']."`b `\$ wurde mit`i gro�er Oberweite`i und `% Pinkten String Tange`\$ gesehn`b");

             $session[user][specialinc]='';
        }
        else
        {
            fightnav(true,true);
        }
}

output("$out");
 page_footer();
?>
