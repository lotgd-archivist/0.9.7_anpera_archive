Willkommen lieber Admin,
du hast dich heute dazu endshcieden dir diese Waldevents anzuschauen, ob es ein Fehler ist ? Nunja das wird sich noch zeigen.
In diesem Waldevent pack von mir befinden sich 9 Skripte von mir und Partnern.

Versionen:
Die einen sind aelter die anderen neuer, die aktuellsten bzw offizellen Versionen befinden sich, in der Regel auf Edahnien.de, der source liegt offen daher k�nnt ihr immer schuaen ob es neuere Versionen gibt.

Bugs:
Solltet ihr einen Fehler finden so schriebt ihm auf anpera.net in den ensprechenden Theard, besser jedoch ist wenn ihr mich personlich aufsucht oder das Edahnien Forum nutzt.

Updates
Wenn ihr die Skriipte von mir und partnern abaendert / verbessert w�rde ich begruessen wenn ihr mir das skript + changelog mitsendet, damit ich ggf eure teile in die von mir erstellten versionen mit einbauen kann.

Rechtschreibung:
Einige skripte haben einiges an rechtschreibfehlern drinne, solltet ihr die skripte bearbeitet haben udn einige fehler reusgeamcht haben .. sendet mir doch bitte die neue datei zu damit ich sie an meine Versionen anpassen kann.

Updatenews:

Ich werde sowohl im anpera forum die neusten updates / aenderungen veroeffentlichen. Solltet ihr w�nschen persoenlich infomiert zu werden so wendet euch an mich ich werde euch dann "aufnehmen".


Einbau der skripte:

Alee kommen in den waldevent ornder (special)  bei den Zubo.php muest ihr ggf anpassungen vornehmen die variable "$res" m�sste angepasst werden

Kontakt:

Per email
mr_edah@edahnien.de
via icq
228384514
per skype 
mredah
oder ueber 
www.edahnien.de

Wir lieben mic.. mi ... Eliwood!