<?php
/*
************************************************************************
*                   Waldspezial H�hle in Felsen                        *
* By Mr edah und Ajuba                                                 *
* Mr edah         http://www.edahnien.de                               *
* Ajuba           http://www.erologd.de                                *
* V 0.5   Final (vorerst)                                              *
*                                                                      *
* History V 0.1 >Bugfixes Ajuba                                        *
*         v 0.2 >Bugfixes Mr edah                                      *
*         v 0.3 >Bugfixes Mr edah                                      *   
*         V 0.4 >Bugfixes Mr edah / Ajuba                              *     
*         V 0.5 >Goldverlsut in der Bank entfernt                      *
* Felsenh�hle Einfach in den Spezial Ordner Kopieren,                  *
* ben�tigt "The Golden Egg von anpera"                                 *
************************************************************************
*/

// Willkommen werter Admin in diesem kleinem Chaos


require_once "common.php";
page_header("Felsen H�hle");


if ($_GET[op]=="")
{
debuglog("Felsen H�hle");

      output("Auf deinen Streifz�gen durch den Wald endeckst du einen Unscheinbaren H�hleneingang. Der Eingang ist  fast komplett zugewuchert.`nWillst du die H�hle betreten?");
      $session[user][specialinc]="felsenhoehle.php";
      addnav("N�her betrachten","forest.php?op=rangehn");
      addnav("Weglaufen","forest.php?op=weglaufen");
}
if ($_GET[op]=="rangehn")
{
switch(e_rand(1,5)){

case 1:
case 2:
case 3:
case 4:
      output("Du betrittst die H�hle und kommst in eine gro�e Halle. Dort betrachtest du staunend die m�chtigen Stalagtiten, die an der Decke h�ngen. In der Halle zweigt links und rechts von dir ein Gang ab. Du kannst nicht erkennen, wohin diese f�hren.");
      addnav("Rechts","forest.php?op=gang");
      addnav("Links","forest.php?op=gang");
       $session[user][specialinc]="felsenhoehle.php";
break;
case 5:
      output("Du betrittst die H�hle und kommst in eine gro�e Halle. Dort betrachtest du staunend die m�chtigen Stalagtiten, die an der Decke h�ngen. In der Halle zweigt links, rechts und in der Mitte ein Gang ab. Du kannst nicht erkennen, wohin diese f�hren.");
      addnav("Rechts","forest.php?op=gang");
      addnav("Mitte","forest.php?op=mittelgang");
      addnav("Links","forest.php?op=gang");
       $session[user][specialinc]="felsenhoehle.php";
} }
if ($_GET[op]=="weglaufen")
{

         output("Dir ist es zu unheimlich. Du drehst dich auf der Stelle um und willst gerade weggehen, als du auf dem Boden vor dir einen Edelstein erblickst. Du gehst in die Knie und betrachtest ihn. \"Welch ein Gl�ck du heute wieder hast, denkst du dir.\" Du nimmst ihn in die Hand und willst ihn einpacken, doch l�st du damit eine Falle aus. Du wirst in die H�he gerissen und h�ngst in einem Sack. Es ist dunkel und dir ist ziemlich mulmig zumute.`n Du verlierst`%10`@ Waldk�mpfe, �hm sorry, ich meinte 50 �hh 5 ");
         $session[user][turns]-=5;
         addnav("Um Hilfe rufen","forest.php?op=hilfe");
         addnav("Sterben","forest.php?op=sterben");
         $session[user][specialinc]="felsenhoehle.php";
}
if ($_GET[op]=="sterben")
{
    output(" Du ziehst deinen Dolch und willst dich gerade umbringen, als dir einf�llt, dass du den Sack einfach zerschneiden k�nntest, was du auch sogleich machst.`n `n Du plumpst aus dem Sack nach unten, f�llst ungl�cklich in deinen Dolch, welcher dir einen h�sslichen Schnitt im Gesicht verpasst. Du verlierst 3 Charmepunkte. Wieder zu Hause stellst du dich vor einen Spiegel und schaust hinein. Der Spiegel ist so schockiert �ber dich, dass du dir glatt eine Backpfeife verpasst, woraufhin du nochmal 3 Charmepunkte verlierst. Sch�n bl�d");
     $session[user][charm]-=6;
     addnav("Rausrennen","forest.php?op=run2");
      $session[user][specialinc]="felsenhoehle.php";
}
if ($_GET[op]=="hilfe")
{
    output("Du schreist so laut du kannst um Hilfe, doch leider h�rt dich niemand. Au�er die Monster im Wald. Du h�ngst und rufst stundenlang. Schlie�lich f�llt der Sack vom Baum. Du landest unsanft, aber weich. Du sp�rst ein Ruckeln. Es dauert eine Weile, doch dann h�rt es auf .. jemand �ffnet den Sack");
switch(e_rand(1,2)){


case 1:
    output("Erleichtert stellst du fest, dass du dich in einer Stadt befindest,");

switch(e_rand(1,2)){
case 1:
    output("Zu deiner Verwunderung musst du jedoch feststellen, dass du dich in einem K�fig befindest. Du schaust den Mann an, welcher dich hinaus gelassen hat. Er zieht ein Schwert und reicht es dir. Ehe du etwas sagen kannst, verschwindet er aus dem K�fig und bet�tigt einen Schalter");

switch(e_rand(1,2)){
    case 1:
     output(" Ein sehr hungriges Tier kommt auf dich zu gerannt. Du kannst die Waffe nicht schnell genug hochziehen und das Tier rei�t dich in 892 St�cke");
     $session[user][alive]=false;
     $session[user][hitpoints]=0;
     addnav("Zu den News","news.php");
      $session[user][specialinc]="felsenhoehle.php";
break;
case 2:
   output("Dir wird auf einmal ganz schwindelig. Du schlie�t die Augen und als du wieder aufwachst, bist du wieder auf dem Dorfplatz. Du f�hlst dich im wahrsten Sinne des Wortes ziemlich erleichtert.`n Du bist splitternackt, verlierst all dein Gold und die Edelsteine, die du dabei hattest. Dazu wird dich in der Bank eine b�se �berraschung erwarten oder Freude.. oder auch gar nichts ?");

   $session[user][gold]=0;
   $session['user']['gems']=0;
   addnav("weiter","village.php");
}
break;
  case 2:

     output("Du wurdest zum Dorfplatz gebracht. Dankbar f�r die Hilfe gibst du ihnen deinen Goldbeutel als Belohnung");
    $session[user][gold]=0;
     addnav("weiter","village.php");

}
break;
case 2:
      output(" Du findest dich in einem Hexenhaus wieder. Die Hexe missbraucht dich f�r neue Tr�nke. Du kannst das Haus verlassen, als du Hasenohren bekommen hast und einen sonderbaren Stummelschwanz am Hintern tr�gst");
      addnews("".$session['user']['name']."`qwurde mit `%rosa`0Hasenohren und Stummelschw�nzchen gesehen. Ja ist denn heut� schon Ostern???");
      addnav("weiter","village.php");
}

    }


if ($_GET[op]=="mittelgang")
{
switch(e_rand(1,2)){
case 1:
      output("Du gehst einen schier endlosen Gang entlang. Nach etlichen Stunden l�sst du dich ersch�pft nieder und irgendwas piekst dich in dein Ges��. Du nimmst keine Notiz davon und seufzt tief. Zu tief. Du stirbst !");
     addnews("".$session['user']['name']."`@ ist an einem Seufzer gestorben?!?!");
     $session[user][alive]=false;
     $session[user][hitpoints]=0;
     addnav("Zu den News","news.php");
break;

case 2:

if (getsetting("hasegg",0)!=0){
      output("Pech gehabt! Hier ist nichts");
      addnav("weiter","forest.php");
}else{
output("Du kommst in einen kleinen Raum, in dem auf einem Alter, du traust deinen Augen nicht, das goldene Ei liegt. Du kannst dein Gl�ck gar nicht fassen und nimmst es mit!");
savesetting("hasegg",stripslashes($session[user][acctid]));
addnews("`^".$session[user][name]."`^ hat das goldene Ei in einer H�hle gefunden!");
}
  }

}

if ($_GET[op]=="run2")
{
output("Auf deiner heillosen Flucht stolperst du �ber eine Fu�angel, fluchst leise und erhebst dich wieder, um schnell weiterzurennen. Als du nach \"Wiener L�nge \" stehen bleibst stellst du fest, dass du deine Waffe verloren hast.");

        $sch=$session[user][weapondmg];
        $session[user][weapon]="Keine";
        $session[user][weaponvalue]=0;
        $session[user][weapondmg]=0;
        $session[user][attack]-=$sch;
}

if ($_GET[op]=="gang")
{
switch(e_rand(1,2)){

case 1:
         

      output("Du dringst vorsichtig tiefer die H�hle ein und endeckst ein Schwert, das auf einem Steinsockel liegt.");
       addnav("Das Schwert liegenlassen","forest.php?op=kampf");
$session[user][specialinc]="felsenhoehle.php";
addnav("Nach dem Schwert greifen","forest.php?op=schwert");
       


break;
case 2:
        output("Du musst k�mpfen");
            $session[user][specialinc]="felsenhoehle.php";
        addnav("K�mpfen","forest.php?op=kampf");


}
}
if ($_GET[op]=="schwert")
{
        output("Du ergreifst das Schwert und betrachtest es sorgf�ltig, um es dann mit einem zufriedenen Nicken in deinem Rucksack zu verstauen");
        $sql="INSERT INTO items (name,class,owner,value1,gold,description) VALUES ('`4Schwert','Waffe','".$session[user][acctid]."','16','15000','Ein Schwert aus einer H�hle')";
        db_query($sql);

        addnav("Zufrieden in den Wald gehn","forest.php");

}

//kampf 


if ($_GET[op]=="kampf")
{
$maxh = $session['user']['maxhitpoints'];
$att = $session['user']['attack'];
$def = $session['user']['defence'];

$badguy = array(
"creaturename"=>"`& Skelettkriegerchen `0"
,"creaturelevel"=>$session['user']['level']
,"creatureweapon"=>"`4Schwert`0"
,"creatureattack"=>$att +=2
,"creaturedefense"=>$def -=5
,"creaturehealth"=>$max +=50
,"diddamage"=>0);
$session['user']['badguy']=createstring($badguy);

$HTTP_GET_VARS['op']="fight";

}

if ($HTTP_GET_VARS[op]=="run"){
    
        output("`c`b`\$Es gelingt dir nicht zu entkommen.`0`b`c`n`n");
        $battle=true;
}

if ($HTTP_GET_VARS['op']=="fight"){
    $battle=true;
     $session[user][specialinc]="felsenhoehle.php"; 
}

if ($battle) {
    include("battle.php");
        if ($victory){
             $badguy=array();
               $session['user']['badguy']=""; 
     $session[user][specialinc]="felsenhoehle.php";                       
addnav("Weiter Gehen","forest.php?op=gang1");      			addnav("Rausrennen","forest.php?op=run2");
$session['user']['experience']+=1000;
output("`nDu hast `^".$badguy['creaturename']." besiegt.`nDu triffst den Skelettkrieger mit einem vernichtenden Schlag. Woraufhin dieser zu Boden geht. Du f�hlst dich erfahrener.");
}
elseif($defeat)
        {
        $badguy=array();

                output("Du wurdest von ".$badguy['creaturename']." besiegt. Du bist alles andere als lebendig. ");
                $session[user][alive]=false;
                $session[user][hitpoints]=0;
   
              



                addnav("T�gliche News","news.php");
}
else
{
fightnav(true,true);
  }
}

if ($_GET[op]=="gang1")
        switch(e_rand(1,2)){
case 1:

output("Als du weiter gehst endeckst du eine Gruft die du sogleich betrittst, das innere kommt die bekannt vor und als du dich unschaust merkst du das du in den Schatten gelandet bist...");

addnews($session['user']['name']." ist aus irgendeinem Grund gestorben");

$session[user][alive]=false;
$session[user][hitpoints]=0;

addnav("Zu den News","news.php");

break;
case 2:

output("Als du weiter gehst endeckst du eine Gruft die du sogleich betrittst, auf einem Sockel steht eine Urne die du �ffnest.In der Urne findest du einen Schrumpfkopf und �berlegst dir was du nun damitt machst");
$session[user][specialinc]="felsenhoehle.php";
addnav("ihn k�ssen","forest.php?op=kuessen");
addnav("in die Augen sehen","forest.php?op=augen");
addnav("achtlos wegwerfen","forest.php?op=werfen");


}

if($_GET['op']=="kuessen")
{
output("leicht verwundert �ber dich selbst k�sst du den Schrumpfkopf und wirst charmanter");
$session[user][charm]+=10;
addnav("zur�ck in den Wald","forest.php");
}

if($_GET['op']=="augen")
{
output("du schaust dem Schrumpfkopf in die Augen und erkennst das es sich um Edelsteine handelt die du sogleich an dich nimmst");
$session['user']['gems']+=2;
addnav("zur�ck in den Wald","forest.php");
}

if($_GET['op']=="werfen")
{
output("angewiedert wirfst du den Schrumpfkopf weg. Der zersplittert in viele Teile und du hast das Gef�hl etwas schreckliches angerichtet zu haben.Du f�hlst einen stechenden Schmerz und bist tot");

$session[user][alive]=false;
$session[user][hitpoints]=0;
addnav("Zu den News","news.php");

}


?>