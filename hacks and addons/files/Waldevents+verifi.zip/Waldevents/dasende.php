<?php
######################################################
# das Ende                                           #
# by Ajuba und Mr edah unter Mithilfe von Beck's     #
# www.lottr.de/lodg                                  #
# www.edahnien.de                                    #
######################################################
/*
page_header("Das Ende");
$gol=$session[user][gold];
$max=$session[user][maxhitpoints];
$hit=$session[user][hitpoints];
$lev=$session[user][level];
$ggwin= $gol-$max+$hit+$lev;

if ($_GET[op]=="")
{

//der Anfang

$session[user][specialinc]="dasende.php";

output('Du triffst einen dunkel gekleideten Mann im Wald der dir mit lauter Stimme verk�ndet "Hier ist das Ende!"');
addnav("Ausfragen","forest.php?op=ausf");
addnav("Ihn verwirrt ansehen","forest.php?op=wirr");
addnav("Fl�chten","forest.php?op=flue");
}

if ($_GET[op]=="ausf")
{
        output('Du willst ihn grade fragen "welches Ende?" als er lachend davonl�uft. Kopfsch�ttelnd �berlegst du, was du nun besser bleiben lassen solltest.');
        $session[user][specialinc]="dasende.php";
        //Spass muss sein
        addnav("Bleiben","forest.php?op=geh");
        addnav("Nur weg hier","forest.php?op=bleib");
}
if ($_GET[op]=="wirr")
{
        output("Du bis so verwirrt das du noch einige Stunden stehen bleibst. Der Mann ist l�ngst verschwunden. Du verlierst 5 Waldk�mpfe");
        $session[user][turns]-=5;
        addnews("".$session[user][name]." steht verwirt im Wald!");
}
if ($_GET[op]=="geh")
{
        output('als du grade in den Wald zur�ck willst stolperst du �ber einen Ast und landest mit der Stirn auf einem spitz zugeschliffenen Edelstein. Ist das das Ende von dem er sprach?');
        addnews("".$session['user']['name']." sollte besser zuh�hren");
        $session[user][alive]=false;
        $session[user][hitpoints]=0;
        addnav("Zu den News","news.php");
}
if ($_GET[op]=="bleib")
{
        $session[user][specialinc]="dasende.php";
        output('Du hast dich entschieden hier zu bleiben unsicher, schaust du dich um und suchst nach dem vermeindlichen Ende. Du kannst jedoch nur einen Farbverlauf erkennen der sich erst beim dritten Hinsehen als Regenbogen zu erkennen gibt. In alten Geschichten hast du geh�rt, das am Ende eines Regenbogens eigentlich immer ein Topf mit Gold zu finden ist. Ohne lange weiter zu �berlegen st�rmst du los.');
        output("Kaum bist du angekommen stellst du auch schon fest das du nicht alleine bist. Von irgendwoher vernimmst du ein leises Winseln. Du willst grade weitergehen, doch st�sst du mit dem Knie gegen etwas ... das sofort schmerzhaft aufst�hnt. Du schaust zu Boden und siehst einen kleinen Gnom vor dir sitzen, der wie gebannt in einen Topf starrt und leise fl�stert: `tmein Schatz!`0 ");
        output(" Eigentlich ist es dir auch egal und so schaust du dich weiter nach dem Topf mit Gold um, gerade noch rechtzeitig f�llt dir ein das du ihn bereits gefunden hast .. er wird von dem Wesen umklammert. Was willst du nun tun?");
        addnav("Topf klauen","forest.php?op=topfkl");
        addnav("Dein Schatz?","forest.php?op=schagno");
}

if ($_GET[op]=="topfkl")
{
        $session[user][specialinc]="";
        output('Du reist dem Gnom den Topf aus der Hand. Er ist nicht sehr erfreut dar�ber und so haut er wie wild auf dich ein');
switch(e_rand(1,3))
{
case 1:
case 2:
     output("Du kannst mit dem Gold nicht verschwinden, kommst aber mit einem blauen Auge davon.");
     addnews("".$session[user][name]." hat nun ein blaues Auge.");
     $newtitel="`9Blauauge`0";
       $n = $session['user']['name'];
if ($session[user][ctitle]==""){
            $neu=$newtitel.substr($n,strlen($session[user][title]));

} else {
        $neu=$newtitel.substr($n,strlen($session[user][ctitle]));
}
           $session['user']['name']=$neu;
           $session[user][title]=$newtitel;
     addnav("Abhauen","forest.php");
break;
case 3:   //Ggewinnberechnung by Mr edah da war wohl viel Becks dabei :P

     output("Du trittst den Gnom vor die F�sse worauf dieser jaulend davon rennt. Du bekommst `^$ggwin `0Gold");
     $session[user][gold]+=$ggwin;
     addnav("Abhauen","forest.php");
}
   }
if ($_GET[op]=="schagno")
{
        $session[user][specialinc]="dasende.php";
        output("W�tend schaust du den Gnom an. `^Dein Schatz? Nicht mehr lange!`0 Sagst du und ziehst deine Waffe");
//kampf
$maxh = $session['user']['maxhitpoints'];
$att = $session['user']['attack'];
$def = $session['user']['defence'];

$badguy = array(
"creaturename"=>"`& Gnom `0"
,"creaturelevel"=>$session['user']['level']
,"creatureweapon"=>"`4Nagelkeule`0"
,"creatureattack"=>$att +=2
,"creaturedefense"=>$def -=5
,"creaturehealth"=>$max +=50
,"diddamage"=>0);
$session['user']['badguy']=createstring($badguy);

$HTTP_GET_VARS['op']="fight";

}

if ($HTTP_GET_VARS[op]=="run"){

        output("`c`b`\$Es gelingt dir nicht zu entkommen.`0`b`c`n`n");
        $battle=true;
}

if ($HTTP_GET_VARS['op']=="fight"){
    $battle=true;
     $session[user][specialinc]="dasende.php";
}

if ($battle) {
    include("battle.php");
        if ($victory){
             $badguy=array();
               $session['user']['badguy']="";
     $session[user][specialinc]="";
$session['user']['experience']+=1000;
$session['user']['gold']+=$ggwin;
output("`nDu hast `^ gesiegt.`0`nDu triffst den Gnom mit einem vernichtenden Schlag. Woraufhin dieser zu Boden geht. Gl�cklich schnappst du dir den Topf mit`^ $ggwin `0Gold und gehst zur�ck in den Wald");
}
elseif($defeat)
        {
        $badguy=array();

                output("Du wurdest von ".$badguy['creaturename']." besiegt.");
                $session[user][alive]=false;
                $session[user][hitpoints]=0;





                addnav("T�gliche News","news.php");
}
else
{
fightnav(true,true);
  }
}
?>