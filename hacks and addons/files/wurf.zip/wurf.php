<?php
// Idee und Umsetzung
// Morpheus f�r www.morpheus-lotgd.de.vu
// Mail to morpheus@magic.ms
// Gewidmet meiner �ber alles geliebten Blume
require_once "common.php";
checkday();
$sql = "SELECT name,reason FROM jail WHERE freedate > NOW()";
$result = db_query($sql);
while($row = db_fetch_assoc($result)) {
$nm=$row[name];
}
page_header("Der Pranger");
if ($_GET['op']=="pfap"){
	if ($session['user']['werfe']<5){
		if ($session['user']['gold']>=1){
			$session['user']['werfe']+=1;
			$session['user']['gold']-=1;
			output("`3Du gehst zu einem der umstehenden `5Gauner`3, die daraus ein Gesch�ft machen, wenn jemand angeprangert ist, und kaufst dir einen `TPf`ter`Tde`tap`Tfel`3.");
			output("`3Mit wucht wirftst Du Dein Geschoss auf $nm `3 und");
				switch(e_rand(1,8)){
					case 1:
					case 2:
					output("`3triffst genau am Kopf! Gut gezielt!");
					$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'jail',".$session['user']['acctid'].",'/me `3wirft einen `TPf`ter`Tde`tap`Tfel `3 auf $nm `3und trifft genau am Kopf!')";
					db_query($sql) or die(db_error(LINK));
					break;
					case 3:
					case 4:
					output("`3triffst an der Schulter!");
					$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'jail',".$session['user']['acctid'].",'/me `3wirft einen `TPf`ter`Tde`tap`Tfel `3 auf $nm `3und trifft die Schulter!')";
					db_query($sql) or die(db_error(LINK));
					break;
					case 5:
					case 6:
					output("`3triffst noch grade so am Bein!");
					$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'jail',".$session['user']['acctid'].",'/me `3wirft einen `TPf`ter`Tde`tap`Tfel `3 auf $nm `3und trifft noch grade das Bein!')";
					db_query($sql) or die(db_error(LINK));
					break;
					case 7:
					case 8:
					output("`3wirfst `4vorbei`3!!! Aus Scham verlierst Du einen Charmpunkt");
					$session['user']['charm']-=1;
					$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'jail',".$session['user']['acctid'].",'/me `3wirft einen `TPf`ter`Tde`tap`Tfel `3 auf $nm `3und wirft Vorbei! Beim n�chsten mal mehr Zielwasser trinken...')";
					db_query($sql) or die(db_error(LINK));
					break;
				}
			addnav("W?Weiter","jail.php");
		}else{
			output("`3Du gehst zu einem der umstehenden `5Gauner`3, die daraus ein Gesch�ft machen, wenn jemand angeprangert ist, und wilst Dir einen `TPf`ter`Tde`tap`Tfel`3 kaufen, hast aber nicht genug `^Gold `3 dabei.");
			addnav("W?Weiter","jail.php");
		}
	}else{
		output("`4Du hast schon genug geworfen f�r heute.");
		addnav("W?Weiter","jail.php");
	}
}
if ($_GET['op']=="tom"){
	if ($session['user']['werfe']<5){
		if ($session['user']['gold']>=2){
			$session['user']['werfe']+=1;
			$session['user']['gold']-=2;
			output("`3Du gehst zu einem der umstehenden `5Gauner`3, die daraus ein Gesch�ft machen, wenn jemand angeprangert ist, und kaufst dir eine faule `\$To`4ma`\$te`3.");
			output("`3Mit wucht wirftst Du Dein Geschoss auf $nm `3 und");
				switch(e_rand(1,8)){
					case 1:
					case 2:
					output("`3triffst genau am Kopf! Gut gezielt!");
					$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'jail',".$session['user']['acctid'].",'/me `3wirft eine faule `\$To`4ma`\$te `3 auf $nm `3und trifft genau am Kopf!')";
					db_query($sql) or die(db_error(LINK));
					break;
					case 3:
					case 4:
					output("`3triffst an der Schulter!");
					$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'jail',".$session['user']['acctid'].",'/me `3wirft eine faule `\$To`4ma`\$te `3 auf $nm `3und trifft die Schulter!')";
					db_query($sql) or die(db_error(LINK));
					break;
					case 5:
					case 6:
					output("`3triffst noch grade so am Bein!");
					$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'jail',".$session['user']['acctid'].",'/me `3wirft eine faule `\$To`4ma`\$te `3 auf $nm `3und trifft noch grade das Bein!')";
					db_query($sql) or die(db_error(LINK));
					break;
					case 7:
					case 8:
					output("`3wirfst `4vorbei`3!!! Aus Scham verlierst Du einen Charmpunkt");
					$session['user']['charm']-=1;
					$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'jail',".$session['user']['acctid'].",'/me `3wirft eine faule `\$To`4ma`\$te `3 auf $nm `3und wirft Vorbei! Beim n�chsten mal mehr Zielwasser trinken...')";
					db_query($sql) or die(db_error(LINK));
					break;
				}
			addnav("W?Weiter","jail.php");
		}else{
			output("`3Du gehst zu einem der umstehenden `5Gauner`3, die daraus ein Gesch�ft machen, wenn jemand angeprangert ist, und wilst Dir eine faule `\$To`4ma`\$te`3 kaufen, hast aber nicht genug `^Gold `3 dabei.");
			addnav("W?Weiter","jail.php");
		}
	}else{
		output("`4Du hast schon genug geworfen f�r heute.");
		addnav("W?Weiter","jail.php");
	}
}
if ($_GET['op']=="ei"){
	if ($session['user']['werfe']<5){
		if ($session['user']['gold']>=3){
			$session['user']['werfe']+=1;
			$session['user']['gold']-=3;
			output("`3Du gehst zu einem der umstehenden `5Gauner`3, die daraus ein Gesch�ft machen, wenn jemand angeprangert ist, und kaufst dir ein faules `&Ei`3.");
			output("`3Mit wucht wirftst Du Dein Geschoss auf $nm `3 und");
				switch(e_rand(1,8)){
					case 1:
					case 2:
					output("`3triffst genau am Kopf! Gut gezielt!");
					$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'jail',".$session['user']['acctid'].",'/me `3wirft ein faules `&Ei `3 auf $nm `3und trifft genau am Kopf!')";
					db_query($sql) or die(db_error(LINK));
					break;
					case 3:
					case 4:
					output("`3triffst an der Schulter!");
					$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'jail',".$session['user']['acctid'].",'/me `3wirft ein faules `&Ei`3 auf $nm `3und trifft die Schulter!')";
					db_query($sql) or die(db_error(LINK));
					break;
					case 5:
					case 6:
					output("`3triffst noch grade so am Bein!");
					$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'jail',".$session['user']['acctid'].",'/me `3wirft ein faules `&Ei`3 auf $nm `3und trifft noch grade das Bein!')";
					db_query($sql) or die(db_error(LINK));
					break;
					case 7:
					case 8:
					output("`3wirfst `4vorbei`3!!! Aus Scham verlierst Du einen Charmpunkt");
					$session['user']['charm']-=1;
					$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'jail',".$session['user']['acctid'].",'/me `3wirft ein faules `&Ei `3 auf $nm `3und wirft Vorbei! Beim n�chsten mal mehr Zielwasser trinken...')";
					db_query($sql) or die(db_error(LINK));
					break;
				}
			addnav("W?Weiter","jail.php");
		}else{
			output("`3Du gehst zu einem der umstehenden `5Gauner`3, die daraus ein Gesch�ft machen, wenn jemand angeprangert ist, und wilst Dir ein faules `&Ei`3 kaufen, hast aber nicht genug `^Gold `3 dabei.");
			addnav("W?Weiter","jail.php");
		}
	}else{
		output("`4Du hast schon genug geworfen f�r heute.");
		addnav("W?Weiter","jail.php");
	}
}
if ($_GET['op']=="gem"){
	if ($session['user']['werfe']<5){
		if ($session['user']['gold']>=3){
			$session['user']['werfe']+=1;
			$session['user']['gold']-=3;
			output("`3Du gehst zu einem der umstehenden `5Gauner`3, die daraus ein Gesch�ft machen, wenn jemand angeprangert ist, und kaufst dir faules `2Ge`@m�`2se`3.");
			output("`3Mit wucht wirftst Du Dein Geschoss auf $nm `3 und");
				switch(e_rand(1,8)){
					case 1:
					case 2:
					output("`3triffst genau am Kopf! Gut gezielt!");
					$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'jail',".$session['user']['acctid'].",'/me `3wirft faules `2Ge`@m�`2se `3 auf $nm `3und trifft genau am Kopf!')";
					db_query($sql) or die(db_error(LINK));
					break;
					case 3:
					case 4:
					output("`3triffst an der Schulter!");
					$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'jail',".$session['user']['acctid'].",'/me `3wirft faules `2Ge`@m�`2se`3 auf $nm `3und trifft die Schulter!')";
					db_query($sql) or die(db_error(LINK));
					break;
					case 5:
					case 6:
					output("`3triffst noch grade so am Bein!");
					$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'jail',".$session['user']['acctid'].",'/me `3wirft faules `2Ge`@m�`2se`3 auf $nm `3und trifft noch grade das Bein!')";
					db_query($sql) or die(db_error(LINK));
					break;
					case 7:
					case 8:
					output("`3wirfst `4vorbei`3!!! Aus Scham verlierst Du einen Charmpunkt");
					$session['user']['charm']-=1;
					$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'jail',".$session['user']['acctid'].",'/me `3wirft faules `2Ge`@m�`2se `3 auf $nm `3und wirft Vorbei! Beim n�chsten mal mehr Zielwasser trinken...')";
					db_query($sql) or die(db_error(LINK));
					break;
				}
			addnav("W?Weiter","jail.php");
		}else{
			output("`3Du gehst zu einem der umstehenden `5Gauner`3, die daraus ein Gesch�ft machen, wenn jemand angeprangert ist, und wilst Dir faules `2Ge`@m�`2se`3 kaufen, hast aber nicht genug `^Gold `3 dabei.");
			addnav("W?Weiter","jail.php");
		}
	}else{
		output("`4Du hast schon genug geworfen f�r heute.");
		addnav("W?Weiter","jail.php");
	}
}
page_footer();
?>