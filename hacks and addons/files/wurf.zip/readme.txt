//Erweiterung zum: Pranger-Mod (jail.php)
//Idee und Umsetzung: Morpheus f�r www.morpheus-lotgd.de.vu
//Gewidmet meiner �ber alles geliebten Blume

Als ich tats�chlich mal jemanden anprangern mu�te, schrieben meine User was von geworfenen Eiern und Tomaten. Da ich selbst auch ziemlich sauer auf den Deliquenten war, habe ich eine Erweiterung geschrieben, die es den Usern erlaubt, f�r kleines Gold, Kleinigkeiten von umstehenden H�ndlern zu kaufen und diese zu werfen, woraufhin ein Eintrag in die Chatleiste erfolgt, wo er getroffen hat, wirft er vorbei, verliert er gar Charm.

EINBAU
======
1. F�hre in der PhPMyAdmin folgenden Befehl unter SQL aus:

ALTER TABLE `accounts` ADD `werfe` INT(10) UNSIGNED NOT NULL DEFAULT '0';



2. �ffne jail.php und finde


		output("Derzeit am Pranger:");
		while($row = db_fetch_assoc($result)) {
			output("`n".$row['name']);
			if ($row['reason']!='') output(" wegen ".$row['reason']);
		}
	}
	output("`n`n");

   F�ge zwischen die 2 KLammern ein:

	addnav("Aktionen");
	addnav("`TPf`ter`Tde`tap`Tfel `3werfen - `^1 Gold","wurf.php?op=pfap");
	addnav("`3Faule `\$To`4ma`\$te `3werfen - `^2Gold","wurf.php?op=tom");
	addnav("`3Faules `&Ei `3werfen - `^3Gold","wurf.php?op=ei");
	addnav("`3Faules `2Ge`@m�`2se `3werfen - `^3 Gold","wurf.php?op=gem");

   Dann sieht es so aus:

		output("Derzeit am Pranger:");
		while($row = db_fetch_assoc($result)) {
			output("`n".$row['name']);
			if ($row['reason']!='') output(" wegen ".$row['reason']);
		}
	addnav("Aktionen");
	addnav("`TPf`ter`Tde`tap`Tfel `3werfen - `^1 Gold","wurf.php?op=pfap");
	addnav("`3Faule `\$To`4ma`\$te `3werfen - `^2Gold","wurf.php?op=tom");
	addnav("`3Faules `&Ei `3werfen - `^3Gold","wurf.php?op=ei");
	addnav("`3Faules `2Ge`@m�`2se `3werfen - `^3 Gold","wurf.php?op=gem");
	}
	output("`n`n");



3. �ffne die newday.php und suche:

		$session['user']['witch'] = 0;

   f�ge dahinter ein:

		$session['user']['werfe']=0;


4. Lade die jail.php, wurf.php und die newday.php hoch und fertig.


Wird nun ein User angeprangert, erscheint das Extra Men�, um den User zu bewerfen, wenn niemand angeprangert ist, ist das Men� auch nicht sichtbar. Ich habe nichts dagegen, wenn jemand noch mehr Gegenst�nde dazu machen will, so habe ich nichts dagegen, aber bitte dann nicht als eigenes Produkt ausgeben, sondern die Copyright nur erg�nzen um 

//erweitert von UVW f�r XYZ

Und nun EUchund Euren Usern viel "Spa�" damit...