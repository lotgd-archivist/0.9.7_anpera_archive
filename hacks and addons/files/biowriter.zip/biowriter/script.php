<?php
// Header
header('Content-type: text/javascript; charset=UTF-8');

$appoencode = mb_convert_encoding("a:60:{i:1;a:2:{s:4:\"code\";s:1:\"1\";s:5:\"color\";s:6:\"0000B0\";}i:2;a:2:{s:4:\"code\";s:1:\"2\";s:5:\"color\";s:6:\"00B000\";}i:3;a:2:{s:4:\"code\";s:1:\"3\";s:5:\"color\";s:6:\"00B0B0\";}i:4;a:2:{s:4:\"code\";s:1:\"4\";s:5:\"color\";s:6:\"B00000\";}i:5;a:2:{s:4:\"code\";s:1:\"5\";s:5:\"color\";s:6:\"B000CC\";}i:6;a:2:{s:4:\"code\";s:1:\"6\";s:5:\"color\";s:6:\"B0B000\";}i:7;a:2:{s:4:\"code\";s:1:\"7\";s:5:\"color\";s:6:\"B0B0B0\";}i:8;a:2:{s:4:\"code\";s:1:\"8\";s:5:\"color\";s:6:\"DDFFBB\";}i:9;a:2:{s:4:\"code\";s:1:\"9\";s:5:\"color\";s:6:\"0070FF\";}s:1:\"!\";a:2:{s:4:\"code\";s:1:\"!\";s:5:\"color\";s:6:\"0000FF\";}s:1:\"@\";a:2:{s:4:\"code\";s:1:\"@\";s:5:\"color\";s:6:\"00FF00\";}s:1:\"#\";a:2:{s:4:\"code\";s:1:\"#\";s:5:\"color\";s:6:\"00FFFF\";}s:1:\"$\";a:2:{s:4:\"code\";s:1:\"$\";s:5:\"color\";s:6:\"FF0000\";}s:1:\"%\";a:2:{s:4:\"code\";s:1:\"%\";s:5:\"color\";s:6:\"FF00FF\";}s:1:\"^\";a:2:{s:4:\"code\";s:1:\"^\";s:5:\"color\";s:6:\"FFFF00\";}s:1:\"&\";a:2:{s:4:\"code\";s:1:\"&\";s:5:\"color\";s:6:\"FFFFFF\";}s:1:\")\";a:2:{s:4:\"code\";s:1:\")\";s:5:\"color\";s:6:\"999999\";}s:1:\"~\";a:2:{s:4:\"code\";s:1:\"~\";s:5:\"color\";s:6:\"222222\";}s:1:\"Q\";a:2:{s:4:\"code\";s:1:\"Q\";s:5:\"color\";s:6:\"FF6600\";}s:1:\"q\";a:2:{s:4:\"code\";s:1:\"q\";s:5:\"color\";s:6:\"FF9900\";}s:1:\"r\";a:2:{s:4:\"code\";s:1:\"r\";s:5:\"color\";s:6:\"575757\";}s:1:\"R\";a:2:{s:4:\"code\";s:1:\"R\";s:5:\"color\";s:6:\"EEBBEE\";}s:1:\"V\";a:2:{s:4:\"code\";s:1:\"V\";s:5:\"color\";s:6:\"9A5BEE\";}s:1:\"v\";a:2:{s:4:\"code\";s:1:\"v\";s:5:\"color\";s:6:\"AABBEE\";}s:1:\"g\";a:2:{s:4:\"code\";s:1:\"g\";s:5:\"color\";s:6:\"aaff99\";}s:1:\"G\";a:2:{s:4:\"code\";s:1:\"G\";s:5:\"color\";s:6:\"3B3B3B\";}s:1:\"T\";a:2:{s:4:\"code\";s:1:\"T\";s:5:\"color\";s:6:\"6b563f\";}s:1:\"t\";a:2:{s:4:\"code\";s:1:\"t\";s:5:\"color\";s:6:\"F8DB83\";}s:1:\"j\";a:2:{s:4:\"code\";s:1:\"j\";s:5:\"color\";s:6:\"38B0DE\";}s:1:\"Z\";a:2:{s:4:\"code\";s:1:\"Z\";s:5:\"color\";s:6:\"006400\";}s:1:\"X\";a:2:{s:4:\"code\";s:1:\"X\";s:5:\"color\";s:6:\"556B2F\";}s:1:\"x\";a:2:{s:4:\"code\";s:1:\"x\";s:5:\"color\";s:6:\"8B864E\";}s:1:\"y\";a:2:{s:4:\"code\";s:1:\"y\";s:5:\"color\";s:6:\"99CC32\";}s:1:\"o\";a:2:{s:4:\"code\";s:1:\"o\";s:5:\"color\";s:6:\"FF2400\";}s:1:\"p\";a:2:{s:4:\"code\";s:1:\"p\";s:5:\"color\";s:6:\"FF7F00\";}s:1:\"K\";a:2:{s:4:\"code\";s:1:\"K\";s:5:\"color\";s:6:\"B87333\";}s:1:\"m\";a:2:{s:4:\"code\";s:1:\"m\";s:5:\"color\";s:6:\"A62A2A\";}s:1:\"k\";a:2:{s:4:\"code\";s:1:\"k\";s:5:\"color\";s:6:\"8E2323\";}s:1:\"L\";a:2:{s:4:\"code\";s:1:\"L\";s:5:\"color\";s:6:\"856363\";}s:1:\"O\";a:2:{s:4:\"code\";s:1:\"O\";s:5:\"color\";s:6:\"8E236B\";}s:1:\"P\";a:2:{s:4:\"code\";s:1:\"P\";s:5:\"color\";s:6:\"9370DB\";}s:1:\"J\";a:2:{s:4:\"code\";s:1:\"J\";s:5:\"color\";s:6:\"CC3299\";}s:1:\"l\";a:2:{s:4:\"code\";s:1:\"l\";s:5:\"color\";s:6:\"DB70DB\";}s:1:\"M\";a:2:{s:4:\"code\";s:1:\"M\";s:5:\"color\";s:6:\"EAADEA\";}s:1:\"A\";a:2:{s:4:\"code\";s:1:\"A\";s:5:\"color\";s:6:\"778899\";}s:1:\"a\";a:2:{s:4:\"code\";s:1:\"a\";s:5:\"color\";s:6:\"8F7D8B\";}s:1:\"*\";a:2:{s:4:\"code\";s:1:\"*\";s:5:\"color\";s:6:\"827D8F\";}s:1:\"?\";a:2:{s:4:\"code\";s:1:\"?\";s:5:\"color\";s:6:\"7D8F85\";}s:1:\"+\";a:2:{s:4:\"code\";s:1:\"+\";s:5:\"color\";s:6:\"8F8C7D\";}s:1:\"Y\";a:2:{s:4:\"code\";s:1:\"Y\";s:5:\"color\";s:6:\"3B3B3B\";}s:1:\"s\";a:2:{s:4:\"code\";s:1:\"s\";s:5:\"color\";s:6:\"575757\";}s:1:\"w\";a:2:{s:4:\"code\";s:1:\"w\";s:5:\"color\";s:6:\"FFD700\";}s:1:\"e\";a:2:{s:4:\"code\";s:1:\"e\";s:5:\"color\";s:6:\"7C7C7C\";}s:1:\"E\";a:2:{s:4:\"code\";s:1:\"E\";s:5:\"color\";s:6:\"FF891E\";}s:1:\"W\";a:2:{s:4:\"code\";s:1:\"W\";s:5:\"color\";s:6:\"DEDE04\";}s:1:\"N\";a:2:{s:4:\"code\";s:1:\"N\";s:5:\"color\";s:6:\"CA7F3C\";}s:1:\"C\";a:2:{s:4:\"code\";s:1:\"C\";s:5:\"color\";s:6:\"D3874F\";}s:1:\"I\";a:2:{s:4:\"code\";s:1:\"I\";s:5:\"color\";s:6:\"975E2B\";}s:1:\"(\";a:2:{s:4:\"code\";s:1:\"(\";s:5:\"color\";s:6:\"1E97C8\";}s:1:\"§\";a:2:{s:4:\"code\";s:1:\"§\";s:5:\"color\";s:6:\"DB9D73\";}}", 'ISO-8859-1', 'UTF-8');

$stringhash = sha1($appoencode);

if(file_exists("$stringhash.tmp.inc")) {
	$includescript = file_get_contents("$stringhash.tmp.inc");
}
else {
	$appoencode = unserialize(StripSlashes($appoencode));

	$includescript = '';
	reset($appoencode);
	while(list($key,$val) = each($appoencode)) {
		$includescript .= '
				case "'.$key.'":
					if(openspan == true) {
						output += "</span>";
					}
					output += "<span style=\"color: #'.$val['color'].';\">";
					break;
					';
			
	}
	$includescript = mb_convert_encoding($includescript, 'UTF-8', 'ISO-8859-1');
	$fh = fopen("$stringhash.tmp.inc", "w");
	fwrite($fh, $includescript);
	fclose($fh);
}


?>
function writeBio(textarea) {
	var Fundstelle = -1;
	var tag = '';
	var append = '';
	var output = '';
	var openspan = false;
	var center = false;
	var openbold = false;
	var openitalic = false;
	data = textarea.value;
	
	while ((Fundstelle = data.search(/`/)) != -1) {
		tag = data.substr(Fundstelle+1, 1);
		append = data.substr(0,Fundstelle);
		output = output+ append;
		if (data.length >= Fundstelle+2) data = data.substring(Fundstelle+2, data.length);
		else data = '';
		
		switch (tag) {
			case "n":
				output += "<br />";
				break;
				
			case "c":
				if(center == true) {
					output += "</center>";
					center = false;
				}
				else {
					output += "<center>";
					center = true;
				}
				break;
				
			case 'b':
				if(openbold == true) {
					output += "</b>";
					openbold = false;
				}
				else {
					output += "<b>";
					openbold = true;
				}
				break;
				
			case 'i':
				if(openitalic == true) {
					output += "</i>";
					openitalic = false;
				}
				else {
					output += "<i>";
					openitalic = true;
				}
				break;
				
			case "`":
				output += "`";
				break; 
				
			case "0":
				if(openspan == true) {
					output += "</span>";
					openspan = false;
				}
				break;
			<?php echo $includescript ?>
				
			default:
				output = output+"`"+tag;
				break;
		}	
	}
	
	output += data
	if (openspan) output += '</span>';		
	
	bio = document.getElementById("bio");
	bio.innerHTML = output;
}