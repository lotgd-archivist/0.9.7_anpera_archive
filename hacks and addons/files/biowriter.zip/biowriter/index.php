<?php
// Header
header('Content-type: text/html; charset=UTF-8');

// Definitionen
define('JAVASCRIPT_USEDYNAMICSCRIPT', false);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<title>Bioschreibmaschine für LoGD</title>
  
	<link rel="stylesheet" href="style.css" type="text/css" />
	
	<?php if(JAVASCRIPT_USEDYNAMICSCRIPT === false) {
		echo '<script type="text/javascript" src="script.js" charset="UTF-8"></script>';
	}
	else {
		echo '<script type="text/javascript" src="script.php" charset="UTF-8"></script>';
	} ?>
</head>

<body>
	<div id="nonFooter">
		<div id="bio">
			
		</div>
	</div>
	
	<div id="footer">
		<div id="textarea">
			<textarea id="textfield" rows="5" cols="5" onkeyup="writeBio(this);"></textarea>
		</div>
	</div>
</body>
</html>