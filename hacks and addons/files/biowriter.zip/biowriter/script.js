function writeBio(textarea) {
	var Fundstelle = -1;
	var tag = '';
	var append = '';
	var output = '';
	var openspan = false;
	var center = false;
	var openbold = false;
	var openitalic = false;
	data = textarea.value;
	
	while ((Fundstelle = data.search(/`/)) != -1) {
		tag = data.substr(Fundstelle+1, 1);
		append = data.substr(0,Fundstelle);
		output = output+ append;
		if (data.length >= Fundstelle+2) data = data.substring(Fundstelle+2, data.length);
		else data = '';
		
		switch (tag) {
			case "n":
				output += "<br />";
				break;
				
			case "c":
				if(center == true) {
					output += "</center>";
					center = false;
				}
				else {
					output += "<center>";
					center = true;
				}
				break;
				
			case 'b':
				if(openbold == true) {
					output += "</b>";
					openbold = false;
				}
				else {
					output += "<b>";
					openbold = true;
				}
				break;
				
			case 'i':
				if(openitalic == true) {
					output += "</i>";
					openitalic = false;
				}
				else {
					output += "<i>";
					openitalic = true;
				}
				break;
				
			case "`":
				output += "`";
				break; 
				
			case "0":
				if(openspan == true) {
					output += "</span>";
					openspan = false;
				}
				break;
				
			case "1":
				if(openspan == true) {
					output += "</span>";
				}
				output += "<span class='colDkBlue'>";
				break;
				
			case "2":
				if(openspan == true) {
					output += "</span>";
				}
				output += "<span class='colDkGreen'>";
				break;
				
			case "3":
				if(openspan == true) {
					output += "</span>";
				}
				output += "<span class='colDkCyan'>";
				break;
				
			case "4":
				if(openspan == true) {
					output += "</span>";
				}
				output += "<span class='colDkRed'>";
				break;
				
			case "5":
				if(openspan == true) {
					output += "</span>";
				}
				output += "<span class='colDkMagenta'>";
				break;
				
			case "6":
				if(openspan == true) {
					output += "</span>";
				}
				output += "<span class='colDkYellow'>";
				break;
				
			case "7":
				if(openspan == true) {
					output += "</span>";
				}
				output += "<span class='colDkWhite'>";
				break;
				
			case "8":
				if(openspan == true) {
					output += "</span>";
				}
				output += "<span class='colLime'>";
				break;
				
			case "9":
				if(openspan == true) {
					output += "</span>";
				}
				output += "<span class='colBlue'>";
				break;
				
			case "!":
				if(openspan == true) {
					output += "</span>";
				}
				output += "<span class='colLtBlue'>";
				break;
				
			case "@":
				if(openspan == true) {
					output += "</span>";
				}
				output += "<span class='colLtGreen'>";
				break;
				
			case "#":
				if(openspan == true) {
					output += "</span>";
				}
				output += "<span class='colLtCyan'>";
				break;
				
			case "$":
				if(openspan == true) {
					output += "</span>";
				}
				output += "<span class='colLtRed'>";
				break;
				
			case "%":
				if(openspan == true) {
					output += "</span>";
				}
				output += "<span class='colLtMagenta'>";
				break;
				
			case "^":
				if(openspan == true) {
					output += "</span>";
				}
				output += "<span class='colLtYellow'>";
				break;
				
			case "&":
				if(openspan == true) {
					output += "</span>";
				}
				output += "<span class='colLtWhite'>";
				break;
				
			case "~":
				if(openspan == true) {
					output += "</span>";
				}
				output += "<span class='colBlack'>";
				break;
				
			case "Q":
				if(openspan == true) {
					output += "</span>";
				}
				output += "<span class='colDkOrange'>";
				break;
				
			case "q":
				if(openspan == true) {
					output += "</span>";
				}
				output += "<span class='colOrange'>";
				break;
				
			case "r":
			case "R":
				if(openspan == true) {
					output += "</span>";
				}
				output += "<span class='colRose'>";
				break;
				
			case "V":
				if(openspan == true) {
					output += "</span>";
				}
				output += "<span class='colBlueViolet'>";
				break;
				
			case "v":
				if(openspan == true) {
					output += "</span>";
				}
				output += "<span class='coliceviolet'>";
				break;
				
			case "G":
			case "g":
				if(openspan == true) {
					output += "</span>";
				}
				output += "<span class='colXLtGreen'>";
				break;
				
			case "T":
				if(openspan == true) {
					output += "</span>";
				}
				output += "<span class='colDkBrown'>";
				break;
				
			case "t":
				if(openspan == true) {
					output += "</span>";
				}
				output += "<span class='colLtBrown'>";
				break;
				
			default:
				output = output+"`"+tag;
				break;
		}	
	}
	
	output += data
	if (openspan) output += '</span>';		
	
	bio = document.getElementById("bio");
	bio.innerHTML = output;
}