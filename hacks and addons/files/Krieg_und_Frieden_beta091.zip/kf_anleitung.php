<?php

// Krieg und Frieden
// Version 0.9.1

require_once "common.php";

page_header("~~~~~~ Krieg und Frieden ~~~~~~~");
output("`c`b`^~~~~~~ Krieg und Frieden ~~~~~~~`^`c`b`n");
output("`c`b`^Anleitung:`^`c`b`n");

output("
	`bKoF ist ein Handelsspiel.`b`n`n
	`b`^Die Idee:`b`n`n
	`&Man braucht Land und kauft Geb�ude und erh�lt dadurch G�ter.`n
	Die G�ter werden entweder von Deinen Einwohnern gebraucht`n
	oder eben f�r andere Geb�ude, um wieder neue bessere G�ter `n
	herzustellen.`n
	Man kann Milit�reinheiten anheuern und Kriege gegen andere`n
	L�nder f�hren. Man setzt Steuern, Zoll und Justiz ein und`n
	erh�lt dadurch Taler bzw. steigert die Zufriedenheit beim Volk.`n
	(Hohe Steuern und Z�lle verringern nat�rlich eher die Zufriedenheit!)`n`n
	Wer Kaiser wird hat gewonnen!"
);

output("
	`n`n`b`^Tipps + Tricks:`n`n
	`&1. Je besser das Wetter, desto mehr Produktion und geringer die Kosten.`n
	2. Je besser das Wetter, desto weniger wird vom Volk ben�tigt.`n
	3. Je besser das Wetter, desto niedriger sind die Preise.`n
	4. Die Preise sind dynamisch. Je mehr im Lager ist, desto geringer sind die Preise.`n
	5. Ratsam ist es, mehrmals in kleinen Mengen einzukafen bzw. zu verkaufen. Preisver�nderungen beobachten.`n
	6. Geb�udekosten von Goldminen, Edelsteinminen sind hoch. Wenn sie noch nicht ben�tigt werden, eher mal eine verkaufen`n
	7. Bed�rfnisse des Volkes beobachten. Die Produktion sollte bei bew�lktem Wetter immer noch alle Bed�rfnisse des Volkes decken!`n
	8. Durch gewonnene Kriege erh�lt man Taler, Land und Einwohner."
);
	

addnav("Sonstiges");
addnav("Zur�ck","kf_mainmenu.php");
if ($session[user][superuser]>=2){
	addnav("Administration");
	addnav("Einstellungen","kf_admin.php");
}

page_footer();

?>


