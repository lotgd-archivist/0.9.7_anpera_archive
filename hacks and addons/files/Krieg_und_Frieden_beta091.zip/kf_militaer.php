<?php

// Krieg und Frieden
// Version 0.9.1

require_once "common.php";
require_once "kf_functions.php";

page_header("~~~~~~ Krieg und Frieden ~~~~~~~");

//Hole Settings
$armee=unserialize(kf_get_setting('armee'));
$armee_total=count($armee);
$x=unserialize(kf_get_setting('x'));
$y=unserialize(kf_get_setting('y'));
$titel=unserialize(kf_get_setting('titel'));
$manoever=kf_get_setting('manoever_kosten');
$laender=unserialize(kf_get_setting('laender'));
$laender_total=count($laender);

	
if ($HTTP_GET_VARS[op]==""){
	output("`c`b`^Milit�r`^`b`n`c");
	output("`n`c`b`6Hier kannst Du nun Deine Armeen verwalten,`nMan�ver abhalten oder in den Krieg ziehen.`b`6`c");
	output("`n`&Du hast derzeit:");
	output("`nGold: ".$session[user][kf_taler]." Taler");
	if($session[user][kf_manoever]>0){
		output("`nDeine Truppen haben durch ".$session[user][kf_manoever]." Man�ver mehr an Erfahrung f�r einen Krieg gesammelt!");
	}
	output("`n`nWas m�chtest Du tun?");
	addnav("Aktionen");
	addnav("Armee-Einheiten anwerben/aufl�sen","kf_militaer.php?op=buy");
	addnav("Man�ver (".$manoever."T)","kf_militaer.php?op=manoever");
	for($a=0;$a<$armee_total;$a++){
		$anzahl=$anzahl+$session[user][$armee[$a][5]];
	}
	if(!$session[user][kf_krieg]){
		if($anzahl>10){
			addnav("Krieg","kf_militaer.php?op=fight1");
		}else{
			addnav("Zuwenig Einheiten! (min.10)","");
		}
	}else{
		addnav("Krieg heute schon gef�hrt!","");
	}
	addnav("Sonstiges");
	addnav("Zur�ck","kf_mainmenu.php");
	if ($session[user][superuser]>=2){
		addnav("Administration");
		addnav("Einstellungen","kf_admin.php");
	}
}else if ($_GET['op'] == "manoever"){
	output("`c`b`^Milit�r: Man�ver`^`b`n`c");
	output("`n`&Du m�chtest gerne ein Man�ver mit Deinen Truppen durchf�hren.");
	if($session[user][kf_taler]-$manoever>=0){
		for($a=0;$a<$armee_total;$a++){
			$ges=$ges+$session[user][$armee[$a][5]];
 		}
 		if($ges<10){
 			output("`nLeider fehlen Dir gen�gend Truppeneinheiten (min.10 Einheiten), um ein ordentliches Man�ver abzuhalten!!!");
 			$no=1;
 	  }
 	}else{
 		output("`nLeider fehlt Dir das gen�gende Kleindgeld, um ein ordentliches Man�ver abzuhalten!!!");
 		$no=1;
 	}
 	if(!$no){
 		output("`nDeine Truppen halten ein Man�ver ab und erhalten dadurch mehr Erfahrung!");
 		$session[user][kf_taler]=$session[user][kf_taler]-$manoever;
 		$session[user][kf_manoever]++;
 	}
 	addnav("Sonstiges");
	addnav("Zur�ck","kf_militaer.php");
}else if ($_GET['op'] == "buy" || $_GET['op']=="werben" || $_GET['op']=="aufloesen"){
	output("`c`b`6Milit�r: Einheit anwerben oder aufl�sen`b`n`c");
	if ($_GET['op'] == "buy"){
		output("`nHier kannst Du nun Milit�reinheiten anwerben oder aufl�sen.");
	}else if($_GET['op']=="werben"){
		output("`n`c`b`6Aktion: Milit�r-Einheit(en) anwerben`b`n`c");
		$anzahl=abs($_POST['amount']);
		$art=$_GET['id'];
		$kaufwert=round($armee[$art][1]*$y[$session[user][kf_tagrelation]]);
		$wert=$anzahl*$kaufwert;
		if($session[user][kf_taler]>=$wert){
			if($anzahl*round($armee[$art][2]*$y[$session[user][kf_tagrelation]])<=$session[user][kf_holz]){
				if($anzahl*round($armee[$art][3]*$y[$session[user][kf_tagrelation]])<=$session[user][kf_stahl]){
					if($anzahl*round($armee[$art][4]*$y[$session[user][kf_tagrelation]])<=$session[user][kf_waffen]){
						output("`n`b`c`@Der Deal ist perfekt.`nDu wirbst ".$anzahl." ".$armee[$art][0]." Einheiten f�r ".$wert." Taler an!`b`c");
						$session[user][$armee[$art][5]]=$session[user][$armee[$art][5]]+$anzahl;
						$session[user][kf_taler]=$session[user][kf_taler]-$wert;
						$session[user][kf_holz]=$session[user][kf_holz]-$anzahl*$armee[$art][2]*$y[$session[user][kf_tagrelation]];
						$session[user][kf_stahl]=$session[user][kf_stahl]-$anzahl*$armee[$art][3]*$y[$session[user][kf_tagrelation]];
						$session[user][kf_waffen]=$session[user][kf_waffen]-$anzahl*$armee[$art][4]*$y[$session[user][kf_tagrelation]];
					}else{
						output("`n`$`c`bLeider hast Du zu wenig Waffen, um ".$anzahl." ".$armee[$art][0]." Einheiten zu kaufen!`c`b");
					}
				}else{
					output("`n`$`c`bLeider hast Du zu wenig Stahl, um ".$anzahl." ".$armee[$art][0]." Einheiten zu kaufen!`c`b");
				}
			}else{
				output("`n`$`c`bLeider hast Du zu wenig Holz, um ".$anzahl." ".$armee[$art][0]." Einheiten zu kaufen!`c`b");
			}
		}else{
			output("`n`$`c`bDein General l�chelt Dich m�de an.`n`#Mein ".$titel[$session[user][kf_lvl]].", leider fehlt uns das Geld, um diese Anzahl an Einheiten zu kaufen!!`c`b");
		}
		$_GET['op']="";
	}else if($_GET['op']=="aufloesen"){
		output("`n`c`b`6Aktion: Milit�r-Einheit(en) aufl�sen`b`n`c");
		$anzahl=abs($_POST['amount']);
		$art=$_GET['id'];		
		if($anzahl<=$session[user][$armee[$art][5]]){
			output("`n`c`b`@So soll es geschehen.`n".$anzahl." ".$armee[$art][0]." Einheiten werden aufgel�st!`c`b");
			$session[user][$armee[$art][5]]=$session[user][$armee[$art][5]]-$anzahl;
		}else{
			output("`n`c`$`bDein General l�chelt Dich m�de an.`n`#Mein ".$titel[$session[user][kf_lvl]].", leider haben wir gar nicht soviele ".$armee[$art][0]." Einheiten!`c`b");
		}
		$_GET['op']="";
	}
	output("`n`n`&Du hast derzeit ein Verm�gen von ".$session[user][kf_taler]." Taler, ".$session[user][kf_holz]."t Holz, ".$session[user][kf_stahl]."t Stahl und ".$session[user][kf_waffen]."t Waffen");
	output("`nFolgende Einheiten stehen zur Auswahl:`n`n");
	output("<table border='0' cellpadding='8' cellspacing='1' bgcolor='#999999'>",true);
	output("<tr class='trhead'>",true);
	output("<td><b>Art</b></td><td><b>Preis</b></td><td><b>Holz</b></td><td><b>Stahl</b></td><td><b>Waffen</b></td><td><b>Du besitzt</b></td><td><b>Einheiten werben</b></td><td><b>Einheiten aufl�sen</b></td>",true);

	for($a=0;$a<$armee_total;$a++){
		$kaufwert=round($armee[$a][1]*$y[$session[user][kf_tagrelation]]);
		output("<tr class='".($a%2?"trlight":"trdark")."'>",true);
		output("<td>".$armee[$a][0]."</td><td>".$kaufwert."</td><td>".round($armee[$a][2]*$y[$session[user][kf_tagrelation]])."</td><td>".round($armee[$a][3]*$y[$session[user][kf_tagrelation]])."</td><td>".round($armee[$a][4]*$y[$session[user][kf_tagrelation]])."</td><td>".$session[user][$armee[$a][5]]."</td>",true);		
		output("<td>",true);
		output("<form action='kf_militaer.php?op=werben&id=$a' method='POST'><input name='amount' id='amount' size='2'>"
		,true);
		output("<input type='submit' class='button' value='OK'></form>",true);
		output("</td>",true);
		addnav("","kf_militaer.php?op=werben&id=$a");
		output("<td>",true);
		output("<form action='kf_militaer.php?op=aufloesen&id=$a' method='POST'><input name='amount' id='amount' size='2' value='1'>"
					,true);
		output("<input type='submit' class='button' value='OK'></form></td>",true);
		output("</td>",true);
		addnav("","kf_militaer.php?op=aufloesen&id=$a");
		output("</tr>",true);
	}
	output("</tr>",true);
	output("</table>",true);
	addnav("Sonstiges");
	addnav("Zur�ck","kf_militaer.php");
}else if ($_GET['op'] == "fight1"){
	output("`c`b`^Krieg`b`6`c");
	output("`nGegen welches Land m�chtest Du in den Krieg ziehen?");
	output("`n`nFolgende L�nder stehen zur Auswahl:`n`n");
	addnav("Krieg gegen:");
	for($a=0;$a<$laender_total;$a++){
		output("- ".$laender[$a]."`n");
		addnav($laender[$a],"kf_militaer.php?op=fight2&id=$a");
	}
	output("`n`n`b`c`$ Deine Berater warnen Dich:`n`# Einmal eine Kriegserkl�rung ausgesprochen, gibt es kein Zur�ck mehr!`b`c");
	addnav("Sonstiges");
	addnav("Zur�ck","kf_militaer.php");
}else if ($_GET['op'] == "fight2"){
	$art=$_GET['id'];
	$land = $laender[$art];
	output("`c`b`6Krieg gegen ".$land."`b`6`c");
	output("`n`nDu hast Dich entschlossen, gegen ".$land." Krieg zu f�hren!`n");
  output("Deine Gener�le ziehen ihre Truppen zusammen und stellen sich dem Gegner.`n`n");
  
  //Der Gegner:
  $e_level= e_rand($session[user][kf_lvl]-1,$session[user][kf_lvl]);
  $badguy = array(        
				"land"=>"`@".$land."`0"
			,"level"=>$e_level
	);
  for($i=0;$i<$armee_total;$i++){
  		if($session[user][kf_lvl]>=7){
  			$e_min = e_rand(0,$session[user][$armee[$i][5]]);
  			$e_max = e_rand($e_min,$session[user][$armee[$i][5]]+$e_level);
  			$anzahl_einheit=e_rand($e_min,$e_max);
  		}else{
  			//Scouts
  			if(i==1){
  				$anzahl_einheit=e_rand(3,$session[user][$armee[$i][5]]+3);
  			//Miliz
  			}else if(i==2){
  				$anzahl_einheit=e_rand(2,$session[user][$armee[$i][5]]+1);
  			}else{
  				$anzahl_einheit=e_rand(0,$session[user][$armee[$i][5]]);
  			}
  		}  		
  		array_push($badguy,$anzahl_einheit);
  };
  $session['user']['kf_gegner']=createstring($badguy);
	$test=createarray($session[user][kf_gegner]);
  output("`bDer Gegner ".$titel[$test['level']]." von ".$test[land]." stellt seine Armee Dir gegen�ber auf!`n`b");
	addnav("Aktion");
	addnav("K�mpfen","kf_militaer.php?op=fight3");
	addnav("Sonstiges");
	addnav("Wei�e Flagge","kf_militaer.php?op=fight4&id=100");
}else if ($_GET['op'] == "fight3"){
	$badguy=createarray($session[user][kf_gegner]);
	output("`c`b`6Krieg gegen ".$badguy[land]."`b`6`c");
	output("`^`n`nDein Schlachtzug steht an! Mit welchen Milit�reinheiten wirst Du angreifen?");
	output("`n`n`bDein Gegner hat noch folgende Einheiten:`b`n");
	addnav("Angreifen mit");
	for($a=0;$a<$armee_total;$a++){
		if($badguy[$a]>0){
			output("- ".$armee[$a][0].": ".$badguy[$a]);
		}
		if($session[user][$armee[$a][5]]>0){
			addnav("".$session[user][$armee[$a][5]]." ".$armee[$a][0]."","kf_militaer.php?op=fight4&id=$a");
		}else{
			$none++;
		}
	}
	if($none==$armee_total){
		addnav("Keine Armee mehr vorhanden :(","");
	}
	addnav("Sonstiges");
	addnav("Wei�e Flagge","kf_militaer.php?op=fight4&id=100");
}else if ($_GET['op'] == "fight4"){
	$einheit=$_GET[id];
	$gegner_einheit=$einheit;
	$badguy=createarray($session[user][kf_gegner]);
	output("`c`b`6Krieg gegen ".$badguy[land]."`b`6`c");
	if($einheit==100){
		output("`n`c`b`^Gedem�tigt vom Gegner, gekr�nkt in der Eitelkeit, musst Du feststellen,`ndass Du dem Gegner nicht ebenb�rtig bist.`nDeine Soldaten strecken auf Deinen Befehl hin die Waffen und ergeben sich!`n`b`c");
		addnav("Aktion");
		addnav("Friedensverhandlung","kf_militaer.php?op=lost");
	}else{
		output("`n`cDeine ".$armee[$einheit][0]." Einheiten greifen den Gegner an!`c");
		$damage=$session[user][$armee[$einheit][5]]*e_rand(1,$armee[$einheit][6])+$session[user][kf_manoever];
		//output("`n`$ TEST: Du verursachst eine Damage in H�he von: ".$damage);
		//wenn der Gegner diese Einheit nicht hat, dann muss er mit was anderem kommen, wenn er hat...sonst Sieg!
		if($badguy[$gegner_einheit]<=0){
			for($a=0;$a<$armee_total;$a++){
				if($a==$armee_total){
					$win=1;
					break;
				}
				if($badguy[$a]>0){
					$gegner_einheit=$a;
					break;
				}
			}
		}
		if(!$win){
			$gegner_damage=$badguy[$gegner_einheit]*e_rand(1,$armee[$gegner_einheit][6]);
			//output("`n`$ TEST: Der Gegner verursachst eine Damage in H�he von: ".$gegner_damage);
			output("`n`n`bNach Deinem Angriff und Gegenangriff:`b`n");
			if($damage-$gegner_damage>0){
				$lost=round($damage/$gegner_damage);
				$u_lost=round($gegner_damage/$damage);
				if($badguy[$gegner_einheit]-$lost<0){
					$lost=$badguy[$gegner_einheit];
					$badguy[$gegner_einheit]=0;
				}else{
					$badguy[$gegner_einheit]=$badguy[$gegner_einheit]-$lost;
				}
				$session['user']['kf_gegner']=createstring($badguy);
				if($session[user][$armee[$einheit][5]]-$u_lost<0){
					$u_lost=$session[user][$armee[$einheit][5]];
					$session[user][$armee[$einheit][5]]=0;
				}else{
					$session[user][$armee[$einheit][5]]=$session[user][$armee[$einheit][5]]-$u_lost;
				}
				if($lost>=5){
					output("`n`@Deine Gener�le vollf�hren eine strategische Meisterleistung!!`n");
				}
				output("`n`&Dein Gegner hat ".$lost." ".$armee[$gegner_einheit][0]." Einheiten verloren.");
				output("`nDu hast dabei ".$u_lost." ".$armee[$einheit][0]." Einheit(en) verloren.");
			}else{
				$lost=round($gegner_damage/$damage);
				$e_lost=round($damage/$gegner_damage);
				if($session[user][$armee[$einheit][5]]-$lost<0){
					$lost=$session[user][$armee[$einheit][5]];
					$session[user][$armee[$einheit][5]]=0;
				}else{
					$session[user][$armee[$einheit][5]]=$session[user][$armee[$einheit][5]]-$lost;
				}
				if($badguy[$gegner_einheit]-$e_lost<0){
					$e_lost=$badguy[$gegner_einheit];
					$badguy[$gegner_einheit]=0;
				}else{
					$badguy[$gegner_einheit]=$badguy[$gegner_einheit]-$e_lost;
				}
				$session['user']['kf_gegner']=createstring($badguy);
				if($lost>=5){
					output("`n`$Die gegnerischen Einheiten sind Deinen haushoch �berlegen!!`n");
				}
				output("`n`&Du hast ".$lost." ".$armee[$einheit][0]." Einheiten verloren.");
				output("`nDein Gegner hat bei dem Angriff ".$e_lost." ".$armee[$gegner_einheit][0]." Einheit(en) verloren.");
			}
			//Nochmal den Sieg �berpr�fen
			$win=0;
			for($a=0;$a<$armee_total;$a++){
				if($badguy[$a]>0){
					$win=0;
					break;
				}else{
					$win=1;
				}
			}
			if(!$win){
				addnav("Aktion");
				addnav("N�chster Zug","kf_militaer.php?op=fight3");
				addnav("Sonstiges");
				addnav("Wei�e Flagge","kf_militaer.php?op=fight4&id=100");
			}else{
				output("`n`n`c`b`6Sieg gegen ".$badguy[land]."`b`6`c");
				output("`n`c`^Alle Einheiten des Gegners wurden besiegt!`nDer Sieg ist Dein!`nDeine Truppen umjubeln Dich!`nDie schmerzlichen Verluste sind (fast) vergessen!`c");
				addnav("Aktion");
				addnav("Friedensverhandlung","kf_militaer.php?op=win");
			}
		}else{
			output("`n`n`c`b`6Sieg gegen ".$badguy[land]."`b`6`c");
			output("`n`c`^Alle Einheiten des Gegners wurden besiegt!`nDer Sieg ist Dein!`nDeine Truppen umjubeln Dich!`nDie schmerzlichen Verluste sind (fast) vergessen!`c");
			addnav("Aktion");
			addnav("Friedensverhandlung","kf_militaer.php?op=win");
		}
	}
}else if ($_GET['op'] == "lost" || $_GET['op'] == "win"){
	

	//Hole Settings
	$min_land_gewinn=kf_get_setting('min_land_gewinn');
	$max_land_gewinn=kf_get_setting('max_land_gewinn');
	$min_taler_gewinn=kf_get_setting('min_taler_gewinn');
	$max_taler_gewinn=kf_get_setting('max_taler_gewinn');
	$min_einwohner_gewinn=kf_get_setting('min_einwohner_gewinn');
	$max_einwohner_gewinn=kf_get_setting('max_einwohner_gewinn');
	
	//Man�ver Erfahrung ist weg
	$session[user][kf_manoever]=0;
	
	$session[user][kf_krieg]=1;
	$badguy=createarray($session[user][kf_gegner]);
	
	//Verlust-Faktor ermitteln. Je fr�her man abgebrochen hat, desto glimpflicher wird es
	for($a=0;$a<$armee_total;$a++){
		$rest_armee=$rest_armee+$session[user][$armee[$a][5]];
	}
	if(!$rest_armee){
		$rest_armee=1;
	}
	
	if($_GET['op'] == "lost"){
		output("`c`b`6Niederlage gegen ".$badguy[land]."`b`6`c");
		addnews("`^`cKrieg und Frieden:`n`$ Niederlage gegen ".$badguy[land]."`nDa hat sich wohl `0".$session[user][name]."`@ etwas zuviel vorgenommen!`c");
		output("`n`nAm Friedenstisch platz genommen, l�chelt Dich ".$titel[$badguy[level]]." von ".$badguy[land]." s�ffisant an:`n`#Meine Forderungen sehen wie folgt aus:`n");
		$min_land_gewinn=$min_land_gewinn/$rest_armee;
		$max_land_gewinn=$max_land_gewinn/$rest_armee;
		$min_taler_gewinn=$min_taler_gewinn/$rest_armee;
		$max_taler_gewinn=$max_taler_gewinn/$rest_armee;
		$min_einwohner_gewinn=$min_einwohner_gewinn/$rest_armee;
		$max_einwohner_gewinn=$max_einwohner_gewinn/$rest_armee;
	}else{
		output("`c`b`6Sieg gegen ".$badguy[land]."`b`6`c");
		addnews("`^`cKrieg und Frieden:`n`$ Sieg gegen ".$badguy[land]."`nDa hat wohl `0".$session[user][name]."`@ milit�rische Qualit�ten gezeigt!`c");
		output("`n`nAm Friedenstisch platz genommen, l�chelst Du den ".$titel[$badguy[level]]." von ".$badguy[land]." s�ffisant an.`nDeine Eroberung sieht wie folgt aus:`n");
	}
	
	//Gewinn ermitteln
	$land=e_rand($min_land_gewinn,$max_land_gewinn);
	$taler=e_rand($min_taler_gewinn,$max_taler_gewinn);
	$einwohner=e_rand($min_einwohner_gewinn,$max_einwohner_gewinn);
	
	//Bei Niederlage negative Werte vermeiden!
	if($_GET['op'] == "lost"){
		if($session[user][kf_land]<$session[user][kf_land]-$land){
				$taler=e_rand(0,$session[user][kf_land]);
		}
		if($session[user][kf_einwohner]<$session[user][kf_einwohner]-$einwohner){
				$einwohner=e_rand(0,$session[user][kf_einwohner]);
		}
		if($session[user][kf_taler]<$session[user][kf_taler]-$taler){
				$taler=e_rand(0,$session[user][kf_taler]);
		}
	}
	
	output("`n`b`& ".$land." ha Land, ".$taler." Taler und ".$einwohner." Einwohner`b");
	
	if($_GET['op'] == "lost"){
		$session[user][kf_land]=$session[user][kf_land]-$land;
		$session[user][kf_taler]=$session[user][kf_taler]-$taler;
		$session[user][kf_einwohner]=$session[user][kf_einwohner]-$einwohner;
		output("`n`nDen Weinkrampf unterdr�ckend, unterschreibst Du den Friedensvertrag mit seinen Forderungen!");
	}else{
		$session[user][kf_land]=$session[user][kf_land]+$land;
		$session[user][kf_taler]=$session[user][kf_taler]+$taler;
		$session[user][kf_einwohner]=$session[user][kf_einwohner]+$einwohner;
		output("`n`nDen Weinkrampf unterdr�ckend, unterschreibt Dein Gegner den Friedensvertrag mit Deinen Forderungen!");
	}
	$session[user][kf_gegner]="";
	addnav("Aktion");
	addnav("Zur�ck","kf_mainmenu.php");
}

page_footer();

?>