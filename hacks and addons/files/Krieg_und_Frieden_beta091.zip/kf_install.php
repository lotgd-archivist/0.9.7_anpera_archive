<?php

// Krieg und Frieden
// Version 0.9.1

//ES HANDELT SICH HIER UM DIE GRUNDWERTE...ALLES ABH�NGIG VOM WETTER :)
//Dient nur zur Installation der Grundwerte in der Tabelle kf_settings.

$x=array(0.5,0.7,1,1.2,1.5);									//DIE RELATION
$y=array(1.5,1.2,1,0.7,0.5);									//DIE ANTI-RELATION ;)
$wetter_string= array("regnerischer","bew�lkter","normaler","heiterer","sonniger");

//KAPAZIT�TEN
$lagerhalle_kap			=150;					//Grundwert, Kapazit�t einer Lagerhalle f�r G�ter und Korn
																	//Es wird in der Reihenfolge eingelagert, wie die Grund-
																	//bed�rfnisse des Volkes sind, aber bereits eingelagerte
																	//Sachen werden nicht gel�scht!!! Au�er Korn wird alles in
																	//die Lagerhalle geliefert.

$punkte_faktor = 10;							//Hier k�nnte man die Schwierigkeit noch mal zus�tzlich
																	//justieren! Punkte= Einwohner/punkte_faktor,
																	//Anzahl Geb�ude*(Preis/punkte_faktor) etc.
																	//Zufriedenheit

$land_grundpreis=3;								//pro Hektar;

$kosten_faktor=100;								//Alle Kosten sind Anschaffungspreis/kosten_faktor;

$preis_faktor=10;									//Preisentwicklung entsch�rfen, wenn zu wenig im Lager und der Bedarf hoch ist. 

$laender= array("Th�ringen","Hessen","W�rtenberg","Berlin","Sachsen","Bayern","Niedersachsen","Westfalen","Preu�en","Baden-Baden","Holstein");
										
//TITEL
$punkte_titel=array(0,0,1001,3001,6001,9001,12001,16001,20001,26001,32001,40000);

$titel=array("","Freiherr","Gro�herr","Baron","Landgraf","Graf","Herzog","F�rst","Kurf�rst","K�nig","Kaiser");

//Geb�ude bauen (was das Volk ben�tigt ist auf 1000 Einwohner bezogen)
//art = 	array(Art(0)			,Gold(1),Holz(2),Stein(3)	,Land(4),DB-Feld(5)					,Level(6)	,Liefert(7)	,Volk ben�tigt(8), Gegenstand(9)																		,DB-Gegenstand(10)		,VK-wert(11) 	,Prod(12) ,von(13) 	,Menge(14) 	,von(15) 	,Menge(16)
$building = array(
	array("Muehle"						,500		,0			,0				,1000		,"kf_muehle"				,1				,10					,12							,"t Korn"																						,"kf_korn"						,20					 	,0				,0				,0					,0				,0),
	array("Holzfaeller"				,400		,0			,0				,500		,"kf_holzfaeller"		,1				,5					,2							,"t Holz"																						,"kf_holz"						,30						,0				,0				,0					,0				,0),
	array("Jaeger"						,200		,3			,0				,500		,"kf_jaeger"				,2				,2					,1							,"t Wildfleisch"																		,"kf_wildfleisch"			,50						,0				,0				,0					,0				,0),
	array("Steinbruch"				,1500		,20			,0				,25			,"kf_steinbruch"		,2				,5					,1							,"t Stein"																					,"kf_stein"						,35						,0				,0				,0					,0				,0),
	array("Schweinefarm"			,1300		,5			,5				,50			,"kf_schweinefarm"	,2				,5					,3							,"t Schweinefleisch"																,"kf_schweinefleisch"	,30						,0				,0				,0					,0				,0),
	array("Kornbrennerei"			,1800		,35			,5				,20			,"kf_brennerei"			,3				,5					,3							,"t Alkohol"																				,"kf_alkohol"					,40						,1				,1				,10					,0				,0),
	array("Schaffarm"					,1000		,3			,3				,150		,"kf_schaffarm"			,3				,5					,4							,"t Wolle"																					,"kf_wolle"						,55						,0				,0				,0					,0				,0),
	array("Salzmine"					,5000		,27			,5				,10			,"kf_salzmine"			,3				,5					,3							,"t Salz"																						,"kf_salz"						,80						,0				,0				,0					,0				,0),
	array("Weinberg"					,2500		,24			,7				,500		,"kf_weinberg"			,4				,5					,3							,"t Wein"																						,"kf_wein"						,110					,0				,0				,0					,0				,0),
	array("Tuchfabrik"				,3000		,15			,8				,5			,"kf_tuchfabrik"		,4				,4					,2							,"t Tuch"																						,"kf_tuch"						,130					,1				,6				,7					,0				,0),
	array("Kleiderfabrik"			,4000		,25			,8				,5			,"kf_kleiderfabrik"	,5				,2					,2							,"t Kleider"																				,"kf_kleider"					,170					,1				,9				,4					,0				,0),
	array("Kohlenmine"				,5000		,45			,10				,25			,"kf_kohlenmine"		,6				,3					,1							,"t Kohle"																					,"kf_kohle"						,125					,0				,0				,0					,0				,0),
	array("Eisenmine"					,5000		,90			,35				,25			,"kf_eisenmine"			,6				,3					,0							,"t Eisen"																					,"kf_eisen"						,250					,0				,0				,0					,0				,0),
	array("Schmiede"					,1500		,15			,10				,5			,"kf_schmiede"			,6				,3					,0							,"t Stahl"																					,"kf_stahl"						,450					,1				,2				,5					,13				,2),
	array("Waffenfabrik"			,4500		,60			,30				,5			,"kf_waffenfabrik"	,7				,3					,0							,"t Waffen"																					,"kf_waffen"					,400					,1				,2				,5					,14				,2),
	array("Goldmine"					,7000		,100		,50				,25			,"kf_goldmine"			,7				,3					,0							,"t Gold"																						,"kf_gold"						,630					,0				,0				,0					,0				,0),
	array("Edelsteinmine"			,8000		,120		,60				,25			,"kf_edelsteinmine"	,8				,3					,0							,"t Edelsteine"																			,"kf_edelsteine"			,750					,0				,0				,0					,0				,0),
	array("Goldschmied"				,5500		,30			,50				,5			,"kf_goldschmied"		,8				,4					,2							,"t Schmuck"																				,"kf_schmuck"					,950					,1				,15				,2					,16				,1),
	array("Marktplatz"				,1000		,30			,0				,5			,"kf_marktplatz"		,1				,0					,1							,"Marktplatz"																				,"kf_marktplatz"			,0						,0				,0				,0					,0				,0),
	array("Lagerhalle"				,2000		,35			,0				,5			,"kf_lagerhalle"		,1				,0					,1							,"* ".$lagerhalle_kap." t Ges. Lagerkapazit�t"			,"kf_lagerhalle"			,0						,0				,0				,0					,0				,0),
	array("Palast"						,5000		,1200		,250			,50			,"kf_palast"				,8				,0					,1							,"Palast"																						,"kf_palast"					,0						,0				,0				,0					,0				,0),
	array("Kathedrale"				,9000		,1500		,350			,20			,"kf_kathedrale"		,9				,0					,1							,"Kathedrale"																				,"kf_kathedrale"			,0						,0				,0				,0					,0				,0)
);

//armee	=			Art(0)								,Gold(1)	,Holz(2)	,Stahl(3)	,Waffen(4)	,DB-Feld(5)					,St�rke(6)
$armee = array(
	array("Scout"								,300			,0				,0				,0					,"kf_scout"					,3),
	array("Miliz"								,900			,30				,0				,0					,"kf_miliz"					,12),
	array("Infantrie"						,1750			,5				,2				,5					,"kf_infanterie"		,24),
	array("Kavallerie"						,3250			,1				,5				,10					,"kf_kavallerie"		,48),
	array("Artellerie"						,6550			,20				,3				,12					,"kf_artellerie"		,60),
	array("Garde"								,2000			,10				,12				,15					,"kf_garde"					,34)
);

//Armeest�rke erh�hen (Summe �ber Armeeart(Anzahl*St�rke+1));
$manoever=	5000; // Gold

//Nach einem gewonnenen Krieg
$min_land_gewinn=1000;
$max_land_gewinn=2000;
$min_taler_gewinn=1000;
$max_taler_gewinn=5000;
$min_einwohner_gewinn=500;
$max_einwohner_gewinn=2000;

?>