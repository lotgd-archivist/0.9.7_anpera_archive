<?php

// Krieg und Frieden
// Version 0.9.1

require_once "common.php";
require_once "kf_functions.php";

page_header("~~~~~~ Krieg und Frieden ~~~~~~~");
output("`c`b`^Geb�ude An-/Verkauf:`^`b`n`c");

//Hole Settings
$x=unserialize(kf_get_setting('x'));
$y=unserialize(kf_get_setting('y'));
$building=unserialize(kf_get_setting('building'));
$building_total=count($building);

if ($HTTP_GET_VARS[op]==""){
	output("`n`c`b`6Hier kannst Du nun Geb�ude kaufen / verkaufen.`b`6`c");
}else if($_GET['op']=="kaufen"){
	output("`n`c`b`6Aktion: Geb�ude kaufen`b`n`c");
	$anzahl=abs($_POST['anzahl']);
	$art=$_GET['id'];
	if($anzahl*$building[$art][1]*$y[$session[user][kf_tagrelation]]<=$session[user][kf_taler]){
		if($anzahl*round($building[$art][2]*$y[$session[user][kf_tagrelation]])<=$session[user][kf_holz]){
			if($anzahl*round($building[$art][3]*$y[$session[user][kf_tagrelation]])<=$session[user][kf_stein]){
				if($anzahl*$building[$art][4]<=$session[user][kf_land]-$session[user][kf_landnutzung]){
					output("`n`c`b`@Der Deal ist Perfekt!!`nDu kaufst ".$anzahl." ".$building[$art][0]."!`b`c");
					$session[user][$building[$art][5]]=$session[user][$building[$art][5]]+$anzahl;
					$session[user][kf_taler]=$session[user][kf_taler]-$anzahl*$building[$art][1]*$y[$session[user][kf_tagrelation]];
					$session[user][kf_holz]=$session[user][kf_holz]-$anzahl*$building[$art][2]*$y[$session[user][kf_tagrelation]];
					$session[user][kf_stein]=$session[user][kf_stein]-$anzahl*$building[$art][3]*$y[$session[user][kf_tagrelation]];
					$session[user][kf_landnutzung]=$session[user][kf_landnutzung]-$anzahl*$building[$art][4];
				}else{
					output("`n`c`b`$ Leider hast Du zu wenig Landbesitzt,`num ".$anzahl." ".$building[$art][0]." zu kaufen!`b`c");
				}
			}else{
				output("`n`c`b`$ Leider hast Du zu wenig Steine,`num ".$anzahl." ".$building[$art][0]." zu kaufen!`b`c");
			}
		}else{
			output("`n`c`b`$ Leider hast Du zu wenig Holz,`num ".$anzahl." ".$building[$art][0]." zu kaufen!`b`c");
		}
	}else{
		output("`n`c`b`$ Leider hast Du zu wenig Taler,`num ".$anzahl." ".$building[$art][0]." zu kaufen!`b`c");
	}
	$_GET['op']="";
}else if($_GET['op']=="verkaufen"){
	output("`n`c`b`6Aktion: Geb�ude verkaufen`b`n`c");
	$anzahl=abs($_POST['anzahl']);
	$art=$_GET['id'];
	if($anzahl>$session[user][$building[$art][5]]){
		output("`n`c`b`&Leider hast Du gar nicht soviele ".$anzahl." ".$building[$art][0]."!!!`n Deal geplatzt!`b`c");
	}else{
		output("`n`c`b`@Der Deal ist Perfekt!!`nDu verkaufst ".$anzahl." ".$building[$art][0]."!`b`c");
		$session[user][$building[$art][5]]=$session[user][$building[$art][5]]-$anzahl;
		$session[user][kf_taler]=$session[user][kf_taler]+$anzahl*$building[$art][1]*$y[$session[user][kf_tagrelation]];
		$session[user][kf_landnutzung]=$session[user][kf_landnutzung]+$anzahl*$building[$art][4];
	}
	$_GET['op']="";
}

output("`n`&`bDu hast derzeit:`b");
output("`nGold: ".$session[user][kf_taler]." Taler");
output(", ".$session[user][kf_holz]." Holz");
output(", ".$session[user][kf_stein]." Stein");
output("und ".$session[user][kf_land]." Land.");
$session[user][kf_landnutzung]=0;
for($i=0;$i<$building_total;$i++){
	$session[user][kf_landnutzung]=$session[user][kf_landnutzung]+$session[user][$building[$i][5]]*$building[$i][4];
}
$land_frei=$session[user][kf_land]-$session[user][kf_landnutzung];
output("`nDu hast noch ".$land_frei." Landkapazit�ten frei f�r Geb�ude.`n");
output("`n`nFolgende �bersicht der Geb�ude die du kaufen/verkaufen kannst:`n`n");
output("<table border='0' cellpadding='8' cellspacing='1' bgcolor='#999999'>",true);
output("<tr class='trhead'>",true);
output("<td><b>LvL</b></td><td><b>Art</b></td><td><b>Preis</b><td><b>Holz</b></td><td><b>Stein</b></td><td><b>Land</b></td><td><b>Du besitzt</b></td><td colspan='2' align='center'><b>Kaufen|Verkaufen</b></td></tr>",true);

for($a=0;$a<$building_total;$a++){
	if($building[$a][6]<=$session[user][kf_lvl]+1 || $session[user][$building[$a][5]]>0){
		output("<tr class='".($a%2?"trlight":"trdark")."'>",true);
		output("<td>".$building[$a][6]."</td><td>".$building[$a][0]."</td><td>".$building[$a][1]*$y[$session[user][kf_tagrelation]]."</td><td>".round($building[$a][2]*$y[$session[user][kf_tagrelation]])."</td><td>".round($building[$a][3]*$y[$session[user][kf_tagrelation]])."</td><td>".$building[$a][4]."</td><td>".$session[user][$building[$a][5]]."</td>",true);
		output("<td>",true);
		output("<form action='kf_gebaeude.php?op=kaufen&id=$a' method='POST'><input name='anzahl' id='anzahl' size='2'>"
		,true);
		output("<input type='submit' class='button' value='OK'></form>",true);
		output("</td>",true);
		addnav("","kf_gebaeude.php?op=kaufen&id=$a");
		output("<td>",true);
		output("<form action='kf_gebaeude.php?op=verkaufen&id=$a' method='POST'><input name='anzahl' id='anzahl' size='2'>"
					,true);
		output("<input type='submit' class='button' value='OK'></form></td>",true);
		output("</td>",true);
		addnav("","kf_gebaeude.php?op=verkaufen&id=$a");
		output("</tr>",true);
	}
}
output("</table>",true);
addnav("Sonstiges");
addnav("Zur�ck","kf_mainmenu.php");
if ($session[user][superuser]>=2){
	addnav("Administration");
	addnav("Einstellungen","kf_admin.php");
}

page_footer();

?>