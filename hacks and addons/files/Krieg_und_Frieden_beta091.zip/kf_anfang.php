<?php

// Krieg und Frieden
// Version: 0.9.1

require_once "common.php";
require_once "kf_functions.php";

page_header("~~~~~~ Krieg und Frieden ~~~~~~~");
output("`^`c`b~~~~~~ Krieg und Frieden ~~~~~~~`b`c`6`n");

addnav("Entscheidung");
if ($HTTP_GET_VARS[op]==""){
  checkday();
  output("`cWillkommen bei dem kleinen Spiel ~~Krieg und Frieden~~!`c`n`n");
  output("`&Die Aufgabe bei diesem Spiel ist, mit entsprechend Deinem Gold, Geschick und Wagemut, ein kleines Handelsimperium aufzubauen, L�nder zu erobern und Dein Volk zufrieden zu stellen!`n`n");
  output("Sollte es Dir ".$session[user][name]." gelingen, so wird der Ruhm und Reichtum Dich in LotgD begleiten!`n");
  output("Entscheide nun, was Du gerne m�chtest:`n`n");
  if($session[user][kf_spiel]==1){
  	output("<a href='kf_mainmenu.php'>Spiel fortsetzen</a><br>",true);
  	addnav("","kf_mainmenu.php");
  	addnav("Spiel fortsetzen","kf_mainmenu.php");
  	addnav("ODER");
  }
  output("<a href='kf_anfang.php?op=new'>Ein neues Spiel beginnen?</a><br>",true);
  addnav("","kf_anfang.php?op=new");
  addnav("Neues Spiel","kf_anfang.php?op=new");
  if ($session[user][superuser]>=2){
		addnav("Administration");
		addnav("Einstellungen","kf_admin.php");
	}
}else if ($HTTP_GET_VARS[op]=="new"){
	output("`&Nun denn, m�ge der Ruhm und Reichtum Dich begleiten und das Gl�ck Dir auf ewig hold sein!");
	set_newgame();
	addnav("Weiter","kf_mainmenu.php");
}

addnav("Sonstiges");
addnav("Spielanleitung","kf_anleitung.php");
addnav("Zur�ck ins Dorf","village.php");

page_footer();
?>
