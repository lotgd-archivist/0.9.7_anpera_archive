<?php

// Krieg und Frieden
// Version 0.9.1

//require_once "kf_constants.php";

function calculate_day(){
	global $session;

	$x=unserialize(kf_get_setting('x'));
	$y=unserialize(kf_get_setting('y'));
	$wetter_string=unserialize(kf_get_setting('wetter_string'));
	$punkte_faktor=kf_get_setting('punkte_faktor');
	$kosten_faktor=kf_get_setting('kosten_faktor');
	$lagerhalle_kap=kf_get_setting('lagerhalle_kap');
	$titel=unserialize(kf_get_setting('titel'));
	$punkte_titel=unserialize(kf_get_setting('punkte_titel'));
	$armee=unserialize(kf_get_setting('armee'));
	$building=unserialize(kf_get_setting('building'));
	
	$armee_ges=count($armee);
	$building_total=count($building);
	$relation=$session[user][kf_tagrelation];	
	
	
	
////////////////////////
//WARENVEWALTUNGTUNG + GELD + REPORT
////////////////////////
	$tagesbericht="`n`c`b`&Ergebnisse des Tages:`b`c";
	$tagesbericht.="`c----------------------------------------`c`n";
	$tagesbericht.="<table align='center' border='0' cellpadding='8' cellspacing='1' bgcolor='#999999'>";
	$tagesbericht.="<tr align='center' class='trhead'>";
	$tagesbericht.="<td><b>Art</b></td><td><b>Erwirtschaftet</b></td><td><b>Ben�tigt</b></td><td><b>Lager</b></td><td><b>Kosten</b></td>";
	for($a=0;$a<$building_total;$a++){
		$item=0;
		$item_ben=0;
		$lager_inhalt=0;
		$item_lager=0;
		$item_vorhanden=0;
		
		//Geb�ude vorhanden
		if($session[user][$building[$a][5]]>0 ){
			//Punkte f�r gekaufte Geb�ude
			$punkte=$punkte+$session[user][$building[$a][5]]*($building[$a][1]/$punkte_faktor);
			//Kosten
			(int)$kosten=round($session[user][$building[$a][5]]*($building[$a][1]/$kosten_faktor)*$y[$relation]);
			$geb�udekosten = $geb�udekosten+$kosten;
			$session[user][kf_taler]=$session[user][kf_taler]-$kosten;
			//Geb�ude liefert was
			if($building[$a][7]>0){
				if(!$building[$a][12]){
					(int)$item=round($session[user][$building[$a][5]]*$building[$a][7]*$x[$relation]);
				}else{
					//Ben�tigte Produktionsmittel errechnen
					$haben_item_a 	= $session[user][$building[$building[$a][13]][10]];
					$ben_menge_a	= $building[$a][14];
					$haben_item_b 	= $session[user][$building[$building[$a][15]][10]];
					$ben_menge_b	= $building[$a][16];
					$geb_ges			=	$session[user][$building[$a][5]]; 
					
					for($i=$geb_ges;$i>=1;$i--){
						$ben_menge_a_ges=$ben_menge_a*$i;
						$ben_menge_b_ges=$ben_menge_b*$i;
						
						if($haben_item_a>=$ben_menge_a_ges && $haben_item_b>=$ben_menge_b_ges){
							(int)$item=round($i*$building[$a][7]*$x[$relation]);
							$session[user][$building[$building[$a][13]][10]]=$haben_item_a-$ben_menge_a_ges;
							$hinweis="<br>Verwendet:".$ben_menge_a_ges." ".$building[$building[$a][13]][9]."";
							if($ben_menge_b>0){
								$session[user][$building[$building[$a][15]][10]]=$haben_item_b-$ben_menge_b_ges;
								$hinweis.=" und ".$ben_menge_b_ges." ".$building[$building[$a][15]][9]."";
							}
							break;
						}
					}
					
					if($i<$geb_ges){
						$hinweis.="<br>`$ Geringe Produktion! Es fehlten die Rohstoffe!";
					}
				}
				//Zoll
				$gesamt_produktion=$gesamt_produktion+$item;
			}
		}
		//Ben�tigt vom Volk
		if($session[user][kf_lvl]>=$building[$a][6]){
			if($building[$a][7]>0){
				$item_ben=round($building[$a][8]*($session[user][kf_einwohner]/1000)*$y[$relation]);
			}else{
				$item_ben=$building[$a][8]*$session[user][kf_lvl];
			}
			//Zoll
			$gesamt_bedarf=$gesamt_bedarf+$item_ben;
			$gesamt_grund_preis=$gesamt_grund_preis+$building[$a][11];
		}
		
		//Lager
		if($building[$a][7]>0){
			if($item>0 || $item_ben>0 || $hinweis<>""){
				//Lagerinhalt berechnet
				for($b=0;$b<$building_total;$b++){
					$lager_inhalt=$lager_inhalt+$session[user][$building[$b][10]];
				}
				//Was wurde erwirtschaftet
				$item_lager=$item-$item_ben;
				
				//Zufriedenheit im Volk, wenn Bed�rfnisse gedeckt wurden
				if($item_ben>0){
					$zufriedenheit=$zufriedenheit+$item_lager+$session[user][$building[$a][10]];
				}
				if($zufriedenheit>100){
					$zufriedenheit=100;
				}
				//output("".$building[$a][0].": ".$zufriedenheit."`n");
				
				//Punkte +/- f�r Produktion, welche alleine die Bed�rfnisse deckt
				$punkte=$punkte+$item_lager;
				
				//Was bleibt davon
				$item_vorhanden=$session[user][$building[$a][10]]+$item_lager;
				//Wenn �berschuss
				if($item_vorhanden>0){
					//und es ins Lager reinpasst, wird es eingelagert!
					if(($lager_inhalt+$item_lager)<=$lagerhalle_kap*$session[user][kf_lagerhalle]){
						$session[user][$building[$a][10]]=$session[user][$building[$a][10]]+$item_lager;
					//oder nur soviel reingetan, bis es voll ist!
					}else{
						if(!$voll){
							$item_lager=$lagerhalle_kap*$session[user][kf_lagerhalle]-$lager_inhalt;
							$session[user][$building[$a][10]]=$session[user][$building[$a][10]]+$item_lager;
						}
						$hinweis.="<br>`$ Lager ist voll!";
						$voll=1;
					}
				//kein �berschuss
				}else if($item_vorhanden==0){
					$session[user][$building[$a][10]]=0;
					$hinweis.="<br>`$ Achtung! Das wird knapp!";
				}else{
					$session[user][$building[$a][10]]=0;
					$hinweis.="<br>`$ Achtung! Es wurden ".abs($item_vorhanden)."t mehr gebraucht!";
				}
			}
		}		
		
	//Zeile im Report erstellen
		//1. Spalte: Wenn Building vorhanden oder ben�tigt, schreibe den Namen
		if($session[user][$building[$a][5]]>0 || $item_ben>0){
			$tagesbericht.="<tr class='".($a%2?"trlight":"trdark")."'>";
			$tagesbericht.="`&<td>".$building[$a][0]."</td>";
			//2.Spalte
			if($item>0){
				$tagesbericht.="`&<td>".$item." ".$building[$a][9]."</td>";
			}else{
				$tagesbericht.="<td></td>";
			}
			//3.Spalte
			if($item_ben>0){
				if($building[$a][7]>0){
					$tagesbericht.="`&<td>".$item_ben." ".$building[$a][9]."</td>";
				}else{
					$tagesbericht.="`&<td>".$item_ben."</td>";
				}
			}else{
				$tagesbericht.="<td></td>";
			}
			//4.Spalte
			if($building[$a][7]>0){
				$tagesbericht.="`&<td>".$session[user][$building[$a][10]]." ".$building[$a][9]." ".$hinweis."</td>";
			}else{
				$tagesbericht.="<td></td>";
			}	
			//5.Spalte
			if($session[user][$building[$a][5]]>0){
				$tagesbericht.="`$<td>".$kosten." Taler</td>";
			}else{
				$tagesbericht.="<td></td>";
			}			
			$tagesbericht.="</tr>";
		}
		$hinweis="";
	}
	$tagesbericht.="</tr>";
	$tagesbericht.="</table>";

	//Steuer und Zoll machen unzufrieden... immer :)
	$zufriedenheit=round($zufriedenheit-$session[user][kf_steuer]/10-$session[user][kf_zoll]/10);
	//output("Zoll/Steuer: ".$zufriedenheit."`n");

	//Justizreaktion auf Straftaten (jeder 100. B�rger ist b��seee und wenn dann auch noch das Wetter schlecht ist...)
	$straftaten=round(($session[user][kf_einwohner]/100)*$x[$relation]);
	//verurteilt
	$justiz=round($straftaten*($session[user][kf_justiz]/100));
	$justiz_ges=$straftaten-$justiz;
	
	//was negative Auswirkungen auf die Zufriedenheit haben kann
	$zufriedenheit=$zufriedenheit-$justiz_ges/5;
	//output("Justiz: ".$zufriedenheit."`n");
			
	//Ereignisse
	$tagesbericht.="`n`n`^`bBEV�LKERUNG:`b`&";
	if($zufriedenheit>=80){
			(int)$einwanderer 	=e_rand(1,$zufriedenheit*$x[$relation]);
			$tagesbericht.="`n- Es kamen ".$einwanderer." Einwanderer, ";	
			(int)$zuwachs			=e_rand(1,($session[user][kf_einwohner]/1000)*$zufriedenheit*$x[$relation]);
			$tagesbericht.=$zuwachs." Menschen sind geboren und ";	
			(int)$gestorben		=e_rand(1,$zuwachs);
			$tagesbericht.=$gestorben." Menschen sind gestorben.";	
	}else if($zufriedenheit>=50){
		(int)$einwanderer 	=e_rand(1,($zufriedenheit-50)*$x[$relation]);
		$tagesbericht.="`n- Es kamen ".$einwanderer." Einwanderer, ";	
		(int)$zuwachs			=e_rand(1,($session[user][kf_einwohner]/1000)*$zufriedenheit*$x[$relation]);
		$tagesbericht.=$zuwachs." Menschen sind geboren und ";	
		(int)$gestorben		=e_rand(1,$zuwachs);
		$tagesbericht.=$gestorben." Menschen sind gestorben.";	
	}else if($zufriedenheit>30){
		(int)$zuwachs			=e_rand(1,($session[user][kf_einwohner]/1000)*$zufriedenheit*$x[$relation]);
		$tagesbericht.="`n- Es sind ".$zuwachs." Menschen geboren und ";	
		(int)$gestorben		=e_rand(1,($session[user][kf_einwohner]/1000)*$zufriedenheit*$y[$relation]);
		$tagesbericht.=$gestorben." Menschen gestorben.";		
	}else{
		(int)$gestorben=e_rand(1,($session[user][kf_einwohner]/1000)*(100-$zufriedenheit)*$y[$relation]);
		$tagesbericht.="`n- Es sind ".$gestorben." Menschen gestorben!!";	
	}
	$tagesbericht.="`n`b`^---------------------`&`b";
	$bev_dif=$einwanderer+$zuwachs-$gestorben;
	$session[user][kf_einwohner]=$session[user][kf_einwohner]+$bev_dif;
	if($bev_dif>0){
		$tagesbericht.="`n`b`@ = ".$session[user][kf_einwohner]." Einwohner (+".$bev_dif." Einw.) `b";
	}else{
		$tagesbericht.="`n`b`$ = ".$session[user][kf_einwohner]." Einwohner (".$bev_dif." Einw.) `b";
	}	
	
	
	//Geld
	//EINNAHMEN
	$tagesbericht.="`n`n`^`bGELD:`b`&";
	$tagesbericht.="`^`n`b GESAMTEINNAHMEN:`b";	
	//Steuereinnahmen
	(int)$steuer=round($session[user][kf_einwohner]*($session[user][kf_steuer]/100)*$x[$relation]);
	$tagesbericht.="`n`&`b - Steuer:`b ".$steuer." Taler, ";
	
	//Zolleinnahmen	
	$verzollen=round(($gesamt_bedarf/$gesamt_produktion)*$gesamt_grund_preis);
	(int)$zoll=round($verzollen*($session[user][kf_zoll]/100)*$x[$relation]);
	$tagesbericht.="`&`b Zoll:`b ".$zoll." Taler, ";
	
	//Marktplatzeinnahmen
	(int)$marktplatz=round($session[user][kf_marktplatz]*$kosten_faktor*$x[$relation]);
	$tagesbericht.="`&`b Marktpl�tze:`b ".$marktplatz." Taler";
	$einnahmen_ges=$zoll+$steuer+$marktplatz;
	
	$tagesbericht.="`n`^`b---------------------`b`&";
	$tagesbericht.="`&`n`b = ".$einnahmen_ges." Taler `b";
	
	//AUSGABEN
	$tagesbericht.="`^`n`n`b GESAMTAUSGABEN: `b";
	$tagesbericht.="`&`n`b- Geb�udekosten:`b ".$geb�udekosten." Taler, ";
	(int)$justiz_k=round($session[user][kf_einwohner]*($session[user][kf_justiz]/$kosten_faktor)*$x[$relation]);
	$tagesbericht.="`&`b Justiz:`b ".$justiz_k." Taler, ";
	$tagesbericht.="`&`b Armee:`b ";
	for($i=0;$i<$armee_ges;$i++){
		if($session[user][$armee[$i][5]]>0){
			$armee_kosten=round(($armee[$i][1]/$kosten_faktor)*$session[user][$armee[$i][5]]*$y[$relation]);
			$tagesbericht.="`&".$session[user][$armee[$i][5]]." ".$armee[$i][0]." = ".$armee_kosten." Taler, ";
			$armee_kosten_ges=$armee_kosten_ges+$armee_kosten;
		}
	}
	$tagesbericht.="`&`b Armeekosten gesamt:`b ".$armee_kosten_ges." Taler";
	$ausgaben_ges=$geb�udekosten+$justiz_k+$armee_kosten_ges;
	$tagesbericht.="`n`^`b---------------------`b`&";
	$tagesbericht.="`&`n`b = ".$ausgaben_ges." Taler `b";
	$tagesbericht.="`n`^`b---------------------`b`&";
	
	//Alles insgesamt an Talern, Geb�udekosten wurden schon oben berechnet
	$session[user][kf_taler]=$session[user][kf_taler]+$einnahmen_ges-$justiz_k-$armee_kosten_ges;
	$taler_dif=$einnahmen_ges-$ausgaben_ges;
	if($session[user][kf_taler]>0 && $taler_dif>0){
		$tagesbericht.="`n`b`@ = ".$session[user][kf_taler]." Taler (+".$taler_dif." Taler)`&`b`n";
	}else{
		$tagesbericht.="`n`b`$ = ".$session[user][kf_taler]." Taler (".$taler_dif." Taler)`&`b`n";
	}
	//Punkte f�r die Bev�lkerung
	$punkte=$punkte+round($session[user][kf_einwohner]/10);
	
	//Punkte f�r Land/Einwohner
	$punkte=$punkte+round($session[user][kf_land]/$session[user][kf_einwohner]);
	
	//Punkte f�r Zufriedenheit
	$punkte=$punkte+round($zufriedenheit);
	
	//Punkte f�r Geld
	$punkte=$punkte+round($session[user][kf_taler]/1000);
	
	if($zufriedenheit>100){
		$zufriedenheit=100;
	}
	$tagesbericht.="`n`^`bJUSTIZ:`b";
	$tagesbericht.="`&`n- Es wurde(n) ".$straftaten." Straftat(en) angezeigt, wobei von der Justiz ".$justiz." verfolgt und bestraft werden konnte(n).";
	
	$results="`n`^`b`c Gesamtergebniss`n------------------------------------------------------------------------------`c`b";
	$results.="`c`g`bZufriedenheit: ".$zufriedenheit." %`b`c";
	$results.="`c`g`bErgebniss: ".$punkte." Punkte`b`c";
	if($punkte>=$punkte_titel[$session[user][kf_lvl]+1] && $session[user][kf_einwohner]>=$punkte_titel[$session[user][kf_lvl]+1] && $zufriedenheit >=50){
		$session[user][kf_lvl]=$session[user][kf_lvl]+1;
		$results.="`g`c`n`bLevel: ".$session[user][kf_lvl]." - Du wurdest zum ".$titel[$session[user][kf_lvl]]." ernannt!!!!`b`c";
		addnews("`^`cKrieg und Frieden:`n`0".$session[user][name]."`@ wurde zum ".$titel[$session[user][kf_lvl]]." ernannt!`c");
		$session[user][kf_titel]=$titel[$session[user][kf_lvl]];
	}else if(($punkte<$punkte_titel[$session[user][kf_lvl]] || $session[user][kf_einwohner]<=$punkte_titel[$session[user][kf_lvl]]) && $session[user][kf_lvl]>1){
		$session[user][kf_lvl]=$session[user][kf_lvl]-1;
		$results.="`g`c`n`bLevel: ".$session[user][kf_lvl]." - Du wurdest zum ".$titel[$session[user][kf_lvl]]." degradiert!!!!`b`c";
		addnews("`^`cKrieg und Frieden:`n`0".$session[user][name]."`@ wurde zum ".$titel[$session[user][kf_lvl]]." degradiert!`c");
		$session[user][kf_titel]=$titel[$session[user][kf_lvl]];
	}else{
		$level=$session[user][kf_lvl];
	}
	$results.="`n`c`$`b Ein Berater fl�stert Dir zu: `#Du bist ".$session[user][kf_titel].".`nDein n�chster Titel l�ge bei ".$punkte_titel[$session[user][kf_lvl]+1]." Punkten und Einwohner!`nNat�rlich nur, wenn Deine Einwohner auch entsprechend zufrieden sind!!`b`c";
	$results.="`c`^`b------------------------------------------------------------------------------`b`c";
	
	//Schreibe es in den Bericht und Datenbank
	$session[user][kf_tagesbericht]=$results;
	$session[user][kf_tagesbericht].=$tagesbericht;
	
}
	
function day_event(){
	global $session;
	
	//Hole Settings
	$building=unserialize(kf_get_setting('building'));
	
	
	//Welchem Geb�ude/Gegenstand passiert was
	$zufall_building=e_rand(1,$building_total);
	
	//je gr��er, desto seltener passieren besondere Ereignisse
	$zufall=50;
	
	switch(e_rand(1,$zufall)){
		case 1:
			if($session[user][$building[$zufall_building][5]]>=2){
				$event = "`b`c`$ Ein Gro�brand vernichtet ein(e/en) ".$building[$zufall_building][0]."`nAlle L�schversuche waren zwecklos!`n`b`c";
				$session[user][kf_land]=$session[user][kf_land]+$session[user][$building[$zufall_building][4]];
				$session[user][kf_landnutzung]=$session[user][kf_landnutzung]-$session[user][$building[$zufall_building][4]];
				$session[user][$building[$zufall_building][5]]=$session[user][$building[$zufall_building][5]]-1;
				addnews("`^`cKrieg und Frieden:`n`0".$session[user][name]."`@ hat bei einem Gro�brand ein ".$building[$zufall_building][0]." verloren.`nAlle L�schversuche waren zwecklos!`c"); 
			}
			break;	
		case 2:
			if($building[$zufall_building][7]>0 && $session[user][$building[$zufall_building][10]]>0){
				$wieviel = e_rand(1,$session[user][$building[$zufall_building][10]]);
				$event = "`b`c`$ Ein Gro�brand in einer Deiner Lagerhallen vernichtet ".$wieviel." ".$building[$zufall_building][9]."`nAlle L�schversuche waren zwecklos!`n`b`c";
				$session[user][$building[$zufall_building][10]]=$session[user][$building[$zufall_building][10]]-$wieviel;
				addnews("`^`cKrieg und Frieden:`n`0".$session[user][name]."`@ hat bei einem Gro�brand ".$wieviel." ".$building[$zufall_building][9]." verloren.`nAlle L�schversuche waren zwecklos!`c"); 
			}
			break;
		case 3:
			if($building[$zufall_building][7]>0){
				if($session[user][kf_scout]>0){
					$wieviel = e_rand(1,10);
					$event = "`b`c`6 Deine Scouts finden Ureinwohner und handeln ".$wieviel." ".$building[$zufall_building][9]." mit Ihnen!`n`b`c";
					$session[user][$building[$zufall_building][10]]=$session[user][$building[$zufall_building][10]]+$wieviel;
					addnews("`^`cKrieg und Frieden:`n`@Die Scouts von `0".$session[user][name]."`@ haben Ureinwohner gefunden`nund ".$wieviel." ".$building[$zufall_building][9]." gehandelt!`c"); 
				}else{
					$event = "`b`c`$ Leider besitzt Du keine Scouts, die f�r Dich Land und Umgebung erforschen!`nSonst w�re vielleicht etwas Tolles zu entdecken gewesen!`n`b`c";
				}
			}
			break;
		case 4:
			$wieviel = e_rand(1,1000);
			$event = "`b`c`6 Einer Deiner G�nner unterst�tzt Dich mit ".$wieviel." Talern!`nL�chelnd �berreicht er Dir den Beutel.`nDu �berlegst noch, ob er Dir nicht lieber ein Messer in den R�cken stechen will, aber verwirfst den Gedanken schnell wieder!`n`b`c";
			$session[user][kf_taler]=$session[user][kf_taler]+$wieviel;
			addnews("`^`cKrieg und Frieden:`n`@Ein G�nner von `0".$session[user][name]."`@ hat ihm ".$wieviel." Talern gespendet!`c");
			break;
		case 5:
			if($session[user][kf_scout]>=10){
				$event = "`b`c`6 Einer Deiner Scouts entdeckt eine Goldmine und stellt den Besitz f�r euch sicher!`n`b`c";
				$session[user][kf_goldmine]=$session[user][kf_goldmine]+1;
				addnews("`c`^Krieg und Frieden:`n`@Die Scouts von `0".$session[user][name]."`@ haben eine Goldmine entdeckt!`c");
			}else{
				$event = "`b`c`$ Leider besitzt Du nicht soviele Scouts, die f�r Dich Land und Umgebung erforschen!`nSonst w�re vielleicht etwas Tolles zu entdecken gewesen!`n`b`c";
			}
			break;
		case 6:
			if($session[user][kf_scout]>=12){
				$event = "`b`c`6 Einer Deiner Scouts entdeckt eine Edelsteinmine und stellt den Besitz f�r euch sicher!`n`b`c";
				$session[user][kf_edelsteinmine]=$session[user][kf_edelsteinmine]+1;
				addnews("`^`cKrieg und Frieden:`n`@Die Scouts von `0".$session[user][name]."`@ haben eine Edelsteinmine entdeckt!`c");
			}else{
				$event = "`b`c`$ Leider besitzt Du nicht soviele Scouts, die f�r Dich Land und Umgebung erforschen!`nSonst w�re vielleicht etwas Tolles zu entdecken gewesen!`n`b`c";
			}
			break;
		case 7:
			if($session[user][kf_scout]>=5){
				$event = "`b`c`6 Einer Deiner Scouts entdeckt eine Kohlenmine und stellt den Besitz f�r euch sicher!`n`b`c";
				$session[user][kf_kohlenmine]=$session[user][kf_kohlenmine]+1;
				addnews("`^`cKrieg und Frieden:`n`@Die Scouts von `0".$session[user][name]."`@ haben eine Kohlenmine entdeckt!`c");
			}else{
				$event = "`b`c`$ Leider besitzt Du nicht soviele Scouts, die f�r Dich Land und Umgebung erforschen!`nSonst w�re vielleicht etwas Tolles zu entdecken gewesen!`n`b`c";
			}
			break;
		case 8:
			if($session[user][kf_scout]>=8){
				$event = "`b`c`6 Einer Deiner Scouts entdeckt eine Eisenmine und stellt den Besitz f�r euch sicher!`n`b`c";
				$session[user][kf_eisenmine]=$session[user][kf_eisenmine]+1;
				addnews("`^`cKrieg und Frieden:`n`@Die Scouts von `0".$session[user][name]."`@ haben eine Eisenmine entdeckt!`c");
			}else{
				$event = "`b`c`$ Leider besitzt Du nicht soviele Scouts, die f�r Dich Land und Umgebung erforschen!`nSonst w�re vielleicht etwas Tolles zu entdecken gewesen!`n`b`c";
			}
			break;
		case 9:
			$wieviel = e_rand(1,1000);
			$event = "`b`c`6 Einer Deiner G�nner schenkt Dir ".$wieviel."ha Land!`nL�chelnd �berreicht er Dir die Besitzerurkunde.`nDu �berlegst noch, was er damit wohl bezwecken will, aber verwirfst den Gedanken schnell wieder!`n`b`c";
			$session[user][kf_land]=$session[user][kf_land]+$wieviel;
			addnews("`^`cKrieg und Frieden:`n`@Ein G�nner von `0".$session[user][name]."`@ schenkt ihm ".$wieviel."ha Land!`c");
			break;
		case 10:
			$event = "`b`c`6 Einer Deiner G�nner unterst�tzt Dich mit einer Milizeinheit!`nDu �berlegst noch, ob diese Einheit Dich nicht infiltrieren will, aber Du verwirfst den Gedanken schnell wieder!`n`b`c";
			$session[user][kf_miliz]=$session[user][kf_miliz]+1;
			addnews("`^`cKrieg und Frieden:`n`@Ein G�nner von `0".$session[user][name]."`@ unterst�zt ihn mit einer Milizeinheit!`c");
			break;
		case 11:
			$event = "`b`c`6 Einer Trapper aus dem Wald bietet Dir seine Dienste als Scout an!`nDankend nimmst Du sein Angebot an!`n`b`c";
			$session[user][kf_scout]=$session[user][kf_scout]+1;
			addnews("`^`cKrieg und Frieden:`n`@Eine Scouteinheit bietet `0".$session[user][name]."`@ seine Dienste an!`c");
			break;
		case 12:
			//erst ab Level 4
			if($session[user][kf_lvl]>=4){
				$wieviel = e_rand(1,$session[user][kf_einwohner]*0.3);
				$event = "`b`c`$ Die Pest! Die Pest!!!`nTraurig musst Du mit ansehen, wie ".$wieviel." Einwohner qualvoll sterben!`n`b`c";
				$session[user][kf_einwohner]=$session[user][kf_einwohner]-$wieviel;
				addnews("`^`cKrieg und Frieden:`n`$ Die Pest! Die Pest!!!`n`0".$session[user][name]."`@ verliert dadurch ".$wieviel." Einwohner!`c");
				break;
			}
		case 13:
		case 14:
		case 15:
		case 16:
		case 17:
		case 18:
		case 19:
		case 20:
		case 21:
		case 22:
		case 23:
		case 24:
		case 25:
		case 26:
		case 27:
		case 28:
		case 29:
		case 30:
		case 31:
		case 32:
		case 33:
		case 34:
		case 35:
		case 36:
		case 37:
		case 38:
		case 39:
		case 40:
		case 41:
		case 42:
		case 43:
		case 44:
		case 45:
		case 46:
		case 47:
		case 48:
		case 49:
		case 50:
	}
	if($event==""){
		output("`b`c`6Derzeit keine besonderen Vorkommnisse.`nAlles l�uft ruhig und geregelt!`n`b`c");
	}else{
		output($event);
	}
}

function kf_load_settings(){
	global $kf_settings;
	if (!is_array($kf_settings)){
		$kf_settings=array();
		$sql = "SELECT * FROM kf_settings";
		$result = db_query($sql) or die(db_error(LINK));
		for ($i=0;$i<db_num_rows($result);$i++){
			$row = db_fetch_assoc($result);
			$kf_settings[$row[setting]] = $row[value];
		}
		db_free_result($result);
	}
}

function kf_save_setting($settingname,$value){
	global $kf_settings;
	kf_load_settings();
	if ($value>""){
		if(is_array($value)){
			$data = serialize($value);
		}else{
			$data = $value;
		}
		if (!isset($kf_settings[$settingname])){
			$sql = "INSERT INTO kf_settings (setting,value) VALUES (\"".addslashes($settingname)."\",\"".addslashes($data)."\")";
		}else{
			$sql = "UPDATE kf_settings SET value=\"".addslashes($data)."\" WHERE setting=\"".addslashes($settingname)."\"";
		}
		db_query($sql) or die(db_error(LINK));
		$kf_settings[$settingname]=$value;
		if (db_affected_rows()>0) return true; else return false;
	}
	return false;
}

function kf_get_setting($settingname){
	global $kf_settings;
	kf_load_settings();
	return $kf_settings[$settingname];
}


function show_details(){
	global $session;
	
	//Hole Settings
	$building=unserialize(kf_get_setting('building'));
	$armee=unserialize(kf_get_setting('armee'));
	$armee_total=count($armee);
	$building_total=count($building);
	
	output("`b`6`cStaatsgesch�fte`c`b`n`&");
	output("<table align='center' border='0' cellpadding='8' cellspacing='1' bgcolor='#999999'>",true);
	output("<tr class='trhead'>",true);
	output("<td align='center'><b>LvL</b></td>
					<td align='center'><b>Titel</b></td>
					<td align='center'><b>Einwohner</b></td>
					<td align='center'><b>Land</b></td>
					<td align='center'><b>Taler</b></td>",true);
	output("<td align='center'><b>Justiz</b></td>
					<td align='center'><b>Zoll</b></td>
					<td align='center'><b>Steuer</b></td>",true);
	output("</tr>",true);
	output("<tr class='trdark'>",true);
	output("<td align='center'>".$session[user][kf_lvl]."</td>
					<td align='center'>".$session[user][kf_titel]."</td>
					<td align='center'>".$session[user][kf_einwohner]."</td>
					<td align='center'>".$session[user][kf_land]."</td>
					<td align='center'>".$session[user][kf_taler]."</td>",true);
	output("<td align='center'>".$session[user][kf_justiz]."</td>
					<td align='center'>".$session[user][kf_zoll]."</td>
					<td align='center'>".$session[user][kf_steuer]."</td>",true);
	output("</tr>",true);
	output("</table>",true);
	
	output("`b`6`c`nGeb�ude/G�ter`c`b`n`&");
	output("<table align='center' border='0' cellpadding='8' cellspacing='1' bgcolor='#999999'>",true);
	output("<tr class='trhead'>",true);
	output("<td align='center'><b>Art</b></td>
					<td align='center'><b>Anz.</b></td>
					<td align='center'><b>Lager</b></td>
					<td align='center'><b>Art</b></td>
					<td align='center'><b>Anz.</b></td>
					<td align='center'><b>Lager</b></td>",true);
	output("</tr>",true);
	output("<tr class='trdark'>",true);
	for($a=0;$a<$building_total;$a++){
		$b++;
		output("<td><b>".$building[$a][0]."</b></td><td>".$session[user][$building[$a][5]]."</td><td>".$session[user][$building[$a][10]]." ".$building[$a][9]."</td>",true);
		if($b==2){
			output("</tr>",true);
			if(!$c){
				output("<tr class='trlight'>",true);
				$c=1;
			}else{
				output("<tr class='trdark'>",true);
				$c=0;
			}
			$b=0;
		}
	}
	output("</tr>",true);
	output("</table>",true);
	
	output("`b`6`c`nArmee`c`b`n`&");
	output("<table align='center' border='0' cellpadding='8' cellspacing='1' bgcolor='#999999'>",true);
	output("<tr class='trhead'>",true);
	for($a=0;$a<$armee_total;$a++){
		output("<td><b>".$armee[$a][0]."</b></td>",true);
	}
	output("</tr>",true);
	output("<tr class='trdark'>",true);
	for($a=0;$a<$armee_total;$a++){
			output("<td>".$session[user][$armee[$a][5]]."</td>",true);
	}
	output("</tr>",true);
	output("</table>",true);
}

function set_newgame(){
	global $session;
	//Einstellen der Startwerte	
	$session[user][kf_spiel]=1;
	$session[user][kf_newday]=1;
	$session[user][kf_day]=0;
	$session[user][kf_titel]="Freiherr";
	$session[user][kf_lvl]=1;
	$session[user][kf_tagesbericht]="";

	//STAAT
	$session[user][kf_einwohner]=1000;   
	$session[user][kf_land]=5000;
	$session[user][kf_taler]=5000;
	$session[user][kf_justiz]=5;  
	$session[user][kf_zoll]=10;  
	$session[user][kf_steuer]=10; 
	$session[user][kf_marktplatz]=1;
	$session[user][kf_lagerhalle]=1;
	$session[user][kf_palast]=0;
	$session[user][kf_kathedrale]=0;

	//INDUSTRIE
	$session[user][kf_muehle]=2;
	$session[user][kf_holzfaeller]=1;
	$session[user][kf_salzmine]=0;
	$session[user][kf_weinberg]=0; 
	$session[user][kf_brennerei]=0;
	$session[user][kf_jaeger]=0; 
	$session[user][kf_schweinefarm]=0;
	$session[user][kf_schaffarm]=0;
	$session[user][kf_tuchfabrik]=0;
	$session[user][kf_kleiderfabrik]=0;
	$session[user][kf_schmiede]=0;
	$session[user][kf_kohlenmine]=0;
	$session[user][kf_eisenmine]=0;
	$session[user][kf_waffenfabrik]=0;
	$session[user][kf_goldmine]=0;
	$session[user][kf_steinbruch]=0;
	$session[user][kf_edelsteinmine]=0;
	$session[user][kf_goldschmied]=0;

	//G�TER in t
	$session[user][kf_korn]=20;
	$session[user][kf_holz]=0;
	$session[user][kf_alkohol]=0;
	$session[user][kf_wein]=0;
	$session[user][kf_wildfleisch]=0;
	$session[user][kf_schweinefleisch]=0;
	$session[user][kf_wolle]=0; 
	$session[user][kf_salz]=0;
	$session[user][kf_stein]=0;
	$session[user][kf_eisen]=0;
	$session[user][kf_kohle]=0;
	$session[user][kf_gold]=0;
	$session[user][kf_edelsteine]=0;
	$session[user][kf_tuch]=0;  
	$session[user][kf_kleider]=0;  
	$session[user][kf_stahl]=0;  
	$session[user][kf_waffen]=0;
	$session[user][kf_schmuck]=0;

	//ARMEE
	$session[user][kf_scout]=1;  
	$session[user][kf_miliz]=2;
	$session[user][kf_infanterie]=0;  
	$session[user][kf_kavallerie]=0;  
	$session[user][kf_artellerie]=0;  
	$session[user][kf_garde]=0;
	$session[user][kf_manoever]=0;
	$session[user][kf_krieg]=0;
}

?>