<?php

// Krieg und Frieden
// Version 0.9.1

require_once "common.php";
require_once "kf_functions.php";

page_header("~~~~~~ Krieg und Frieden ~~~~~~~");
output("`c`b`^Administration:`^`c`b`n");

$description_a = array(
	"Einheit",
	"Kosten",
	"Wieviel t Holz werden ben�tigt?",
	"Wieviel t Stahl werden ben�tigt?",
	"Wieviel t Waffen werden ben�tigt?",
	"Datenbankfeld der Einheit",
	"St�rke der Einheit"
);

$description_b = array(
		"Geb�udename",
		"Geb�udekosten",
		"Wieviel Tonnen Holz werden zum Bau ben�tigt",
		"Wieviel Tonnen Stein werden zum Bau ben�tigt",
		"Wieviel Hektar Land werden zum Bau ben�tigt",
		"Datenbankfeld des Geb�udes",
		"Ab Level erh�ltlich",
		"Das Geb�ude liefert Anzahl von Tonnen",
		"Anzahl Tonnen vom Volk ben�tigt (pro 1000)",
		"Bezeichnung des Gegenstandes, welches das Geb�ude liefert",
		"Datenbankfeld des Gegenstandes",
		"Grundpreis des Gegenstandes",
		"Ben�tigt das Geb�ude Gegenst�nde von anderen Geb�uden zur Herstellung (0=Nein,1=Ja)",
		"Wenn Ja, von welchem Geb�ude (Geb�udenr.)",
		"Wieviel Tonnen von dem Geb�ude",
		"Wenn Ja, von einem weiteren Geb�ude (Geb�udenr.)",
		"Wieviel Tonnen von diesem Geb�ude"
);

$setup = array(
	"`cSpieleinstellungen`c,title",
	"Wetter,title",
	"wetter_string"	=> "Wetterbezeichnungen",
	"x" => "daraus resultierender X-Faktor",
	"y" => "entgegengesetzter Y-Faktor",
	"Punkte/Titel,title",
	"punkte_titel" => "Punkte (ab wann man einen neuen Titel erh�lt)",
	"titel" => "Titelbezeichnung",
	"punkte_faktor"=>"Punkte Faktor",
	"Handel,title",
	"lagerhalle_kap"=>"Lagerhallenkapazit�t",
	"kosten_faktor"=>"Kosten Faktor",
	"preis_faktor"=>"Preis Faktor",
	"land_grundpreis"=>"Landgrundpreis",
	"Armee/Kriegeinstellungen,title",
	"laender" => "L�nder",
	"manoever_kosten"=>"Man�verkosten",
	"min_land_gewinn"=>"Minimum Landgewinn",
	"max_land_gewinn"=>"Maximum Landgewinn",
	"min_taler_gewinn"=>"Minimum Talergewinn",
	"max_taler_gewinn"=>"Maximum Talergewinn",
	"min_einwohner_gewinn"=>"Minimum Einwohnergewinn",
	"max_einwohner_gewinn"=>"Maximum Einwohnergewinn",
);

//Userdaten, Tagesbericht weggelassen!
$kf_userinfo = array(
	"Benutzerdaten,title"
	,"name"													=> "Name in LotgD"
	,"kf_spiel"											=> "Hat ein Spiel begonnen"   
	,"kf_lvl"  											=> "Level"
	,"kf_titel" 										=> "Titel" 
	,"kf_day" 											=> "Spieltag" 
	,"kf_newday" 										=> "Neuer Tag"
	,"kf_tagrelation" 							=> "Tagrelation f�r Wetter, X und Y Faktor"  
	,"kf_einwohner" 								=> "Einwohner" 
	,"kf_taler"											=> "Taler"
	,"kf_land" 											=> "Land"
	,"kf_landnutzung" 							=> "Landnutzung"
	,"kf_land_kauf" 								=> "Land in der Runde gekauft (0=Nein,1=Ja)"
	,"kf_krieg"  										=> "Krieg in der Runde gef�hrt"
	,"Staatsgesch�fte,title"
	,"kf_justiz" 										=> "Justiz" 
	,"kf_zoll"											=> "Zoll"  
	,"kf_steuer"										=> "Steuer"
	,"Geb�ude,title"
	,"kf_palast" 										=> "Pal�ste" 
	,"kf_kathedrale" 								=> "Kathedralen"
	,"kf_marktplatz"  							=> "Marktpl�tze"
	,"kf_lagerhalle"								=> "Lagerhallen"
	,"kf_muehle" 										=> "M�hlen"
	,"kf_holzfaeller"  							=> "Holzfaeller"
	,"kf_jaeger"										=> "J�ger"
	,"kf_steinbruch"								=> "Steinbr�che"
	,"kf_schaffarm"									=> "Schaffarmen"
	,"kf_schweinefarm"							=> "Schweinefarmen"
	,"kf_tuchfabrik"								=> "Tuchfabriken"  
	,"kf_kleiderfabrik"							=> "Kleiderfabriken" 
	,"kf_salzmine"									=> "Salzminen" 
	,"kf_brennerei"  								=> "Kornbrennerei" 
	,"kf_weinberg"									=> "Weinberg"   	
	,"kf_eisenmine"									=> "Eisenminen"   
	,"kf_kohlenmine"								=> "Kohlenminen"   
	,"kf_schmiede"									=> "Schmieden"   
	,"kf_waffenfabrik"							=> "Waffenfabriken"     
	,"kf_goldmine"  								=> "Goldminen" 
	,"kf_edelsteinmine"  						=> "Edelsteinminen" 
	,"kf_goldschmied"								=> "Goldschmieden"
	,"Gegenst�nde,title"
	,"kf_korn"											=> "t Korn"
	,"kf_holz"											=> "t Holz"
	,"kf_wildfleisch"								=> "t Wildfleisch"
	,"kf_stein" 										=> "t Stein"
	,"kf_wolle"											=> "t Wolle"
	,"kf_tuch"											=> "t Tuch"  
	,"kf_kleider"										=> "t Kleider"    
	,"kf_schweinefleisch"						=> "t Schweinefleisch"   
	,"kf_salz"											=> "t Salz"   
	,"kf_alkohol"										=> "t Alkohol" 
	,"kf_wein"											=> "t Wein" 
	,"kf_eisen" 										=> "t Eisen"  
	,"kf_kohle"											=> "t Kohle"   
	,"kf_stahl"											=> "t Stahl" 
	,"kf_waffen"										=> "t Waffen" 
	,"kf_gold"											=> "t Gold"   
	,"kf_edelsteine"								=> "t Edelsteine"  
	,"kf_schmuck"										=> "t Schmuck" 
	,"Armee,title"
	,"kf_scout" 										=> "Scouts"  
	,"kf_miliz"											=> "Milizen"   
	,"kf_infanterie"								=> "Infanterie"   
	,"kf_kavallerie"								=> "Kavallerie"   
	,"kf_artellerie"								=> "Artellerie"   
	,"kf_garde"											=> "Garde"   
	,"kf_manoever"									=> "Man�ver" 
	,"kf_gegner"										=> "Gegner"   
);

if ($HTTP_GET_VARS[op]==""){
	output("`&In diesem Bereich kannst Du Spieleinstellungen durchf�hren!`n");
	output("`nWas m�chtest Du tun?");
	addnav("Aktionen");
	addnav("Geb�ude-Editor","kf_admin.php?op=building");
	addnav("Armee-Editor","kf_admin.php?op=armee");
	addnav("Handel/Krieg-Editor","kf_admin.php?op=sonstige");
	addnav("Spieler-Editor","kf_admin.php?op=spieler");
	addnav("Installation");
	addnav("Default-Werte in kf_settings schreiben","kf_admin.php?op=install");
	addnav("Sonstiges");
	addnav("Neuer Tag","newday.php");
	addnav("X?Admin Grotte","superuser.php");
	addnav("Zur�ck");
	addnav("Zur�ck zum Spiel","kf_anfang.php");
//INSTALLATION
}else if($_GET[op]=="install"){
	require_once "kf_install.php";
	output("`c`bDefault-Werte werden in die Tabelle kf_settings geschrieben!`b`c`n");
	kf_save_setting("x",$x);
	kf_save_setting("y",$y);
	kf_save_setting("wetter_string",$wetter_string);
	kf_save_setting("lagerhalle_kap",$lagerhalle_kap);
	kf_save_setting("punkte_faktor",$punkte_faktor);
	kf_save_setting("land_grundpreis",$land_grundpreis);
	kf_save_setting("kosten_faktor",$kosten_faktor);
	kf_save_setting("preis_faktor",$preis_faktor);
	kf_save_setting("laender",$laender);
	kf_save_setting("punkte_titel",$punkte_titel);
	kf_save_setting("titel",$titel);
	kf_save_setting("building",$building);
	kf_save_setting("armee",$armee);
	kf_save_setting("manoever_kosten",$manoever);
	kf_save_setting("min_land_gewinn",$min_land_gewinn);
	kf_save_setting("max_land_gewinn",$max_land_gewinn);
	kf_save_setting("min_taler_gewinn",$min_taler_gewinn);
	kf_save_setting("max_taler_gewinn",$max_taler_gewinn);
	kf_save_setting("min_einwohner_gewinn",$min_einwohner_gewinn);
	kf_save_setting("max_einwohner_gewinn",$max_einwohner_gewinn);
	output("`nAbgeschlossen! Alle Daten sind in der Tabelle kf_settings gespeichert!");
	addnav("Sonstiges");
	addnav("Zur�ck","kf_admin.php");
	
//GEBAEUDE
}else if($_GET['op']=="building"){
	output("`c`6Option: Geb�ude editieren`c`6`n");
	kf_load_settings();
	$building = unserialize($kf_settings['building']);
	$building_total = count($building);
	$anzahl_2= count($building[1]);
	
	if($_GET['id']==""){
		output("`nWelches Geb�ude willst Du editieren?`n`n");
		for($a=0;$a<$building_total;$a++){
			output("<a href='kf_admin.php?op=building&id=$a'>".$a.". ".$building[$a][0]."</a><br>",true);
			addnav("","kf_admin.php?op=building&id=$a");
		}
		addnav("Aktion");
		addnav("Neues Geb�ude","kf_admin.php?op=newbuilding");
	}else{
		$a=$_GET['id'];
		output("<table border='0' cellpadding='8' cellspacing='1' bgcolor='#999999' align='center'>",true);
		output("<tr>",true);
		output("<form action='kf_admin.php?op=buildingdel&id=$a' method='POST'>",true);
		addnav("","kf_admin.php?op=buildingdel&id=$a");
		output("<input type='submit' class='button' value='Delete'>",true);
		output("</form>",true);
		output("</tr>",true);
		output("<tr class='".($a%2?"trlight":"trdark")."'>",true);
		output("<td colspan='2' align='center'><b>Geb�udenr.: ".$a." Name:".$building[$a][0]."</b></td>",true);
		output("<form action='kf_admin.php?op=building2&id=$a' method='POST'>",true);
		addnav("","kf_admin.php?op=building2&id=$a");
		for($b=0;$b<$anzahl_2;$b++){
			output("<tr class='".($b%2?"trlight":"trdark")."'>",true);
			output("<td>".$description_b[$b]."</td>",true);
			output("<td>",true);
			output("<input name='$b' id='wert' value='".$building[$a][$b]."'>",true);
			output("</td>",true);
			output("</tr>",true);
		}
		output("<input type='submit' class='button' value='SAVE'></form>",true);
		output("</tr>",true);
		
		output("</table>",true);
		addnav("Aktion");
		addnav("Zur�ck zum Geb�udeeditor","kf_admin.php?op=building");
	}
	addnav("Sonstiges");
	addnav("Zur�ck","kf_admin.php");
}else if($_GET['op']=="building2"){
	kf_load_settings();
	$building = unserialize($kf_settings['building']);
	output("`c`6Option: Geb�ude editiert`c`6`n");
	$a=$_GET['id'];
	output("`bGeb�udenr.: ".$a." Name: ".$building[$a][0]."`b`n`n");
	reset($_POST);
	while(list($key,$val)=each($_POST)){
		output("`b`^".$description_b[$key].":`b`&`nVon ".$building[$a][$key]." auf $val gesetzt`n");
	}
	$building[$a]=$_POST;
	kf_save_setting('building',$building);
	addnav("Sonstiges");
	addnav("Zur�ck","kf_admin.php?op=building&id=$a");
}else if($_GET['op']=="newbuilding"){	
	output("<table border='0' cellpadding='8' cellspacing='1' bgcolor='#999999' align='center'>",true);
	output("<tr class='trlight'>",true);
	output("<td colspan='2' align='center'><b>Neues Geb�ude:</b></td>",true);
	output("</tr>",true);
	output("<form action='kf_admin.php?op=newbuildingsave' method='POST'>",true);
	addnav("","kf_admin.php?op=newbuildingsave");
	while(list($key,$val)=each($description_b)){
			output("<tr class='".($b%2?"trlight":"trdark")."'>",true);
			output("<td>".$description_b[$key]."</td>",true);
			output("<td><input name='$key'></td>",true);
			output("</tr>",true);
			$b++;
	}
	output("<input type='submit' class='button' value='Speichern'>",true);
	output("</form>",true);
	output("</table>",true);
	addnav("Sonstiges");
	addnav("Zur�ck zum Geb�udeeditor","kf_admin.php?op=building");
}else if($_GET['op']=="newbuildingsave"){
	$building = unserialize(kf_get_setting('building'));
	array_push($building,$_POST);
	kf_save_setting('building',$building);
	output("Geb�ude hinzugef�gt!");
	addnav("Sonstiges");
	addnav("Zur�ck zum Geb�udeeditor","kf_admin.php?op=building");
}else if($_GET['op']=="buildingdel"){
	$a=$_GET['id'];
	$building = unserialize(kf_get_setting('building'));
	
	//Untersuche, ob andere Geb�ude abh�ngig sind
	for($i=0;$i<count($building);$i++){
		if($building[$i][13]==$a || $building[$i][15]==$a){
			$no=1;
			output("`n`$ Geb�ude kann nicht gel�scht werden, da Geb�ude ".$building[$i][0]." Gegenst�nde von diesem Geb�ude ben�tigt!`n");
		}
	}
	if(!$no){
		$rest=$a+1-count($building);
		if($rest==0){
			$rest=$a;
		}
		array_splice($building,$a,$rest);
		kf_save_setting('building',$building);
		output("Geb�ude gel�scht! Eventuelle Datenbankfelder, Zuweisungen in der kf_functions.php und dragon.php m�ssen manuell gel�scht werden!!!!");
	}
	addnav("Sonstiges");
	addnav("Zur�ck zum Geb�udeeditor","kf_admin.php?op=building");
//ARMEE	
}else if($_GET['op']=="armee"){
	output("`c`6Option: Armee editieren`c`6`n");
	kf_load_settings();
	$armee = unserialize($kf_settings['armee']);
	$armee_total = count($armee);
	$anzahl_2= count($armee[1]);
	if($_GET['id']==""){
		output("`nWelche Armeeeinheit willst Du editieren?`n`n");
		for($a=0;$a<$armee_total;$a++){
			output("<a href='kf_admin.php?op=armee&id=$a'>".$a.". ".$armee[$a][0]."</a><br>",true);
			addnav("","kf_admin.php?op=armee&id=$a");
		}
		addnav("Aktion");
		addnav("Neue Armee-Einheit","kf_admin.php?op=newarmee");
	}else{
		$a=$_GET['id'];
		output("<table border='0' cellpadding='8' cellspacing='1' bgcolor='#999999' align='center'>",true);
		output("<tr>",true);
			output("<td>",true);
			output("<form action='kf_admin.php?op=armeedel&id=$a' method='POST'>",true);
			addnav("","kf_admin.php?op=armeedel&id=$a");
			output("<input align='center' type='submit' class='button' value='Delete'>",true);
			output("</form>",true);
			output("</td>",true);
			output("<td>",true);
			output("<form action='kf_admin.php?op=armee2&id=$a' method='POST'>",true);
			addnav("","kf_admin.php?op=armee2&id=$a");
			output("<input  align='center' type='submit' class='button' value='SAVE'>",true);
			output("</td>",true);
		output("</tr>",true);
		output("<tr class='".($a%2?"trlight":"trdark")."'>",true);
			output("<td colspan='2' align='center'><b>Armeeinheit: ".$a.". ".$armee[$a][0]."</b></td>",true);
		output("</tr>",true);
		
		for($b=0;$b<$anzahl_2;$b++){
			output("<tr class='".($b%2?"trlight":"trdark")."'>",true);
				output("<td>".$description_a[$b]."</td>",true);
				output("<td>",true);
				output("<input name='$b' id='wert' value='".$armee[$a][$b]."'>",true);
				output("</td>",true);
			output("</tr>",true);
		}
		output("</form>",true);
		output("</table>",true);
		addnav("Aktion");
		addnav("Zur�ck zum Armee-Editor","kf_admin.php?op=armee");
	}
	addnav("Sonstiges");
	addnav("Zur�ck","kf_admin.php");
}else if($_GET['op']=="armee2"){
	output("`c`6Option: Armee editiert`c`6`n");
	kf_load_settings();
	$armee = unserialize($kf_settings['armee']);
	$a=$_GET['id'];
	reset($_POST);
	output("`bEinheit: ".$a.". ".$armee[$a][0]."`b`n`n");
	while(list($key,$val)=each($_POST)){
		output("`b`^".$description_a[$key].":`b`&`nVon ".$armee[$a][$key]." auf $val gesetzt`n");
	}
	$armee[$a]=$_POST;
	kf_save_setting('armee',$armee);
	addnav("Sonstiges");
	addnav("Zur�ck zum Armee-Editor","kf_admin.php?op=armee&id=$a");
}else if($_GET['op']=="newarmee"){	
	output("<table border='0' cellpadding='8' cellspacing='1' bgcolor='#999999' align='center'>",true);
	output("<tr class='trlight'>",true);
	output("<td colspan='2' align='center'><b>Neue Armee-Einheit:</b></td>",true);
	output("</tr>",true);
	output("<form action='kf_admin.php?op=newarmeesave' method='POST'>",true);
	addnav("","kf_admin.php?op=newarmeesave");
	while(list($key,$val)=each($description_a)){
			output("<tr class='".($b%2?"trlight":"trdark")."'>",true);
			output("<td>".$description_a[$key]."</td>",true);
			output("<td><input name='$key'></td>",true);
			output("</tr>",true);
			$b++;
	}
	output("<input type='submit' class='button' value='Speichern'>",true);
	output("</form>",true);
	output("</table>",true);
	addnav("Sonstiges");
	addnav("Zur�ck zum Armee-Editor","kf_admin.php?op=armee");
}else if($_GET['op']=="newarmeesave"){
	$armee = unserialize(kf_get_setting('armee'));
	array_push($armee,$_POST);
	kf_save_setting('armee',$armee);
	output("Armee-Einheit hinzugef�gt!");
	addnav("Sonstiges");
	addnav("Zur�ck zum Armee-Editor","kf_admin.php?op=armee");
}else if($_GET['op']=="armeedel"){
	$a=$_GET['id'];
	$armee = unserialize(kf_get_setting('armee'));
	$rest=$a+1-count($armee);
	if($rest==0){
		$rest=$a;
	}
	array_splice($armee,$a,$rest);
	kf_save_setting('armee',$armee);
	output("Armee-Einheit gel�scht! Eventuelle Datenbankfelder, Zuweisungen in der kf_functions.php und dragon.php m�ssen manuell gel�scht werden!!!!");
	addnav("Sonstiges");
	addnav("Zur�ck zum Armee-Editor","kf_admin.php?op=armee");
	
	
//Sonstige Werte
}else if($_GET['op']=="sonstige"){
	output("`c`6Option: Krieg und Handel Werte editieren`c`6`n`n");
	kf_load_settings();	
	output("<form action='kf_admin.php?op=sonstige2' method='POST'>",true);
	addnav("","kf_admin.php?op=sonstige2");
	showform($setup,$kf_settings);
	output("</form>",true);
	addnav("Sonstiges");
	addnav("Zur�ck","kf_admin.php");
}else if($_GET['op']=="sonstige2"){
	output("`c`6Option: Krieg und Handel Werte editiert`c`6`n`n");
	reset($_POST);
	while (list($key,$val)=each($_POST)){
		kf_save_setting($key,stripslashes($val));
		output("Setze $key auf ".stripslashes($val)."`n");
	}
	addnav("Sonstiges");
	addnav("Zur�ck","kf_admin.php?op=sonstige");
}else if($_GET['op']=="spieler"){
	output("`c`6Option: Spieler ausw�hlen`c`6`n`n");
	
	$sql = "SELECT acctid FROM accounts WHERE ";
	$where="kf_spiel=1";
	$result = db_query($sql.$where);
	if (db_num_rows($result)<=0){
		output("`\$Keine Ergebnisse gefunden`0");
		$_GET[op]="";
		$where="";
	}elseif (db_num_rows($result)>100){
		output("`\$Zu viele Ergebnisse gefunden. Bitte Suche einengen.`0");
		$_GET[op]="";
		$where="";
	}elseif (db_num_rows($result)==1){
		$_GET[op]="";
		$_GET['page']=0;
	}else{
		$_GET[op]="";
		$_GET['page']=0;
	}
	$sql = "SELECT count(acctid) AS count FROM accounts WHERE kf_spiel=1";
	$result = db_query($sql);
	$row = db_fetch_assoc($result);
	$page=0;
	addnav("Seiten");
	while ($row[count]>0){
		$page++;
		addnav("$page Seite $page","kf_admin.php?op=spieler&page=".($page-1)."&sort=$_GET[sort]");
		$row[count]-=100;
	}
	if (isset($_GET['page'])){
			$order = "acctid";
			if ($_GET[sort]!="") $order = "$_GET[sort]";
			$offset=(int)$_GET['page']*100;
			$sql = "SELECT acctid,login,name FROM accounts ".($where>""?"WHERE $where ":"")."ORDER BY \"$order\" LIMIT $offset,100";
			$result = db_query($sql) or die(db_error(LINK));
			output("<table align='center'>",true);
			output("<tr>
			<td><b>Ops</b></td>
			<td><b>Login</b></a></td>
			<td><b>Name</b></td>
			</tr>",true);
			for ($i=0;$i<db_num_rows($result);$i++){
				$row=db_fetch_assoc($result);
				output("<tr class='".($rn%2?"trlight":"trdark")."'>",true);
				output("<td>",true);
				output("[<a href='kf_admin.php?op=spieler2&userid=$row[acctid]'>Edit</a>]",true);
				addnav("","kf_admin.php?op=spieler2&userid=$row[acctid]");
				output("</td><td>",true);
				output($row[login]);
				output("</td><td>",true);
				output($row[name]);
				output("</td>",true);
				output("</tr>",true);
			}
			output("</table>",true);
	}
	addnav("Sonstiges");
	addnav("Zur�ck","kf_admin.php");
}else if($_GET['op']=="spieler2"){
	output("`c`6Option: Spielerwerte editieren`c`6`n`n");
	$result = db_query("SELECT * FROM accounts WHERE acctid='$_GET[userid]'") or die(db_error(LINK));
	$row = db_fetch_assoc($result) or die(db_error(LINK));
	output("<form action='kf_admin.php?op=spieler3&userid=$_GET[userid]' method='POST'>",true);
	output("<input type='submit' class='button' value='Speichern'>",true);
	addnav("","kf_admin.php?op=spieler3&userid=$_GET[userid]");
	showform($kf_userinfo,$row);
	output("</form>",true);
	addnav("Sonstiges");
	addnav("Zur�ck","kf_admin.php?op=spieler");
}else if($_GET['op']=="spieler3"){
	output("`c`6Option: Spielerwerte editiert`c`6`n`n");
	$sql = "UPDATE accounts SET ";
	reset($_POST);
	while (list($key,$val)=each($_POST)){
		if (isset($kf_userinfo[$key])){
			$sql.="$key = \"$val\",";
		}
	}
	$sql=substr($sql,0,strlen($sql)-1);
	$sql.=" WHERE acctid=\"$_GET[userid]\"";
	addnav("","kf_admin.php?op=spieler2&userid=$_GET[userid]");
	saveuser();
	$result=db_query($sql) or die(db_error(LINK));
	header("Location: kf_admin.php?op=spieler2&userid=$_GET[userid]");
	exit();
}
page_footer();

?>