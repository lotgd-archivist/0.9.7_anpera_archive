<?php

// Krieg und Frieden
// Version 0.9.1

require_once "common.php";

page_header("~~~~~~ Krieg und Frieden ~~~~~~~");
output("`c`b`^Staatsgesch�fte:`^`c`b`n");

if ($HTTP_GET_VARS[op]==""){
	output("`&In diesem Bereich stehen Dir derzeit die Staatsgesch�fte wie Steuer, Zoll und Justiz zur Verf�gung.`n");
	output("`nWas m�chtest Du tun?");
	addnav("Aktionen");
	addnav("Steuer festlegen","kf_staat.php?op=steuer");
	addnav("Zoll festlegen","kf_staat.php?op=zoll");
	addnav("Justiz festlegen","kf_staat.php?op=justiz");
	addnav("Sonstiges");
	addnav("Zur�ck","kf_mainmenu.php");
	if ($session[user][superuser]>=2){
		addnav("Administration");
		addnav("Einstellungen","kf_admin.php");
	}
}else if($_GET['op']=="steuer"){
	output("`c`6Option: Steuer festlegen`c`6`n");
	output("Die Steuer stehen derzeit bei ".$session[user][kf_steuer]." %`n");
	output("<form action='kf_staat.php?op=steuer2' method='POST'>Auf wieviel m�chtest Du sie festlegen?
					<input name='amount' id='amount' width='5'>",true);
	output("<input type='submit' class='button' value='OK'></form>",true);
	addnav("","kf_staat.php?op=steuer2");
	addnav("Sonstiges");
	addnav("Zur�ck","kf_staat.php");
}else if($_GET['op']=="steuer2"){
	output("`c`6Option: Steuer festlegen`c`6`n");
	$session[user][kf_steuer]=abs((int)$_POST['amount']);
	if($session[user][kf_steuer]>100){
		$session[user][kf_steuer]=100;
	}
	output("`&Du setzt die Steuer auf ".$session[user][kf_steuer]."%`n");
	addnav("Sonstiges");
	addnav("Zur�ck","kf_staat.php");
}else if($_GET['op']=="zoll"){
	output("`c`6Option: Zoll festlegen`c`6`n");
	output("Der Zoll steht derzeit bei ".$session[user][kf_zoll]." %`n");
	output("<form action='kf_staat.php?op=zoll2' method='POST'>Auf wieviel m�chtest Du ihn festlegen?
					<input name='amount' id='amount' width='5'>",true);
	output("<input type='submit' class='button' value='OK'></form>",true);
	addnav("","kf_staat.php?op=zoll2");
	addnav("Sonstiges");
	addnav("Zur�ck","kf_staat.php");
}else if($_GET['op']=="zoll2"){
	output("`c`6Option: Zoll festlegen`c`6`n");
	$session[user][kf_zoll]=abs((int)$_POST['amount']);
	if($session[user][kf_zoll]>100){
		$session[user][kf_zoll]=100;
	}
	output("`&Du setzt den Zoll auf ".$session[user][kf_zoll]."%`n");
	addnav("Sonstiges");
	addnav("Zur�ck","kf_staat.php");
}else if($_GET['op']=="justiz"){
	output("`c`6Option: Justiz festlegen`c`6`n");
	output("Die Justiz steht derzeit bei ".$session[user][kf_justiz]." % H�rte`n");
	output("<form action='kf_staat.php?op=justiz2' method='POST'>Auf wieviel m�chtest Du sie festlegen?
					<input name='amount' id='amount' width='5'>",true);
	output("<input type='submit' class='button' value='OK'></form>",true);
	addnav("","kf_staat.php?op=justiz2");
	addnav("Sonstiges");
	addnav("Zur�ck","kf_staat.php");
}else if($_GET['op']=="justiz2"){
	output("`c`6Option: Justiz festlegen`c`6`n");
	$session[user][kf_justiz]=abs((int)$_POST['amount']);
	if($session[user][kf_justiz]>100){
			$session[user][kf_justiz]=100;
	}
	output("`&Du setzt die H�rte der Justiz auf ".$session[user][kf_justiz]."%`n");
	addnav("Sonstiges");
	addnav("Zur�ck","kf_staat.php");
}

page_footer();

?>