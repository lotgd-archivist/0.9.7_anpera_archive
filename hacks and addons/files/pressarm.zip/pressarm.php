<?php
require_once "common.php";
$user =& $session[user];

$infos=array(
"owner"=>"Donols Haus der Qualen",
"file" => "".basename(__FILE__),
"creator" => "Hadriel",
"editor" => "Tiger313",
"homepage" => "http://www.hadrielnet.ch",
"homepage-editor" => "http://www.mlcrew.de",
"version" => "1.3 Beta"
);
page_header($infos['owner']);
$vermoegen=$session[user][goldinbank];
$gewinn1 =round(($session['user']['goldinbank']+$session['user']['gold'])/100*15);
$gewinn2 =round(($session['user']['goldinbank']+$session['user']['gold'])/100*20);
$gewinn3 =round(($session['user']['goldinbank']+$session['user']['gold'])/100*25);
$gold1 =round($vermoegen/10);
$gold2 =round($vermoegen /8);
$gold3 =round($vermoegen /6);
if($_GET[op]==""){
output("`2Donol begr�sst dich in seinem sogenannten 'Haus der Qualen'. Hier kannst du gegen seine Jungs, Jirok, Kolop und Faler, armdr�cken.`n Jeder der drei hat andere st�rken und schw�chen. `nEr macht dich darauf aufmerksam, dass du erst mit 500 Goldst�cken Gesamtverm�gen hier k�mpfen kannst.");
if ($vermoegen >=500){
addnav("Infotafel");
addnav("Heutige Quote","".$infos['file']."?op=info");
addnav("Die Gegner");
addnav("Jirok","".$infos['file']."?op=1");
addnav("Kolop","".$infos['file']."?op=2");
addnav("Faler","".$infos['file']."?op=3");
}
addnav("Sonstiges");
addnav("Zur�ck zum Dorf","village.php");
}
if($_GET[op]==1){
output("`2Du w�hlst Jirok aus. Ihr setzt euch an einen Tisch, legt einen eurer Arme auf den Tisch und beginnt.");
output("`n`n`2Aktueller Status:");
output("`n".grafbar(100,50,100,20)."",true);
addnav("Weiter","".$infos['file']."?op=11");
}
if($_GET[op]==11){
$rand=e_rand(1,100);
$session['try']++;
$try=$session['try'];
output("`2Du versuchst wie Wild den Arm von Jirok auf den Tisch zu schmettern.");
output("`n`n`2Aktueller Status:");
output("`n".grafbar(100,$rand,100,20)."",true);
if($rand<=10){
//$gold =$vermoegen /10;
output("`n`2Du hast in ".$try." Z�gen `4VERLOREN!`2 Jirok verlangt ".$gold1." Gold von dir.");
if ($user['gold'] >=$gold1){
$user[gold]-=$gold1;
} else {
$user[goldinbank]-=$gold1;
output("`n`2Da du nicht genug bei dir hast wurde der Betrag von deinem Konto abgezogen..");
}

addnav("Zur�ck",$infos['file']);
$session['try']=0;
}else if($rand>=90){
if ($gewinn1 >=1000){
$gold=1000;
} else {
$gold =$gewinn1;
}
output("`n`2Du hast in ".$try." Z�gen `4GEWONNEN!`2 Du schnappst dir ".$gold." Gold von Jirok.");
$user[gold]+=$gold;
addnav("Zur�ck",$infos['file']);
$session['try']=0;
}else{
addnav("Weiter","".$infos['file']."?op=11");
}
}

if($_GET[op]==2){
output("`2Du w�hlst Kolop aus. Ihr setzt euch an einen Tisch, legt einen eurer Arme auf den Tisch und beginnt.");
output("`n`n`2Aktueller Status:");
output("`n".grafbar(200,100,100,20)."",true);
addnav("Weiter","".$infos['file']."?op=21");
}
if($_GET[op]==21){
$rand=e_rand(1,200);
$session['try']++;
$try=$session['try'];
output("`2Du versuchst wie Wild den Arm von Kolop auf den Tisch zu schmettern.");
output("`n`n`2Aktueller Status:");
output("`n".grafbar(200,$rand,100,20)."",true);
if($rand<=25){
output("`n`2Du hast in ".$try." Z�gen `4VERLOREN!`2 Kolop verlangt ".$gold2." Gold von dir.");
if ($user['gold'] >=$gold2){
$user[gold]-=$gold2;
} else {
$user[goldinbank]-=$gold2;
output("`n`2Da du nicht genug bei dir hast wurde der Betrag von deinem Konto abgezogen..");
}
addnav("Zur�ck",$infos['file']);
$session['try']=0;
}else if($rand>=175){
if ($gewinn1 >=2500){
$gold=2500;
} else {
$gold =$gewinn2;
}
$user[gold]+=$gold;
output("`n`2Du hast in ".$try." Z�gen `4GEWONNEN!`2 Du schnappst dir ".$gold." Gold von Kolop.");
addnav("Zur�ck",$infos['file']);
$session['try']=0;
}else{
addnav("Weiter","".$infos['file']."?op=21");
}
}

if($_GET[op]==3){
output("`2Du w�hlst Faler aus. Ihr setzt euch an einen Tisch, legt einen eurer Arme auf den Tisch und beginnt.");
output("`n`n`2Aktueller Status:");
output("`n".grafbar(300,150,100,20)."",true);
addnav("Weiter","".$infos['file']."?op=31");
}
if($_GET[op]==31){
$rand=e_rand(1,300);
$session['try']++;
$try=$session['try'];
output("`2Du versuchst wie Wild den Arm von Faler auf den Tisch zu schmettern.");
output("`n`n`2Aktueller Status:");
output("`n".grafbar(300,$rand,100,20)."",true);
if($rand<=50){
output("`n`2Du hast in ".$try." Z�gen `4VERLOREN!`2 Faler verlangt ".$gold3." Gold von dir.");
if ($user['gold'] >=$gold3){
$user[gold]-=$gold3;
} else {
$user[goldinbank]-=$gold3;
output("`n`2Da du nicht genug bei dir hast wurde der Betrag von deinem Konto abgezogen..");
}
$session['try']=0;
addnav("Zur�ck",$infos['file']);
}else if($rand>=275){
if ($gewinn1 >=5000){
$gold=5000;
} else {
$gold =$gewinn3;
}
$user[gold]+=$gold;
output("`n`2Du hast in ".$try." Z�gen `4GEWONNEN!`2 Du schnappst dir ".$gold." Gold von Faler.");
addnav("Zur�ck",$infos['file']);
$session['try']=0;
}else{
addnav("Weiter","".$infos['file']."?op=31");
}
}
if($_GET[op]==info){
output("`c`b`#Die heutige Quote f�r ".$session[user][name]."`b`n`n`n");
output("`6Dein gesamt Verm�gen betr�gt `$$vermoegen `6Goldst�cke`n`n");
if ($gewinn1 >=1000){
output("`6Quote gegen `b`%Jirok`b`n`6--->Verlust: `!".$gold1."`6 Goldst�cke<---`n--->Gewinn: `@1000 `6Goldst�cke<---`n`n");
} else {
output("`6Quote gegen `b`%Jirok`b`n`6--->Verlust: `!".$gold1."`6 Goldst�cke<---`n--->Gewinn: `@".$gewinn1." `6Goldst�cke<---`n`n");
}
if ($gewinn2 >=2500){
output("`6Quote gegen `b`QKolop`b`n`6--->Verlust: `!".$gold2."`6 Goldst�cke<---`n--->Gewinn: `@2500 `6Goldst�cke<---`n`n");
} else {
output("`6Quote gegen `b`QKolop`b`n`6--->Verlust: `!".$gold2."`6 Goldst�cke<---`n--->Gewinn: `@".$gewinn2." `6Goldst�cke<---`n`n");
}
if ($gewinn3 >=5000){
output("`6Quote gegen `b`gFaler`b`n`6--->Verlust: `!".$gold3."`6 Goldst�cke<---`n--->Gewinn: `@5000 `6Goldst�cke<---`n`n");
} else {
output("`6Quote gegen `b`gFaler`b`n`6--->Verlust: `!".$gold3."`6 Goldst�cke<---`n--->Gewinn: `@".$gewinn3." `6Goldst�cke<---`c`n`n");
}
addnav("Zur�ck",$infos['file']);
}
//copyright
output("`n`n`n`n`n `^".$infos['owner']."`2 by <a href='".$infos['homepage']."' target='_blank'>".$infos['creator']."</a> `2 Edit by <a href='".$infos['homepage-editor']."' target='_blank'>".$infos['editor']."</a> Version ".$infos['version']."`n`n",true);
page_footer();
?>