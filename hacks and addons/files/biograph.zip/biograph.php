<?php

// Coded by Taikun. www.logd-midgar.de

/*
INSERT INTO `bio` (`acctid`,`login`,`name`,`bio`, `avatar`)
    SELECT `acctid`,`login`,`name`, `bio`,`avatar` FROM `accounts` WHERE acctid='3626'
 */
 require_once "common.php";
 page_header("Biographien");
 addnav("Ins Dorf","village.php");
  if($_GET['op']==""){
	$res1 = db_query("SELECT * FROM `bio` WHERE acctid='".$session['user']['acctid']."'");
	  $row1 = db_fetch_assoc($res1);
	 output("Bitte w�hle die gew�nschte Aktion aus!`n`n");
	 
	   output("<a href='biograph.php?op=1&id=$row1[acctid]'>Bio editieren</a>",true);
        addnav("","biograph.php?op=1&id=$row1[acctid]");    
	 addnav("Deine Bio anschauen","bio.php?char=".$row1[login]."");
if ($session['user']['acctid']!=$row1[acctid]){
	
	$sql10 = "INSERT INTO bio (acctid,login) VALUES ('".$session[user][acctid]."','".$session[user][login]."')";
         $result10 = db_query($sql10) or die(db_error(LINK));
	
}
	  
}	  
	  
 if($_GET['op']=="1"){
	
	 
    $res = db_query("SELECT * FROM `bio` WHERE `acctid`='".$_GET['id']."'");
    $row = db_fetch_assoc($res);

	
output("<form action='biograph.php?op=2&id=$_GET[id]' method='POST'>", true);  
$maxbio = getsetting("maxbio", 255);
    $form=array(

        "bio"=>"Kurzbeschreibung des Charakters `n(Maximal {$maxbio} Zeichen),textarea,80,40,$maxbio",
        "avatar"=>"Link auf einen Avatar`n(Bilddatei - maximal 200x200 Pixel)`n"


    );
    



    $prefs['bio'] = $row['bio'];
    $prefs['avatar'] = $row['avatar'];
    showform($form,$prefs);
    output("</form>", true); 	
    addnav("", "biograph.php?op=2&id=".$_GET[id]);  
}   
   if($_GET['op']=="2"){  
	   
	   
	   
     $bio = mysql_real_escape_string(stripslashes($_POST['bio']));
        $avatar = mysql_real_escape_string(stripslashes($_POST['avatar']));
        db_query("UPDATE bio SET avatar='$avatar', bio='$bio' WHERE acctid='".$_GET['id']."'");


        redirect("biograph.php"); 
}
   page_footer();
?>