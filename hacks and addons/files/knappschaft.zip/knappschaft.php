<?php
/**
* _______________________________________________
* | knappschaft.php: Knappen f�r Jedermann      |
* |                                             |
* |    !!! WICHTIG !!!  VORAUSSETZUNG !!!       |
* |  LoGD 0.9.7 ext. Dragonslayer Edition 2.5   |
* |                                             |
* | hiermit soll es jedem m�glich sein, einen   |
* | Knappen zu kaufen, trainieren, umbenennen   |
* | verkaufen oder seine Runden zu erh�hen      |
* |                                             |
* | �2009 by Liath www.germany-project.de/logd  |
* | programmiert in der LoGD DragonSlayer 2.5   |
* |                                             |
* | fertiggestellt:                             |
* | am 05. Februar 2009 um 14�� Uhr             |
* |                                             |
* | Benutzung, Ver�nderungen, Versch�nerungen,  |
* | oder auch eigene Anpassungen sind erlaubt,  |
* | solange dieser Header beibehalten wird und  |
* | die Datei im Source offen gehalten wird.    |
* |                                             |
* | Changelog:                                  |
* |                                             |
* | 06.02.09 Danke an Salator f�r die Hinweise  |
* | Einbau, das Namensl�nge gepr�ft wird        |
* | Namen werden gefiltert (add/stripslash)     |
* | Einbau f�r Trainingsmaximum                 |
* | Knappe kann nun wieder hergestellt werden   |
* | Alte unn�tig SQL-Abfrage entfernt           |
* | Eingabeformulare abge�ndert                 |
* |                                             |
* �����������������������������������������������
* 
* Eigene Ver�nderungen d�rfen ab hier
* gekennzeichnet werden:
* _______________________________________________ 
* | Author:                                     |
* | Changed:                                    |
* | Date:                                       |
* �����������������������������������������������
* 
**/

/**
* _______________________________________________ 
* | Einbauanleitung f�r die Dragonslayer 2.5    |
* |                                             |
* | Diese Datei ist auf die Insel Necron        |
* | ausgelegt, solltest Du diese Insel nicht    |
* | bei Dir haben oder m�chtest diese Datei     |
* | an einem anderen Ort einf�gen, brauchst     |
* | Du nur Die Variable "$dorf" an den Ort      |
* | Deiner Wahl anzupassen und die Datei dort   |
* | zu verlinken wo Du es hinhaben m�chtest:    |
* |                                             |
* | addnav("Knappschaft","knappschaft.php");    |
* |                                             |
* | danach die Datei in den Rootpath von Deinem |
* | LoGD kopieren, �nderungen speichern, fertig |
* �����������������������������������������������
*/

require_once('common.php');
require_once(LIB_PATH.'disciples.lib.php');

page_header('die Knappschaft');

// Einstellung f�r den Backlink
$dorf = 'necron.php';
$ortname = 'zur�ck nach Necron';

// Einstellungen f�r die Knappen
# Level 5
$k1_gold = 100000;
$k1_gems = 25;
$k1_level = 5;
# Level 10
$k2_gold = 150000;
$k2_gems = 35;
$k2_level = 10;
# Level 15
$k3_gold = 200000;
$k3_gems = 50;
$k3_level = 15;
# Level 20
$k4_gold = 500000;
$k4_gems = 75;
$k4_level = 20;

// Bestimmung des Accountnamens, der Anrede und des Geschlechts
$u = $session['user'];
$anr = ($u['sex']?"`#Teure`y":"`#Teuerster`y");
$name = $u['name'];

// Abfrage der Datenbank nach existierendem Knappen
$sql = "SELECT name,state,oldstate,level FROM disciples WHERE master=".$u['acctid']."";
$result = db_query($sql) or die(db_error(LINK));
$row = db_fetch_assoc($result);

// Bestimmung der Daten des Knappen und der maximalen Namensl�nge
$klevel = $row['level'];
$kmaster = $row['master'];
$kname = $row['name'];
$kstate = get_disciple_stat($row['state']);
$kostate = get_disciple_stat($row['oldstate']);
$klen = 25;

// Bestimmung des Restwertes des Knappen
$kgold = round(((200000 * $klevel) / 50),0);   
$kgems = round(((50 * $klevel) / 50),0);

// Kosten f�r die Suche berechnen
$sgold = round(((250000 * $klevel) / 25),0);   
$sgems = round(((100 * $klevel) / 25),0);

// Kosten f�r das Training berechnen und maximaler Level
$tgold = round(((250000 * $klevel) / 50),0);   
$tgems = round(((100 * $klevel) / 50),0);
$tlevel = 45;

// Kosten f�r die Regenerierung berechnen
$rlevel = $session['bufflist']['decbuff']['rounds'];
$rgold = round(((250000 * $klevel) / 75),0);   
$rgems = round(((100 * $klevel) / 75),0);
// Einstellungen Ende

// Ausgabetext bei betreten der Knappschaft
output("`c`y�ber der T�r h�ngt ein grosses Schild,`n`n`b`4Knappschaft, wir trainieren die besten Knappen im Land.`y`b`n Gegen einen Entsch�digungsaufwand
        k�nnen Sie bei uns die besten Knappen erwerben.`n`n
");

// Das anzuzeigende Bild wird bestimmt
$img_knapp = './images/knappschaft.jpg';

// Es wird �berpr�ft ob das Bild existiert, wenn ja angezeigt
if (is_file($img_knapp)) { output('<div align="center"><img border="0" src="'.$img_knapp.'" alt="die Knappschaft"></div>`n`n'); }

if ($_GET['op']=="") {
    if (db_num_rows($result)>0) {
        
        // Abfrage nach Status des Knappen
        if ($row['state']>=1) {
            
            // Textausgabe falls Knappe schon vorhanden
            output("`n`n`cDu h�rst Schritte hinter Dir`nAaaah seid mir gegr�sst ".$anr." ".$name.", womit kann ich Ihnen dienen, wie ich sehe haben Sie bereits einen Knappen.
                    `wIch hoffe Dir ist es gut ergangen `d".$kname."`w, `wDu machst einen `d".$kstate." `wEindruck und hast ja mittlerweile schon Stufe `d".$klevel."`w erreicht. `yEr war einer meiner
                    liebsten Sch�ler m�ssen Sie wissen, ich erinner mich noch an einen `d".$kostate." `ySch�ler der er damals war.`n`nSie k�nnen nicht mehr wie einen Knappen 
                    besitzen. Oder m�chten Sie Ihren Knappen bei uns ins Training geben?`n`n Der Meister �berlegt kurz und meint darauf. Ich w�rde Ihnen f�r 
                    Ihren Aufwand `g".$kgold."`y Gold und `g".$kgems."`y Edelsteine anbieten, m�chten Sie Ihren Knappen wieder an uns verkaufen?
            ");
        
            // Einf�gen der Navigation falls Knappe schon vorhanden    
            addnav("Dein Knappe");            
            addnav("Verkaufen","knappschaft.php?op=sell");
            addnav("Umtaufen","knappschaft.php?op=rename");
            addnav("Trainieren","knappschaft.php?op=train");
            addnav("Aufbauen","knappschaft.php?op=kur");
            addnav("Verlassen");
            addnav("$ortname","$dorf");
        }
        else {
            
            // Textausgabe falls Knappe schon vorhanden
            output("`n`n`cDu h�rst Schritte hinter Dir`nAaaah seid mir gegr�sst ".$anr." ".$name.", womit kann ich Ihnen dienen, in Ihren Diensten steht ja bereits ein Knappe.
                    aber ich kann ihn nirgends sehen. Ist ".$kname." etwa... Nein das kann ich mir nicht vorstellen, er war doch immer in so guter Sch�ler. Lassen Sie uns mal
                    schauen ob wir etwas tun k�nnen. Das wird allerdings nicht billig m�ssen Sie wissen. Das ganze wird Sie ".$sgold." Gold und ".$sgems." Edelsteine kosten.
            ");
        
            // Einf�gen der Navigation falls Knappe tot ist    
            addnav("Dein Knappe");            
            addnav("Suchen","knappschaft.php?op=search");
            addnav("Verlassen");
            addnav("$ortname","$dorf");
        }    
    }
    else {
        
        // Textausgabe falls noch kein Knappe vorhanden ist
        output("`n`n`cDu h�rst Schritte hinter Dir`nAaaah seid mir gegr�sst ".$anr." ".$name.", womit kann ich Ihnen dienen, wie ich sehe habt Ihr noch keinen Knappen... ich hab hier ein paar sehr gute Sch�ler, 
                Wollen Sie einen gegen einen geringen Entsch�digungsaufwand f�r das viele Training bei uns erwerben? Schauen Sie sich ruhig um und sagen Sie mir Bescheid, wenn Sie sich entschieden
                haben stehe ich Ihnen gerne zur Verf�gung. Aber z�gern Sie nicht zu lang, unsere Knappen sind die bestrainiertesten des ganzen Landes und dementsprechend gefragt.
        ");
        
        // Einf�gen der generellen Navigation
        addnav("Knappen");
        addnav("Knappen kaufen","knappschaft.php?op=buy");        
        addnav("Verlassen");
        addnav("$ortname","$dorf");
    }    
}
else if ($_GET['op']=="search") {
    // Textausgabe falls noch kein Knappe vorhanden ist
    output("`n`n`Der Meister verschwindet f�r kurze Zeit, w�hrend Du wartest schaust Du den anderen beim Training zu. Nach einer Weile kommt der Meister wieder und meint.
            Also ".$anr." ".$name." Ich habe Ihren Knappen gefunden und Ihn f�r Sie zur�ckgeholt, bitte passen Sie das n�chste mal besser auf ihn auf.
    ");
    
    // Abzug der Bezahlung f�r die Suche
    $session['user']['gold']+=$sgold;
    $session['user']['gems']+=$sgems;
    
    // Wiederherstellen des Status und eintragen in Bufflist
    $kbuff = array("startmsg"=>"`n`^Dein Knappe freut sich bei Dir zu sein.`&`n`n"
                            ,"name"=>"$kname `y"
                            ,"rounds"=>500
                            ,"minioncount"=>1
                            ,"defmod"=>1.25
                            ,"atkmod"=>1.25
                            ,"minbadguydamage"=>round($session['user']['level'])
                            ,"maxbadguydamage"=>round($session['user']['level']*2)
                            ,"effectmsg"=>"`yDein Knappe richtet`g {badguy} `ymit `4{damage} `ySchadenspunkten �bel zu."
                            ,"wearoff"=>"Dein Knappe zieht sich zur Meditation zur�ck"
                            ,"activate"=>"roundstart");
                            
    $session['bufflist']['decbuff'] = $kbuff;
    $sql = "UPDATE disciples SET state=".$row['oldstate']." WHERE master=".$u['acctid']."";
    db_query($sql);
    
    // Einf�gen der Navigation ob Knappe verkauft werden soll
    addnav("Wege");
    addnav("zur�ck zur Knappschaft","knappschaft.php");
    addnav("$ortname","$dorf");
}

else if ($_GET['op']=="sell") {
    if ($_GET['act']=="") {
        
        // Textausgabe ob Knappe verkauft werden soll
        output("Wollen Sie wirklich Ihren Knappen verkaufen? `d".$row['name']."`y war immer ein sehr guter Sch�ler und ist ja mittlerweile auch auf Level `d".$klevel."`y aufgestiegen.
                Sie sollten sich Ihren Scritt wirklich noch einmal gut �berlegen ".$anr." ".$name.", aber wie gesagt. Ich gebe Ihnen`g ".$kgold." `yGold und`g ".$kgems." `yEdelsteine f�r Ihren Knappen.`n`n`n`n
        ");
        
        // Einf�gen der Navigation ob Knappe verkauft werden soll
        addnav("Verkaufen?");
        addnav("Ja","knappschaft.php?op=sell&act=ja");
        addnav("Nein","knappschaft.php?op=sell&act=nein");
        addnav("Wege");
        addnav("zur�ck zur Knappschaft","knappschaft.php");
        addnav("$ortname","$dorf");
        
    }
    else if ($_GET['act']=="ja") {
        
        // Textausgabe das Knappe verkauft wurde
        output("Ich bedauere es sehr, da� Sie mit unserem Sch�ler nicht zufrieden waren, wir werden ihn umgehend wieder ins Training schicken. Nat�rlich bekommen sie auch das Gold und die Edelsteine
                die ich Ihnen zugesichert habe. Ich hoffe dennoch Sie bald wieder als unseren Gast begr�ssen zu d�rfen ".$anr." ".$name.".`n`n`n`n
        ");
        
        // Hinzurechnen des Restwertes
        $session['user']['gold']+=$kgold;
        $session['user']['gems']+=$kgems;
        
        // L�schen des Knappen aus der Datenbank
        unset($session['bufflist']['decbuff']);
        $sql="DELETE FROM disciples WHERE master=".$u['acctid'];
        db_query($sql);
        
        // Einf�gen der Navigation
        addnav("Wege");
        addnav("zur�ck zur Knappschaft","knappschaft.php");
        addnav("$ortname","$dorf");
    }
    else if ($_GET['act']=="nein") {
        
        // Textausgabe das Knappe nicht verkauft wurde
        output("Aaah ".$anr." ".$name.", ich wusste Sie w�rden es sich anders �berlegen. Einen besseren Knappen werden Sie nirgends anders finden`n`n`n`n");

        // Einf�gen der Navigation
        addnav("Wege");
        addnav("zur�ck zur Knappschaft","knappschaft.php");
        addnav("$ortname","$dorf");
    }    
}
else if ($_GET['op']=="rename") {
    if ($_GET['act']=="") {
        
        // Textausgabe f�r die Umbenennung des Knappen
        output("Es freut mich Sie wiederzusehen ".$anr." ".$name.", Sie m�chten Ihrem Knappen einen neuen Namen geben?
                W�hlen Sie den Namen sorgf�ltig aus, eine Eintragung in das Einwohnerbuch wird sich vom Staat teuer bezahlen
                lassen. Zur Zeit kostet die Eintragung 2500 Gold und 5 Edelsteine. Wenn Sie m�chten w�hlen Sie jetzt einen
                neuen Namen f�r Ihren Knappen.
        ");
        
        // Hinzuf�gen der Navigation ob Knappe umbenannt werden soll
        addnav("umbenennen?");
        addnav("Ja","knappschaft.php?op=rename&act=ja");
        addnav("Nein","knappschaft.php?op=rename&act=nein");
        addnav("Wege");
        addnav("zur�ck zur Knappschaft","knappschaft.php");
        addnav("$ortname","$dorf");
    }
    else if ($_GET['act']=="ja") {
        if ($u['gold']>=2500 && $u['gems']>=5) {
            
            // Textausgabe das Knappe umbenannt wird
            output("Nun gut ".$anr." ".$name.", bitte schreiben Sie den neuen Namen Ihres Knappen in unser Buch, damit wir ihn
                    im Dorfamt auf den neuen Namen taufen lassen k�nnen. Die Unkosten hinterlassen Sie dann bitte am Ausgang.
                    Wir werden alle Formalit�ten f�r Sie erledigen`n`n
            ");
            
            // Namenseingabefeld wird erstellt
            output("<form action='knappschaft.php?op=rename&act=done' method='POST'>`n`n`wDein Knappe heisst derzeit`d ".$kname."`w`n`n",true);
            output("`wWelchen Namen soll er nun tragen? <input id='rename' name='name' size='25' maxlength='".$klen."'> <input type='submit' class='button' value='Umbenennen'>`n`n</form>",true);
            output("<script language='javascript'>document.getElementById('rename').focus();</script>",true);
            addnav("","knappschaft.php?op=rename&act=done");
            
            // Einf�gen der Navigation
            addnav("Wege");
            addnav("zur�ck zur Knappschaft","knappschaft.php");
            addnav("$ortname","$dorf");
        }
        else {
                    
            // Textausgabe das Knappe mangels Deckung nicht umbenannt wurde
            output("Nun gut ".$anr." ".$name.", wenn Sie Ihren Knappen umbenennen wollen, m�ssen Sie schon daf�r sorgen, da�
                    auch das Dorfamt daf�r bezahlt wird. Wir k�nnen die Kosten nicht aus unserer Tasche f�r Sie bezahlen.
            ");
        
            // Einf�gen der Navigation     
            addnav("Wege");
            addnav("zur�ck zur Knappschaft","knappschaft.php");
            addnav("$ortname","$dorf");
        }    
    }
    else if ($_GET['act']=="done") {
        // Abfrage ob Name eingetragen wurde
        if ($_POST['name']) {
                                         
            // Name wird gespeichert
            $newname=addslashes(stripslashes($_POST['name']));
            
            // Abfrage ob Name Zeichenl�nge �berschreitet
            if(strlen($newname)<=$klen) {            
                // Textausgabe das der Name ge�ndert wurde
                output("Nun gut, ".$anr." ".$name." Ihr Knappe ".$kname." ist von nun an unter dem Namen ".$newname." bekannt, sollten
                        Sie irgendwann mit diesem Namen nicht mehr zufrieden sein, helfen wir Ihnen nat�rlich gerne weiter.
                        ");
             
                // Name wird in der Datenbank und in den Buffs ge�ndert
                $session['bufflist']['decbuff']['name']='`%Knappe '.$newname.' `& ->Lvl '.$klevel.'`0';            
                $sql = "UPDATE disciples SET name='$newname' WHERE master=".$session['user']['acctid']."";
                db_query($sql);
         
                // Bezahlung abziehen
                $session['user']['gold']-=2500;
                $session['user']['gems']-=5;
         
                // Navigation hinzuf�gen     
                addnav("Wege");
                addnav("zur�ck zur Knappschaft","knappschaft.php");
                addnav("$ortname","$dorf");
            }
            else {
                // Textausgabe weil Name zu lang ist
                output("Nun gut, ".$anr." ".$name." Ihr Knappe ".$kname." kann diesen Namen leider nicht annehmen, das Dorfamt verbietet so lange
                        Namen, sollten Sie sich einen anderen ausgesucht haben, kommen Sie bitte wieder und wir k�mmern uns um den Rest.
                ");
            
                // Navigation hinzuf�gen     
                addnav("Wege");
                addnav("zur�ck zur Knappschaft","knappschaft.php");
                addnav("$ortname","$dorf");
            }
        }
        else {
            
            // Textausgabe das kein Name eingetragen wurde
            output("Nun gut, ".$anr." ".$name." Ihr Knappe ".$kname." kann nicht ohne Namen in unserer Welt leben, Sie sollten ihm schon einen
                    ansprechenden Namen geben. Es sei denn Sie m�chten das er seinen alten Namen beibeh�lt. Dann schauen wir ob wir noch etwas
                    anderes f�r Sie tun k�nnen.
            ");
            
            // Navigation hinzuf�gen     
            addnav("Wege");
            addnav("zur�ck zur Knappschaft","knappschaft.php");
            addnav("$ortname","$dorf");    
        }
    }
    else if ($_GET['act']=="nein") {
        
        // Ausgabetext Name wurde nicht ge�ndert
        output("Nun gut ".$anr." ".$name.", nat�rlich entscheiden Sie selbst ob Ihr Knappe einen neuen Namen tragen soll, sollten Sie
                mit dem alten Namen nicht mehr zufrieden sein, k�nnen Sie uns jederzeit wieder besuchen. Wir k�mmern uns dann um seine Namens�nderung.
        ");
        
        // Navigation hinzuf�gen
        addnav("Wege");
        addnav("zur�ck zur Knappschaft","knappschaft.php");
        addnav("$ortname","$dorf");   
    }
}
else if ($_GET['op']=="train") {
    if ($_GET['act']=="") {
        
        // Abfrage des Level um zu hohes Training zu verhindern
        if ($klevel==$tlevel) {
            
            // Ausgabetext Knappe darf nicht mehr trainieren       
            output("`yEs freut mich Sie wiederzusehen `g".$anr." ".$name.", `ySie m�chten Ihren Knappen also etwas trainieren lassen?
                    Aber da `d".$kname."`y bereits auf Level `d".$tlevel."`y ist, k�nnen wir ihm leider nichts mehr beibringen. Es tut
                    mit leid, aber noch h�her k�nnen wir ihn nicht trainieren. 
                    ");
        
            // Navigation hinzuf�gen
            addnav("Wege");
            addnav("zur�ck zur Knappschaft","knappschaft.php");
            addnav("$ortname","$dorf");        
        }
        // Knappe darf noch trainieren
        else {        
            // Ausgabetext f�r zu absolvierendes Training       
            output("Es freut mich Sie wiederzusehen ".$anr." ".$name.", Sie m�chten Ihren Knappen also etwas trainieren lassen?
                    F�r eine kleine Spende in H�he von ".$tgold." Gold und ".$tgems." Edelsteinen d�rfte das kein Problem sein
                    ");
        
            // Navigation hinzuf�gen
            addnav("Trainieren?");
            addnav("Ja","knappschaft.php?op=train&act=ja");
            addnav("Nein","knappschaft.php?op=train&act=nein");
            addnav("Wege");
            addnav("zur�ck zur Knappschaft","knappschaft.php");
            addnav("$ortname","$dorf");
        }
    }
    else if ($_GET['act']=="ja") {
        if ($u['gold']>=$tgold && $u['gems']>=$tgems) {
            
            // Knappen Level aufsteigen lassen
            $newlevel=(int)($row['level']+1);
            $session['bufflist']['decbuff']['name']='`%Knappe '.$kname.' `& ->Lvl '.$newlevel.'`0';
            $session['bufflist']['decbuff']['rounds']=$session['bufflist']['decbuff']['rounds']-10;
            
            $sql = "UPDATE disciples SET level=".$newlevel." WHERE master=".$u['acctid']."";
            db_query($sql);
            
            // Text nach dem Training
            output("Nun gut ".$anr." ".$name.", wir werden `d".$kname."`y in unser Training integrieren. Durch das Training hat Ihr Knappe
                    jetzt Level ".$newlevel.", sollten Sie weitere Trainingseinheiten ben�tigen sagen Sie Bescheid. Die kleine Spende f�r das 
                    Trainig hinterlegen Sie bitte am Ausgang.
            ");
            
            // Bezahlung abziehen
            $session['user']['gold']-=$tgold;
            $session['user']['gems']-=$tgems;
            
            // Navigation hinzuf�gen
            addnav("Wege");
            addnav("zur�ck zur Knappschaft","knappschaft.php");
            addnav("$ortname","$dorf");
        }
        else {
            
            // Ausgabetext das nicht die n�tigen Mittel vorhanden sind
            output("Nun gut ".$anr." ".$name.", bitte kommen Sie wieder wenn Sie bereit sind die kleine Spende von ".$tgold." Gold und ".$tgems." Edelsteinen
                    zu entrichten, auch wir m�ssen von etwas leben und haben nichts zu verschenken. Solange Sie nicht genug Gold oder Edelsteine
                    dabei haben, nehmen Sie Ihren Knappen bitte wieder mit
            ");
            
            // Navigation hinzuf�gen
            addnav("Wege");
            addnav("zur�ck zur Knappschaft","knappschaft.php");
            addnav("$ortname","$dorf");
        }
    }
    else if ($_GET['act']=="nein") {
        
        // Ausgabetext das nicht trainiert wurde
        output("Nun gut ".$anr." ".$name.", nat�rlich entscheiden Sie selbst ob Ihr Knappe trainieren soll oder nicht, nur bedenken Sie auch die
                Vorteile die Ihnen ein gut ausgebildeter Knappe bringt. Es lauern viele Gefahren draussen auf Sie. Drum sollten Sie einen starken
                Begleiter an Ihrer Seite nicht untersch�tzen.
        ");
        
        // Navigation hinzuf�gen
        addnav("Wege");
        addnav("zur�ck zur Knappschaft","knappschaft.php");
        addnav("$ortname","$dorf");   
    }
}
else if ($_GET['op']=="kur") {
    if ($_GET['act']=="") {
        
        // Ausgabetext f�r Regeneration       
        output("Es freut mich Sie wiederzusehen ".$anr." ".$name.", Sie m�chten Ihren Knappen also einer Kur unterziehen?
                Derzeit k�nnte Ihr Knappe noch f�r ".$rlevel." Runden an Ihrer Seite k�mpfen, nun m�ssen Sie entscheiden.
                F�r eine kleine Spende in H�he von ".$rgold." Gold und ".$rgems." Edelsteinen d�rfte das kein Problem sein
        ");
        
        // Navigation hinzuf�gen
        addnav("Ausruhen?");
        addnav("Ja","knappschaft.php?op=kur&act=ja");
        addnav("Nein","knappschaft.php?op=kur&act=nein");
        addnav("Wege");
        addnav("zur�ck zur Knappschaft","knappschaft.php");
        addnav("$ortname","$dorf");
    }
    else if ($_GET['act']=="ja") {
        if ($u['gold']>=$rgold && $u['gems']>=$rgems) {
            
            // Knappen Runden aufsteigen lassen
            $session['bufflist']['decbuff']['rounds']=500;
            
            // Text nach der Kur
            output("Nun gut ".$anr." ".$name.", wir werden `d".$kname."`y in unsere Kuranlage verlegen. Durch die Therapie kann Ihr Knappe
                    jetzt wieder `d500 Runden`y an Ihrer Seite k�mpfen, sollten Sie weitere Regenerationseinheiten ben�tigen sagen Sie 
                    Bescheid. Die kleine Spende f�r die Kur hinterlegen Sie bitte am Ausgang.
            ");
            
            // Bezahlung abziehen
            $session['user']['gold']-=$rgold;
            $session['user']['gems']-=$rgems;
            
            // Navigation hinzuf�gen
            addnav("Wege");
            addnav("zur�ck zur Knappschaft","knappschaft.php");
            addnav("$ortname","$dorf");
        }
        else {
            
            // Ausgabetext das nicht die n�tigen Mittel vorhanden sind
            output("Nun gut ".$anr." ".$name.", bitte kommen Sie wieder wenn Sie bereit sind die kleine Spende von ".$rgold." Gold und ".$rgems." Edelsteinen
                    zu entrichten, auch wir m�ssen von etwas leben und haben nichts zu verschenken. Solange Sie nicht genug Gold oder Edelsteine
                    dabei haben, nehmen Sie Ihren Knappen bitte wieder mit
            ");
            
            // Navigation hinzuf�gen
            addnav("Wege");
            addnav("zur�ck zur Knappschaft","knappschaft.php");
            addnav("$ortname","$dorf");
        }
    }
    else if ($_GET['act']=="nein") {
        
        // Ausgabetext das nicht trainiert wurde
        output("Nun gut ".$anr." ".$name.", nat�rlich entscheiden Sie selbst ob Ihr Knappe regenerieren soll oder nicht, nur bedenken Sie auch die
                Vorteile die Ihnen ein gut erholter Knappe bringt. Es lauern viele Gefahren draussen auf Sie. Drum sollten Sie einen gut erholten
                Begleiter an Ihrer Seite nicht untersch�tzen.
        ");
        
        // Navigation hinzuf�gen
        addnav("Wege");
        addnav("zur�ck zur Knappschaft","knappschaft.php");
        addnav("$ortname","$dorf");   
    }
}
else if ($_GET['op']=="buy") {
    if ($_GET['level']=="") {
        
        // Ausgabetext f�r den Kauf eines Knappen       
        output("Es freut mich Sie wiederzusehen ".$anr." ".$name.", Sie m�chten also einen Knappen bei uns erwerben??
                Derzeit haben wir 4 verschiedene Leistungsstufen in unserem Training, suchen Sie sich einen aus und sagen
                mir dann Bescheid. Ich werde dann direkt nach meinen besten K�mpfern Ausschau halten. �brigens, da wir eine
                Bruderschaft sind, haben wir alle unsere Weltlichen Namen abgelegt. Sie m�ssen Ihrem Knappen also noch einen
                Namen geben.
        ");
        
        // Navigation hinzuf�gen
        addnav("Knappen");
        addnav("Level ".$k1_level."","knappschaft.php?op=buy&level=".$k1_level."");
        addnav("Level ".$k2_level."","knappschaft.php?op=buy&level=".$k2_level."");
        addnav("Level ".$k3_level."","knappschaft.php?op=buy&level=".$k3_level."");
        addnav("Level ".$k4_level."","knappschaft.php?op=buy&level=".$k4_level."");
        addnav("Wege");
        addnav("zur�ck zur Knappschaft","knappschaft.php");
        addnav("$ortname","$dorf");
    }
    else if ($_GET['level']=="select") {
        if ($_POST['name']) {
            
            // Name Knappe
            $knappe=addslashes(stripslashes($_POST['name']));
            
            // Namensl�nge wird gepr�ft
            if(strlen($newname)>$klen) {
                
                // Ausgabetext das Name zu lang ist
                output("Nun gut, ".$anr." ".$name." Ihr Knappe ".$kname." kann diesen Namen leider nicht annehmen, das Dorfamt verbietet so lange
                        Namen, sollten Sie sich einen anderen ausgesucht haben, kommen Sie bitte wieder und wir k�mmern uns um den Rest.
                ");
            
                // Navigation hinzuf�gen     
                addnav("Wege");
                addnav("zur�ck zur Knappschaft","knappschaft.php");
                addnav("$ortname","$dorf");
            }
            // Namensl�nge ist ok Knappe wird gekauft
            else {
                // Neusetzen der Preise und des Level
                if ($_GET['id']=="1") {
                    $gold = $k1_gold;
                    $gems = $k1_gems;
                    $level = $k1_level;
                }
                else if ($_GET['id']=="2") {
                    $gold = $k2_gold;
                    $gems = $k2_gems;
                    $level = $k2_level;
                }
                else if ($_GET['id']=="3") {
                    $gold = $k3_gold;
                    $gems = $k3_gems;
                    $level = $k3_level;
                }    
                else if ($_GET['id']=="4") {
                    $gold = $k4_gold;
                    $gems = $k4_gems;
                    $level = $k4_level;
                }
            
                // Ausgabetext Knappe gekauft
                output("Eine wirklich sehr gute Wahl`y ".$anr." ".$name.", ich versichere Ihnen das ".$knappe." auf Level ".$level." Ihnen immer treu zur Seite stehen
                        wird. Ihre ".$gold." Gold und ".$gems." Edelsteine sind mit Sicherheit gut angelegt. Ich w�rde mich freuen Sie �fters bei
                        uns Willkommen heissen zu k�nnen. Sollten Sie noch eine Frage haben, sagen Sie einfach Bescheid. Ich werde alles in meiner
                        Macht stehende f�r Sie tun. 
                    ");
            
                // Knappe wird erstellt und in die Datenbank eingetragen            
                $sql = "INSERT INTO disciples (name,state,level,master) VALUES ('".$knappe."',4,'$level','".$session['user']['acctid']."')";
                db_query($sql) or die(sql_error($sql));
            
                // Knappe wird in die Bufflist eintragen
                $kbuff = array("startmsg"=>"`n`^Dein Knappe freut sich bei Dir zu sein.`&`n`n"
                            ,"name"=>"$knappe `y"
                            ,"rounds"=>500
                            ,"minioncount"=>1
                            ,"defmod"=>1.25
                            ,"atkmod"=>1.25
                            ,"minbadguydamage"=>round($session['user']['level'])
                            ,"maxbadguydamage"=>round($session['user']['level']*2)
                            ,"effectmsg"=>"`yDein Knappe richtet`g {badguy} `ymit `4{damage} `ySchadenspunkten �bel zu."
                            ,"wearoff"=>"Dein Knappe zieht sich zur Meditation zur�ck"
                            ,"activate"=>"roundstart");
                                        
                $session['bufflist']['decbuff'] = $kbuff;
            
                // Bezahlung abziehen
                $session['user']['gold']-=$gold;
                $session['user']['gems']-=$gems;
            
                // Navigation hinzuf�gen
                addnav("Wege");
                addnav("zur�ck zur Knappschaft","knappschaft.php");
                addnav("$ortname","$dorf");
            }            
        }
        else {
            
            // Ausgabetext das dem Knappen kein Name gegeben wurde
            output("Aber`y ".$anr." ".$name.", Ihr Knappe kann doch nicht Namenlos bleiben. Bitte geben Sie ihm einen Namen.
                    Ohne den k�nnen wir Ihnen leider keinen Knappen verkaufen. Nur wir hier im Orden verzichten auf die Weltliche
                    Anrede, aber da draussen in der Normalen Welt, ist es Unverzichtbar einen eigenen Namen zu haben. 
            ");
            
            // Navigation hinzuf�gen
            addnav("Knappen");
            addnav("Level ".$k1_level."","knappschaft.php?op=buy&level=".$k1_level."");
            addnav("Level ".$k2_level."","knappschaft.php?op=buy&level=".$k2_level."");
            addnav("Level ".$k3_level."","knappschaft.php?op=buy&level=".$k3_level."");
            addnav("Level ".$k4_level."","knappschaft.php?op=buy&level=".$k4_level."");
            addnav("Wege");
            addnav("zur�ck zur Knappschaft","knappschaft.php");
            addnav("$ortname","$dorf");
        }
    }
    else if ($_GET['level']==$k1_level) {
        
        // setzen des Preises und des Levels
        $gold = $k1_gold;
        $gems = $k1_gems;
        $level = $k1_level;
        
        // Kann der Knappe bezahlt werden?
        if ($u['gold']>=$gold && $u['gems']>=$gems) {
            
            // Text f�r Knappen kaufen
            output("Hier habe ich meinen st�rksten K�mpfer in Level `d".$level."`y ".$anr." ".$name.", er ist kerngesund und w�rde sich freuen
                   an Ihrer Seite dienen zu d�rfen. Die Aufwandsentsch�digung w�rde in diesem Fall `d".$gold." `yGold und `d".$gems." `yEdelsteine betragen.
                   Jetzt liegt es an Ihnen ob Sie ihn direkt an Ihre Seite nehmen m�chten. 
            ");
            
            // Namenseingabefeld wird erstellt
            output("<form action='knappschaft.php?op=buy&level=select&id=1' method='POST'>`n`n",true);
            output("`wWelchen Namen soll der Knappe tragen? <input id='buy' name='name' size='25' maxlength='".$klen."'> <input type='submit' class='button' value='Kaufen'>`n`n</form>",true);
            output("<script language='javascript'>document.getElementById('buy').focus();</script>",true);
            addnav("","knappschaft.php?op=buy&level=select&id=1");
            
            // Navigation hinzuf�gen
            addnav("Wege");
            addnav("zur�ck zur Knappschaft","knappschaft.php");
            addnav("$ortname","$dorf");
        }
        
        // Scheinbar kann er nicht bezahlt werden
        else {
            
            // Ausgabetext das nicht die n�tigen Mittel vorhanden sind
            output("Nun gut ".$anr." ".$name.", bitte kommen Sie wieder wenn Sie bereit sind die kleine Spende von ".$gold." Gold und ".$gems." Edelsteinen
                    zu entrichten, auch wir m�ssen von etwas leben und haben nichts zu verschenken. Solange Sie nicht genug Gold oder Edelsteine
                    dabei haben.
            ");
            
            // Navigation hinzuf�gen
            addnav("Wege");
            addnav("zur�ck zur Knappschaft","knappschaft.php");
            addnav("$ortname","$dorf");
        }
    }
    else if ($_GET['level']==$k2_level) {
        
        // setzen des Preises und des Levels
        $gold = $k2_gold;
        $gems = $k2_gems;
        $level = $k2_level;
        
        // Kann der Knappe bezahlt werden?
        if ($u['gold']>=$gold && $u['gems']>=$gems) {
            
            // Text f�r Knappen kaufen
            output("Hier habe ich meinen st�rksten K�mpfer in Level `d".$level."`y ".$anr." ".$name.", er ist kerngesund und w�rde sich freuen
                   an Ihrer Seite dienen zu d�rfen. Die Aufwandsentsch�digung w�rde in diesem Fall `d".$gold." `yGold und `d".$gems." `yEdelsteine betragen.
                   Jetzt liegt es an Ihnen ob Sie ihn direkt an Ihre Seite nehmen m�chten. 
            ");
            
            // Namenseingabefeld wird erstellt
            output("<form action='knappschaft.php?op=buy&level=select&id=2' method='POST'>`n`n",true);
            output("`wWelchen Namen soll der Knappe tragen? <input id='buy' name='name' size='25' maxlength='".$klen."'> <input type='submit' class='button' value='Kaufen'>`n`n</form>",true);
            output("<script language='javascript'>document.getElementById('buy').focus();</script>",true);
            addnav("","knappschaft.php?op=buy&level=select&id=2");
            
            // Navigation hinzuf�gen
            addnav("Wege");
            addnav("zur�ck zur Knappschaft","knappschaft.php");
            addnav("$ortname","$dorf");
        }
        
        // Scheinbar kann er nicht bezahlt werden
        else {
            
            // Ausgabetext das nicht die n�tigen Mittel vorhanden sind
            output("Nun gut ".$anr." ".$name.", bitte kommen Sie wieder wenn Sie bereit sind die kleine Spende von ".$gold." Gold und ".$gems." Edelsteinen
                    zu entrichten, auch wir m�ssen von etwas leben und haben nichts zu verschenken. Solange Sie nicht genug Gold oder Edelsteine
                    dabei haben.
            ");
            
            // Navigation hinzuf�gen
            addnav("Wege");
            addnav("zur�ck zur Knappschaft","knappschaft.php");
            addnav("$ortname","$dorf");
        }
    }
    else if ($_GET['level']==$k3_level) {
        
        // setzen des Preises und des Levels
        $gold = $k3_gold;
        $gems = $k3_gems;
        $level = $k3_level;
        
        // Kann der Knappe bezahlt werden?
        if ($u['gold']>=$gold && $u['gems']>=$gems) {
            
            // Text f�r Knappen kaufen
            output("Hier habe ich meinen st�rksten K�mpfer in Level `d".$level."`y ".$anr." ".$name.", er ist kerngesund und w�rde sich freuen
                   an Ihrer Seite dienen zu d�rfen. Die Aufwandsentsch�digung w�rde in diesem Fall `d".$gold." `yGold und `d".$gems." `yEdelsteine betragen.
                   Jetzt liegt es an Ihnen ob Sie ihn direkt an Ihre Seite nehmen m�chten. 
            ");
            
            // Namenseingabefeld wird erstellt
            output("<form action='knappschaft.php?op=buy&level=select&id=3' method='POST'>`n`n",true);
            output("`wWelchen Namen soll der Knappe tragen? <input id='buy' name='name' size='25' maxlength='".$klen."'> <input type='submit' class='button' value='Kaufen'>`n`n</form>",true);
            output("<script language='javascript'>document.getElementById('buy').focus();</script>",true);
            addnav("","knappschaft.php?op=buy&level=select&id=3");
            
            // Navigation hinzuf�gen
            addnav("Wege");
            addnav("zur�ck zur Knappschaft","knappschaft.php");
            addnav("$ortname","$dorf");
        }
        
        // Scheinbar kann er nicht bezahlt werden
        else {
            
            // Ausgabetext das nicht die n�tigen Mittel vorhanden sind
            output("Nun gut ".$anr." ".$name.", bitte kommen Sie wieder wenn Sie bereit sind die kleine Spende von ".$gold." Gold und ".$gems." Edelsteinen
                    zu entrichten, auch wir m�ssen von etwas leben und haben nichts zu verschenken. Solange Sie nicht genug Gold oder Edelsteine
                    dabei haben.
            ");
            
            // Navigation hinzuf�gen
            addnav("Wege");
            addnav("zur�ck zur Knappschaft","knappschaft.php");
            addnav("$ortname","$dorf");
        }
    }
    else if ($_GET['level']==$k4_level) {
        
        // setzen des Preises und des Levels
        $gold = $k4_gold;
        $gems = $k4_gems;
        $level = $k4_level;
        
        // Kann der Knappe bezahlt werden?
        if ($u['gold']>=$gold && $u['gems']>=$gems) {
            
            // Text f�r Knappen kaufen
            output("Hier habe ich meinen st�rksten K�mpfer in Level `d".$level."`y ".$anr." ".$name.", er ist kerngesund und w�rde sich freuen
                   an Ihrer Seite dienen zu d�rfen. Die Aufwandsentsch�digung w�rde in diesem Fall `d".$gold." `yGold und `d".$gems." `yEdelsteine betragen.
                   Jetzt liegt es an Ihnen ob Sie ihn direkt an Ihre Seite nehmen m�chten. 
            ");
            
            // Namenseingabefeld wird erstellt
            output("<form action='knappschaft.php?op=buy&level=select&id=4' method='POST'>`n`n",true);
            output("`wWelchen Namen soll der Knappe tragen? <input id='buy' name='name' size='25' maxlength='".$klen."'> <input type='submit' class='button' value='Kaufen'>`n`n</form>",true);
            output("<script language='javascript'>document.getElementById('buy').focus();</script>",true);
            addnav("","knappschaft.php?op=buy&level=select&id=4");
            
            // Navigation hinzuf�gen
            addnav("Wege");
            addnav("zur�ck zur Knappschaft","knappschaft.php");
            addnav("$ortname","$dorf");
        }
        
        // Scheinbar kann er nicht bezahlt werden
        else {
            
            // Ausgabetext das nicht die n�tigen Mittel vorhanden sind
            output("Nun gut ".$anr." ".$name.", bitte kommen Sie wieder wenn Sie bereit sind die kleine Spende von ".$gold." Gold und ".$gems." Edelsteinen
                    zu entrichten, auch wir m�ssen von etwas leben und haben nichts zu verschenken. Solange Sie nicht genug Gold oder Edelsteine
                    dabei haben.
            ");
            
            // Navigation hinzuf�gen
            addnav("Wege");
            addnav("zur�ck zur Knappschaft","knappschaft.php");
            addnav("$ortname","$dorf");
        }
    }
}

page_footer();
?>
