<?php

//Script by Jupiter, Hades and Horus

require_once "common.php";
addnav("Labor");
addnav("Trank erstellen","trank.php");
addnav("Wege");
addnav("Zur�ck zum Dorf","village.php");

page_header("Labor");
output("`&`c`bLabor`c`b");
output("`5Du betrittst ein kleines, dunkles Geb�ude, das durch `tFack`qel`^n `5und `&Kerzenli`qch`^t `5in seinem Inneren beleuchtet wird.");
output("`5In einem gro�en `tRegal`5, das im hinteren Teil des Raumes steht, siehst Du viele `7Flaschen `5stehen, die mit Fl��igkeiten gef�llt sind, die alle m�glichen `\$F`2a`%r`qb`^e`vn `5haben und vor dem `tRegal `5eine Art Theke, auf der, in besonderen St�ndern, viele `7Reagenzgl�ser `5stehen.");
output("`5 Auf der rechten Seite des Raumes stehen `tKisten`5, in denen leere `7Flaschen `5liegen und Du �berlegst, ob Du Dir nicht vielleicht einen Trank brauen m�chtest.");
page_footer();
?>