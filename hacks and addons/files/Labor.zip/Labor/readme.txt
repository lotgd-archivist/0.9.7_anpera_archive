*****************************************
*             Skript von		*		 	
*					*
*					*
*	Jupiter, Hades und Horus	*			
*					*
*****************************************



Einfach die Datei labor.php irgendwo im Spiel verlinken. Trankergebnisse sind erweiterbar in erstellen.php 
Texte k�nnen ver�ndert werden, Quelle des Codes jedoch nicht!