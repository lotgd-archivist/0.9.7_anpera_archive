<?
require_once "common.php";

addnav("Trank erstellen");
if($session[user][turns]>0 &&
$session[user][gold]>499 &&
$session[user][gems]>0) {
addnav("Erstellen","erstellen.php");
}
addnav("Wege");
addnav("Zur�ck zum Dorf","village.php");
page_header("Labor");
output("`&`b`cTrank erstellen`c`b");
output("`5 Ein alter `vMann`5, der in einen dunklen `vMantelumhang `5gekleidet ist, kommt auf Dich zu, begr��t Dich und fragt, was Dein Begehren ist");
output("`5 Du gr��t ihn und erkl�rst, da� Du gerne einen Trank brauen w�rdest, wobei er Dich darauf hinweist, da� dies eine Geb�hr von `6500 Gold `5 und `@1 Gem `5kostet.");
page_footer();
?>