<?
require_once "common.php";
addnav("Wege");
addnav("Zur�ck zum Dorf","village.php");
addnav("Zur�ck zum Labor","trank.php");
page_header("Ergebnis");

switch(e_rand(1,12)){

case 1:
$session[user][gold]-=500;
$session[user][gems]-=1;
output("`&`c`bErgebnis`b`c");
output("`%Du nimmst verschiedene `7Flaschen`%, f�llst Fl��igkeit um Fl��igkeit in ein `7Reagenzglas `%und das ganze schlie�lich in eine `7Flasche`%.");
output("`%Schlie�lich hast Du einen hell lilanen Trank zusammen gemischt, den Du direkt trinkst, worauf hin Du Dich gro�artig f�hlst!");
output("`%Du erh�lst `^1 permanenten Lebenspunkt`%!");
($session[user][maxhitpoints]+=1);
break;

case 2:
$session[user][gold]-=500;
$session[user][gems]-=1;
output("`&`c`bErgebnis`b`c");
output("`5Du nimmst verschiedene `7Flaschen`5, f�llst Fl��igkeit um Fl��igkeit in ein `7Reagenzglas `5und das ganze schlie�lich in eine `7Flasche`5.");
output("`5Schlie�lich hast Du einen dunkel lilanen Trank zusammen gemischt, den Du direkt trinkst, worauf hin Du Dich schlecht f�hlst!");
output("`5Du verlierst `^1 permanenten Lebenspunkt`%!");
($session[user][maxhitpoints]-=1);
break;

case 3:
$session[user][gold]-=500;
$session[user][gems]-=1;
output("`&`c`bErgebnis`b`c");
output("`^Du nimmst verschiedene `7Flaschen`^, f�llst Fl��igkeit um Fl��igkeit in ein `7Reagenzglas `^und das ganze schlie�lich in eine `7Flasche`^.");
output("`^Schlie�lich hast Du einen gelben Trank zusammen gemischt, den Du direkt trinkst, worauf hin Du Dich m�de f�hlst!");
output("`^Du verlierst `%1 Waldkampf`^!");
($session[user][turns]-=1);
break;

case 4:
$session[user][gold]-=500;
$session[user][gems]-=1;
output("`&`c`bErgebnis`b`c");
output("`6Du nimmst verschiedene `7Flaschen`6, f�llst Fl��igkeit um Fl��igkeit in ein `7Reagenzglas `6und das ganze schlie�lich in eine `7Flasche`6.");
output("`6Schlie�lich hast Du einen goldfarbenen Trank zusammen gemischt, den Du direkt trinkst, worauf hin Du Dich wach f�hlst!");
output("`6Du gewinnst `^1 Waldkampf`6!");
($session[user][turns]+=1);
break;

case 5:
$session[user][gold]-=500;
$session[user][gems]-=1;
output("`&`c`bErgebnis`b`c");
output("`\$Du nimmst verschiedene `7Flaschen`\$, f�llst Fl��igkeit um Fl��igkeit in ein `7Reagenzglas `\$und das ganze schlie�lich in eine `7Flasche`\$.");
output("`\$Schlie�lich hast Du einen hell roten Trank zusammen gemischt, den Du direkt trinkst, worauf hin Du Dich stark f�hlst!");
output("`\$Du gewinnst `^1 permanenten Angriffspunkt`\$!");
$session[user][attack]++;
break;

case 6:
$session[user][gold]-=500;
$session[user][gems]-=1;
output("`&`c`bErgebnis`b`c");
output("`5Du nimmst verschiedene `7Flaschen`5, f�llst Fl��igkeit um Fl��igkeit in ein `7Reagenzglas `5und das ganze schlie�lich in eine `7Flasche`5.");
output("`5Schlie�lich hast Du einen dunkel roten Trank zusammen gemischt, den Du direkt trinkst, worauf hin Du Dich schwach f�hlst!");
output("`5Du verlierst `^1 permanenten Angriffspunkt`5!");
$session[user][attack]--;
break;

case 7:
$session[user][gold]-=500;
$session[user][gems]-=1;
output("`&`c`bErgebnis`b`c");
output("`#Du nimmst verschiedene `7Flaschen`#, f�llst Fl��igkeit um Fl��igkeit in ein `7Reagenzglas `#und das ganze schlie�lich in eine `7Flasche`#.");
output("`#Schlie�lich hast Du einen hell blauen Trank zusammen gemischt, den Du direkt trinkst, worauf hin Du Dich stark f�hlst!");
output("`#Du gewinnst `^1 permanenten Verteidigungspunkt`#!");
$session[user][defence]++;
break;

case 8:
$session[user][gold]-=500;
$session[user][gems]-=1;
output("`&`c`bErgebnis`b`c");
output("`1Du nimmst verschiedene `7Flaschen`1, f�llst Fl��igkeit um Fl��igkeit in ein `7Reagenzglas `1und das ganze schlie�lich in eine `7Flasche`1.");
output("`1Schlie�lich hast Du einen dunkel blauen Trank zusammen gemischt, den Du direkt trinkst, worauf hin Du Dich schwach f�hlst!");
output("`1Du verlierst `^1 permanenten Verteidigungspunkt`1!");
$session[user][defence]--;
break;

case 9:
$session[user][gold]-=500;
$session[user][gems]-=1;
output("`&`c`bErgebnis`b`c");
output("`9Du nimmst verschiedene `7Flaschen`9, f�llst Fl��igkeit um Fl��igkeit in ein `7Reagenzglas `9und das ganze schlie�lich in eine `7Flasche`9.");
output("`9Schlie�lich hast Du einen mittel blauen Trank zusammen gemischt, den Du direkt trinkst, worauf hin Du Dich schwach und schlecht f�hlst!");
output("`9Du sp�rtst, wie das Leben Deinem K�rper entweicht und stirbst!");
$session['user']['alive']=false; 
$session['user']['hitpoints']=0; 
$session['user']['gold']=0; 
$session['user']['experience']*=0.95;
addnews($session['user']['name']." `9starb langsam an einem selbstgebrauten Trank.`0"); 
addnav("T�gliche News","news.php");
break;

case 10:
$session[user][gold]-=500;
$session[user][gems]-=1;
output("`&`c`bErgebnis`b`c");
output("`7Du nimmst verschiedene `%Flaschen`7, f�llst Fl��igkeit um Fl��igkeit in ein `%Reagenzglas `7und das ganze schlie�lich in eine `%Flasche`7.");
output("`7Schlie�lich hast Du einen hell orangen Trank zusammen gemischt, den Du direkt trinkst, worauf hin Du Dich sch�n f�hlst!");
output("`7Du gewinnst `^10 Gefallen bei Ramius`7!");
$session['user']['deathpower']+=10;
break;

case 11:
$session[user][gold]-=500;
$session[user][gems]-=1;
output("`&`c`bErgebnis`b`c");
output("`qDu nimmst verschiedene `7Flaschen`q, f�llst Fl��igkeit um Fl��igkeit in ein `7Reagenzglas `qund das ganze schlie�lich in eine `7Flasche`q.");
output("`qSchlie�lich hast Du einen hell orangen Trank zusammen gemischt, den Du direkt trinkst, worauf hin Du Dich sch�n f�hlst!");
output("`qDu gewinnst `^1 Charmepunkt`q!");
$session[user][charm]++;
break;

case 12:
$session[user][gold]-=500;
$session[user][gems]-=1;
output("`&`c`bErgebnis`b`c");
output("`QDu nimmst verschiedene `7Flaschen`Q, f�llst Fl��igkeit um Fl��igkeit in ein `7Reagenzglas `Qund das ganze schlie�lich in eine `7Flasche`Q.");
output("`QSchlie�lich hast Du einen hell orangen Trank zusammen gemischt, den Du direkt trinkst, worauf hin Du Dich sch�n f�hlst!");
output("`QDu verlierst `^1 Charmepunkt`Q!");
$session[user][charm]--;
break;
}

page_footer();
?>