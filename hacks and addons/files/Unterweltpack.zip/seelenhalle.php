<? 
//Idee und Umsetzung
//Morpheus aka Apollon 
//2006 f�r www.Morpheus-Lotgd.de.vu(LoGD 0.9.7 +jt ext (GER) 3)
//Mail to Morpheus@magic.ms or Apollon@magic.ms
//gewitmet meiner �ber alles geliebten Blume
require_once "common.php";
addcommentary();
checkday();
page_header("Das Haus der guten Seelen"); 
if ($_GET[op]==""){
	output("`7Du gehst auf eine gro�e H�hle zu und stehst pl�tzlich vor einer T�r, die von 2 m�chtigen Gargoyles bewacht wird und an der ein Schild h�ngt, auf dem Du lesen kannst:`n`n"); 
	output("`n`n`6Zutritt nur f�r ehrenvolle Seelen`n`n");
	if ($session['user']['reputation']<50){
		output("`7Offenbar reicht Dein Ansehen in der Welt nicht aus, um `4Ramius `7zu beeindrucken.`n`n");
	}else{
		output("`7Vielleicht solltest Du mal nachschauen, was `4Ramius `7 da wieder eingefallen ist.`n`n");
	}
	if ($session['user']['reputation']>=50){
		addnav("H?Halle der reinen Seelen","seelenhalle.php?op=ein");
	}
	addnav("Z?Zur�ck zur H�lle","thehell.php");
}
if ($_GET[op]=="ein"){
	output("`\$Du gehst auf die Gargoyles zu, sie mustern Dich kurz und einer �ffnet Dir die T�r in eine andere Welt hier unten in der H�lle, die nur den ehrenhaften Seelen offen steht.");
	output("`7Du kommst in eine gro�e Halle, die mit Marmor verkleidet ist und in der sich ein gro�er Platz befindet, in dessn Mitte eine Statue von `4Ramius `7steht, rund um die Staue kannst Du andere Seelen sehen, die dort wandeln und sich unterhalten.`n");
	output("`7Wie es scheint, hat Ramius seinen Sinn f�r Gesch�fte entdeckt und offeriert hier ganz besonderen Service an alle guten Seelen, der den ehrlosen vorenthalten bleibt.`n`n"); 
	output("`3Du blickst Dich um und kannst verschieden Angebote erkennen, die von Ramius gemacht werden.`n`n");
	viewcommentary("seelenhalle","sagen:`n",25,"sagt");
	addnav("Den irdischen K�rper...");
	addnav("r?...reinigen","seelenhalle.php?op=rein");
	addnav("E?...mit Essen versorgen","seelenhalle.php?op=essen");
	addnav("T?...mit Trinken versorgen","seelenhalle.php?op=trinken");
	addnav("Anderes");
	addnav("S?An der Statue beten","seelenhalle.php?op=beten");
	if ( $session['user']['reputation']>=80){
		addnav("B?Besonders ehrenvolles Gesch�ft","seelenhalle.php?op=ehre");
	}
	if ( $session['user']['reputation']>=100){
		addnav("R?Ramius Segen","seelenhalle.php?op=segen");
	}
	addnav("Z?Zur�ck zur H�lle","thehell.php");
}
if ($_GET[op]=="halle"){ 
	output("`\$Wieder stehst Du in der Halle `7und �berlegst, was Du machen sollst.`n`n");
	viewcommentary("seelenhalle","sagen:`n",25,"sagt");
	addnav("Den irdischen K�rper...");
	addnav("r?...reinigen","seelenhalle.php?op=rein");
	addnav("E?...mit Essen versorgen","seelenhalle.php?op=essen");
	addnav("T?...mit Trinken versorgen","seelenhalle.php?op=trinken");
	addnav("Anderes");
	addnav("S?An der Statue beten","seelenhalle.php?op=beten");
	if ( $session['user']['reputation']>=80){
		addnav("B?Besonders ehrenvolles Gesch�ft","seelenhalle.php?op=ehre");
	}
	if ( $session['user']['reputation']>=100){
		addnav("R?Ramius Segen","seelenhalle.php?op=segen");
	}
	addnav("Z?Zur�ck zur H�lle","thehell.php");
}
if ($_GET[op]=="rein"){
	output("`3Du gehst zu einem Stand, hinter dem ein Gargoyle steht, der in `4Ramius `3Namen hier das Gesch�ft f�hrt.");
	output("`3Das Angebot besteht darin, da� f�r 20 Gefallen daf�r gesorgt wird, das Dein irdischer K�rper, wenn Du wieder in ihn schl�pfst, sauber ist.`n");
	output("`3Grinsend wartet der Gargoyle auf Deine Entscheidung.");
	addnav("K?K�rper reinigen lassen (20 Gefallen)","seelenhalle.php?op=reinig");
	addnav("Z?Zur�ck zur Halle","seelenhalle.php?op=halle");
}
if ($_GET[op]=="reinig"){
	output("`3Du sagst dem Gargoyle, da� Du gerne einen reinen K�rper m�chtest, in den Du wieder schl�pfst.");
	output("`3Er wirft einen Blick in sein Gesch�ftsbuch und");
	if ($session['user']['deathpower']>19){
		output("`3nickt zufrieden:`4\"So sei es, wenn Du wieder in Deinen K�rper schl�pfst, wird er rein sein wie an jedem anderen Tag auch!\"`n`3Mit diesen Worten notiert er etwas in das Buch und die Dinge nehmen ihren Gang.");
		$session['user']['deathpower']-=20;
		$session['user']['clean']=0;
		addnav("Z?Zur�ck zur Halle","seelenhalle.php?op=halle");
	}else{
		output("`3sieht kurz darauf b�se auf:`4\"So, Du glaubst wohl, Du k�nntest Ramius betr�gen?!!\"`n`3Mit diesen Worten schnappt er Dich und verpa�t Dir einen Tritt, der Dich zur T�r bef�rdert, wo Dich die 2 Wachen in Empfang nehmen und vor die T�r setzen.");
		$session['user']['reputation']-=10;
		$session['user']['soulpoints']=0;
		addnav("Z?Zur�ck zur Halle","seelenhalle.php?op=halle");
	}
}
if ($_GET[op]=="essen"){
	output("`3Du gehst zu einem Stand, hinter dem ein Gargoyle steht, der in `4Ramius `3Namen hier das Gesch�ft f�hrt.");
	output("`3Das Angebot besteht darin, da� f�r 100 Gefallen daf�r gesorgt wird, das Dein irdischer K�rper, wenn Du wieder in ihn schl�pfst, mit Essen f�r 1 Tag versorgt wurde.`n");
	output("`3Grinsend wartet der Gargoyle auf Deine Entscheidung.");
	addnav("E?K�rper mit Essen versorgen lassen (100 Gefallen)","seelenhalle.php?op=essenj");
	addnav("Z?Zur�ck zur Halle","seelenhalle.php?op=halle");
}
if ($_GET[op]=="essenj"){
	output("`3Du sagst dem Gargoyle, da� Du gerne Deinen K�rper mit Essen f�r 1 Tag versorgt wissen willst, wenn Du wieder in ihn schl�pfst.");
	output("`3Er wirft einen Blick in sein Gesch�ftsbuch und");
	if ($session['user']['deathpower']>99){
		output("`3nickt zufrieden:`4\"So sei es, wenn Du wieder in Deinen K�rper schl�pfst, wird er mit Essen f�r einen Tag versorgt worden sein!\"`n`3Mit diesen Worten notiert er etwas in das Buch und die Dinge nehmen ihren Gang.");
		$session['user']['deathpower']-=100;
		$session['user']['hungry']+=10;
		addnav("Z?Zur�ck zur Halle","seelenhalle.php?op=halle");
	}else{
		output("`3sieht kurz darauf b�se auf:`4\"So, Du glaubst wohl, Du k�nntest Ramius betr�gen?!!\"`n`3Mit diesen Worten schnappt er Dich und verpa�t Dir einen Tritt, der Dich zur T�r bef�rdert, wo Dich die 2 Wachen in Empfang nehmen und vor die T�r setzen.");
		$session['user']['reputation']-=10;
		$session['user']['soulpoints']=0;
		addnav("Z?Zur�ck zur Halle","seelenhalle.php?op=halle");
	}
}
if ($_GET[op]=="trinken"){
	output("`3Du gehst zu einem Stand, hinter dem ein Gargoyle steht, der in `4Ramius `3Namen hier das Gesch�ft f�hrt.");
	output("`3Das Angebot besteht darin, da� f�r 100 Gefallen daf�r gesorgt wird, das Dein irdischer K�rper, wenn Du wieder in ihn schl�pfst, mit Trinken f�r 1 Tag versorgt wurde.`n");
	output("`3Grinsend wartet der Gargoyle auf Deine Entscheidung.");
	addnav("T?K�rper mit Trinken versorgen lassen (100 Gefallen)","seelenhalle.php?op=trinkenj");
	addnav("Z?Zur�ck zur Halle","seelenhalle.php?op=halle");
}
if ($_GET[op]=="trinkenj"){
	output("`3Du sagst dem Gargoyle, da� Du gerne Deinen K�rper mit Trinken f�r 1 Tag versorgt wissen willst, wenn Du wieder in ihn schl�pfst.");
	output("`3Er wirft einen Blick in sein Gesch�ftsbuch und");
	if ($session['user']['deathpower']>99){
		output("`3nickt zufrieden:`4\"So sei es, wenn Du wieder in Deinen K�rper schl�pfst, wird er mit Trinken f�r einen Tag versorgt worden sein!\"`n`3Mit diesen Worten notiert er etwas in das Buch und die Dinge nehmen ihren Gang.");
		$session['user']['deathpower']-=100;
		$session['user']['thirsty']+=5;
		addnav("Z?Zur�ck zur Halle","seelenhalle.php?op=halle");
	}else{
		output("`3sieht kurz darauf b�se auf:`4\"So, Du glaubst wohl, Du k�nntest Ramius betr�gen?!!\"`n`3Mit diesen Worten schnappt er Dich und verpa�t Dir einen Tritt, der Dich zur T�r bef�rdert, wo Dich die 2 Wachen in Empfang nehmen und vor die T�r setzen.");
		$session['user']['reputation']-=10;
		$session['user']['soulpoints']=0;
		addnav("Z?Zur�ck zur Halle","seelenhalle.php?op=halle");
	}
}
if($_GET[op]=="beten"){
	if(!$session[bet]){
		$session[bet]=true;
		output("`\$Du gehst zur Statue und beginnst intensiv zu beten.");
		switch(e_rand(1,20)){
			case 1:
			case 2:
			case 3:
			case 4:
			output("`4Ramius `\$ist zufrieden, seine Statue bewegt kurz eine Hand und Du hast 5 Gefallen mehr.");
			$session['user']['deathpower']+=5;
			break;
			case 5:
			case 6:
			case 7:
			case 8:
			output("`4Ramius `\$ist zufrieden, seine Statue bewegt kurz eine Hand und Du hast 1 Kampf mehr.");
			$session['user']['gravefights']+=1;
			break;
			case 9:
			case 10:
			case 11:
			output("`4Ramius `\$ist zufrieden, seine Statue bewegt kurz eine Hand und Du hast 10 Gefallen mehr.");
			$session['user']['deathpower']+=10;
			break;
			case 12:
			case 13:
			case 14:
			output("`4Ramius `\$ist zufrieden, seine Statue bewegt kurz eine Hand und Du hast 2 K�mpfe mehr.");
			$session['user']['gravefights']+=2;
			break;
			case 15:
			case 16:
			output("`4Ramius `\$ist zufrieden, seine Statue bewegt kurz eine Hand und Du hast 15 Gefallen mehr.");
			$session['user']['deathpower']+=15;
			break;
			case 17:
			case 18:
			output("`4Ramius `\$ist zufrieden, seine Statue bewegt kurz eine Hand und Du hast 3 K�mpfe mehr.");
			$session['user']['gravefights']+=3;
			break;
			case 19:
			output("`4Ramius `\$ist sehr zufrieden, seine Statue bewegt kurz eine Hand und Du hast 20 Gefallen mehr.");
			$session['user']['deathpower']+=20;
			break;
			case 20:
			output("`4Ramius `\$ist aehr zufrieden, seine Statue bewegt kurz eine Hand und Du hast 4 K�mpfe mehr.");
			$session['user']['gravefights']+=4;
			break;
		}
	}else{
                output("`\$Du hast heute schon zu `4Ramius `\$gebetet.");
		}
	addnav("Z?Zur�ck zur Halle","seelenhalle.php?op=halle");
}
if ($_GET[op]=="ehre"){
	output("`3Da Du ein besonders hoch geachteter B�rger von Simahr bist, hast Du `4Ramius `3besonders beeindruckt und wirst zu seinem Thron vor gelassen.`n`n");
	output("`3\"`4Also, `5".$session['user']['name']."`4, ich will Dir ein besonders Gesch�ft vorschlagen: wenn Du mir 50 Deiner Ansehenspunkte �berl��t, will ich dich wiederbeleben und es wird Dich nicht einen Gefallen kosten.`n Nun, `5".$session['user']['name']."`4, was sagst Du dazu?`3\"");
	addnav("J?Ja, gerne","seelenhalle.php?op=wieder");
	addnav("N?Nein, lieber nicht","seelenhalle.php?op=halle");
}
if ($_GET[op]=="wieder"){
	output("`4Ramius `3nickt zufrieden\"`4Nun, `5".$session['user']['name']."`4,`3 so soll es denn sein!`3\"`n`n");
	output("`&Er hebt beide Arme, murmmelt eine Formel und Dir wird schwarz vor Augen...");
	$session['user']['reputation']-=50;
	addnav("W?Weiter","newday.php?resurrection=true");
}
if ($_GET[op]=="segen"){
	output("`3Da Du ein ganz besonders hoch geachteter B�rger von Simahr bist, hast Du `4Ramius `3auch ganz besonders beeindruckt und wirst zu seinem Thron vor gelassen.`n`n");
	output("`3\"`4Also, `5".$session['user']['name']."`4, ich will Dir ein ganz besonders Gesch�ft vorschlagen:`n wenn Du mir `^100 Deiner Ansehenspunkte `4�berl��t und mir `^500 Gefallen `4zahlst, will ich meinen Segen auf Deine Waffe oder R�stung legen, der sich, bis Du den `@GR�NEN `4erlegt hast, jeden Morgen erneuern wird und f�r 120 Runden h�lt.`n Nun, `5".$session['user']['name']."`4, was sagst Du dazu?`3\"");
	if ($session['user']['ramiusw']=0){
		addnav("W?Waffe segnen","seelenhalle.php?op=waffe");
	}
	if ($session['user']['ramiusr']=0){
		addnav("R?R�stung segnen","seelenhalle.php?op=ruestung");
	}
	addnav("N?Nein, lieber nicht","seelenhalle.php?op=halle");
}
if ($_GET[op]=="waffe"){
	output("`3Du sagst `4Ramius`3, da� Du gerne seinen Segen auf Deiner Waffe h�ttest und er wirft einen Blick in sein dickes `4Buch des Wissens`3.");
	if ($session['user']['deathpower']>499){
		output("`3Er nickt zufrieden:`4\"So sei es, also reiche mir Deine Waffe!\"`n`n`3Du gibst sie ihm, er fasst sie ihn beide H�nde und beginnt, Beschw�rungsformeln zu murmeln, worauf hin sie `4rot `3 zu gl�hen anf�ngt. Als sie wieder ihre normale Farbe hat, reicht er sie Dir wieder, beginnt schallend zu lachen und deutet auf die T�r.");
		$session['user']['deathpower']-=500;
		$session['user']['reputation']-=100;
		$session['user']['ramiusw']=1;
		addnav("Z?Zur�ck zur Halle","seelenhalle.php?op=halle");
	}else{
		output("`3Er sieht kurz darauf b�se auf:`4\"So, Du glaubst wohl, Du k�nntest mich, Ramius, den Herrn der Unterwelt, betr�gen?!!\"`n`3Mit diesen Worten hebt er die Hand und Du sp�rst den Schlag einer unsichtbaren Hand, der Dich zur T�r bef�rdert, wo Dich 2 Wachen in Empfang nehmen und vor die T�r setzen.");
		$session['user']['reputation']-=30;
		$session['user']['soulpoints']=1;
		addnav("W?Weiter","seelenhalle.php?op=halle");
	}
}
if ($_GET[op]=="ruestung"){
	output("`3Du sagst `4Ramius`3, da� Du gerne seinen Segen auf Deiner R�stung h�ttest und er wirft einen Blick in sein dickes `4Buch des Wissens`3.");
	if ($session['user']['deathpower']>499){
		output("`3Er nickt zufrieden:`4\"So sei es, also reiche mir Deine R�stung!\"`n`n`3Du gibst sie ihm, er fasst sie ihn beide H�nde und beginnt, Beschw�rungsformeln zu murmeln, worauf hin sie `4rot `3 zu gl�hen anf�ngt. Als sie wieder ihre normale Farbe hat, reicht er sie Dir wieder, beginnt schallend zu lachen und deutet auf die T�r.");
		$session['user']['deathpower']-=500;
		$session['user']['reputation']-=100;
		$session['user']['ramiusr']=1;
		addnav("Z?Zur�ck zur Halle","seelenhalle.php?op=halle");
	}else{
		output("`3Er sieht kurz darauf b�se auf:`4\"So, Du glaubst wohl, Du k�nntest mich, Ramius, den Herrn der Unterwelt, betr�gen?!!\"`n`3Mit diesen Worten hebt er die Hand und Du sp�rst den Schlag einer unsichtbaren Hand, der Dich zur T�r bef�rdert, wo Dich 2 Wachen in Empfang nehmen und vor die T�r setzen.");
		$session['user']['reputation']-=30;
		$session['user']['soulpoints']=1;
		addnav("W?Weiter","seelenhalle.php?op=halle");
	}
}
page_footer(); 
?> 