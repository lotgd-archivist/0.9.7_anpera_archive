Seelenfeuer, Halle der reinen Seelen und RP Wiederbelebung
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
1.Seelenfeuer
=============
Ich fand es ein wenig eint�nig mit der Qu�lerei auf dem Friedhof, der Flu� der Seelen brachte da schon ein wenig Abwechslung, also hab ich etwas einfaches gemacht, was dem User entweder einen Grabkampf mehr bringt oder einen weniger, das entscheidet der Zufall und der User selbst, ob er nachsieht, oder nicht.

EINBAU
------

1. Kopiere die soulfire.php in Dein LOTGD Hauptverzeichnis


2. �ffne die gravyard.php, suche

	if ($victory) {
		output("`b`&{$badguy['creaturelose']}`0`b`n`n"); 
		output("`b`\$Du hast {$badguy['creaturename']} erniedrigt!`0`b`n`n");
		output("`#Du bekommst `^{$badguy['creatureexp']}`# Gefallen bei `\$Ramius`#!`n`0");
		$session['user']['deathpower']+=$badguy['creatureexp'];
		$badguy=array();

   F�ge danach ein

		$_GET['op']="";
		if (e_rand(1,10)==2) addnav("Ein Seelenfeuer","soulfire.php");

   Wenn Du willst, kannst Du ja die Zufallszahl ein wenig erh�hen oder senken.


3. Lade die gravyard.php wieder hoch, fertig!



2. Halle der reinen Seelen
==========================
Ich habe auf meinem Derver die Schmutzfunktion sowie Essen & Trinken und meine User haben sich beschwert, wenn sie im Wald sterben, da� sie ja keine M�glichkeit mehr h�tten, sich zu waschen oder Essen/Trinken zu kaufen. Eigentlich unterst�tze ich ja Faulheit nicht, Essen/Trinken kann man auch vorher kaufen, aber mit dem Waschen, da hatten sie recht. Also habe ich die Halle der reinen Seelen geschrieben, wo es folgende Optionen gibt:

- K�rper f�r 100 Gefallen mit Essen versorgen lassen
- K�rper f�r 100 Gefallen mit Trinken versorgen lassen
- K�rper f�r 20 Gefallen reinigen lassen
- 1 mal ander Statue des Armius beten
- F�r 50 Ansehenespunkte Wiederbeleben lasssen

Die Werte k�nnen beliebig erh�ht oder gesenkt werden, also dem Server angepa�t. An der Satue des Ramius gibt es immer etwas, und zwar positiv, wem das nicht gef�llt, der kann ja auch einbauen, da� es mal nichts gibt.
Die Wiederbelebung kostet nur die Ansehenspunkte und soll ein Bonbon f�r die ganz ehrenhaften sein, damit sie etwas davon haben, wenn sie sich im Wald dieses Ansehen erwerben, da es ja am neuen Tag sowieso auf 50 zur�ck geht. Die Zahl der Ehrenpunkte kann auch der Serverbalance angepa�t werden.

EINBAU
======
1. �ffne die seelnhalle.php und suche den Link zur�ck (ich hab sie in der H�lle angesiedelt), um ihn,
   gegebenen Falls zu �ndern.

2. Lade die seelenhalle.php in Dein LOTGD Hauptverzeichnis

3. Mache da, wo sie erscheinen soll, in der H�lle, auf dem Friedhof, bei den Schatten oder wo auch immmer
   in der Unterwelt, eienen Link addnav("Halle der reinen Seelen","seelenhalle.php"); und fertig!


3. Wiederbelebung zum RP
========================
Es kam oft vor, da� Spieler ein RP machten, der ein oder andere ging zwischen drin in den Wald, starbund kam nicht mehr hoch, das RP war gestorben. Also habe ich die M�glichkeit geschaffen, da� jeder, der stirbt, auch wieder hoch kommt, um sein RP fort zu setzen, allerdings hat er dann keine Runden mehr und nur 1 Lebenspunkt.

EINBAU
======

PHPMyAdmin:

ALTER TABLE 'accounts' ADD 'auferstanden' INT( 10 ) UNSIGNED NOT NULL ;

1. �ffne die rpresurect.php und suche ganz unten

	addnav("W?Weiter","friedhof.php");

   Ersetze es mit dem Ort, an dem Du Deine Spieler dann wieder ins Leben tretten lasen willst.

2. �ffne die newday.php und suche 

		$session['user']['amountouttoday'] = 0;
		$session['user']['seendragon'] = 0;

   F�ge, irgendwo in dieser Liste, ein

		$session['user']['auferstanden']=0;

3. �ffne die graveyard.php und suche

	}elseif ($session['user']['deathpower'] >= 25){
		output("`n`\$Ramius`) spricht: \"`7Ich bin nicht wirklich beeindruckt von deinen Bem�hungen, aber einen kleinen Gefallen werde ich dir gew�hren. F�hre meine Arbeit fort und ich kann dir vielleicht mehr meiner Kraft anbieten.`)\""); 
		addnav("Ramius' Gefallen");
		addnav("h?Feind heimsuchen (25 Gefallen)","graveyard.php?op=haunt");
		addnav("Sonstiges");

   f�ge dort ein

		addnav("Wiederbelebunug zum RP (10 Gefallen)","rpresurect.php");

   Dann sieht es etwa so aus

	}elseif ($session['user']['deathpower'] >= 25){
		output("`n`\$Ramius`) spricht: \"`7Ich bin nicht wirklich beeindruckt von deinen Bem�hungen, aber einen kleinen Gefallen werde ich dir gew�hren. F�hre meine Arbeit fort und ich kann dir vielleicht mehr meiner Kraft anbieten.`)\""); 
		addnav("Ramius' Gefallen");
		addnav("h?Feind heimsuchen (25 Gefallen)","graveyard.php?op=haunt");
		addnav("Wiederbelebunug zum RP (10 Gefallen)","rpresurect.php");
		addnav("Sonstiges");

   Suche davor direkt

		if ($session[user][reputation]>-40) addnav("e?Wiedererwecken (100 Gefallen)","newday.php?resurrection=true");
		addnav("5 Donationpoints (100 Gefallen)","graveyard.php?op=dona");
		addnav("Sonstiges");

   und f�ge dort ein

		addnav("Wiederbelebunug zum RP (10 Gefallen)","rpresurect.php");

   dann sieht es etwa so aus

		if ($session[user][reputation]>-40) addnav("e?Wiedererwecken (100 Gefallen)","newday.php?resurrection=true");
		addnav("Wiederbelebunug zum RP (10 Gefallen)","rpresurect.php");
		addnav("5 Donationpoints (100 Gefallen)","graveyard.php?op=dona");
		addnav("Sonstiges");

4. F�ge bei allen Wegen aus dem Ort, in dem die Leute wieder ins Leben tretten folegndes ein

if ($session['user']['auferstanden']==1) {
	$session['user']['turns']=0;
}

   Wenn Du willst, kannst Du es auch in der commen.php in den Teil f�r den Wald schreiben (bitte nur 
   erfahrene Admins)

5. Lade die rpresurect.php in Dein LOTGD Hauptverzeichnis, fertig!




Ich hoffe, dem ein oder anderen werden diese Funktionen Gefallen und er hat Verwendung daf�r. Den Copyright Hinweis oben bitte stehen lassen, bei �nderungen kann man gerne noch anf�gen 

//ge�ndert von XYZ f�r den Server www.xylotgd

aber dann bitte nicht f�r eigenes Werk ausgeben. Fairness sollte Grundvoraussetzung sein bei allen Admins.
Und nun Euch und Euren Usern viel Spa� damit...