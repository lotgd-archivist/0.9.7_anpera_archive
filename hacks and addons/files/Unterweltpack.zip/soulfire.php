<?php
// Idee und Umsetzung
// Morpheus aka Apollon
// f�r www.morpheus-lotgd.de.vu
// 2006, Mail an Morpheus@magic.ms
// Gewitmet meiner �ber alles geliebten Blume
require_once "common.php";
checkday();
page_header("Das Seelenfeuer");
if (!$session[user][alive]){
	output("`3Als Du �ber den Friedhof ziehst, bemerkst Du pl�tzlich zu deinen F��en eine kleine Flamme, die aus dem Boden schie�t, Dich an den Beinen ber�hrt und in ihnen zu verschwinden scheint.");
	switch(e_rand(1,4)){
		case 1:
		case 2:
		output("Erschrocken zuckst Du zusammen, doch versp�rst Du keinen Schmerz, sondern vielmehr neue Energie, die sich in Dir ausbreitet.`n`n");
		output("`4Du kannst einen Grabkampf mehr austragen!"); 
		$session['user']['gravefights']+=1;
		addnav("Zur�ck zum Friedhof","graveyard.php");
		break;
		case 3:
		case 4:
		output("Erschrocken zuckst Du zusammen und sp�rst, wie die Flamme an Deinen Kr�ften zerrt.`n`n");
		output("`\$Du kannst einen Grabkampf weniger austragen!"); 
		$session['user']['gravefights']-=1;
		addnav("Zur�ck zum Friedhof","graveyard.php");
		break;
		}
}else{
	redirect("village.php");
}
page_footer();
?>