<?php
// Idee & Umsetzung
// Morpheus f�r www.morpheus-lotgd.de.vu
// Mail an morpheus@magic.ms
// Gewidmet meiner �ber alles geliebten Blume
require_once("common.php");
page_header("RP Auferstehung");
if($_GET['op']==""){
	output("`7Ramius sieht Dich grinsend an:\"`4So so, wartet wohl noch jemand in der Oberwelt auf Dich, hmmm?");
	output("Ich kann Dich auferstehen lassen, das kostet Dich dann nur 10 Gefallen`7\" sagt er grienend\"`4 aber Du wirst keine Zeit mehr f�r Waldk�mpfe haben und kein Zinsen bekommen, nur Deinem normalen Leben nachgehen k�nnen, bist Du Dir sicher, da� Du das willst?`7\"fragt er Dich.");
	addnav("J?Ja","rpresurect.php?op=ja");
	addnav("N?Nein","graveyard.php?op=enter");
}
if($_GET['op']=="ja"){
	if ($session['user']['deathpower']>=10){
		output("`7Ramius sch�ttelt lachend den Kopf:\"`4Na, das scheint Dir ja wirklich am Herzen zu liegen, dann will ich mal nicht so sein.`7\"");
		$session['user']['deathpower']-=10;
		$session['user']['turns']=0;
		$session['user']['alive']=1;
		$session['user']['hitpoints']=1;
		$session['user']['auferstanden']=1;
		addnav("W?Weiter","rpresurect.php?op=hoch");
	}
	if ($session['user']['deathpower']<10){
		output("`7W�tend hebt Ramius die Faust:\"`4Du willst mich wohl f�r dumm verkaufen?!? VErschwinde, Du elender Wurm, befvor ich dich zerquetsche und nie mehr hier weg lasse!!!`7\"");
		$session['user']['gravefights']=0;
		if ($session['user']['deadtreepick']=0){
			$session['user']['deadtreepick']=1;
		}
		$session['user']['reputation']-=10;
		addnav("W?Weiter","graveyard.php?op=enter");
	}
}
if($_GET['op']=="hoch"){
	output("`7Ramius spricht eine Beschw�rungsformel, in Deinen Ohren dr�hnt es, Dir wird schwarz vor Augen und ein Schwindel erfa�t Dich, alles dreht sich um Dich!`n");
	output("`7Du schlie�t die Augen, h�rst ein Rauschen und als Du die Augen wieder �ffnest, stehst Du auf dem Friedhof von Simahr, in Deinen Ohren dr�hnen noch Ramius Worte nach:\"`4Pa� ja gut auf, denn sterben kannst Du trotz allem wieder...und wenn nicht jetzt, dann ein andermal, aber wir sehen uns wieder!`7\"");
	addnews($session[user][name]." `3durfte aus `4Ramius Reich `3auferstehen, um seiner t�glichen Besch�ftigung nach zu gehen.");
	addnav("W?Weiter","friedhof.php");
}
page_footer();
?>