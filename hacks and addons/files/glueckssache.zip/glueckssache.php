<?php
$gold = e_rand($session[user][level]*10,$session[user][level]*50); 
$session[user][gems]++;
output("`^Das Gl�ck l�chelt dich an. Du findest $gold Gold! `nDu solltest dir mal �berlegen, was du mit den $gold Gold anfangen m�chtest.`nW�hrend du auf einem Baustamm sitzt entdeckst du zu deinem `nGl�ck noch etwas..... $gems `qeinen Edelsteine!`0");
$session[user][gold]+=$gold;
//debuglog("found $gold gold in the forest");
addnews("`QEin B�rger hatte Gl�ck und fand $gold Gold im Wald von Imberia! `qZuf�lliger Weise fand er dort auch noch einen Edelstein!") 
?>
