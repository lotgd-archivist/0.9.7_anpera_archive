<?php 





require_once "common.php"; 

page_header("Bann"); 

if($_GET[op]==""){ 

output("`4Willst du  `^$_GET[char]`4 wirklich zum Verh�r in den dunklen Turm werfen?"); 
addnav("Ja ich will","get.php?op=ja&id=$_GET[id]&char=$_GET[char]"); 
addnav("Sonstiges"); 
addnav("Zur�ck","bio.php?id=$_GET[id]&char=$_GET[char]"); 

} 

if($_GET[op]=="ja"){ 

$sql="SELECT acctid, name,zwischenwelt,zwischentage,turm,login, level FROM accounts WHERE acctid = '$_GET[id]'";  
$result = db_query($sql) or die(db_error(LINK));  
$row = db_fetch_assoc($result);  

output("`n`n`7Du hast ".$row['name']."`7 In den Turm geworfen.",true);  
systemmail($_GET[id],"`^Verh�r!`0",$session[user][name]." `&Scharfrichter der Inquisition hat dich zum Verh�r in den dunklen Turm gebracht!",$session[user]['acctid']);  

db_query("UPDATE accounts SET turm=turm+1 WHERE acctid = '$_GET[id]'"); 

//Newseintrag 
addnews("{$row[name]}`&wurde zum Verh�r in den `9Dunklen`&Turm gesperrt!!!");


addnav("Sonstiges"); 
addnav("Zur�ck","bio.php?id=$_GET[id]&char=$_GET[char]"); 
} 
page_footer(); 
?>