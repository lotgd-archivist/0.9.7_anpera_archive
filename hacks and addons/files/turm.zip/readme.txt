
Der dunkle Turm
Inquisitions addon

______________________________________________________
SQL

ALTER TABLE accounts ADD `scharfrichter` int(11) NOT NULL;
ALTER TABLE accounts ADD `turm` int(11) NOT NULL;
ALTER TABLE accounts ADD `folter` int(11) NOT NULL;
_______________________________________________________

�ffne bio.php

suche:
name,login,

f�ge ein:
scharfrichter,

suche: 
$link1="bann.php?char=$row[login]&id=$row[acctid]"; 
if($session[user][inquisitor]==1 && $row[tarn]==0 && $row[zwischenwelt]==0) addnav("User bannen", $link1);
if ($session[user][beschwoerer]==1 && $row[zwischenwelt]==1)addnav("User beschw�ren","banne.php?char=$row[login]&id=$row[acctid]");

f�ge danach ein:
if ($session[user][scharfrichter]==1)addnav("Verh�r","get.php?char=$row[login]&id=$row[acctid]");


suche:
if ($session['user']['loggedin']) { output('<a href="mail.php?op=write&to=$row[login]" target="_blank" onClick="'.popup("mail.php?op=write&to=$row[login]").';return false;"><img src="images/newscroll.GIF" width="16" height="16" alt="Mail schreiben" border="0"></a>',true); }

f�ge darunter ein:
if($row[scharfrichter]==1){ output("`b `& `nScharfrichter der Inquisition`n");}


CLOSE AND UP
________________________________________________
�ffne Newday
suche:
 Du schnallst deine[...];

f�ge darunter ein:

// Turm

if ($session['user']['turm']==1){

output('`9 Noch immer ist es Dir nicht gelungen deine Unschuld zu beweisen weshalb du im dunklen Turm gefangen gehalten wirst. Vielleicht hast du heute mehr Gl�ck?`n`n In der kleinen Zelle hast du keine M�glichkeit dich ehrzurichten, darum verlierst du einen Charmpunkt.`n`n Das st�ndige Nichtstun geht gewaltig an die Substanz und zerrt an Deinen Kr�ften, darum verlierst du zwei Aprenapunkte.`n`n');
$session['user']['charm']--;
$session['user']['battlepoints']-=2;
$session['user']['folter']=0;
$session['user']['zufall']=0;
}

if ($session['user']['scharfrichter']==1){
output('`4 `n Ein neuer Tag zum Foltern ist angebrochen, vielleicht gelingt es dir ja heute ein Gest�ndniss zu erwirken? ');
$session['user']['folter']=0;
$session['user']['zufall']=0;
}
//Turm Ende

SAFE AND UP
________________________________________________________
user.php:
suche:
"emailaddress"=>"Email-Adresse",

f�ge darunter ein:
"scharfrichter"=>"Ist Scharfrichter?,enum,0,Nein,1,Ja",		

SAFE AND UP
___________________________________________________________
turm.php
get.php ins root

turm.php in der village oder an geeigneter Stelle verlinken.

Have fun