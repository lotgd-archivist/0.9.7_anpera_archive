<? 
//****************************************//
// Der Dunkle Turm				//
// Idee: Rakarth Killian/Barra		//
// Umsetzung: Newby/Barra			//
//www.child-of-mystik-moon.de/lotgd		//
//****************************************//



require_once "common.php"; 
page_header("Der dunkle Turm"); 
switch ($_GET['op']){ 


case 'gestehen': 
output("`n`nEs ist vorbei..du gestehst und machst dieser Tourtur ein Ende und gestehst dem Scharfrichter was immer er h�ren will.Alelrdings bringt dich das Direkt in die Zwischenwelt. Bye Bye`n`n"); 
         $sql= "UPDATE accounts SET tarn=0, zwischenwelt=1, turm=0, folter=0,zwischentage=zwischentage+2 "; 
    db_query($sql); 
    
    addnav(" weiter","zwischen.php"); 

break; 

case 'folter': 
if ($session['user']['folter']<3){
         output("`#Du l�sst Dich zwei Stunden am armen Verd�chtigen aus.`n Durch das ganze Blut und die harte Arbeit verlierst du etwas Charme"); 
$session['user']['charm']--;
   output("`# Durch die ganze Folterrei bekommst du aber Arenapunkte!`n`n`^ Du erh�llst `@ 2`^ Arenapunkte`n`n");
$session['user']['battlepoints']+=2;
    addnav("Ende","turm.php"); 
}else{ 
output("Na das reicht doch f�r heute, hmm?");
addnav("zur�ck","turm.php");
}
break; 
  
case 'unschuld': 
   if ($session['user']['zufall']<3)
        {
            $what=$_GET['what'];
            switch ($what)
            {

case '1':
                $limit=50;
               
                $text="`t Du redest wie wild auf den Scharfrichter ein und versucht ihn von Deiner Unschuld zu �berzeugen`n`n!`0`n";
                break;
            }
            $chance=e_rand(1,100);
            if ($chance<=$limit)
            {
                output('`@Gl�ckwunsch!`n'.$text);
                output('`t Der Scharfrichter glaubt dir und du kannst gehen!`n`n');
                $session['user']['turm']=0;
                $session['user']['folter']=0;
addnav('weiter','village.php');
            }
            else
            {
                output('`# `n`n Der Scharfrichter scheint dir nicht zu glauben..`n');
           }
        }
        else
        {
            output('`t Dein Hals ist zu trocken zum Sprechen. Versuche es morgen.`n`n!`n');
        }
        $session['user']['zufall']++;
        addnav('Zur�ck','turm.php');
        
        break;

case 'tafel':

    output("`c`7Verd�chtige `n`n<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999'>",true); 
    output("<tr class='trhead'><td><b>Name</b></td><td><b>APs</b></td><td>Aktionen</td>",true); 


    $sql="SELECT * FROM accounts WHERE turm = 1 ORDER BY battlepoints DESC  "; 

    $result=db_query($sql);
    for ($i=0; $i<db_num_rows($result); $i++)
    {
        $row = db_fetch_assoc($result);
 

 
       

         output("<tr class='".($i%2?"trdark":"trlight")."'><td>",true); 
        output("$row[name]`n"); 
        output("</td><td>",true); 
        output("$row[battlepoints]`n"); 
          output("</td><td>",true);   
 output("<a href=\"mail.php?op=write&to=".rawurlencode($row['login'])."\" target=\"_blank\" onClick=\"".popup("mail.php?op=write&to=".rawurlencode($row['login'])."").";return false;\"><img src='images/newscroll.GIF' width='16' height='16' alt='Mail schreiben' border='0'></a>",true); 
   

         }
   
    output("</table>`c",true); 
 addnav("zur�ck","turm.php");
break;

default: 
         output("`cDer dunkle Turm`c`n`n`n`bDer dunkle Turm. Hier �bt die Inquisition  besondere Verh�rmethoden aus.  `n`n"); 
    if ($session[user][scharfrichter]==1)addnav ("Foltern","turm.php?op=folter"); 
addnav("Tafel","turm.php?op=tafel"); 

 if ($session[user][turm]==1)addnav ("Gestehen","turm.php?op=gestehen");
 if ($session[user][turm]==1&& $session[user][scharfrichter]==0)addnav ("Unschuld beteuern","turm.php?op=unschuld&what=1");  
   if($session[user][turm]==0) addnav("Gehen","village.php"); 
if ($session[user][turm]==1)addnav('Schlafen','login.php?op=logout',true);

   
   
addcommentary();
viewcommentary('turm','Hinzuf�gen',25);
break; 
}//switch op end 
//$session[user][standort]="`9 Der dunkle Turm";
 //nur wenn Standortanzeige ind er list aktivieren

page_footer(); 
?> 