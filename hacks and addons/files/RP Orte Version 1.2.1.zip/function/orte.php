<?
/* Functions Script f�r Orte.php by Passion de la glace */
require_once 'common.php';


$allowedTags = '<h1><b><i><a><ul><li><pre><hr><blockquote><img><h3>';
$stripAttrib = 'javascript&#058;|onclick|ondblclick|onmousedown|onmouseup|onmouseover|'.
'onmousemove|onmouseout|onkeypress|onkeydown|onkeyup|onabort|'.
'onfocus|onload|onblur|onchange|onerror|onreset|onselect|obsubmit|onunload';


function removeEvilTags($source)
{
   global $allowedTags;
   $source = strip_tags($source, $allowedTags);
   return preg_replace('/<(.*?)>/ie', "'<'.removeEvilAttributes('\\1').'>'", $source);
}


function removeEvilAttributes($tagSource)
{
   global $stripAttrib;
   return stripslashes(preg_replace("/$stripAttrib/i", 'forbidden', $tagSource));
}


//Function f�r Navigation
function navs($navinfo,$id,$acctid){
	global $session;

  switch ($navinfo){
	case 'default':
	 addnav('Optionen');
  if ($session['user']['rport']==0)
	 addnav('RP Ort erstellen','orte.php?op=erstellen');
	 addnav('Zur�ck','village.php');
  if ($session['user']['superuser']>=2){
     addnav('SU Optionen');
	 addnav('Orte Administration','orte.php?op=admin&suop=');
   }
	break;
	
	case 'admin':
	  addnav('SU Optionen');
      addnav('Ort anlegen','orte.php?op=admin&suop=anlegen');
      addnav('------');
  if ($session['user']['superuser']>=3)
      addnav('Tabelle leeren','orte.php?op=admin&suop=leeren');
      addnav('Sonstiges');
      addnav('Zur�ck zu den Orten','orte.php');
    break;
    
    case 'ort':
     if ($session['user']['acctid']==$acctid){
      addnav('Deine Ortsadministration');
      addnav('Dein Ort editieren','orte.php?op=ort&editop=edit&id='.$id.'');
      addnav('Bann�bersicht','orte.php?op=ort&act=bann&id='.$id.'');
      addnav('----');
      addnav('Dein Ort l�schen','orte.php?op=ort&editop=delete&id='.$id.'');
    }   
      addnav('Sonstiges');
      addnav('Aktualisieren','orte.php?op=ort&id='.$id.'');
	  addnav('Zur�ck zu den Orten','orte.php');
    break;
   
    case 'bann':
      addnav('Bannoptionen');
	  addnav('Spieler bannen','orte.php?op=ort&act=playerbann&id='.$id.'');
	break;
  }
}


//Function f�r Anzeige aller Orte
function ShowallPlaces(){
 
   navs('default','','');
	output('`&`c`bDie RPG Orte`c`b`n`n`n');
	    output('Hier sind all die RPG Orte aufgelistet die die Spieler erstellt haben. Du kannst jeden dieser Orte besuchen und dort RP betreiben.');
	    output('`c');
	    output('<table border=0 cellpadding=2 cellspacing=1 bgcolor=\"#000000\" align=\"center\">',true);
        output('<tr class=\"trhead\" align=\"center\">
                <td><b>Ersteller</b></td>
			    <td><b>Ortsname</b></td>
			    <td><b>Betreten</b></td>',true);
			  
	     $sql = 'SELECT id,acctname,name FROM rporte ORDER BY id ASC';
	     $result = db_query($sql) or die (db_error(LINK));
	     while ($row = db_fetch_assoc($result)) {
	        $class = ($class=='trdark'?'trlight':'trdark');
	        
                output("<tr class='$class'><td>",true);
                output($row['acctname']);
                output('</td><td>',true);
                output($row['name']);
                output("</td><td>
                <a href='orte.php?op=ort&id=".$row['id']."'>Betreten",true);
                addnav('','orte.php?op=ort&id='.$row['id'].'');
                output("</td>",true);
        }
             output('</table>',true);
	output('`c');
}


//Function f�r anschauen der Orte
function ShowPlaceDesc($id,$checkbann){
	global $session;
	   $sql = 'SELECT * FROM rporte WHERE id='.$id.'';
	   $result = db_query($sql) or die (db_error(LINK));
	   $ort = db_fetch_assoc($result);
	 
	 if ($ort['close']==1){
	   output('<h3>`$Dieser Ort wurde von den Admins geschlossen</h3>',true);
	  }else{
	 
	   $search = 'SELECT name,ort,grund FROM ortebann WHERE ort='.$id.' AND name="'.$checkbann.'"';
	     $result = db_query($search) or die (db_error(LINK));
	 if (db_num_rows($result)>0){
		  $bann = db_fetch_assoc($result) or die (db_error(LINK));
		
		output(''.$checkbann.' du wurdest von '.$ort['acctname'].' dem Ersteller dieses Ortes gebannt er/sie hat dir folgenden Grund genannt: '.$bann['grund'].'');
		  addnav('Zur�ck','orte.php');
	 }else{
	
	      output('`$Diesen Ort hat '.$ort['acctname'].' erstellt`n`n');
	      output('`c'.$ort['name'].'`c`n');
	
	      output(''.CloseTags(removeEvilTags($ort['text']),'`n`c`b`i').'`n`n`n',true);
	
	
		viewcommentary('Ort_'.$ort['id'].'','Hier schreiben',20);
		
		}
	}
       navs('ort',''.$ort['id'].'',''.$ort['acctid'].'');
      
}

//Function f�r anschauen der Tabelle f�r gebannte Spieler
function ViewPeoplebanns($id){
	global $session;
	
	  $select = "SELECT id,acctid FROM rporte WHERE id=".$id."";
              $result = db_query($select) or die(db_error(LINK));
	          $ort = db_fetch_assoc($result);
	          
			  output('`n`n`c`$`bDie von dir gebannten Spieler`b`n`n');
	            output('<table border=0 cellpadding=2 cellspacing=1 bgcolor=\"#000000\" align=\"center\">',true);
                output('<tr class=\"trhead\" align=\"center\">
                        <td><b>Name</b></td>
						<td><b>L�schen</b></td>',true);
			  
	              $sql = 'SELECT id,name,ort FROM ortebann WHERE ort='.$id.' ORDER BY id ASC';
	              $result = db_query($sql) or die (db_error(LINK));
	              
	              if (db_num_rows($result)==0){
	                $class = ($class=='trdark'?'trlight':'trdark');
                      output("<tr class='$class'><td>",true);
                      output('`c`$Keine Bannungen vorhanden!!`c</td>',true);
	              }else{
	              while ($row = db_fetch_assoc($result)) {
	            $class = ($class=='trdark'?'trlight':'trdark');
                      output("<tr class='$class'><td>",true);
                      output($row['name']);
                      output("</td><td>
                      <a href='orte.php?op=ort&act=delete&id=".$row['id']."'>L�schen",true);
                      addnav('','orte.php?op=ort&act=delete&id='.$row['id'].'');
                      output("</td>",true);
                     }
                  }
                 output('</table>',true);
	          output('`c`n`n`n`n');
	          
	           navs('bann',''.$id.'','');
}

//Function f�r SU Optionen
function ViewSUoptions(){
	 output('`c');
	       output('<table border=0 cellpadding=2 cellspacing=1 bgcolor=\"#000000\" align=\"center\">',true);
           output('<tr class=\"trhead\" align=\"center\">
                   <td><b>OrtsID</b></td>
                   <td><b>Ersteller</b></td>
			       <td><b>Ortsname</b></td>
			       <td><b>Editieren</b></td>
				   <td><b>L�schen</b></td>',true);
			  
	     $sql = 'SELECT id,acctname,name FROM rporte ORDER BY id ASC';
	     $result = db_query($sql) or die (db_error(LINK));
	     while ($row = db_fetch_assoc($result)) {
	        $class = ($class=='trdark'?'trlight':'trdark');
	        
                output("<tr class='$class'><td>",true);
                output($row['id']);
                output('</td><td>',true);
                output($row['acctname']);
                output('</td><td>',true);
                output($row['name']);
                output("</td><td>
                <a href='orte.php?op=admin&suop=edit&id=".$row['id']."'>Editieren",true);
                addnav('','orte.php?op=admin&suop=edit&id='.$row['id'].'');
                output("</td><td>
                <a href='orte.php?op=admin&suop=delete&id=".$row['id']."'>L�schen",true);
                addnav('','orte.php?op=admin&suop=delete&id='.$row['id'].'');
                output('</td>',true);
        }
             output('</table>',true);
             output('`c');
          
          navs('admin','','');
  }
?>