<?php /* Neuer Tanzsaal (2.2) */
/**
 * Tanzsaal f+r LotgD 0.97
 * by Auric @ http://www.tharesia.de
 * webmaster@blood-reaver.de
 * Version 2.2
 * Last Change: So, 04.03.09 19:45
 * Abzug von Runden-Exploit entfernt
 * Veröffentlicht unter GNU GPL
 */
/*
####Einbauanleitung###
		// DANTENBANK //
#WICHTIG: Wenn noch die alte Version (dancehall.php) installiert ist bitte zunächst die Felder
# "danceby","hasdanced" und "dance" löschen, am besten mit diesem Query:
ALTER TABLE `accounts`
  DROP `dance`,
  DROP `danceby`,
  DROP `hasdanced`;
#Ansonsten muss der Query oben nicht ausgeführt werden.

#In jedem Falle muss jedoch dieser Datenbankbefehl ausgeführt werden:
ALTER TABLE `accounts`
	ADD `tanz_mode` ENUM( 'nichts', 'hat', 'wurde' ) NOT NULL ,
	ADD `tanz_partner` INT NOT NULL DEFAULT '0',
	ADD `tanz_heute` TINYINT( 1 ) NOT NULL DEFAULT '0';


		// PHP-DATEIEN //
#in Beliebige Ausgangsdatei einfügen (meist village.php)
addnav("Tanzsaal","tanzsaal.php");

#in der newday.php
//suche
$session['user']['seenbard'] = 0;
//darunter einfügen
$session['user']['tanz_heute'] = 0;

# Bei belieben kann auch noch dies in der hexte.php geändert werden - dann kann der User für einen Edelstein noch einmal tanzen gehen.
//suche
} else if ($_GET[op] == "barde"){
	output("`!\"`%Soso, der Barde will nicht mehr für dich singen. Hättest du ihm diesen Edelstein gegeben statt mir, hätte er sicher gesungen. Weißt du was? Ich werde ihm diesen Edelstein vor die Füße zaubern und ihn ");
	output(" wissen lassen, daß er von dir ist. So wie ich ihn kenne, steckt er ihn sich in die löchrige Hosentasche und verliert ihn in der Kneipe wieder ... aber was solls.`!\" Damit legt die Hexe ");
	output("den Edelstein auf den Tisch und schüttet etwas von ihrem Punsch darüber. \"`%Schon gut, du kannst gehen.`!\" sagt sie noch zu dir und während du dich ");
	output("Richtung Wald umdrehst, siehst du den Edelstein verschwinden... `n`n");
	$session[user][gems]--;
	$session[user][seenbard]=0;
	forest(true);

//darunter einfügen
} else if ($_GET[op] == "tanzen") {
	output("`!\"`%Ach, wir möchten nochmal das Tazbein schwingen, so ist das. Jaja, und ich soll nun deine Füße \"Umstimmen\" *seufz*, na gut, du bezahlst ja`!\"`n");
	output("Die Hexe bricht in ein Kichern aus, das klingt, wie ein Frettchen mit Nebenhöhlenentzündung. Doch dann beginnt sie immer schneller Worte zu sprechen, die dir den Kopf schwirren lassen.`n");
	output("Dann sieht sie dich an und fragt: \"`%So, genug der Effekte. Trink das, und du kannst heute noch eine Runde drehen! Keine Angst, ist nur Kamillentee!`!\", gackert sie und drückt dir ein Fläschchen in die Hand und dich aus der Hütte.");
	$session['user']['tanz_heute']=0;
	$session['user']['gems']--;
	forest(true);

//suche
if ($session[user][seenbard] && $session[user][gems]) addnav("Bardenhals befeuchten (1 Edelstein)","hexe.php?op=barde");

//danach einfügen
if ($session[user][hasdanced] && $session[user][gems]) addnav("Tanzbein flottmachen (1 Edelstein)","hexe.php?op=tanzen");

#Damit wäre die Installation dann abgeschlossen.
#Eine Außname ergibt sich, wenn vorher schon die dancehall.php installiert war, 
#dann müssen alle Änderungen in den anderen php-Dateien noch rückgängig gemacht werden.
#Wenn die dancehall.php vorher noch installiert war, kann diese Datei jetzt gelöscht werden.

#Auric
*/
/* Prekonfiguration */
require_once ("common.php");
page_header("Tanzsaal");
addcommentary();
checkday();
$geschlecht = getsetting("tanzpartner", false);
$charmebonus = 2; // Hier einstelen, wie viele Charmepunkte man bekommt


/* Funktionen */
function checkdance() {
	global $session;
	if ($session['user']['tanz_mode'] != 'nichts')
		return $session['user']['tanz_partner'];
	else
		return false;
}

function partner() {
	global $session;
	$sql = "SELECT `acctid`, `name`, `login`, `sex`, 'turns' FROM `accounts` WHERE `acctid` = " . $session['user']['tanz_partner'] . " LIMIT 1";
	$result = db_query($sql);
	return db_fetch_assoc($result);
}

/* Haupt-Script */
if ($_GET['op'] == "absagen") {
	$partner = partner();
	/* Daten übermitteln und zurücksetzen */
	systemmail($partner['acctid'], "`4Aufforderung abgelehnt", "`$ " . $session['user']['name'] . " `4hat deine Aufforderung zum Tanz leider abgelhnt. `nVieleicht findest du ja einen anderen Partner.");
	$session['user']['tanz_mode'] = 'nichts';
	$session['user']['tanz_partner'] = 0;
	$sql = "UPDATE `accounts` SET `tanz_mode` = 'nichts', `tanz_partner` = 0 WHERE `acctid` = " . $partner['acctid'] . " LIMIT 1";
	db_query($sql) or die(db_error(LINK));
	
	/* Auswirkungen */
	switch (round(rand(1, 5))) {
		case 2:
			output("`6Zwar hast du`$ " . $partner['name'] . " `6die eiskalte Schulter gezeigt, aber so wirklich gut fühlst du dich trotzdem nicht.`n");
			output("`%Dir vergeht die Laune und du möchtest heute nicht mehr tanzen.");
			addnav("Zurück ins Dorf", "village.php");
			$session['user']['tanz_heute'] = 1;
			break;
		case 3:
			output("`^Du sagst`$ " . $partner['name'] . " `^ab, doch anscheinend wirst du dabei von einigen anderen Tänzern gesehen, die sofort zu lästern beginnen.`n");
			output("`5Du verlierst daher an Charme");
			$session['user']['charm']--;
			addnav("Zurück zur Tanzfläche", "tanzsaal.php");
			break;
		case 4:
			output("`9Du willst`$ " . $partner['name'] . " `9absagen doch bringst es nicht übers Herz. Stattdessen geht ihr gemeinsam etwas trinken, wobei du es dann doch über dich bringst.");
			output(" " . $partner['name'] . " `#ist zwar ein wenig enttäuscht, bedankt sich aber für deine Höflichkeit. Sogleich fühlst du dich charmanter!");
			addnav("Zurück zur Tanzfläche", "tanzsaal.php");
			break;
		default:
			output("`@Du sagst " . $partner['name'] . " ab und machst dich statdessen auf die Suche nach einem anderen Tanzpartner`n`n");
			addnav("Zurück zur Tanzfläche", "tanzsaal.php");
			break;
	}
} elseif ($_GET['op'] == "auffordern") {
	$session['user']['tanz_partner'] = $_GET['id'];
	$partner = partner();
	output("`^Du nimmst deinen Mut zusammen und gehst auf `@" . $partner['name'] . " `^ zu, um " . ($partner['sex'] ? "sie" : "ihn") . " zum Tanz aufzufordern.`n");
	if ($session['user']['turns'] < 1 || $session['user']['tanz_heute'] == 1) {
		output("Aber schon als du auf " . ($partner['sex'] ? "sie" : "ihn") . " zu gehst, merkst du, das du heute einfach nicht mehr die kondition dafür hast, noch einmla zu tanzen.");
		$session['user']['tanz_partner'] = 0;
	} else {
		$sql = "UPDATE `accounts` SET `tanz_mode` = 'wurde', `tanz_partner` = " . $session['user']['acctid'] . " WHERE `acctid` = " . $_GET['id'] . " LIMIT 1";
		db_query($sql) or die(db_error(LINK));
		$session['user']['tanz_mode'] = 'hat';
		output("Nachdem du " . $partner['name'] . " `6nun tatsächlich angesprochen hast, muust du nur noch abwarten, ob " . ($partner['sex'] ? "sie" : "er") . "an nimmt.");
	}
	systemmail($partner['acctid'], "`^Tanzaufforderung`0", "`$ " . $session['user']['name'] . " `%hat dich zu einem Tanz im Saal aufgefordert!`nNun ist deine Entscheidung vonnöten!");
	addnav("Zurück in den Saal", "tanzsaal.php");
} elseif ($_GET['op'] == "suchen") {
	$g_sql = ($geschlecht ? "" : "(sex <> " . $session[user][sex] . ") AND");
	output("`gDu gehst umher und suchst nach einem passenden Tanzpartner`n");
	if (isset($_POST['search']) || $_GET['search'] > "") {
		if ($_GET['search'] > "")
			$_POST['search'] = $_GET['search'];
		$search = "%";
		for($x = 0; $x < strlen($_POST['search']); $x++) {
			$search .= substr($_POST['search'], $x, 1) . "%";
		}
		$search = "name LIKE '" . $search . "' AND ";
	} else {
		$search = "";
	}
	$ppp = 30; // Player Per Page to display
	if (!$_GET[limit]) {
		$page = 0;
	} else {
		$page = (int) $_GET[limit];
		addnav("Vorherige Seite", "tanzsaal.php?op=suchen&limit=" . ($page - 1) . "&search=" . $_POST['search']);
	}
	$limit = "" . ($page * $ppp) . "," . ($ppp + 1);
	output("Für wen entscheidest du dich?`n`n");
	output("<form action='tanzsaal.php?op=suchen' method='POST'>Nach Name suchen: <input name='search' value='" . $_POST['search'] . "'><input type='submit' class='button' value='Suchen'></form>", true);
	addnav("", "tanzsaal.php?op=suchen");
	
	$sql = "SELECT acctid,name,sex,level,race,login,marriedto,charisma,tanz_mode FROM accounts WHERE
					$search $g_sql
					(acctid <> " . $session['user']['acctid'] . ") AND (laston > '" . date("Y-m-d H:i:s", strtotime(date("r") . "-346000 sec")) . "')	ORDER BY charm DESC LIMIT $limit";
	$result = db_query($sql) or die(db_error(LINK));
	output("<table border='0' cellpadding='3' cellspacing='0'>", true);
	output("<tr><td><b>Name</b></td><td><b>Rasse</b></td>" . ($geschlecht ? "<td><b>Geschlecht</b></td>" : "") . "<td><b>Status</b></td><td><b>Ops</b></td></tr>", true);
	if (db_num_rows($result) > $ppp)
		addnav("Nächste Seite", "tanzsaal.php?op=suchen&limit=" . ($page + 1) . "&search=" . $_POST['search']);
	for($i = 0; $i < db_num_rows($result); $i++) {
		$row = db_fetch_assoc($result);
		$biolink = "bio.php?char=" . rawurlencode($row['login']) . "&ret=" . urlencode($_SERVER['REQUEST_URI']);
		$tanzlink = "tanzsaal.php?op=auffordern&id=" . $row['acctid'];
		addnav("", $biolink);
		addnav("", $tanzlink);
		output("<tr class=" . ($i % 2 ? "trlight" : "trdark") . "'><td>" . $row['name'] . "</td><td>" . $colraces[$row['race']] . "</td>", true);
		if ($geschlecht)
			output("<td align='center'>" . ($row['sex'] ? "<img src='images/female.gif' alt='weibl.'>" : "<img src='images/male.gif' alt='maennl.'>") . "</td>", true);
		if ($row['tanz_mode'] == 'hat')
			output("<td>Hat jemanden aufgefordert</td>", true);
		elseif ($row['tanz_mode'] == 'wurde')
			output("<td>Wurde aufgefordert</td>", true);
		else
			output("<td><i>Ist noch frei</i></td>", true);
		output("<td>[ <a href='" . $biolink . "'>Bio</a> " . ($row['tanz_mode'] == 'nichts' ? "| <a href='" . $tanzlink . "'>Tanzen</a> " : "") . "]</td></tr>", true);
	}
	output("</table>", true);
	addnav("zurück zum Saal", "tanzsaal.php");
	addnav("Nochmal sehen", "tanzsaal.php?op=suchen");
} elseif ($_GET['op'] == "tanzen") {
	$partner = partner();
	if ($partner['turns'] < 0) {
		output("`^Gerade willst du mit " . $partner['name'] . " `^zur Tanzfläche schreiten, als du bemerkst, das " . ($partner['sex'] ? "sie" : "er") . " nach all dem Kämpfen im Walde schon viel zu erschöpft ist.`n");
		output("Daher berschließt ihr euren Tanz auf später zu verschieben.");
	} else {
		output("`%Du und " . $partner['name'] . " `%habt nun endlich Zeit für einen Tanz gefunden und begebt euch gemeinsam auf die Tanzfläche.");
		output("Ihr beginnt euch zur Musik zu bewegen und werdet dabei immer schneller. Du fühlst dich außerordentlich gut dabei.`n");
		output("doch in der Freude geht alles so schnell vorbei, das du dich und " . $partner['name'] . " schon bald etwas erschöpft am Rand wiederfindest.");
		output("`nZufrieden blickst du " . $partner['name'] . " an und bedankst dich. Ihr versprecht euch, bald wieder einmla gemeinsam zu tanzen und geht dann.");
		addnav("Zurück un den Saal", "tanzsaal.php");
		addnav("Zurück ins Dorf", "village.php");
		$session['user']['turns']--;
		$session['user']['charm'] += $charmebonus;
		$session['user']['tanz_heute'] = 1;
		$session['user']['tanz_mode'] = 'nichts';
		$session['user']['tanz_partner'] = 0;
		$sql = "UPDATE `accounts` SET `charm` = `charm` + 1, `turns` = `turns` -1, `tanz_mode` = 'nichts', `tanz_partner` = 0 WHERE acctid = " . $partner['acctid'] . " LIMIT 1";
		db_query($sql) or die(db_error(LINK));
	}
} else {
	/* Eingang */
	output("`gDu betrittst den großen Tanzsaal. Überall siehst die verliebte oder befreundete Pärchen, die sich auf dem Parkett bewegen oder an einigen Tischen weiter hinten im Saal sitzten.`n");
	output("Etwas erhöht auf einer Bühne siehst du eine Hand voll Musiker, die ihren Instumenten die Klänge entlocken, zu denen getanzt wird.`n`n");
	output("Alles wirkt sehr festlich und dir wird bewusst, das du dich hier besser benehmen solltest.`n`n");
	if (checkdance() === false) {
		if ($session['user']['sex'] == 1) {
			output("`QMöchtest du nicht vieleicht nach einem hübschen Herren als Tanzpartner ausschau halten?`nOder traust du dich nicht und willst lieber wieder gehen?`n");
			if ($geschlecht)
				output("Du kannst es natürlich auch wagen, eine der Damen anzuprechen....");
		} else {
			output("`6Viele hübsche junge Damen laufen hier herum, möchtest du eine von ihnen zum Tanz auffordern, oder lieber verschwinden, ehe dich jemand sieht?`n");
			if ($geschlecht)
				output("Du kannst es natürlich auch wagen, einen der Herren anzusprechen....");
		}
		addnav("`4Einen Tanzpartner suchen", "tanzsaal.php?op=suchen");
	} elseif ($session['user']['tanz_mode'] == "wurde") {
		/* Tanzpartner hat User aufgefordert */
		$partner = partner();
		output("`9Als du dich gerade ein wenig umsiehst, bemerkst du, das jemand auf dich zukommt, den du als `@" . $partner['name'] . "`9 erkennst.`n");
		output(($partner['sex'] ? "Sie" : "Er") . " begrüßt dich höflich und fordert dich galant zu einem Tanz auf.");
		if ($session['user']['tanz_heute'] == 1 || $session['user']['turns'] < 1) {
			output("`n`i`^Doch du bemerkst, dass du heute schon viel zu erschöpft bist, um noch einmal zu tanzen.`i");
		} else {
			addnav("Annehmen", "tanzsaal.php?op=tanzen");
		}
		addnav("Absagen", "tanzsaal.php?op=absagen");
	} else {
		/* User hat Tanzpartner aufgefordert */
		$partner = partner();
		output("`^Gerade in diesem Moment fällt dir ein, das du ja noch eine Verabredung mit `@" . $partner['name'] . "`^ ausstehen hast.");
		output("Allerdings scheint " . ($partner['sex'] ? "sie" : "er") . " noch immer nicht hier zu sein. Kurz überlegst du, dir einen anderen Tanzpartner zu suchen...");
		addnav("Aktionen");
		addnav("`^" . $partner['login'] . "`0 absagen", "tanzsaal.php?op=absagen");
	} // Ende checkdance-Prüfung
	output("`n");
	viewcommentary("Tanzsaal", "Mit anderen Tänzern unterhalten", 20);
	addnav("Ausgang");
	addnav("Nach draußen ins Dorf", "village.php");
}
page_footer();
?>
