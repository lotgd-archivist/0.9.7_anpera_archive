<?php
// Klassen und Funktionen //
class house {
		// Wichtige:
	var $id, $besitzerid, $status, $name, $text;
		// Sonstige
	var $goldprice, $gemprice, $locid, $schatz_gold, $schatz_gems;
		// Arbeitsvariablen
	var $query;
	
	function house($data) {
		$this->einlesen($data);
	}	// Ende Funktion
	
	function einlesen($data) {
		global $schatz_id;
		$this->id 				=	$data['houseid'];
		$this->besitzerid = $data['owner'];
		$this->status 		= $data['status'];
		$this->name				= $data['housename'];
		$this->text				= $data['description'];
		
		$this->goldprice	= $data['goldprice'];
		$this->gemprice		= $data['gemprice'];
		$this->locid 			= $data['locid'];
		
		// Gold und Edelsteine Lesen //
			/* Gold */
		$sql = "SELECT `value` FROM `housemoduledata` WHERE houseid = ".$this->id." AND name = 'gold' AND moduleid = ".$schatz_id.";";
		$result = mysql_query($sql) or die(mysql_error()." In Zeile ".__LINE__);
		$row = mysql_fetch_assoc($result);
		$this->schatz_gold = $row['value'];
		unset($row); unset($result); unset($sql);
			/* Gems */
		$sql = "SELECT `value` FROM `housemoduledata` WHERE houseid = ".$this->id." AND name = 'gems' AND moduleid = ".$schatz_id.";";
		$result = mysql_query($sql) or die(mysql_error()." In Zeile ".__LINE__);
		$row = mysql_fetch_assoc($result);
		$this->schatz_gems = $row['value'];
	}	// Ende Funktion
	
	function sichern() {
		// �berpr�fung //
		if(empty($this->goldprice)) $this->goldprice = 30000;
		if(empty($this->gemprice)) 	$this->gemprice = 50;
		if(empty($this->locid)) 		$this->locid = 1;
		// Zusammensetzen des Querys //
		$this->query = 
		 "INSERT INTO `houses` (`houseid`,`owner`,`status`,`goldprice`,`gemprice`,`housename`,`description`,`locid`) VALUES "
		."(".$this->id.",".$this->besitzerid.",'".$this->status."',".$this->goldprice.",".$this->gemprice.",'".$this->name."','".$this->text."',".$this->locid.");";
	}	// Ende Funktion
}	// Ende Klasse

class haus {
		// Variablen:
	var $id, $besitzerid, $status, $gold, $gems, $name, $text, $level, $ausbauten;
	
	function haus($alte_daten) {
		$this->konvertieren($alte_daten);
	}	// Ende Funktion
	
	function konvertieren($data) {
			// Direkt �bernehmbare Daten:
		$this->id 				= $data->id;
		$this->besitzerid	= $data->besitzerid;
		$this->name				= $data->name;
		$this->text				= $data->text;
		
			// Fixe Datenwerte:
		$this->level 			= 6;
		$this->ausbauten	= '';
		
			// Aufw�ndigere Konvertierung:
		switch($data->status) {
			case 'build':	// Haus noch im Bau
			if($data->besitzerid == 0) {	// Bauruine
				$this->status = 4;
			}	else {											// Im Bau
				$this->status = 0;
			}
				$this->gold = $data->goldprice;
				$this->gems = $data->gemprice;
			break;
			
			case 'sell':
			$this->status = 2;
			if($data->besitzerid == 0) {	// Maklerverkauf
				// (noch) Nichts weiter...
				$this->gold = 0;
				$this->gems = 0;
			} else {											// Privatverkauf
				$this->gold = $data->goldprice;
				$this->gems = $data->gemprice;
			}
			break;
			
			case 'ready':
			if($data->besitzerid == 0) {	// Verlassen
				$this->status = 3;
			} else {											// Bewohnt
				$this->status = 1;
			}
			$this->gold = $data->schatz_gold;
			$this->gems = $data->schatz_gems;
			break;
		}	// Ende SWITCH
	}	// Ende Funktion
	
	function query() {
		$query = 
		 "INSERT INTO `houses` (`houseid`,`owner`,`status`,`gold`,`gems`,`housename`,`description`,`level`,`ausbauten`) VALUES "
		."(".$this->id.",".$this->owner.",".$this->status.",".$this->gold.",".$this->gems.",'".$this->name."','".$this->text."',".$this->level.",".$this->ausbauten.");\n";
		return $query;
	}	// Ende Funktion
}	// Ende Klasse

// Verbindung Aufbauen:	//
		// Test only:	//
require_once "dbconnect.php";
mysql_connect($DB_HOST,$DB_USER,$DB_PASS) or die("Fehler - Datenbankverbindung konnte nicht hergestellt werden: ".mysql_error());
mysql_select_db($DB_NAME) or die("Fehler - Datenbank konnte nicht ausgew�hlt werden: ".mysql_error());
// Sammeln der Daten	//
	/* Schatzkammer-Modul-ID ermitteln */
$sql = "SELECT `moduleid` FROM housemodules WHERE `modulename` = 'treasury'";
$result = mysql_query($sql) or die(mysql_error()." In Zeile ".__LINE__);
$row = mysql_fetch_assoc($result);
$schatz_id = $row['moduleid'];
	/* H�user */
$houses = array();
$sql = "SELECT * FROM houses ORDER BY houseid ASC";
$result = mysql_query($sql) or die(mysql_error()." In Zeile ".__LINE__);
for($i=0;$i < mysql_num_rows($result);$i++) {
	$row = mysql_fetch_assoc($result);
	$houses[$i] = new house($row);
}
// Sicherung der Daten //
$datei = tempnam("save/","save");
$base = basename($datei);
$path = substr($datei,0,(strlen($datei) - strlen($base)));
$lotgd =  substr(realpath("./special"),0,strlen(realpath(""))+1);
if(file_exists($lotgd."save.sql")) unlink($lotgd."save.sql");
rename($datei,$lotgd."save.sql");
unset($datei);
$dateiname = $lotgd."save.sql";
$datei = fopen($dateiname,"w") or die("Fehler - konnte Datei nicht �ffnen!");
fwrite($datei,"#\n# Daten der Haeuser selbst:\n#\n");
for($i=0;$i< count($houses);$i++) {
	$houses[$i]->sichern();
	fwrite($datei,$houses[$i]->query."\n");
}
$d_sql = "SELECT * FROM `housemoduledata` ORDER BY `moduleid` ASC";
$d_result = mysql_query($d_sql) or die(mysql_query());
fwrite($datei,"#\n# Daten der Module:\n#\n");
for($i=0;$i < mysql_num_rows($d_result);$i++) {
	$d_row = mysql_fetch_assoc($d_result);
	$d_query = "INSERT INTO `housemoduledata` VALUES (".$d_row['moduleid'].",'".$d_row['name']."',".$d_row['houseid'].",'".$d_row['value']."');";
	fwrite($datei,$d_query."\n");
}
fwrite($datei,"#\n# ENDE - EoF\n#");
echo "<a href='".basename($dateiname)."'>Hier k�nnen Sie die Sicherungsdatei herunterladen</a> - im Notfall Rechtsklick->Ziel Speichern unter verwenden<br>"; 
fclose($datei);
// L�schen der Alten Tabellen //

mysql_query("DROP TABLE `houses`,`housemoduledata`") or die(mysql_error()." In Zeile ".__LINE__);

// Anlegen von neue Tabellenstrukturen und einlesen von Standardwerten //

$sql = <<<SQL
CREATE TABLE `houses` (
  `houseid` int(11) unsigned NOT NULL,
  `owner` int(11) unsigned NOT NULL default '0',
  `status` int(10) unsigned NOT NULL default '0',
  `gold` int(10) unsigned NOT NULL default '0',
  `gems` int(10) unsigned NOT NULL default '0',
  `housename` varchar(25) default NULL,
  `description` text NOT NULL,
  `level` smallint(6) default '0',
  `ausbauten` varchar(255) default '',
  PRIMARY KEY  (`houseid`)
);

CREATE TABLE `hauslevels` (
  `level` tinyint(3) unsigned NOT NULL auto_increment,
  `name` varchar(32) default NULL,
  `gold` mediumint(9) default NULL,
  `gems` smallint(6) default NULL,
  `keys` tinyint(4) default NULL,
  `goldchest` mediumint(9) default NULL,
  `gemschest` smallint(6) default NULL,
  `zimmer` smallint(6) unsigned default 0,
  PRIMARY KEY  (`level`),
  UNIQUE KEY `name` (`name`)
);

CREATE TABLE `zimmer` (
  `zimmerid` smallint(5) unsigned NOT NULL auto_increment,
  `name` varchar(32) default NULL,
  `link` varchar(128) default NULL,
  `label` varchar(32) NOT NULL,
  `level` tinyint(3) unsigned NOT NULL default '1',
  `aktiv` tinyint(3) unsigned NOT NULL default '0',
  `gold` mediumint unsigned not null default '0',
  `gems` smallint unsigned not null default '0',
  PRIMARY KEY  (`zimmerid`),
  UNIQUE KEY `label` (`label`)
);

INSERT INTO `zimmer` VALUES (1, 'gemeinschaftsraum', 'nhouses.php?op=drin&go=gemeinschaftsraum', 'Gemeinschaftsraum', 1, 1, 0, 0);

INSERT INTO `settings`(`setting`,`value`) VALUES ('zimmerausnahmen','office schatz schlafzimmer');

INSERT INTO `hauslevels` VALUES (1, '`TVerschlag`0', 0, 0, 3, 0, 15000, 25);
INSERT INTO `hauslevels` VALUES (2, '`2H�uschen`0', 1000, 2, 4, 1, 17500, 30);
INSERT INTO `hauslevels` VALUES (3, '`%Haus`0', 1500, 3, 5, 2, 22500, 35);
INSERT INTO `hauslevels` VALUES (4, '`QGeh�ft`0', 2500, 5, 7, 3, 27500, 45);
INSERT INTO `hauslevels` VALUES (5, '`vLandgut`0', 5000, 10, 9, 5, 35000, 60);
INSERT INTO `hauslevels` VALUES (6, '`4Schl�sschen`0', 10000, 20, 10, 7, 50000, 75);
INSERT INTO `hauslevels` VALUES (7, '`$Jagtschloss`0', 20000, 35, 12, 10, 75000, 100);
SQL;
mysql_query($sql) or die(mysql_error()." In Zeile ".__LINE__);

// Konvertierung und Bildung des Querys //
$sql = "";
for($i=0;$i< count($houses);$i++) {
	$haus[$i] = new haus($house[$i]);
	$sql .= $haus[$i]->query();
}
// Daten neu einlesen //
mysql_query($sql) or die(mysql_error()." In Zeile ".__LINE__);
// Abschluss
echo "<br>So, das ganz scheint ja schon mal soweit geklappt zu haben! Falls die neuen Dateien noch nicht hochgeladen sind das jetzt bitte tun.<br>";
echo "Danach sollte das Wohnviertel f�r gew�hnlich komplett \"umgezogen\" sein - Kleiner Nachteil: Alle besherigen H�user wurden nun auf Level 6 gesetzt, damit die Anzahl der Schl�ssel stimmt. Dieser Bug l�sst sich alelrdings nicht beheben.";
echo "Wenn alles funktioniert k�nnen sie dann die verbliebenen Tabelen per 'DROP TABLE `houseconfig`, `housemodules`;' entfernen!<br><br>";
echo "Ich hoffe Sie finden Gefallen an meinem Wohnviertel,<br>Auric <b>@</b> <a href='http://www.tharesia.de'>Tharesia.de</a>";
?>