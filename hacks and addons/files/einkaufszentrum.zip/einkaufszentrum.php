<?
require_once "common.php";
addcommentary();
page_header("Marktplatz");
	output("`c`b`QEingangstor`c`b`n`n");
	output("`gDu kommst durch ein gro�es Tor auf einen Platz der voller Menschen ist, die dich nicht beachten.");
	output("Du schlenderst ein wenig herum und st��t plt�zlich auf einen gro�en Felsen in den die");
	output("verschiedenen Pl�tze mit ihren verschiedenen L�den eingemei�elt sind.`n");
	output("`c1. Platz, der Handel mit Waffen und R�stungen, hier ist auch der Wahrsager.`c`n");
	output("`c2. Platz, das aufbewahren anderer Leutes Goldst�cke ist hier die Aufgabe der L�den`c`n");
	output("`c3. Platz, hier sind alle Gilden zu finden.`c`n`n`n`n");

addnav("L�den");
addnav("1. Platz");
if (getsetting("vendor",0)==1) addnav("Wanderh�ndler","vendor.php");
addnav("W?MightyEs Waffen","weapons.php");
addnav("R?Pegasus R�stungen","armor.php");
addnav("Maegus Kleider","kleidung.php");
addnav("Z?Zigeunerzelt","gypsy.php");
if (@file_exists("pavilion.php")) addnav("P?Auff�lliger Pavilion","pavilion.php");
addnav("2. Platz");
addnav("B?Die alte Bank","bank.php");
addnav("3. Platz");
addnav("Gildenstrasse","gildenstrasse.php");
addnav("Sonstiges");
addnav("zum Schloss","schloss.php");
addnav("Zur�ck zum Dorf","village.php");
	output("`n`n`%`@In der n�he reden ein paar charaktere: `n");
	viewcommentary("einkaufszentrum","Auf `$ Rollenspiel`@ gerechte Kommentare Achten!",20);
page_footer()
?>