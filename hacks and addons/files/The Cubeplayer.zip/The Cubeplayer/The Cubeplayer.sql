ALTER TABLE accounts
ADD win INT(11) NOT NULL default 0,
ADD lost INT(11) NOT NULL default 0,
ADD zuege TINYINT(5) NOT NULL default 0;