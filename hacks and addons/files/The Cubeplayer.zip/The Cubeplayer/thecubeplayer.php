<?php
# Coded by MySql - Blood�

require_once 'common.php';

page_header('Der W�rfelspieler');

function nav($what) 
   {
   	global $session;
   	switch($what)
   	 {
   	  case 'spielt':
	  if ($session['user_wuerfel'] == $session['npc_wuerfel'])
	   {
	      addnav('Unentschieden');
		  addnav('Weiter','thecubeplayer.php?op=spielen&act=user');
		  output('`n`nMIST! Unentschieden.');
		  $session['drawn']++;
		  $session['user_wuerfel']=0;
		  $session['npc_wuerfel']=0;	
	}else	   
	  if ($session['user_wuerfel'] <= $session['npc_wuerfel'])
	   {
		  addnav('Du verlierst');
		  addnav('Weiter','thecubeplayer.php?op=spielen&act=user');
		  output('HAHAHAHAHAHAHAHAHAHAHAHAHAHAHA! Ich wusste das du verlieren w�rdest!');
		  $session['lost']++;
		  $session['user_wuerfel']=0;
		  $session['npc_wuerfel']=0;
	}else
	  if ($session['user_wuerfel'] >= $session['npc_wuerfel'])
	   {
		  addnav('Du gewinnst');
		  addnav('Weiter','thecubeplayer.php?op=spielen&act=user');
		  output('NEIN! Du hast geschummelt! GIB ES ZU! So eine schande. *schlurz*');
		  $session['win']++;
		  $session['user_wuerfel']=0;
		  $session['npc_wuerfel']=0;
	}
	  break;
	  case 'ende';
	  if ($session['win'] == 3)
	   {
		  addnav('Spiel gewonnen');
		  addnav('Weiter','thecubeplayer.php');
		  output('Du hast 3 mal gesiegt. Hol dir deinen Preis ab.`n`n');
		  output('Als du dem W�rfelspieler sagst, das du deinen Preis haben willst, schnaubt er dich an und wirft dir einen Betel entgegen.`n
		          Als du ihn �ffnest findest du ');
		  $gold = getsetting("wuerfel_gold",0);
		  $gems = getsetting("wuerfel_gems",0);
		  output($gold.' Goldst�cke und '.$gems.' Edelsteine.');
		  $session['user']['gold']+=getsetting("wuerfel_gold",0);
		  $session['user']['gems']+=getsetting("wuerfel_gems",0);
		  savesetting("wuerfel_gold",200);
		  savesetting("wuerfel_gems",1);
		  $win = $session['win']+$session['lost'];
		  $end = $win+$session['drawn'];
		  $session['user']['zuege']=$end;
		  $session['user']['win']++;
		  $session['win']=0;
		  $session['lost']=0;
		  $session['drawn']=0;
	}
	  if ($session['lost'] == 3)
	   {
	      addnav('Spiel verloren');
		  addnav('Weiter','thecubeplayer.php');
		  output('Du hast leider 3 mal verloren....');
		  $win = $session['win']+$session['lost'];
		  $end = $win+$session['drawn'];
		  $session['user']['zuege']=$end;
		  $session['user']['lost']++;
		  $session['win']=0;
		  $session['lost']=0;
		  $session['drawn']=0;	
	}
	  break;
	  case 'general':
	  addnav('Der W�rfelspieler');
	  addnav('Spielen','thecubeplayer.php?op=check');
	  addnav('Die besten','thecubeplayer.php?op=list&act=thebest');
	  addnav('Zur Schencke','inn.php');
	  break;
   }	
}

switch ($_GET['op'])
    {
    	case '':
                nav(general);		
                output('Du betrittst ein hinter Zimmer vom Eberkopf und findest dort den "W�rfelspieler".
				        Er sieht dich an und fragt dich ob du dir die Liste der besten Spieler ansehen willst
						oder die der schlechtesten. Oder ob du gegen Ihn spielen willst.');
		break;
		case 'check':
		             addnav('Aktionen');
		             output('Ein Spiel kostet 200 Goldst�cke und 1 Edelstein.');
		             if ($session['user']['gold'] < 200 || $session['user']['gems'] <1)
		              {
						 output('`nDoch leider hast du entweder zu wenig Gold dabei, oder dein Edelsteinvorat ist aufgebraucht!');
						 addnav('Zur�ck','thecubeplayer.php');
					}
					else{
						 savesetting("wuerfel_gold",(string)(getsetting("wuerfel_gold",0)+ (200)));
						 savesetting("wuerfel_gems",(string)(getsetting("wuerfel_gems",0)+ (1)));
						 $session['user']['gold']-=200;
						 $session['user']['gems']-=1;
						 output('Es wurde bezahlt. Du darfst nun gegen mich spielen.');
						 addnav('Spiel starten','thecubeplayer.php?op=spielen&act=user');
					}
		break;
		case 'spielen':
		     switch ($_GET['act'])
		         {
					 case 'user':
					             if ($session['lost'] < 3 && $session['win'] <3)
					              {
					                 output('Du sch�ttelst die W�rfel. Du sch�ttelst und sch�ttelst. Als du die W�rfel fallen l�sst,
									         siehst du das du eine ');
									 $wuerfelt = e_rand(1,6);
									 output($wuerfelt.' gew�rfelt hast.`n`n');
                                  rawoutput('<div align="center"><img src="images/The_Cubeplayer/wuerfel-'.$wuerfelt.'.jpg"></div>');
								     output('`n`nJetzt ist der W�rfelspieler an der Reihe. Hoffentlicht wirft er keine h�here Zahl als du!');
									 addnav('Aktionen');
									 addnav('Weiter','thecubeplayer.php?op=spielen&act=npc');
									 $session['user_wuerfel']=$wuerfelt;									 
					              }
					              else{
								       nav(ende);	
								  }
					 break;
					 case 'npc':
					            output('Auch der W�rfelspieler sch�ttelt was das Zeug h�lt. Als er die W�rfel fallen l�sst. Beugt er sich vor und
								        schaut sich seine Zahl an.`n`n');
								$wuerfelt = e_rand(1,6);
                             rawoutput('<div align="center"><img src="images/The_Cubeplayer/wuerfel-'.$wuerfelt.'.jpg"></div>');
                                output('`n`nUnd er hat eine '.$wuerfelt.' geworfen.`n`n');
                                $session['npc_wuerfel']=$wuerfelt;
                                nav(spielt);
                    break;
				}
		break;
		case 'list':
		            switch($_GET['act'])
		                {
							case 'thebest':
							                output('`cDie besten W�rfelspieler der Stadt!`c`n`n');
							               	$select = "SELECT name,zuege,win FROM accounts WHERE win > 0 ORDER BY win DESC LIMIT 10";
											$result = Db_Query($select);
											
											rawoutput('<table cellpadding=3 cellspacing=1 border=0 bgcolor="#FFFFFF" align="center">'.
											          '<tr class="trhead">'.
													  '<td align="center">Name</td>'.
													  '<td align="center">Siege</td>'.
													  '<td align="center">Z�ge</td>'.
													  '</tr>'
													 );
											while ($gebaus = Db_Fetch_Assoc($result))
											  {
												   output("<tr class='".($i%2?"trdark":"trlight")."'>".
												          "<td>{$gebaus['name']}</td>".
														  "<td>{$gebaus['win']}</td>".
														  "<td>{$gebaus['zuege']}</td>".
														  "</tr>"
													,true);
											}
											nav(general);
							break;          
						}
}   
page_footer();
?>