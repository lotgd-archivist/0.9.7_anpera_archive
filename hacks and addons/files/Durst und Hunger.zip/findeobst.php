<?php
/*
                                �@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@�
                                �                                                      �
                                �  Idee und Umsetzung                                  �
                                �  Morpheus aka Apollon                                �
                                �  2006 f�r Morpheus-Lotgd.de                          �
                                �  Verbesserungen in 2008                              �
                                �  Mail to Morpheus@magic.ms or Apollon@magic.ms       �
                                �  gewidmet meiner �ber alles geliebten Blume          �
                                �                                                      �
                                @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
*/
output("`3Du kommst an einer `2Wiese `3vorbei, auf der `TB�u`2me `3mit `@Ob`4st `3wachsen, die ideale Erg�nzung f�r Deinen `^Essensvorrat`3!`nDu nimmst Dir einen Moment Zeit und pfl�ckst etwas davon.");
switch(e_rand(1,3)){
	case 1:
	$session[user][hungry]+=3;
	break;
	case 2:
	$session[user][hungry]+=5;
	break;
	case 3:
	$session[user][hungry]+=8;
	break;
	}
addnews($session[user][name]." `3fand im Wald eine `2Wiese `3mit `2Obstb�umen`3.`0");
debuglog("found food in the forest");
?>