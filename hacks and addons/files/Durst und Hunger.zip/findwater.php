<?php
/*
                                �@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@�
                                �                                                      �
                                �  Idee und Umsetzung                                  �
                                �  Morpheus aka Apollon                                �
                                �  2006 f�r Morpheus-Lotgd.de                          �
                                �  Mail to Morpheus@magic.ms or Apollon@magic.ms       �
                                �  gewitmet meiner �ber alles geliebten Blume          �
                                �                                                      �
                                @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
*/
output("`3Du kommst zu einem m�chtigen `7Felsen`3, aus dem eine `#Quelle `3sprudelt. Das k�stliche `#Wasser `3ist eine ideale Gelegenheit, Deine `^Wasservorr�te `3zu erg�nzen, und so f�llst Du Dir etwas davon ab.");
switch(e_rand(1,3)){
	case 1:
	$session[user][thirsty]+=5;
	break;
	case 2:
	$session[user][thirsty]+=8;
	break;
	case 3:
	$session[user][thirsty]+=10;
	break;
	}
addnews($session[user][name]." `3fand im `2Wald `3eine `#Quelle`3.`0");
debuglog("found water in the forest");
?>