<?
/*
Sir Keith's Rations v1.0 
Author: bwatford
Board: http://www.ftpdreams.com/lotgd
Date: 03-2004
Drop this in your main folder.
�bersetzt von Morpheus
*/

require_once "common.php";
checkday(); 
if ($HTTP_GET_VARS[op]==""){
$food=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*25;
$weekfood=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*25*5;
$water=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*15;
$weekwater=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*15*5;
page_header("Sir Keith's Rationen Shop");
addnav("Navigation");
addnav("Z?Zurueck zum Dorf","village.php");
addnav("Aktionen");
addnav("Essensrationen kaufen","groceries.php?op=food");
addnav("Wasserrationen kaufen","groceries.php?op=water");
output("`b`n`n`c`bSir Keith's Rationen Shop`b`c`n`n");
output("`@Du betrittst den kleinen Laden, in dem es bereits von Kunden wimmelt. Alle haben sich ihre Rationen gekauft und ihre Buendel gepackt, fertig, fuer einen langen Tag im Wald!`@`n`n");
output("`@Ein Mann mittleren Alters mit einem Holzbein kommt auf Dich zu 'Sei willkommenin meinem Rationenshop, mein Name ist Sir Keith. Wie kann ich Dir helfen?`@`n`n");
}

if ($HTTP_GET_VARS['op']=="food"){
$food=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*25;
$weekfood=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*25*5;
page_header("Essensrationen kaufen");
output("`n`n`c`bEssensrationen kaufen`b`c`n`n");
output("`@`c'Ich habe verschieden grosse Essensrationen fuer Krieger da' preist Sir Keith Dir an.Die Auswahl ist folgende:`n`n`c");
$food=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*25;
$weekfood=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*25*5;
output("1 Tagesration = ".$food." gold`n");
output("1 Wochenration = ".$weekfood." gold");
addnav("Auswahl");
addnav("Zurueck zum Laden","groceries.php");
addnav("Einkaufs Menue");
addnav("Kaufe 1 Tagesration Essen","groceries.php?op=payfoodday");
addnav("Kaufe 1 Wochenration Essen","groceries.php?op=payfoodweek");

}

if ($HTTP_GET_VARS['op']=="payfoodday"){
$food=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*25;
page_header("Essensrationen kaufen");
output("`n`n`c`bEssensrationen kaufen`b`c`n`n");
if ($session[user][hungry]>=100){
output("`@`c'Du hast bereits Deine maximalen Tagesrationen Essen' erklaert dir Sir Keith.`@`c`n`n");
addnav("Auswahl");
addnav("Zurueck zum Laden","groceries.php");
   }else{
if ($session[user][gold]<$food){
output("`@`c'Du hast leider nicht genug Gold.' sagt Sir Keith.`@`c`n`n");
addnav("Auswahl");
addnav("Zurueck zum Laden","groceries.php");
   }else{
output("`@`cSir Keith nimmt Deine Bestellung entgegen und gibt sie Dir mit einem freundlichen laecheln.`@`c`n`n");
output("`^Du erhaelst 1 Tagesration Essen`^`n`n");
addnav("Auswahl");
addnav("Zurueck zum Laden","groceries.php");
$session[user][hungry]+=10;
$session[user][gold]-=$food;

}
}
}

if ($HTTP_GET_VARS[op]=="payfoodweek"){
$weekfood=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*25*5;
page_header("Essensrationen kaufen");
output("`n`n`c`bEssensrationen kaufen`b`c`n`n");
if ($session[user][hungry]>=100){
output("`@`c'Du hast bereits Deine maximalen Wochenrationen Essen' erklaert dir Sir Keith.`@`c`n`n");
addnav("Auswahl");
addnav("Zurueck zum Laden","groceries.php");
   }else{
if ($session[user][gold]<$weekfood){
output("`@`c'Du hast leider nicht genug Gold.' sagt Sir Keith.`@`c`n`n");
addnav("Auswahl");
addnav("Zurueck zum Laden","groceries.php");
   }else{
output("`@`cSir Keith nimmt Deine Bestellung entgegen und gibt sie Dir mit einem freundlichen laecheln.' Sir Keith .`@`c`n`n");
output("`^Du erhaelst 1 Wochenartion Essen, die 7 Tage reicht`^`n`n");
addnav("Auswahl");
addnav("Zurueck zum Laden","groceries.php");
$session[user][hungry]+=70;
$session[user][gold]-=$weekfood;

}
}
}

if ($HTTP_GET_VARS[op]=="water"){
$water=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*15;
$weekwater=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*15*5;
page_header("Wasserrationen kaufen");
output("`n`n`c`bWasserrationen kaufen`b`c`n`n");
output("`@`c'Ich habe verschieden grosse Wasserrationen fuer Krieger da' preist Sir Keith Dir an.Die Auswahl ist folgende:`n`n`c");
output("1 Tagesration Wasser = ".$water." gold`n");
output("1 Wochenration Wasser = ".$weekwater." gold");
addnav("Auswahl");
addnav("Zurueck zum Laden","groceries.php");
addnav("Einkaufs Menue");
addnav("1 Tagesration Wasser kaufen","groceries.php?op=paywaterday");
addnav("1 Wochenration Wasser kaufen","groceries.php?op=paywaterweek");

}

if ($HTTP_GET_VARS[op]=="paywaterday"){
$water=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*15;
page_header("Wasserrationen kaufen");
output("`n`n`c`bWasserrationen kaufen`b`c`n`n");
if ($session[user][thirsty]>=50){
output("`@`c'Du hast bereits Deine maximalen Tagesrationen Wasser' erklaert dir Sir Keith.`@`c`n`n");
addnav("Auswahl");
addnav("Zurueck zum Laden","groceries.php");
   }else{
if ($session[user][gold]<$water){
output("`@`c'Du hast leider nicht genug Gold.' sagt Sir Keith.`@`c`n`n");
addnav("Auswahl");
addnav("Zurueck zum Laden","groceries.php");
   }else{
output("`@`cSir Keith nimmt Deine Bestellung entgegen und gibt sie Dir mit einem freundlichen laecheln.'`@`c`n`n");
output("`^Du erhaelst ein Wasserration fuer einen Tag`^`n`n");
addnav("Auswahl");
addnav("Zurueck zum Laden","groceries.php");
$session[user][thirsty]+=5;
$session[user][gold]-=$water;

}
}
}

if ($HTTP_GET_VARS[op]=="paywaterweek"){
$weekwater=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*15*5;
page_header("Wasserrationen kaufen");
output("`n`n`c`bWasserrationen kaufen`b`c`n`n");
if ($session[user][thirsty]>=50){
output("`@`c'Du hast bereits Deine maximalen Wochenrationen Wasser' erklaert dir Sir Keith.`@`c`n`n");
addnav("Auswahl");
addnav("Zurueck zum Laden","groceries.php");
   }else{
if ($session[user][gold]<$weekwater){
output("`@`c'Du hast leidernicht genug Gold.' sagt Sir Keith.`@`c`n`n");
addnav("Auswahl");
addnav("Zurueck zum Laden","groceries.php");
   }else{
output("`@`cSir Keith nimmt Deine Bestellung entgegen und gibt sie Dir mit einem freundlichen laecheln.`@`c`n`n");
output("`^Du erhaelst eine Wasserration fuer 1 Woche, die 7 Tage haelt`^`n`n");
addnav("Auswahl");
addnav("Zurueck zum Laden","groceries.php");
$session[user][thirsty]+=35;
$session[user][gold]-=$weekwater;
}
}
}

page_footer();

?> 