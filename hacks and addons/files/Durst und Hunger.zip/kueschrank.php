<?php
/*
                                �@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@�
                                �                                                      �
                                �  Idee und Umsetzung                                  �
                                �  Morpheus aka Apollon                                �
                                �  2006 f�r Morpheus-Lotgd.de                          �
                                �  Mail to Morpheus@magic.ms or Apollon@magic.ms       �
                                �  gewidmet meiner �ber alles geliebten Blume          �
                                �                                                      �
                                @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
*/
require_once "common.php";
page_header("Der K�chenschrank");
checkday();
if($_GET['op']==""){
	$erat=($session['user']['eseila']/10);
	$eplatz=(14-$erat);
	output("`3Du �ffnest den K�chenschrank und siehst, da� sich noch `^$erat Tagesrationen Essen `3darin befinden und noch Platz f�r `^$eplatz Rationen `3ist, was m�chtest Du machen?");
	addnav("l?Essensrationen lagern","kueschrank.php?op=lager");
	addnav("m?Essensrationen mitnehmen","kueschrank.php?op=mit");
	addnav("Zur�ck zum Haus","houses.php?op=drin&module=");
}
if($_GET['op']=="lager"){
	$erat=($session['user']['eseila']/10);
	$eplatz=(14-$erat);
	$ehat=$session['user']['hungry'];
	$ehatr=($session['user']['hungry']/10);
        if ($ehat<10){
		output("`3Du hast momentan keine kompletten Essensrationen bei Dir, die Du lagern k�nntest.`n");
	}else{
		output("Du hast im Moment $ehatr komplette Essensrationen bei Dir, wieviel davon willst Du einlagern?`n");
		output("<form action='kueschrank.php?op=lager2' method='POST'><input name='store' id='store'><input type='submit' class='button' value='lagern'></form>",true);
		output("<script language='JavaScript'>document.getElementById('bet').focus();</script>",true);
		addnav("","kueschrank.php?op=lager2");
	}
	addnav("m?Essensrationen mitnehmen","kueschrank.php?op=mit");
	addnav("Zur�ck zum Haus","houses.php?op=drin&module=");
}
if ($_GET[op]=="lager2"){
	$store=$_POST[store];
	$erat=($session['user']['eseila']/10);
	$eplatz=(14-$erat);
	$ehat=$session['user']['hungry'];
	$ehatr=($session['user']['hungry']/10);
        if ($ehatr<$store){ 
		output("`3Du kannst nicht mehr Rationen einlagern, als Du bei Dir hast!`n");
        }elseif ($eplatz<$store){ 
		output("`3F�r so viel ist kein Platz mehr, es ist noch maximal f�r `^$eplatz `3Rationen Platz!`n");
        }else{
		output("`3Du legst `^$store `3Rationen in den Schrank.`n");
		$session['user']['eseila']+=($store*10);
		$session['user']['hungry']-=($store*10);
	}
	addnav("l?Essensrationen lagern","kueschrank.php?op=lager");
	addnav("m?Essensrationen mitnehmen","kueschrank.php?op=mit");
	addnav("Zur�ck zum Haus","houses.php?op=drin&module=");
}
if($_GET['op']=="mit"){
	$erat=($session['user']['eseila']/10);
	$eplatz=(14-$erat);
	$ehat=$session['user']['hungry'];
	$ehatr=($session['user']['hungry']/10);
        if ($erat<1){
		output("`3Du hast momentan keine Rationen gelagert, die Du mitnehmen k�nntest.`n");
	}else{
		output("`3Du hast im Moment `^$erat`3 Rationen im Schrank gelagert, wieviele willst Du mitnehmen?`n");
		output("<form action='kueschrank.php?op=mit2' method='POST'><input name='take' id='take'><input type='submit' class='button' value='nehmen'></form>",true);
		output("<script language='JavaScript'>document.getElementById('bet').focus();</script>",true);
		addnav("","kueschrank.php?op=mit2");
	}
	addnav("l?Essensrationen lagern","kueschrank.php?op=lager");
	addnav("Zur�ck zum Haus","houses.php?op=drin&module=");
}
if ($_GET[op]=="mit2"){
	$take=$_POST[take];
	$erat=($session['user']['eseila']/10);
	$eplatz=(14-$erat);
	$ehat=$session['user']['hungry'];
	$ehatr=($session['user']['hungry']/10);
        if ($erat<$take){ 
		output("`3Du kannst nicht mehr Rationen mitnehmen, als Du gelagert hast!`n");
	}elseif ($session['user']['hungry']>=100){ 
		output("`3Du hast bereits das Maximum an Rationen bei Dir!`n");
        }else{
		output("`3Du nimmst `^$take `3Rationen aus dem Schrank.`n");
		$session['user']['eseila']-=($take*10);
		$session['user']['hungry']+=($take*10);
	}
	addnav("l?Essensrationen lagern","kueschrank.php?op=lager");
	addnav("m?Essensrationen mitnehmen","kueschrank.php?op=mit");
	addnav("Zur�ck zum Haus","houses.php?op=drin&module=");
}
page_footer();
?>