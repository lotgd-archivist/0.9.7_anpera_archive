<?php
/*
                                �@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@�
                                �                                                      �
                                �  Idee und Umsetzung                                  �
                                �  Morpheus aka Apollon                                �
                                �  2006 f�r Morpheus-Lotgd.de                          �
                                �  Verbesserungen in 2008                              �
                                �  Mail to Morpheus@magic.ms or Apollon@magic.ms       �
                                �  gewidmet meiner �ber alles geliebten Blume          �
                                �                                                      �
                                @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
*/
require_once "common.php";
page_header("Onkel Toms kleiner Laden");
$go=$session['user']['gold'];
$es=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*22;
$wa=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*12;
$ves=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*16;
$vwa=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*8;
$haes=$session['user']['hungry']/10;
$hawa=$session['user']['thirsty']/5;
$ples=10-$haes;
$plwa=10-$hawa;
$mn=$session[user][name];
page_header("Onkel Toms kleiner Laden");
if($_GET['op']==""){
	output("`c`b`6Onkel Toms kleiner Laden`0`b`c");
	output("`n`n`3Du betrittst einen Raum, in dem lauter `TRegale `3an den W�nden stehen, im hinteren Bereich ist eine `tTheke `3zu sehen, hinter der ein �lterer, `7grauhaariger `^Elfe `3sich um die Kunden k�mmert, die vor der `tTheke `3ruhig warten, bis sie an der Reihe sind.`n`n");
	output("`3Geduldig stellst auch du Dich an, und als Du an der Reihe bist, strahlen Dich `22 gr�ne Augen `3an:\"`VAh, $mn`V, sei willkommen in meinem Laden, ich bin Heraldus Grandiosus Thomasius von Simahr, aber alle nennen mich einfach nur Onkel Tom`3\" sagt er l�chelnd.");
	output("`3\"`VIn meinem Laden kannst Du Essens- und Wasserrationen kaufen und verkaufen, sag, was kann ich denn f�r Dich tun?`3\"fragt er schelmisch l�chelnd, w�hrend er die kleine, runde Brille auf seiner Nase zurecht r�ckt.");
	if ($session['user']['dragonkills']==0){
		addnav("Essen");
		addnav("Tagesration Essen erbitten","onkeltom.php?op=esska");
		addnav("Wasser");
		addnav("Tagesration Wasser erbitten","onkeltom.php?op=waska");
	}else{
		addnav("Essen");
		addnav("Tagesration kaufen`n`^$es Gold","onkeltom.php?op=eska");
		addnav("Tagesration verkaufen`n`^$ves Gold","onkeltom.php?op=esve");
		addnav("Wasser");
		addnav("Tagesration kaufen`n`^$wa Gold","onkeltom.php?op=waka");
		addnav("Tagesration verkaufen`n`^$vwa Gold","onkeltom.php?op=wave");
	}
	addnav("Wege");
	addnav("Zur�ck zum Dorf","village.php");
}
if($_GET['op']=="eska"){
	output("`gOnkel Tom `3nickt freundlich mit dem Kopf:\"`VAber sehr gerne doch, eine Tagesration kostet `^$es Gold`3,`Vwieviel darf es denn sein?`n");
	output("`3Du blickst in Deinen `TVoratsbeutel `3und siehst, da� Du noch `^$haes Tagesrationen `3Essen besitzt und somit noch Platz f�r `^$ples Tagesrationen`3.");
	output("<form action='onkeltom.php?op=eska2' method='POST'><input name='take' id='take'><input type='submit' class='button' value='kaufen'></form>",true);
	output("<script language='JavaScript'>document.getElementById('bet').focus();</script>",true);
	addnav("","onkeltom.php?op=eska2");
	addnav("Essensrationen verkaufen","onkeltom.php?op=esve");
	addnav("Zur�ck zum Laden","onkeltom.php");
}
if ($_GET[op]=="eska2"){
	$take=$_POST[take];
	$cost=$take*$es;
        if ($go<$cost){ 
		output("`gOnkel Tom `3sch�ttelt den Kopf:\"`VIch f�rchte, so viel Gold hast Du nicht dabei, tut mir leid`3\".`n");
	}elseif ($take>$ples){ 
		output("`gOnkel Tom `3sch�ttelt den Kopf:\"`VIch f�rchte, so viel Platz hast Du nicht mehr, tut mir leid`3\".`n");
        }else{
		output("`gOnkel Tom `3nickt freundlich und gibt Dir `^$take Essensrationen`3, w�hrend du zu deinem Goldbeutel greifst und ihm die `^$cost Gold `3gibst.");
		$session['user']['gold']-=$cost;
		$session['user']['hungry']+=($take*10);
	}
	addnav("Essensrationen kaufen","onkeltom.php?op=eska");
	addnav("Essensrationen verkaufen","onkeltom.php?op=esve");
	addnav("Zur�ck zum Laden","onkeltom.php");
}
if($_GET['op']=="esve"){
        if ($haes<1){
		output("`3Du hast momentan keine kompletten `%Essensrationen `3bei dir, die du verkaufen k�nntest.`n");
	}else{
		output("`3Du hast im Moment `^$haes Essensrationen `3bei Dir, je Tagesration bekommst Du `^$ves Gold`3, wieviel davon m�chtest Du verkaufen?`n");
		output("<form action='onkeltom.php?op=esve2' method='POST'><input name='sell' id='sell'><input type='submit' class='button' value='verkaufen'></form>",true);
		output("<script language='JavaScript'>document.getElementById('bet').focus();</script>",true);
		addnav("","onkeltom.php?op=esve2");
	}
	addnav("Essensrationen kaufen","onkeltom.php?op=eska");
	addnav("Zur�ck zum Laden","onkeltom.php");
}
if ($_GET[op]=="esve2"){
	$sell=$_POST[sell];
	$get=$sell*$ves;
        if ($haes<$sell){ 
		output("`gOnkel Tom `3sch�ttelt lachend den Kopf:\"`VDu kannst mir doch nicht mehr Rationen verkaufen, als Du besitzt!`3\"`n");
        }else{
		output("`gOnkel Tom `3nickt freundlich mit dem Kopf, nimmt die `^$sell Essensrationen `3von dir entgegen, packt sie sorgsam weg und gibt Dir daf�r `^$get Gold`3, das Du in Deinen Goldbeutell steckst.`n");
		$session['user']['gold']+=$get;
		$session['user']['hungry']-=($sell*10);
	}
	addnav("Essensrationen kaufen","onkeltom.php?op=eska");
	addnav("Essensrationen verkaufen","onkeltom.php?op=esve");
	addnav("Zur�ck zum Laden","onkeltom.php");
}
if($_GET['op']=="waka"){
	output("`gOnkel Tom `3nickt freundlich mit dem Kopf:\"`VAber sehr gerne doch, eine Tagesration kostet `^$wa Gold`3,`Vwieviel darf es denn sein?`n");
	output("`3Du blickst in Deinen `9Voratskanister `3und siehst, da� Du noch `^$hawa Tagesrationen `9Wasser `3besitzt und somit noch Platz f�r `^$plwa Tagesrationen`3.");
	output("<form action='onkeltom.php?op=waka2' method='POST'><input name='take' id='take'><input type='submit' class='button' value='kaufen'></form>",true);
	output("<script language='JavaScript'>document.getElementById('bet').focus();</script>",true);
	addnav("","onkeltom.php?op=waka2");
	addnav("Wasserrationen verkaufen","onkeltom.php?op=wave");
	addnav("Zur�ck zum Laden","onkeltom.php");
}
if ($_GET[op]=="waka2"){
	$take=$_POST[take];
	$cost=$take*$wa;
        if ($go<$cost){ 
		output("`gOnkel Tom `3sch�ttelt den Kopf:\"`VIch f�rchte, so viel Gold hast Du nicht dabei, tut mir leid`3\".`n");
	}elseif ($take>$plwa){ 
		output("`gOnkel Tom `3sch�ttelt den Kopf:\"`VIch f�rchte, so viel Platz hast Du nicht mehr, tut mir leid`3\".`n");
        }else{
		output("`gOnkel Tom `3nickt freundlich und gibt Dir `^$take Wasserrationen`3, w�hrend du zu deinem Goldbeutel greifst und ihm die `^$cost Gold `3gibst.");
		$session['user']['gold']-=$cost;
		$session['user']['thirsty']+=($take*5);
	}
	addnav("Wasserrationen kaufen","onkeltom.php?op=waka");
	addnav("Wasserrationen verkaufen","onkeltom.php?op=wave");
	addnav("Zur�ck zum Laden","onkeltom.php");
}
if($_GET['op']=="wave"){
        if ($hawa<1){
		output("`3Du hast momentan keine kompletten `%Wasserrationen `3bei dir, die du verkaufen k�nntest.`n");
	}else{
		output("`3Du hast im Moment `^$hawa `9Wasserrationen `3bei Dir, je Tagesration bekommst Du `^$vwa Gold`3, wieviel davon m�chtest Du verkaufen?`n");
		output("<form action='onkeltom.php?op=wave2' method='POST'><input name='sell' id='sell'><input type='submit' class='button' value='verkaufen'></form>",true);
		output("<script language='JavaScript'>document.getElementById('bet').focus();</script>",true);
		addnav("","onkeltom.php?op=wave2");
	}
	addnav("Wasserrationen kaufen","onkeltom.php?op=waka");
	addnav("Zur�ck zum Laden","onkeltom.php");
}
if ($_GET[op]=="wave2"){
	$sell=$_POST[sell];
	$get=$sell*$vwa;
        if ($hawa<$sell){ 
		output("`gOnkel Tom `3sch�ttelt lachend den Kopf:\"`VDu kannst mir doch nicht mehr Rationen verkaufen, als Du besitzt!`3\"`n");
        }else{
		output("`gOnkel Tom `3nickt freundlich mit dem Kopf, nimmt die `^$sell `9Wasserrationen `3von dir entgegen, packt sie sorgsam weg und gibt Dir daf�r `^$get Gold`3, das Du in Deinen Goldbeutell steckst.`n");
		$session['user']['gold']+=$get;
		$session['user']['thirsty']-=($sell*5);
	}
	addnav("Wasserrationen kaufen","onkeltom.php?op=waka");
	addnav("Wasserrationen verkaufen","onkeltom.php?op=wave");
	addnav("Zur�ck zum Laden","onkeltom.php");
}
if($_GET['op']=="esska"){
	output("`gOnkel Tom `3nickt freundlich mit dem Kopf:\"`VAber sehr gerne doch, und weil Du ein Bauernkind bist, kosten sie Dich auch nichts. Wieviel darf es denn sein?`n");
	output("`3Du blickst in Deinen `TVoratsbeutel `3und siehst, da� Du noch `^$haes Tagesrationen `3Essen besitzt und somit noch Platz f�r `^$ples Tagesrationen`3.");
	output("<form action='onkeltom.php?op=esska2' method='POST'><input name='take' id='take'><input type='submit' class='button' value='kaufen'></form>",true);
	output("<script language='JavaScript'>document.getElementById('bet').focus();</script>",true);
	addnav("","onkeltom.php?op=esska2");
	addnav("Zur�ck zum Laden","onkeltom.php");
}
if ($_GET[op]=="esska2"){
	$take=$_POST[take];
	if ($take>$ples){ 
		output("`gOnkel Tom `3sch�ttelt den Kopf:\"`VIch f�rchte, so viel Platz hast Du nicht mehr, tut mir leid`3\".`n");
        }else{
		output("`gOnkel Tom `3nickt freundlich und gibt Dir `^$take Essensrationen`3, die Du entgegen nimmst, ihm freundlich dankst und sie weg packst.");
		$session['user']['hungry']+=($take*10);
	}
	addnav("Tagesration Wasser erbitten","onkeltom.php?op=waska");
	addnav("Zur�ck zum Laden","onkeltom.php");
}
if($_GET['op']=="waska"){
	output("`gOnkel Tom `3nickt freundlich mit dem Kopf:\"`VAber sehr gerne doch, und weil Du ein Bauernkind bist, kosten sie Dich auch nichts. Wieviel darf es denn sein?`n");
	output("`3Du blickst in Deinen `9Voratskanister `3und siehst, da� Du noch `^$hawa Tagesrationen `9Wasser `3besitzt und somit noch Platz f�r `^$plwa Tagesrationen`3.");
	output("<form action='onkeltom.php?op=waska2' method='POST'><input name='take' id='take'><input type='submit' class='button' value='kaufen'></form>",true);
	output("<script language='JavaScript'>document.getElementById('bet').focus();</script>",true);
	addnav("","onkeltom.php?op=waska2");
	addnav("Zur�ck zum Laden","onkeltom.php");
}
if ($_GET[op]=="waska2"){
	$take=$_POST[take];
	if ($take>$plwa){ 
		output("`gOnkel Tom `3sch�ttelt den Kopf:\"`VIch f�rchte, so viel Platz hast Du nicht mehr, tut mir leid`3\".`n");
        }else{
		output("`gOnkel Tom `3nickt freundlich und gibt Dir `^$take Wasserrationen`3, die Du entgegen nimmst, ihm freundlich dankst und sie weg packst.");
		$session['user']['thirsty']+=($take*5);
	}
	addnav("Tagesration Essen erbitten","onkeltom.php?op=esska");
	addnav("Zur�ck zum Laden","onkeltom.php");
}
page_footer();
?>