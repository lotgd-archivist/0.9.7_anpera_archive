<?php
//Idee und Umsetzung
//Morpheus aka Apollon & Lilith
//2006 f�r www.morpheus-lotgd.de.vu
//Mail to Morpheus@magic.ms
//gewidmet meiner �ber alles geliebten Blume
require_once "common.php";
page_header("Die Stadtwache");
if ($_GET['op']==""){
$badguy = array(
        "creaturename"=>"`4Stadtwache`0",
        "creaturelevel"=>$session[user][level]+1, 
        "creatureweapon"=>"`6Br`^ei`6ts`^ch`6we`^rt",
        "creatureattack"=>$session['user']['attack']+2,
        "creaturedefense"=>$session['user']['defence']+2,
        "creaturehealth"=>round($session['user']['maxhitpoints']*1.25,0),
	"diddamage"=>0);
    	$session[user][badguy]=createstring($badguy);
	$session['user']['specialinc']="";
$_GET['op']="fight";
}
if ($_GET['op']=="fight"){
	$battle=true;
}
if ($battle){
	include ("battle.php");
	if ($victory){		
		output("`nDu hast `^".$badguy['creaturename']." besiegt.`n`#So schnell Du kannst, l�ufst Du nun davon...");
		$badguy=array();
		$session[user][badguy]="";
		addnews("`0".$session[user][name]." `3besiegte die `4Stadtwache `3und konnte entkommen, als diese ihn verhaften wollte.`0");
		addnav("In die Stadt","village.php");
		addnav("In den Wald","forest.php");
	}elseif($defeat){
		output("`VDu wurdest von der Stadtwache besiegt! Du bist tot!");
		$session[user][hitpoints]=0;
		$session[user][specialinc]="";
		$session[user][reputation]-=5;
		$session[user][bounty]=0;
		addnews("`0".$session[user][name]." `3wurde von der `4Stadtwache `3besiegt, als er versuchte, durch einen Kampf der Verhaftung zu entkommen.");
		addnav("T�gliche News","news.php");
	}else{
		fightnav();
	}
}
page_footer();
?>