<?php 
/*
********************************************************************************
*                                                                              *
*Shanas Kondomladen f�r Midgars Freudenhaus --> www.logd-midgar.de             *
*Idee: Shana hat ne ganze weile im Ot von Midgar Kondome per Bauchladen        *
*verkauft. Das ist fast ein Jahr schon her und Shana hat sich weiter           *
*entwickelt. Nun hat sie keinen Bauchladen sondern ein Ladenlokal in           *
*Midgars Freudenhaus. Viel Spass beim einkaufen ;) Ach ja, ihr k�nnt den       *
*Namen  des Dorfes �ndern aber lasst bitte den Namen der Verk�uferin drin.     *
*Vielen Dank.                                                                  *
*Verbrochen von: mfs                                                           *
*Texte von: Shana                                                              *
*Repariert von:  Taikun                                                              *
*SQL:                                                                          *
*ALTER TABLE `accounts` ADD `kondom` tinyint(4) unsigned NOT NULL default '0';
*Newday.php
*$session['user']['kondom'] = 0;
*                                                                              *
********************************************************************************
*/
 
require_once "common.php";
page_header("Shanas Kondomladen");
$maxhp=$session[user][maxhitpoints];
if($_GET['op']==""){
output("`rDu betrittst das Freudenhaus Midgars und gleich zu deiner rechten Seite f�llt dir ein goldenes gl�nzendes
Schild ins Auge, auf dem in geschwungenen Lettern geschrieben steht: '`%Shanas Kondoml�dchen`r'
Neugierig n�herst du dich dem kleinen putzigen Gesch�ft. Ist das die selbe Shana, die fr�her mit ihrem Bauchladen durch
Midgar streifte und laut schreiend ihre Waren feilbot? Neugierig gehst du n�her und musst feststellen, das sie es
wirklich ist. Noch immer hast du ihr fr�hliches Gebr�ll in den Ohren: '`%Du wolle Kondome kaufe? Preiswert aber nich
billisch! Kondome aus Jute f�r de kleine Goldbeutel. M�usedarmkondome f�r de winzig Schnibbel. Schafsdarmkondome mit de
L�cher f�r de kinderwilligen P�rchen. Rinddarmkondome gef�hlsecht. Pferdedarmkondome f�r den schnellen Galopp.
Lammdarmkondome mit de Hasenk�ttel wegen de Noppen. Dinodarmkondome f�r de Saferscheksch. H�hnchenknochenverst�rkte
Kondome f�r de Knickschnibbel. Zitteraalkondom f�r de prickelnde Scheksch. Drachendarmkondom wenn's feurig werden soll.'
`rDu bist noch ganz in deinen Gedanken versunken, als du eine melodische Stimme wahrnimmst, die deinen Ohren zu schmeicheln
scheint. Aus einem kleinen Hinterraum kommt Shana mit sanft wiegenden H�ften n�her. Dich freundlich anl�chelnd fragt sie: 'Wie kann ich Euch behilflich sein? Schaut Euch nur in Ruhe um. Es sollte gen�gend Auswahl f�r Euch vorhanden
sein.' Dann wendet sie sich diskret wieder ab, damit du dich in Ruhe umschauen kannst. Willst du dir hier ein paar
Kondome einkaufen oder lieber nicht?");

addnav("Jutesackkondom - 100 Gold","kondom.php?op=jute");
addnav("M�usedarmkondom - 150 Gold","kondom.php?op=maus");
addnav("Schafsdarmkondom - 350 Gold","kondom.php?op=schaf");
addnav("Rindsdarmkondom - 800 Gold","kondom.php?op=rind");
addnav("Hengstdarmkondom - 1000 Gold","kondom.php?op=hengst");
addnav("Lammdarmkondom - 1300 Gold","kondom.php?op=lamm");
addnav("Dinodarmkondom - 1350 Gold","kondom.php?op=dino");
addnav("Knochenkondom - 1700 Gold","kondom.php?op=knochen");
addnav("Zitteraalkondom - 2500 Gold","kondom.php?op=aal");
if ($session[user][level]==15){
addnav("Drachendarmkondom - 3500 Gold","kondom.php?op=drache");
   }
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
addnav("Nach Midgar","village.php");
}

if ($_GET['op']=="jute"){
if ($session[user][gold]<100){
output("`rDu glaubst doch nicht etwa, dass du hier etwas geschenkt bekommst? Das kannst du dir das nicht leisten!");
addnav("Kondomladen","kondom.php");
}else{
$session[user][gold]-=100;
switch(e_rand(1,3)){
case 1:
output("`rShana reicht dir im Austausch gegen das Gold ein in bunten Stoff eingewickeltes P�ckchen. Du schaust neugierig
hinein und entdeckst Nichts!. Da du dich nicht traust, diese Frau des Betruges zu bezichtigen, sagst du nichts dazu.");
$session[user][kondom]+=1;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;
case 2:
output("`rShana reicht dir im Austausch gegen das Gold ein in bunten Stoff gewickeltes P�ckchen. Du blickst hinein und
entdeckst ein brandneues Jutesackkondom. Du regenerierst um ein paar Lebenspunkte.");
$session[user][hitpoints]+=15;
$session[user][kondom]+=1;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;
case 3:
output("`rShana reicht dir im Austausch gegen das Gold ein in bunten Stoff gewickeltes P�ckchen. Du schaust hinein und
dir wird schlecht. Das Kondom war schon benutzt worden. B�H' Es ist feucht und glitschig gl�nzend. Du verlierst ein paar
Lebenspunkte.");
$session[user][hitpoints]*=0.90;
$session[user][kondom]+=1;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;
  }}}
if($_GET['op']=="maus"){
if($session[user][gold]<150){
output("`rDu glaubst doch nicht etwa, dass du hier was geschenkt bekommst? Das kannst du dir nicht leisten!");
addnav("Kondomladen","kondom.php");
}else{
$session[user][gold]-=150;
switch(e_rand(1,3)){
case 1:
output("`rDu gibst Shana dein Gold, woraufhin sie dir ein in bunten Stoff gewickeltes P�ckchen aush�ndigt. Du drehst es
einmal in deiner Hand und linst vorsichtig hinein. Deine Miene hellt sich bei dem Anblick des M�usedarmkondoms auf, du
wirkst ein wenig fitter - deine Lebenspunkte sind vollst�ndig
aufgef�llt.");
$session[user][hitpoints]=$maxhp;
$session[user][kondom]+=1;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;
case 2:
output("`rDu gibst Shana dein Gold, woraufhin sie  dir ein in bunten Stoff gewickeltes P�ckchen aush�ndigt. Du greifst
hinein und sp�rst etwas feuchtes, glitschiges an deinen Fingern. Ob das Kondom schon benutzt wurde? Dir ist nun so
schlecht, dass du einen Gro�teil deiner Lebenspunkte verlierst.");
$session[user][hitpoints]*=0.25;
$session[user][kondom]+=1;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;
case 3:
output("`rDu gibst Shana dein Gold, woraufhin sie dir ein in bunten Stoff gewickeltes P�ckchen aush�ndigt. Du blickst in
das P�ckchen und findest kein Kondom. Du grummelst zwar ein wenig, aber das bezaubernde L�cheln Shanas l�sst dich
vergessen, dass du w�tend bist. Dass du trotzdem w�tend wurdest, verursacht, dass du dich so elend f�hlst, dass du Waldk�mpfe
verlierst.");
$session[user][turns]-=4;
$session[user][kondom]+=1;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;
  }
 }
}
if($_GET['op']=="schaf"){
if($session[user][gold]<350){
output("`rDu glaubst doch nicht etwa, dass du hier was geschenkt bekommst? Das kannst du dir nicht leisten!");
addnav("Kondomladen","kondom.php");
}else{
$session[user][gold]-=350;
switch(e_rand(1,4)){
case 1:
output("`rDu �bergibst Shana die das gew�nschte Gold und sie schnippt dir ein in bunten Stoff gewickeltes P�ckchen zu,
welches du geschickt auff�ngst. Du nutzt deinen
Dolch, um den Stoff von dem P�ckchen zu l�sen, um dir das brandneue Schafsdarmkondom anzuschauen. Als du es 'erste' Mal
benutzt, steigt ein tolles Gef�hl in dir hoch, du f�hlst dich gut!");
$session['bufflist']['kondom'] =
     array("name"=>"`rGutes Gef�hl",
     "rounds"=>15,
     "wearoff"=>"`rDein gutes Gef�hl verschwindet.",
     "atkmod"=>1.2,
     "roundmsg"=>"`rDu f�hlst dich gut!",
     "activate"=>"offense");
$session[user][kondom]+=1;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;
case 2:
output("`rDu �bergibst Shana die 350 Gold und sie schnippt dir ein in bunten Stoff gewickeltes P�ckchen zu, welches du
geschickt auff�ngst. Du nutzt deinen Dolch, um den Stoff zu zweiteilen. Als du anf�ngst das Schafsdarmkondom zu
bestaunen, prickelt dein ganzer K�rper in freudiger Erwartung und du sp�rst die Kraft, die n�tig ist, um drei
weitere Monster zu erschlagen.");
$session[user][turns]+=3;
$session[user][kondom]+=1;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;
case 3:
output("`rDu �bergibst Shana die 350 Gold und sie schnippt dir ein in bunten Stoff gewickeltes P�ckchen zu, welches dir
zweimal knapp aus der Hand flutscht, bevor du es richtig zu fassen bekommst. Die Sukkubus betrachtet dich sp�ttisch,
w�hrend du den Stoff mit deinem Dolch nerv�s zwei Teile teilst. Du murrst ein wenig, als du das Schmunzeln Shanas
bemerkst. Dann drehst du dich auf dem Absatz um und verschwindest aus dem Gesch�ft. Aber da du so ungeschickt bist,
rutschst du auf einer offenen Gleitcremedose aus und blamierst dich bis auf die Knochen. Du wirst wohl mit dieser
Peinlichkeit leben m�ssen, zumindest f�r eine gewisse Zeit. Aufgrund deines Missgeschickes verlierst
du au�erdem einen Charmepunkt.");
$session['bufflist']['kondom'] =
     array("name"=>"`rPeinlichkeit",
     "rounds"=>10,
     "wearoff"=>"`rDas peinliche Gef�hl verschwindet.",
     "defmod"=>0.8,
     "roundmsg"=>"`rDu f�hlst dich etwas st�rker.",
     "activate"=>"offense");
$session[user][charm]--;
$session[user][kondom]+=1;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;
case 4:
output("`rDu �bergibst Shana die 350 Gold und sie schnippt  dir ein in bunten Stoff gewickeltes P�ckchen zu, welches du
auch geschickt f�ngst. Allerdings ist der Stoff nur lose um das P�ckchen befestigt und dein Schafdarmkondom f�llt auf
den Boden. Dr�hnendes Gel�chter hallt durch das Freudenhaus, weil deine Blamage sofort die Runde macht und du
verschwindest recht kleinlaut. Du hast durch dein tollpatschiges Verhalten ein wenig an Ansehen verloren.");
$session[user][reputation]-=20;
$session[user][kondom]+=1;
break;
  }
 }
}
if($_GET['op']=="rind"){
if($session[user][gold]<800){
output("`rDu glaubst doch nicht etwa, dass du hier was geschenkt bekommst? Das kannst du dir nicht leisten!");
addnav("Kondomladen","kondom.php");
}else{
$session[user][gold]-=800;
switch(e_rand(1,3)){
case 1:
output("`rDu �berreichst Shana das Gold, welches sie verlangt, bevor sie dir ein gro�es in bunten Stoff gewickeltes
P�ckchen her�berreicht.Du betrachtest das P�ckchen neugierig und �ffnest es. Eine gr�nliche Gaswolke steigt aus dem
P�ckchen auf. Nicht lange dauert es, dann kippst du um. Ein leises melodisches, aber auch h�hnisches Lachen ist das
Letzte, was du vernimmst, bevor du ohnm�chtig wirst. Du wachst nach Stunden wieder auf und bemerkst, dass dir 10
Edelsteine gestohlen wurden! Du f�hlst dich dar�ber hinaus noch sehr schwach und solltest einen Heiler aufsuchen, bevor
dich ein Monster t�tet.");
$session[user][gems]-=10;
$session[user][hitpoints]=1;
$session[user][kondom]+=1;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
addnews("`r{$session['user']['name']} w�re beinahe an einer gr�nen Gaswolke gestorben.");
break;

case 2:
output("`rDu �berreichst Shana das Gold, welches sie verlangt, bevor sie dir ein gro�es in bunten Stoff gewickeltes
P�ckchen her�berreicht. Du betrachtest das P�ckchen neugierig, �ffnest es aber eher zaghaft. Sofort durchstr�mt dich ein
tolles Gef�hl, weil du in freudiger Erwartung  bist, das Rinddarmkondom anzuwenden. Du f�hlst dich unbesiegbar STARK!
Zudem sp�rst du die Kraft f�r einen weiteren Waldkampf.");
$session['bufflist']['kondom'] =
     array("name"=>"`rTolles Gef�hl",
     "rounds"=>20,
     "wearoff"=>"`rDu f�hlst dich wieder normal.",
     "atkmod"=>1.2,
     "roundmsg"=>"`rDu f�hlst dich etwas st�rker.",
     "activate"=>"offense");

$session[user][turns]+=1;
$session[user][kondom]+=1;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;
case 3:
$turns = e_rand(2,7);
output("`rDu �berreichst Shana das Gold, welches sie verlangt, bevor sie  dir ein grosses in bunten Stoff gewickeltes
P�ckchen her�berreicht.Du �ffnest erst nach sorgf�ltiger Untersuchung das P�ckchen, schmeisst es allerdings sofort 
wieder auf die Ladentheke. Dieses Rinddarmkondom hat so ekelhaft gerochen, dass du dich jetzt erstmal eine ganze Weile 
ausruhen musst.");
$session[user][turns]-=$turns;
$session[user][kondom]+=1;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;
  }
 }
}
if($_GET['op']=="hengst"){
if($session[user][gold]<1000){
output("`rDu glaubst doch nicht etwa, dass du hier was geschenkt bekommst? Das kannst du dir nicht leisten!");
addnav("Kondomladen","kondom.php");
}else{
$session[user][gold]-=1000;

switch(e_rand(1,4)){

case 1:
$turns = e_rand(1,3);
output("`rDu �berreichst Shana das Gold, welches sie von dir verlangt, bevor sie dir ein in bunten Stoff gewickeltes
P�ckchen �ber den Tisch schiebt. Du reisst neugierig den Stoff von dem K�stchen und als du es �ffnest, bekommst du ganz
grosse Augen. Deine Wangen r�ten sich, aber du f�hlst dich stark genug, um noch ein paar Monster zu t�ten.");
$session[user][turns]+=$turns;
$session[user][kondom]+=1;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;

case 2:
$gold = e_rand(250,500);
output("`rDu �berreichst Shana das Gold, welches sie von dir verlangt, bevor sie dir ein in bunten Stoff gewickeltes
P�ckchen �ber den Tisch schiebt. Dich auf den s��en Moment, wo du das Hengstdarmkondom ausprobieren wirst, freuend, packst
du das Kondom sofort aus. Doch der unerwartet extrem s�uerliche Geruch �berw�ltigt dich und l�sst dich zur�cktaumeln.
Noch w�hrend du darum k�mpfst, deine Besinnung nicht zu verlieren, sp�rst du, wie sich jemand an deinem Geldbeutel zu
schaffen macht. Als du wieder klar sehen kannst, ist jedoch niemand mehr anwesend. Als du sp�ter dein Gold z�hlst,
bemerkst du, dass dir jemand $gold Gold gestohlen hat!");
$session['bufflist']['kondom'] =
     array("name"=>"`rSehr s�uerlicher Geruch",
     "rounds"=>25,
     "wearoff"=>"`rDer Geruch verschwindet.",
     "defmod"=>0.75,
     "roundmsg"=>"`rDer Geruch l�sst deine Augen brennen.",
     "activate"=>"offense");

$session[user][gold]-=$gold;
$session[user][kondom]+=1;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;

case 3:
output("`rDu �berreichst Shana das Gold, welches sie von dir verlangt, bevor sie dir ein gro�es in bunten Stoff
gewickeltes P�ckchen her�berreicht. In freudiger Erwartung reisst du den Stoff von dem K�stchen und genie�t die
Vorfreude auf die Benutzung des Hengstdarmkondomes. Du sp�rst, wie dich der Adrenalinschub der Erwartung  restistenter
gegen Angriffe macht. Au�erdem erh�lst du genug Energie f�r einen weiteren Waldkampf. ");
$session['bufflist']['kondom'] =
     array("name"=>"`rAdrenalinschub",
     "rounds"=>25,
     "wearoff"=>"`rDein Adrenalinschub verschwindet.",
     "defmod"=>1.25,
     "roundmsg"=>"`rDu bist resistenter gegen Angriffe, da dein Adrenalin dich voran treibt.",
     "activate"=>"offense");

$session[user][turns]+=1;
$session[user][kondom]+=1;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;

case 4:
output("`rDu �berreichst Shana das Gold, welches sie verlangt, bevor sie  dir eine ein in bunten Stoff gewickeltes
P�ckchen her�berreicht. Skeptisch nimmst du das P�ckchen entgegen und betrachtest das Hengstdarmkondom, nachdem du es
ausgepackt hast. Da dir die ungew�hnlich schimmelig, gr�nliche  Farbe des Kondoms sonderbar vorkommt, gibst du es wieder
zur�ck. Durch den Streit, den du dadurch mit Shana anzettelst, verlierst du die Zeit f�r einen Waldkampf.");
$session[user][turns]--;
$session[user][kondom]+=1;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;
  }
 }
}
if($_GET['op']=="lamm"){
if($session[user][gold]<1300){
output("`rDu glaubst doch nicht etwa, dass du hier was geschenkt bekommst? Das kannst du dir nicht leisten!");
addnav("Kondomladen","kondom.php");
}else{
$session[user][gold]-=1300;
switch(e_rand(1,3)){
case 1:
output("`rDu �berreichst Shana das Gold, welches sie verlangt, bevor sie ein in bunten Stoff gewickeltes P�ckchen auf
den Tresen legt. In dem Moment, als du das P�ckchen �ffnest, springt dich eine durchgedrehte Springmaus an und bei�t
dich in die Nase. Reflexartig schnaufst du wie eine Dampflok und sch�ttelst das Untier wieder ab, jedoch kostet dich der
Biss einige deiner Lebenspunkte.");
$session[user][hitpoints]-=30;
$session[user][kondom]+=1;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;
case 2:
output("`rDu �berreichst Shana das Gold, welches sie verlangt, bevor sie ein in bunten Stoff gewickeltes P�ckchen auf
den Tresen legt. Freudig nimmst du das P�ckchen und machst dich auf den Weg zu deiner Verabredung. Dank der k�stlichen
Vorfreude wirst du gleich munterer und erh�lst mehr Energie zum 'K�mpfen'. ");
$session[user][hitpoints]+=30;
$session[user][kondom]+=1;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;
case 3:
output("`rDu �berreichst Shana das Gold, welches sie verlangt, bevor sie dir ein in bunten Stoff gewickeltes P�ckchen
auf den Tresen legt. Etwas entt�uscht dar�ber, dass Shana nur ein Lammdarmkondom in das P�ckchen gepackt hat obwohl du
f�nf bestellt hast. Trotzdem nimmst du dieses und packst es missmutig aus. Ob deiner Entt�uschung bemerkst du nicht, dass
es schon gebraucht ist. Erst als du es anwenden willst, merkst du dies und kommst wieder zur�ck, um es umzutauschen. Der
Laden hat aber schon geschlossen. Dies kostet dich einige Waldk�mpfe.");
$session[user][turns]-=5;
$session[user][kondom]+=1;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;
  }
 }
}
if($_GET['op']=="dino"){
if($session[user][gold]<1350){
output("`rDu glaubst doch nicht etwa, dass du hier was geschenkt bekommst? Das kannst du dir nicht leisten!");
addnav("Kondomladen","kondom.php");
}else{
$session[user][gold]-=1350;
switch(e_rand(1,3)){
case 1:
output("`rDu �berreichst Shana die Goldsumme, welches sie dir nannte, bevor sie unter Anstrengung ein wirklich riesiges
Dinokondom auf den Tresen legt. Neugierig beobachtest du sie, wie sie das fremdartig und wirklich monstr�s grosse
Kondom ausbreitet. Als du dann jedoch den widerw�rtigen Gestank des schimmeligen Kondoms wahrnimmst, wird dir schwarz
vor Augen. Erst mehrere Stunden sp�ter erwachst du wieder und... h�rst Ramius dich auslachen. Du bist TOT!");
$session[user][alive]=false;
$session[user][hitpoints]=0;
addnews("`rDa hat sich wohl einer �bersch�tzt. {$session['user']['name']} ist der tote Beweis daf�r, dass
es nicht immer bei allem auf die Gr�sse ankommt!!!");
addnav("News","news.php");
break;
case 2:
output("`rDu �berreichst Shana die Goldsumme, welche sie dir nannte, bevor sie unter gr�sster Anstrengung ein wirklich
riesiges Dinokondom auf den Tresen legt. Mit einer geschickten Bewegung �ffnet der H�ndler die Schale. Leicht
angewiedert, ob des Gestankes der Kondom, wagst du es aber trotzdem, ein St�ck davon zu kosten. �berraschenderweise
nimmst du einen karamellartigen Geschmack wahr.Au�erdem werden in dir neue Kr�fte erweckt, die dir einen
Lebenspunkteschub verleihen.");
$session[user][hitpoints]+=100;
$session[user][kondom]+=1;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;
case 3:
output("`rDu �berreichst Shana die Goldsumme, welche sie dir nannte, bevor unter gr�sster Anstrengung ein wirklich
riesiges Dinokondom auf den Tresen legt. Die Sukubus rollt das monstr�se Kondom zusammen und reicht es dir. Knallrot
nimmst du es entgeben, stockst aber, als du merkst, dass es fast schon zu schwer f�r dich ist. Nur mit gr�sster M�he tr�gst
du es davon. Mit schmerzverzerrtem Gesicht ziehst du dich zur�ck. Wegen deiner Schw�che kannst du heute nicht mehr
k�mpfen. Du hast glatt die Zwerge hinter dem Tresen �bersehen, die Shana bei der schweren Last geholfen haben.");
$session[user][turns]=0;
$session[user][kondom]+=1;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;
  }
 }
}
if($_GET['op']=="knochen"){
if($session[user][gold]<1700){
output("`rDu glaubst doch nicht etwa, dass du hier was geschenkt bekommst? Das kannst du dir nicht leisten!");
addnav("Kondomladen","kondom.php");
}else{
$session[user][gold]-=1700;
switch(e_rand(1,3)){
case 1:
output("`rDu �berreichst Shana das abgez�hlte Gold, welches sie haben m�chte, bevor sie ein kunstvolles Gebilde von
einem H�hnchenknochen verst�rkten Kondom f�r Knickschnibbel den Tresen legt. Das seltsame Kondom, dass dich an eine
Nachbildung des Turm der Elemente zu erinnern scheint, betrachtend, nimmst du dieses vom Tisch und verl�sst den Laden
wieder. Als du dann auf der Stra�e mit einem nackten Ph�nix, der verwirrt �ber den Dorfplatz wetzt, zusammen st�sst,
schaust du w�tend auf das Kondom in deiner Hand hinab und zerdr�ckst dieses aus Versehen. Jedoch der Ph�nix nimmt dir
�bel, dass du ein Knochenger�st von einem Vogel herum tr�gst und pickt dir so dolle in deinen Po, dass du
ein paar Waldk�mpfe verschwndest, um zu dem Heiler zu kommen.");
$session[user][turns]-=10;
$session[user][kondom]+=1;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;

case 2:
output("`rDu �berreichst Shana das abgez�hlte Gold, welches sie haben m�chte, bevor sie ein kunstvolles Gebilde von
einem H�hnchenknochen verst�rkten Kondom f�r Knickschnibbel den Tresen legt. Der Adrenalinkick, welcher die Aussicht auf
das Verwenden des Kondoms bei dir ausgel�st wird, verleiht dir sofort mehr Kraft. 'Kampfeslustig' schulterst du dein
P�ckchen mit dem bunten Stoff drumherum und verl�sst das Kondoml�dchen mit einem gl�cklichen L�cheln.");
$session['bufflist']['kondom'] =
     array("name"=>"`rAdrenalinkick",
     "rounds"=>35,
     "wearoff"=>"`rDeine Energie schwindet.",
     "atkmod"=>1.50,
     "roundmsg"=>"`rDein Adrenalinspiegel ist erh�ht und du kannst fester zuschlagen.",
     "activate"=>"offense");

$session[user][kondom]+=1;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;
case 3:
output("`rDu �berreichst Shana das abgez�hlte Gold, welches sie haben m�chte, bevor sie ein kunstvolles Gebilde von
einem H�hnchenknochen verst�rkten Kondom f�r Knickschnibbel den Tresen legt. Die eigenartige Optik des Kondoms macht dich
neugierig, so dass du ohne gro�artig zu �berlegen das St�ck gleich ganz in deine Tasche stopfst. In dem selben Moment
st�rmt eine betrunkene Horde Orks in den Laden und erschreckt dich so sehr, dass du fast an deinem Speichel, der dir im
Mund zusammen gelaufen war, erstickst. Im letzten Moment kannst du den Hustenanfall beenden, bevor die Orks sich
beleidigt f�hlen, jedoch bist dadurch so geschw�cht, dass du fast deine gesamten Lebenspunkte verlierst.");
$session[user][hitpoints]=1;
$session[user][kondom]+=1;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;
  }
 }
}
if($_GET['op']=="aal"){
if($session[user][gold]<2500){
output("`rDu glaubst doch nicht etwa, dass du hier was geschenkt bekommst? Das kannst du dir nicht leisten!");
addnav("Kondomladen","kondom.php");
}else{
$session[user][gold]-=2500;
switch(e_rand(1,4)){
case 1:
output("`rDu �berreichst Shana das gew�nschte Gold, welches sie verlangt, bevor sie ein Zitteraalkondom auf den Tresen
legt. Alleine bei dem Anblick des zitternd vibrierenden Kondoms l�uft dir schon das Wasser im Munde zusammen und
dementsprechend schnell schnappst du dir das in bunte Stoffe gewickelte Kondom. Durch die freudige Erwartung f�hlst du
dich gleich fitter und k�nntest heute ein paar 'Monster' mehr erlegen.");
$session[user][turns]+=13;
$session[user][kondom]+=1;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;
case 2:
output("`rDu �berreichst Shana das gew�nschte Gold, welches sie verlangt, bevor sie ein Zitteraalkondom auf den Tresen
legt. Das innovative Kondom, welches auf dem Tresen zitternd vibriert, schnappst du dir so schnell wie es von Shana auf
den Tresen gelegt wurde. Die Freude �ber das neu erstandene Kondom macht dich sofort munterer und wachsamer.");
$session['bufflist']['kondom'] =
     array("name"=>"`rWachsamkeit",
     "rounds"=>40,
     "wearoff"=>"`rDeine Wachsamkeit l�sst nach.",
     "defmod"=>1.60,
     "roundmsg"=>"`rDeine Freude macht dich wachsamer; dich kann nicht mehr �berraschen.",
     "activate"=>"offense");
$session[user][kondom]+=1;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;
case 3:
output("`rDu �berreichst Shana das gew�nschte Gold, welches sie verlangt, bevor sie ein Zitteraalkondom auf den Tresen
legt. Verdutzt schaust du das zitternde, vibrierende auf dem Tresen zappelnde Kondom an, das vor dir liegt.
Letztendlich, nachdem du das Dr�ngen Shanas nicht mehr ertragen kannst, nimmst du deinen ganzen Mut zusammen und das
Zitteraalkondom an dich. Jedoch ist dieses so flutschig und schwer zu halten, dass es wie ein neuer Tanz aussieht, wie du
mit dem Kondom heim gehst und dir deine Kr�fte raubt.");
$session['bufflist']['kondom'] =
     array("name"=>"`rUngeschicklichkeit",
     "rounds"=>40,
     "wearoff"=>"`rDu l�sst das Zitteraalkondom fallen und es zappelt zitternd auf dem Boden weiter.",
     "defmod"=>0.40,
     "atkmod"=>0.40,
     "roundmsg"=>"`rDas Zitteraalkondom ist zu schwer f�r dich zu halten!",
     "activate"=>"offense");

$session[user][kondom]+=1;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;
case 4:
output("`rDu �berreichst Shana das gew�nschte Gold, welches sie verlangt, bevor sie ein Zitteraalkondom auf den Tresen
legt. Als du das zitternd vibrierende Kondom erblickt, fliehst du panikartig aus dem Laden. Das Ding, was Shana dir auf
den Tresen gelegt hat, sieht dir zu lebendig f�r seinen Zweck aus. Au�er Atem bleibst du hinter der n�chsten H�userecke
stehen und beobachtest die Stra�e. Du hast dergleichen noch nie gesehen und bist nun so ver�ngstigt, dass du heute
sicherlich nicht mehr k�mpfen wirst.");
$session[user][turns]-=13;
$session[user][kondom]+=1;
addnav("Blos weg hier","village.php");
addnews("{$session['user']['name']} hat Angst vor zappelnden Zitteraalen.");
break;
  }
 }
}
if($_GET['op']=="drache"){
if($session[user][gold]<3800){
output("`rDu glaubst doch nicht etwa, dass du hier was geschenkt bekommst? Das kannst du dir nicht leisten!");
addnav("Kondomladen","kondom.php");
}else{
$session[user][gold]-=3800;
switch(e_rand(1,4)){
case 1:
output("`rDu �berreichst Shana das gew�nschte Gold, welches sie verlangt, bevor sie ein rotgl�hendes Drachendarmkondom
auf den Tresen legt. Als du das feurige Kondom erblickt, fliehst du panikartig aus dem Laden. Das Ding, was Shana dir
auf den Tresen gelegt hat, sieht dir zu heiss f�r seinen Zweck aus. Au�er Atem bleibst du hinter einem dicken Baum im
Wald erst stehen und versuchst, keuchend zu Atem zu kommen. Du hast dergleichen noch nie gesehen und bist nun so
ver�ngstigt, dass du heute sicherlich nicht mehr k�mpfen wirst.");
$session[user][turns]=0;
$session[user][kondom]=5;
addnav("Blos weg hier","forest.php");
addnews(" `r {$session['user']['name']} hat Angst vor feurigen Dingen.");
break;
case 2:
output("`rDu �berreichst Shana das gew�nschte Gold, welches sie verlangt, bevor sie ein rotgl�hendes Drachendarmkondom auf den Tresen legt und dieses dann gekonnt pr�sentiert. Neugierig betrachtest du dieses feurige Kondom. Das grosse
gl�hende Kondom kommt dir zwar seltsam vor, jedoch willst du es trotzdem probieren. Seltsamerweise scheint das Kondom
nicht wirklich heiss zu sein und du hebst es hoch. Als du dann nach einigen Augenblicken deine Haut betrachtest, hat
diese die Farbe der Drachenkondom angenommen. Panikartig schaust du zu Shana auf, welche dann auch die Letzte ist, die
du f�r heute siehst.");
$session[user][alive]=false;
$session[user][hitpoints]=0;
$session[user][kondom]=5;
addnav("News","news.php");
addnews("{$session['user']['name']} ist an einem feurigen Drachending gestorben.");
break;
case 3:
output("`rDu �berreichst Shana das gew�nschte Gold, welches sie verlangt, bevor sie ein rotgl�hendes Drachendarmkondom auf den Tresen legt. Fasziniert starrst du das feurige Kondom an. Mit jedem Augenblick, wo du es anschaust, scheinst du
kr�ftiger zu werden und immer, wenn du es mit deinem Zeigefinger anstupst, wird deine Aufmerksamkeit gesteigert. Als du
dich entschieden hast, es zu kaufen, f�hlst du dich so energiegeladen, dass dir heute nichts etwas anhaben kann. ");
$session['bufflist']['frhandel'] =
     array("name"=>"`rUnglaubliche Energie",
     "rounds"=>40,
     "wearoff"=>"`rDu f�hlst dich wieder normal.",
     "defmod"=>3.00,
     "atkmod"=>3.00,
     "roundmsg"=>"`rDu f�hlst dich unbesiegbar!",
     "activate"=>"offense");
$session[user][hitpoints]+=400;
$session[user][kondom]=5;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;
case 4:
output("`rDu �berreichst Shana das gew�nschte Gold, welches sie verlangt, bevor sie ein rotgl�hendes Drachendarmkondom auf den Tresen legt. Da du solch ein besonderes Kondom zuvor noch nie gesehen hast, bist du dir nicht sicher, ob du dieses nutzen sollst. Wagemutig nimmst du das Kondom in die Hand und blickst es noch einmal erwartungsvoll an. Nun nimmst du jedoch einen bitteren Geruch wahr, der dir die Nasenschleimhaut zu ver�tzen scheint. Der bittere Geruch legt sich �ber deine Geruchsnerven und verwirrt dein Denken. Bevor du wieder in den Wald gehst, besorgst du dir in der Schenke noch ein Ale, um den ekligen Geruch loszuwerden, was jedoch kaum etwas bringt.");
$session['bufflist']['kondom'] =
     array("name"=>"`rEkelhafter Geruch",
     "rounds"=>40,
     "wearoff"=>"`rDer Geruch verschwindet.",
     "defmod"=>0.20,
     "atkmod"=>0.20,
     "roundmsg"=>"`rDu musst fast brechen ob des ekelhaftes Geruchs in deiner Nase!",
     "activate"=>"offense");
$session[user][turns]-=20;
addnav("Zur�ck ins Freudenhaus","frdnhaus.php");
break;
  }
 }
}
$copyright ="<div align='center'><a href=http://www.logd-midgar.de/logd/ target='_blank'>&copy;`#Midgar`0</a></div>";
output("`n`n`n`n$copyright`n ",true);
page_footer();
?>