<?php

//  Coded by Taikun // www.logd-midgar.de

        require_once "common.php";
        require_once "frdnhausfunk.php";

        checkday();

        page_header("Das Freudenhaus");

        addcommentary();

        $stadt = "Midgar";
        $verw = "3750";

        $sql = "SELECT name, sex FROM accounts";
        $result = db_query($sql);
        $row = db_fetch_assoc($result);

        switch($_GET['op']):

        case "";

        output(" ".$row['user']['name']." Bevor du das Freudenhaus betrittst, kommst du in eine mysteri�se Gasse, in der du auch noch einige andere Sachen findest. Auch siehst du, wie sich hier andere Leute unterhalten.");
        viewcommentary("mygasse","Hinzuf�gen",25);
        if ($session['user']['frdnerl']==1) addnav("Kondomladen","kondom.php");
        if ($session['user']['superuser']>=3) addnav("Spielzeugladen","secret_vendor.php");
        addnav("Freudenhaus","frdnhaus.php?op=alter");

        break;

        case "alter";

        if ($session['user']['frdnerl']==0)
        {

        inputalter();

        }
        else
        {

        if($session['user']['room']==1)
        {

        settingsanfang();

        } 
        else 
        {

        settings( $stadt, $verw );

        }


        }

        break;

        case "pruf";

        $var1 = $session['user']['acctid'];
        $var2 = $session['user']['name'];
        
        alterprufen();
        
        break;

        case "weiterpruf";

        alterweiterprufen();
        
        break;

        
        case "room";

        roominside();

        break;


        case "beend";

        rpbeenden();

        break;


        case "anbiet";

        anbieten();

        break;


        case "send";        

        anbietenprufen();   

        break;


        case "ver";

        getpartner();

        break;


        case "getroom";

        getroom();

        break;


        case "zimmdel";

        delzimmer1();

        break;


        case "zimmdel1";

        delzimmer2();

        break;

        endswitch;
        
        $copyright ="<div align='center'><a href=http://www.logd-midgar.de/logd/ target='_blank'>&copy;`#Midgar`0</a></div>";
        output("`n`n`n`n$copyright`n ",true);
        page_footer();

?>