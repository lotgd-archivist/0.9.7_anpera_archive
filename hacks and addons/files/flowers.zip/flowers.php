<?php
//Pflanzenzucht
//Idee von Fichte, Texte von Kisa, Zusammengeschuster von Hecki :o)
//Version: 1.0
//Erstmals eschienen auf http://www.cop-logd.de
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//Einfach in der Accounts Tabelle 3 Felder erstellen beet, crowedup, flowerlimit!
//Datei in den Logd Ordern schieben!
//Wenn die Datei nicht im Garten verlinkt wird, die zur�ck Buttons neu Einstellen!
// Viel Spass ihr Hobbyg�rtner!

require_once "common.php";
if ($HTTP_GET_VARS[op] == ""){
    page_header("Die Pflanzenzucht");
    output("`c`b.:>Pflanzenzucht<:.`c`b");
    output("`n`n");
if ($session['user']['beet'] == 0){
    output("`@ Hier kannst du dir ein Blumenbeet anlegen. Wenn du es t�glich pflegst wird schon bald die erste Knospe zu einer wundersch�nen Bl�te werden.");
     output("`@ Sei sorgsam und liebevoll, dann wird dich deine Pflanze sicher belohnen! Denn der Samen enth�lt magische Zutaten!");
    output("`n`n");
     output("`@ Ein Beet kostet einmalig 4000 Gold und 10 Edelsteine!`n");
     output("`@ Auf dem Beet ist Platz f�r eine Blume, aber diese entwickelt unendlich viele Knospen und in jeder ihrer Knospen wartet eine kleine �berraschung auf dich!`n");
// if ($session['user']['gold']>3999 && $session['user']['gems']>9{
   addnav("Ein Beet anlegen","flowers.php?op=anlegen");
   addnav("zur�ck zum Garten","gardens.php");
   }else{
   output("Voller Vorfreude betrittst du dein Beet. Du bist gespannt ob heute vielleicht etwas aus einer der Knospen spriest.`n`n");
   output("Du solltest etwas Zeit und Gold in die Aufzucht deiner Pflanze investieren, schliesslich braucht eine Pflanze, Liebe, Wasser und D�nger damit sie gedeiht!`n`n");
   addnav("Um deine Pflanze k�mmern`^(100 Gold)","flowers.php?op=kuemmern");
   addnav("zur�ck zum Garten","gardens.php");
   }
   }
if ($HTTP_GET_VARS[op] == "anlegen"){
    page_header("Ein Beet anlegen");
    //output(" `n`n`2`b`cLeg hier ein Blumenbeet an`n");
if ($session['user']['gold']>3999 && $session['user']['gems']>9){
    //output(" `n`n`2`b`cDu hast Du hast jetzt ein sch�nes Blumenbeet, und kannst mit deiner Aufzucht beginnen!`n");
    $session['user']['gold'] -= 4000;
    $session['user']['gems'] -= 10;
    $session['user']['beet'] = 1;
    output(" `n`n`2`b`cDu hast jetzt ein sch�nes Blumenbeet, und kannst mit deiner Aufzucht beginnen!`n");
    addnav("zur�ck zum Garten","gardens.php");
    addnav("zu deinem Beet","flowers.php");
    }else{
    output("`n`n`2Leider hast du nicht genug Gold und/oder Gems dabei, komm doch sp�ter wieder vorbei!`n");
    output("`n`n");
    addnav("zur�ck zum Garten","flowers.php?op=gehen");
    }
    }

   if ($HTTP_GET_VARS[op] == "kuemmern"){
   page_header("Um deine Pflanze k�mmern!");
   if($session['user']['gold']>=100 && $session['user']['flowerlimit']==0 && $session['user']['turns']>0){
   $session['user']['turns'] --;
   $session['user']['gold'] -=100;
   $session['user']['crowedup'] ++;
   $session['user']['flowerlimit'] = 1;
   output("`@Du steckst viel Liebe und Energie in deine Arbeit, und hoffst das dich deine Pflanze in naher Zukunft f�r deine aufopferungsvollen Bem�hungen belohnen wird!`n`n");
   addnav("Zur�ck zum Garten","gardens.php");
if ($session['user']['crowedup']==10){
$up = e_rand(1,5);
    $session['user']['crowedup']=0;
    switch ($up){
          case 1:
                              // addnav("Zur�ck zum Garten","gardens.php");
                               output("`qVor deinen Augen �ffnet sich pl�tzlich eine der Knospen und eine wundersch�ne,");
                               output("`qlecker riechende Frucht erblickt das Licht der Welt und danach die Dunkelheit deines Rachens.``nn");
                               output("`@ Diese Frucht bringt dir 3 permanente Lebenspunkte!");
                                $session[user][maxhitpoints] += 3;
                               break;
         case 2:
                               //addnav("Zur�ck zum Garten","gardens.php");
                               output("`qAls du deine Blume hoffnungsvoll anschaust scheint sie sich doch tats�chlich zu bewegen.");
                               output("`qJa, es ist wahr, die Bl�te �ffnet sich ganz langsam und als sie vollkommen aufgebl�ht ist bist du dir ganz sicher, dass es die allersch�nste Blume ist, die du je in deinem Leben gesehen hast.");
                               output("`qVor lauter Begeisterung kannst du garnicht reagieren als dein Nachbar auf dich zugerannt kommt,");
                               output("`qdir 2500 Gold in die Hand dr�ckt und mit deiner wundersch�nen Blume hinter der n�chsten Ecke verschwindet. Du stehst da mit offenem Mund und fragst dich ob du je wieder eine solch wundervolle Blume z�chten kannst!!!");
                                 $session[user][gold]+=2500;
                               break;
          case 3:
                               //addnav("Zur�ck zum Garten","gardens.php");
                                output("`qVor deinen Augen �ffnet sich pl�tzlich eine der Knospen und eine wundersch�ne,");
                               output("`qlecker riechende Frucht erblickt das Licht der Welt und danach die Dunkelheit deines Rachens.`n`n");
                               output("`@ Diese Frucht bringt dir 15 weitere Waldk�mpfe!");
                                $session[user][turns] += 15;
                               break;
          case 4:
                              // addnav("Zur�ck zum Garten","gardens.php");
                               output("`5Vetr�umt schaust du dein Bl�mchen an und hoffst das du dich bald an ihrer wundersch�nen Bl�te erfreuen kannst.`n`n");
                               output("`5Pl�tzlich reckt sich das kleine Bl�mchen und innerhalb von Sekunden erbl�ht eine ihrer Knospen in den sch�nsten Regenbogenfarben.`n");
                               output("`5Sie scheint richtig zu gl�nzen, nur f�r dich. Du h�ltst sie an deine Nase um ihren lieblichen Duft in dir aufzunehmen und je n�her du sie richtung Nase h�ltst desto heller leuchtet sie!`n`n");
                               output("`5Heller, heller und immer heller strahlt sie dich an, du bist von Ihrer Sch�nheit wahrlich geblendet");
                               output("`5und entdeckst erst als du die Blume ganz an deiner Nase hast, dass ihre Bl�te mit Edelsteinen verziert ist.`n`n");
                               output("`5Du steckst die 5 Edelsteine sorgsam ein und beschlie�t dich noch intensiver um dein kleines Pfl�nzchen zu k�mmern - wer wei� was die n�chste Bl�te f�r wundersame Kr�fte in sich verbirgt - ");
                               $session[user][gems]+=5;
                               break;
             case 5:
                             //  addnav("Zur�ck zum Garten","gardens.php");
                               output("`qGespannt wartest du, wann deine M�hen endlich belohnt werden und tats�chlich, eine der gr��ten Knospen an deiner Blume reckt und streckt sich und erbl�ht zu einer wahren Pracht.");
                               output("`qDu bist so stolz wie noch nie zuvor auf dich selbst. Jetzt wei�t du was einen richtigen G�rtner ausmacht.`n`n");
                               output("`@Dieses Wissen l�sst deine Erfahrung um 5% ansteigen!");
                               $session[user][experience] = $session[user][experience]*1.05;
                               break;



                               }
                               }
  }else if ($session['user']['flowerlimit']==1){
   output("Deine Pflanze hatte heute schon Besuch von dir.");
   addnav("Zur�ck zum Garten","gardens.php");
 }else if ($session['user']['gold']<100){
        output("Du hast zu wenig Gold dabei.");
        addnav("Zur�ck zum Garten","gardens.php");
  }else if ($session['user']['turns']<1){
        output("Du hast keine Runden mehr �brig.");
        addnav("Zur�ck zum Garten","gardens.php");


   }
   }


if ($HTTP_GET_VARS[op] == "gehen"){
    page_header("In Gedanken!");
    output("Du drehst dem Beet den R�cken zu und denkst dir heimlich, dass wenn du dir schon kein Beet leisten kannst, dir sp�ter eins stehlen wirst, ja ganz bestimmt!");
    addnav("Zur�ck zum Garten","gardens.php");
    }

//addnav("Zur�ck zum Garten","gardens.php");


page_footer("test");
?>