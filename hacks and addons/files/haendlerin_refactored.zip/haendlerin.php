<?php
/*
Skriptname      : Die verzweifelte H�ndlerin
Geschrieben von : Innos (Martin Bitzer)
Geschrieben f�r : http://www.talamar.de/logd
Gewidmet        : Agriel (Jasmin Hempel)
*/

require_once"common.php";
page_header("Die verzweifelte H�ndlerin");
if (!isset($session)) exit();

switch($_GET['op']) {
	
		// Hingehen oder Weggehen
	case 'hinge':
		$session['user']['specialinc'] ="haendlerin.php";
		output("`r Was ist mit Euch junge Maid?`9 Fragst du sie h�flich und die junge Frau schaut dich an.`n`6 Ich bin H�ndlerin Sheila und war auf dem Weg nach Talamar. Der Grossbauer Harkon kam zu mir und nahm sich meine Ware weil er meint ihm geh�re der Wald und ich habe diesen widerrechtlich betreten. Er habe das recht dazu.Nun habe ich nichts mehr.`n`9 meint die junge Frau unter tr�nen.");
		output("`n`9 Du wunderst dich im ersten Moment da du dachtest, dass der Wald dem Reich geh�rt und nicht einem Grossbauern. Dann wird dir klar,dass der Grossbauer nichts anderes ist als ein mieses Schwein und ein Betr�ger.");
		output("`n`9 Willst du der Gerechtigkeit dienen.");
		addnav("Ja","forest.php?op=ja");
		addnav("Nein","forest.php?op=nein");
		break;
	
	case 'wegge':
		output("`9Du denkst dir dein teil und verschwindest. Jedoch plagt dich dein schlechtes Gewissen und du denkst lange nach ob dein handeln richtig war.");
		output("`n`9Bis du dein Handeln verdaut hast, vergeht eine lange Zeit. du verlierst nicht nur 5 Waldk�mpfe sondern auch noch 2 Charmpunkte.");
		$session['user']['turns']-=5;
		$session['user']['charm']-=2;
		$session['user']['specialinc']="";
		addnav("Zur�ck","forest.php");		
		break;
		
		// Helfen oder nicht Helfen
	case 'nein':
		output("`9`r Stell dich nicht so j�mmerlich an du dummes Weib.Wenn du so dumm bist, haste auch selbst schuld.`9 meinst du kalt und gehst wieder");
		output("`n`9Du hast die H�ndlerin schwer getroffen mit deinen Worten.Die G�tter haben dich beobachtet und bestrafen dich mit dem Tod.schenken der H�ndlerin dein Gold und deine Edelsteine.");
		$session['user']['alive']=false;
		$session['user']['hitpoints']=0;
		$session['user']['gold']=0;
		$session['user']['gems']=0;
		$session['user']['specialinc']="";
		addnews($session['user']['name']." wurde von den G�ttern bestraft wegen kaltherzigkeit.");
		addnav("News","news.php");
		break;
	
	case 'ja':
		$session['user']['specialinc']="haendlerin.php";
		output("`9Du kannst es nicht verantworten und tr�stet die junge H�ndlerin. Dann ziehst du los um den fiesen Grossbauern zu stellen`n");
		switch(e_rand(1,12)){
			case 1:
				output("`9 Du findest den Grossbauern und baust dich vor ihm auf. Jedoch bemerkst du leider zu sp�t,dass sich einer seine S�ldner hinter dich stellt und dich hinterr�cks ermordet");
				$session['user']['alive']=false;
				$session['user']['hitpoints']=0;
				$session['user']['gold']=0;
				addnews($session['user']['name']." wurde vom S�ldner des Grossbauern Harkon hinterr�cks ermordet.");
				addnav("News","news.php");
				break;
				
			case 2:
			case 3:
			case 4:
			case 5:
				output("Es kostet dir 3 Waldrunden bis du den Grossbauern stellen kannst. Als er dich sieht macht er sich vor Angst in die Hose und und gibt dir alles was der H�ndlerin geh�rt.");
				$session['user']['turns']+=3;
				addnav("Zur�ck zur H�ndlerin","forest.php?op=back");
				break;
				
			case 6:
			case 7:
			case 8:
			case 9:
				output("`9 Du kommst beim Bauern an und willst ihm stellen. Jedoch z�ckt er seine Waffe..");
				$crexp = e_rand(200,500);
				$badguy = array(
					"creaturename"=>"Grossbauer Harkon",
					"creaturelevel"=>0,
					"creatureweapon"=>"Goldener Sichel",
					"creatureattack"=>1,
					"creaturedefense"=>1,
					"creaturehealth"=>2,
					"creaturegold"=>0,
					"creatureexp"=>$crexp,
					"diddamage"=>0
				);

				$userlevel=$session['user']['level'];
				$userattack=e_rand($session['user']['attack']-1,$session['user']['attack']+2);
				$userhealth=$session['user']['hitpoints'];
				$userdefense=e_rand($session['user']['defence']-1,$session['user']['defence']+2);
				$badguy['creaturelevel']+=$userlevel;
				$badguy['creatureattack']+=$userattack;
				$badguy['creaturehealth']=$userhealth;
				$badguy['creaturedefense']+=$userdefense;
				$badguy['creaturegold']=0;
				$session['user']['badguy']=createstring($badguy);
				$battle = true;
				break;

			case 10:
			case 11:
			case 12:
				output("`9 Du findest den Bauern und stellst ihn.Nach einer Weile gibt er dir ein Teil der Ware zur�ck. Den anderen Teil hat er bereits verkauft");
				output("`9 Leider hat die Diskution zu lange gedauert.du verlierst 4 Waldk�mpfe");
				$session['user']['turns']-=4;
				addnav("Zur�ck zur H�ndlerin","forest.php?op=back2");
				break;
		}
		break;
		
		// Zur�ck zur H�ndlerin
	case 'back':
		$session['user']['specialinc']="haendlerin.php";
		output("`n`9 Nach einer Weile kommst du zur�ck und gibst der H�ndlerin all ihre Sachen wieder.`6 Was verlangt ihr nun f�r eure Tat als Belohnung?`9 fragt sie dich sch�chtern?");
		output("`n`9 Was willst Du verlangen?");
		addnav("1000 Gold","forest.php?op=gold");
		addnav("Nichts","forest.php?op=nichts");
		break;
	
	case 'back2':
		$session['user']['specialinc']="haendlerin.php";
		output("`n`9 Nach einer Weile kommst du zur�ck und gibst der H�ndlerin des Rest ihrer Sachen wieder.Sie ist entt�uscht weil sie nicht alles wieder hat.`6 Was verlangt ihr nun f�r eure Tat als Belohnung?`9 fragt sie dich dennoch sch�chtern.");
		output("`n`9 Was willst Du verlangen?");
		addnav("500 Gold","forest.php?op=gold2");
		addnav("Nichts","forest.php?op=nichts2");
		break;
	
		// Entscheidung Belohnung oder nicht
	case 'gold':
		output("`n`9 Du verlangst 1000 Gold f�r deine Tat. Die H�ndlerin gibt sie dir nat�rlich.Jedoch verlierst du Ansehen");
		$session['user']['gold']+=1000;
		$session['user']['reputation']-=10;
		$session['user']['specialinc']="";
		addnews($session['user']['name']." nutzt die charmlos die Notlage der H�ndlerin Sheila aus und verlangte 1000 Goldst�cke.");
		addnav("In den Wald","forest.php");
		break;
		
	case 'gold2':
		output("`n`9 Du verlangst 500 Gold f�r deine Tat. Die H�ndlerin gibt sie dir nat�rlich.Jedoch verlierst du Ansehen.");
		$session['user']['gold']+=500;
		$session['user']['reputation']-=20;
		$session['user']['specialinc']="";
		addnews($session['user']['name']." verlangt f�r sein teilversagen auch noch 500 Gold.");
		addnav("In den Wald","forest.php");
		break;
	
	case 'nichts':
		output("`n`9 Du willst nichts haben. Die H�ndlerin f�llt dir gl�cklich um den Hals. und k�sst dich innig.`n Du bekommst 10 Charmpunkte und von den G�ttern auch noch 10 Edelsteine");
		$session['user']['gems']+=10;
		$session['user']['charm']+=10;
		$session['user']['specialinc']="";
		addnews($session['user']['name']." ist der Held der jungen H�ndlerin Sheila.");
		addnav("In den Wald","forest.php");
		break;
	
	case 'nichts2':
		output("`n`9 Du willst nichts haben.Die H�ndlerin nickt dankend und gibt dir ein kleinen Kuss auf die Wange. Du bekommst zwei Ansehnspunkte");
		$session['user']['charm']+=2;
		$session['user']['specialinc']="";
		addnews($session['user']['name']." bringt der H�ndlerin ein Teil ihrer Ware zurr�ck");
		addnav("In den Wald","forest.php");
		break;
	
	
	default:		// Eingang
		$session['user']['specialinc']="haendlerin.php";
		output("`9 Du wanderst durch den Wald und summst vor dich hin. Pl�tzlich siehst du eine junge h�bsche Frau auf einem umgefallenen Baum sitzen.`n Sie weint bitterlich und du fragst dich was los ist.");
		output("`9Was willst du machen?");
		addnav("Hingehen","forest.php?op=hinge");
		addnav("Sie in ruhe lassen","forest.php?op=wegge");
		break;
}


if ($battle){
	include ("battle.php");
	if ($victory)	{
		$expwin = $badguy['creatureexp'];
		$session['user']['experience']+=$expwin;
		output("`4Du hast `^".$badguy['creaturename']."`4 geschlagen.`n `^Du bekommst $expwin Erfahrungspunkte.");
		addnav("Zur�ck zur H�ndlerin","forest.php?op=back");
		$session['user']['specialinc']="haendlerin.php";
		$badguy=array();
		$session['user']['badguy']="";
	} elseif ($defeat) {
		output("Du liegst auf dem Boden und der Grossbauer rammt sein goldenen Sichel in dein Hals");
		addnews($session['user']['name']."starb durch den Grossbauern Harkon");
		output("`n`4Du bist tot.`n");
		output("Du verlierst 10% deiner Erfahrung und alles Gold.`n");
		output("Du kannst morgen weiterspielen.");
		$session['user']['gold']=0;
		$session['user']['experience']=round($session['user']['experience']*.9,0);
		$session['user']['alive']=false;
		$session['user']['hitpoints']=0;
		$session['user']['specialinc']="haendlerin.php";
		$session['user']['reputation']--;
		addnav("T�gliche News","news.php");
	} else {
		fightnav(true,false);
	}
}
page_footer();
?>