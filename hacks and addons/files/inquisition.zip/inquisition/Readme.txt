Inquisition Version 1
***********************************************************
* Inquisitions Add on					        *
* Idee und Umsetzung: Newby/ Barra			        *
* www.child-of-mystik-moon.de/lotgd			        *
***********************************************************
 Der Kampf zwischen gut und b�se hat ein Neues Nivau erreicht. Engel, Avatare, Elfen und Menschen habe eine Magie geschaffen, mit der sie das B�se f�r immer von der Welt tilgen konnten. So zumindest schien es, doch der Schein tr�gt immer. Denn es wurde ein Serum entwickelt das die Rassen zu tarnen vermochte. Ein Serum welches in den geheimen G�rten( Rasseng�rten) zu finden war.

ben�tigt: racegarden.php
_____________________________________________________________________________________________
SQL
ALTER TABLE accounts ADD `beschwoerer` int(11) NOT NULL;
ALTER TABLE accounts ADD `inquisitor` int(11) NOT NULL;
ALTER TABLE accounts ADD `zwischenwelt` int(11) NOT NULL;
ALTER TABLE accounts ADD `zwischentage` int(11) NOT NULL;
ALTER TABLE accounts ADD `tarn` int(11) NOT NULL;

________________________________________________________________________________________________
�ffne bio.php

suche:
name,login,

f�ge ein:
inquisitor,beschwoerer,tarn

suche:

addnav("Zur�ck",$return);


f�ge darunter ein:
$link1="bann.php?char=$row[login]&id=$row[acctid]"; 
if($session[user][inquisitor]==1 && $row[tarn]==0 && $row[zwischenwelt]==0) addnav("User bannen", $link1);
if ($session[user][beschwoerer]==1 && $row[zwischenwelt]==1)addnav("User beschw�ren","banne.php?char=$row[login]&id=$row[acctid]");


suche:

output("`^Rasse: `@{$races[$row['race']]}`n");
 f�ge davor ein:
if ($session['user']['tarn']==0){

suche:

output("`^Rasse: `@{$races[$row['race']]}`n");

f�ge darunter ein:
if ($session['user']['tarn']>0){ output"`^ Rasse: `@Mensch`n");


SAVE AND UP
__________________________________________________________________________________________________________

�ffne newday.php

suche:

$session['user']['seenbard'] = 0;

 f�ge danach ein:
if($session['user']['tarn']>0)
{
$session['user']['tarn']--;
}
if ($session['user']['zwischenwelt']==1) 
{ 
$session['user']['zwischentage'] -=1; 
} 
if ($session['user']['zwischentage']==0 && $session['user']['zwischenwelt']==1){
$session['user']['zwischenwelt']=0;
}

suche :


			output("`n`&Du schnallst dein(e/n) `%".$session['user']['weapon']."`& auf den R�cken und ziehst los ins Abenteuer.`0");
}

f�ge darunter ein
if ($session['user']['tarn']==1){
output("`n`@ Du bist nur noch heute getarnt. Um weiterhin vor der Inquisition gesch�tzt zu sein soltlest du dir ein neues Serum besorgen`n");
}


SAVE AND UP
_______________________________________________________________________________________________________________________________
�ffne racegarden.php

suche:
page_footer():

f�ge dar�ber ein:
// INQUISITION _SERUM ANFANG

else if ($_GET['op']=="serum"){
page_header("Serum");
output("`4 Ein alter Greis steht gebeugt �ber einen gro�en Kessel in dem eine tr�be Fl�ssigkeit vor sich hinbrodelt.`n `6 Na mein Freund..ein Fl�schchen und niemand erkennt mehr was du bist..ein Fl�schchen und du siehst aus wie ein unscheinbarer Mensch..willst du das?`4 Irre kichernd sch�pft der Alte eine blubbernde Kelle und f�llt sie in eine Phiole.`6 nur einen Edelstein und die Inquisitoren werden dich nicht erkennen..oder sonst jemand.`n`n`@ Willst Du einen Edelstein bezahlen um getarnt zu wandeln?`n`n");
 output("<a href='racegarden.php?op=serum1'>[Trinken`0]</a>",true);
output("<a href='racegarden.php'>`0[`^Lieber nicht`0]</a>",true);
addnav("", "racegarden.php?op=serum1");
addnav("","racegarden.php");

}else if ($_GET['op']=="serum1"){
output("Du nimmst die Phiole und trinkst den Inhalt in einem Schluck. Dir wird �bel aber die Kennzeichen deiner Rasse werden zur�ckgesetzt. Du bist getarnt.");
$session[user][gems]--;
$session[user][tarn]=7;
}
addnav("Zur�ck ins Dorf","village.php");
// INQUISITION_SERUM ENDE

 jetzt noch in jeden Rassenraum der "dunklen" Rassen ( bei mir Vampire, D�monen, Werw�lfe) unter 

viewcommentary();

einf�gen:
addnav("Serum besorgen","racegarden.php?op=serum");

SAVE AND UP
______________________________________________________________________________________________________
 �ffne user.php

			"avatar"=>"Avatar:",

f�ge darunter ein:
"inquisitor"=>"Ist Inquisitor?,enum,0,Nein,1,Ja",			"beschwoerer"=>"Ist Beschw�rer?,enum,0,Nein,1,Ja",


_______________________________________________________________________________________________________

Marktplatz, Dorfplatz   und offenen Orten einf�gen:

suche:
checkday();
 setze darunter:

if ($session['user']['zwischenwelt']==1)
{
	redirect('zwischen.php');
}

**********************************************************
zwischen.php
bann.php
banne.php

ins Root laden

