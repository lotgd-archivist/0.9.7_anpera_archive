<?php 





require_once "common.php"; 

page_header("Bann"); 

if($_GET[op]==""){ 

output("`4Willst du `^$_GET[char]`0 wirklich verbannen ?"); 
addnav("Ja ich will","bann.php?op=ja&id=$_GET[id]&char=$_GET[char]"); 
addnav("Sonstiges"); 
addnav("Zur�ck","bio.php?id=$_GET[id]&char=$_GET[char]"); 

} 

if($_GET[op]=="ja"){ 

$sql="SELECT acctid, name,zwischenwelt,zwischentage,login, level FROM accounts WHERE acctid = '$_GET[id]'";  
$result = db_query($sql) or die(db_error(LINK));  
$row = db_fetch_assoc($result);  

output("`n`n`7Du hast ".$row['name']."`7 in die Zwischenwelt gebannt.",true);  
systemmail($_GET[id],"`^Gebannt!`0",$session[user][name]." hat Dich in die Zwischenwelt verbannt. !",$session[user]['acctid']);  

db_query("UPDATE accounts SET zwischentage=zwischentage+3, zwischenwelt = 1, attack=attack-1,charm=charm-1,battlepoints=battlepoints-5 WHERE acctid = '$_GET[id]'"); 
db_query("UPDATE account_extra_info SET sentence=sentence+3 WHERE acctid = '$_GET[id]'"); 

//Newseintrag 
addnews("{$row[name]}`0 wurde entarnt und in die Zwischenwelt gebannt!!!");


addnav("Sonstiges"); 
addnav("Zur�ck","bio.php?id=$_GET[id]&char=$_GET[char]"); 
} 
page_footer(); 
?>