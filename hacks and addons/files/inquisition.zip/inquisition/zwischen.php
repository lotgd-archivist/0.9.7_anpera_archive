<?php

// Zwischenwelt version 1.0
// Inquisition version 1.0
// Idee und umsetzung: Newby/barra
// www.child-of-mystik-moon.de/lotgd


require_once "common.php";

checkday();

page_header("Zwischenwelt");
if ($_GET['op']=="")
{
    if ($session['user']['zwischenwelt']==0)
    {
        redirect('village.php');
    }
    
    output(" `7`n`n Nebel...nichts als Nebel und unendliche weiten sind hier zu finden. Dir bleibt kaum eine M�glichkeit diesem Ort wieder zu entfliehen. Einzig ein m�chtiger D�mon k�nnte dich befreien...");
    
    addcommentary();
    viewcommentary("Zwischen");
    addnav("Aktionen");
    addnav("Liste der Beschw�rer","zwischen.php?op=tafel");
    addnav("Roulette","zwischen.php?op=zufall");
    
    addnav("freikaufen","zwischen.php?op=kauf");
}
if ($_GET['op']=="kauf")
{
    page_header("Zwischenwelt");
    
    output("Du hast die M�glichkeit, Dich aus der Zwischenwelt zu befreien, indem du einen hohen Preis zahlst. `n`n Der Preis betr�gt `^ 1000 Gold`# 1 Edelstein`@ 5 Charmepunkte und`4 5 Arenapunkte`0 . `n`n ");
    if ($session['user']['gems']>4 && $session['user']['gold']>999 && $session['user']['charm']>4 && $session['user']['battlepoints']>4)
    {
        output("`n<a href='zwischen.php?op=ja'>Ja ich will</a>",true);
    }
    
    addnav("","zwischen.php?op=ja");
    output("`n<a href='zwischen.php'>Nein</a>",true);
    
    addnav("","zwischen.php");
}
if ($_GET['op']=="ja")
{
    page_header("Zwischenwelt");
    
    output("So soll es sein. Ein neuer Tag wird Dir geschenkt, zu jenem Preis.");
    $session['user']['gems']-=5;
    $session['user']['charm']=-5;
    $session['user']['gold']-=1000;
    $session['user']['battlepoints']-=5;
    $session['user']['zwischenwelt'] = 0;
    $session['user']['zwischentage']= 0;
    addnav("weiter", "village.php");
}
if ($_GET['op']=="tafel")
{
    output("`c`7Beschw�rer `n`n<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999'>",true);
    output("<tr class='trhead'><td><b>Name</b></td><td><b>APs</b></td><td>Aktionen</td>",true);
    
    
    $sql="SELECT * FROM accounts WHERE beschwoerer=1 ORDER BY battlepoints DESC ";
    
    $result=db_query($sql);
    for ($i=0; $i<db_num_rows($result); $i++)
    {
        $row = db_fetch_assoc($result);
        
        output("<tr class='".($i%2?"trdark":"trlight")."'><td>",true);
        output("$row[name]`n");
        output("</td><td>",true);
        output("$row[battlepoints]`n");
        output("</td><td>",true);
        output("<a href=\"mail.php?op=write&to=".rawurlencode($row['login'])."\" target=\"_blank\" onClick=\"".popup("mail.php?op=write&to=".rawurlencode($row['login'])."").";return false;\"><img src='images/newscroll.GIF' width='16' height='16' alt='Mail schreiben' border='0'></a>",true);
        
    }
    output("</table>`c",true);
    
    addnav("Zur�ck","zwischen.php");
}
if ($_GET['op']=="zufall")
{
    page_header("Zwischenwelt");
    if ($session['user']['zufall']==0){
        output("`2 `b`cDas Roulette`b`c`n`n`n`Ein altes M�nnchen erscheint aus dem Nebeln des Nichts und mit ihm ein Tischchen und drei Phiolen. `7Willst du es wagen? Was hast du zu verlieren?`2 Ein ungutes Gef�hl steigt in dir auf w�hrend du langsam n�her tritts und allen Ahnungen zum Trotz nickst.`7 Drei Phiolen...eine vermag es Dich aus dieser H�lle zu befreien..oder Dich in ewiges Ungl�ck zu st�rzen`2 Lacht der Alte.`n`n Welche Phiole willst du versuchen?`n`n");
        addnav("Phiole 1", "zwischen.php?op=1");
        addnav("Phiole 2","zwischen.php?op=2");
        addnav("Phiole 3","zwischen.php?op=3");
        addnav("Nichts wie weg","zwischen.php");
    }
    if ($session['user']['zufall']==1){
        output(" Du hast Dein Gl�ck heute schon Versucht. Das reicht doch aus.`n`n");addnav("Schade","zwischen.php");
    }
}
if ($_GET['op']=="1")
{
    page_header("Zwischenwelt");
    output("`Du w�hlst die erste der drei Phiolen und...`n`n");
switch(e_rand(1,6)){
case 1:
output("`3...sp�rst keine Wirkung");
    $session['user']['zufall']=1;
    addnav("Weiter","zwischen.php");
    break;
case 2:
    output("`2...Du sp�rst wie sich eine wohlige W�rme in dir Ausbreitet, welche von einem unentlichem Schmerz begleitet wird. Du sackst auf dem Boden zusammen. Als du die Augen wieder �ffnest findest du dich im Dorf wieder. Es hat geklappt");
    $session['user']['zufall']=1;
    
    $session['user']['zwischentage']=0;
    $session['user']['zwischenwelt']=0;
    $session['user']['turns']=0;
    addnav("weiter","village.php");
addnews("{$row[name]}`0 Hatte gro�es Gl�ck in der Zwischenwelt");
    break;
case 3:
    
    output("`2 Der Alte Mann wird pl�tzlich zu einer Grauenerweckenden gestallt. Du rennstw as das Zeug h�llt, doch der Fluch des Alten hat Dich erwischt. Du sitzt weitere 2 tage hier ein.");
    $session['user']['zufall']=1;
    
    $session['user']['zwischentage']+=2;
    addnav("Weiter","zwischen.php");
}
}
if ($_GET['op']=="2")
{
    page_header("Zwischenwelt");
    output("`Du w�hlst die zweite der drei Phiolen und...`n`n");
switch(e_rand(1,6)){
case 1:
output("`3...sp�rst keine Wirkung");
    $session['user']['zufall']=1;
    addnav("Weiter","zwischen.php");
    break;
case 2:
    output("`2...Du sp�rst wie sich eine wohlige W�rme in dir Ausbreitet, welche von einem unentlichem Schmerz begleitet wird. Du sackst auf dem Boden zusammen. Als du die Augen wieder �ffnest findest du dich im Dorf wieder. Es hat geklappt");
    $session['user']['zufall']=1;
    
    $session['user']['zwischentage']=0;
    $session['user']['zwischenwelt']=0;
    $session['user']['turns']=0;
    addnav("weiter","village.php");
addnews("{$row[name]}`0 hatte gro�es Gl�ck in der Zwischenwelt!!!");

    break;
case 3:
    
    output("`2 Der Alte Mann wird pl�tzlich zu einer Grauenerweckenden gestallt. Du rennst was das Zeug h�llt, doch der Fluch des Alten hat Dich erwischt. Du sitzt weitere 2 tage hier ein.");
    $session['user']['zufall']=1;
    
    $session['user']['zwischentage']+=2;
    addnav("Weiter","zwischen.php");
}
}
if ($_GET['op']=="3")
{
    page_header("Zwischenwelt");
    output("`Du w�hlst die letzte der drei Phiolen und...`n`n");
switch(e_rand(1,6)){
case 1:
output("`3...sp�rst keine Wirkung");
    $session['user']['zufall']=1;
    addnav("Weiter","zwischen.php");
    break;
case 2:
    output("`2...Du sp�rst wie sich eine wohlige W�rme in dir Ausbreitet, welche von einem unentlichem Schmerz begleitet wird. Du sackst auf dem Boden zusammen. Als du die Augen wieder �ffnest findest du dich im Dorf wieder. Es hat geklappt");
    $session['user']['zufall']=1;
    
    $session['user']['zwischentage']=0;
    $session['user']['zwischenwelt']=0;
    $session['user']['turns']=0;
    addnav("weiter","village.php");
addnews("{$row[name]}`0 hatte gro�es Gl�ck!!!");

    break;
case 3:
    
    output("`2 Der Alte Mann wird pl�tzlich zu einer Grauenerweckenden gestallt. Du rennst was das Zeug h�llt, doch der Fluch des Alten hat Dich erwischt. Du sitzt weitere 2 Tage hier fest.");
    $session['user']['zufall']=1;
    
    $session['user']['zwischentage']+=2;
    addnav("Weiter","zwischen.php");
}
}

page_footer()
?>
