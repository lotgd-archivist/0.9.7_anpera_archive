<?php 





require_once "common.php"; 

page_header("Banne"); 

if($_GET[op]==""){ 

output("`4Willst du `^$_GET[char]`0 wirklich beschw�ren? "); 
addnav("Ja ich will","banne.php?op=ja&id=$_GET[id]&char=$_GET[char]"); 
addnav("Sonstiges"); 
addnav("Zur�ck","bio.php?id=$_GET[id]&char=$_GET[char]"); 

} 

if($_GET[op]=="ja"){ 




        
              if($_GET[op]=="ja"){ 

$sql="SELECT acctid, name,zwischenwelt,zwischentage,login, level FROM accounts WHERE acctid = '$_GET[id]'";  
$result = db_query($sql) or die(db_error(LINK));  
$row = db_fetch_assoc($result);  

output("`n`n`7Du hast ".$row['name']."`7 in beschworen.",true);  
systemmail($_GET[id],"`^Beschworen!`0",$session[user][name]." hat Dich Beschworen !",$session[user]['acctid']);  

db_query("UPDATE accounts SET zwischentage=zwischentage-1, zwischenwelt = 0  WHERE acctid = '$_GET[id]'"); 

//Newseintrag 
addnews("{$row[name]}wurde in einem kraftraubendem Ritual beschworen!!!");


addnav("Sonstiges"); 
addnav("Zur�ck","bio.php?id=$_GET[id]&char=$_GET[char]"); 


$session[user][turns]--;
                             }   
}   

page_footer(); 
?>