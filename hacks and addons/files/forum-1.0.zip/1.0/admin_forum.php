<?php
 /**
  * Project: Forum hack for Legend of the Green Dragon
  *
  * PHP Version 4 and 5
  *
  * Copyright (C) 2006 Thibaud Roth
  *
  * This program is free software; you can redistribute it and/or
  * modify it under the terms of the GNU General Public License
  * as published by the Free Software Foundation; either version 2
  * of the License, or (at your option) any later version.
  *
  * This program is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  * GNU General Public License for more details.
  *
  * You should have received a copy of the GNU General Public License
  * along with this program; if not, write to the Free Software
  * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
  *
  * @category   Browsergame
  * @package    Legend of the Green Dragon
  * @author     Thibaud Roth <thibaud.roth@betriebsdirektor.de>
  * @copyright  2006 Thibaud Roth
  * @license    http://www.fsf.org/licensing/licenses/gpl.txt GNU GPL Version 2
  * @version    1.0; 28022006
  * @link       http://thibaudroth.magicforrest.de/?lotgd/forum
  */
require_once "common.php";
isnewday(1);

page_header("Diskussionsforum");
addnav("Zur�ck zum Forum","forum.php");

if($_GET["op"] == "edit"){
output("`c`b`9Beitrag editieren`b`c");
$row = mysql_fetch_array(mysql_query("SELECT `title`,`text` FROM `forum` WHERE `id`=".$_GET["id"].""));
addnav("","admin_forum.php?op=update&id=".$_GET["id"]."&topicid=".$_GET["topicid"]."");
output("<table border=\"0\"><form action=\"admin_forum.php?op=update&id=".$_GET["id"]."&topicid=".$_GET["topicid"]."\" method=\"post\">",true);
output("<tr><td>`9`bTitel:`b</td><td><input type=\"Text\" name=\"title\" value=\"".$row["title"]."\" size=\"\" maxlength=\"255\"></td></tr>",true);
output("<tr><td valign=\"top\">`9`bText:`b</td><td valign=\"top\"><textarea name=\"text\" cols=\"20\" rows=\"10\" class=\"input\">".$row["text"]."</textarea></td></tr>",true);
output("<tr><td></td><td><input type=\"Submit\" name=\"submit\" value=\"Editieren\" class=\"button\"></td></tr>",true);
output("</form></table>",true);
}

elseif($_GET["op"] == "update"){
mysql_query("UPDATE `forum` Set `text` = '".$_POST["text"]."', `title` = '".$_POST["title"]."' WHERE `id`=".$_GET["id"]."");
redirect("forum.php?id=".$_GET["topicid"]."&title=".URLEncode($_POST["title"])."");
}

elseif($_GET["op"] == "deletetopic"){
mysql_query("DELETE FROM `forum` WHERE `id`=".$_GET["id"]."");
mysql_query("DELETE FROM `forum` WHERE `sub`=".$_GET["id"]."");
redirect("forum.php");
}

elseif($_GET["op"] == "delete"){
mysql_query("DELETE FROM `forum` WHERE `id`=".$_GET["id"]."");
redirect("forum.php?id=".$_GET["topicid"]."&title=".URLEncode($_GET["title"])."");
}
page_footer();
?>