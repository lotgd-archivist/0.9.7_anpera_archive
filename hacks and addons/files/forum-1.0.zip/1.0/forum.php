<?php
 /**
  * Project: Forum hack for Legend of the Green Dragon
  *
  * PHP Version 4 and 5
  *
  * Copyright (C) 2006 Thibaud Roth
  *
  * This program is free software; you can redistribute it and/or
  * modify it under the terms of the GNU General Public License
  * as published by the Free Software Foundation; either version 2
  * of the License, or (at your option) any later version.
  *
  * This program is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  * GNU General Public License for more details.
  *
  * You should have received a copy of the GNU General Public License
  * along with this program; if not, write to the Free Software
  * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
  *
  * @category   Browsergame
  * @package    Legend of the Green Dragon
  * @author     Thibaud Roth <thibaud.roth@betriebsdirektor.de>
  * @copyright  2006 Thibaud Roth
  * @license    http://www.fsf.org/licensing/licenses/gpl.txt GNU GPL Version 2
  * @version    1.0; 30042006
  * @link       http://thibaudroth.magicforrest.de/?lotgd/forum
  */
require_once "common.php";
checkday();

page_header("Diskussionsforum");
output("`9`c`bDiskussionsforum`c`b`0");
addnav("Neues Thema erstellen","forum.php?op=new");
if(!$_GET["id"]){
if(!$_GET["op"]){
output("`9Herzlich Willkommen im Diskussionsforum zum Spiel! Hier werden Vorschl�ge zu neuen Addons zum Spiel gesammelt und");
output("`9besprochen, Fehler und Bugs gemeldet und sonst alles behandelt, was euch auf dem Herzen liegt.`n`n");
output("`bDie Themen:`b");
    output("<table border=\"0\" cellpadding=\"2\" cellspacing=\"1\" bgcolor=\"#999999\" align=\"center\">",true);
    output("<tr class='trhead'><td><b>Titel</b></td><td><b>Autor</b></td><td><b>Letzte Antwort</b></td></tr>",true);
    $sql = "SELECT forum.id,forum.title,forum.lastreply,accounts.name,accounts.forum_lastvisit,accounts.login FROM forum LEFT JOIN `accounts` USING(acctid) WHERE !forum.sub ORDER BY `lastreply` DESC";
    $result = db_query($sql);
    $max = db_num_rows($result);
    for ($i=0; $row=db_fetch_assoc($result); $i++){
    output("<tr class='".($i%2?"trlight":"trdark")."'>",true);
    addnav("","forum.php?id=".$row["id"]."&title=".URLEncode($row["title"])."");
    if($session[user][forum_lastvisit] <= $row["lastreply"]){
    output("<td><a href=\"forum.php?id=".$row["id"]."&title=".URLEncode($row["title"])."\">`$`b".$row[title]."`b`$</a></td>",true);
    }
    else{
    output("<td><a href=\"forum.php?id=".$row["id"]."&title=".URLEncode($row["title"])."\">".$row[title]."</a></td>",true);
    }
    addnav("","bio.php?char=".$row["login"]."&ret=".URLEncode($_SERVER['REQUEST_URI'])."");
    output("<td><a href=\"bio.php?char=".$row["login"]."&ret=".URLEncode($_SERVER['REQUEST_URI'])."\">".$row["name"]."</a></td>",true);
    $date = date("j.m.Y, G:i","".$row["lastreply"]."");
    output("<td>".$date." Uhr</td>",true);
    if($session['user']['superuser'] >= "1"){
    addnav("","admin_forum.php?op=deletetopic&id=".$row["id"]."");
    output("<td><a href=\"admin_forum.php?op=deletetopic&id=".$row["id"]."\">Thema l�schen</a></td>",true);
    }
    output("</tr>",true);
    }
    output("</table>",true);
    output("`b`iErkl&auml;rungen:`i `$ Thema mit neuen Antworten`b",true);
}
elseif($_GET["op"] == "new"){
    addnav("Zur�ck zur �bersicht","forum.php");
    output("`n`n`b`9Neues Thema erstellen`b");
    addnav("","forum.php?op=insert");
    output("<table border=\"0\"><form action=\"forum.php?op=insert\" method=\"post\">",true);
    output("<tr><td>`9`bTitel:`b</td><td><input type=\"Text\" name=\"title\" value=\"\" size=\"\" maxlength=\"255\"></td></tr>",true);
    output("<tr><td valign=\"top\">`9`bText:`b</td><td valign=\"top\"><textarea name=\"text\" cols=\"40\" rows=\"20\" class=\"input\"></textarea></td></tr>",true);
    output("<tr><td></td><td><input type=\"Submit\" name=\"submit\" value=\"Thema erstellen\"></td></tr>",true);
    output("</form></table>",true);
}
elseif($_GET["op"] == "insert"){
    mysql_query("INSERT INTO forum (acctid, title, text, timestamp, lastreply) VALUES ('".$session["user"]["acctid"]."', '".$_POST["title"]."', '".$_POST["text"]."', '".time()."', '".time()."')");
    $row = mysql_fetch_array(mysql_query("SELECT `id`, `title` FROM `forum` ORDER by `id` DESC"));
    redirect("forum.php?id=".$row["id"]."&title=".URLEncode($row["title"])."");
}
elseif($_GET["op"] == "village"){
    $session[user][forum_lastvisit] = time();
    redirect("village.php");
}
elseif($_GET["op"] == "shades"){
    $session[user][forum_lastvisit] = time();
    redirect("shades.php");
}
}
elseif($_GET["op"] == "reply"){
    mysql_query("INSERT INTO forum (acctid, title, text, sub, timestamp) VALUES ('".$session["user"]["acctid"]."', '".$_POST["title"]."', '".$_POST["text"]."', '".$_GET["id"]."', '".time()."')");
    mysql_query("UPDATE `forum` SET `lastreply`=".time()." WHERE `id`=".$_GET["id"]."");
    redirect("forum.php?id=".$_GET["id"]."&title=".URLEncode($_GET["title"])."");
}
else{
    addnav("Zur�ck zur �bersicht","forum.php");
    output("<table border=\"0\" cellpadding=\"2\" cellspacing=\"1\" bgcolor=\"#999999\" align=\"center\">",true);
    output("<tr class=\"trhead\"><td><b>".$_GET["title"]."</b></td><td><b></b></td></tr>",true);
    $sql = "SELECT forum.id,forum.title,forum.timestamp,forum.text,accounts.name,accounts.login FROM forum LEFT JOIN `accounts` USING(acctid) WHERE forum.id = ".$_GET["id"]." OR forum.sub = ".$_GET["id"]." ORDER BY `timestamp`";
    $result = db_query($sql);
    $max = db_num_rows($result);
    for ($i=0; $row=db_fetch_assoc($result); $i++){
    output("<tr class=\"".($i%2?"trlight":"trdark")."\">",true);
    $date = date("j.m.Y, G:i","".$row["timestamp"]."");
    addnav("","bio.php?char=".$row[login]."&ret=".URLEncode($_SERVER['REQUEST_URI'])."");
    output("<td valign=\"top\">`b`c<a href=\"bio.php?char=".$row["login"]."&ret=".URLEncode($_SERVER['REQUEST_URI'])."\">".$row[name]."</a>`c`b",true);
    output("`c<a href=\"mail.php?op=write&to=$row[login]\" target=\"_blank\" onClick=\"".popup("mail.php?op=write&to=$row[login]").";return false;\"><img src='images/newscroll.GIF' width='16' height='16' alt='Mail schreiben' border='0'></a>`c",true);
    output("`n`n<div align=\"right\"><em>".$date." Uhr</em>",true);
    if($session['user']['superuser'] >= "1"){
    addnav("","admin_forum.php?op=edit&id=".$row["id"]."&title=".URLEncode($_GET["title"])."&topicid=".$_GET["id"]."");
    addnav("","admin_forum.php?op=delete&id=".$row["id"]."&title=".URLEncode($_GET["title"])."&topicid=".$_GET["id"]."");
    output("`n<a href=\"admin_forum.php?op=edit&id=".$row["id"]."&title=".URLEncode($_GET["title"])."&topicid=".$_GET["id"]."\">Post bearbeiten</a> &bull; <a href=\"admin_forum.php?op=delete&id=".$row["id"]."&title=".URLEncode($_GET["title"])."&topicid=".$_GET["id"]."\">Post l�schen</a>",true);
    }
    output("</div></td>",true);
    $row["text"] = nl2br($row["text"]);
    output("<td valign=\"top\">`b".$row["title"]."`b`n".$row["text"]."</td>",true);
    output("</tr>",true);
    }
    output("</table>",true);
    output("`n`n`b`9Antwort erstellen`b");
    addnav("","forum.php?op=reply&id=".$_GET["id"]."&title=".URLEncode($_GET["title"])."");
    output("<table border=\"0\"><form action=\"forum.php?op=reply&id=".$_GET["id"]."&title=".URLEncode($_GET["title"])."\" method=\"post\">",true);
    output("<tr><td>`9`bTitel:`b</td><td><input type=\"Text\" name=\"title\" value=\"Re: ".$_GET["title"]."\" size=\"\" maxlength=\"255\"></td></tr>",true);
    output("<tr><td valign=\"top\">`9`bText:`b</td><td valign=\"top\"><textarea name=\"text\" cols=\"30\" rows=\"10\" class=\"input\"></textarea></td></tr>",true);
    output("<tr><td></td><td><input type=\"Submit\" name=\"submit\" value=\"Antwort posten\" class=\"button\"></td></tr>",true);
    output("</form></table>",true);
}
if($session['user']['alive']){
addnav("Zur�ck ins Dorf und...");
addnav("Themen als gelesen markieren","forum.php?op=village");
addnav("Themen ungelesen zur�cklassen","village.php");
}
else{
addnav("Zur�ck zu den Schatten und...");
addnav("Themen als gelesen markieren","forum.php?op=shades");
addnav("Themen ungelesen zur�cklassenlassen","shades.php");
}
page_footer();
?>