<?php
/*Idee by Eichi Version 0.3
Grundger�st teilweise der Cruxis.php von Elliwood entnommen und noch ein Danke f�r Squalls Hilfe bei der Umsetzung!
 ----------------------------------------
 | Einfach irgendwo den Link             |
 | addnav("W�ste","kaktor.php");         |
 | einbauen... Zum Beispiel in der       |
 | Village.php unter dem Wald...         |
 | Die Kaktor.php ins Root-Verzeichnis,  |
 | Kaktorius.JPG ins Images-Verzeichnis  |
 | und fighting.mid ins Media-Verzeichnis|
 | kopieren ^.~                          |
 | Viel Spa� damit *g*                   |
 ----------------------------------------
*/
require_once "common.php";
page_header("Die W�ste");
if ($_GET[op]=="")
{
 if ($session[user][turns]<4 && $session[user][turns]>0) /* Jenachdem wie oft, von wann bis wann ein User in die W�ste d�rfen soll*/
{
 $session[kaktor]=0;
 if (!$session['user']['prefs']['nosounds'])
 output("Du beschlie�t das Dorf �ber die Steppe zu verlassen, die gegen�ber vom Wald liegt.`n");
 output("Nach einigen Stunden Wandern bist du nun am Rand der Steppe angekommen und siehst eine karge und verlassene W�ste vor dir.`n");
 output("Langsam f�ngst du an zu �berlegen ob es �berhaupt sinnvoll war hiererzukommen und siehst nochmal zur�ck.`n");
 addnav("In die W�ste","kaktor.php?op=go");
 addnav("Zur�ck zum Dorf","village.php");
 $badguy = array(
 "creaturename"=>"`@Kaktor`0"
 ,"creaturelevel"=>16
 ,"creatureweapon"=>"`@1000 Stacheln"
 ,"creatureattack"=>25
 ,"creaturedefense"=>25
 ,"creaturehealth"=>250
 ,"diddamage"=>0);
 $session[user][badguy]=createstring($badguy);
 $atkflux = e_rand(0,$session['user']['dragonkills']*2);
 $defflux = e_rand(0,($session['user']['dragonkills']*2-$atkflux));
 $hpflux = ($session['user']['dragonkills']*2 - ($atkflux+$defflux)) * 5;
 $badguy['creatureattack']+=$atkflux;
 $badguy['creaturedefense']+=$defflux;
 $badguy['creaturehealth']+=$hpflux;
 }else{
 output("Du irrst umher und siehst es als sinnlos an hier noch weiter irgendwelche Zeit dran zu vergeuden, du gehst zur�ck ins Dorf.`n `4Sp�ter villeicht`0, denkst du dir.`n");
 addnav("Zur�ck","village.php");
 }
 }
if ($_GET[op]=="go")
{
 output("Du warst etwas geschockt, als dieses Wesen auf Dich sprang und Dich angriff");
 output("w�tend l�ufts Du nun tiefer in die W�ste hinein und beginnst den �berblick zu verlieren.`n");
 output("Pl�tzlich erschreckst du. Ein weiterer Kaktor springt Dir entgegen.`n");
 output("Aber du hast noch nicht vergessen in welche Richtung du wohl ungef�hr laufen m�sstest, falls du doch das Heil in der Flucht suchen wolltest.`n");
 output("Was tust du nun?");
 $session[user][turns]-=1;
 addnav("K�mpfe","kaktor.php?op=fight");
 addnav("Reden","kaktor.php?op=reden1");
 addnav("Fl�chte in Furcht","village.php");
}
if ($_GET[op]=="reden1")
{
 output("Der Kaktor schaut dich leicht verwirrt an und mustert dich.`n");
 output("Schon nach kurzer Zeit wendet sich der Kaktor um und zeigt mit einem �rmchen in eine Richtung zur W�ste hinaus.`n");
 output("Du siehst den Kaktor langsam von dir weggehen, du denkst dir, dass dies ein guter Augenblick w�re ihn von hinten zu ermeucheln.`n");
 addnav("Den Kaktor zu einem fairen Kampf herausfordern","kaktor.php?op=fight");
 addnav("Den Kaktor von hinten ermeucheln","kaktor.php?op=death1");
 addnav("Den Kaktor fragen wo er hingehen will","kaktor.php?op=reden2");
 addnav("Dem Kaktor folgen","kaktor.php?op=folgen");
 addnav("versuchen wieder zum Dorf zur�ck zu finden","kaktor.php?op=death2");
 addnav("Willk�rlich in irgendeine Richtung laufen","kaktor.php");
 }
if ($_GET[op]=="death1")
{
 output("Ohne an weitere Konsequenzen zu denken st�rzt du dich auf den Kaktor.`n");
 output("Doch noch im selben Moment, in dem du deine Waffe ziehst, sp�rst du wie dich von hinten tausend Stacheln durchbohren.`n");
 output("Voller Qualen f�llst du in den Sand und entschwindest ins Reich der Toten...`n");
 addnews($session[user][name]." hat die Kaktoren w�tend gemacht!");
 output("`n`4Du bist tot.`n");
 output("Du verlierst 30% deiner Erfahrung, weil du so unehrenhaft gehandelt hast und alles Gold.`n");
 output("Du kannst morgen weiterspielen.");
 $session[user][gold]=0;
 $session[user][experience]=round($session[user][experience]*0.7);
 $session[user][alive]=0;
 $session[user][hitpoints]=0;
 $session[user][specialinc]="";
 $session[user][reputation]--;
 addnav("T�gliche News","news.php");
 }
 
 if ($_GET[op]=="death2")
{
 switch(e_rand(1,10))
 {
 case 1:
 case 2:
 case 3:
 case 4:
 output("Du irrst durch die W�ste und durstest stark.`n");
 output("Schon bald sp�rst du, dass du hier sterben wirst, ohne eine Ahnung wo du hier bist, verlierst du all dein Gold und alle Edelsteine.`n");
 addnews($session[user][name]." ist in der W�ste bei lebendigem Leibe verbrannt!");
 output("`n`4Du bist qualvoll verreckt.`n");
 output("Du verlierst 3% deiner Erfahrung, alles Gold und alle Edelsteine.`n");
 output("Du kannst morgen weiterspielen.");
 $session[user][gold]=0;
 $session[user][gems]=0;
 $session[user][experience]=round($session[user][experience]*0.97);
 $session[user][alive]=0;
 $session[user][hitpoints]=0;
 $session[user][specialinc]="";
 $session[user][reputation]--;
 addnav("T�gliche News","news.php");
 break;
 case 5:
 output("Da hattest gl�ck, kurz vor dem Verdursten findest du den Rand der W�ste!`n");
 addnav("Zur�ck zum Dorf","kaktor.php");
 break;
 case 6:
 case 7:
 output("Du triffst auf der Suche nach dem Dorf auf einen Kaktor...");
 addnav("Weiter","kaktor.php?op=fight");
 break;
 case 8:
 case 9:
 case 10:
 output("Du irrst umher aber glaubst dann doch am Horizont das Dorf erkennen zu k�nnen!");
 addnav("Weiter","kaktor.php?op=vil");
 break;
 }
}
 if ($_GET[op]=="reden2")
{
 output("Der Kaktor scheint dich nicht zu beachten und geht seines Weges.`n");
 output("Du h�rst hinter dir ein leises Rascheln, drehst dich schnell um, kannst jedoch nichts sehen.`n");
 output("Wieder drehst du dich um, wo der eine Kaktor hingelaufen ist, du siehst ihn nicht, kannst aber noch erahnen wo er hingelaufen ist.`n");
 addnav("Versuchen dem Kaktor zu folgen","kaktor.php?op=folgen2");
 addnav("versuchen wieder zum Dorf zur�ck zu finden","kaktor.php?op=death2");
 addnav("Willk�rlich in irgendeine Richtung laufen","kaktor.php?op=vil");
 }
 
 if ($_GET[op]=="folgen")
 {
 output("Ihr wandert nun schon fast eine Stunde, sch�tzt du, und du hast die Orientierung verloren, du beginnst zu verstehen, der Kaktor f�hrt nichts gutes im Schilde!`n");
 addnav("Dem Kaktor einfach weiter folgen","kaktor.php?op=folgen3");
 addnav("Den Kaktor ansprechen","kaktor.php?op=reden3");
 addnav("Dieses Mal versuchen den Kaktor umzubringen","kaktor.php?op=death1");
 addnav("Weglaufen","kaktor.php?op=death3");
 }
 if ($_GET[op]=="reden3")
 {
 output("Der Kaktor ignoriert dich...`n");
 addnav("Dem Kaktor wieder folgen","kaktor.php?op=folgen3");
 addnav("Das l�sst du dir doch nicht gefallen, den Kaktor mal richtig anschnauzen!","kaktor.php?op=reden4");
 addnav("Den Kaktor treten!","kaktor.php?op=death1");
 addnav("Weglaufen","kaktor.php?op=death2");
 }
 if ($_GET[op]=="reden4")
 {
 output("Der Kaktor sieht dich etwas skeptisch aber auch leicht am�siert an, dreht sich dann wieder um und l�uft weiter seines Weges`n");
 addnav("Folgen","kaktor.php?op=folgen3");
 addnav("Den Kaktor ansprechen","kaktor.php?op=reden3");
 addnav("Anfangen dem Kaktor deine Lebensgeschichte zu erz�hlen","kaktor.php?op=reden5");
 addnav("Den Kaktor schlagen","kaktor.php?op=schlag");
 addnav("Weglaufen","kaktor.php?op=vil");
 }
 if ($_GET[op]=="reden5")
 {
 output("Der Kaktor scheint sichlich angenervt zu sein von deiner laahmkraamigen Geschichte und greift dich an!`n");
 addnav("Den Kaktor bek�mpfen!","kaktor.php?op=fight");
 addnav("Weglaufen","kaktor.php?op=death2");
 }
 if ($_GET[op]=="schlag")
 {
 output("Der Kaktor weicht dir aus und beschie�t dich mit mehreren Stacheln, l�uft dann weiter...`n");
 output("Du ziehst dir die Stacheln unter Schmerzen wieder raus, sackst ein wenig zusammen und findest dabei auf dem Boden einiges an Gold und ein paar Edelsteine.`n");
 addnav("Den Kaktor bek�mpfen!","kaktor.php?op=fight");
 $session[user][gems]=3;
 $session[user][gold]=3000;
 $session[user][hitpoints]=round($session[user][hitpoints]*0.25);
 addnav("Anfangen dem Kaktor deine Lebensgeschichte zu erz�hlen","kaktor.php?op=reden5");
 addnav("Weglaufen","kaktor.php?op=vil");
 addnav("Den Kaktor treten!","kaktor.php?op=death1");
 }
 if ($_GET[op]=="death3")
{
 output("So ein Pech, ohne hinzuschauen wo du hinl�ufst landest du in Treibsand.`n");
 output("Du versinkst im Sand, versuchst zwar um Hilfe zu schreien, doch das Spuckkraut, das hier im Sandloch lebt denkt nicht daran dich zu retten.`n");
 output("Gen�sslich knabbert das Spuckkraut an dir ohne dass du dich wehren kannst.`n");
 addnews($session[user][name]." ist in der W�ste verschollen!");
 output("`n`4Du wurdest bei lebendigem Leibe verspeist.`n");
 output("Du verlierst 5% deiner Erfahrung und alles Gold.`n");
 output("Du kannst morgen weiterspielen.");
 $session[user][gold]=0;
 $session[user][experience]=round($session[user][experience]*0.95);
 $session[user][alive]=0;
 $session[user][hitpoints]=0;
 $session[user][specialinc]="";
 $session[user][reputation]--;
 addnav("T�gliche News","news.php");
 }
 if ($_GET[op]=="folgen3")
{
 output("Du taperst dem Kaktor hinterher wie ein treudoofer Hund.`n");
 output("Vor dir kannst du eine H�hle sehen, der Kaktor l�uft hinein und es kommt ein gro�er Kaktor heraus.`n");
 output("Das ist kein normaler Kaktus, er ist riesig!`n");
 addnav("Weiter","kaktor.php?op=fight");
 $session[kaktor]+=2;
 }
 
 if ($_GET[op]=="folgen2")
 
 {
 switch(e_rand(1,6))
 {
 case 1:
 case 2:
 case 3:
 output("Du hast den Kaktor wiedergefunden und rennst ihm hinterher, gespannt wo es denn hingehen soll.`n");
 output("Ihr wandert nun schon fast eine Stunde, sch�tzt du, und du hast die Orientierung verloren, du beginnst zu verstehen, der Kaktor f�hrt nichts gutes im Schilde!`n");
 addnav("Dem Kaktor folgen","kaktor.php?op=folgen3");
 addnav("Den Kaktor etwas zur�ckhaltend vorsichtig fragen was er vor hat und wo er hin m�chte","kaktor.php?op=reden3");
 addnav("Den Kaktor etwas aufm�pfig anquatschen wo er denn mit dir hin will","kaktor.php?op=reden4");
 addnav("Sauer dem Kaktor eine r�ber ziehen","kaktor.php?op=death1");
 addnav("Weglaufen","kaktor.php?op=death2");
 break;
 case 4:
 output("Du irrst durch die W�ste und durstest stark.`n");
 output("Schon bald sp�rst du, dass du hier sterben wirst, ohne eine Ahnung wo du hier bist, verlierst du all dein Gold und alle Edelsteine.`n");
 addnews($session[user][name]." ist in der W�ste bei lebendigem Leibe verbrannt!");
 output("`n`4Du bist qualvoll verreckt.`n");
 output("Du verlierst 3% deiner Erfahrung, alles Gold und alle Edelsteine.`n");
 output("Du kannst morgen weiterspielen.");
 $session[user][gold]=0;
 $session[user][gems]=0;
 $session[user][experience]=round($session[user][experience]*0.97);
 $session[user][alive]=0;
 $session[user][hitpoints]=0;
 $session[user][specialinc]="";
 $session[user][reputation]--;
 addnav("T�gliche News","news.php");
 break;
 case 5:
 output("Du triffst auf der Suche nach dem Dorf auf einen Kaktor...");
 addnav("Weiter","kaktor.php?op=fight");
 break;
 case 6:
 output("Ein Wurm!");
 addnav("Weiter","kaktor.php?op=vil");
 break;
 }
}
if ($_GET[op]=="fight")
{
 $battle=true;
}
if ($battle)
{
 include ("battle.php");
 if ($victory)
 {
 output("`nDu hast ".$badguy['creaturename']." geschlagen.");
 $badguy=array();
 $session[user][badguy]="";
 $session[kaktor]+=1;
 }
 elseif($defeat)
 {
 output("Du wurdest get�tet! Deine Reicht�mer liegen nun hier in der W�ste verstreut, vielleicht findest du sie ja n�chstes Mal wieder...");
 addnews($session[user][name]." ist in der W�ste verschollen!");
 output("`n`4Du bist tot.`n");
 output("Du verlierst 10% deiner Erfahrung, alles Gold und alle Edelsteine.`n");
 output("Du kannst morgen weiterspielen.");
 $session[user][gold]=0;
 $session[user][gems]=0;
 $session[user][experience]=round($session[user][experience]*0.9);
 $session[user][alive]=0;
 $session[user][hitpoints]=0;
 $session[user][specialinc]="";
 $session[user][reputation]--;
 addnav("T�gliche News","news.php");
 }
 else
 {
 fightnav();
 }
}
if($session[kaktor]==1){
$session[kaktor]+=1;
addnav("Weiter","kaktor.php?op=goa");
}
if($session[kaktor]==3){
$session[kaktor]+=1;
addnav("Weiter","kaktor.php?op=end");
}
if($session[kaktor]==5){
$session[kaktor]+=1;
addnav("Weiter","kaktor.php?op=Kisten");
}
if($session[kaktor]==7){
$session[kaktor]+=1;
addnav("Weiter","kaktor.php?op=bttv");
}
if ($_GET[op]=="bttv")
{
 output("Du hast es geschafft, stolz schaust du nochmal zu diesem Unget�m und blickst dich dann gen Dorf`n");
 output("Mit erhobenen Hauptes stolzierst du zum Dorf, wobei du die ganzen Edelsteine die hier �berall rumliegen garnicht bemerkst...!`n");
 addnews("`qEs wurde die Leiche eines riesigen `QWurmes`q in der N�he der W�ste entdeckt");
 addnav("Zur�ck ins Dorf","village.php");
}
if ($_GET[op]=="goa")
{
 output("Du betrittst den W�stenpfad , die Sonne brennt und �berall ist nur Sand zusehen");
 output("du bist ersch�pft und durstig..du siehst eine kleine Oase.`n");
 output("Nach einer Weile kommst du dort an.");
 addnav("Weiter","kaktor.php?op=gob");
}
if ($_GET[op]=="gob")
{
page_header("Die Kaktoren greifen an!");
 switch(e_rand(1,3))
 {
 case 1:
 output("Du gehst unvorsichtig weiter und trittst in eine Sandfalle.`n");
 output("Du verlierst einige Lebenspunkte, doch gewinnst du an Erfahrung, da du nun weisst, wo du deine Schritte hinsetzetn musst.");
 $session['user']['hitpoints']*=0.9;
 $session['user']['experience']*=1.02;
 addnav("Weiter","kaktor.php?op=goc");
 break;
 case 2:
 output("Du siehst rechtzeitig eine Falle und weichst ihr gekonnt aus.`n`n");
 output("Du weisst, dass dieser Ort voller Fallen ist und gewinnst an Erfahrung");
 $session['user']['experience']*=1.01;
 addnav("Weiter","kaktor.php?op=goc");
 break;
 case 3:
 output("Du siehst bei der Oase einen kleinen Wassersprung und willst daraus einen Schluck trinken.`n`n");
 output("Du f�hlst dich von dem Wasser erfrischt und bist voller Energie.");
 $session['user']['hitpoints'] = $session['user']['maxhitpoints'];
 addnav("Weiter","kaktor.php?op=goc");
 break;
 }
}
if ($_GET[op]=="goc")
{
 page_header("Die W�ste der W�chter");
 output("Nach der Erfrischung, l�ufts Du weiter und erkundest die W�ste etwas.");
 output("Du weisst, dass dies ein gef�hrlicher Ort ist, jedoch kann es sich lohnen nach Sch�tzen zu suchen");
 output("Pl�tzlich siehst du eine ganze Armee von Kaktoren, die sich auf dich st�rzen. Was willst du nun tun?");
 addnav("Bek�mpfe diese Viecher","kaktor.php?op=f2");
 addnav("Blo� weg hier","kaktor.php?op=tot1");
}
if ($_GET[op]=="f2")
{
 output("Du schl�gst dich durch die Masse und die Kaktoren ergreifen die Flucht.`n");
 output("Du merkst es schon fast zu sp�t, als ein Kaktor stehen bleibt.");
 output("Dieser grinst Dich an und meint.`n`n");
 output("\"Wer bist du, wie kannst du es wagen, uns W�chter zut�ten? Wir, besch�tzen diese W�ste vor Dieben wie Dich.");
 output("Ich werde, nicht aufgeben, ehe Du tot bist. STIRB!!\"");
 addnav("K�mpfe","kaktor.php?op=fight");
 $badguy = array(
 "creaturename"=>"`@gro�er Kaktorw�chter`0"
 ,"creaturelevel"=>17
 ,"creatureweapon"=>"`@1000 spitze Stacheln"
 ,"creatureattack"=>36
 ,"creaturedefense"=>36
 ,"creaturehealth"=>360
 ,"diddamage"=>0);
 $session[user][badguy]=createstring($badguy);
 $atkflux = e_rand(0,$session['user']['dragonkills']*2);
 $defflux = e_rand(0,($session['user']['dragonkills']*2-$atkflux));
 $hpflux = ($session['user']['dragonkills']*2 - ($atkflux+$defflux)) * 5;
 $badguy['creatureattack']+=$atkflux;
 $badguy['creaturedefense']+=$defflux;
 $badguy['creaturehealth']+=$hpflux;
}
if ($_GET[op]=="tot1")
{
 output("Die Armee der Kaktoren hat dich umzingelt und macht aus dir ein Nadelkissen.`n`n");
 output("`c`\$Du bist Tod. Du verlierst dein ganzes Gold, alle Edelsteine und 3% deiner Erfahrung und kannst morgen weiter spielen`c`0");
 $session['user']['gold']=0;
 $session['user']['gems']=0;
 $session['user']['experience']*=0.97;
 $session['user']['alive']=false;
 $session['user']['hitpoints']=0;
 addnews($session[user][name]."'`tHat die `2Kaktoren`t w�tend gemacht ");
 addnav("T�gliche News","news.php");
}
if ($_GET[op]=="end")
{
 output(" `n");
 output("<img src='images/kaktorius.JPG' border='0' align=center alt='Kaktorius'>",true);
 output(" `n`n");
 output("<embed src=\"media/fighting.mid\" width=10 height=10 autostart=true loop=true hidden=false volume=100>",true);
 output("Du betritts nun eine H�hle die hinter der Oase lag, Du tritts und h�rst eine w�tendene Stimme:");
 output("\"Wer wagt es, dieses Heiligtum zu betreten? Wie konnten die W�chter verlieren?");
 output("Doch nun bist zu zu weit gegangen, mein Lieber. STIRB!\"");
 addnav("K�mpfe","kaktor.php?op=fight");
 addnav("Stirb lieber","kaktor.php?op=tot2");
 $badguy = array(
 "creaturename"=>"`2Kaktorius`0"
 ,"creaturelevel"=>20
 ,"creatureweapon"=>"`210000 t�dliche Stacheln"
 ,"creatureattack"=>64
 ,"creaturedefense"=>48
 ,"creaturehealth"=>500
 ,"diddamage"=>0);
 $session[user][badguy]=createstring($badguy);
 $atkflux = e_rand(0,$session['user']['dragonkills']*2);
 $defflux = e_rand(0,($session['user']['dragonkills']*2-$atkflux));
 $hpflux = ($session['user']['dragonkills']*2 - ($atkflux+$defflux)) * 5;
 $badguy['creatureattack']+=$atkflux;
 $badguy['creaturedefense']+=$defflux;
 $badguy['creaturehealth']+=$hpflux;
}
if ($_GET[op]=="vil")
{
 output("Du l�ufst Stunde f�r Stunde durch diese elendige W�ste und beginnst schon bald zu verstehen, dass du hier wohl bald die Welt von unten sehen wirst...`n");
 output("Du hast schon einen mordsdurst und kriechst auf allen Vieren, doch dein Wille zu leben gibt dir nocheinmal Kraft, du springst auf und l�ufst nochmal mit aller Kraft, bis du schlie�lich doch noch das Dorf am Hotizont erkennen kannst!`n");
 output("Doch das Schicksal meint es nicht gut mit dir und direkt vor dir schie�t ein riesiger Wurm aus dem Boden und droht dich aufzufressen!`n");
 output("Sofort wird dir klar, entweder du versuchst zu fliehen und verdurstest in der W�ste oder du l�sst dich auffressen...");
 addnav("Aufgefressen werden","kaktor.php?op=fight");
 addnav("Verdursten","kaktor.php?op=tot2");
 $session[kaktor]+=6;
 $badguy = array(
 "creaturename"=>"`qAbyss`Qwurm`0"
 ,"creaturelevel"=>15
 ,"creatureweapon"=>"`qErd`Qbeb`qen"
 ,"creatureattack"=>12
 ,"creaturedefense"=>10
 ,"creaturehealth"=>2500
 ,"diddamage"=>0);
 $session[user][badguy]=createstring($badguy);
 $atkflux = e_rand(0,$session['user']['dragonkills']*2);
 $defflux = e_rand(0,($session['user']['dragonkills']*2-$atkflux));
 $hpflux = ($session['user']['dragonkills']*2 - ($atkflux+$defflux)) * 5;
 $badguy['creatureattack']+=$atkflux;
 $badguy['creaturedefense']+=$defflux;
 $badguy['creaturehealth']+=$hpflux;
}
if ($_GET[op]=="tot2")
{
 output("Du kehrst der merkw�rdigen Kaktoren den R�cken und fliehst, so schnell du kannst, doch du hast dich zu fr�h gefreut.`n`n");
 output("\"Wuhaaa!\", schreit Kaktorius.");
 output("Du wirst von 10000 Stacheln getroffen und f�llst blutend um, bis die Person sagt:`n");
 output("\"Wuhaaa. Das hast du davon, mir den R�cken zu kehren. Nun stibst du einen Tod, der nicht gerade sch�n ist.\"`n`n`n");
 output("`c`\$Du bist Tod. Du verlierst all dein Gold, alle Edelsteine und 5% deiner Erfahrung. Du kannst morgen weiter spielen.`c`n`n");
 $session['user']['gold']=0;
 $session['user']['gems']=0;
 $session['user']['experience']*=0.95;
 $session['user']['alive']=false;
 $session['user']['hitpoints']=0;
 addnews($session[user][name]."s Leiche wurde von 10000 Stacheln duchbohrt in der W�ste gefunden");
 addnav("T�gliche News","news.php");
}
if ($_GET[op]=="Kisten")
{
 $session[kaktor]=0;
 output("Du warst in der W�ste erfolgreich und hast allen Gefahren getrotzt und verl�sst die H�hle zufrieden.`n`n");
 output("Auf dem Weg nach Hause siehst du Schatztruhen in der W�ste stehen, komisch vorher waren diese noch nicht da..denkst Du Dir?");
 output("was solls, kann ja nicht Schaden...sie zu�ffnen `n");
 addnav("Kleine Schatztruhe","kaktor.php?op=b1");
 addnav("Mittlere Schatztruhe","kaktor.php?op=b2");
 addnav("Gro�e Kiste","kaktor.php?op=b3");
 addnews($session[user][name]."`t hat die Kaktoren ungl�cklich gemacht!");
}
if ($_GET[op]=="b1")
{
 switch(e_rand(1,7))
 {
 case 1:
 case 2:
 output("Du entscheidest dich f�r die kleine Schatztruhe und �ffnest sie.`n");
 output("\"`7Ah ja,`0\", murmelts du, \"`7du bekommst ein paar Donationpunkte.`0\"`n`n");
 addnav("Zur�ck in ins Dorf","village.php");
 $session['user']['donation']+=25;
 break;
 case 3:
 case 4:
 case 5:
 output("Du entscheidest dich f�r die kleine Schatztruhe und �ffnest sie.`n");
 output("\"`7Ah ja,\", murmelts du, \"`7du bekommst Gold.0\"`n`n");
 addnav("Zur�ck in ins Dorf","village.php");
 $session['user']['gold']+=2500;
 break;
 case 6:
 case 7:
 output("Du entscheidest dich f�r die kleine Schatztruhe und �ffnest sie.`n");
 output("\"`7Hahahaha,\", lacht ein Kaktor der in der Truhe war, \"`7B�hhh.\"`n`n");
 output("Du brichst zusammen und merkst, als du wieder aufwachst, dass dir alles Gold gestohlen wurde.");
 addnav("Weiter","village.php");
 $session['user']['gold']=0;
 $session['user']['experience']*=1.05;
 break;
 }
}
if ($_GET[op]=="b2")
{
 switch(e_rand(1,7))
 {
 case 1:
 output("Du entscheidest dich f�r die mittlere Schatztruhe und �ffnest sie. Im innern ist ein Fl�schchen, das du �ffnest und tinkst.`n");
 output("\"`7Hahahaha,`0\", lacht ein Kaktor der hinter Dir steht, \"`7Du bist nicht w�rdig davon zukosten.`0\"`n`n");
 output("Du merkst, dass dieser Trank eklig schmeckt und du an Kraft verlierst.");
 addnav("Zur�ck in ins Dorf","village.php");
 $session['user']['attack']*=0.95;
 break;
 case 2:
 output("Du entscheidest dich f�r die mittlere Schatztruhe und �ffnest sie. Im innern ist ein Fl�schchen, das du �ffnest und tinkst.`n");
 output("\"`7Ah, der Trank der St�rke,`0\", meint der Kaktor hinter dir, \"`7Dies ist eines meiner besten St�cke. Nun gut, jetzt bist du st�rker`0\"`n`n");
 addnav("Erfreut l�ufst du zur�ck","village.php");
 $session['user']['attack']*=1.05;
 break;
 case 3:
 case 4:
 output("Du entscheidest dich f�r die mittlere Schatztruhe und �ffnest sie. Im innern ist ein St�ck Pergament.`n");
 output("\"`7Ah, der Gutschein der J�gerh�tte,`0\", meint ein kleiner Kaktor, \"`7Du bekommst wohl oder �ber 10 Punkte gutgeschrieben.`0\"`n`n");
 addnav("Erfreut l�ufst du zur�ck","village.php");
 $session['user']['donation']+=12;
 break;
 case 5:
 case 6:
 output("Du entscheidest dich f�r die mittlere Schatztruhe und �ffnest sie. Im innern ist ein St�ck Pergament.`n");
 output("\"`7Ah, das Papier der Edelsteine,`0\", meint ein molliger Kaktor, \"`7Du hast Gl�ck.`0\"`n`n");
 addnav("Lachend l�ufst du ins Dorf zur�ck","village.php");
 $session['user']['gems']+=10;
 break;
 case 7:
 output("Du entscheidest dich f�r die mittlere Schatztruhe und �ffnest sie. Du siehst einen gro�en Sack darin.`n");
 output("Du nimmst den Sack an dich und schaust hinein. 5000 Gold sind nun dein!");
 addnav("Mit einem breiten grinsen gehst du wieder ins Dorf zur�ck","village.php");
 $session['user']['gold']+=5000;
 break;
 }
}
if ($_GET[op]=="b3")
{
 switch(e_rand(1,7))
 {
 case 1:
 output("Du entscheidest dich f�r die gro�e Kiste und �ffnest sie. Im innern ist ein Fl�schchen, das du �ffnest und tinkst.`n");
 output("\"`7Hahahaha,`0\", Kaktor der Witzige, \"Du darfst das nicht trinken.`0\"`n`n");
 output("Du merkst, dass du schw�cher wie vorher bist und brichst dann bewusstlos zusammen. Du hast an Verteidung verloren.");
 addnav("Du kommst im Wald zu dir","forest.php");
 $session['user']['defence']*=0.95;
 break;
 case 2:
 output("Du entscheidest dich f�r die gro�e Kiste und �ffnest sie. Im innern ist ein Fl�schchen, das du �ffnest und tinkst.`n");
 output("\"`7Ah, der Trank des Schildes,`0\", meint Kaktor Witzig, \"`7Dies ist eines meiner besten St�cke. Nun gut, jetzt bist du st�rker`0\"`n`n");
 output("Du merkst, dass du widerstandf�higer bist, brichst aber trotzdem bewusstlos zusammen. Du hast an Verteidigung dazugewonnen.");
 addnav("Du l�uft zufrieden zur�ck","village.php");
 $session['user']['defence']*=1.05;
 break;
 case 3:
 case 4:
 output("Du entscheidest dich f�r die Kiste und �ffnest sie. Im innern ist ein St�ck Pergament.`n");
 output("\"`7Ah, der Gutschein der J�gerh�tte,`0\", meint Kaktor Hummelbrot, \"`7Du bekommst wohl oder �ber 15 Punkte gutgeschrieben.`0\"`n`n");
 output("Du freust dich �ber die Punkte und gehts zur�ck.");
 addnav("Du grisnt h�hnisch und l�ufst zur�ck","village.php");
 $session['user']['donation']+=25;
 break;
 case 5:
 case 6:
 case 7:
 output("Du entscheidest dich f�r die gro�e Kiste und �ffnest sie. Im innern ist ein St�ck Pergament.`n");
 output("\"`7Ah, das Papier der Edelsteine,`0\", meint Kaktor H�ndler \"`7Du hast Gl�ck.`0\"`n`n");
 addnav("Hoch erfreut gehst du zum Dorf zur�ck","village.php");
 $session['user']['gems']+=10;
 break;
 }
}
page_footer();
?>