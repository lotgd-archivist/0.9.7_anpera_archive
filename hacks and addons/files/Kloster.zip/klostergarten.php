<?php
// Idee und Umsetzung
// Morpheus aka Apollon 
// 2006 f�r Morpheus.Lotgd(LoGD 0.9.7 +jt ext (GER) 3)
// Mail to Morpheus@magic.ms or Apollon@magic.ms
// gewidmet meiner �ber alles geliebten Blume
require_once "common.php";
page_header("Der Klostergarten");
addcommentary();
if($_GET['op']==""){
	output("`b`c`2Der Klostergarten`c`b`n");
	output("`2Du betrittst den Klostergarten, eine Ort der Ruhe, in dem die M�nche ihre Entspannung von den M�hen des Tages suchen und wo auch die Obstb�ume des Klosters stehen.");
	output("Die Luft ist angenehm warm, die Wiesen sind saftig gr�n und �berall bl�hen Blumen in den sch�nsten Farben, in der Mitte des Parkteils ist ein kleiner Teich, in dessen Mitte leise ein Springbrunnen pl�tschert.");
	output("Der Garten ist umgeben von Baumreihen, durch die sacht der Wind streicht und erz�hlt von seinen Reisen in die Ferne.");
	output("Die V�gel singen ein fr�hliches Lied und Schmetterlinge ziehen ihre Bahnen von Blume zu Blume.`n");
	output("Direkt am Eingang steht ein Schild, auf dem darauf hin gewiesen wird, da� hier ein Ort des Friedens, der Ruhe und Entspannung ist.");
	output("Auf einer Bank am Eingang sitzen G�ste und unterhalten sich:`n`n");
	viewcommentary("klostergarten","fl�stert leise:`n",25); 
	addnav("O?Zu den Obstb�umen","klostergarten.php?op=baum");  
	addnav("Z?Zur�ck zum Klosterhof","kloster.php");
}
if($_GET['op']=="baum"){
	output("`^`c`bDie Obstb�ume`b`c`n`n"); 
	output("`3Du betrittst den Teil des Gartens, in dem die Obstb�ume stehen, die erstaunlicher Weise immer voll Obst h�ngen."); 
	output("`3Noch vor den ersten B�umen steht ein Schild, auf dem Du in klaren Lettern lesen kannst:`n`n"); 
	output("`6Diese Obst dient zur Ern�hrung der `^Bewohner`6 des Klosters.`n"); 
	output("`6Es ist auch nur `^Bewohner `6des Klosters erlaubt, Obst zu pfl�cken!`n`n"); 
	output("`3Die Fr�chte an den B�umen sind die saftigsten, die Du je gesehen hast und es niemand da, der die B�ume bewacht, vielleicht solltest Du doch mal wenigstens kosten?"); 
	addnav("Obstb�ume"); 
	addnav("A?Apfelbaum","klostergarten.php?op=apfel"); 
	addnav("K?Kirschbaum","klostergarten.php?op=kirsche"); 
	addnav("B?Birnenbaum","klostergarten.php?op=birne");  
	addnav("Z?Zur�ck zum Garten","klostergarten.php"); 
}
if($_GET['op']=="apfel"){ 
	output("`3Du gehst hin�ber zu den Apfelb�umen, pl�ckst Dir einen saftigen Apfel und bei�t hinein."); 
	$sql = "SELECT * FROM items WHERE owner=".$session[user][acctid]." AND class='Schmuck' AND name='Zugangsm�nze'";
	$result = db_query($sql);
	if (db_num_rows($result)>0){
		switch(e_rand(1,12)){
			case 1:
			case 2:
			case 3:
			case 4:
			output("`3Hmmm, das ist wirklich der beste Apfel, den Du je gegessen hast!");
			break;
			case 5:
			output("`3Hmmm, das ist wirklich der beste Apfel, den Du je gegessen hast und er scheint eine besondere Wirkung zu haben, denn Du f�hlst, wie Dich Energie durchstr�mt");
			$session[user][hitpoints]*=1.05;
			break;
			}
		addnav("Z?Zur�ck","klostergarten.php?op=baum");
	}else{
		output("`3Hmmm, der Apfel ist wirklich der Beste, den Du je gegessen hast!"); 
		output("`3Du vergi�t das Warnschild, pfl�ckst noch mehr und i�t sie."); 
		output("`3Als Du satt bist, setzt Du Dich unter den Baum und h�lst Dir den wohlgen�hrten Bauch, als pl�tzlich, aus heiterem Himmel, ein `^Bl`6i`^tz`3 auf Dich herab f�hrt!!!"); 
		output("Du verlierst 5 Permanente Lebenspunkte und an Charme!"); 
		$name=$session['user']['name'];
		addnews("$name `7nahm vom Eigentum der G�tter und wurde bestraft!"); 
		$session[user][maxhitpoints]-=5; 
		$session[user][charm]-=10;  
		addnav("Z?Zur�ck","klostergarten.php?op=baum");       
} 
}
if($_GET['op']=="kirsche"){ 
	output("`3Du gehst hin�ber zu den Kirschb�umen, pl�ckst Dir eine Hand voll Kirschenund i�t sie."); 
	$sql = "SELECT * FROM items WHERE owner=".$session[user][acctid]." AND class='Schmuck' AND name='Zugangsm�nze'";
	$result = db_query($sql);
	if (db_num_rows($result)>0){
		switch(e_rand(1,12)){
			case 1:
			case 2:
			case 3:
			case 4:
			output("`3Hmmm, das sind wirklich die besten Kirschen, die Du je gegessen hast!");
			break;
			case 5:
			output("`3Hmmm, das sind wirklich die besten Kirschen, die Du je gegessen hast und sie scheinen eine besondere Wirkung zu haben, denn Du f�hlst, wie Dich Energie durchstr�mt");
			$session[user][hitpoints]*=1.05;
			break;
			}
		addnav("Z?Zur�ck","klostergarten.php?op=baum");
	}else{
		output("`3Hmmm, das sind wirklich die besten Kirschen, die Du je gegessen hast!"); 
		output("`3Du vergi�t das Warnschild, pfl�ckst noch mehr und i�t sie."); 
		output("`3Als Du satt bist, setzt Du Dich unter den Baum und h�lst Dir den wohlgen�hrten Bauch, als pl�tzlich, aus heiterem Himmel, ein `^Bl`6i`^tz`3 auf Dich herab f�hrt!!!"); 
		output("Du verlierst 5 Permanente Lebenspunkte und an Charme!"); 
		$name=$session['user']['name'];
		addnews("$name `7nahm vom Eigentum der G�tter und wurde bestraft!"); 
		$session[user][maxhitpoints]-=5; 
		$session[user][charm]-=10; 
		addnav("Z?Zur�ck","klostergarten.php?op=baum");        
} 
}
if($_GET['op']=="birne"){ 
	output("`3Du gehst hin�ber zu den Birnenb�umen, pl�ckst Dir eine saftige Birne und bei�t hinein."); 
	$sql = "SELECT * FROM items WHERE owner=".$session[user][acctid]." AND class='Schmuck' AND name='Zugangsm�nze'";
	$result = db_query($sql);
	if (db_num_rows($result)>0){
		switch(e_rand(1,12)){
			case 1:
			case 2:
			case 3:
			case 4:
			output("`3Hmmm, das ist wirklich die beste Birne, die Du je gegessen hast!");
			break;
			case 5:
			output("`3Hmmm, das ist wirklich die beste Birne, die Du je gegessen hast und sie scheint eine besondere Wirkung zu haben, denn Du f�hlst, wie Dich Energie durchstr�mt");
			$session[user][hitpoints]*=1.05;
			break;
			}
		addnav("Z?Zur�ck","klostergarten.php?op=baum");
	}else{
		output("`3Hmmm, die Birne ist wirklich die Beste, die Du je gegessen hast!"); 
		output("`3Du vergi�t das Warnschild, pfl�ckst noch mehr und i�t sie."); 
		output("`3Als Du satt bist, setzt Du Dich unter den Baum und h�lst Dir den wohlgen�hrten Bauch, als pl�tzlich, aus heiterem Himmel, ein `^Bl`6i`^tz`3 auf Dich herab f�hrt!!!"); 
		output("Du verlierst 5 Permanente Lebenspunkte und an Charme!"); 
		$name=$session['user']['name'];
		addnews("$name `7nahm vom Eigentum der G�tter und wurde bestraft!"); 
		$session[user][maxhitpoints]-=5; 
		$session[user][charm]-=10;  
		addnav("Z?Zur�ck","klostergarten.php?op=baum");       
}
}
page_footer(); 
?>
