<?php
// Idee und Umsetzung
// Morpheus aka Apollon 
// 2006 f�r Morpheus.Lotgd(LoGD 0.9.7 +jt ext (GER) 3)
// Mail to Morpheus@magic.ms or Apollon@magic.ms
// gewidmet meiner �ber alles geliebten Blume
require_once "common.php";
page_header("Tempel des Apollon");
if($HTTP_GET_VARS['op']==""){
	output("`7`b`cTempel des Apollon`c`b");
	output("`n<table align='center'><tr><td><IMG SRC=\"images/apoll.jpg\"></tr></td></table>`n",true);
	output("`3Du betrittst eine gr��ere, freundlich helle Tempelhalle, die durch ein Tor in seiner Mitte in 2 H�lften geteilt wird.");
	output("`3Im vorderen Teil sind an den W�nden Zeichnungen von magischer Bedeutung zu sehen, im Hinteren steht eine Statue des Apollon vor einem Altar, auf dem ein Dolch, ein Sch�del und ein Stab liegen.`n");
	output("`3Als Du in den Tempel trittst, erscheint aus dem Tor ein Priester, der Dich freundlich begr��t.`n");
	output("`5Sei willkommen, ".$session['user']['name'].", im Tempell des Gottes Apollon!");
	output("`5Dies ist ein Ort der Ruhe und Gelehrsamkeit, der Lehre �ber die geheimen K�nste, derer Du Dich unterziehen kannst, so Du m�chtest.`n");
	output("`3Du nickst l�chelnd mit dem Kopf und der Priester bedeutet Dir,ihm zu folgen w�hrend er durch das Tor zur�ck geht und gradewegs zum Altar.");
	output("`3Am Altar zeigt er auf eine Goldene Tafel, auf der Du folgendes lesen kannst:`n`n");
	output("`^3 Level in `5mysthischen K�nsten`^ - 15 Gems`n");
	output("`^3 Level in `3dunklen K�nsten`^ - 15 Gems`n");
	output("`^3 Level in `#Diebesk�nsten`^ - 15 Gems`n`n");
	output("`5Bedenke `3f�gt er hinzu`5 wenn ich Dich Lehre, so wird Dich das auch etwas Zeit kosten.");
	addnav("3 Level in mysthischen K�nsten - 15 Gems", "apolltempel.php?op=mystic");
	addnav("3 Level in dunklen K�nsten - 15 Gems", "apolltempel.php?op=dunkel");
	addnav("3 Level in Diebesk�nsten - 15 Gems", "apolltempel.php?op=dieb");
	addnav("Zur�ck zum Klosterhof", "kloster.php");
	}
if($_GET['op']=="mystic"){ 
	if ($session[user][turns] >1) {
		if ($session[user][gems] >14) {
    			$session[user][gems]-=15; 
    			$session[user][turns]-=2;
             		output(" `3Du greifst zu Deinem Beutel und �berreichst dem Priester `@15 Gems`3, die er dankend entgegen nimmt und sie in einer Altarnische hinter sich verstaut."); 
             		output(" `3Dann wendet er sich wieder um und geht zu einer Truhe an der Seite, aus der er ein Buch und 2 kleine Schemel holt, setzt sich nieder und bedeutet Dir,auf dem anderen Platz zu nehmen.");
             		output(" `3Du setzt Dich und er beginnt, Dich aus dem Buch zu lehren.`n");
             		output(" `3And�chtig lauscht Du seinen Worten, und nach einer kurzen Medithation am Schlu� sp�rst Du, wie Dich die Kraft durchstr�mt" ); 
             		$session[user][magic] = $session[user][magic] + 3; 
             		$session[user][magicuses]++;
		}else{ 
             		output("`3Der Priester sch�ttelt l�chelnd den Kopf:`5 Ich f�rchte, Deine Gems werden nicht ausreichen, die Gunst des Gottes zu erlangen."); 
		}
	}else{
		output("`3Der Priester sch�ttelt l�chelnd den Kopf:`5 Du scheinst mir heute schon zu m�de dazu zu sein. Ruhe Dich aus und kehre noch einmal wieder, wenn Du wieder erholter bist.");
	}
	addnav("Zur�ck zum Klosterhof", "kloster.php");
}
if($_GET['op']=="dunkel"){ 
	if ($session[user][turns] >1) {
		if ($session[user][gems] >14) {
    			$session[user][gems]-=15; 
    			$session[user][turns]-=2;
             		output(" `3Du greifst zu Deinem Beutel und �berreichst dem Priester `@15 Gems`3, die er dankend entgegen nimmt und sie in einer Altarnische hinter sich verstaut."); 
             		output(" `3Dann wendet er sich wieder um und geht zu einer Truhe an der Seite, aus der er ein Buch und 2 kleine Schemel holt, setzt sich nieder und bedeutet Dir,auf dem anderen Platz zu nehmen.");
             		output(" `3Du setzt Dich und er beginnt, Dich aus dem Buch zu lehren.`n");
             		output(" `3And�chtig lauscht Du seinen Worten, und nach einer kurzen Medithation am Schlu� sp�rst Du, wie Dich die Kraft durchstr�mt" ); 
             		$session[user][darkarts] = $session[user][darkarts] + 3; 
             		$session[user][darkartuses]++;
		}else{ 
             		output("`3Der Priester sch�ttelt l�chelnd den Kopf:`5 Ich f�rchte, Deine Gems werden nicht ausreichen, die Gunst des Gottes zu erlangen."); 
		}
	}else{
		output("`3Der Priester sch�ttelt l�chelnd den Kopf:`5 Du scheinst mir heute schon zu m�de dazu zu sein. Ruhe Dich aus und kehre noch einmal wieder, wenn Du wieder erholter bist.");
	}
	addnav("Zur�ck zum Klosterhof", "kloster.php");
}
if($_GET['op']=="dieb"){ 
	if ($session[user][turns] >1) {
		if ($session[user][gems] >14) {
    			$session[user][gems]-=15; 
    			$session[user][turns]-=2;
             		output(" `3Du greifst zu Deinem Beutel und �berreichst dem Priester `@15 Gems`3, die er dankend entgegen nimmt und sie in einer Altarnische hinter sich verstaut."); 
             		output(" `3Dann wendet er sich wieder um und geht zu einer Truhe an der Seite, aus der er ein Buch und 2 kleine Schemel holt, setzt sich nieder und bedeutet Dir,auf dem anderen Platz zu nehmen.");
             		output(" `3Du setzt Dich und er beginnt, Dich aus dem Buch zu lehren.`n");
             		output(" `3And�chtig lauscht Du seinen Worten, und nach einer kurzen Medithation am Schlu� sp�rst Du, wie Dich die Kraft durchstr�mt" ); 
             		$session[user][thievery] = $session[user][thievery] + 3; 
             		$session[user][thieveryuses]++;
		}else{ 
             		output("`3Der Priester sch�ttelt l�chelnd den Kopf:`5 Ich f�rchte, Deine Gems werden nicht ausreichen, die Gunst des Gottes zu erlangen."); 
		}
	}else{
		output("`3Der Priester sch�ttelt l�chelnd den Kopf:`5 Du scheinst mir heute schon zu m�de dazu zu sein. Ruhe Dich aus und kehre noch einmal wieder, wenn Du wieder erholter bist.");
	}
	addnav("Zur�ck zum Klosterhof", "kloster.php");
}
page_footer();
?> 