<?php
// Idee und Umsetzung
// Morpheus aka Apollon 
// 2006 f�r Morpheus.Lotgd(LoGD 0.9.7 +jt ext (GER) 3)
// Mail to Morpheus@magic.ms or Apollon@magic.ms
// gewidmet meiner �ber alles geliebten Blume
require_once "common.php";
addcommentary();
checkday();
if ($session['user']['alive']){ 
}else{
	redirect("shades.php");
}
addnav("Wege");
addnav("Z?Zurueck nach XXX","XXX.php");
if ($session['user']['dragonkills']>=10){
	addnav("G?Ins Gebirge","berge.php");
}
addnav("Klosterhof");
addnav("N?Norden - Der Tempel des Morpheus","morpheustempel.php");
addnav("O?Osten - Der Tempel des Aeskulap","tempelderheilung1.php");
addnav("S?S�den - Der Tempel der Artemis","artemistempel.php");
addnav("W?Westen - Der Tempel des Apollon","apolltempel.php");
addnav("K?Zum Klostergarten","klostergarten.php");
addnav("I?Ins Klostergeb�ude","klosterhaus.php");
addnav("t?In den Glockenturm","klosterturm.php");
page_header("Das Kloster");
output("`^`c`bDer Klosterhof`b`c`n`@Du stehst im Hof eines Klosters, da� von frommen Maennern bewohnt wird, die ihr Leben und Wirken dem Dienst an den G�ttern verschrieben haben und der Verwaltung von XXX, da� ihr Lehen ist, welches sie von den G�ttern �bertragen bekommen haben.`n");
output("Das Kloster wurde in exakter Ausrichtung nach den Himmelsrichtungen erbaut und sein Innenhof ist ein Atrium, das von einem S�ulengang umrahmt wird. In jede Himmelsrichtung kannst Du einen Durchgang entdecken, der in den Schrein eines Gottes f�hrt, w�hrend der Eingang in den Hof, das Geb�ude, den Turm und den Garten in den Ecken innerhalb des S�ulenganges liegen.`n`n In der Mitte des Atriums steht ein uralter Obelisk, an dem auf jeder Seite, am unteren Rand, eine helle Fl�che zu sehen ist.");
$sql = "SELECT * FROM news WHERE 1 ORDER BY newsid DESC LIMIT 1";
$result = db_query($sql) or die(db_error(LINK));
$row = db_fetch_assoc($result);
output("Auf ihr stehen die neusten Meldungen aus unserer Welt:`0`n`n`c`i$row[newstext]`i`c`n");
if (getsetting('activategamedate','0')==1) output("`qWir schreiben den `^".getgamedate()."`q im Zeitalter des Drachen.`n");
output("Die Uhr �ber dem Klostereingang zeigt `^".getgametime()."`q Uhr.`n");
output("Das heutige Wetter ist `^".$settings['weather']."`q.`0");
output("`n`n`%`@In der N�he des Tores stehen einige Abenteurer und unterhalten sich:`n`n");
viewcommentary("klosterhof","Hinzuf�gen:",25);
page_footer();
?>