<?php
// Idee und Umsetzung
// Morpheus aka Apollon 
// 2006 f�r Morpheus.Lotgd(LoGD 0.9.7 +jt ext (GER) 3)
// Mail to Morpheus@magic.ms or Apollon@magic.ms
// gewidmet meiner �ber alles geliebten Blume
require_once "common.php";
page_header("Das Kloster XXX");
addcommentary();
if($_GET['op']==""){
	output("`7`b`cDas Kloster XXX`c`b");
	output("`3`nDu betrittst das Haupthaus des Klosters und gelangst zun�chst in einen Flur, in dem Dich ein M�nch um Deine Waffe und R�stung bittet, die Du ihm aush�ndigst.");
	output("`3Hinter dem Flur kommst Du in eine recht gro�e Vorhalle, die von Fackeln an den W�nden beleuchtet wird.");
	output("`3Die Decke bildet ein m�chtiges Gew�lbe, da� von 7 Pfeilern gest�tzt wird, die von den seiten des Raumes nach oben zu einem Stern zusammen laufen, in dessen Mitte ein Hacken eingelassen wurde, an dem ein vielarmiger Deckenkerzenleuchter h�ngt.");
	output("`3In der Mitte der gegen�ber liegenden Wand sind 3 T�ren, die in die Klosterschenke f�hren, rechts und links davon f�hrt je eine Treppe nach oben, �ber die man in die Schlafs�le gelangt.");;
	output("`3Rechts neben der Treppe gelangt man zum B�ro des Abtes, w�hrend ein T�r neben der linken Treppe zur Klosterschmiede f�hrt`n.");
	output("`3Vor dem Eingang zur Schenke stehn einige M�nche mit G�sten, die sich leise unterhalten:`n`n");
	viewcommentary("klosterhaus","`3Hinzuf�gen:`0",25,"fl�stert");
	addnav("Wege");
	addnav("In die Klosterschenke","klosterhaus.php?op=schenk");
	addnav("In die Klosterschmiede","klosterhaus.php?op=schmied");
	addnav("Zum B�ro des Abtes","klosterabt.php");
	addnav("Treppe zu den Schlafs�len","klosterhaus.php?op=schlaf");
	addnav("Zur�ck zum Klosterhof","kloster.php");
}
if($_GET['op']=="halle"){
	output("`7`b`cDas Kloster XXX`c`b");
	output("`3`nErneut trittst Du in die Vorhalle, wo noch immer M�nche mit G�sten beim Gespr�ch zusammen stehen, und �berlegst, was Du jetzt tun sollst.");
	viewcommentary("klosterhaus","`3Hinzuf�gen:`0",25,"fl�stert");
	addnav("Wege");
	addnav("In die Klosterschenke","klosterhaus.php?op=schenk");
	addnav("In die Klosterschmiede","klosterhaus.php?op=schmied");
	addnav("Zum B�ro des Abtes","klosterabt.php");
	addnav("Treppe zu den Schlafs�len","klosterhaus.php?op=schlaf");
	addnav("Zur�ck zum Klosterhof","kloster.php");
}
if($_GET['op']=="schmied"){
	output("`7`b`cDas Klosterschmiede`c`b");
	output("`3`n`nDu holst Dir Deine Waffe am Eingang ab und gehst durch die Linke T�r neben der Treppe in die Schmiede des Klosters, in der die M�nche Waffen und R�stungen herstellen lassen, die an die verschiedenen L�den des Landes geliefert werden.");
	output("`3Die Schmiedekunst des Klosterschmieds ist weithin ber�hmt, doch die besten Waffen und R�stungen werden nicht an die L�den geliefert sondern nur hier vor Ort erstellt und aufbewahrt.`n");
	output("`3Powerolus, der Schmied, ist ein staemmiger Kerl, der nur aus Muskeln zu bestehen scheint und als Du den Raum betrittst, arbeitet er grade an einer m�chtigen Streitaxt");
	output("`3Er blickt auf, unterbricht die Arbeit und fragt Dich, was er f�r Dich tun kann.");
	addnav("Waffe verbessern","klosterhaus.php?op=waffe");
	addnav("R�stung verbessern","klosterhaus.php?op=ruestung");
	addnav("Zur�ck zur Halle","klosterhaus.php?op=halle");
}
if($_GET['op']=="waffe"){
	output("`3Du sagst Powerolus, da� Du gerne Deine Waffe verbessert haben willst, damit Du im Kampf gegen die b�sen M�chte besser bestehen kannst.");
	output("`3Powerolus nick Dir zu und ergreift Dein/e/n ".$session['user']['weapon'].", um einen Blick darauf zu werfen.`n");
	if (strchr($session['user']['weapon'],"Power")){
		output("`3 Er h�lt die Waffe ins Licht und entdeckt sein Zeichen auf ihr, worauf sich seine Mundwinkel zu einem L�cheln formen:");
		output("`%Wie ich sehe, habe ich Deine Waffe ja bereits verbessert, daran kann ich leider nichts mehr machen. Ich hoffe, sie hat sich bisher im Kampf bew�hrt");
		addnav("Zur�ck zur Halle","klosterhaus.php?op=halle");
	}else{
        	$newdmg=$session['user']['weapondmg']+3;
        	$cost =$session['user']['weapondmg']*300;
                output("`3Er betrachtet Deine Wafffe ganz genau von allen Seiten.`n");
        	if ($cost > $session['user']['gold']){
            		output("`%F�r nur `^$cost`# Gold k�nnte ich daraus eine besondere Waffe machen, so Du willst.`n");
            		output("`3Du blickst in Deinen Goldbeutel, z�hlst die M�nzen und teilst Powerolus mit, da� Du spter noch einmal vorbei kommen wirst.");
                        addnav("Zur�ck zur Halle","klosterhaus.php?op=halle");
        	}else{
                        output("`%F�r nur `^$cost`# Gold kann ich daraus eine ganz besondere Waffe machen, die dann $newdmg Schaden machen w�rde, so Du denn willst!");
                        addnav("Ja, bitte","klosterhaus.php?op=waffe1");
                        addnav("Ich werde es mir �berlegen","klosterhaus.php?op=halle");
        }
    }
}
if($_GET['op']=="waffe1"){
	output("`3Powerolus nimmt Dein/e/n `^".$session['user']['weapon']."`3 und beginnt sie sorgsam zu bearbeiten.");
	output("`3Nach einer Weile nickt er zufrieden und verschwindet in einem Hinterraum, um sie zu testen.`n");
	output("`3Als er wieder zur�ck kehrt, �berreicht er Dir Dein/e/n ".$session['user']['weapon'].", poliert und verbessert.");
	output("`3Freudestrahlend �bergibst Du ihm das Gold und verl��t die Schmiede, um Deine Waffe wieder am Eingang ab zu geben.");
	$newweapon = "Power ".$session['user']['weapon'];
	$cost = $session['user']['weapondmg'] * 300;
	$session['user']['gold']-=$cost;
	$session['user']['weapon']=$newweapon;
	$session['user']['weapondmg']+=3;
	$session['user']['weaponvalue']+=$cost;
	$session['user']['attack']+=3;
	addnav("Zur�ck zur Halle","klosterhaus.php?op=halle");
}
if($_GET['op']=="ruestung"){
	output("`3Du sagst Powerolus, da� Du gerne Deine R�stung verbessert haben willst, damit Du im Kampf gegen die b�sen M�chte besser bestehen kannst.");
	output("`3Powerolus nick Dir zu und ergreift Dein/e/n ".$session['user']['armor'].", um einen Blick darauf zu werfen.`n");
	if (strchr($session['user']['armor'],"Power")){
		output("`3 Er h�lt die R�stung ins Licht und entdeckt sein Zeichen auf ihr, worauf sich seine Mundwinkel zu einem L�cheln formen:");
		output("`%Wie ich sehe, habe ich Deine R�stung ja bereits verbessert, daran kann ich leider nichts mehr machen. Ich hoffe, sie hat sich bisher im Kampf bew�hrt");
		addnav("Zur�ck zur Halle","klosterhaus.php?op=halle");
	}else{
        	$newdef=$session['user']['armordef']+3;
        	$cost =$session['user']['armordef']*300;
                output("`3Er betrachtet Deine R�stung ganz genau von allen Seiten.`n");
        	if ($cost > $session['user']['gold']){
            		output("`%F�r nur `^$cost`# Gold k�nnte ich daraus eine besondere R�stung machen, so Du willst.`n");
            		output("`3Du blickst in Deinen Goldbeutel, z�hlst die M�nzen und teilst Powerolus mit, da� Du spter noch einmal vorbei kommen wirst.");
                        addnav("Zur�ck zur Halle","klosterhaus.php?op=halle");
        	}else{
                        output("`%F�r nur `^$cost`# Gold kann ich daraus eine ganz besondere R�stung machen, die dann $newdef R�stschutz h�tte, so Du denn willst!");
                        addnav("Ja, bitte","klosterhaus.php?op=ruestung1");
                        addnav("Ich werde es mir �berlegen","klosterhaus.php?op=halle");
        }
    }
}
if($_GET['op']=="ruestung1"){
	output("`3Powerolus nimmt Dein/e/n `^".$session['user']['armor']."`3 und beginnt sie sorgsam zu bearbeiten.");
	output("`3Nach einer Weile nickt er zufrieden und verschwindet in einem Hinterraum, um sie zu testen.`n");
	output("`3Als er wieder zur�ck kehrt, �berreicht er Dir Dein/e/n ".$session['user']['armor'].", poliert und verbessert.");
	output("`3Freudestrahlend �bergibst Du ihm das Gold und verl��t die Schmiede, um Deine R�stung wieder am Eingang ab zu geben.");
	$newarmor = "Power ".$session['user']['armor'];
	$cost = $session['user']['armordef'] * 300;
	$session['user']['gold']-=$cost;
	$session['user']['armor']=$newarmor;
	$session['user']['armordef']+=3;
	$session['user']['armorvalue']+=$cost;
	$session['user']['defence']+=3;
	addnav("Zur�ck zur Halle","klosterhaus.php?op=halle");
}
if($_GET['op']=="schlaf"){
	output("`3Du gehst die Treppe hinauf, wo sich die Schlafs�le der M�nche befinden.");
	$sql = "SELECT * FROM items WHERE owner=".$session[user][acctid]." AND class='Schmuck' AND name='Zugangsm�nze'";
	$result = db_query($sql);
	if (db_num_rows($result)>0){
		output("`3Der M�nch vor der T�r �berpr�ft kurz Deine Zugangsm�nze und l��t Dich dann freundlich l�chelnd passieren.");
		output("`3Du begibst Dich in das R�umchen, in dem Dein Bett steht, setzt Dich darauf und streckst Dich.");
		addnav("Schlafen gehen (Logout)","klosterhaus.php?op=logout",true);
		addnav("Zur�ck zur Halle","klosterhaus.php?op=halle");
        }else{
		output("`3Der M�nch vor der T�r fragt Dich nach Deiner Zugangsm�nze und Du wei�t nicht, was er meint.");
		output("`3Er erkl�rt Dir, da� Du, um hier n�chtigen zu k�nnen, eine Zugangsm�nze ben�tigst, die Du beim Abt erhalten kannst.");
		addnav("Zur�ck zur Halle","klosterhaus.php?op=halle");
		}
}
if ($_GET[op]=="logout"){
	debuglog("logged out in XXX");
        $session['user']['donationconfig']=serialize($config);
        $session['user']['location']=14;
        $session['user']['loggedin']=0;
        saveuser();
        $session=array();
        redirect("index.php");
}
if($_GET['op']=="schenk"){
	if($HTTP_GET_VARS['what']==""){
	addnav("Zur�ck zur Halle","klosterhaus.php?op=halle");
	output("`3`nAls Du die Klosterschenke, einen gro�en, ger�umigen Gew�lbekeller mit Tischen und B�nken, betrittst, steigt Dir der Geruch von guten Speisen direkt in die Nase und kitzelt Deinen Gaumen. Auf der Tafel, die hinter dem Wirt an der Theke h�ngt, kannst Du folgendes lesen:`n`n");
	output("`7 SPEISEN`n`n");
	output("`6Maisbrei:`n`3Leckerer Brei aus frischem Mais, dazu frisches Obst aus dem eigenen Klostergarten.`n`n");
	output("`qRebhuhn:`n`3Heute im Wald gejagt, gut durchgebraten, dazu frische Kn�del, auch aus eigenen Zutaten.`n`n");
	output("`TWildschwein:`n`3Vorhin erst geliefert, ganz frisch und gut durchgebraten, dazu frisches Brot aus der Kloster�ckerei.`n`n");
	output("`7 GETR�NKE`n`n");
	output("`6Bie`&r:`n`3Direkt aus der klostereigenen Brauerei, das Beste im Lande.`n`n");
	output("`\$Wein:`n`3Aus dem Weinkeller der Klosters, alle Weine sind selbst produziert.`n`n");
	output("`7 OHNE ALKOHOL`n`n");
	output("`#Frisches Quellwasser:`n`3Direkt aus dem klostereigenen Brunnen, sch�n k�hl und erfrischend.`n`n");
	output("`5Traubensaft:`n`3Aus der letzten Ernte der klostereigenen Weinberge.`n`n");
	output("`&Frische Milch:`n`3Direkt aus den St�llen XXXs.`n`n");
	$maiscost=$session[user][level]*11;
	$rebhuhncost=$session[user][level]*25;
	$schweincost=$session[user][level]*35;
	$biercost=$session[user][level]*15;
	$weincost=$session[user][level]*20;
	$wassercost=$session[user][level]*8;
	$saftcost=$session[user][level]*10;
	$milchcost=$session[user][level]*12;
	addnav("Speisen");
	addnav("`6Maisbrei `^($maiscost Gold)","klosterhaus.php?op=schenk&what=mais");
	addnav("`qRebhuhn `^($rebhuhncost Gold)","klosterhaus.php?op=schenk&what=braten");
	addnav("`TWildschwein `^($schweincost Gold)","klosterhaus.php?op=schenk&what=wild");
	addnav("Getr�nke");
	addnav("`6Bie`&r `^($biercost Gold)","klosterhaus.php?op=schenk&what=bier");
	addnav("`\$Wein `^($weincost Gold)","klosterhaus.php?op=schenk&what=wein");
	addnav("Ohne Alkohol");
	addnav("`#Quellwasser `^($wassercost Gold)","klosterhaus.php?op=schenk&what=wasser");
	addnav("`5Traubensaft `^($saftcost Gold)","klosterhaus.php?op=schenk&what=saft");
	addnav("`&Milch `^($milchcost Gold)","klosterhaus.php?op=schenk&what=milch");
	}
if($_GET['what']=="mais"){
	if ($session[user][gold] >= ($session[user][level]*11) && $session[user][turns]>0){
		switch(e_rand(1,3)){ 
			case 1:
			output("`n`3Du i�t den `6Maisbrei mit dem Obst `3voll Genu� und bis zum letzten Happen.");
			output("`3Du f�hlst dich satt und zufrieden, jetzt k�nntest glatt noch ein Monster erschlagen.`n`n"); 
			$session['user']['turns']+=1;
			$session['user']['gold']-=($session[user][level]*11);
			break;
			case 2:
			output("`n`3Du i�t den `6Maisbrei mit dem Obst `3voll Genu� und bis zum letzten Happen.");
			output("`3Du f�hlst dich satt und so voll, da� Du die Zeit f�r 1 Waldkampf verlierst.`n`n"); ; 
			$session['user']['turns']-=1; 
			$session['user']['gold']-=($session[user][level]*11);
			break;
			case 3:
			output("`n`3Du i�t den `6Maisbrei mit dem Obst `3voll Genu�.");
			output("`3Das war wirklich lecker!`n`n"); ; 
			$session['user']['gold']-=($session[user][level]*11);
			break;
		}
	}else if ($session[user][turns]<=0){
		output("`n`3 Der Wirt schaut Dich an und sagt: `#\"So kurz vor dem Schlafen solltest Du aber nichts mehr essen, das gibt nur Alptr�ume, komm morgen noch mal wieder.\"");
	}else {
		output("`n`3Der Wirt sieht Dich nur fragend an und sch�ttelt dann mit dem Kopf: `#\"Das kannst Du Dir wohl nicht leisten, mein Freund.\"");
	}
	addnav("Zur�ck","klosterhaus.php?op=schenk");
}
if($_GET['what']=="braten"){
	if ($session[user][gold] >= ($session[user][level]*25) && $session[user][turns]>0){
		switch(e_rand(1,4)){ 
			case 1:
			case 2:
			output("`n`3Du i�t das `qRebhuhn und die Kn�del `3mit Genu� und bis zum letzten Happen.");
			output("`3DU f�hlst dich satt und zufrieden, Deine Wunden beginnen zu heilen und Du k�nntest glatt noch ein Monster erschlagen.`n`n"); 
			$session['user']['turns']+=1;
			$session['user']['gold']-=($session[user][level]*25);
			$session['user']['hitpoints'] +=(2.5*($session['user']['level']));
			if ($session['user']['hitpoints'] > $session['user']['maxhitpoints']){							$session['user']['hitpoints'] = $session['user']['maxhitpoints'];
			}
			break;
			case 3:
			case 4:
			output("`n`3Du i�t das `qRebhuhn und die Kn�del `3mit Genu� und bis zum letzten Happen.");
			output("`3DU f�hlst dich satt und so voll, da� Du die Zeit f�r 1 Waldkampf verlierst, aber Deine Wunden beginnen zu heilen.`n`n"); ; 
			$session['user']['turns']-=1; 
			$session['user']['gold']-=($session[user][level]*25);
			$session['user']['hitpoints'] += (2.5*$session['user']['level']);
			if ($session['user']['hitpoints'] > $session['user']['maxhitpoints']){							$session['user']['hitpoints'] = $session['user']['maxhitpoints'];
			}
			break;
		}
	}else if ($session[user][turns]<=0){
		output("`n`3 Der Wirt schaut Dich an: \"`#So kurz vor dem Schlafen solltest Du aber nichts mehr essen, das gibt nur Alptr�ume, komm morgen noch mal wieder.\"");
	}else {
		output("`n`3Der Wirt sieht Dich nur fragend an und sch�ttelt dann mit dem Kopf: `#\"Das kannst Du Dir wohl nicht leisten, mein Freund.\"");
		}
	addnav("Zur�ck","klosterhaus.php?op=schenk");
}
if($_GET['what']=="wild"){
	if ($session[user][gold] >= ($session[user][level]*25) && $session[user][turns]>0){
		switch(e_rand(1,4)){ 
			case 1:
			output("`n`3Du i�t das `TWildschwein mit Brot `3voll Genu� und bis zum letzten Happen.");
			output("`3Du f�hlst dich satt und super gut, jetzt k�nntest Du glatt noch ein Monster erschlagen.`n`n"); 
			$session['user']['turns']+=1;
			$session[user][hungry]+=5;
			$session['user']['gold']-=($session[user][level]*35);
			$session['user']['hitpoints'] = ($session['user']['maxhitpoints']*1.02);
			break;
			case 2:
			case 3:
			case 4:
			output("`n`3Du i�t das `TWildschwein mit Brot `3mit Genu� und bis zum letzten Happen.");
			output("`3Du f�hlst dich satt und so voll, da� Du die Zeit f�r 1 Waldkampf verlierst, aber Deine Wunden sind verheilt und Du f�hlst Dich super!`n`n"); ; 
			$session['user']['turns']-=1; 
			$session[user][hungry]+=5;
			$session['user']['gold']-=($session[user][level]*35);
			$session['user']['hitpoints'] = ($session['user']['maxhitpoints']*=1.01);
			break;
		}
	}else if ($session[user][turns]<=0){
		output("`n`3 Der Wirt schaut Dich an: \"`#So kurz vor dem Schlafen solltest Du aber nichts mehr essen, das gibt nur Alptr�ume, komm morgen noch mal wieder.\"");
	}else {
		output("`n`3Der Wirt sieht Dich nur fragend an und sch�ttelt dann mit dem Kopf: `#\"Das kannst Du Dir wohl nicht leisten, mein Freund.\"");
	}
	addnav("Zur�ck","klosterhaus.php?op=schenk");
}
if($_GET['what']=="wasser"){
	if ($session[user][gold] >= ($session[user][level]*8) && $session[user][turns]>0){
		switch(e_rand(1,10)){ 
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
			case 6:
			case 7:
			case 8:
			output("`n`3Aaaaah, das `#Wasser `3war wirklich lecker und erfrischend!");
			$session['user']['gold']-=($session[user][level]*8);
			break;
			case 9:
			case 10:
			output("`n`3Aaaaah, das `#Wasser `3war wirklich lecker und erfrischend!");
			output("`3Du f�hlst Dich erholt und sp�rst, wie sich Deine Wunden schlie�en."); 
			$session['user']['gold']-=($session[user][level]*8);
			$session['user']['hitpoints'] += (2.5*$session['user']['level']);
			if ($session['user']['hitpoints'] > $session['user']['maxhitpoints']){							$session['user']['hitpoints'] = $session['user']['maxhitpoints'];
			}
			break;
		}
	}else if ($session[user][turns]<=0){
		output("`n`3 Der Wirt schaut Dich an: \"`#So kurz vor dem Schlafen solltest Du aber nichts mehr so Kaltes trinken, das gibt nur Alptr�ume, komm morgen noch mal wieder.\"");
	}else {
		output("`n`3Der Wirt sieht Dich nur fragend an und sch�ttelt dann mit dem Kopf: `#\"Das kannst Du Dir wohl nicht leisten, mein Freund.\"");
	}
	addnav("Zur�ck","klosterhaus.php?op=schenk");
}
if($_GET['what']=="saft"){
	if ($session[user][gold] >= ($session[user][level]*10) && $session[user][turns]>0){
		switch(e_rand(1,10)){ 
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
			case 6:
			case 7:
			case 8:
			output("`n`3Aaaaah, der `5Traubensaft `3war wirklich lecker und erfrischend!");
			$session['user']['gold']-=($session[user][level]*10);
			break;
			case 9:
			case 10:
			output("`n`3Aaaaah, der `5Traubensaft `3war wirklich lecker und erfrischend!");
			output("`3Deine Wunden schlie�en sich und Du f�hlst Dich super!"); 
			$session['user']['gold']-=($session[user][level]*10);
			$session['user']['hitpoints'] = ($session['user']['maxhitpoints']*=1.01);
			break;
		}
	}else if ($session[user][turns]<=0){
		output("`n`3 Der Wirt schaut Dich an: \"`#So kurz vor dem Schlafen solltest Du aber nichts mehr so Kaltes trinken, das gibt nur Alptr�ume, komm morgen noch mal wieder.\"");
	}else {
		output("`n`3Der Wirt sieht Dich nur fragend an und sch�ttelt dann mit dem Kopf: `#\"Das kannst Du Dir wohl nicht leisten, mein Freund.\"");
	}
	addnav("Zur�ck","klosterhaus.php?op=schenk");
}
if($_GET['what']=="milch"){
	if ($session[user][gold] >= ($session[user][level]*12) && $session[user][turns]>0){
		switch(e_rand(1,10)){ 
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
			case 6:
			case 7:
			case 8:
			output("`n`3Aaaaah, die `&Milch `3war wirklich lecker und erfrischend!");
			$session['user']['gold']-=($session[user][level]*12);
			break;
			case 9:
			case 10:
			output("`n`3Aaaaah, die `&Milch `3war wirklich lecker und erfrischend!");
			output("`3Du f�hlst Dich super und etwas n�chterner!"); 
			$session['user']['gold']-=($session[user][level]*12);
			$session[user][drunkenness]-=5;
			break;
		}
	}else if ($session[user][turns]<=0){
		output("`n`3 Der Wirt schaut Dich an: \"`#So kurz vor dem Schlafen solltest Du aber nichts mehr so Kaltes trinken, das gibt nur Alptr�ume, komm morgen noch mal wieder.\"");
	}else {
		output("`n`3Der Wirt sieht Dich nur fragend an und sch�ttelt dann mit dem Kopf: `#\"Das kannst Du Dir wohl nicht leisten, mein Freund.\"");
	}
	addnav("Zur�ck","klosterhaus.php?op=schenk");
}
if ($_GET[what]=="wein"){ 
	if ($session[user][gold] >= ($session[user][level]*20)){
     		$session[bufflist][moenchwein]= array("name"=>"`^M�nchsgeist","rounds"=>20,"wearoff"=>"`4Der M�nchsgeist hat Dich wieder verlassen", "defmod"=>1.1,"atkmod"=>1.1,"roundmsg"=>"Der M�nchsgeist staerkt Dich!","activate"=>"offense");
     		$session[user][gold]-=($session[user][level]*20);  
     		output(" `n`n`3Der Wirt gibt Dir einen Kelch mit einem ganz besonderen Wein, der am klostereigenen Weinberg geerntet wurde und lange gelagert hat.`n");  
     		output("`3Du genie�t jeden Tropfen dieses Weins, bei dem man schmeckt, da� er mit Sachverstand und Liebe gemacht wurde.");
     		$session[user][drunkenness]+=35;
     		debuglog("Trank im Kloster XXX einen wunderbaren Wein!");
	}else{ 
		output("`n`n`9Der Wirt sch�ttelt den Kopf:`3Soviel Gold hast Du nicht!");  
	}
	addnav("Zur�ck","klosterhaus.php?op=schenk");
}
if ($_GET[what]=="bier"){ 
	if ($session[user][gold] >= ($session[user][level]*15)){
     		$session[bufflist][moenchsbier]= array("name"=>"`^Bierrausch","rounds"=>20,"wearoff"=>"`4Der Rausch des M�nchsbiers ist verflogen", "defmod"=>1.05,"atkmod"=>1.25,"roundmsg"=>"Du sp�rst noch den Rausch des M�nchsbiers!","activate"=>"offense");
     		$session[user][gold]-=($session[user][level]*15);  
     		output(" `n`n`3Der Wirt gibt Dir einen Krug voll feinen Biers, da� direkt aus der eigenen Brauerei kommt.`n");  
     		output("`3Du genie�t jeden Tropfen dieses Biers, welches das Beste zu sein scheint, da� Du je getrunken hast.");
     		$session[user][drunkenness]+=35;
     		debuglog("Trank im Kloster XXX ein hervorragendes Bier!");
	}else{ 
		output("`n`n`9Der Wirt sch�ttelt den Kopf:`3Soviel Gold hast Du nicht!");  
	}
	addnav("Zur�ck","klosterhaus.php?op=schenk");
}
}
page_footer();
?>