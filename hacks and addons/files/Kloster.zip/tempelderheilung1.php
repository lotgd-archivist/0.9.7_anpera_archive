<?php

// 24062004

require_once "common.php";


page_header("Tempel des Aeskulap");
output("`q`b`cTempel des Aeskulap`c`b");

$loglev = log($session[user][level]);
$cost = ($loglev * ($session[user][maxhitpoints]-$session[user][hitpoints])) + ($loglev*10);
$cost = round($cost,0);

if ($HTTP_GET_VARS[op]==""){
checkday();

output("`n<table align='center'><tr><td><IMG SRC=\"images/aeskulap.jpg\"></tr></td></table>`n",true);
output("`3Du schreitest in den gro�en, prachtvollen Tempel, welcher dem Gott Aeskulap geweiht ist.`n Du wirst gebeten, deine Waffen am Eingang abzugeben, denn niemand darf mit Waffen vor das Antlitz der G�ttin treten.`n`n");

if($session[user][hitpoints] < $session[user][maxhitpoints]){
    output("`3\Du siehst dich um und gehst zu einem Kleriker. Er sieht dich freundlich l�chelnd an und spricht: \"`qAeskulap zum Gru�e. Ihr sucht Heilung, nicht wahr? Nun, ich bin bereit, Euch zu heilen, solange man mich f�r meine Dienste angemessen entsch�digt.`3\"`n`n\"`5Oh-oh. Wieviel?`3\" fragst du.`n`nEr mustert dich von oben bis unten: \"`qF�r dich... `^`b$cost`b Goldst�cke `qf�r eine komplette Heilung!!`3\". Der schlanke, hochgewachsene Kleriker schiebt die �rmel seiner Kutte leicht nach oben und wei�es, warmes Licht erhellt seine Fingerkuppen.");
        addnav("Heilung");
        addnav("`^Komplette Heilung`0","tempelderheilung1.php?op=buy&pct=100");
        for ($i=90;$i>0;$i-=10){
        addnav("$i% - ".round($cost*$i/100,0)." Gold","tempelderheilung1.php?op=buy&pct=$i");
     }
    
}
else if($session[user][hitpoints] == $session[user][maxhitpoints]){
      output("`3Der Kleriker mustert dich von oben bis unten: \"`qHeilung scheint Ihr nicht zu ben�tigen. Sonst kann ich leider auch nichts f�r Euch tun. M�ge Aeskulap Euch auf Eurem Wege geleiten.`3\" Du nickst dem Kleriker zu und verabschiedest dich freundlich.");  
      }
else{
output("`3Der Kleriker mustert dich von oben bis unten: \"`qHeilung scheint Ihr nicht zu ben�tigen. Sonst kann ich leider auch nichts f�r Euch tun. M�ge Aeskulap Euch auf Eurem Wege geleiten.`3\" Du nickst dem Kleriker zu und verabschiedest dich freundlich.");
$session[user][hitpoints] = $session[user][maxhitpoints];
}
  addnav("`bZur�ck`b");
  addnav("Zur�ck zum Klosterhof", "kloster.php");
} 
else{
    $newcost=round($HTTP_GET_VARS[pct]*$cost/100,0);
if ($session[user][gold]>=$newcost){
    $session[user][gold]-=$newcost;
    //debuglog("spent $newcost gold on healing");
    $diff = round(($session[user][maxhitpoints]-$session[user][hitpoints])*$HTTP_GET_VARS[pct]/100,0);
    $session[user][hitpoints] += $diff;
    output("`3Du zeigst dem Kleriker deine Wunden und er bittet dich auf einer Liege Platz zu nehmen. Du legst dich hin, er reibt sich kurz die H�nde, legt den Kopf in den Nacken und schickt ein Sto�gebet zu dem Gott. Wei�es Licht leuchtet um seinen H�nden. Er beugt sich mit tr�ben Blick �ber dich, legt dir die H�nde auf und du sp�rst, wie eine pulsierende W�rme durch deinen K�rper f�hrt. Erstaunt �ber diese schnelle Heilung stehst du auf, ziehst dich an und gibst dem leicht ersch�pften Kleriker das Gold.");
    output("`n`n`#Du wurdest um $diff Punkte geheilt!");        
  }
else{    
  output("`3Du willst dem Kleriker gerade deine Wunden zeigen, als du bemerkst, dass du nicht genug Gold f�r die Heilung dabei hast. Der Kleriker nickt kurz bei deiner Erkl�rung und bittet dich mit gen�gend Gold wieder zu kommen.");    
  addnav("Heilung");
    addnav("`^Komplette Heilung`0","tempelderheilung1.php?op=buy&pct=100");
    for ($i=90;$i>0;$i-=10){
    addnav("$i% - ".round($cost*$i/100,0)." Gold","tempelderheilung1.php?op=buy&pct=$i");
    }
}
    addnav("`bZur�ck`b");
  addnav("Zur�ck zum Klosterhof", "kloster.php");
}


page_footer();

?> 