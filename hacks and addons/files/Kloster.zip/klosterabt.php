<?php
// Idee und Umsetzung
// Morpheus aka Apollon 
// 2006 f�r Morpheus.Lotgd(LoGD 0.9.7 +jt ext (GER) 3)
// Mail to Morpheus@magic.ms or Apollon@magic.ms
// gewidmet meiner �ber alles geliebten Blume
require_once "common.php";
page_header("Das B�ro des Abts");
if($_GET['op']==""){
	output("`7`b`cDas B�ro des Sekret�rs`c`b");
	output("`3`n`nDu gehst durch die rechte T�r neben der Treppe in das B�ro des Abtes und gelangst in einen Vorraum, in dem sonst der Sekret�r des Abtes sitzt, der im Moment nicht anwesend ist.");
	output("`3Der Raum besitzt kein Fenster und wird durch Fackel an den W�nden erhellt und Kerzen, die auf dem Schreibtisch des Sekret�rs stehen, auf dem Du auch allerlei Pergamente sehen kannst und eine Spendendose.");
	output("`3An der rechten Wand steht ein Regal mit vielen B�chern, an der Linken eines mit vielen F�chern, in die Pergamente einsortiert sind.");
	output("`3An der Wand gegen�ber liegt die T�r, die zum B�ro des Abtes f�hrt. Du schlie�t die T�r hinter Dir und �berlegst, was Du machen willst.");
	addnav("Die Paiere auf dem Schreibtisch ansehen","klosterabt.php?op=tisch");
	addnav("Die Spendendose leeren","klosterabt.php?op=dose");
	addnav("Weiter zum B�ro des Abts","klosterabt.php?op=tuer");
	addnav("Zur�ck zur Halle","klosterhaus.php?op=halle");
}
if($_GET['op']=="buero"){
	output("`7`b`cDas B�ro des Sekret�rs`c`b");
	output("`3Du stehst wieder mitten im Raum und �berlegst, was Du machen willst.");
	addnav("Die Papiere auf dem Schreibtisch ansehen","klosterabt.php?op=tisch");
	addnav("Die Spendendose leeren","klosterabt.php?op=dose");
	addnav("Weiter zum B�ro des Abts","klosterabt.php?op=tuer");
	addnav("Zur�ck zur Halle","klosterhaus.php?op=halle");
}
if($_GET['op']=="tisch"){
	output("`3Du nutzt die Gelegenheit, stellst Dich vor den Schreibtisch und durchst�berst die Papiere, die auf dem Schreibtisch des Sekret�rs liegen.");
		switch(e_rand(1,5)){
			case 1:
			case 2:
			case 3:
			output("`3Du findest Berichte �ber die Gesch�fte der M�nche und die Lage in XXX, insgesammt nichts aufregendes.");
			addnav("Zur�ck zum B�ro","klosterabt.php?op=buero");
			break;
			case 4:
			output("`3Du findest Berichte �ber die Gesch�fte der M�nche und die Lage in XXX, insgesammt nichts aufregendes.");
			output("`3Pl�tzlich entdeckst Du die Rezeptur f�r eine Creme, um die Haut zu pflegen.");
			output("`3Schnell schreibst Du es ab, denn das wir Dich noch schn�ner machen, was Dir einen Charmepunkt bringt.");
			$session[user][charm]+=1;
			addnav("Zur�ck zum B�ro","klosterabt.php?op=buero");
			break;
			case 5:
			output("`3Du findest Berichte �ber die Gesch�fte der M�nche und die Lage in XXX, insgesammt nichts aufregendes.");
			output("`3Pl�tzlich �ffnet sich die T�r und der Sekret�r kommt herein");
			output("`3Schnell l��t Du alles fallen und hoffst, da� er nicht bemerkt da� Du geschn�felt hast.");
			output("`3Du hast Gl�ck, er merkt es nicht, aber aus lauter Scham verlierst Du 2 Charmpunkte.");
			$session[user][charm]-=2;
			addnav("Zum B�ro des Abts","klosterabt.php?op=tuer");
			break;
		}
}
if($_GET['op']=="dose"){
	output("`3Du gehst zum Schreibtisch, hebst die Spendenose anund �ffnest sie.");
	output("`3Wenn sie schon ihr Spendendose alleine lassen, kannst Du Dich auch ein wenig daran bedienen, selbst Schuld die M�nche.");
		switch(e_rand(1,12)){
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
			case 6:
			case 7:
			case 8:
			case 9:
			case 10:
			case 11:
			output("`3Grade willst Du das Gold daraus nehmen, als Du ein Ger�usch an der T�r zum B�ro des Abtes h�rst.");
			output("`3Du wirst ganz starr vor Schreck, als sich die Klinke langsam nach unten bewegt und schaffst es nicht, die Dose zur�ck zu stellen.");
			output("`3DIe T�r �ffnet sich und heraus tritt der Sekret�r, der Dich auf frischer tat beim versuchten Diebstahl ertappt!!");
			output("`3Er ruft nach der Klosterwache, die Dich ergreift und aus dem Kloster wirft, Dein Gold, Deine Waffe und Deine R�stung werden einbehalten und Du erh�lst den Titel Klosterr�uber.");
			$session['user']['attack']-=$session['user']['weapondmg'];
			$session['user']['gold']=0;
			$session['user']['weapon']=Fists;
			$session['user']['weapondmg']=0;
			$session['user']['weaponvalue']=0;
			$session['user']['defence']-=$session['user']['armordef'];
			$session['user']['armor']=TShirt;
			$session['user']['armordef']=0;
			$session['user']['armorvalue']=0;
			$name=$session['user']['name'];
			addnews("$name `7wollte im Kloster stehlen und hat nun den Titel Klosterr�uber!");
			$newtitle="Klosterr�uber";
			$regname = $session['user']['name'];
			$session['user']['name'] = $newtitle." ".$session['user']['name'];
			$session['user']['title'] = $newtitle;
			addnav("Weiter","XXX.php");
			break;
			case 12:
			output("`3Grade willst Du das Gold daraus nehmen, als Du ein Ger�usch an der T�r zum B�ro des Abtes h�rst.");
			output("`3Du wirst ganz starr vor Schreck, als sich die Klinke langsam nach unten bewegt.");
			output("`3Schnell stellst Du die Dose wieder auf ihren Platz und siehst zu, da� Du zur�ck in die Halle kommst.");
			output("`3Dein Herz schl�gt bis zum Hals und Dir wird bewu�t, was Du da machen wolltest! Aus lauter Scham verlierst Du 5 Charmpunkte.");
			$session[user][charm]-=5;
			addnav("Zum zur Halle","klosterhaus.php?op=halle");
			break;
		}
}
if($_GET['op']=="tuer"){
	output("`7`b`cDas B�ro des Abtes`c`b");
	output("`3Du klopfst h�fflich an die T�r des B�ros und h�rst eine Stimme, die Dich herein bittet.");
	output("`3Als Du den Raum betrittst, siehst Du den Abt hinter seinem Schreibtisch sitzen und in Papieren lesen.");
	output("`3Sein B�ro ist hell mit gro�en Fenstern, an den Seiten stehen gro�e Regale mit vielen B�chern und vor seinem Schreibtisch stehen 2 St�hle`n.");
	output("`3Der Abt blickt von seinen Papieren auf, begr��t Dich freundlich, bietet Dir einen Platz an und fragt Dich, was er f�r Dich tun kann.");
	addnav("Auskunft �ber");
	addnav("die Tempel","klosterabt.php?op=atempel");
	addnav("die G�rten","klosterabt.php?op=agarten");
	addnav("den Glockenturm","klosterabt.php?op=aturm");
	addnav("die Schenke","klosterabt.php?op=aschenke");
	addnav("die Schmiede","klosterabt.php?op=aschmiede");
	addnav("die Schlafs�le","klosterabt.php?op=asaal");
	if ($session['user']['title']=='Klosterr�uber'){
		addnav("Um Gnade bitten","klosterabt.php?op=gnade");
	}
	addnav("Zur�ck zur Halle","klosterabt.php?op=buero1");
}
if($_GET['op']=="abt"){
	output("`2Nun, kann ich Dir sonst noch irgendwie helfen?.");
	addnav("Auskunft �ber");
	addnav("die Tempel","klosterabt.php?op=atempel");
	addnav("die G�rten","klosterabt.php?op=agarten");
	addnav("den Glockenturm","klosterabt.php?op=aturm");
	addnav("die Schenke","klosterabt.php?op=aschenke");
	addnav("die Schmiede","klosterabt.php?op=aschmiede");
	addnav("die Schlafs�le","klosterabt.php?op=asaal");
	if ($session['user']['title']=='Klosterr�uber'){
		addnav("Um Gnade bitten","klosterabt.php?op=gnade");
	}
	addnav("Zur�ck zur Halle","klosterabt.php?op=buero1");
	addnav("Zur�ck zur Halle","klosterabt.php?op=buero1");
}
if($_GET['op']=="atempel"){
	output("`2In den Tempeln kannst Du den G�ttern huldigen und Opfer bringen, die nat�rlich von den G�ttern belohnt werden, denn sie sind gute und g�tige G�tter.");
	output("`2Jeder Gott hat seinen eigenen Tempel, der nach einer anderen Himmelsrichtung ausgerichtet ist.");
	addnav("Weiter","klosterabt.php?op=abt");
}
if($_GET['op']=="agarten"){
	output("`2In den G�rten bauen wir Obst an, da� allerdings nur f�r Bewohner des Klosters zum Verzehr gedacht ist.");
	output("`2Die B�ume werden von den G�ttern h�chstselbst bewacht, und wenn sich jemand, der kein Bewohner des Klosters ist, daran vergeift, so wird er von den G�ttern daf�r bestraft.");
	addnav("Weiter","klosterabt.php?op=abt");
}
if($_GET['op']=="aturm"){
	output("`2Vom Turm aus haben wir einen wundervollen Blick �ber XXX, den umgebenden Wald und in die Berge, an sch�nen Tagen kann man sogar bis nach Eythgim blicken.");
	output("`2Doch der Turm ist auch ein magischer Ort: Die Legende besagt, wenn ein Krieger, der kurz davor steht, den `@GR�NEN DRACHEN `2auf zu suchen den Turm betritt, so �ffnet sich ihm eine magische Kammer, in der er g�ttliche Hilfe findet.");
	addnav("Weiter","klosterabt.php?op=abt");
}
if($_GET['op']=="aschenke"){
	output("`2In der Schenke kannst Du Deinen Hunger und Durst stillen, wir betreiben sie selbst.");
	output("`2Du findest dort die besten Speisen und Getr�nke weit und breit, sei es unser selbst gebrautes Bier, unser Wein oder das Wasser aus unserem Brunnen.");
	addnav("Weiter","klosterabt.php?op=abt");
}
if($_GET['op']=="aschmiede"){
	output("`2Oh, in unserer Schmiede entstehen die besten Waffen weit und breit, wir liefern sie in aller L�den unseres Landes aus.");
	output("`2Powerolus, der Schmied, versteht sein Handwerk auf das Feinste und kann aus jeder Waffe und R�stung noch etwas besonderes machen, Du solltest ihn einmal besuchen.");
	addnav("Weiter","klosterabt.php?op=abt");
}
if($_GET['op']=="asaal"){
	$sql = "SELECT * FROM items WHERE owner=".$session[user][acctid]." AND class='Schmuck' AND name='Zugangsm�nze'";
	$result = db_query($sql);
	if (db_num_rows($result)>0){
		output("`2Oh, Du hast doch schon eine Zugangsm�nze gekauft, wie aus meinen Unterlagen hervorgeht, ich w��te nicht, was ich Dir noch sagen k�nnte.");
		output("`2Dein Bett wird iin Deinem Raum immer f�r Dich bereit stehen, damit Du in uhe und Frieden dort schlummern kannst.");
		addnav("Weiter","klosterabt.php?op=abt");
        }else{
		output("`2Nun, in unseren Schlafss�len ruhen wir, und so mancher Gast, uns aus, bewacht von den G�ttern und der Klosterwache.");
		output("`2 Wenn Du willst, kannst auch Du hier bei uns jederzeit �bernachten, ohne Dich f�rchten zu m��en, �berfallen und beraubt zu werden. H�ttest Du daran Interesse?");
	addnav("Ja, gerne","klosterabt.php?op=muenze");
	addnav("Nein, vielen Dank","klosterabt.php?op=abt");
	}
}
if($_GET['op']=="muenze"){
	output("`2Um hier �bernachtenzu k�nnen, ben�tigst Du eine Zugangsm�nze.");
	output("`2Mit dieser M�nze wirst Du zu einem Bewohner des Klosters, allerdings ohne weiter Pflichten, sie kostet Dich nur 30 Gems M�chtest Du eine Erwerben?.");
	addnav("Ja, gerne","klosterabt.php?op=muka");
	addnav("Nein, vielen Dank","klosterabt.php?op=abt");
}
if($_GET['op']=="muka"){ 
	if ($session[user][gems] >29){
    		$session[user][gems]-=30; 
             	output(" `3Du greifst zu Deinem Beutel und �berreichst dem Abt `@30 Gems`3, die er dankend entgegen nimmt und sie in einer Truhe verstaut, die hinter seinem Schreibtisch steht."); 
             	output(" `3Dabei nimmt er auch eine kleine M�nze aus der Truhe, die er Dir aush�ndigt mit den Worten, gut auf sie zu achten, da sie sehr wertvoll sei und begr��t Dich als neuen Bewohner des Klosters XXX.");
             	output(" `3Du nimmst die M�nze, verstaust sie sorgf�ltig und dankst ihm.`n");
		$sql = "INSERT INTO items (name,owner,class,gems,description) VALUES ('Zugangsm�nze',".$session[user][acctid].",'Schmuck',10,'Sie wei�t Dich als Bewohner des Klosters aus')";
		db_query($sql);
	}else{ 
		output("`3Der Abt sch�ttelt l�chelnd den Kopf:`2 Ich f�rchte, Deine Gems werden nicht ausreichen, die M�nze zu kaufen."); 
		}
 		addnav("Zur�ck","klosterabt.php?op=abt");
}
if($_GET['op']=="gnade"){
	output("`2Du hast, zur Strafe, diesen Titel erhalten und er wird Dich begleiten, bis Du den G�ttern ein entsprechendes Opfer gebracht hast, da� 50 Gems betr�gt.");
	output("`2Wenn Du genug Gold hast, so sende ihnen eine offizielle Taube, da� Du Bu�e tun willst.");
	addnav("Weiter","klosterabt.php?op=abt");
}
if($_GET['op']=="buero1"){
	output("`3Da nun Deine Neugierde gestillt ist, machst Du Dich auf den Weg zur�ck in die Halle, wobei Du zuerst wieder in das B�ro des Sekret�rs mu�t, der nun an seinem Platz sitzt.");
	output("`3 Du gr��t ihn freundlich und verl��t sein B�ro in Richtung Klostervorraum.");
	addnav("Weiter","klosterhaus.php?op=halle");
}
page_footer();
?>
