<?php
// Idee und Umsetzung
// Morpheus aka Apollon 
// 2006 f�r Morpheus.Lotgd(LoGD 0.9.7 +jt ext (GER) 3)
// Mail to Morpheus@magic.ms or Apollon@magic.ms
// gewidmet meiner �ber alles geliebten Blume
require_once "common.php";
addcommentary();
page_header("Der Glockenturm");
if($_GET['op']==""){
	output("`7`b`cDer Glockenturm`c`b");
	output("`3`n`nDu gehst durch eine schmalle T�r in einen Raum, der im Erdgescho� des Glockenturmes liegt und blickst nach oben.");
	$sql = "SELECT * FROM items WHERE owner=".$session[user][acctid]." AND class='Beute' AND name='Phiolle'";
	$result = db_query($sql);
	if (db_num_rows($result)>0){
		output("`3Die Treppe ist sehr steil und der Aufsttieg bestimmt anstrengend, aber es gibt, au�er dem Balkon im obersten Gescho�, direkt unter dem Dach, auch noch einen Balkon auf halber H�he.");
		output("`3Bis dahin auf zu steigen, w�re nicht ganz so anstrengend.");
		output("`3Du �berlegst, was Du tun sollst.");
		addnav("Zum Balkon in der Mitte","klosterturm.php?op=mitte");
		addnav("Zum Balkon ganz oben","klosterturm.php?op=oben");
		addnav("Zur�ck zum Klosterhof","kloster.php");
	}else{
		output("`3Die Treppe ist sehr steil und der Aufsttieg bestimmt anstrengend, aber es gibt, au�er dem Balkon im obersten Gescho�, direkt unter dem Dach, auch noch einen Balkon auf halber H�he.");
		if ($session['user']['level']==15){
			output("`3Als Du nach vorne blickst, f�llt Dir eine T�r auf, die Du zuvor noch nie bemerkt hast.");
		}else{
			output("`3Bis dahin auf zu steigen, w�re nicht ganz so anstrengend.");
		}
		output("`3Du �berlegst, was Du tun sollst.");
		addnav("Zum Balkon in der Mitte","klosterturm.php?op=mitte");
		addnav("Zum Balkon ganz oben","klosterturm.php?op=oben");
		if ($session['user']['level']==15){
			addnav("Geheimnisvolle T�r","klosterturm.php?op=tuer");
		}
		addnav("Zur�ck zum Klosterhof","kloster.php");
	}
}
if($_GET['op']=="raum"){
	output("`3Wieder sthst Du im Raum, in dem die Treppe nach oben f�hrt und �berlegst, was Du tun sollst.");
	addnav("Zum Balkon in der Mitte","klosterturm.php?op=mitte");
	addnav("Zum Balkon ganz oben","klosterturm.php?op=oben");
	if ($session['user']['level']==15){
		addnav("Geheimnisvolle T�r","klosterturm.php?op=tuer");
	}
	addnav("Zur�ck zum Klosterhof","kloster.php");
}
if($_GET['op']=="mitte"){
	output("`3Du beginnst mit dem Aufstieg zum mittleren Balkon, der ziemlich antrengend ist, sich aber schon ziemlich lohnt, da Du eine recht gute Sicht ins Tal hast.");
	output("`3Wie mu� die erst von ganz oben sein?!");
	addnav("Zum Balkon ganz oben","klosterturm.php?op=oben1");
	addnav("Wieder nach unten","klosterturm.php?op=raum");
	addnav("Direkt zum Klosterhof","kloster.php");
}
if($_GET['op']=="oben"){
	output("`3Du beginnst mit dem Aufstieg zum obersten Balkon, der antrengend ist, sich aber absolut lohnt, da Du eine phantastische Sicht ins Tal und noch weiter hast.");
	output("`3In Deiner N�he stehen noch andere G�ste und unterhalten sich:");
	viewcommentary("klosterturm","`3Hinzuf�gen:`0",25,"staunt");
	addnav("Zum Balkon in der Mitte","klosterturm.php?op=mitte1");
	addnav("Wieder nach unten","klosterturm.php?op=raum");
	addnav("Direkt zum Klosterhof","kloster.php");
}
if($_GET['op']=="mitte1"){
	output("`3Du beginnst mit dem Abstieg zum mittleren Balkon weil Du neugierig bist, wie die Aussicht wohl von dort sein mag.");
	output("`3Dort angekommen stellst Du fest, da� die Aussicht von Oben doch wirklich besser war.");
	addnav("Zum Balkon ganz oben","klosterturm.php?op=oben");
	addnav("Wieder nach unten","klosterturm.php?op=raum");
	addnav("Direkt zum Klosterhof","kloster.php");
}
if($_GET['op']=="oben1"){
	output("`3Du beginnst mit dem weiteren Aufstieg zum obersten Balkon, der genauso antrengend ist, sich aber absolut lohnt, da Du von hier eine phantastische Sicht ins Tal, viel sch�ner als aus der Mitte.");
	output("`3In Deiner N�he stehen noch andere G�ste und unterhalten sich:");
	viewcommentary("klosterturm","`3Hinzuf�gen:`0",25,"staunt");
	addnav("Zum Balkon in der Mitte","klosterturm.php?op=mitte1");
	addnav("Wieder nach unten","klosterturm.php?op=raum");
	addnav("Direkt zum Klosterhof","kloster.php");
}
if($_GET['op']=="tuer"){
	output("`3Du �ffnest die geheimnisvolle T�r und stellst fest, da� sie in den Keller des Turmes f�hrt.");
	output("`3Mutig nimmst Du Dir eine Fackel und steigst hinab in den Keller, wo Du in einen Gang kommst, der Dich ein St�ck in den Berg f�hrt.");
	output("`3Pl�tzlich tut sich eine kleine Halle vor Dir auf, in die Seitenw�nde sind sieben Pfeiler gemei�elt worden, die, wie im Vorraum, nach oben laufenund sich dort zu einem Stern treffen.");
	output("`3Obwohl es keine Fenster oder sonstige Lichtquellen gibt, ist der Raum hell erleuchtet und in der Mitte kannst Du einen Altar sehen, auf dessen Vorderseite Du folgendes lesen kannst:`n`n");
	output("`6Krieger, der Du den `@Drachen`6 suchen gehst, empfange den Segen der G�tter in der kleinen Phiolle auf dem Altar.");
	output("`6M�ge Dich der Segen sicher gegen den `@GR�NEN DRACHEN `6f�hren und Dir Heil bringen.`n`n");
	output("`3Du gehst zum Altar, nimmst die Phiolle, �ffnest sie, trinkst und sp�rst, wie Dich eine geheimnisvolle Kraft durchdringt.");
		switch(e_rand(1,4)){
			case 1:
			output("`6 Deine Lebenspunkte haben sich erh�ht!");
			$session[user][hitpoints]*=1.2;
			break;
			case 2:
			output("`6 Du hast 2 Anwendungen in mysthischen Kr�ften erhaltent!");
			$session[user][magicuses]++;
			break;
			case 3:
			output("`6 Du hast 2 Anwendungen in dunklen Kr�ften erhaltent!");
			$session[user][darkartuses]++;
			break;
			case 4:
			output("`6 Du hast 2 Anwendungen in Diebesf�higkeiten erhaltent!");
			$session[user][thieveryuses]++;
			break;
		}
	addnav("Weiter","klosterturm.php?op=tuer1");
}
if($_GET['op']=="tuer1"){
	$sql = "INSERT INTO items (name,owner,class,gold,description) VALUES ('Phiolle',".$session[user][acctid].",'Beute',1,'Wertloser Plunder')";
	db_query($sql);
	output("`3Voll Ehrfurcht f�llst Du auf die Knie, dankst den G�ttern f�r ihre G�te und steckst die Phiolle noch ein bevor Du Dich auf den Weg zur�ck nach oben machst.");
	output("`3Als Du aus der T�r trittst, schlie�t sich hinter Dir die Wand, als w�re dort niemals eine T�r gewesen.");
	addnav("Zum Balkon in der Mitte","klosterturm.php?op=mitte");
	addnav("Zum Balkon ganz oben","klosterturm.php?op=oben");
	addnav("Zur�ck zum Klosterhof","kloster.php");
}
page_footer();
?>