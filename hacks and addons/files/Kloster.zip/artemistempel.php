<?php
// 20060401
// Idee und Umsetzung 
// Morpheus aka Apollon 
// 2006 f�r logd.at(LoGD 0.9.7 +jt ext (GER) 3) 
// Mail to Morpheus@magic.ms or Apollon@magic.ms 
// gewidmet meiner �ber alles geliebten Blume 
// Funktion entnommen aus der inn.php
// Dank an Anpera f�r seine Unterst�tzung bei diesm Modul
require_once("common.php"); 
page_header("Tempel der Artemis"); 

if ($_GET['op']=="gems"){ 
   if ($_POST['gemcount']==""){ 
      output("\"`2Nun, f�r Deine Edelsteine kann ich Dir einen magischen Trank brauen, je mehr Du mir gibst je st�rker wird er sein, der Grundtrank kostet 2 Gems.`0\""); 
      output("`n`nWieviele Edelsteine gibst du ihm?"); 
      output("<form action='artemistempel.php?op=gems' method='POST'><input name='gemcount' value='0'><input type='submit' class='button' value='Weggeben'>`n",true); 
      output("`nUnd welche Gunst erhoffst Du Dir von der G�ttin daf�r?`n`n<input type='radio' name='wish' value='1' checked> Charme`n<input type='radio' name='wish' value='2'> Lebenskraft`n",true); 
      addnav("","artemistempel.php?op=gems"); 
      output("<input type='radio' name='wish' value='3'> Gesundheit`n",true); 
      output("<input type='radio' name='wish' value='4'> Ansehen</form>",true); 
   }else{ 
      $gemcount = abs((int)$_POST['gemcount']); 
      if ($gemcount>$session['user']['gems']){ 
         output("Der Priester blickt dich an, sch�ttelt den Kopf und sagt l�chelnd: \"`2Du hast nich so viele Edelsteine bei Dir, `bich f�rchte, Du wirst noch welche Besorgen m��en!`b`0\""); 
      }else{ 
         output("`#Du platzierst $gemcount Edelsteine auf der Theke."); 
         if ($gemcount%2!=0){ 
            output(" Der Priester l�chelt milde, weil Du ihm einen Gem zuviel gegeben hast, den er Dir zwinkernd wieder gibt."); 
            $gemcount-=1; 
         } 
         if ($gemcount>0){
         	output("Der Prister wendet sich zum Altar, mischt einen Trunk und �berreicht Dir die Schale, die Du bis auf den letzten Tropfen leerst...`n`n"); 
         	$session['user']['gems']-=$gemcount; 
         	//debuglog("used $gemcount gems on potions"); 
            switch($_POST['wish']){ 
               case 1: 
               $session['user']['charm']+=($gemcount/2); 
               output("`&Du f�hlst dich charmant! `^(Du erh�ltst Charmepunkte)"); 
               break; 
               case 2: 
               $session['user']['maxhitpoints']+=($gemcount/2); 
               $session['user']['hitpoints']+=($gemcount/2); 
               output("`&Du f�hlst wie neue Lebensenergie in Dir w�chst! `^(Deine maximale Lebensenergie erh�ht sich permanent)"); 
               break; 
               case 3: 
               if ($session['user']['hitpoints']<$session['user']['maxhitpoints']) $session['user']['hitpoints']=$session['user']['maxhitpoints']; 
               $session['user']['hitpoints']+=($gemcount*10); 
               output("`&Du f�hlst, wie Deine Gesundheit zu steigen scheint! `^(Du erh�ltst vor�bergehend mehr Lebenspunkte)"); 
               break; 
               case 4: 
               $session['user']['reputation']+=(($gemcount/2)*5); 
               output("`&Ein paar Deiner S�nden wurden Dir vergeben und Dein Ansehen erh�ht"); 
               break;
               default:
               //catch cross scripting and cheating
               output("`&Der Priester ist nicht am�siert. Er informiert die G�tter, die �ber dein weiteres Schicksal entscheiden werden.");
               debuglog($session['user']['login']."�bergab einen unm�glichen und ung�ltigen Wert in artemistempel.php");
               break; 
            } 
         }else{ 
            output("`n`nDu �berlegst es Dir anders, entschuldigst Dich beim Priester und verabschiedest Dich von ihm."); 
         } 
      } 
   } 
   addnav("Zur�ck zum Klosterhof","kloster.php"); 
}else{
   output("`7`b`cTempel der Artemis`c`b"); 
   output("`n<table align='center'><tr><td><IMG SRC=\"images/artemis.jpg\"></tr></td></table>`n",true); 
   output("`3Du betrittst eine recht gro�e Tempelhalle, die hell und freundlich wirkt."); 
   output("`3Durch die gro�en, bunten Fenster in den Seiten dringt helles Sonnenlicht in den Tempel, an dessen Ende eine Statue der Artemis steht.`n"); 
   output("`3Vor der Statue steht ein Altar, der mit Blumen geschm�ckt ist, die in allen Farben leuchten und ein Priester ist grade dabei, sie mit Wasser zu versorgen.`n"); 
   output("`3Als er Dich bemerkt, stellt er seine Kanne bei Seite und wendet sich zu Dir:`2Hallo ".$session['user']['name']."`2, sei herzlichen willkommen im Tempel der Artemis!"); 
   output("`2Du m�chtest also die Gnade der G�ttin erflehen, auf da� sie Dich St�rke und Deinem Leben mehr Glanz verleihe.`n"); 
   output("`3Ehrf�rchtig nickst Du und er Priester l�chelt:`2 Nun, das sollte kein Problem sein, so fern Du bereit bist, der G�ttin angemessen Opfer zu bringen."); 
   output("`2Ich hoffe, Du besitzt auch Edelsteine, die Du zu opfern bereit bist!?`n"); 
   addnav("Ja, das will ich", "artemistempel.php?op=gems"); 
   addnav("Verzeiht, lieber doch nicht", "kloster.php"); 
}
page_footer(); 
?>