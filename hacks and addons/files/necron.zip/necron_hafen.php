<? 
require_once "common.php"; 
page_header("Necrons Toten-Hafen"); 
output("`^`c`bNecrons Toten-Hafen`b`c`6"); 
if ($_GET[op]==""){
output ("In Necron ist alles Prunkvoll und sch�n... aber nicht der Hafen hier sieht es aus wie vor der Koniallisierung durch Nightwood, �berall lungern Zombies rum und warten auf`n");
output ("Wesen die Reisen wollen, du siehst allerdings nur einen 3 Master der nach Nightwood fahren will. Ein anderes Schiff das scheinabr die neuen Kolonnien ansteuert hat leider gerade abgelegt`n
Du beschliesst dich etwas umzugucken und eventuell nach Hause zu fahren.");
addnav ("Zum Schiff nach Nightwood (300 Gold)","necron_hafen.php?op=nightwood");
addnav("Zur�ck nach Necron","necron.php"); 
}
if ($_GET[op]=="nightwood"){
if ($session[user][gold]>299 && $session[user][turns]>5){
output ("Du betrittst das Schiff und wirst gleich vom Capit�n eingewiesen. Dann bezahlst du die 300 Gold und wartest einige Stunden`n");
addnav ("Nach Nightwood","hafen.php");
$session[user][gold]-=300;
$session[user][turns]-=5;
}
else{
output ("Du kannst nicht Reisen da du zu M�de bist oder zu Arm!");
addnav ("Zur�ck zum Hafen","necron_hafen.php");
addnav("Zur�ck nach Necron","necron.php"); 
}
}
page_footer(); 
?> 