<? 
require_once "common.php"; 
page_header("Hafen"); 
output("`^`c`bHafen`b`c`6"); 
if ($_GET[op]==""){
output ("Die Hafengegend ist eine eher kriminelle Gegend, in der alle illegalen Gesch�fte 
abgewickelt werden, doch als du in diese Gegend kommst, ist nicht viel los, und die Nebelschwaden lassen dich auch nicht weit sehen.`n Trotzdem 
 kommst du zum Steg und guckst dir das Schiff nach Necron an.");
addnav ("Zum Schiff nach Necron (300 Gold)","hafen.php?op=necron");
addnav("Zur�ck ins Dorf","village.php"); 
}
if ($_GET[op]=="necron"){
if ($session[user][gold]>299 && $session[user][turns]>5){
output ("Du betrittst das Schiff und wirst gleich vom Capit�n eingewiesen. Dann bezahlst du die 300 Gold und wartest einige Stunden`n");
addnav ("Nach Necron","necron_hafen.php");
$session[user][gold]-=300;
$session[user][turns]-=5;
}
else{
output ("Du kannst nicht Reisen da du zu M�de bist oder zu Arm!");
addnav ("Zur�ck zum Hafen","hafen.php");
addnav("Zur�ck ins Dorf","village.php"); 
}
}
page_footer(); 
?> 