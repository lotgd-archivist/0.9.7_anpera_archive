<?
// German translation file by anpera 2003 for "Legend of the Green Dragon" by Eric Stevens
//
// Running on www.anpera.net/logd
//
// version: 2.0.1 for 0.9.7 
// changes:
// 2.0.1: fixed some errors, added referral.php, moved superuserparts to the end of the file
//
// please report bugs (and fixes if you know) to http://sourceforge.net/projects/lotgd or to logd@anpera.de
//
// I have to thank the following persons for additional translations, help, and errorfinding:
// raybe, rheiny, traumhaft, weasle
//

$translate_page = $_SERVER['PHP_SELF'];
$translate_page = substr($translate_page,strrpos($translate_page,"/")+1);
function translate($input){
	global $translate_page;
	//echo $_SERVER['SCRIPT_FILENAME'];
	//echo $translate_page;
	switch ($translate_page){
	case "index.php":
		$replace = array(
		"`cWelcome to Legend of the Green Dragon, a shameless knockoff of Seth Able's Legend of the Red Dragon.`n"=>"`cWillkommen bei Legend of the Green Dragon, schamlos abgekupfert von Seth Able's Legend of the Red Dragon.`n"
		,"The current time in the village is"=>"Die gegenw�rtige Zeit im Dorf ist"
		,array(
			"`@Next new game day in: "=>"`@N�chster neuer Spieltag ist in: "
			,"real time"=>"Echtzeit"
		)
		,"Enter your name and password to enter the realm.`n"=>"Gebe deinen Namen und dein Passwort ein, um diese Welt zu betreten.`n"
		,array(
			"Your session has timed out, you must log in again.`n"=>" Deine Sessionzeit ist abgelaufen. Bitte neu einloggen.`n"
			,"Also, it appears that you may be blocking cookies from this site.  At least session cookies must be enabled in order to use this site.`n"=>" Es scheint, als ob die Cookies dieser Seite von deinem System blockiert werden.  Zumindest Sessioncookies m�ssen f�r diese Seite zugelassen werden.`n"
		// part from "common.php"
			,"You are not logged in, this may be because your session timed out."=>" Du bist nicht eingeloggt. Wahrscheinlich ist deine Sessionzeit abgelaufen.`n"
			,"Account not logged in but session thinks they are."=>"Account ist nicht eingeloggt, aber die Session denkt, er ist es. "
			,"`4Error, your login was incorrect`0"=>"`4Fehler! Dein Login war falsch.`0 "
			,"Account Disappeared!"=>"Account verschwunden!"
		// end common
		)
		,"`c`2Game server running version: "=>"`c`2Version auf diesem Gameserver:  " 
		,"New to LoGD?"=>"Neu hier?"
		,"Create a character"=>"Charakter erstellen"
		,"Other"=>"Sonstiges"
		,"About LoGD"=>"�ber LoGD"
		,"List Warriors"=>"Liste der K�mpfer"
		,"Daily News"=>"T�gliche News"
		,"Game Setup Info"=>"Spieleinstellungen"
		,"LoGD Net"=>"LoGD Netz"
		,"Forgotten Password"=>"Passwort vergessen?"
		,array(
			"<u>U</u>sername:"=>"Name:"
			,"<u>P</u>assword:"=>"<u>P</u>asswort:"
		)	
		);
		break;
	case "create.php":
		$replace = array(
		"`#`cYour email has been validated.  You may now log in.`c`0"=>"`#`cDeine E-Mail Adresse wurde best�tigt. Du kannst jetzt einloggen.`c`0"
		,"`#Your email could not be verified.  This may be because you already validated your email.  Try to log in, and if that doesn't help, use the petition link at the bottom of the page."=>"`#Deine E-Mail Adresse konnte nicht best�tigt werden. M�glicherweise wurde sie schon best�tigt. Versuch mal dich einzuloggen und informiere den Webmaster, wenn es nicht klappt."
		,"`#Sent a new validation email to the address on file for that account.  You may use the validation email to log in and change your password."=>"`#Eine neue Best�tigungsmail wurde an die mit diesem Account gespeicherte Adresse verschickt. Du kannst sie zum Einlogen und zum �ndern des Passworts verwenden."
		,"`#Could not locate a character with that name.  Look at the List Warriors page off the login page to make sure that the character hasn't expired and been deleted."=>"`#Dieser Charakter kann nicht gefunden werden. Suche mal in der Kriegerliste danach, vielleicht wurde der Charakter gel�scht."
		,"`\$Error`^: Bad language was found in your name, please consider revising it."=>"`\$Fehler`^: Unzul�ssiger Name. Bitte �berdenke deinen Namen nochmal."
		,"You may have only one account.`n"=>"Du kannst nur einen Account haben.`n"
		,"Your password must be at least 4 characters long.`n"=>"Dein Passwort muss mindestens 4 Zeichen lang sein.`n"
		,"Your passwords do not match.`n"=>"Die Passw�rter stimmen nicht �berein.`n"
		,"Your name must be at least 3 characters long.`n"=>"Dein Name muss mindestens 3 Buchstaben lang sein.`n"
		,"Your character's name cannot exceed 25 characters.`n"=>"Der Name ist zu lang. Maximal 25 Buchstaben zugelassen.`n"
		,"You must enter a valid email address.`n"=>"Du musst eine g�ltige E-Mail Adresse eingeben.`n"
		,"`\$Error`^: Someone is already known by that name in this realm, please try again."=>"`\$Fehler`^: Diesen Namen gibt es schon. Bitte versuchs nochmal."
		,"`\$Error`^: Your account was not created for an unknown reason, please try again. "=>"`\$Fehler`^: Dein Account konnte aus unbekannten Gr�nden nicht erstellt werden. Versuchs nochmal. "
		,"How will you be known to this world?"=>"`nWie willst du in dieser Welt heissen?"
		,"Enter a password:"=>"`nDein Passwort: "
		,"Re-enter it for confirmation:"=>"`nPasswort best�tigen: "
		,array(
			"`#We're sorry, but that account does not have an email address associated with it, and so we cannot help you with your"=>"Bei diesem Accoount wurde keine E-Mail Adresse angegeben. Wir k�nnen mit dem vergessenen Passwort nicht helfen."
			,"forgotten password.  Use the Petition for Help link at the bottom of the page to"=>""
			,"request help with resolving your problem."=>""
		)
		,array(
			"`bForgotten Passwords:`b`n`n"=>"`bVergessene Passw�rter:`b`n`n"
			,"Enter your character's name: "=>"Gebe den Charakternamen ein: "
			,"Email me my password"=>"Passwort zumailen"
		)
		,array(
			"Enter your email address:"=>"`nDeine Email Adresse: "
			,"(optional)"=>"(freiwillig)"
			,"(required"=>"(ben�tigt"
			,", an email will be sent to this address to verify it before you can log in"=>", eine E-Mail wird zur Best�tigung an diese Adresse geschickt"
		)
		,array(
			"Your email has been validated, your login name is "=>"Deine E-Maill Adresse wurde best�tigt. Dein Login Name ist "
			,"Your account was created, your login name is"=>"Dein Charaker wurde erstellt. Dein Login Name ist"
			,"Click here to log in"=>"Hier klicken zum Einloggen"
			,"Characters that have never been logged in to will be deleted after"=>"Charaktere die nie einloggen werden nach "
			,"day(s) of no activity."=>" Tag(en) gel�scht."
			,"Characters that have never reached level 2 will be deleted after"=>"Charaktere die nie Level 2 erreichen werden nach "
			,"days of no activity."=>" Tagen ohne Aktivit�t gel�scht."
			,"Characters that have reached level 2 at least once will be deleted after"=>"Charaktere die Level 2 erreicht haben werden nach "
			,"Click here to log in"=>"Klick hier zum Einloggen"
		)
		,array(
			"`4An email was sent to `\$"=>"`4Eine E-Mail wurde an `\$"
			,"`4 to validate your address.  Click the link in the email to activate your account.`0`n`n"=>"`4 geschickt, um die Adresse zu best�tigen. Klicke auf den Link darin, um den Account zu aktivieren.`0`n`n"
		)
		,"Create your character"=>"Charakter erstellen"
		,array(
			"And are you a"=>"`nDu bist"
			,"Female or a"=>"Weiblich oder"
			,"Male?"=>"M�nnlich?"
		)
		);
		break;
	case "village.php":
		$replace = array(
		"Blades Boulevard"=>"Klingengasse"
		,"Forest"=>"Wald"
		,"Bluspring's Warrior Training"=>"Trainingslager"
		,"Slay Other Players"=>"K�mpfe mit anderen Spielern"
		,"Hall o' Fame"=>"Ruhmeshalle"
		,"Market Street"=>"Marktplatz"
		,"MightyE's Weaponry"=>"MightyE's Waffen"
		,"Pegasus Armor"=>"PegAsus R�stungen"
		,"Ye Olde Bank"=>"Die alte Bank"
		,"Gypsy Tent"=>"Zigeuner Zelt"
		,"Eye-catching Pavilion"=>"Auff�lligEr Pavilion"
		,"Tavern Street"=>"Tavernenstrasse"
		,"The Inn"=>"Die KneIpe"
		,"Merick's Stables"=>"Merick's St�lle"
		,"Hunter's Lodge"=>"J�gerh�tte"
		,"The Garden"=>"Der Garten"
		,"Curious Looking Rock"=>"Seltsamer Felsen"
		,"`bOther`b"=>"`bAnderes`b"
		,"F.A.Q. (newbies start here)"=>"F.A.Q. (F�r neue Spieler)"
		,"Daily News"=>"T�gliche News"
		,"Preferences"=>"Einstellungen"
		,"List Warriors"=>"K�mpfer Liste"
		,"Quit`0 to the fields"=>"`0In die Felder verlassen"
		,"Superuser Grotto"=>"Adminbereich"
		,"New Day"=>"Neuer Tag"
		,"Cast your Vote"=>"Stimme abgeben"
		,"`@`c`bVillage Square`b`cThe village hustles and bustles.  No one really notices that you're standing there."=>"`@`c`bDorfplatz`b`cDie Einwohner rennen gesch�ftig umher.  Keiner bemerkt wirklich, dass Du dort stehst."
		,"You see various shops and businesses along main street.  There is a curious looking rock to one side."=>"Du siehst verschiedene Gesch�fte und L�den entlang der Strasse.  Es gibt einen merkw�rdig aussehenden Felsen auf einer Seite."
		,"On every side the village is surrounded by deep dark forest.`n`n"=>"Auf jeder Seite wird das Dorf durch tiefen dunklen Wald umgeben.`n`n"
		,"The clock on the inn reads"=>"Die Uhr an der Kneipe zeigt"
		,"`n`n`%`@Nearby some villagers talk:`n"=>"`n`n`%`@In der N�he reden einige Dorfbewohner:`n"
		// part from "common.php"
		,"Previous"=>"Vorherige"
		,"Refresh"=>"Aktualisieren"
		,"Next"=>"N�chste"
		,"drunkenly says,"=>"lallt:"
		,"says,"=>"sagt:"
		// end of common
		,"Add"=>"Hinzuf�gen"
		);
		break;
	case "about.php":
		$replace = array(
		"Game Setup Info"=>"Spieleinstellungen"
		,"About LoGD"=>"�ber LoGD"
		,"Enable Slay Other Players"=>"Spieler gegen Spieler erlaubt"
		,"Player Fights per day"=>"Erlaubte Anzahl Spielerk�mpfe pro Tag"
		,"Days that new players are safe from PvP"=>"Tage, die Spieler sicher vor PvP sind"
		,"Amount of experience when players become killable in PvP"=>"N�tige Erfahrungspunkte, bevor ein Spieler im PvP angreifbar wird"
		,"Clean user posts (filters bad language and splits words over 45 chars long)"=>"Spielerbeitr�ge 'bereinigen' (Wortfilter)"
		,"Amount of gold to start a new character with"=>"Startmenge an Gold f�r neue Charaktere"
		,"New Days"=>"Neue Tage"
		,"Player must have fewer than how many forest fights to earn interest?"=>"Um Zinsen zu bekommen muss ein Spieler weniger Waldk�mpfe haben als"
		,"Max Interest Rate "=>"Maximaler Zinssatz " 
		,"Min Interest Rate "=>"Minimaler Zinssatz "
		,"Game days per calendar day"=>"Spieltage pro Kalendertag"
		,"Extra daily uses in specialty area"=>"Extras des Spezialgebiets t�glich einsetzen"
		,"Bank settings"=>"Bankeinstellungen"
		,"Max amount player can borrow per level"=>"Maximum, das ein Spieler pro Level leihen kann"
		,"Max amount player can transfer per level of recipient"=>"Maximum, das ein Spieler pro Level des Empf�ngers �berweisen kann"
		,"Minimum level a player has to be before they can transfer gold"=>"Mindestlevel f�r �berweisungen"
		,"Total transfers a player can receive in one play day"=>"�berweisungen, die ein Spieler pro Tag empfangen darf"
		,"Max amount total a player can transfer to others per level"=>"Absolutes Maximum, das ein Spieler pro Tag und Level �berweisen darf"
		,"Minimum amount per level of target for bounty"=>"Mindestbetrag pro Level der Zielperson"
		,"Maximum amount per level of target for bounty"=>"Maximalbetrag pro Level der Zielperson"
		,"Minimum player level for being a bounty target"=>"Mindestlevel, um Opfer sein zu k�nnen"
		,"Percentage of bounty kept by Dag Durnick"=>"Geb�hr f�r Dag Durnick in Prozent"
		,"How many bounties can a person set per day"=>"Anzahl an Kopfgeldern, die ein Spieler pro Tag aussetzen darf"
		,"Bounty"=>"Kopfgeld"
		,"Forest Fights per day"=>"Waldk�mpfe (Z�ge) pro Tag"
		,"Forest Creatures always drop at least 1/4 of possible gold"=>"Waldbewohner lassen wenigstens 1/4 des m�glichen Golds fallen"
		,"Forest"=>"Wald"
		,"Minimum level to allow slumming"=>"Mindestlevel zum Herumstreifen"
		,"Message size limit per message"=>"Maximale Nachrichtengr��e"
		,"Limit # of messages in inbox"=>"Maximale Anzahl an Nachrichten in der Inbox"
		,"Automatically delete old messages after (days)"=>"Alte Nachrichten werden automatisch gel�scht nach Tagen"
		,"Content Expiration"=>"Inhaltsverfallsdatum (0 f�r keines)"
		,"Days to keep comments and news?  (0 for infinite)"=>"Tage, die Kommentare und Neuigkeiten aufgehoben werden"
		,"Days to keep accounts that were never logged in to? (0 for infinite)"=>"Accounts, die sich nie eingeloggt haben, werden nach x Tagen gel�scht. x ="
		,"Days to keep level 1 accounts with no dragon kills? (0 for infinite)"=>"Level 1 Charaktere ohne Drachenkill werden nach x Tagen gel�scht. x ="
		,"Days to keep all other accounts? (0 for infinite)"=>"Alle anderen Accounts werden nach x Tagen Inaktivit�t gel�scht.x =" 
		,"Seconds of inactivity before auto-logoff"=>"Sekunden Inaktivit�t bis zum automatischen Logout"
		,"Useful Information"=>"N�tzliche Infos"
		,array(
			"Day Duration: "=>"Tagesl�nge: "
			," hours"=>" Stunden"
		)
		,"Current Server Time: "=>"aktuelle Serveruhrzeit: "
		,"Last new day: "=>"Letzter neuer Tag: "
		,"Current game time: "=>"aktuelle Spielzeit: "
		,"Next new day: "=>"N�chster neuer Tag: "
		,"`@<h3>Settings for this game</h3>`n`n"=>"`@<h3>Einstellungen f�r diesen Server</h3>`n`n"
		,"Login Page"=>"Zum Login"
		,"Return to the news"=>"Zur�ck zu Neuigkeiten"
		);
		break;
	case "armor.php":
		$replace = array(
		"`c`b`%Pegasus Armor`0`b`c"=>"`c`b`%Pegasus R�stungen`0`b`c"
		,"`5The fair and beautiful `#Pegasus`5 greets you with a warm smile as you stroll over to her brightly colored "=>"`5Die gerechte und h�bsche `#Pegasus`5 begr��t dich mit einem herzlichen L�cheln, als du ihren bunten Zigeunerwagen "
		,"gypsy wagon, which is placed, not out of coincidence, right next to `!MightyE`5's weapon shop.  Her outfit is "=>"betrittst, der nicht ganz zuf�llig direkt neben `!MightyE`5's Waffenladen steht. Ihr Erscheinungsbild "
		,"as brightly colored and outrageous as her wagon, and it is almost (but not quite) enough to make you look away from her huge "=>"ist genauso grell und farbenfroh, wie ihr Wagen, und lenkt dich fast (aber nicht ganz) von ihren "
		,"gray eyes and flashes of skin between her not-quite-sufficent gypsy clothes."=>"gro�en grauen Augen und der zwischen ihren nicht ganz ausreichenden Zigeunerklamotten hindurchleuchtenden Haut ab."
		,"Browse `#Pegasus`0' wares"=>"Pegasus' Waren durchst�bern"
		,"Return to the village"=>"Zur�ck zum Dorf"
		,"`5You look over the various pieces of apparal, and wonder if `#Pegasus`5 would be so good as to try some of them "=>"`5Du blickst �ber die verschiedenen Kleidungsst�cke und fragst dich, ob `#Pegasus`5 einige davon f�r dich "
		,"on for you, when you realize that she is busy staring dreamily at `!MightyE`5 through the window of his shop "=>"anprobieren w�rde. Aber dann bemerkst du, da� sie damit besch�ftigt ist, `!MightyE`5 vertr�umt durch das Fenster seines Ladens dabei zu beobachten, "
		,"as he, barechested, demonstrates the use of one of his fine wares to a customer.  Noticing for a moment that "=>"wie er gerade mit nacktem Oberk�rper einem Kunden den Gebrauch einer seiner Waren demonstriert. Als sie kurz wahrnimmt, dass du "
		,array(
			"`5Waiting until `#Pegasus`5 looks away, you reach carefully for the `%"=>"`5Du wartest, bis `#Pegasus`5 wieder abgelenkt ist, dann n�herst du dich vorsichtig `%"
			,"`5, which you silently remove from the stack of clothes on which "=>"`5 und l��t die R�stung leise vom Stapel verschwinden, auf dem sie lag. "
		)
		,"it sits.  Secure in your theft, you begin to turn around only to realize that your turning action is hindered by a fist closed tightly around your "=>"Deiner Beute sicher drehst du dich um ... nur um festzustellen, dass du dich nicht ganz umdrehen kannst, weil sich zwei H�nde fest um deinen "
		,"throat.  Glancing down, you trace the fist to the arm on which it is attached, which in turn is attached to a very muscular `!MightyE`5.  You try to "=>"Hals schliessen. Du schaust runter, verfolgst die H�nde bis zu einem Arm, an dem sie befestigt sind, der wiederum an einem �u�erst muskul�sen `!MightyE`5 befestigt ist. Du versuchst "
		,"explain what happened here, but your throat doesn't seem to be able to open up to let your voice through, let alone essential oxygen.  "=>"zu erkl�ren was hier passiert ist, aber dein Hals scheint nicht in der Lage zu sein, deine Stimme, oder gar den so dringend ben�tigten Sauerstoff hindurch zu lassen. "
		,"`n`nAs darkness creeps in on the edge of your vision, you glance pleadingly, but futilly at `%Pegasus`5 who is staring dreamily at `!MightyE`5, her "=>"`n`nAls langsam Dunkelheit in deine Wahrnehmung schl�pft, schaust du flehend zu `%Pegasus`5, doch die starrt nur v�llig vertr�umt und mit den H�nden seitlich auf dem l�chelnden Gesicht "
		,"hands clutched next to her face, which is painted with a large admiring smile."=>"auf `!MightyE`5."
		,array(
			"you are browsing her wares, she glances at your "=>"ihre Waren durchst�berst, blickt sie auf dein(e/n) "
			," and says that she'll give you `^"=>" und bietet dir daf�r im Tausch `^"
			,"`5 for them."=>"`5 Gold an.`n`n"
		)
		,"`b`&You have been slain by `!MightyE`&!!!`n"=>"`b`&Du wurdest von `!MightyE`& umgebracht!!!`n"
		,"`4All gold on hand has been lost!`n"=>"`4Das Gold, das du dabei hattest, hast du verloren!`n"
		,"`410% of experience has been lost!`n"=>"`4Du hast 10% deiner Erfahrung verloren!`n"
		,"You may begin fighting again tomorrow."=>"Du kannst vielleicht morgen wieder k�mpfen."
		,"`#Pegasus`5 looks at you, confused for a second, then realizes that you've apparently taken one too many bonks on the head, and nods and smiles."=>"`#Pegasus`5 schaut dich ein paar Sekunden verwirrt an, entschlie�t sich dann aber zu glauben, dass du wohl ein paar Schl�ge zu viel auf den Kopf bekommen hast und nickt l�chelnd."
		,"Try again?"=>"Nochmal versuchen?"
		,array(
			"`#Pegasus`5 takes your gold, and much to your surprise she also takes your `%"=>"`#Pegasus`5 nimmt dein Gold und sehr zu deiner �berraschung nimmt sie auch dein(e/n) `%"
			,"`5 and promptly puts a price on it, setting it neatly on another stack of clothes. "=>"`5, h�ngt ein Preisschild dran und legt die R�stung h�bsch zu den anderen. "
			,"`n`nIn return, she hands you a beautiful  new `%"=>"`n`nIm Gegenzug h�ndigt sie dir deine wunderbare neue R�stung `%"
			,"`n`nYou begin to protest, \"`@Won't I look silly wearing nothing but a `&"=>"`5 aus. `n`nDu f�ngst an zu protestieren: \"`@Werde ich nicht albern aussehen, wenn ich nichts ausser `&"
			,"`@?`5\" you ask.  You ponder it a moment, and then realize that everyone else in "=>"`@ trage?`5\" Du denkst einen Augenblick dar�ber nach, dann wird dir klar, dass jeder in der "
			,"the town is doing the same thing.  \"`@Oh well, when in Rome...`5\""=>"Stadt ja das selbe macht.	\"`@Na gut. Andere L�nder, andere Sitten`5\""
		)
		,array(
			"`bDefense`b"=>"`bVerteidigung`b"
			,"`bCost`b"=>"`bKosten`b"
		)
		,"Daily news"=>"T�gliche News"
		);
		break;
	case "bank.php":
		$replace = array(
		"`^`c`bYe Olde Bank`b`c`6"=>"`^`c`bDie alte Stadtbank`b`c`6"
		,"A short man in a immaculately arranged suit greets you from behind reading spectacles.`n`n"=>"Ein kleiner Mann in einem makellosen Anzug mit Lesebrille gr��t dich.`n`n"
		,"\"`5Hello my good man,`6\" you greet him, \"`5Might I inquire as to my balance this fine day?`6\"`n`n"=>"\"`5Hallo guter Mann,`6\" gr��t du zur�ck, \"`5Kann ich meinen Kontostand an diesem wundersch�nen Tag einsehen?`6\"`n`n"
		,array(
			"The banker mumbles, \"`3Hmm, "=>"Der Bankier murmelt \"`3Hmm, "
			,"`3, let's see.....`6\" as he scans down a page "=>"`3, mal sehen.....`6\" w�hrend er die Seiten in seinem Buch "
			,"in his ledger. "=>"sorgf�ltig �berfliegt." 
		)
		,"Take out a loan"=>"Kredit aufnehmen"
		,"Borrow More"=>"Mehr leihen"
		,"Transfer Money"=>"Gold �berweisen"
		,array(
			"\"`3Aah, yes, here we are.  You have a `&debt`3 of `^"=>"\"`3Aah ja, hier ist es.  Du hast `&Schulden`3 von `^"
			,"\"`3Aah, yes, here we are.  You have `^"=>"\"`3Aah ja, hier ist es. Du hast `^"
			," gold`3 in our "=>" Gold`3 bei unserer "
		)
		,"prestigious bank.  Is there anything else I can do for you?`6\""=>"renomierten Bank.  Kann ich sonst noch etwas f�r dich tun?`6\""
		,"`6`bTransfer Money`b:`n"=>"`6`bGeld �berweisen`b:`n"
		,array(
			"You may only transfer `^"=>"Du kannst maximal `^"
			,"`6 gold per the recipient's level.`n"=>"`6 Gold pro Level des Empf�ngers �berweisen.`n"
		)
		,array(
			"You may transfer no more than `^"=>"Du kannst nicht mehr als insgesamt `^"
			,"`6 gold total. "=>"`6 Gold �berweisen. "
		)
		,array(
			"(You have already transferred `^"=>"(Du hast heute schon `^"
			,"`6 gold today)`n`n"=>"`6 Gold �berwiesen)`n`n"
		)
		,"Transfer <u>h</u>ow much: "=>"Gebe den Betrag ein: "
		,"`6Transfer Completed!"=>"`6Transfer erfolgreich!"
		,array(
			"T<u>o</u>: "=>"An: "
			,"(partial names are ok, you will be asked to confirm the transaction before it occurs)."=>"(Unvollst�ndige Namen werden automatisch erg�nzt)`n"
		)
		,"Preview Transfer"=>"Vorschau"
		,"`6The little old banker tells you that he refuses to transfer money for someone who is in debt."=>"Der kleine alte Bankier weigert sich, Geld f�r jemanden zu �berweisen, der Schulden hat"
		,"`6`bConfirm Transfer`b:`n"=>"`6`bTransfer best�tigen`b:`n"
		,"The banker looks at you disgustedly and suggests you try narrowing down the field of who you want to send money to just a little bit!`n`n"=>"Der Bankier schaut dich �berfordert an und schl�gt dir vor, deine Suche vielleicht etwas mehr einzuengen, indem du den Namen genauer festlegst.`n`n"
		,array(
			"Withdraw"=>"Abheben"
			,"Deposit"=>"Einzahlen"
			,"Borrow"=>"Leihen"
			,"(you may borrow a max of "=>"(mit deinem Level kannst du maximal "
			," total at your level)? "=>" leihen) "
			,"Money will be withdrawn until you have none left, the remainder will be borrowed"=>"Gold wird abgehoben, bis dein Konto leer ist. Der Restbetrag wird geliehen"
			,"Pay off debt"=>"Schuld zur�ckzahlen"
			,"Pay off"=>"Abzahlen"
			," <u>h</u>ow much"=>" wieviel "
			,"Enter 0 or nothing to withdraw it all"=>"Gebe 0 oder gar nichts ein, um alles abzuheben"
			,"Enter 0 or nothing to deposit it all"=>"Gebe 0 oder gar nichts ein, um alles einzuzahlen"
		)
 		,"`6No one matching that name could be found!  Please try again."=>"`6Es gibt niemanden mit diesem Namen. Bitte nochmal versuchen."
		,"`6 has received too many transfers today, you will have to wait until tomorrow."=>"`6 hat f�r heute genug �berweisungen bekommen. Du wirst bis morgen warten m�ssen. "
		,"`6You might want to send a worthwhile transfer, at least as much as your level."=>"`6Du solltest etwas �berweisen, das sich auch lohnt. Wenigstens dein Level in Gold. "
		,"`6You cannot transfer money to yourself!  That makes no sense!"=>"6`Du kannst dir nicht selbst Gold �berweisen. Das macht keinen Sinn! "
		,"`6Transfer could not be completed, please try again!"=>"�berweisung fehlgeschlagen. Bitte nochmal versuchen."
		,"`\$ERROR: Not enough gold in hand to deposit.`^`n`n"=>"`\$FEHLER: Soviel Gold hast du nicht dabei.`^`n`n"
		,"`\$ERROR: Not enough gold in the bank to to withdraw.`^`n`n"=>"`\$FEHLER: Nicht genug auf dem Konto.`^`n`n"
		,"`6`bTransfer Completion`b`n"=>"`6`bTransfer vervollst�ndigen`b`n"
		,"Complete Transfer"=>"Transfer abschliessen"
		,array(
			"`6The transfer was not completed: You are not allowed to transfer more than `^"=>"`6Die �berweisung wurde nicht durchgef�hrt: Du darfst nicht mehr als `^"
			,"`6 gold total per day."=>"`6 Gold pro Tag �berweisen."
		)
		,array(
			"Having been informed that you have `&"=>"Nachdem du dar�ber informiert wurdest, dass du `&"
			,"`^ gold in your account, you declare that you would like to withdraw all `&"=>"`^ Gold auf dem Konto hast, erkl�rst du dem M�nnlein mit der Lesebrille, dass du gerne `&"
			,"`^ of it."=>"`^ davon abheben w�rdest. "
			,"`n`nThe little man stares blankly at you for a second, then advises you take basic arithmetic.  You realize your folly and think you should try again."=>"`n`nDer Bankier schaut dich bedauernd an und erkl�rt dir die Grundlagen der Mathematik. Nach einer Weile verstehst du deinen Fehler und w�rdest es gerne nochmal versuchen."
		)
		,array(
			"You plunk your `&"=>"Du schmeisst deine `&"
			,"`^ gold on the counter and declare that you would like to deposit all `&"=>"`^ Gold auf die Theke und erkl�rst, dass du die ganzen `&"
			,"`^ gold of it."=>"`^ Gold einzahlen m�chtest."
		)
		,"`n`nThe little old man stares blankly for a few seconds until you become self conscious and count your money again, realizing your mistake."=>"`n`nDer kleine alte Mann schaut dich nur verst�ndnislos an. Durch diesen seltsamen Blick verunsichert, z�hlst du nocheinmal nach und erkennst deinen Irrtum. Verdammt, wozu soll ein Krieger rechnen k�nnen?"
		,array(
			"ask to borrow `^"=>"fragst, ob du `^"
			,"`6 gold.  The short little man looks up your account and informs you that you may only borrow up to `^"=>"`6 Gold leihen kannst. Der kleine Mann informiert dich dar�ber, dass er dir in deiner gegenw�rtigen Situation nur `^"
		)
		,array(
			"`6You withdraw your remaining `^"=>"`6Du deine deine verbleibenden `^"
			,"`6 gold, and "=>"`6 Gold und weitere "
		)
		,array(
			"`6The transfer was not completed: `&"=>"`6Die �berweisung hat nicht geklappt: `&"
			,"`6 can only receive up to `^"=>"`6 kann maximal `^"
			,"`6 gold."=>"`6 Gold empfangen. "
		)
		,array(
			"`^`bYou deposit `&"=>"`^`bDu zahlst `&"
			,"`^ gold in to your bank account, "=>"`^ Gold auf dein Konto ein. "
		)
		,array(
			"`^`bYou withdraw `&"=>"`^`bDu hast `&" 
			,"`^ gold from your bank account, "=>"`^ Gold von deinem Bankkonto abgehoben. "
		)
		,array(
			"`6Considering the `^"=>"`6Mit den schlappen `^" 
			,"`6 gold in your account, you ask to borrow `^"=>"`6 Gold auf deinem Konto bittest du um einen Kredit von `^"
			,"`6, but"=>"`6 Gold, aber"
			,"the short little man looks up your account and informs you that you may only borrow up to `^"=>" der kurze kleine Mann informiert dich dar�ber, dass du mit deinem Level h�chstens `^"
			,"`6 gold at your level."=>"`6 Gold leihen kannst."
		)	
		,array(
			"You have "=>"Du hast "
			,"a balance of"=>"ein Guthaben von"
			,"a debt of"=>"Schulden in H�he von"
			," gold in the bank.`n"=>" Gold bei der Bank.`n"
			,"leaving you with "=>"Du hast damit "
			,"`^ gold in your account and `&"=>"`^ Gold auf deinem Konto und `&"
			,"`^ gold in hand.`b"=>"`^ Gold hast du bei dir.`b"
		)
		,array(
			"`6Transfer `^"=>"`6�berweise `^"
			,"`6 to `&"=>"`6 an `&"
		)
		,array(
			"`6How can you transfer `^"=>"Wie willst du `^"
			,"`6 gold when you only possess "=>"`6 Gold �berweisen, wenn du nur "
			,"`6?"=>"`6 besitzt?"
		)
		,"Return to the Village"=>"Zur�ck ins Dorf"
		,"borrow `^"=>"leihst dir `^"
		,"`6You "=>"`6Du "
		);
		break;
	case "bio.php":
		$replace = array(
		"`^Biography for "=>"`^Biografie f�r "
		,"`n`^Recent accomplishments (and defeats) of "=>"`n`^Letzte Leistungen (und Niederlagen) von "
		,"Return to the warrior list"=>"Zur Liste der Krieger"
		,"Return whence you came"=>"Zur�ck"
		// addnews for bio:
		,"`5 has been slain by `!MightyE`5 for trying to steal from `#Pegasus`5' Armor Wagon."=>"`5 wurde von `!MightyE`5 f�r den Versuch, etwas aus `#Pegasus`5' R�stungsladen zu stehlen, erw�rgt."
		,"`5 has been slain for trying to steal from `!MightyE`5's Weapons Shop."=>"`5 wurde beim Versuch in `!MightyE`5's Waffenladen zu stehlen niedergemetzelt."
		," was smote down for attempting to defile the gods (they tried to hack superuser pages)."=>" wurde f�r den Versuch, die G�tter zu besudeln, zu Tode gequ�lt! (Hackversuch gescheitert)"
		," and `5Violet`@ were seen heading up the stairs in the inn together."=>" und `5Violet`@ wurden dabei beobachtet, wie sie gemeinsam die Treppen in der Kneipe nach oben gingen. "
		," and `%Violet`& are joined today in joyous matrimony!!!"=>" und `%Violet`& haben heute den Bund der Ehe geschlossen!!!"
		," and `^Seth`& are joined today in joyous matrimony!!!"=>" und `^Seth`& haben heute den Bund der Ehe geschlossen!!!"
		," and `^Seth`@ were seen heading up the stairs in the inn together."=>" und `^Seth`@ wurden dabei beobachtet, wie sie gemeinsam die Treppen in der Kneipe nach oben gingen. "
		,"encountered strange powers in the forest, and was not seen again."=>"hat seltsame Kr�fte im Wald entdeckt und wurde nie wieder gesehen."
		,"has been gone for a while, and those who have looked for him do not come back."=>"ist f�r eine Weile verschwunden und jene, welche gesucht haben, kommen nicht zur�ck."
		,"'s body was found lying in an empty clearing."=>"'s lebloser K�rper wurde auf einer leeren Lichtung gefunden."
		," body was found on an altar in the woods."=>" K�rper wurde auf einem Altar im Wald gefunden."
		," remains were found charred upon an altar."=>" verkohlte �berreste wurden auf einem Altar gefunden."
		," body was found... being feasted on by rabbits!"=>" K�rper wurde gefunden... angeknabbert von Kaninchen!"
		,"weapons were found by a giant plant, but that's all anyone knows of what happend to her."=>"Waffen wurden bei einer gigantischen Pflanzen gefunden, aber das ist auch schon alles, was man �ber ihr Schicksal weiss."
		,"weapons were found by a giant plant, but that's all anyone knows of what happend to him."=>"Waffen wurden bei einer gigantischen Pflanzen gefunden, aber das ist auch schon alles, was man �ber sein Schiksal weiss."
		,"head was found... on a spike near an altar for the Gods."=>"Kopf wurde gefunden... auf einem Spiess in der N�he eines G�tteraltars."
		,"remains weren't very pretty when found..."=>"sterbliche �berreste waren nicht sehr ansehnlich, als sie gefunden wurden..."
		,"was slain by the gods because he was filled with greed!"=>"wurde von den G�ttern geschlagen, da er von Gier zerfressen war!"
		,"was slain by the gods because she was filled with greed!"=>"wurde von den G�ttern geschlagen, da sie von Gier zerfressen war!"
		,array(
			"The charred and twisted body of "=>"Der verbrannte und verdrehte K�rper von "
			," was found impaled by "=>" wurde gefunden - durchbohrt mit "
		)
		,"body was found in the woods, completely stripped of all gold."=>"K�rper wurde im Wald gefunden, allen Goldes beraubt."
		,"came home from the forest, a bit less than what she used to be."=>"kam aus dem Wald heim - etwas schw�cher als sie fr�her war."
		,"came home from the forest, a bit less than what he used to be."=>"kam aus dem Wald heim - etwas schw�cher als er fr�her war."
		,array(
			"Seth has left "=>"Seth hat "
			,"Violet has left "=>"Violet hat "
			,"`\$ to pursue \"other interests.\""=>"`\$ verlassen, um \"anderen Interessen\" nachzugehen."
		)
		,array(
			"`2Always cool, "=>"`2Cool, "
			," was seen walking around "=>" lief mit einem langen St�ck Klopapier an "
			," with a long string of toilet paper stuck to her foot.`n"=>"ihrem Fu� herum.`n"
			," with a long string of toilet paper stuck to his foot.`n"=>"seinem Fu� herum.`n"
		)
		,"was unmade by the gods"=>"wurde von den G�ttern aufgel�st"
		,array(
			" has earned the title `&"=>" hat sich den Titel `&"
			,"`# for having slain the `@Green Dragon`& `^"=>"`# f�r den `^"
			,"`# times!"=>"`#ten erfolgreichen Kampf gegen den `@Gr�nen Drachen`# verdient!"
		)
		,"has been resurrected by `\$Ramius`&."=>"wurde von `\$Ramius`& wiedererweckt."
		,"`) unsuccessfully haunted `7"=>"`) hat erfolglos heimgesucht `7"
		,"`) haunted `7"=>"`) hat heimgesucht `7"
		," was penalized for attempting to defile the gods."=>" wurde f�r den Versuch, die G�tter zu betr�gen, bestraft."
		,"committed suicide."=>"beging Selbstmord."
		,array(
			"`3 was slain attempting to rescue a prince from"=>"`3 starb beim Versuch, einen Prinzen aus "
			,"`3 was slain attempting to rescue a princess from"=>"`3 starb beim Versuch, eine Prinzessin aus "
			,"Wyvern Keep"=>"der Lindwurmfestung`3 zu befreien"
			,"Castle Slaag"=>"der Burg Slaag`3 zu befreien"
			,"Draco's Dungeon"=>"Draco's Kerker `3zu befreien"
		)
		,array(
			"`3 was hunted down by their master `^"=>"`3 wurde von Meister `^"
			,"`3 for being truant."=>"`3 wegen �berheblichkeit gejagt und gestellt."
		)
		,array(
			"`5 has been slain when "=>"`5 wurde geschlagen, als "
 			," has slain the hideous creature known as `@The Green Dragon`&.  Across all the lands, people rejoice!"=>" hat die abscheuliche, als `@Gr�ner Drachen`& bekannte Kreatur besiegt. �ber alle L�nder freuen sich die Menschen!"
			,"His bones now litter the cave entrance, just like the bones of those who came before.`n"=>"Seine Knochen liegen nun am Eingang der H�hle, genau wie die der Krieger, die vorher kamen.`n"
			,"Her bones now litter the cave entrance, just like the bones of those who came before.`n"=>"Ihre Knochen liegen nun am Eingang der H�hle, genau wie die der Krieger, die vorher kamen.`n"
			," has been slain in the forest by "=>" wurde im Wald niedergemetzelt von "
			,"`) has been defeated in the graveyard by "=>"`) wurde auf dem Friedhof erniedrigt von "
			,"encountered `@The Green Dragon`5!!!  "=>"dem `@Gr�nen Drach�n`5 begegnete!!!  "
			,"`5 has challenged their master, "=>"`5 hat Meister "
			,"and lost!`n"=>" herausgefordert und verloren!`n"
			,"`3 has defeated her master, `%"=>"`3 hat ihren Meister `%"
			,"`3 has defeated his master, `%"=>"`3 hat seinen Meister `%"
			,"`3 to advance to level `^"=>"`3 besiegt, steigt auf Level `^"
			,"`3 on her `^"=>"`3 auf und feiert ihren `^"
			,"`3 on his `^"=>"`3 auf und feiert seinen `^"
			,"`3 by sneaking in to their room in the inn!"=>"`3 brutal in einem Zimmer in der Kneipe."
			,"`3 in fair combat in the fields."=>"`3 in einem fairen Kampf in den Feldern."
			,"gold bounty by turning in `4"=>"Gold f�r den Kopf von `4"
			," was completely buried when "=>" wurde komplett begraben, als "
			," became greedy digging in the mines"=>" in der Mine zu gierig wurde"
			,"`3 defeated `4"=>"`3 besiegt `4"
			,"`3 collected `4"=>"`3 bekommt `4"
			," attacked "=>" angriff "
			,"`6The Inn"=>"`6einem Zimmer in der Kneipe"
			,"`@The Fields"=>"`@den Feldern"
			,"'s head!"=>"!"
			,"`3 day!!"=>"`3 Tag!!"
			," she "=>" sie "
			," he "=>" er "
		)

		// end addnews for bio
		,"`^Title: `@"=>"`^Titel: `@"
		,"`^Resurrections: `@"=>"`^Auferstehungen: `@"
		,array(
			"`^Race: `@"=>"`^Rasse: `@"
			,"Human"=>"Mensch"
			,"Dwarf"=>"Zwerg"
		)
		,array(
			"`^Gender: `@"=>"`^Geschlecht: `@"
			,"Female"=>"Weiblich"
			,"Male"=>"M�nnlich"
		)
		,array(
			"`^Specialty: `@"=>"`^Spezialgebiet: `@"
			,"Unspecified"=>"Unspezifiziert" 
			,"Dark Arts"=>"Dunkle K�nste" 
			,"Mystical Powers"=>"Mystische Kr�fte" 
			,"Thieving Skills"=>"Diebeskunst" 
		)
		,"Write Mail"=>"Mail schreiben"
		,array(
			"`^Creature: `@"=>"`^Kreatur: `@"
			,"None"=>"Keine"
		)
		,"`^Dragon Kills: `@"=>"`^Drachenkills: `@"
		);
		break;
	case "dag.php":
		$replace = array(
		"`c`bDag Durnick's Table`b`c"=>"`c`bDag Durnick's Tisch`b`c"
		,"Dag fishes a small leather bound book out from under his cloak, flips through it to a certain page and holds it up for you to see.`n`n"=>"Dag fischt ein kleines ledergebundenes Buch unter seinem Mantel hervor, bl�ttert es zu einer bestimmten Seite durch und h�lt es dir zum Lesen hin.`n`n"
		,"`c`bThe Bounty List`b`c`n"=>"`c`bDie Kopfgeld Liste`b`c`n"
		,"Dag gives you a piercing look. `7\"Ye be thinkin' I be an assassin or somewhat?  Ye already be placin' more than 'nuff bounties for t'day.  Now, be ye gone before I stick a bounty on yer head fer annoyin' me.`n`n"=>"Dag durchbohrt dich fast mit seinem Blick. \"`7H�ltst du mich f�r nen Meuchelm�rder oder was? Du hast heut schon genuch Kopfgelder ausgesetzt. Jetz hau ab, bevor ich n Kopfgeld auf deinen Kopf aussetz, weil du mir auf die Nerven gehst.\"`n`n"
		,array(
			"Dag Durnick glances up at you and adjusts the pipe in his mouth with his teeth.`n`7\"So, who ye be wantin' to place a hit on? Just so ye be knowing, they got to be legal to be killin', they got to be at least level "=>"Dag Durnick blickt zu dir auf und r�ckt seine Pfeife mit den Z�hnen zurecht.`n\"`7So, wen willst'n tot sehen? Du sollst aber wissen, dass wir keine Kinder killn, deswegen muss dein Opfer mindestens Level "
			,", and they can't be having too much outstandin' bounty nor be getting hit to frequent like, so if they ain't be listed, they can't be contracted on!  We don't run no slaughterhouse here, we run a.....business.  Also, there be a "=>" sein und der Preis darf nicht zu hoch sein. Ausserdem d�rfen die Opfer nicht zu oft getroffen werdn. Also wer in meinem Buch nicht gelistet is, kann nicht zum Abschuss freigegeben werdn! Wir betreiben hier kein Schlachthaus, sondern 'n ... Unternehmen. Ich verlang "
			,"% listin' fee fer any hit ye be placin'.\"`n`n"=>"% Bearbeitungsgeb�hren f�r jeden Namen, den ich auf die Liste setzn soll.\"`n`n"
		)
		,"Dag Durnick sneers at you, `7\"There not be anyone I be knowin' of by that name.  Maybe ye should come back when ye got a real target in mind?\""=>"Dag Durnick sagt h�hnisch lachend: `7\"Es gibt nicht einen den ich mit so einem Namen kenne. Vielleicht kommst' wieder, wenn du 'n echtes Opfer hast.\""
		,"Dag Durnick scratches his head in puzzlement, `7\"Ye be describing near half th' town ye fool?  Why don't ye be giving me a better name now?\""=>"Dag Durnick kratzt sich verwirrt am Kopf. `7\"Du beschreibst hier fast die H�lfte der Stadt, du Narr. Warum gibst du mir jetzt nicht mal ne genauere Beschreibung?\" "
		,"Dag Durnick searches through his list for a moment, `7\"There be a couple of 'em that ye could be talkin' about.  Which one ye be meaning?\"`n"=>"Dag Durnick durchsucht seine Liste f�r einen Moment. `7\"Da sind ein paar, die du meinen k�nntest. Wer genau solls denn sein?\"`n"
		,"Dag Durnick slaps his knee laughing uproariously, `7\"Ye be wanting to take out a contract on yerself?  I ain't be helping no suicider, now!\""=>"Dag Durnick schl�gt sich br�llend lachend auf die Schenkel: `7\"Du willst n Kopfgeld auf dich selbst aussetzen? Ich helf doch keinem Selbstm�rder!\""
		,"Dag Durnick stares at you angrily, `7\"I told ye that I not be an assassin.  That ain't a target worthy of a bounty.  Now get outta me sight!\""=>"Dag Durnick starrt dich �rgerlich an: `7\"Hab ich dir nicht gesagt, dass ich kein Meuchler bin? Das ist kein Opfer, das ein Kopfgeld wert w�re. Jetzt geh mir aus den Augen!\""
		,array(
			"Dag Durnick scowls, `7\"Ye think I be workin' for that pittance?  Be thinkin' again an come back when ye willing to spend some real coin.  That mark be needin' at least "=>"Dag Durnick blickt finster: `7\"Glaubst im Ernst, ich arbeite f�r so nen Hungerlohn? Denk ma dr�ber nach und komm wieder, wenn du bereit bist, hartes Bares zu bezahlen. F� dein Opfer brauchste mindestens "
			," gold to be worth me time.\""=>" Gold, damits meine Zeit wert is.\""
		)
		,"Dag Durnick scowls, `7\"Ye don't be havin enough gold to be settin' that contract.  Wastin' my time like this, I aught to be puttin' a contract on YE instead!"=>"Dag Durnick schaut dich finster an: `7\"Du hast nicht genug Gold f�r diesen Vertrag. Wenn du meine Zeit so vergeudest, sollte ich stattdessen vielleicht n Kopfgeld auf DICH aussetzen!\""
		,array(
			"Dag looks down at the pile of coin and just leaves them there. `7\"I'll just be passin' on that contract.  That's way more'n `^"=>"Dag schaut auf den Berg M�nzen und l�sst ihn unber�hrt liegen. `7\"Ich werde diesen Vertrag ablehnen. Das is viel mehr, als `^"
			," `7be worth and ye know it.  I ain't no durned assassin. A bounty o' "=>" `7Wert is und das weisst du. Ich bin kein verdammter Auftragskiller. N Kopfgeld von "
			," already be on their head.  I might be willin' t'up it to "=>" is schon auf diesen Kopf ausgesetzt. Ich w�r bereit, es auf "
			,", after me "=>" zu erh�hen, nach meinen "
			,"% listin' fee of course\"`n`n"=>"% Bearbeitungsgeb�hren nat�rlich\"`n`n"
		)
		,array(
			"You slide the coins towards Dag Durnick, who deftly palms them from the table. `7\"I'll just be takin' me "=>"Du schiebst die M�nzen zu Dag Durnick, der sie flink einstreicht. `7\"Ich werd mir nur meine "
			,"% listin' fee offa the top.  The word be put out that ye be wantin' `^"=>"% Geb�hr einbehalten. Ich werd die Nachricht verbreiten, dass sich jemand um `^"
			,"`7taken care of. Be patient, and keep yer eyes on the news.\"`n`n"=>"`7k�mmern soll. Hab Geduld und hab ein Auge auf die News.\"`n`n"
		)
		,"You stroll over to Dag Durnick, who doesn't even bother to look up at you. He takes a long pull on his pipe.`n"=>"Du schlenderst r�ber zu Dag Durnick, der es nichtmal f�r n�tig h�lt, zu dir aufzuschauen. Er nimmt einen langen Zug aus seiner Pfeife.`n"
		,"`7\"Ye probably be wantin' to know if there's a price on yer head, ain't ye.\"`n`n"=>"`7\"Du willst wohl wissn, ob n Preis auf deinen Kopf ausgesetzt is, richtig?\"`n`n"
		,array(
			"\"`3Well, it be lookin like ye have `^"=>"\"`3Nun, es sieht so aus als ob da `^"
			," gold`3 on yer head currently. Ye might wanna be watchin yourself.\""=>" Gold`3 auf deinen Kopf ausgesetzt is. Du solltest gut auf dich aufpassen.\""
		)
		,"\"`3Ye don't have no bounty on ya.  I suggest ye be keepin' it that way.\""=>"\"`3Da is kein Kopfgeld auf dich ausgesetzt. Ich schlag vor du tust alles, damit das auch so bleibt.\""
		,"Check the Wanted List"=>"Kopfgeldliste"
		,"Set a Bounty"=>"Kopfgeld aussetzen"
		,"Talk to Dag Durnick"=>"Rede mit Dag Durnick"
		,"Return to the inn"=>"Zur�ck zur Kneipe"
		,"`2Target: "=>"`2Zielperson: "
		,"`2Amount to Place: "=>"`2Betrag aussetzen: "
		,"Finalize Contract"=>"Vertrag abschliessen"
		,array(
			"Bounty Amount"=>"Kopfgeld"
			,"Location"=>"Ort"
			,"Sex"=>"Geschlecht"
			,"Last on"=>"Zuletzt online"
			,"`3Boar's Head Inn`0"=>"`3Zimmer in Kneipe`0"
			,"`3The Fields`0"=>"`3Felder`0"
			,"`!Female`0"=>"`!Weiblich`0"
			,"`!Male`0"=>"`!M�nnlich`0"
			,"Today"=>"Heute"
			,"Yesterday"=>"Gestern"
			," days"=>" Tage"
			,"1 day"=>"1 Tag"
		)
		);
		break;
	case "dragon.php":
		$replace = array(
		"`\$Fighting down every urge to flee, you cautiously enter the cave entrance, intent "=>"`\$Du erstickst jeden Drang zu fliehen und betrittst vorsichtig die H�hle. Du spekulierst "
		,"on catching the great green dragon sleeping, so that you might slay him with a minimum "=>"darauf, den gro�en Drachen im Schlaf zu �berraschen, um ihn mit einem Minimum an eigenem Schmerz "
		,"of pain.  Sadly, this is not to be the case, for as you round a corner within the cave "=>"zu erlegen. Leider ist das nicht der Fall. Du biegst in der H�hle um eine Ecke "
		,"you discover the great beast sitting on its haunches on a huge pile of gold, picking its "=>" und entdeckst das Riesenbiest, das mit den Hinterbeinen auf einem gewaltigen Haufen Gold sitzt und "
		,"teeth with a rib."=>"seine Z�hne mit etwas reinigt, das wie eine Rippe aussieht."
		,"`b`c`&~~ Flawless Fight ~~`0`c`b`n`n"=>"`b`c`&~~ Perfekter Kampf ~~`0`c`b`n`n"
		,"`2Before you, the great dragon lies immobile, its heavy breathing like acid to your lungs.  "=>"`2Vor dir liegt regungslos der gro�e Drache. Sein schwerer Atem ist wie S�ure f�r deine Lungen.  "
		,"You are covered, head to toe, with the foul creature's thick black blood.  "=>"Du bist vom Kopf bis zu den Zehen mit dem dicken schwarzen Blut dieser stinkenden Kreatur bedeckt.  "
		,"The great beast begins to move its mouth.  You spring back, angry at yourself for having been "=>"Das Riesenbiest f�ngt pl�tzlich an, den Mund zu bewegen. Ver�rgert �ber dich selbst, da� du dich von dem vorget�uschten Tod "
		,"fooled by its ploy of death, and watch for its huge tail to come sweeping your way.  But it does "=>"der Kreatur reilegen lassen hast, springst du zur�ck und erwartest, dass der riesige Schwanz auf dich zugeschossen kommt. Doch das passiert "
		,"not.  Instead the dragon begins to speak.`n`n"=>"nicht. Stattdessen beginnt der Drachen zu sprechen:`n`n"
		,"\"`^Why have you come here mortal?  What have I done to you?`2\" it says with obvious effort.  "=>"\"`^Warum bist du hierher gekommen, Sterblicher? Was habe ich dir getan?`2\", sagt er mit sichtlicher Anstrengung.  "
		,"\"`^Always my kind are sought out to be destroyed.  Why?  Because of stories from distant lands "=>"\"`^Meinesgleichen wurde schon immer gesucht, um vernichtet zu werden. Warum? Wegen Geschichten aus fernen L�ndern, "
		,"that tell of dragons preying on the weak?  I tell you that these stories come only from misunderstanding "=>"die von Drachen erz�hlen, die Jagd auf die Schwachen machen? Ich sage dir, da� diese M�rchen nur durch Mi�verst�ndnisse "
		,"of us, and not because we devour your children.`2\"  The beast pauses, breathing heavily before continuing, "=>"�ber uns entstehen, und nicht, weil wir eure Kinder fressen.`2\" Das Biest macht eine Pause um schwer zu atmen, dann f�hrt es fort: "
		,"\"`^I will tell you a secret.  Behind me now are my eggs.  They will hatch, and the young will battle "=>"\"`^Ich werde dir jetzt ein Geheimnis verraten. Hinter mir liegen meine Eier. Meine Jungen werden schl�pfen und sich gegenseitig "
		,"each other.  Only one will survive, but she will be the strongest.  She will quickly grow, and be as "=>"auffressen. Nur eins wird �berleben, aber das wird das st�rkste sein. Es wird sehr schnell wachsen und "
		,"powerful as me.`2\"  Breath comes shorter and shallower for the great beast.`n`n"=>"genauso stark werden wie ich.`2\" Der Atem des Drachen wird k�rzer und flacher.`n`n"
		,"\"`#Why do you tell me this?  Don't you know that I will destroy your eggs?`2\" you ask.`n`n"=>"Du fragst: \"`#Warum erz�hlst du mir das? Kannst du dir nicht denken, da� ich deine Eier jetzt auch vernichten werde?`2\""
		,"\"`^No, you will not, for I know of one more secret that you do not.`2\"`n`n"=>"\"`^Nein, das wirst du nicht. Ich kenne noch ein weiteres Geheimnis, von dem du offensichtlich nichts wei�t.`2\"`n`n"
		,"\"`#Pray tell oh mighty beast!`2\"`n`n"=>"\"`#Bitte erz�hle, oh m�chtiges Wesen!`2\"`n`n"
		,"The great beast pauses, gathering the last of its energy.  \"`^Your kind cannot tolerate the blood of "=>"Das gro�e Biest macht eine Pause, um seine letzten Kr�fte zu sammeln. \"`^Eure Art vertr�gt das Blut Meinesgleichen nicht. "
		,"my kind.  Even if you survive, you will be a feeble human, barely able to hold a weapon, your mind "=>"Selbst wenn du �berleben solltest, wirst du nur noch ein schwacher Mensch sein, kaum in der Lage, eine Waffe zu halten. Dein Geist "
		,"blank of all that you have learned.  No, you are no threat to my children, for you are already dead!`2\"`n`n"=>"wird vollst�ndig geleert sein von allem, was du je gelernt hast. Nein, du bist keine Bedrohung f�r meine Kinder, denn du bist bereits tot!`2\"`n`n"
		,"Realizing that already the edges of your vision are a little dim, you flee from the cave, bound to reach "=>"Du bemerkst, dass deine Wahrnehmung tats�chlich bereits zu schwinden beginnt und fliehst Hals �ber Kopf aus der H�hle, nur darauf fiixiert, "
		,"the healer's hut before it is too late.  Somewhere along the way you lose your weapon, and finally you "=>"die H�tte des Heilers zu erreichen, bevor es zu sp�t ist. Irgendwo unterwegs verlierst du deine Waffe und schlie�lich "
		,"trip on a stone in a shallow stream, sight now limited to only a small circle that seems to float around "=>"stolperst du �ber einen Stein in einem schmalen Bach. Deine Sicht ist inzwischen auf einen kleinen Kreis beschr�nkt, der in deinem Kopf "
		,"your head.  As you lay, staring up through the trees, you think that nearby you can hear the sounds of the "=>"herumzuwandern scheint. W�hrend du so da liegst und in die B�ume starrst, glaubst du die Ger�usche des Dorfes "
		,"village.  Your final thought is that although you defeated the dragon, you reflect on the irony that it "=>"in der N�he zu h�ren. Dein letzter ironischer Gedanke ist, da�, obwohl du den Drachen besiegt hast, er doch "
		,"defeated you.`n`n"=>"dich besiegt hat.`n`n"
		,"As your vision winks out, far away in the dragon's lair, an egg shuffles to its side, and a small crack "=>"W�hrend sich deine Wahrnehmung vollst�ndig verabschiedet, f�llt in der Drachenh�hle weit entfernt ein Ei auf die Seite und ein kleiner Riss "
		,"appears in its thick leathery skin."=>"erscheint in der dicken, lederartigen Schale."
		,"`nYou fall forward, and remember at the last moment that you at least managed to grab some of the dragon's treasure, so maybe it wasn't all a total loss."=>"`nDu f�llst vorw�rts um. Im Fallen erinnerst du sich, dass du es im letzten Moment doch noch geschafft hast, etwas von dem Schatz des Drachen einzustecken. Vielleicht war das alles ja doch kein totaler Verlust. "
		,"`n`nYou wake up in the midst of some trees.  Nearby you hear the sounds of a village.  "=>"`n`nDu erwachst umgeben von B�umen. In der N�he h�rst du die Ger�usche eines Dorfs.  "
		,"Dimly you remember that you are a new warrior, and something of a dangerous Green Dragon that is plaguing "=>"Dunkel erinnerst du dich daran, da� du ein neuer Krieger bist, und an irgendwas von einem gef�hrlichen gr�nen Drachen, der die Gegend heimsucht. "
		,"the area.  You decide you would like to earn a name for yourself by perhaps some day confronting this "=>"Du beschlie�t, da� du dir einen Namen verdienen k�nntest, wenn du dich vielleicht eines Tages dieser abscheulichen Kreatur stellst."
		,"vile creature."=>""
		,"It is a new day"=>"Es ist ein neuer Tag"
		,"`n`n`^You are now known as `&"=>"`n`n`^Du bist nun bekannt als `&"
		,array(
			"`n`n`&Because you have slain the dragon "=>"Weil du den Drachen "
			," times, you start with some extras.  You also keep additional hitpoints you've earned or purchased.`n"=>" mal besiegt hast, startest du mit einigen Extras. Ausserdem beh�ltst du alle zus�tzlichen Lebenspunkte, die du verdient oder gekauft hast.`n"
		)
		,"`^You gain FIVE charm points for having defeated the dragon!`n"=>"`^Du bekommst F�NF Charmepunkte f�r deinen Sieg �ber den Drachen!`n"
		,"The creature's tail blocks the only exit to its lair!"=>"Der Schwanz der Kreatur versperrt den einzigen Ausgang aus der H�hle!"
		,"`&With a mighty final blow, `@The Green Dragon`& lets out a tremendous bellow and falls to your feet, dead at last."=>"`&Mit einem letzten m�chtigen Knall l�sst `@der Gr�ne Drachen`& ein furchtbares Br�llen los und f�llt dir vor die F��e, nun wirklich tot."
		,"Continue"=>"Weiter"
		,"Daily news"=>"T�gliche News"
		,"`b`&You have been slain by `%"=>"`b`&Du wurdest besiegt von `%"
		,"`4All gold on hand has been lost!`n"=>"`4Du hast all dein Gold verloren!`n"
		,"You may begin fighting again tomorrow."=>"Du kannst morgen wieder k�mpfen."
 		,"`@Victory!`n`n"=>"`@Sieg!`n`n"
		// battle (battle.php & common.php)
		,"You feel mortal again."=>"Du bist wieder sterblich."
		,"`n`&You feel godlike`n`n"=>"`n`&Du f�hlst dich gottgleich`n`n"
		,"`n`^You begin to regenerate!`n`n"=>"`n`^Du f�ngst an zu regenerieren!`n`n"
		,"You have stopped regenerating"=>"Deine Regeneration hat aufgeh�rt"
		,"You have no wounds to regenerate."=>"Du bist v�llig gesund."
		,"`% is clutched by a fist of earth and slammed to the ground!`n`n"=>"`% wird von einer Klaue aus Erde gepackt und auf den Boden geschleudert!`n`n"
		,"The earthen fist crumbles to dust."=>"Die erdene Faust zerf�llt zu staub."
		,"`n`^Your weapon glows with an unearthly presence.`n`n"=>"`n`n`^Deine Waffe gl�ht in einem �berirdischen Schein.`n`n"
		,"Your weapon's aura fades."=>"Die Aura deiner Waffe verschwindet."
		,"You feel a tingle as your weapon tries to heal your effectivly healthy body."=>"Du f�hlst ein Prickeln, als deine Waffe versucht, deinen vollst�ndig geheilten K�rper zu heilen."
		,"Your weapon wails as you deal no damage to your opponent."=>"Deine Waffe scheint zu jammern, als du deinem Gegner keinen Schaden machst."
		,"`n`^Your skin sparkles as you assume an aura of lightning`n`n"=>"`n`^Deine Haut glitzert, als du dir eine Aura aus Blitzen zulegst`n`n"
		,"With a fizzle, your skin returns to normal."=>"Mit einem Zischen wird deine Haut wieder normal."
		," is slightly singed by your lightning, but otherwise unharmed."=>" ist leicht geblendet von deinen Blitzen, ansonsten aber unverletzt."
		,array(
			"`nYou furrow your brow and call on the powers of the elements.  A tiny flame appears.  "=>"Du legst deine Stirn in Falten und beschw�rst die Elemente.  Eine kleine Flamme erscheint.  "
			," lights a cigarrette from it, giving you a word of thanks before swinging at you again."=>" z�ndet sich eine Zigarette daran an, dankt dir und st�rzt sich wieder auf dich. "
		)
		,array(
			"`n`\$You call on the spirits of the dead, and skeletal hands claw at "=>"`n`\$Du rufst die Geister der Toten und skelettartige H�nde zerren an "
			," from beyond the grave.`n`n"=>" aus den tiefen ihrer Gr�ber.`n`n"
		)
		,"Your skeleton minions crumble to dust."=>"Deine Skelettdiener zerbr�ckeln zu staub."
		,"`n`\$You pull out a tiny doll that looks like "=>"`n`\$Du holst eine winzige Puppe hervor, die aussieht wie "
		,array(
			"`n`\$You place a curse on "=>"`n`\$Du sprichst einen Fluch auf die Ahnen von "
			,"'s ancestors.`n`n"=>". `n`n"
		)
		,"Your curse has faded."=>"Dein Fluch ist gewichen."
		," staggers under the weight of your curse, and deals only half damage."=>" taumelt unter der Gewalt deines Fluchs und macht nur halben Schaden."
		,array(
			"`n`\$You hold out your hand and "=>"`n`\$Du streckst deine Hand aus und "
			," begins to bleed from its ears.`n`n"=>" f�ngt an aus den Ohren zu bluten.`n`n"
		)
		,"Your victim's soul has been restored."=>"Die Seele deines Opfers hat sich erholt."
		," claws at its eyes, trying to release its own soul, and cannot attack or defend."=>" kratzt sich beim Versuch, die eigene Seele zu befreien, fast die Augen aus und kann nicht angreifen oder sich verteidigen."
		,array(
			"`nExhausted, you try your darkest magic, a bad joke.  "=>"`nErsch�pft versuchst du deine dunkelste Magie: einen schlechten Witz.  "
			," looks at you for a minute, thinking, and finally gets the joke.  Laughing, it swings at you again.`n`n"=>" schaut dich nachdenklich eine Minute lang an. Endlich versteht er den Witz und st�rzt sich lachend wieder auf dich.`n`n"
		)
		,array(
			"`n`^You call "=>"`n`^Du gibst "
			," a bad name, making it cry.`n`n"=>" einen schlimmen Namen und bringst deinen Gegner zum Weinen.`n`n"
		)
		,"Your victim stops crying and wipes its nose."=>"Dein Gegner putzt sich die Nase und h�rt auf zu weinen."
		," feels dejected and cannot attack as well."=>" ist deprimiert und kann nicht so gut angreifen."
		,"`n`^You apply some poison to your "=>"`n`^Du reibst Gift auf dein(e/n) "
		,"Your victim's blood has washed the poison from your blade."=>"Das Blut deines Gegners hat das Gift von deiner Waffe gewaschen."
		,"Your attack is multiplied!"=>"Dein Angriffswert vervielfacht sich!"
		,array(
			"`n`^With the skill of an expert thief, you virtually dissapear, and attack "=>"`n`^Mit dem Geschick eines erfahrenen Diebs scheinst du zu verschwinden und kannst "
			," from a safer vantage point.`n`n"=>" aus einer g�nstigeren und sichereren Position angreifen.`n`n"
		)
		,"Your victim has located you."=>"Dein Opfer hat dich gefunden."
		,"cannot locate you."=>" kann dich nicht finden."
		,array(
			"`n`^Using your skills as a thief, dissapear behind "=>"`n`^Mit deinen F�higkeiten als Dieb verschwindest du und schiebst "
			," and slide a thin blade between its vertibrae!`n`n"=>" von hinten eine d�nne Klinge zwischen die R�ckenwirbel.`n`n "
		)
		,"Your victim won't be so likely to let you get behind it again!"=>"Dein Opfer ist nicht mehr so nett, dich hinter sich zu lassen!"
		,"Your attack is multiplied, as is your defense!"=>"Dein Angriffswert und deine Verteidigung vervielfachen sich!"
		,array(
			"`nYou try to attack "=>"`nDu versuchst, "
			," by putting your best thievery skills in to practice, but instead, you trip over your feet."=>" anzugreifen, indem du deine besten Diebesk�nste in die Praxis umsetzt - aber du stolperst �ber deine eigenen F�sse."
		)
		,array(
			"`!Lover's Protection"=>"`!Schutz durch den Liebhaber"
			,"`!You miss Seth!.`0"=>"`!Du vermisst Seth.`0"
			,"Your lover inspires you to keep safe!"=>"Die Gedanken an deinen Liebhaber lassen dich an deine Sicherheit denken!"
			,"`!You miss `5Violet`!.`0"=>"`!Du vermisst `5Violet`!.`0"
		)
		,array(
			"`6Transmutation Sickness"=>"`6Transmutationsprobleme"
			,"You stop puking your guts up.  Literally."=>"Du h�rst auf deine D�rme auszukotzen. Im wahrsten Sinne des Wortes."
			,"Bits of skin and bone reshape themselves like wax."=>"Teile deiner Haut und deiner Knochen verformen sich wie Wachs."
			,"`6Due to the effects of the Transmutation Potion, you still feel `2ill`6."=>"`6Durch die Auswirkungen des Transmutationstranks f�hlst du dich immer noch `2krank`6."
		)
		,array(
			"`#Buzz"=>"`#Rausch"
			,"Your buzz fades."=>"Dein Rausch l�sst nach."
			,"You've got a nice buzz going."=>"Du hast nen ordentlichen Rausch am laufen."
		)
		,"`\$`c`b~ ~ ~ Fight ~ ~ ~`b`c`0"=>"`\$`c`b~ ~ ~ Kampf ~ ~ ~`b`c`0"
		,array(
			"You have encountered `^"=>"Du hast den Gegner `^"
			,"`@ which lunges at you with `%"=>"`@ entdeckt, der sich mit seiner Waffe `%"
			,"`@!`0`n`n"=>"`@ auf dich st�rzt!`0`n`n"
		)
		,"`2Level: `6Undead`0`n"=>"`2Level: `6Untoter`0`n"
		,"`2`bStart of round:`b`n"=>"`2`bBeginn der Runde:`b`n"
		,"`2`bEnd of Round:`b`n"=>"`2`bEnde der Runde:`b`n"
		,"`&The gods have suspended any special effects!`n"=>"`&Die G�tter verbieten den Einsatz jeder Spezialf�higkeit!`n"
		,"'s bodyguard protects them!`n`n"=>" ist durch einen Leibw�chter gesch�tzt!`n`n"
		,"The bodyguard seems to have fallen asleep."=>"Der Leibw�chter scheint eingeschlafen zu sein."
		,"`\$'s skill allows them to get the first round of attack!`0`b`n`n"=>"`\$'s F�higkeiten erlauben deinem Gegner den ersten Schlag!`0`b`n`n"
		,"`\$ surprises you and gets the first round of attack!`0`b`n`n"=>"`\$ �berrascht dich und hat den ersten Schlag!`0`b`n`n"
		,"`b`\$Your skill allows you to get the first attack!`0`b`n`n"=>"`b`\$Dein K�nnen erlaubt dir den ersten Angriff!`0`b`n`n"
		,array(
			"`7`bYou execute a minor power move!`b`0`n"=>"`7`bDu holst zu einem kleinen Powerschlag aus!`b`0`n"
			,"`&`bYou execute a power move!!!`b`0`n"=>"`&`bDu holst zu einem Powerschlag aus!!!`b`0`n"
			,"`&`bYou execute a DOUBLE power move!!!`b`n"=>"`&`bDu holst zu einem DOPPELTEN Powerschlag aus!!!`b`n"
			,"`&`bYou execute a "=>"`&`bDu holst zu einem "
			," power move!!!`b`n"=>" Powerschlag aus!!!`b`n"
		)
		,"`4You are too busy trying to run away like a cowardly dog to try to fight `^"=>"`4Du bist zu besch�ftigt damit wegzulaufen wie ein feiger Hund und kannst nicht k�mpfen gegen `^"
		,"`&The gods have restored your special effects.`n`n"=>"`&Die G�tter gew�hren dir wieder alle deine speziellen F�higkeiten.`n`n"
		,array(
			"You regenerate for "=>"Du regenerierst um "
			,"You are healed for "=>"Du wirst geheilt um "
			,"A huge fist of earth pummels "=>"Eine gewaltige Faust aus Erde trifft "
			," recoils as lightning arcs out from your skin, hitting for `^"=>" wird von einem Blitzbogen aus deiner Haut zur�ckgeworfen und bekommt `^"
			,"`)An undead minion tries to hit "=>"`)Ein Untoter Diener versucht "
			," but `\$MISSES`)!"=>" zu treffen, aber `\$TRIFFT NICHT`)!"
			,"`)An undead minion hits "=>"`)Ein Untoter Diener trifft "
			,"You thrust a pin into the "=>"Du st��t eine Nadel in die "
			," doll hurting it for `^"=>"-Puppe und machst damit `^"
			,"'s bodyguard hits you for `\$"=>"'s Leibw�chter trifft dich mit `\$"
			,"'s bodyguard tries to it you but `\$MISSES`7!"=>"'s Leibw�chter schl�gt zu, aber `\$TRIFFt NICHT`7!"
			,"`4 tries to hit you but `\$MISSES!`n"=>"`4 versucht dich zu treffen, aber `\$TRIFFT NICHT!`n"
			,"`4 tries to hit you but you `^RIPOSTE`4 for `^"=>"`4 versucht dich zu treffen, aber dein `^GEGENSCHLAG`4 trifft mit `^"
			,"`4You try to hit "=>"`4Du versuchst "
			,"`4 but `\$MISS!`n"=>"`4 zu treffen, aber du `\$TRIFFST NICHT!`n"
			,"`4 but are `\$RIPOSTED `4for "=>"`4 zu treffen, aber sein `\$GEGENSCHLAG`4 trifft dich mit "
			,"Soulpoints"=>"Seelenpunkte"
			,"Hitpoints"=>"Lebenspunkte"
			,"`4 points of damage!`n"=>"`4 Schadenspunkten!`n"
			,"`) points!"=>"`) Schadenspunkte!"
			,"`) damage."=>"`) Schadenspunkte."
			,"`7 damage."=>"`7 Schadenspunkten."
			,"`4You hit `^"=>"`4Du triffst `^"
			,"`4 hits you for `\$"=>"`4 trifft dich mit `\$"
			,"`2YOUR "=>"`2DEINE "
			," for `^"=>" mit `^"
			,"`) points."=>"`) Punkten."
			," health."=>" Gesundheitspunkte"
		)
		,"Special Abilities"=>"Spezielle F�higkeiten"
		,array(
			"Dark Arts"=>"Dunkle K�nste"
			,"Skeleton Crew"=>"Skelette herbeirufen"
			,"Curse Spirit"=>"Geist verfluchen"
			,"Wither Soul"=>"Seele verdorren"
			,"Thieving Skills"=>"Diebesk�nste:"
			,"Insult"=>"Beleidigen"
			,"Poison Blade"=>"Waffe vergiften"
			,"Hidden Attack"=>"Versteckter Angriff"
			,"Backstab"=>"Angriff von hinten"
			,"Mystical Powers"=>"Mystische Kr�fte"
			,"Earth Fist"=>"Erdenfaust"
			,"Siphon Life"=>"Leben absaugen"
			,"Lightning Aura"=>"Blitzaura"
		)
		,"Fight"=>"K�mpfen!"
		,"Run"=>"Wegrennen"
		// end battle

		);
		break;
	case "forest.php":
		$replace = array(
		"Something Special"=>"Etwas Besonderes!"
		// Specials
		// alter 1/2
		,"`@You stumble accross a clearing.  You notice an altar with 5 sides sitting infront of you.  Each side contains a different Item.  You see `#A Dagger, `\$A Skull,`% A Jeweled Wand, `^An Abacus, `7and A Plain looking Book.  `@Sitting on top of the altar in the center is a `&Crystal Lightning Bolt.`n`n"=>"`@Du stolperst �ber eine Lichtung und bemerkst einen Altar mit 5 Seiten vor dir. Auf jeder Seite liegt ein anderer Gegenstand. Du siehst `#einen Dolch, `\$einen Sch�del,`% einen juwelenbesetzten Stab, `^ein Rechenbrett `7und ein schlicht aussehendes Buch. `@In der Mitte �ber dem Altar befindet sich ein `&Kristallblitz.`n`n"
		,"  `@You know that if you take the time to pick up one of the items,  it will cost you the time for one forest fight.`n`n`n"=>" `@Du wei�t, da� es dich Zeit f�r einen ganzen Waldkampf kosten wird, einen der Gegenst�nde n�her zu untersuchen.`n`n`n"
		,"Grab the Dagger"=>"Nimm den Dolch"
		,"Grab the Skull"=>"Nimm den Sch�del"
		,"Grab the Jeweled Wand"=>"Nimm den Stab"
		,"Grab the Abacus"=>"Nimm das Rechenbrett"
		,"Grab the Book"=>"Nimm das Buch"
		,"Grab the Crystal Lightning Bolt"=>"Nimm den Kristallblitz"
		,"Leave the Alter Undisturbed"=>"Verlasse den Altar unber�hrt"
		,array(
			"`#You grab the Dagger from its resting place.  The dagger vanishes, and you feel a surge of power enter your body!`n`n"=>"`#Du nimmst den Dolch von seinem Platz. Doch er l�st sich in deinen H�nden in Luft auf und du f�hlst eine Welle von Energie in deinen K�rper str�men!`n`n"
			,"`&You gain 10 uses of Theiving Skills`n`n`#But you are saddened as you know the power will vanish tommorow."=>"`&Du erh�ltst 10 zus�tzliche Anwendungen in Diebesk�nsten.`n`n`#Aber du bist auch etwas traurig, denn diese Kraft wird morgen wieder verschwunden sein."
			,"`&You gain 3 levels of Theiving Skills!"=>"`&Du erh�ltst 3 Level in Diebesk�nsten!"
		)
		,array(
			"`#You grab the Skull from its resting place.  The Skull vanishes, and you feel a surge of power enter your body!`n`n"=>"`#Du greifst nach dem Sch�del. Vor deinen Augen l�st sich der Sch�del auf und du f�hlst eine Energiewelle in deinen K�rper fahren!`n`n"
			,"`&You gain 10 uses of Dark Arts Skills`n`n`#But you are saddened as you know the power will vanish tommorow."=>"`&Du erh�ltst 10 zus�tzliche Anwendungen der Dunklen K�nste.`n`n`#Aber du bist auch etwas traurig, denn diese Kraft wird morgen wieder verschwunden sein."
			,"`&You gain 3 levels of Dark Art Skills!"=>"`&Du erh�ltst 3 Levels in Dunklen K�nsten!"
		)
		,array(
			"`#You grab the Wand from its resting place.  The Wand vanishes, and you feel a surge of power enter your body!`n`n"=>"`#Du hebst den Stab von seinem Platz auf. In einem Lichtblitz verschwindet er und eine seltsame Kraft durchstr�mt deinen K�rper!`n`n"
			,"`&You gain 10 uses of Magic Skills`n`n`#But you are saddened as you know the power will vanish tommorow."=>"`&Du erh�ltst 10 zus�tzliche Anwendungen in Mystischen Kr�ften.`n`n`#Aber du bist auch etwas traurig, denn diese Kraft wird morgen wieder verschwunden sein."
			,"`&You gain 3 levels of Magic Skills!"=>"`&Du erh�ltst 3 Levels in Mystischen Kr�ften!"
		)
		,"`@You decide not to temp fate and anger the gods.  You leave the alters alone."=>"`@Du beschlie�t, das Schicksal lieber nicht herauszufordern und dadurch wom�glich die G�tter zu ver�rgern. Du l��t den Altar in Ruhe."
		,"As you leave you stumble across a pouch containing 2 gems!  The gods must be smiling on you!"=>"Als du die Lichtung gerade verlassen willst, stolperst du �ber ein Beutelchen mit 2 Edelsteinen! Die G�tter m�ssen dir wohlgesonnen sein!"
		// audrey
		,array(
			"`5You stumble across a clearing that is oddly quiet.  To one side are three baskets, tightly lidded.  Finding this "=>"`5Du stolperst �ber eine Lichtung, die seltsam ruhig ist. Auf einer Seite stehen drei ordentlich verschlossene K�rbe. Du findest das "
			,"curious, you cautiously approach them when you hear the faint mew of a kitten.  You reach for the lid of the first basket"=>"merkw�rdig und n�herst dich den K�rben vorsichtig. Wie du n�her kommst, h�rst du ein schwaches Miauen. Du hast den Deckel des ersten "
			,"when out of no where, Crazy Audrey appears, ranting feverishly about colored kittens, and pulls the baskets to her.  Taken "=>"Korbes schon fast in der Hand, als die verr�ckte Audrey wie aus dem Nichts auftaucht und wie im Fieberwahn etwas von farbigen K�tzchen daherredet. Sie zieht die K�rbe zu sich heran. "
			,"somewhat aback, you decide you had best question her about these kittens.`n`n"=>"Etwas verbl�fft befragst du sie �ber diese K�tzchen.`n`n"
			,"\"`#Tell me, good woman,`5\" you begin...`n`n"=>"\"`#Sprich, gute Frau...`5\"`n`n"
			,"\"`%GOOD GOOD good good goodgoodgoodgoodgood...`5\" Audrey begins to repeat.  Unflustered, you persist.`n`n"=>"\"`%GUT GUT gut gut gutgutgutgutgut...`5\", wiederholt Audrey. Unbeeindruckt f�hrst du fort.`n`n"
			,"\"`#What are these kittens you speak of?`5\"`n`n"=>"\"`#Was sind das f�r Katzen, von denen du sprichst?`5\"`n`n"
			,"Amazingly, Crazy Audrey suddenly grows quiet and begins to speak in a regal accent both melodious and soft.`n`n"=>"Erstaunlicherweise wird die verr�ckte Audrey pl�tzlich ganz ruhig und spricht mit leichtem sowohl melodischen wie auch sanften Akzent.`n`n"
			,"\"`%Of these baskets, have I three,`n"=>"\"`%Von diesen K�rben habe ich drei.`n"
			,"Four kittens inside each there do be.`n`n"=>"Vier K�tzchen in jedem der drei.`n`n"
			,"Minds of their own, do they have,`n"=>"Ihren eigenen Willen sie alle wohl haben.`n"
			,"Should two alike emerge, you'll get this salve.`n`n"=>"Sollten zwei gleiche entkommen, du sollst diese Salbe haben.`n`n"
			,"Energy it gives, to fight your foes,`n"=>"Energie sie dir bringt gegen deine Feinde.`n"
			,"Merely rub it 'tween your toes.`n`n"=>"Wenn gleichm�ssig verteilte auf die Beine.`n`n" 
			,"Should no two alike show their head,`n"=>"Wenn keine zwei gleichen den Kopf raus strecken,`n"
			,"Earlier today, you'll see your bed.`n`n"=>"ich fr�her heute ins Bett dich werd stecken.`n`n"
			,"That then is my proposition,`n"=>"Das w�re mein Angebot,`n"
			,"Shall thou take it, or from me run?`5\"`n`n"=>"Nimmst du es an, oder fliehst du hinfort?`5\"`n`n"
			,"Will you play her game?"=>"Wirst du ihr Spiel mitspielen?"
		)
		,"Run away from Crazy Audrey"=>"Renne vor Audrey davon"
		,array(
			"`^C`&a`6l`7i`^c`7o"=>"`^G`&e`6s`7c`^h`7e`^c`&k`6t"
			,"`7T`&i`7g`&e`7r"=>"`7G`&e`7t`&i`7g`&e`7r`&`7t"
			,"`&White"=>"`&Weiss"
			,"`^`bHedgehog`b"=>"`^`bLanghaarig`b"
			,"`5Agreeing to Crazy Audrey's preposterous game, she thumps the first basket on the lid.  A "=>"`5Du stimmst einem Spiel mit der verr�ckten Audrey zu und sie klopft dem ersten Korb auf den ersten Deckel. Das K�tzchen ist "
			,"`5 kitten peeks its head out.`n`n"=>"`5.`n`n"
			,"Crazy Audrey then thumps the second basket on the lid, and a "=>"Die verr�ckte Audrey klopft auf den Deckel des zweiten Korbes. Das K�tzchen, das dort den Kopf herausstreckt,  ist "
			,"She thumps the third basket on the lid, and a "=>"Sie klopft auf den dritten Korb und ein "
			,"`5 kitten hops out and bounds up to Crazy Audrey's shoulder.`n`n"=>"`5es K�tzchen springt heraus und klettert Audrey auf die Schulter.`n`n"
		)
		,array(
			"\"`%Hedgehogs?  HEDGEHOGS??  Hahahahaha, HEDGEHOGS!!!!`5\" shouts Crazy Audrey as she snatches them up and runs screaming in to the"=>"\"`%Langhaarige? LANGHAARIGE?? Hahahaha, LANGHAARIGE!!!!`5\", schreit die verr�ckte Audrey, w�hrend sie alle einsammelt und schreiend in den Wald rennt."
			,"forest.  You notice that she has dropped a full BAG of those wonderful salves.`n`n`^You gain FIVE forest fights!"=>" Du bemerkst, dass sie eine ganze TASCHE dieser wunderbaren Salbe fallengelassen hat.`n`n`^Du erh�tst F�NF zus�tzliche Waldk�mpfe!"
		)
		,array(
			"\"`%Argh, you are ALL very bad kittens!`5\" shouts Crazy Audrey before hugging her shoulder kitten and putting it back in the"=>"\"`%Aaaah! Ihr seid ALLES sehr b�se K�tzchen!`5\", schreit die verr�ckte Audrey. Dann umarmt sie das K�tzchen auf ihrer Schulter und steckt es "
			,"basket.  \"`%Because my kittens all were alike, I grant you TWO salves.`5\"`n`nYou rub the salves on your toes.`n`n`^You gain TWO forest fights!"=>"zur�ck in den Korb. \"`%Weil es lauter gleiche K�tzchen waren, werde ich dir zwei Salben geben.`5\"`n`nDu verteilst die Salbe auf deinen Beinen.`n`n`^Du erh�ltst ZWEI Waldk�mpfe!"
		)
		,array(
			"\"`%Garr, you crazy kittens, what do you know?  Why I ought to paint you all different colors!`5\"  Despite her threatening"=>"\"`%Grrr, ihr verr�ckten Katzen, was denkt ihr euch? Ich sollte euch alle in verschiedenen Farben anmalen!`5\" Trotz ihrer Drohung"
			,"words, Crazy Audrey pets the kitten on her shoulder before placing it back in the basket, and giving you your salve, which you rub all"=>"streichelt Audrey das K�tzchen auf ihrer Schulter, bevor sie es in den Korb zur�ck steckt. Dann gibt sie dir deine Salbe, die du sofort auf die Beine schmierst."
			,"over your toes.`n`n`^You gain a forest fight!"=>"`n`n`^Du bekommst einen Waldkampf dazu!"
		)
		,array(
			"\"`%Well done my pretties!`5\" shouts Crazy Audrey.  Just then her shoulder-mounted kitten leaps at you.  In fending it off,"=>"\"`%Gut gemacht, meine H�bschen!`5\" schreit Audrey. In diesem Moment springt dich das K�tzchen von ihrer Schulter an. Beim Versuch, es abzuwehren, "
			,"you lose some energy.  Finally it hops back in its basket and all is quiet.  Crazy Audrey cackles quietly and looks at you."=>" verlierst du etwas Energie. Schlie�lich hopst es zur�ck ins K�rbchen und alles ist wieder still. Die verr�ckte Audrey schnattert leise vor sich hin und schaut dich dabei an."
		)
		,"`n`n`^You lose a forest fight!"=>"`n`n`^Du verlierst einen Waldkampf"
		,"`5You run, very quickly, away from this mad woman."=>"`5Du rennst sehr schnell vor dieser durchgedrehten Frau davon."
		//distress
		,"`n`3While searching through the forest, you find a man lying face down in the dirt. "=>"`n`3Bei der Suche im Wald findest du ein Mann mit dem Gesicht nach unten im Schmutz liegen. "
 		,"The Arrow in his back, the pool of blood, and the lack of movement are a good "=>"Der Pfeil in seinem R�cken, der See an Blut und das Fehlen jeder Bewegung sind gute Anzeichen daf�r: "
 		,"indication this man is dead.`n`n"=>"Dieser Mann ist tot.`n`n"
    		,"`3While searching his body, you find a a crumpled piece of paper, tightly clenched within his fist. "=>"`3Du durchsucht die Leiche und findest ein zerkn�lltes St�ck Papier in seiner geschlossenen Faust. "
 		,"You carefully free the paper and realize it is a note, hastily written by the look of it.  "=>"Vorsichtig befreist du das Papier aus seiner Hand und erkennst, dass es eine hastig niedergeschriebene Notiz ist. "
		,"The note reads:`n`n"=>"Auf dem Papier steht geschrieben:`n`n"
    		,"`3\"`7Help! I have been imprisoned by my horrid old Uncle. He plans to force me to marry.  "=>"`3\"`7Hilfe! Ich wurde von meinem gemeinem alten Onkel eingesperrt. Er will mich zur Hochzeit zwingen. !"
 		,"Please save me! I am being held at ...`3\"`n`n"=>"Bitte rette mich! Ich werde gefangen gehalten in ... `3\"`n`n"
		,"`3The rest of the note is either too bloody or too badly damaged to read.`n`n"=>"`3Der Rest der Notiz ist entweder zu stark mit Blut beschmiert, oder zu stark besch�digt, um mehr zu erkennen.`n`n"
		,"`3Outraged you cry \"`7I must save him!`3\" But where will you go?`n`n"=>"`3Emp�rt schreist du: \"`7Ich muss ihn retten!`3\" Aber wo willst du suchen?`n`n"
		,"`3Outraged you cry \"`7I must save her!`3\" But where will you go?`n`n"=>"`3Emp�rt schreist du: \"`7Ich muss sie retten!`3\" Aber wo willst du suchen?`n`n"
		,"`3You crumple the note up and toss it into the trees.  You're not afraid, she's just not worth your time. "=>"`3Du kn�llst die Notiz zusammen und wirfst sie in den Wald.  Du hast keine Angst, es ist dir nur die Zeit zu Schade daf�r.  "
 		,"Nope, not afraid at all, no way.  You turn your back on the poor distressed man's pitiful cry for "=>"Nop, �berhaupt keine Angst, kein bisschen. Du wendest dem erb�rmlichnen Hilferuf des armen Mannes "
 		,"Nope, not afraid at all, no way.  You turn your back on the poor distressed maiden's pitiful cry for "=>"Nop, �berhaupt keine Angst, kein bisschen. Du wendest dem erb�rmlichnen Hilferuf der armen Jungfrau "
		,"help, and set off through the trees to find something a little less danger- ...er, a little more challenging."=>"den R�cken zu und machst dich auf, im Wald etwas weniger gef�hrl... �h, etwas gr��ere Herausforderungen zu finden."
		,"`3Finally you open what looks like a likely door and spy a well furnished chamber. `n`n"=>"`3Schlie�lich offnest du etwas, das wie eine T�r aussieht und entdeckst eine gut eingerichtete Kammer.`n`n"
		,"The chamber holds a young, handsome, and grateful occupant.`n`n"=>"Die Kammer enth�lt einen jungen, attraktiven und dankbaren Bewohner.`n`n"
		,"The chamber holds a young, beautiful, and grateful occupant.`n`n"=>"Die Kammer enth�lt eine junge, h�bsche und dankbare Bewohnerin.`n`n"
		,"\"`#Oh, you came!`3\" he says. \"`#Heroine, how can I ever thank you?`3\"`n`n"=>"\"`#Du bist gekommen!`3\", sagt er, \"`#Meine Heldin, wie kann ich dir jemals danken?`3\"`n`n"
		,"\"`#Oh, you came!`3\" she beams. \"`#Hero, how can I ever thank you?`3\"`n`n"=>"\"`#Du bist gekommen!`3\", strahlt sie, \"`#Mein Held, wie kann ich dir jemals danken?`3\"`n`n"
  		,"After a few hours in each others arms, you leave the princes side "=>"Nach einigen Stunden der Umarmung verl�sst du den Prinzen "
  		,"After a few hours in each others arms, you leave the princess' side "=>"Nach einigen Stunden der Umarmung verl�sst du die Prinzessin "
		,"and go on your way, but not without a small token of his appreciation.`n`n"=>"und gehst wieder deinen eigenen Weg. Allerdings nicht ohne ein kleines Zeichen seiner Wertsch�tzung.`n`n"
		,"and go on your way, but not without a small token of her appreciation.`n`n"=>"und gehst wieder deinen eigenen Weg. Allerdings nicht ohne ein kleines Zeichen ihrer Anerkennung!`n`n"
		,"He gives you a small leather bag.`n`n"=>"Er gab dir einen kleinen Lederbeutel.`n`n"
		,"She gives you a small leather bag.`n`n"=>"Sie gab dir einen kleinen Lederbeutel.`n`n"
		,"He showed you things you never dreamed of.`n`n"=>"Er hat dir Dinge gezeigt, von denen du nichtmal zu tr�umen gewagt hast.`n`n"
		,"She showed you things you never dreamed of.`n`n"=>"Sie hat dir Dinge gezeigt, von denen du nichtmal zu tr�umen gewagt hast.`n`n"
		,"`^You gain experience!"=>"`^Deine Erfahrung steigt!"
		,"He taught you how to be a real woman.`n`n"=>"Er hat dir beigebracht, wie eine richtige Frau zu sein.`n`n"
		,"She taught you how to be a real man.`n`n"=>"Sie hat dir beigebracht, wie ein richtiger Mann zu sein.`n`n"
		,"`^You gain two charm points!"=>"`^Du erh�ltst zwei Charmpunkte!"
		,"He gives you a carriage ride back to the forest, alone...`n`n"=>"Er gibt dir eine Fahrt mit der Kutsche zur�ck ins Dorf, alleine...`n`n"
		,"She gives you a carriage ride back to the forest, alone...`n`n"=>"Sie gibt dir eine Fahrt mit der Kutsche zur�ck ins Dorf, alleine...`n`n"
		,"`^You gain a forest fight, and are completely healed!"=>"`^Du bekommst einen Waldkampf und bist vollst�ndig geheilt!"
   		,"The chamber holds a large chest, muffled cries for help come from inside.  You throw the chest open "=>"Die Kammer enth�lt eine grosse Truhe, aus der ged�mpfte Hilferufe kommen. Du reisst die Truhe auf  "
		,"and strike a heroic pose, then you see the chests occupant.  Out from the chest leaps a monstrous, "=>"und wirfst dich in Heldenpose. Dann siehst du den Bewohner der Truhe. "
		,"and lonely, troll!!  After a few hours of... excitement,"=>"Ein monstr�ser und einsamer Troll steigt daraus empor!! Nach einigen Stunden des ... Vergn�gens "
		,"and lonely, trolless!!  After a few hours of... excitement,"=>"Eine monstr�se und einsame Trolldame steigt daraus empor!! Nach einigen Stunden des Vergn�gens "
		,"he lets you go on your way.  You feel more than a little dirty.`n`n"=>" l�sst er dich ziehen. Du f�hlst dich mehr als ein bisschen schmutzig.`n`n"
		,"she lets you go on your way.  You feel more than a little dirty.`n`n"=>"l�sst sie dich ziehen. Du f�hlst dich mehr als ein bisschen schmutzig.`n`n"
		,"The chamber holds a wrinkled old man!  You gasp in horror "=>"In der Kammer steht ein runzeliger alter Mann! Du schnappst vor Abscheu vor diesem f�rchterlichen Ding nach Luft "
		,"The chamber holds a wrinkled old hag!  You gasp in horror "=>"In der Kammer steht ein runzeliges altes Weib! Du schnappst vor Abscheu vor diesem f�rchterlichen Ding nach Luft "
		,"at the hideous thing before you, and run screaming from the room.  Somehow, you think something "=>"vor dir, bevor laut schreiend davon rennst. Irgendwie hast du das Gef�hl, "
		,"rubbed off on you.`n`n"=>"irgendetwas hat dich ausgenutzt.`n`n"
		,"You dash into the room, and sitting at the window is a a rediculous-looking effeminate fop.  "=>"Du st�rzt in den Raum. Am Fenster sitzt ein l�cherlich aussehender unm�nnlicher Trottel.  "
		,"\"`5Oh, you came!`3\" he cries, jumping to his feet.  As he starts toward you, he trips over his "=>"\"`5Du bist gekommen!`3\", heult er. Er springt auf die Beine und rennt dir entgegen, stolpert dabei aber �ber seinen "
		,"bedpan and gets tangled in his clothes.  You take this opportunity to slip away as quickly and "=>"Nachttopf und verf�ngt sich in seinen Kleidern. Du nutzt diese Gelegenheit und machst dich so schnell und leise wie "
		,"quietly as possible.  Luckily, nothing was injured but your pride.`n`n"=>"m�glich aus dem Staub. Gl�cklicherweise hat ausser deinem Stolz sonst nichts Schaden genommen.`n`n"
		,"`%You lose a forest fight!`n"=>"`%Du verlierst einen Waldkampf!`n"
 		,"`%You lose a charm point!`n"=>"`%Du verlierst einen Charmepunkt!`n"
		,"`3A fierce fight ensues, and you put forth a valiant effort!  Unfortunately you are hopelessly "=>"`3Eine heisse SChlacht entbrennt un du bringst einiges an M�he auf! Ungl�cklicherweise bist du hoffnungslos "
		,"outnumbered, you try to run, but soon fall beneath the blades of your enemies. `n`n"=>"in Unterzahl. Du versuchst wegzurennen, f�llst aber sehr bald zwischen den Klingen deiner Feinde.`n`n"
		,"outnumbered, finally you see your chance and break free.  The last thing the denizens of "=>"in Unterzahl. Schlie�lich siehst du doch eine Chance zu Flucht und brichst aus. Das letzte, was die Einwohner von "
		,"see is your backside, fleeing into the forest.`n`n"=>" von dir sehen, ist dein R�cken. Du fliehst in den Wald.`n`n"
		,"`%You lose most of your hitpoints!`n"=>"`%Du verlierst die meisten deiner Lebenspunkte!`n"
      		,"You dash inside, and find a surprised nobleman and his wife, just sitting down to dinner.`n`n"=>"Du st�rmst hinein und findest einen �berraschten Edelmann und seine Frau friedlich beim Essen vor.`n`n"
		,"\"`^What is the meaning of this?`3\" he demands.  You try to explain how you ended up in the "=>"`3Er fordert eine Erkl�rung: \"`^Was bedeutet das?`3\" Du versuchst ihm zu erkl�ren, wie es dazu kam und "
		,"wrong place, but he doesn't seem to pay any attention.  The authorities are called, and you "=>"dass du den falschen Ort erwischt hast. Aber er scheint an Erkl�rungen kein Interesse zu haben! Die Beh�rden werden gerufen und "
		,"are fined for damages.`n`n"=>"du mu�t f�r alle entstandenen Sch�den aufkommen!`n`n"
		,"`%You lose all the gold you were carrying!`n"=>"`%Du verlierst alles Gold, das du dabei hattest!`n"
		,"`%You have died!`n`n"=>"`%Du bist gestorben!`n`n"
		,array(
			"Go to"=>"Gehe zu"	// troublemaker?
			,"Wyvern Keep"=>"Lindwurmfestung"
			,"Castle Slaag"=>"Burg Slaag"
			,"Draco's Dungeon"=>"Draco's Kerker"
			,"`n`3You storm through the doors of "=>"`n`3Du st�rmst durch die Tore von "
			,"`3slaying the guards and anybody else who gets in your way. "=>"`3und metzelst die Wachen und alles nieder, was dir in die Quere kommt. "
		)
		,"It's not worth my time"=>"Das ist reine Zeitverschwendung"
		,"Ignore it"=>"Ignoriere es"
		//goldmine
		,"`2You found an old abandoned mine in the depths of the forest. There is some old mining equipment nearby.`n`n"=>"`2In den tiefen des Waldes hast du eine alte verlassene Mine gefunden. Es liegt sogar noch Goldgr�berausr�stung in der N�he herum.`n`n"
		,"`^As you look around you realize that this is going to be a lot of work.  So much so in fact that you will lose a forest fight for the day if you attempt it.`n`n"=>"`^Als du dich etwas umsiehst, bemerkst du, dass das hier eine Menge Arbeit w�re. So viel, dass du auf jeden Fall einen Waldkampf verlieren wirst, wenn du dein Gl�ck versuchen willst.`n`n"
		,"`^Looking around a bit more, you do notice what looks like evidence of occasional cave-ins in the mine.`n`n"=>"`^Ausserdem stellst du fest, dass durchaus die Gefahr von gegelgentlichen Einst�rzen in der Mine besteht.`n`n"
		,"Mine for gold and gems"=>"Nach Gold und Edelsteinen suchen" 
		,"`2Nope you don't have time for this slow way to gain gold and gems so you leave the old mine...`n"=>"`2Nop, f�r so einen langsamen Weg an Gold und Edelsteine zu kommen hast du keine Zeit. Also verl�sst du die alte Mine...`n"
		,"`2You are too tired to mine anymore..`n"=>"`2Du bist zu m�de um weiter zu buddeln...`n"
		,array(
			"`&Seeing that the mine entrace is too small for your "=>"`&Du siehst, dass der Eingang zu Mine zu klein f�r dein "
			,"`&, you tether it off to the side of the entrance.`n"=>"`& ist und du bindest das Tier am Eingang der Seite fest.`n"
		)
		,"`2You pick up the mining equipment and start mining for gold and gems..`n`n"=>"`2Du hebst die Ausr�stung auf und f�ngst an nach Gold und Edelsteinen zu graben...`n`n"
		,"`2After a few hours of hard work you have only found worthless stones and one skull..`n`n"=>"`2Nach einigen Stunden harter Arbeit hast du nur ein paar wertlose Steine und einen Sch�del gefunden.`n`n"
		,"`^You lose one forest fight while digging.`n`n"=>"`^Beim Graben verlierst du einen Waldkampf.`n`n"
		,array(
			"`^After a few hours of hard work, you find "=>"`^Nach einigen Stunden harter Arbeit findest du "
			,"gems and "=>"Edelsteine und "
		)
		,"`^You have found the mother lode!`n`n"=>"`^Du hast die Hauptader entdeckt!`n`n"
		,"`2After a lot of hard work you believe you have spotted a `&huge`2 gem and some `6gold`2.`n"=>"`2Nach einer Menge harter Arbeit glaubst du, einen `&riesigen`2 Edelstein und etwas `6Gold`2 gesehen zu haben.`n"
		,"`2Anxious to be rich, you rear back and slam the pick home, knowing that the harder you hit, the quicker you will be done....`n"=>"`2Begierig auf Reichtum lehnst du dich zur�ck und schmetterst mit der  Spitzhacke darauf ein. `2Denn je fester du zuschl�gst, umso schneller wird es erledigt sein...`n"
		,"`7Unfortunatly, you are quickly done in.`n"=>"`7Ungl�cklicherweise bist `bdu`b erledigt.`n"
		,"Your over-exuberant hit caused a massive cave in.`n"=>"Dein �bereifriges Schlagen verursacht einen schweren H�hleneinsturz.`n"
		,"You have been crushed under a ton of rock.`n`nPerhaps the next adventurer will recover your body and bury it properly.`n"=>"Du wurdest unter einer Tonne Felsen zerquetscht.`n`nVielleicht wird der n�chste Abenteurer deine Knochen bergen und ordentlich begraben.`n"
		,array(
			"Fortunately you left your "=>"Zum Gl�ck hast du dein(e/n) "
			," tethered outside.  You know that it is trained to return to the village.`n"=>" draussen angebunden. Du weisst, dass das Tier darauf trainiert ist, zum Dorf zur�ckzukehren.`n"
		)
		,"At least you learned something about mining from this experience and have gained "=>"Wenigstens hast du dabei etwas �ber Bergbau gelernt. Du bekommst "
		,"`3You may continue to play tommorrow`n"=>"`3Du kannst morgen weiterspielen`n"
		,"Fortunately your dwarven skill let you escape unscathed.`n"=>"Gl�cklicherweise lassen dich deine Zwergenf�higkeiten unverletzt entkommen.`n"
		,"Through sheer luck you manage to escape the cave-in intact!`n"=>"Durch pures Gl�ck kannst du der Mine unverletzt entkommen!`n"
		,"Your close call scared you so badly that you cannot face any more opponents today.`n"=>"Dein knappes Entkommen vor dem Tod hat dich so erschreckt, dass du heute keinen weiteren Gegner mehr zur Strecken bringen wirst."
		//fairy
		,"`%You encounter a fairy in the forest.  \"`^Give me a gem!`%\" she demands.  What do you do?"=>"`%Du begegnest einer Fee. \"`^Gib mir einen Edelstein!`%\", verlangt sie. Was tust du?"
		,"`%You give the fairy one of your hard-earned gems.  She looks at it, squeals with delight, "=>"`%Du gibst der Fee einen deiner schwer verdienten Edelsteine. Sie schaut ihn an, quickt vor Entz�ckung und "
		,"and promises a gift in return.  She hovers over your head, sprinkles golden fairy dust down "=>"verspricht dir als Gegenleistung ein Geschenk. Sie schwebt dir �ber den Kopf und streut goldenen Feenstaub auf  "
		,"on you before flitting away.  You discover that ...`n`n`^"=>"dich herab, bevor sie davon huscht. Du stellst fest.... `n`n`^"
		,"You receive an extra forest fight!"=>"Du bekommst einen zus�tzlichen Waldkampf!"
		,"You feel perceptive and notice `%TWO`^ gems nearby!"=>"Du f�hlst deine Sinne gesch�rft und bemerkst `%ZWEI`^ Edelsteine in der N�he."
		,"Your maximum hitpoints are `bpermanently`b increased by 1!"=>"Deine maximalen Lebenspunkte sind `bpermanent`b um 1 erh�ht!"
		,"`%You promise to give the fairy a gem, however, when you open your purse, you discover that "=>"`%Du versprichst der Fee einen Edelstein, aber als du dein Golds�ckchen �ffnest, entdeckst du, "
		,"you have none.  The tiny fairy floats before you, tapping her foot on the air as you try "=>"da� du gar keinen Edelstein hast. Die kleine Fee schwebt vor dir, die Arme in die H�fte gestemmt und mit dem Fu� in der Luft klopfend, "
		,"to explain why it is that you lied to her."=>"w�hrend du ihr zu erkl�ren versuchst, warum du sie angelogen hast."
		,"`n`nHaving had enough of your mumblings, she sprinkles some angry red fairy dust on you.  "=>"`n`nAls sie genug von deinem Gestammel hat, streut sie �rgerlich etwas roten Feenstaub auf dich.  "
		,"Your vision blacks out, and when you wake again, you cannot tell where you are.  You spend "=>"Du wirst ohnm�chtig und als du wieder zu dir kommst, hast du keine Ahnung, wo du bist. Du brauchst "
		,"enough time searching for the way back to the village that you lose time for a forest fight."=>"so viel Zeit, um den Weg zur�ck ins Dorf zu finden, da� du einen ganzen Waldkampf verlierst."
		,"`%Not wanting to part with one of your precious precious gems, you swat the tiny creature to the "=>"`%Du willst dich nicht von einem deiner kostbaren Edelsteine trennen und schmetterst das kleine Gesch�pf im "
		,"ground and walk away."=>"Vorbeigehen auf den Boden."
		,"Give her a gem"=>"Gib ihr einen Edelstein"
		,"Don't give her a gem"=>"Gib ihr keinen Edelstein"
		//findgem and findgold
		,"`^Fortune smiles on you and you find a gem!"=>"`^Das Gl�ck l�chelt dich an. Du findest einen Edelstein!"
		,"`^Fortune smiles on you and you find "=>"`^Das Gl�ck l�chelt dich an. Du findest "
		//glowingstream
		,"`#You discover a small stream of faintly glowing water that babbles over round pure white stones.  You can sense a magical "=>"`#Du entdeckst einen schmalen Strom schwach gl�henden Wassers, das �ber runde, glatte, wei�e Steine blubbert. Du kannst eine magische "
		,"power in the water.  Drinking this water may yield untold powers, or it may result "=>"Kraft in diesem Wasser f�hlen. Es zu trinken, k�nnte ungeahnte Kr�fte in dir freisetzen - oder es k�nnte "
		,"in crippling disability.  Do you wish to take a drink?"=>"dich zum v�lligen Kr�ppel machen. Wagst du es, von dem Wasser zu trinken?"
		,"`#Knowing that the water could yield deadly, you decide to take your chances.  Kneeling down "=>"Im Wissen, da� dieses Wasser dich auch umbringen k�nnte, willst du trotzdem die Chance wahrnehmen. Du kniest dich am Rand des Stroms nieder "
		,"at the edge of the stream, you take a long hard draught from the cold stream.  You feel a warmth "=>"und nimmst einen langen, kr�ftigen Schluck von diesem kalten Wasser. Du f�hlst W�rme "
		,"growing out from your chest, "=>"von deiner Brust heraufziehen, "
	  	,"`#Fearing the dreadful power in the water, you decide to let it be, and return to the forest."=>"`#Weil du die verh�ngnisvollen Kr�fte in diesem Wasser f�rchtest, entschlie�t du dich, es nicht zu trinken und gehst zur�ck in den Wald."
		,"`ifollowed by a dreadful clammy cold`i.  You stagger and claw at your breast as you feel what "=>"`igefolgt von einer bedrohlichen, beklemmenden K�lte`i. Du taumelst und greifst dir an die Brust. Du f�hlst das, was "
		,"you imagine to be the hand of the reaper placing its unbreakable grip on your heart."=>"du dir als die Hand des Sensenmanns vorstellst, der seinen gnadenlosen Griff um dein Herz legt."
		,"`n`nYou collapse by the edge of the stream, only just now noticing that the stones you observed "=>"`n`nDu brichst am Rande des Stroms zusammen. Dabei erkennst du erst jetzt gerade noch, da� die Steine, die dir aufgefallen sind, "
		,"before were actually the bleached skulls of other adventurers as unfortunate as you."=>"die blanken Sch�del anderer Abenteurer sind, die genauso viel Pech hatten wie du."
		,"`n`nDarkness creeps in around the edges of your vision as you lay staring up through "=>"`n`nDunkelheit umf�ngt dich, w�hrend du da liegst und in die B�ume starrst.  "
		,"the trees.  Your breath comes shallower and less and less frequently "=>"Dein Atem wird d�nner und immer unregelm��iger. "
		,"as warm sunshine splashes on your face, in sharp contrast to the void taking residence in "=>"Warmer Sonnenschein strahlt dir ins Gesicht, als scharfer Kontrast zu der Leere, die von deinem "
		,"your heart."=>"Herzen Besitz ergreift."
		,"`n`n`^You have died to the foul power of the stream.`n"=>"`n`n`^Du bist an den dunklen Kr�ften des Stroms gestorben.`n"
		,"As the woodland creatures know the danger of this place, none are here to scavenge from your corpse, you may keep your gold.`n"=>"Da die Waldkreaturen die Gefahr dieses Platzes kennen, meiden sie ihn und deinen K�rper als Nahrungsquelle. Du beh�ltst dein Gold.`n"
		,"The life lesson learned here balances any experience you would have lost.`n"=>"Die Lektion, die du heute gelernt hast, gleicht jeden Erfahrungsverlust aus.`n"
		,"You may continue playing again tomorrow."=>"Du kannst morgen wieder k�mpfen."
		,"As you exhale your last breath, you distantly hear a tiny giggle.  You find the strength "=>"Als du deinen letzten Atem aushauchst, h�rst du ein entferntes leises Kichern. Du findest die Kraft, "
		,"to open your eyes, and find yourself staring at a tiny fairy who, flying just above your face "=>"die Augen zu �ffnen und siehst eine kleine Fee �ber deinem Gesicht schweben, die "
		,"is inadvertantly sprinkling its fairy dust all over you, granting you the power to crawl once "=>"unachtsam ihren Feenstaub �berall �ber dich verstreut. Dieser gibt dir genug Kraft, dich wieder "
		,"again to your feet.  The lurch to your feet startles the tiny creature, and before you have a "=>"aufzurappeln. Dein abruptes Aufstehen erschreckt die Fee, und noch bevor du die M�glichkeit hast, "
		,"chance to thank it, it flits off."=>"ihr zu danken, fliegt sie davon."
		,"`n`n`^You narrowly avoid death, you lose a forest fight, and most of your hitpoints."=>"`n`n`^Du bist dem Tod knapp entkommen! Du hast einen Waldkampf und die meisten deiner Lebenspunkte verloren."
		,"you feel INVIGORATED!"=>"du f�hlst dich GEST�RKT!"
		,"`n`n`^Your hitpoints have been restored to full, and you feel the energy for another turn in the forest."=>"`n`n`^Deine Lebenspunkte wurden aufgef�llt und du sp�rst die Kraft f�r einen weiteren Waldkampf."
		,"you feel PERCEPTIVE!  You notice something glittering under one of the pebbles that line the stream."=>"du f�hlst deine SINNE GESCH�RFT! Du bemerkst unter den Kieselsteinen am Bach etwas glitzern."
		,"`n`n`^You find a GEM!"=>"`n`n`^Du findest einen EDELSTEIN!"
		,"you feel ENERGETIC!"=>"du f�hlst dich VOLLER ENERGIE!"
		,"`n`n`^You receive an extra forest fight!"=>"`n`n`^Du bekommst einen zus�tzlichen Waldkampf!"
		,"you feel HEALTHY!"=>"du f�hlst dich GESUND!"
		,"`n`n`^Your hitpoints have been restored to full."=>"`n`n`^Deine Lebenspunkte wurden vollst�ndig aufgef�llt."
		// grassyfield
		,"`n`c`#You Stumble Upon a Grassy Field`c"=>"`n`c`#Du stolperst �ber eine grasbewachsene Lichtung.`c"
		,"Nothing to see here, move along."=>"Hier gibt's nichts zu sehen."
                	,array(
			"`n`n`&You allow your "=>"`n`n`&Du erlaubst deinem "
			," to frolic and gambol in the field."=>", sich hier zu st�rken und herumzutollen."
			," to hunt and rest in the field."=>" zu jagen und sich auszuruhen."
		)
		,"You lose a forest fight for today."=>"Du verlierst einen Waldkampf f�r heute."
		,"`n`^Your nap leaves you completely healed!"=>"`n`^Dein Nickerchen hat dich vollst�ndig geheilt!"
		,"`n`n`^Your break leaves you completely healed!"=>"`n`n`^Du regenerierst vollst�ndig!"
   		,"`n`n`&Deciding to take a moment and a load off your poor weary feet you take a quick break from your ventures to take in the beautiful surroundings."=>"`n`n`&Du beschlie�t, dir einen Moment Zeit zu nehmen und deinen armen F��en eine kurze Pause von deinen riskanten Abenteuern zu g�nnen. Du genie�t die wundersch�ne Umgebung."
		,"`n`n`&You relax a while in the fields enjoying the sun and the shade."=>"`n`n`&Du ruhst dich eine Weile hier aus und genie�t die Sonne und den Schatten."
		,"`n`n`@Talk with the others lounging here.`n"=>"`n`n`@Rede mit den anderen, die hier herumlungern:`n"
		//oldmanpretty & oldmanugly
		,"`^An old man whacks you with a pretty stick, giggles and runs away!`n`nYou `%receive one`^ charm!"=>"`^Ein alter Mann schl�gt dich mit einem sch�nen Stock, kichert und rennt davon!`n`nDu `%bekommst einen`^ Charmepunkt!"
		,"`^An old man hits you with an ugly stick, and gasps as his stick `%loses one`^ charm!  You're even uglier than his ugly stick!"=>"`^Ein alter Mann trifft dich mit einem h�sslichen Stock und schnappt nach Luft, als der Stock `%einen Charmepunkt verliert`^.  Du bist noch h�sslicher als dieser h�ssliche Stock!!"
		,"`^An old man whacks you with an ugly stick, giggles and runs away!`n`nYou `%lose one`^ charm!"=>"`^Ein alter Mann schl�gt dich mit einem h�sslichen Stock, kichert und rennt davon!`n`nDu `%verlierst einen`^ Charmepunkt!"
		// oldmantown
		,"`@You encounter a strange old man!`n`n\"`#I am lost,`@\" he says, \"`#can you lead me back to town?`@\"`n`n"=>"`@Du begegnest einem merkw�rdigen alten Mann!`n`n\"`#Ich hab mich verlaufen.`@\", sagt er, \"`#Kannst du mich ins Dorf zur�ckbringen?`@\"`n`n"
		,"You know that if you do, you will lose time for a forest fight for today, will you help out this poor old man?"=>"Du wei�t, da� du einen Waldkampf f�r heute verlieren wirst, wenn du diesen alten Mann ins Dorf bringst. Wirst du ihm helfen?"
		,"Walk him to town"=>"F�hre ihn ins Dorf"
		,"Leave him here"=>"Lass ihn stehen"
		,"`@You take the time to lead the old man back to town.`n`n In exchange he whacks you with his pretty stick, and you receive `%one charm point`@!"=>"`@Du nimmst dir die Zeit, ihn zur�ck ins Dorf zu geleiten.`n`nAls Gegenleistung schl�gt er dich mit seinem h�bschen Stock und du erh�ltst `%einen Charmepunkt`@!"
		,"`@You take the time to lead the old man back to town.`n`n In exchange he gives you `%a gem`@!"=>"`@Du nimmst dir die Zeit, ihn zur�ck ins Dorf zu geleiten.`n`nAls Dankesch�n gibt er dir `%einen Edelstein`@!"
		,"`@You tell the old man that you are far too busy to aid him.`n`nNot a big deal, he should be able to find his way back "=>"Du erkl�rst dem Opa, da� du viel zu besch�ftigt bist, um ihm zu helfen.`n`nKeine gro�e Sache, er sollte in der Lage sein, den Weg zur�ck "
		,"to town on his own, he made his way out here, didn't he?  A wolf bays in the distance to your left, and a few seconds later "=>"ins Dorf selbst zu finden. Immerhin hat er es ja auch vom Dorf hierher geschafft, oder? Ein Wolf heult links von dir in der Ferne und wenige Sekunden sp�ter "
		,"one bays somewhere closer to your right.  Yep, he should be fine."=>"antwortet ein anderer Wolf viel n�her von rechts. Jup, der Mann sollte in Sicherheit sein."
		// riddles
		,"`6`nA short little gnome with leaves in his hair squats beside a small tree.  He smirks, giggling behind one of his fatty hands."=>"`6`nEin kurzer kleiner Gnom mit Bl�ttern in den Haaren hockt neben einem kleinen Baum. Er grinst und kichert hinter einer seiner fettigen H�nde. "
		,"For a moment, it looks like he might scramble off into the trees, but after a moment smirks and looks at you.`n`n"=>"F�r einen Moment sieht es so aus, als ob er in den Wald wegkrabbeln will, aber dann grinst er dich an.`n`n"
		,"`6\"`@I'll give you a boon,`6\" he says, \"`@if you can think and answer my riddle!`6\"`n`n"=>"`6\"`@Ich werde dir einen Gefallen tun,`6\" sagt er, \"`@wenn du mein R�tsel l�sen kannst!`6\"`n`n"
		,"`6He loses himself momentarily in a fit of giggling, then contains his excitement for a moment and continues.`n`n"=>"`6Vor�bergehend verf�llt er in unkontrolliertes Kichern, fasst sich wieder f�r einen Moment und f�hrt fort.`n`n"
		,"`6\"`@But if ere long your guess is wrong, then my boon it will be!`6\"`n"=>"`6\"`@Aber wenn du falsch liegen solltest, mein Gefallen es wird sein!`6\"`n"
		,"`6`nDo you accept his challenge?`n`n"=>"`6`nNimmst du die Herausforderung an?`n`n"
		,"`6Giggling with glee, he asks his riddle:`n`n"=>"`6Vor Freude kichernd stellt er sein R�tsel:`n`n"
		,"`6What is your guess?"=>"`6Was meinst du? "
		,"`n`6\"`@Lizards and polywogs!!`6\" he blusters, \"`@You got it!`6\"`n"=>"`n`6\"`@Eidechsen und Kaulquappen!! Du hast es!`6\", tobt er, `n"
		,"`6\"`@Oh very well.  Here's your stupid prize.`6\"`n`n"=>"`6\"`@Oh na gut. Hier hast du deinen d�mlichen Preis.`6\"`n`n" 
	 	,"`^He gives you a gem!"=>"`^Er gibt dir einen Edelstein!"
		,"`^He gives you two gems!"=>"Er gibt dir zwei Edelsteine!"
		,"He does the hokey pokey, and turns himself around.  After that display, you feel ready for battle!"=>"Er macht ein Hokus Pokus und dreht sich um. Nach diesem Schauspiel f�hlst du dich bereit f�r den Kampf!"
		,"`n`n`^You gain a forest fight!"=>"`n`n`^Du erh�ltst einen zus�tzlichen Waldkampf!"
		,"He looks deep in your eyes, then whacks you hard across the side of your head.  "=>"Er schaut dir tief in die Augen, dann zieht er dir kr�ftig eins �ber die R�be."
		,"When you come to, you feel a little bit smarter.`n`#"=>"Als du wieder zu dir kommst, f�hlst du dich ein klein wenig geschickter.`n`#"
		,"That was a fun lesson."=>"Das war eine Lektion in Spa�."
		,"`n`n`^You gain some experience!"=>"`n`n`^Du erh�ltst ein paar Erfahrungspunkte!"
		,"`n`6The strange gnome cackles with glee and dances around you.  You feel very silly standing there with a crazy gnome prancing around like a fairy,"=>"`n`6Der merkw�rdige Gnom gackert vor Freude und tanzt um dich herum. Du f�hlst dich ziemlich albern dabei, als dieser verr�ckte Gnom um dich herum t�nzelt wie eine Fee, "
		,"`6so you quietly make your exit while he's distracted.  Somehow you feel like less of a hero with his mocking laughter echoing in your ears, "=>" deswegen machst du dich leise aus dem Staub, solange der Gnom abgelenkt ist. Irgendwie f�hlst du dich jetzt weniger als ein Held - mit diesem sp�ttischen Gel�chter in den Ohren. "
		,"it's not until much later that you also notice some of your gold is missing."=>"Nicht viel sp�ter stellst du fest, dass dir auch etwas Gold fehlt..."
		,"`n`n`^You lost some gold!"=>"`n`n`^Du hast Gold verloren!"
		,"you don't think you can face another opponent right away."=>"Du glaubst nicht, dass du sofort wieder einem Gegner gegen�ber treten kannst."
		,"`n`n`^You lose a charm point!"=>"`n`n`^Du verlierst einen Charmepunkt!"
		,"`n`6Afraid to look the fool, you decline his challenge.  He was a little bit creepy anyway."=>"`n`6Du f�rchtest dich l�cherlich zu machen und lehnst seine Herausforderung ab. Er war sowieso etwas gruselig. "
		,"`n`6The strange gnome giggles histerically as he disappears into the forest."=>"`n`6Der merkw�rdige Gnom kichert hysterisch und verschwindet im Wald."
		,"what would Seth think?"=>"Was w�rde Seth blo� dar�ber denken?"
		,"what would Violet think?"=>"Was w�rde Violet blo� dar�ber denken?"
		// skillmaster
		,"You have no direction in the world, you should rest and make some important decisions about your life."=>"Du wanderst plan- und ziellos durchs Leben. Du solltest eine Rast machen und einige wichtige Entscheidungen f�r dein weiteres Leben treffen."
		,array(
			"You give `@Foil`&wench"=>"Du gibst `@Foil`&wench"
			,"a gem, and she hands you a slip of parchment with instructions on how to advance in your specialty.`n`n"=>"einen Edelstein und sie �berreicht dir einen Zettel aus Pergament mit Anweisungen, wie du deine Fertigkeiten steigern kannst.`n`n"
		)
		,array(
			"You study it intensely, shred it up, and eat it lest infidels get ahold of the information.`n`n`@Foil`&wench"=>"Du studierst den Zettel, zerreisst ihn und futterst ihn auf, damit Ungl�ubige nicht an die Information gelangen k�nnen. `n`n`@Foil`&wench"
			," sighs... \"`&You didn't"=>" seufzt... \"`&Du h�ttest ihn nicht "
			,"have to eat it...  Oh well, now be gone from here!"=>"zu essen brauchen... Naja, jetzt verschwinde von hier! "
			,"You hand over your imaginary gem.  `@Foil`&wench"=>"Du �berreichst deinen imagin�ren Edelstein. `@Foil`&wench"
			," stares blankly back at you.  \"`&Come back when you have a `breal`b gem you simpleton."=>" starrt dich verdutzt an. \"`&Komm wieder, wenn du einen `bechten`b Edelstein hast, du Dummkopf"
			,"\"`#Simpleton?"=>"\"`#Dummkopf?"
			,"\" you ask.`n`n"=>"\"`n`n"
			,"With that, `@Foil`&wench"=>"Damit schmeisst `@Foil`&wench"
			," throws you out."=>" dich endg�ltig raus."
		)
		,array(
			"You inform `@Foil`&wench"=>"Du informierst `@Foil`&wench"
			," that if she would like to get rich, she will have to do so on her efforts, and stomp away."=>" dar�ber, dass sie sich ihren Reichtum selbst verdienen sollte. Dann stampfst du davon."
		)
		,array(
			"You are seeking prey in the forest when you stumble across a strange hut.  Ducking inside, you are met by the grizzled face of a battle-hardened"=>"Auf deinen Streifz�gen durch den Wald auf Jagd nach Beute st�sst du auf eine kleine H�tte. Du gehst hinein und wirst vom grauen Gesicht einer kampferprobten alten Frau empfangen: "
			,"\"`&Yes, master of all.  All the skills are mine to control, and to teach."=>"\"`&Ja, Meister in Allem. Es liegt in meiner Macht, alle F�higkeiten zu kontrollieren und zu lehren. "
			,"old woman.  \"`&Greetings "=>"\"`&Sei gegr�sst "
			,", I am `@Foil`&wench"=>", ich bin `@Foil`&wench"
			,", master of all."=>", Meister in allem."
			,"\"`n`n\"`#Master of all?"=>"\"`n`n\"`#Meister in allem?"
			,"\" you inquire.`n`n"=>"\", fragst du nach.`n`n"
			,"\"`n`n\"`#Yours to teach?"=>"\"`n`n\"`#Und zu lehren?"
			,"\" you query.`n`n"=>"\", fragst du sie.`n`n"
			,"The old woman sighs, \"`&Yes, mine to teach.  I will teach you how to advance in "=>"Die alte Frau seufzt: \"`&Ja, und zu lehren.  Ich werde dir zeigen, wie du deine "
			," on two conditions."=>" steigern kannst - unter zwei Bedingungen."
			,"\"`#Two conditions?"=>"\"`#Zwei Bedingungen?"
			,"\" you repeat inquisitively.`n`n"=>"\", wiederholst du fragend.`n`n"
			,"\"`&Yes.  First, you must give me a gem, and second you must stop repeating what I say in the form of a question!"=>"\"`&Ja. Zuerst musst du mir einen Edelstein geben und dann musst du aufh�ren, alles was ich sage als Frage zu wiederholen!"
			,"\"`#A gem!"=>"\"`#Ein Edelstein!"
			,"\" you state definitively.`n`n"=>"\" sagst du bestimmt.`n`n"
			,"\"`&Well... I guess that wasn't a question.  So how about that gem?"=>"\"`&Nun ... ich glaube das war keine Frage. Und wie sieht es mit dem Edelstein aus?"
		)
		//darkhorse and oldmanbet
		,"A cluster of trees nearby looks familiar... You're sure you've seen this place before.  "=>"Eine Baumgruppe in der N�he kommt dir bekannt vor... Du bist dir sicher, diesen Platz schoneinmal gesehen zu haben.  "
		,"As you approach the grove, a strange mist creeps in around you; your mind begins to buzz, "=>"Als du n�her kommst, steigt ein seltsamer Nebel auf. Dein Ged�chtnis spielt dir Streiche "
		,"and you're no longer sure exactly how you got here"=>"und du bist dir pl�tzlich gar nicht mehr sicher, wie du hier her gekommen bist."
		,", but your horse seems to have known the way"=>" Aber dein Pferd scheint den Weg zu kennen"
		,".`n`nThe mist clears, and before you is "=>".`n`nDer Nebel verschwindet und vor dir siehst du "
		,"a log building with smoke trailing from its chimney.  A sign over the door says `7\"Dark Horse Tavern.\"`0"=>"eine Holzh�tte, bei der Rauch aus dem Kamin aufsteigt. Auf einem Schild �ber der T�r steht: \"`7Dark Horse Taverne`0\"."
		,"Enter the tavern"=>"Betrete die Taverne"
		,"Leave this place"=>"Verlasse diesen Ort"
		,"You stand near the entrance of the tavern and survey the scene before you.  Whereas most taverns "=>"Du stehst in der N�he des Eingangs und beobachtest das Geschehen vor dir. W�hrend es in den meisten Tavernen "
		,"are noisy and raucous, this one is quiet, and nearly empty.  In the corner, an old man plays with "=>"laut und rauh zugeht, ist diese hier erstaunlich ruhig und fast leer. In einer Ecke spielt ein alter Mann mit "
		,"some dice.  You notice that the tables have been etched on by previous adventurers who have found "=>"einigen W�rfeln. Du bemerkst, da� Abenteurern, die diesen Platz gefunden haben, Botschaften in die Tische "
		,"this place before, and behind the bar, a stick of an old man hobbles around, polishing glasses, "=>"geritzt haben. Hinter der Theke humpelt ein alter Mann herum und poliert Gl�ser - "
		,"as though there were anyone here to use them."=>"obwohl niemand hier zu sein scheint, der sie benutzen w�rde."
		,"Talk to the old man"=>"Rede mit dem alten Mann"
		,"Talk to the bartender"=>"Rede mit dem Barkeeper"
		,"Examine the tables"=>"Untersuche die Tische"
		,"Exit the tavern"=>"Verlasse die Taverne"
		,"You examine the etchings in the table:`n`n"=>"Du untersuchst die Schnitzereien in den Tischen:`n`n"
		,"Add your own etching:"=>"Ritze etwas in die Tische:"
		,"Return to the tavern"=>"Zur�ck zur Taverne"
		,"The grizzled old man behind the bar reminds you very much of a strip of beef jerkey.`n`n"=>"Der runzelige alte Mann an der Bar erinnert dich stark an eine Scheibe Rindfleisch.`n`n"
		,array(
			"\"`7Shay, what can I do for you "=>"\"`7Schag, wasch kann ich f�r dich tun, "
			,"lasshie"=>"M�dchen"
			,"shon"=>"mein Schohn"
			,"?`0\" inquires the toothless "=>"?`0\" spricht der zahnlose Artgenosse. "
		)
		,"fellow.  \"`7Don't shee the likesh of your short too offen 'round theshe partsh.`0\""=>"\"`7Schehe die W�nsche deineschgleichen nicht alltschuoft hier.`0\""
		,"Learn about my enemies"=>"Etwas �ber die Feinde lernen"
		,"Learn about colors"=>"Farbenlehre"
		,"The old man leans on the bar.  \"`%Sho you want to know about colorsh, do you?`0\" he asks."=>"Der alte Mann st�tzt sich auf die Theke. \"`%Scho, du willscht alscho wasch �ber Farben wischen?`0\""
		,"  You are about to answer when you realize the question was posed in the rhetoric.  "=>"  Du willst gerade antworten, als du gerade noch merkst, da� das eine rhetorische Frage war.  "
		,"He continues, \"`%To do colorsh, here'sh what you need to do.  Firsht, you ushe a &#0096; mark "=>"Er f�hrt fort: \"`%Um farbig tschu sprechen, mache folgendesch. Zuerscht benutsche das &#0096; Tscheichen "
		,"(found right above the tab key) followed by 1, 2, 3, 4, 5, 6, 7, !, @, #, $, %, ^, &.  Each of thoshe correshpondsh with "=>" (Shift und die Taste links neben Backspace), gefolgt von 1, 2, 3, 4, 5, 6, 7, !, @, #, $, %, ^ oder &. Jedesch diescher Tscheichen entspricht "
		,"a color to look like this: `n`1&#0096;1 `2&#0096;2 `3&#0096;3 `4&#0096;4 `5&#0096;5 `6&#0096;6 `7&#0096;7 "=>"einer Farbe, die folgendermaschenen ausschschieht: `n`1&#0096;1 `2&#0096;2 `3&#0096;3 `4&#0096;4 `5&#0096;5 `6&#0096;6 `7&#0096;7 "
		,"`% got it?`0\"  You can practice below:"=>"`% kapiert?`0\" Hier kannst du testen: "
		,"`0`n`nThese colors can be used in your name, and in any conversations you have."=>"`0`n`nDu kannst diese Farben in jedem Text verwenden, den du eingibst."
		,"You entered "=>"Deine Eingabe: "
		,"It looks like "=>"Sieht so aus: "
		,"Search Again"=>"Neue Suche"
		,"\"`7Sho, you want to learn about your enemiesh, do you?  Who do you want to know about?  Well?  Shpeak up!  It only costs `^100`7 gold per person for information.`0\""=>"\"`7Scho, du willscht alscho etwasch �ber deine Feinde erfahren, ja? �ber wen willscht du wasch wischen? Nun? Schag schon! Esch koschtet nur `^100`7 Gold pro Information �ber eine Perschon.`0\""
		,"`n`n\"`7Hey, whatsh you think yoush doin'.  That'sh too many namesh to shay.  I'll jusht tell you 'bout shome of them.`0`n"=>"`n`n\"`7Hey, wasch glaubscht du tuscht du hier? Dasch schind tschu viele Namen. Ich werd dir nur �ber ein paar davon wasch ertsch�hlen.`0`n"
		,array(
			"\"`7Well... letsh shee what I know about "=>"\"`7Nun ... mal schehen wasch ich �ber "
			,"`0\" he says...`n`n"=>" allesch weisch...`0\"`n`n"
			,"cheapshkates like you,"=>"Geitschkragen wie dich"
		)
		,"\"`7Eh..?  I don't know anyone named that.`0\""=>"\"`7H�? Ich kenne niemenden mit dieschem Namen.`0\""
		,"`4`bName:`b`6 Get some money`n"=>"`4`bName:`b`6 Ohnemo Snixlos`n"
		,"`4`bLevel:`b`6 You're too broke`n"=>"`4`bLevel:`b`6 Ganz unten`n"
		,"`4`bHitpoints:`b`6 Probably more than you`n"=>"`4`bLebenspunkte:`b`6 M�glicherweische mehr alsch du`n"
		,"`4`bGold:`b`6 Definately richer than you`n"=>"`4`bGold:`b`6 Gantsch schicher mehr alsch du`n"
		,"`4`bWeapon:`b`6 Something good enough to lay the smackdown on you`n"=>"`4`bWaffe:`b`6 Etwasch, dasch gut genug ischt, dich ungespitscht in den Boden tschu rammen`n"
		,"`4`bArmor:`b`6 Probably something more fashionable than you`n"=>"`4`bR�stung:`b`6 Kleidschamer alsch deine`n"
		,"`4`bAttack:`b`6 Eleventy billion`n"=>"`4`bAngriffswert:`b`6 Dr�lf Milliarden`n"
		,"The old man looks up at you, his eyes sunken and hollow.  His red eyes make it seem that he may have been crying recently "=>"Der alte Mann schaut mit tiefliegenden und hohlen Augen zu dir auf. Seine roten Augen lassen darauf schlieesen, dass er erst k�rzlich geweint hat, "
		,"so you ask him what is bothering him.  \"`7Aah, I met an adventurer in the woods, and figured I'd play a little game "=>"deswegen fragst du ihn, was geschehen ist. \"`7Ach, Ich hab nen Abenteurer im Wald getroffen und hab gedacht ich spiel n kleines Spiel "
		,"with her, but she won, and took "=>"mit ihr, aber sie hat immer gewonnen und mir fast "
		,"with him, but he won, and took"=>"mit ihm, aber er hat immer gewonnen und mir fast "
		,"almost all of my money."=>"mein ganzen Gold aus der Tasche gezogen."
		,"`n`n`0\"`7Say... why not do an old man a favor and let me try to win some of it back from you?  I can play several "=>"`n`nSag, w�rdest du einem alten Mann den Gefallen tun und ihn versuchen lassen, etwas von den Gold von dir zur�ckzugewinnen? Ich kenne mehrere "
		,"games!`0\""=>"Spiele!`0\""
		,"Play Dice Game"=>"W�rfelspiel"
		,"Play Stones Game"=>"Steinchenspiel"
		,"`3The old man explains his game, \"`7I have a bag with 6 red stones, and 10 blue stones in it.  You can choose between 'like pair' or 'unlike pair.'  I will"=>"`3Der alte Mann erkl�rt sein Spiel: \"`7Ich habe einen Beutel mit 6 roten und 10 blauen Steinen darin. Du kannst zwischen 'gleiches Paar' und 'ungleiches Paar' w�hlen. Ich werde"
		,"then draw out pairs of stones two at a time.  If they are the same color as each other, they go to which ever of us is 'like pair,'"=>" dann jedesmal 2 Steine ziehen. Wenn sie die selbe Farbe haben, bekommt der die Steine, der 'gleiches Paar' getippt hat, "
		,"and otherwise they go to which ever of us is 'unlike pair.'  Whoever has the most stones at the end will win.  If we have the same number,"=>" ansonsten bekommt sie der von uns, der 'ungleiches Paar' getippt hat. Wer am ende die meisten Steine hat, gewinnt. Wenn wir Gleichstand haben,"
		,"then it is a draw, and no one wins.`3\""=>" gewinnt keiner von uns.`3\""
		,"`3\"`7Like pair for you, and unlike pair for me it is then!"=>"`3\"`7Gleiches Paar f�r dich, dann ist ein ungleiches Paar f�r mich."
		,"`3\"`7Unlike pair for you, and like pair for me it is then!"=>"`3\"`7Ungleiches Paar f�r dich, dann ist ein gleiches Paar f�r mich."
		,"How much do you bet?`3\""=>"Wieviel wettest du?`3\""
		,array(
			"`3The old man reaches in to his bag and withdraws two stones.  They are "=>"`3Der alte Mann greift in seinen Beutel und nimmt 2 Steine heraus. Sie sind "
			,"`\$red`3 and `!blue`3"=>"`\$rot`3 und `!blau`3"
			,"`\$red`3 and `\$red`3"=>"`\$rot`3 und `\$rot`3"
			,"`!blue`3 and `!blue`3"=>"`!blau`3 und `!blau`3"
			,"`!blue`3 and `\$red`3"=>"`!blau`3 und `\$rot`3"	// this is done to prevent a translation of the single word 'and'  
			,"Your bet is `^"=>"Deine Wette ist `^"
		)
		,array(
			"`n`nYou currently have `^"=>"`n`nDu hast momentan `^"
			,"`3 stones in your pile, and the old man has `^"=>"`3 Steine in deinem Haufen und der alte Mann hat `^"
			,"`3 stones."=>"`3 Steine."
			,"`n`nThere are "=>"`n`nEs sind noch "
			,"`\$red`3 stones and "=>"`\$ rote`3 und "
			,"`!blue`3 stones in the bag yet."=>"`! blaue`3 Steine im Beutel."
		)
		,"Since you are like pairs, "=>"Da du auf ein gleiches Paar getippt hast, "
		,"Since you are unlike pairs, "=>"Da du auf ein ungleiches Paar getippt hast, "
		,"the old man places the stones in your pile."=>"schiebt der alte Mann dir die Steine zu."
		,"the old man places the stones in his pile."=>"legt der alte Mann die Steine auf seine Seite."
		,"`3Having defeated the old man at his game, you claim your `^"=>"`3Du hast den alten Mann besiegt und verlangst deine `^"
		,"`3Having defeated you at his game, the old man claims your `^"=>"`3Der alte Mann hat dich besiegt und fordert nun seine `^"
		,"`3Having tied the old man, you call it a draw."=>"`3Ihr habt einen Gleichtand erreicht. Niemand gewinnt."
		,"Play again?"=>"Nochmal spielen?"
		,"Other Games"=>"Andere Spiele"
		,"Never Mind"=>"Vergiss es"
		,"Like Pair"=>"Gleiches Paar"
		,"Unlike Pair"=>"Ungleiches Paar"
		,"`3\"`!You have 6 tries to guess the number I am thinking of, from 1 to 100.  Each time I will tell you if you are too high or too low.`3\"`n`n"=>"`3\"`!Ich denke mir eine Zahl aus und du hast 6 Versuche, diese Zahl zwischen 1 und 100 zu erraten. Ich werde dir immer sagen, ob dein Versuch zu hoch oder zu niedrig war.`3\"`n`n"
		,"`3\"`!How much would you bet young man?`3\""=>"`3\"`!Wie hoch ist ein Einsatz, junger Mann?`3\""
		,"`3\"`!How much would you bet young lady?`3\""=>"`3\"`!Wie hoch ist dein Einsatz, junge Dame?`3\""
		,array(
			"`3The old man reaches out with his stick and pokes your coin purse.  \"`!I don't believe you have `^"=>"`3Der alte Mann streckt seinen Stock aus und klopft damit deinen Golsbeutel ab. \"`!Ich glaub nicht, da� da `^"
			,"`! gold!`3\" he declares.`n`n"=>"`! Gold drin ist!`3\", erkl�rt er.`n`n"
		)
		,"Desperate to really show him good, you open up your purse and spill out it's contents: `^"=>"Verzweifelt versuchst du ihm deinen guten Willen zu zeigen und kippst den Beutelinhalt auf den Tisch: `^"
		,"`n`nEmbarrased, you think you'll head back to the tavern."=>"`n`nVerlegen kehrst du zur Taverne zur�ck."
		,"`n`nEmbarrased, you think you'll head back in to the forest."=>"`n`nVerlegen kehrst du in den Wald zur�ck."
		,array(
			"`3\"`!INCREDIBLE!!!!`3\" the old man shouts, \"`!You guessed the number in only `^one try`!! Well, congratulations to you, and I am thoroughly impressed! It is almost as if you read my mind.`3\" He looks at you suspiciously and thinks about trying to make off with your winnings, but remembers your seemingly psychic abilities and hands over the `^"=>"`3\"`!UNGLAUBLICH`3\", schreit der alte Mann, \"`!Du hast meine Zahl mit nur `^einem Versuch`! erraten! Nun, ich gratuliere dir. Ich bin stark beeindruckt. Es ist gerade so, als ob du meine Gedanken lesen k�nntest.`3\" Er schaut dich misstrauisch eine Weile an und �berlegt, ob er sich mit deinem Gewinn einfach aus dem Staub machen soll, erinnert sich dann aber an deine scheinbaren geistigen Kr�fte und h�ndigt dir deine `^"
			,"`3 gold that he owes you."=>"`3 Gold aus."
			,"`3\"`!AAAH!!!!`3\" the old man shouts, \"`!You guessed the number in only "=>"`3\"`!AAAH!!!!`3\", schreit der alte Mann, \"`!Du hast die Zahl mit nur "
			," tries!  It was `^"=>" Versuchen erraten!  Es war `^"
			,"`!!!  Well, congratulations to you, "=>"`!!!  Nun, ich gratuliere dir "
		)
		,"`3The old man reaches out with his stick and pokes your coin purse.  \"`!Empty?!?!  How can you bet with no money??`3\" he shouts."=>"`3Der alte Mann streckt seinen Stock aus und klopft deinen Goldbeutel ab. \"`!Leer?!?! Wie kannst du etwas setzen ohne Gold??`3\", br�llt er."
		,array(
			"`3The old man chuckles.  \"`!The number was `^"=>"`3Der Mann gluckst vor Freude: \"`!Die Zahl war `^"
			,"`!,`3\" he says.  You, being the honorable citizen "=>"`!`3\" Als der ehrenwerte B�rger, der du bist, "
			,"that you are, give the man the `^"=>"gibst du dem Mann die `^"
			,"`3 gold that you owe him, ready to be away from here."=>"`3 Goldm�nzen, die du ihm schuldest, bereit, von hier zu verschwinden."
			,"`3 gold that you owe him, ready to be away from him."=>"`3 Goldm�nzen, die du ihm schuldest, bereit, ihn zu verlassen. "
		)			
		,array(
			" knocks him back in to his seat.  You help yourself to his coinpurse, retrieving the `^"=>" dr�ckst du ihn zur�ck auf seinen Stuhl. Du hilfst dem Mann dabei, dir die `^"
			,"I think I'll just be going now... `3\" he says as he heads for the door.  A swift blow from your "=>"und denke ich werde jetzt besser gehen... `3\" Er steht auf und will zur T�r gehen, doch mit einem sanften Schlag mit "
			,"I think I'll just be going now... `3\" he says as he heads for the underbrush.  A swift blow from your "=>"und denke ich werde jetzt besser gehen...`3\" Er will ins Unterholz verschwinden, doch mit einem flinken Schlag mit "
			," knocks him unconscious.  You help yourself to his coinpurse, retrieving the `^"=>" schl�gst du ihn KO. Du hilfst ihm dabei, dir die `^"
			,"`3 gold that he owes you."=>"`3 Goldm�nzen zu geben, die er dir schuldet."
		)
		,"  With that, he turns with a HARUMPH, and dissapears in to the underbrush."=>"  Damit dreht er sich mit einem HARUMF um und verschwindet im Unterholz."
		,"  With that, he turns back to his dice, apparently having already forgotten his anger."=>"  Damit wendet er sich wieder seinen W�rfeln zu. Seinen �rger hat er offensichtlich schon wieder vergessen."
		,"`3\"`!You get to roll a die, and choose to keep or pass on the roll.  If you pass, you get up to two more chances"=>"`3\"`!Du w�rfelst und w�hlst dann, ob du die Zahl behalten willst, oder ob du nochmal w�rfeln willst. Du hast insgesamt 3 Versuche. "
		," to roll, for a total of three rolls.  Once you keep your roll (or on the third roll), I will do the same.  "=>" Danach, oder nachdem du eine Zahl behalten hast, werde ich das selbe machen.  "
		,"In the end, if my die is higher than yours, I win, if yours is higher, you win, and if they are a tie, "=>"Wer am Ende die h�here Zahl gew�rfelt und behalten hat, gewinnt. Bei Gleichstand "
		,"neither of us wins, and we each keep our bet.`3\"`n`n"=>"gewinnt keiner von uns.`3\"`n`n"
		,"You roll your first die, and it comes up as `b"=>"Du w�rfelst deinen ersten Versuch und es erscheint die `b"
		,"You roll your second die, and it comes up as `b"=>"Du w�rfelst deinen zweiten Versuch und es erscheint die `b"
		,"You roll your third die, and it comes up as `b"=>"Du w�rfelst deinen dritten und letzten Versuch und es erscheint die `b"
		,array(
			"Your final roll was `b"=>"Dein letzter Wurf war eine `b"
			,"`b, the old man will now try to beat it:`n`n"=>"`b, der alte Mann wird jetzt versuchen, das zu �berbieten:`n`n"
			,"The old man rolls a "=>"Der alte Mann wirft eine "
			,"\"`7I think I'll stick with that roll!`0\" he says.`n"=>"\"`7Ich glaub ich behalte diesen Wurf!`0\"`n"
			,"The old man rolls again and gets a "=>"Der alte Mann w�rfelt nochmal und bekommt eine "
			,"The old man rolls his final roll and gets a "=>"Der alte Mann wirft seinen letzten Versuch und bekommt eine "
		)
		,"`n\"`7Yeehaw, I knew the likes of you would never stand up to the likes of me!`0\" exclaims the old man as you hand him your `^"=>"`n\"`7Juuhuu! Ich wusste, dass deinesgleichen niemals �ber meinesgleichen siegen kann!`0\", ruft der Mann, w�hrend du ihm gibst, was du ihm schuldest: `^"
		,"`n\"`7Yah... well, looks as though we tied.`0\" he says."=>"`n\"`7Tja... nun, sieht so aus, als ob wir ein Unentschieden h�tten.`0\""
		,"`n\"`7Aaarrgh!!!  How could the likes of you beat me?!?!?`0\" shouts the old man as he gives you the gold he owes."=>"`n\"`7Waaaaaah!! Wie konnte jemand wie du mich besiegen?!?!?`0\" schreit der alte Mann, w�hrend er dir gibt, was er dir schuldet." 
		,array(
			"`3\"`!Nope, not `^"=>"`3\"`!Nop, nicht `^"
			,"`!, it's lower than that!  That was try `^"=>"`!, meine Zahl ist kleiner als das!  Das war Versuch `^"
			,"`!, it's higher than that!  That was try `^"=>"`!, meine Zahl ist gr��er als das!  Das war Versuch `^"
			,"`3You have bet `^"=>"`3Du hast `3"
			,"`3.  What is your guess?"=>"`3 Gold gesetzt.  Was sch�tzt du?"
			,"`3.  What do you do?"=>"`3.  Was machst du?"
		)
		,"You duck out of the tavern, and wander in to the thick foliage around you.  That strange mist "=>"Du verl�sst die Taverne und l�ufst durch das dichte Blattwerk. Der seltsame Nebel "
		,"revisits you, making your mind buzz.  The mist clears, and you find yourself again in the forest "=>"ist wieder aufgezogen und verwirrt deine Sinne. Als du den Nebel verl��t, befindest du dich wieder im Wald an einer "
		,"that you are familiar with.  How exactly you got to the tavern is not exactly clear."=>"dir vertrauten Stelle. Aber wie genau du zu dieser Taverne gekommen bist, ist dir nicht klarer geworden."
		,"`3An old man stops you as you wander through the woods.  \"`!How would you like to play a little "=>"`3Ein alter Mann h�lt dich im Wald an und fragt dich: \"`!Wie w�rde es dir gefallen, ein kleines Ratespielchen "
		,"guessing game?`3\" he asks.  Knowing his sort, you know he will insist on a small wager if you do. "=>"mit mir zu spielen?`3\" Da du Leute wie ihn kennst, wei�t du, da� er auf einem kleinen Wetteinsatz bestehen wird, wenn du dich darauf einl�sst. "
		,"`3Afraid to part with your precious precious money, you decline the old man his game.  There wasn't "=>"`3Aus Furcht, dich von deinem teuren teuren Gold trennen zu m�ssen, lehnst du das Spiel des Alten ab. H�tte ja eh nicht viel Sinn gehabt, "
		,"much point to it anyhow, as you certainly would have won.  Yep, definately not afraid of the old man, nope."=>" weil du so oder so gewonnen h�ttest. Jep, h�tte definitiv keine Chance dieser alte Kerl, nop."
		// alter 2/2
		,array(
			"`#You grab the abacus from its resting place."=>"`#Du nimmst das Rechenbrett von seinem Platz."
			,"The abacus turns into a pouch filled with gold an gems!`n`n You gain "=>"Das Rechenbrett verwandelt sich in einen Beutel voller Gold und Edelsteine!`n`n Du bekommst "
 			,"The abacus turns into a sack filled with gold!`n`nYou gain "=>"Das Rechenbrett verwandelt sich in einen Beutel voller Gold! Du bekommst "
			," gold coins and "=>" Goldm�nzen und "
			," gold coins!"=>" Goldm�nzen!"
			," gems!"=>" Edelsteine!"		// CRITICAL! maybe this must be removed again.
 		)
		,array(
			"`#You grab the Crystal Lightning Bolt from its resting place."=>"`#Du greifst nach dem Kristallblitz."
			,"The Bolt vanishes from your hand and reappears back at the top of the alter.  After several tries at grabbing the Bolt, you decide not to waste any more time on it, fearfull of upsetting the gods"=>" Der Blitz verschwindet aus deinen H�nden und erscheint wieder auf dem Altar. Nach einigen Versuchen, den Blitz zu bekommen, hast du keine Lust mehr, noch mehr Zeit damit zu vergeuden. Du f�rchtest auch, die G�tter dadurch herauszufordern."
			,"Upon touching the bolt you are knocked backwards to the ground.  You get to your feet, and feel very powerfull!"=>"Als du den Blitz gerade ber�hrst, wirst du r�ckw�rts auf den Boden geschleudert. Du kommst schnell wieder auf die Beine und f�hlst dich sehr m�chtig!"
			,"`n`nYou gain 10 uses in each of the Skills!  You are sadden though, as you know this power will not last until morning."=>"`n`nDu bekommst 10 Anwendungen in allen Fertigkeiten! Leider sp�rst du, da� diese Macht nicht einmal bis zum n�chsten Morgen halten wird."
			,"`n`nYou gain 3 levels in Each Skill!"=>"`n`nDu steigst in jeder Fertigkeit 3 Level auf!"
			,"`n`nYou gain 10 Max HP!"=>"`n`nDu bekommst 10 zus�tzliche Lebenspunkte!"
			,"`n`nYou gain 2 Attack Points and 2 Defence Points!"=>"`n`nDu bekommst 2 Angriffspunkte und 2 Verteidigungspunkte dazu!"
			,"`#You reach for the Crystal Lightning Bolt when the skys suddenly boil over with clouds.  You fear you have angered the gods, and start to run, before you get clear of the area a bolt of lightning strikes you."=>"`#Deine Hand n�hert sich dem Kristallblitz, als der Himmel pl�tzlich vor Wolken �berkocht. Du f�rchtest, die G�tter ver�rgert zu haben und beginnst zu rennen. Doch noch bevor du die Lichtung verlassen kannst, wirst du von einem Blitz getroffen."
			,"`n`nYou Feel Dumber!  You loose "=>"`n`nDu f�hlst dich d�mmer!  Du verlierst "
			,"You loose 5% of your Experience and all gold on hand!"=>"Du verlierst 5% deiner Erfahrungspunkte und all dein Gold."
			,"You may continue to play tommorow."=>"Du kannst morgen wieder spielen."	// Can be removed when missspelling in source is corrected
			,"`n`nYou are dead!"=>"`n`nDu bist tot!"	// Can be removed when missspelling in sourceis corrected
			,"`n`nYou gain "=>"`n`nDu erh�ltst "
			," experience points!"=>" Erfahrungspunkte!"	// DANGER!
			,"`#You grab the book from its resting place and procede to read it.  The knowledge contiain in the book passes on to you.  You place the book back on the alter, hoping someone else will find it and make use of its knowledge.`n`n"=>"`#Du nimmst das Buch und beginnst darin zu lesen. Das Wissen in diesem Buch hilft dir viel weiter und du legst es an seinen Platz zur�ck, damit ein anderer auch noch davon profitieren kann."
			," experiance!"=>" Erfahrungspunkte!"	// thank god there is a misspelling in source :)
			," forest fights!"=>" Waldk�mpfe!"		// critical (causes troubles with sacrifice.php)
		)
		,"Return to the forest"=>"Zur�ck in den Wald"
		// end of specials
		,"You have successfully fled your oponent!"=>"Du bist erfolgreich vor deinem Gegner geflohen!"
		,"You failed to flee your oponent!"=>"Dir ist es nicht gelungen deinem Gegner zu entkommen!"
		,"Enter the cave"=>"Betrete die H�hle"
		,"Run away like a baby"=>"Renne weg wie ein Baby"
		,"You approach the blackened entrance of a cave deep in the forest, though"=>"Du betrittst den dunklen Eingang einer H�hle in den Tiefen des Waldes, "
		,"the trees are scorched to stumps for a hundred yards all around."=>"im Umkreis von mehreren hundert Metern sind die B�ume bis zu den St�mpfen niedergebrannt."
		,"A thin tendril of smoke escapes the roof of the cave's entrance, and is whisked away"=>"Rauchschwaden steigen an der Decke des H�hleneinganges empor und werden pl�tzlich"
		,"by a suddenly cold and brisk wind.  The mouth of the cave lies up a dozen"=>"von einer kalten Windb�e verweht.  Der Eingang der H�hle liegt an der Seite eines Felsens,"
		,"feet from the forest floor, set in the side of a cliff, with debris making a"=>"ein Dutzent Meter �ber dem Boden des Waldes, wobei Ger�ll eine kegelf�rmige"
		,"conical ramp to the opening.  Stalactites and stalagmites near the entrance"=>"Rampe zum Eingang bildet.  Stalaktiten und Stalagmiten nahe des Einganges"
		,"trigger your imagination to inspire thoughts that the opening is really"=>"erwecken in dir dein Eindruck, dass der H�hleneingang in Wirklichkeit "
		,"the mouth of a great leach."=>"das Maul einer riesigen Bestie ist."
		,"You cautiously approach the entrance of the cave, and as you do, you hear,"=>"Als du vorsichtig den Eingang der H�hle betrittst, h�rst - oder besser f�hlst du"
		,"or perhaps feel a deep rumble that lasts thirty seconds or so, before silencing"=>"ein lautes Rumpeln, das etwa drei�ig Sekunden andauert, bevor es wieder verstummt. "
		,"to a breeze of sulfur-air which wafts out of the cave.  The sound starts again, and stops"=>"Du bemerkst, dass dir ein Schwefelgeruch entgegenkommt.  Das Poltern ert�nt erneut, und h�rt wieder auf,"
		,"again in a regular rhythm."=>"in einem regelm��igen Rhythmus."
		,"You clamber up the debris pile leading to the mouth of the cave, your feet crunching"=>"Du kletterst den Ger�llhaufen rauf, der zum Eingang der H�hle f�hrt. Deine Schritte zerbrechen"
		,"on the apparent remains of previous heroes, or perhaps hors d'ouvers."=>"die scheinbaren �berreste ehemaliger Helden."
		,"Every instinct in your body wants to run, and run quickly, back to the warm inn, and"=>"Jeder Instinkt in deinem K�rper will fliehen und so schnell wie m�glich zur�ck ins warme Wirtshaus und "
		,array(
			"the even warmer Violet."=>"zur noch w�rmeren Violet."
			,"the even warmer Seth."=>"zum noch w�rmeren Seth."
			," What do you do?"=>" Was tust du?"
		)
		,"You are too tired to search the forest any longer today.  Perhaps tomorrow you will have more energy."=>"Du bist zu m�de um heute den Wald weiter zu durchsuchen. Vielleicht hast du morgen mehr Energie dazu."
		,"Aww, your administrator has decided you're not allowed to have any special events.  Complain to them, not me."=>"Arrr, dein Administrator hat entschieden, dass es dir nicht erlaubt ist, besondere Ereignisse zu haben.  Beschwer dich bei ihm, nicht bei mir."
		,"ERROR!!!`b`c`&Unable to open the special events!  Please notify the administrator!!"=>"ERROR!!!`b`c`&Es ist nicht m�glich die Speziellen Ereignisse zu �ffnen! Bitte benachrichtige den Administrator!!"
		,"You head for the section of forest you know to contain foes that you're a bit more comfortable with."=>"Du steuerst den Abschnitt des Waldes an, von dem du wei�t, dass sich dort Feinde aufhalten,  die dir ein bisschen angenehemer sind."
		,"You head for the section of forest which contains creatures of your nightmares, hoping to find one of them injured."=>"Du steuerst den Abschnitt des Waldes an, in dem sich Kreaturen deiner schlimmsten Alptr�ume aufhalten, in der Hoffnung dass Du eine findest die verletzt ist."
		,array(
			"`#You receive `^"=>"`#Du erbeutest `^"
			,"`# gold!`n"=>"`# Gold!`n"
		)
		,"`&You find A GEM!`n`#"=>"`&Du findest EINEN EDELSTEIN!`n`#"
		,array(
			"`b`c`&~~ Flawless Fight! ~~`\$`n`bYou receive an extra turn!`c`0`n"=>"`b`c`&~~ Perfekter Kampf! ~~`\$`n`bDu erh�ltst eine Extrarunde!`c`0`n"
			,"`b`c`&~~ Flawless Fight! ~~`b`\$`nA more difficult fight would have yielded an extra turn.`c`n`0"=>"`b`c`&~~ Perfekter Kampf! ~~`b`\$`nEin schwierigerer Kampf h�tte dir eine extra Runde gebracht !`c`n`0"
			,"You receive"=>"Du bekommst insgesamt"
			,"total experience!"=>"Erfahrungspunkte!"
			,"`#***Because of the simplistic nature of this fight, you are penalized `^"=>"`#*** Weil dieser Kampf so leicht war, verlierst du `^"
			,"`# experience! `n"=>"`# Erfahrungspunkte! `n"
			,"`#***Because of the difficult nature of this fight, you are awarded an additional `^"=>"`#*** Durch die hohe Schwierigkeit des Kampfes erh�ltst du zus�tzlich `^"
		)
		,"Daily news"=>"T�gliche News"
		// part from "common.php"
		,"The Forest, home to evil creatures and evil doers of all sorts."=>"Der Wald, Heimat von b�sartigen Kraturen und �blen �belt�tern aller Art.."
		,"The thick foliage of the forest restricts view to only a few yards in most places."=>"Die dichten Bl�tter des Waldes erlauben an den meisten Stellen nur wenige Meter Sicht."
		,"The paths would be imperceptible except for your trained eye.  You move as silently as"=>"Die Wege w�rden dir verborgen bleiben, h�ttest du nicht ein so gut geschultes Auge. Du bewegst dich so leise wie"
		,"a soft breeze across the thick mould covering the ground, wary to avoid stepping on"=>" eine milde Briese �ber den dicken Humus, der den Boden bedeckt. Dabei versuchst du es zu vermeiden, "
		,"a twig or any of numerous bleached pieces of bone that perforate the forest floor, lest"=>"auf d�nne Zweige oder irgendwelche der ausgebleichten Knochenst�cke zu treten, welche den Waldboden spicken. "
		,"you belie your presence to one of the vile beasts that wander the forest."=>"Du verbirgst deine Gegenwart vor den abscheulichen Monstern, die den Wald durchwandern."
		,"Golinda's Hut"=>"Golinda's H�tte"
		,"Healer's Hut"=>"H�tte des Heilers"
		,"Look for Something to kill"=>"Etwas zum Bek�mpfen suchen"
		,"Go Slumming"=>"Herumziehen"
		,"Go Thrillseeking"=>"Nervenkitzel suchen"
		,array(
			"Take "=>"Nimm "
			," to Dark Horse Tavern"=>" zur Dark Horse Taverne"
		)
		,"Return to the Village"=>"Zur�ck zum Dorf"
		,"Seek out the Green Dragon"=>"Suche den Gr�nen Drachen"
		,"Other"=>"Sonstiges"
		,"The Outhouse"=>"Plumpsklo"
		// end common
		,"The Forest"=>"Der Wald"
		,array(
			"You have slain"=>"Du erledigst "
			,"`b`&You have been slain by `%"=>"`b`&Du wurdest niedergemetzelt von `%"
			,"`4All gold on hand has been lost!`n"=>"`4Dein ganzes Gold wurde dir abgenommen!`n"
			,"% of experience has been lost!`n"=>"% deiner Erfahrung hast du verloren!`n"
			,"You may begin fighting again tomorrow."=>"Du kannst morgen weiter k�mpfen."
		)
		// battle (battle.php & common.php)
		,"You feel mortal again."=>"Du bist wieder sterblich."
		,"`n`&You feel godlike`n`n"=>"`n`&Du f�hlst dich gottgleich`n`n"
		,"`n`^You begin to regenerate!`n`n"=>"`n`^Du f�ngst an zu regenerieren!`n`n"
		,"You have stopped regenerating"=>"Deine Regeneration hat aufgeh�rt"
		,"You have no wounds to regenerate."=>"Du bist v�llig gesund."
		,"`% is clutched by a fist of earth and slammed to the ground!`n`n"=>"`% wird von einer Klaue aus Erde gepackt und auf den Boden geschleudert!`n`n"
		,"The earthen fist crumbles to dust."=>"Die erdene Faust zerf�llt zu staub."
		,"`n`^Your weapon glows with an unearthly presence.`n`n"=>"`n`n`^Deine Waffe gl�ht in einem �berirdischen Schein.`n`n"
		,"Your weapon's aura fades."=>"Die Aura deiner Waffe verschwindet."
		,"You feel a tingle as your weapon tries to heal your effectivly healthy body."=>"Du f�hlst ein Prickeln, als deine Waffe versucht, deinen vollst�ndig geheilten K�rper zu heilen."
		,"Your weapon wails as you deal no damage to your opponent."=>"Deine Waffe scheint zu jammern, als du deinem Gegner keinen Schaden machst."
		,"`n`^Your skin sparkles as you assume an aura of lightning`n`n"=>"`n`^Deine Haut glitzert, als du dir eine Aura aus Blitzen zulegst`n`n"
		,"With a fizzle, your skin returns to normal."=>"Mit einem Zischen wird deine Haut wieder normal."
		," is slightly singed by your lightning, but otherwise unharmed."=>" ist leicht geblendet von deinen Blitzen, ansonsten aber unverletzt."
		,array(
			"`nYou furrow your brow and call on the powers of the elements.  A tiny flame appears.  "=>"Du legst deine Stirn in Falten und beschw�rst die Elemente.  Eine kleine Flamme erscheint.  "
			," lights a cigarrette from it, giving you a word of thanks before swinging at you again."=>" z�ndet sich eine Zigarette daran an, dankt dir und st�rzt sich wieder auf dich. "
		)
		,array(
			"`n`\$You call on the spirits of the dead, and skeletal hands claw at "=>"`n`\$Du rufst die Geister der Toten und skelettartige H�nde zerren an "
			," from beyond the grave.`n`n"=>" aus den tiefen ihrer Gr�ber.`n`n"
		)
		,"Your skeleton minions crumble to dust."=>"Deine Skelettdiener zerbr�ckeln zu staub."
		,"`n`\$You pull out a tiny doll that looks like "=>"`n`\$Du holst eine winzige Puppe hervor, die aussieht wie "
		,array(
			"`n`\$You place a curse on "=>"`n`\$Du sprichst einen Fluch auf die Ahnen von "
			,"'s ancestors.`n`n"=>". `n`n"
		)
		,"Your curse has faded."=>"Dein Fluch ist gewichen."
		," staggers under the weight of your curse, and deals only half damage."=>" taumelt unter der Gewalt deines Fluchs und macht nur halben Schaden."
		,array(
			"`n`\$You hold out your hand and "=>"`n`\$Du streckst deine Hand aus und "
			," begins to bleed from its ears.`n`n"=>" f�ngt an aus den Ohren zu bluten.`n`n"
		)
		,"Your victim's soul has been restored."=>"Die Seele deines Opfers hat sich erholt."
		," claws at its eyes, trying to release its own soul, and cannot attack or defend."=>" kratzt sich beim Versuch, die eigene Seele zu befreien, fast die Augen aus und kann nicht angreifen oder sich verteidigen."
		,array(
			"`nExhausted, you try your darkest magic, a bad joke.  "=>"`nErsch�pft versuchst du deine dunkelste Magie: einen schlechten Witz.  "
			," looks at you for a minute, thinking, and finally gets the joke.  Laughing, it swings at you again.`n`n"=>" schaut dich nachdenklich eine Minute lang an. Endlich versteht er den Witz und st�rzt sich lachend wieder auf dich.`n`n"
		)
		,array(
			"`n`^You call "=>"`n`^Du gibst "
			," a bad name, making it cry.`n`n"=>" einen schlimmen Namen und bringst deinen Gegner zum Weinen.`n`n"
		)
		,"Your victim stops crying and wipes its nose."=>"Dein Gegner putzt sich die Nase und h�rt auf zu weinen."
		," feels dejected and cannot attack as well."=>" ist deprimiert und kann nicht so gut angreifen."
		,"`n`^You apply some poison to your "=>"`n`^Du reibst Gift auf dein(e/n) "
		,"Your victim's blood has washed the poison from your blade."=>"Das Blut deines Gegners hat das Gift von deiner Waffe gewaschen."
		,"Your attack is multiplied!"=>"Dein Angriffswert vervielfacht sich!"
		,array(
			"`n`^With the skill of an expert thief, you virtually dissapear, and attack "=>"`n`^Mit dem Geschick eines erfahrenen Diebs scheinst du zu verschwinden und kannst "
			," from a safer vantage point.`n`n"=>" aus einer g�nstigeren und sichereren Position angreifen.`n`n"
		)
		,"Your victim has located you."=>"Dein Opfer hat dich gefunden."
		,"cannot locate you."=>" kann dich nicht finden."
		,array(
			"`n`^Using your skills as a thief, dissapear behind "=>"`n`^Mit deinen F�higkeiten als Dieb verschwindest du und schiebst "
			," and slide a thin blade between its vertibrae!`n`n"=>" von hinten eine d�nne Klinge zwischen die R�ckenwirbel.`n`n "
		)
		,"Your victim won't be so likely to let you get behind it again!"=>"Dein Opfer ist nicht mehr so nett, dich hinter sich zu lassen!"
		,"Your attack is multiplied, as is your defense!"=>"Dein Angriffswert und deine Verteidigung vervielfachen sich!"
		,array(
			"`nYou try to attack "=>"`nDu versuchst, "
			," by putting your best thievery skills in to practice, but instead, you trip over your feet."=>" anzugreifen, indem du deine besten Diebesk�nste in die Praxis umsetzt - aber du stolperst �ber deine eigenen F�sse."
		)
		,array(
			"`!Lover's Protection"=>"`!Schutz durch den Liebhaber"
			,"`!You miss Seth!.`0"=>"`!Du vermisst Seth.`0"
			,"Your lover inspires you to keep safe!"=>"Die Gedanken an deinen Liebhaber lassen dich an deine Sicherheit denken!"
			,"`!You miss `5Violet`!.`0"=>"`!Du vermisst `5Violet`!.`0"
		)
		,array(
			"`6Transmutation Sickness"=>"`6Transmutationsprobleme"
			,"You stop puking your guts up.  Literally."=>"Du h�rst auf deine D�rme auszukotzen. Im wahrsten Sinne des Wortes."
			,"Bits of skin and bone reshape themselves like wax."=>"Teile deiner Haut und deiner Knochen verformen sich wie Wachs."
			,"`6Due to the effects of the Transmutation Potion, you still feel `2ill`6."=>"`6Durch die Auswirkungen des Transmutationstranks f�hlst du dich immer noch `2krank`6."
		)
		,array(
			"`#Buzz"=>"`#Rausch"
			,"Your buzz fades."=>"Dein Rausch l�sst nach."
			,"You've got a nice buzz going."=>"Du hast nen ordentlichen Rausch am laufen."
		)
		,"`\$`c`b~ ~ ~ Fight ~ ~ ~`b`c`0"=>"`\$`c`b~ ~ ~ Kampf ~ ~ ~`b`c`0"
		,array(
			"You have encountered `^"=>"Du hast den Gegner `^"
			,"`@ which lunges at you with `%"=>"`@ entdeckt, der sich mit seiner Waffe `%"
			,"`@!`0`n`n"=>"`@ auf dich st�rzt!`0`n`n"
		)
		,"`2Level: `6Undead`0`n"=>"`2Level: `6Untoter`0`n"
		,"`2`bStart of round:`b`n"=>"`2`bBeginn der Runde:`b`n"
		,"`2`bEnd of Round:`b`n"=>"`2`bEnde der Runde:`b`n"
		,"`&The gods have suspended any special effects!`n"=>"`&Die G�tter verbieten den Einsatz jeder Spezialf�higkeit!`n"
		,"'s bodyguard protects them!`n`n"=>" ist durch einen Leibw�chter gesch�tzt!`n`n"
		,"The bodyguard seems to have fallen asleep."=>"Der Leibw�chter scheint eingeschlafen zu sein."
		,"`\$'s skill allows them to get the first round of attack!`0`b`n`n"=>"`\$'s F�higkeiten erlauben deinem Gegner den ersten Schlag!`0`b`n`n"
		,"`\$ surprises you and gets the first round of attack!`0`b`n`n"=>"`\$ �berrascht dich und hat den ersten Schlag!`0`b`n`n"
		,"`b`\$Your skill allows you to get the first attack!`0`b`n`n"=>"`b`\$Dein K�nnen erlaubt dir den ersten Angriff!`0`b`n`n"
		,array(
			"`7`bYou execute a minor power move!`b`0`n"=>"`7`bDu holst zu einem kleinen Powerschlag aus!`b`0`n"
			,"`&`bYou execute a power move!!!`b`0`n"=>"`&`bDu holst zu einem Powerschlag aus!!!`b`0`n"
			,"`&`bYou execute a DOUBLE power move!!!`b`n"=>"`&`bDu holst zu einem DOPPELTEN Powerschlag aus!!!`b`n"
			,"`&`bYou execute a "=>"`&`bDu holst zu einem "
			," power move!!!`b`n"=>" Powerschlag aus!!!`b`n"
		)
		,"`4You are too busy trying to run away like a cowardly dog to try to fight `^"=>"`4Du bist zu besch�ftigt damit wegzulaufen wie ein feiger Hund und kannst nicht k�mpfen gegen `^"
		,"`&The gods have restored your special effects.`n`n"=>"`&Die G�tter gew�hren dir wieder alle deine speziellen F�higkeiten.`n`n"
		,array(
			"You regenerate for "=>"Du regenerierst um "
			,"You are healed for "=>"Du wirst geheilt um "
			,"A huge fist of earth pummels "=>"Eine gewaltige Faust aus Erde trifft "
			," recoils as lightning arcs out from your skin, hitting for `^"=>" wird von einem Blitzbogen aus deiner Haut zur�ckgeworfen und bekommt `^"
			,"`)An undead minion tries to hit "=>"`)Ein Untoter Diener versucht "
			," but `\$MISSES`)!"=>" zu treffen, aber `\$TRIFFT NICHT`)!"
			,"`)An undead minion hits "=>"`)Ein Untoter Diener trifft "
			,"You thrust a pin into the "=>"Du st��t eine Nadel in die "
			," doll hurting it for `^"=>"-Puppe und machst damit `^"
			,"'s bodyguard hits you for `\$"=>"'s Leibw�chter trifft dich mit `\$"
			,"'s bodyguard tries to it you but `\$MISSES`7!"=>"'s Leibw�chter schl�gt zu, aber `\$TRIFFt NICHT`7!"
			,"`4 tries to hit you but `\$MISSES!`n"=>"`4 versucht dich zu treffen, aber `\$TRIFFT NICHT!`n"
			,"`4 tries to hit you but you `^RIPOSTE`4 for `^"=>"`4 versucht dich zu treffen, aber dein `^GEGENSCHLAG`4 trifft mit `^"
			,"`4You try to hit "=>"`4Du versuchst "
			,"`4 but `\$MISS!`n"=>"`4 zu treffen, aber du `\$TRIFFST NICHT!`n"
			,"`4 but are `\$RIPOSTED `4for "=>"`4 zu treffen, aber sein `\$GEGENSCHLAG`4 trifft dich mit "
			,"Soulpoints"=>"Seelenpunkte"
			,"Hitpoints"=>"Lebenspunkte"
			,"`4 points of damage!`n"=>"`4 Schadenspunkten!`n"
			,"`) points!"=>"`) Schadenspunkte!"
			,"`) damage."=>"`) Schadenspunkte."
			,"`7 damage."=>"`7 Schadenspunkten."
			,"`4You hit `^"=>"`4Du triffst `^"
			,"`4 hits you for `\$"=>"`4 trifft dich mit `\$"
			,"`2YOUR "=>"`2DEINE "
			," for `^"=>" mit `^"
			,"`) points."=>"`) Punkten."
			," health."=>" Gesundheitspunkte"
		)
		,"Special Abilities"=>"Spezielle F�higkeiten"
		,array(
			"Dark Arts"=>"Dunkle K�nste"
			,"Skeleton Crew"=>"Skelette herbeirufen"
			,"Curse Spirit"=>"Geist verfluchen"
			,"Wither Soul"=>"Seele verdorren"
			,"Thieving Skills"=>"Diebesk�nste:"
			,"Insult"=>"Beleidigen"
			,"Poison Blade"=>"Waffe vergiften"
			,"Hidden Attack"=>"Versteckter Angriff"
			,"Backstab"=>"Angriff von hinten"
			,"Mystical Powers"=>"Mystische Kr�fte"
			,"Earth Fist"=>"Erdenfaust"
			,"Siphon Life"=>"Leben absaugen"
			,"Lightning Aura"=>"BlitzAura"
			,"You gain a level in"=>"Du steigst 1 Level auf in"
			,"only"=>" damit fehlen dir noch"
			,"more skill levels until you gain an extra use point!"=>"Fertigkeitspunkte, um eine weitere Anwendung pro Tag zu erhalten!"
			,"you gain an extra use point!"=>"du hast eine zus�tzliche Anwendung erhalten!"
			,"Thievery"=>"Diebesk�nsten"
		)
		,"Fight"=>"K�mpfen!"
		,"Run"=>"Wegrennen"
		// end battle
		// more from specials
		,"Old Man"=>"Alter Mann"
		,"`4`bHitpoints:`b`6"=>"`4`bLebenspunkte: `b`6"
		,"`4`bWeapon:`b`6"=>"`4`bWaffe: `b`6"
		,"`4`bArmor:`b`6"=>"`4`bR�stung:`b`6"
		,"`4`bAttack:`b`6"=>"`4`bAngriffswert:`b`6"
		,"`4`bDefense:`b`6"=>"`4`bVerteidigung: `b`6"
		,"Search"=>"Suchen"
		,"Previous"=>"Vorherige"
		,"Refresh"=>"Aktualisieren"
		,"Next"=>"N�chste"
		,"Play"=>"Spiele"
		,"says,"=>"sagt:"
		,"Continue"=>"Weiter"
		,"Keep"=>"Behalten"
		,"Pass"=>"Nochmal w�rfeln"
		,"Guess"=>"Rate"
		,array(
			"Don't drink"=>"Nicht trinken"
			,"Don't Drink"=>"Nicht Trinken"
			,"Drink"=>"Trinken"
		)
		,array(
			"Your "=>"Dein "
			,"'s bones were buried right alongside yours."=>" wurde direkt neben dir begraben."
			," managed to escape being crushed. You know that it is trained to return to the village.`n"=>" hat es geschafft dem Einsturz zu entkommen. Du weisst, dass das Tier darauf trainiert ist, zum Dorf zur�ckzukehren.`n"
			," managed to drag you to safety in the nick of time!`n"=>" schaffte es gerade noch rechtzeitig, dich in Sicherheit zu zerren!`n"
		)
		,array(
			"`n`nDo you wish to play his game?`n`n"=>"`n`nWillst du bei seinem Spielchen mitmachen?`n`n"
			,"Yes"=>"Ja"
			,"No"=>"Nein"
		)
		,"You gain "=>"Du bekommst "
		// end of more specials
		);
		break;
	case "gardens.php":
		$replace = array(
		"`b`c`2The Gardens`0`c`b"=>"`b`c`2Die G�rten`0`c`b"
		,"`n`n You walk through a gate and on to one of the many winding paths that makes its way through the well-tended gardens.  From the flowerbeds that bloom even in darkest winter, to the hedges whose shadows promise forbidden secrets, these gardens provide a refuge for those seeking out the Green Dragon; a place where they can forget their troubles for a while and just relax."=>"`n`nDu l�ufst durch einen Torbogen und weiter auf einem der vielen verschlungenen Pfade, die sich durch die wohlgepflegten G�rten ziehen. Von den Blumenbeeten, die auch im tiefsten Winter bl�hen, bis hin zu den Hecken, deren Schatten verbotene Geheimnisse versprechen, stellen diese G�rten einen Zufluchtsort f�r alle dar, die auf der Suche nach dem Gr�nen Drachen sind. Hier k�nnen sie ihre Sorgen vergessen und einfach mal entspannen."
		,"`n`nOne of the fairies buzzing about the garden flies up to remind you that the garden is a place for roleplaying, and to confine out-of-character comments to the other areas of the game."=>"`n`nEine der Feen, die hier im Garten umherschwirren, erinnert dich daran, dass der Garten ein Platz f�r Rollenspiel ist, und dass dieser Bereich vollst�ndig auf charakterspezifische Kommentare beschr�nkt ist."
		// part from "common.php"
		,"Previous"=>"Vorherige"
		,"Refresh"=>"Aktualisieren"
		,"Next"=>"N�chste"
		// end of common
		,"Whisper here"=>"Hier fl�stern"
		,"Return to the village"=>"Zur�ck zum Dorf"
		,"drunkenly whispers,"=>"fl�stert betrunken:"
		,"whispers,"=>"fl�stert:"
		);
		break;
	case "graveyard.php":
		$replace = array(
		"`\$`bYour soul can bear no more torment in this afterlife.`b`0"=>"`\$`bDeine Seele kann keine weiteren Qualen in diesem Nachleben mehr ertragen.`b`0"
		,"`\$Ramius`) curses you for your cowardice.`n`n"=>"`\$Ramius`) verflucht dich f�r deine Feigheit.`n`n"
		,array(
			"Your spirit wanders in to a lonely graveyard, overgrown with sickly weeds which seem to grab at your spirit as you float past them."=>"Dein Geist wandert auf einen einsamen mit Unkraut �berwucherten Friedhof. Die Pflanzen scheinen nach deinem Geist im Vorbeischweben zu greifen. "
			,"Around you are the remains of many broken tombstones, some lying on their face, some shattered to pieces.  You can almost hear the"=>"Du bist umgeben von den �berresten alter Grabsteine. Einige liegen auf dem Gesicht, andere sind in St�cke zerbrochen. Fast kannst du das Wehklagen "
			,"wails of the souls trapped within each plot lamenting their fates."=>"der hier in gefangenen Seelen h�ren."
			,"`n`n In the center of the graveyard is an ancient looking mausoleum which has been worn by the effects of untold years.  A sinister"=>"`n`n Mitten im Friedhof steht ein altert�mliches Mausoleum, dem die Spuren ungez�hlter Jahre deutlich anzusehen sind. "
			,"looking gargoyle adorns the apex of its roof; its eyes seem to follow  you, and its mouth gapes with sharp stone teeth."=>"Ein b�se schauender Gargoyle ziert die Dachspitze; seine Augen scheinen dir zu folgen und sein aufklaffender Mund ist gespickt mit scharfen Steinz�hnen. "
			,"The plaque above the door reads `\$Ramius, Overlord of Death`)."=>"Auf der Gedenktafel �ber der T�r ist zu lesen: `\$Ramius, Herr �ber den Tod`)."
		)
		,array(
			"You enter the mausoleum and find yourself in a cold, stark marble chamber.  The air around you carries the chill of death itself."=>"Du betrittst das Mausoleum und siehst dich in einer kalten, kahlen Kammer aus Marmor. Die Luft um dich herum tr�gt die K�lte des Todes selbst. "
			,"From the darkness, two black eyes stare into your soul.  A clammy grasp seems to clutch your mind, and fill it with the words of the Overlord of Death, `\$Ramius`) himself.`n`n"=>"Aus der Dunkelheit starren zwei schwarze Augen direkt in deine Seele. Ein feuchtkalter Griff scheint deine Seele zu umklammern und sie mit den Worten des Todesgottes `\$Ramius`) h�chstpers�nlich zu erf�llen:`n`n"
			,"\"`7Your mortal coil has forsaken you.  Now you turn to me.  There are those within this land that have eluded my grasp and posess a life beyond life.  To prove your worth to me "=>"\"`7Dein sterblicher K�per hat dich im Stich gelassen. Und jetzt wendest du dich an mich. Es gibt in diesem Land diejenigen, die sich meinem Griff entziehen konnten und ein Leben �ber das Leben hinaus besitzen. Um mir deinen Wert f�r mich zu beweisen "
			,"and earn my favor, go out and torment their souls.  Should you gain enough of my favor, I will reward you.`)\""=>"und dir Gefallen zu verdienen, gehe raus und qu�le deren Seelen. Solltest du mir genug Gefallen getan haben, werde ich dich belohnen.`)\" "
		)
		,"`\$Ramius`) curses you and throws you from the Mausoleum, you must gain more favor with him before he will grant restoration."=>"`\$Ramius`) verflucht dich und wirft dich aus dem Mausoleum. Du mu�t ihm erst genug Gefallen getan haben, bevor er dir die Wiederherstellung deiner Seele gew�hrt!"
		,"`\$Ramius`) sighs and mumbles something about, \"`7just 'cause they're dead, does that mean they don't have to think?`)\"`n`n"=>"`\$Ramius`) seufzt und murmelt etwas von \"`7Nur weil sie tot sind, hei�t das doch nicht, dass sie nicht zu denken brauchen, oder?`)\"`n`n"
		,"Perhaps you'd like to actually `ineed`i restoration before you ask for it."=>"Vielleicht solltest du erstmal eine Wiederherstellung `in�tig`i haben, bevor du danach fragst."
		,"`\$Ramius`) speaks, \"`7You have impressed me indeed.  I shall grant you the ability to visit your foes in the mortal world.`)\""=>"`\$Ramius`) spricht: \"`7Du hast mich tats�chlich beeindruckt. Ich sollte dir die M�glichkeit gew�hren, deine Feinde in der Welt der Sterblichen zu besuchen.`)\""
		,"`\$Ramius`) speaks, \"`7I am moderately impressed with your efforts.  A minor favor I now grant to you, but continue my work, and I may yet have more power to bestow.`)\""=>"`\$Ramius`) spricht: \"`7Ich bin nicht wirklich beeindruckt von deinen Bem�hungen, aber einen kleinen Gefallen werde ich dir gew�hren. F�hre meine Arbeit fort und ich kann dir vielleicht mehr meiner Kraft anbieten."
		,"`\$Ramius`) speaks, \"`7I am not yet impressed with your efforts.  Continue my work, and we may speak further.`)\""=>"`\$Ramius`) spricht: \"`7Ich bin von deinen Bem�hungen noch nicht beeindruckt. F�hre meine Arbeit fort und wir k�nnen weiter reden.`)\""
		,"`\$Ramius`) is impressed with your actions, and grants you the power to haunt a foe.`n`n"=>"`\$Ramius`) ist von deinen Aktionen beeindruckt und gew�hrt dir die Macht, einen Feind heimzusuchen.`n`n"
		,"Who would you like to haunt?"=>"Wen willst du heimsuchen?"
		,"`\$Ramius`) thinks you should narrow down the number of people you wish to haunt."=>"`\$Ramius`) denkt, du solltest die Zahl derer, die du heimsuchen willst, etwas einschr�nken."
		,"`\$Ramius`) could find no one who matched the name you gave him."=>"`\$Ramius`) kann niemanden mit einem solchen Namen finden."
		,"`\$Ramius`) will allow you to try to haunt these people:`n"=>"`\$Ramius`) wird dir gestatten, eine der folgenden Personen heimzusuchen:`n`n"
		,"That person has already been haunted, please select another target"=>"Diese Person wurde bereits heimgesucht. W�hle eine andere."
		,"You have successfully haunted `7"=>"Die Heimsuchung war erfolgreich bei `7"
		,"Search for something to torment"=>"Etwas zu qu�len suchen"
		,"Enter the Mausoleum"=>"Mausoleum betreten"
		,"List Warriors"=>"Kriegerliste"
		,"Return to the shades"=>"Zur�ck zu den Schatten"
		,array(
			"`\$Ramius`) calls you weak for needing restoration, but as you have enough favor with him, he grants your request at the cost of `4"=>"`\$Ramius`) nennt dich einen Schw�chling, weil du nach Wiederherstellung deiner Seele fragst. Aber da du genug Gefallen bei ihm gut hast, gibt er deiner Bitte zum Preis von `4"
			,"`) favor."=>"`) Gefallen nach."
		)
		,array(
			"Just as you were about to haunt `7"=>"Gerade als du "
			,"`) good, they sneezed, and missed it completely."=>"`)heimsuchen wolltest, versaut dir ein Niesen komplett den Erfolg."
		)
		,array(
			"You haunt `7"=>"Die Heimsuchung von `7"
			,"`) real good like, but unfortunately they're sleeping and are completely unaware of your presence."=>"`) l�uft richtig gut. Leider schl�ft dein Opfer tief und fest und bekommt von deiner Anwesenheit absolut nichts mit."
		)
		,array(
			"You're about to haunt `7"=>"Du machst dich zur Heimsuchung von `7"
			,"`), but trip over your ghostly tail and land flat on your, um... face."=>"`)bereit, stolperst aber �ber deinen Geisterschwanz und landest flach auf deinem .... �hm ... Gesicht."
		)
		,array(
			"You go to haunt `7"=>"Du willst `7"
			,"`) in their sleep, but they look up at you, and roll over mumbling something about eating sausage just before going to bed."=>"`) im Schlaf heimsuchen, doch dein Opfer dreht sich nur im Bett um und murmelt etwas von 'nie wieder W�rstchen so kurz vor dem Schlafengehen'."
		)
		,array(
			"You wake `7"=>"Du weckst `7"
			,"`) up, who looks at you for a moment before declaring, \"Neat!\" and trying to catch you."=>"`) auf. Er schaut dich kurz an, sagt kurz \"Niedlich!\" und versucht dich in einem Einmachglas einzufangen."
		)
		,array(
			"You go to scare `7"=>"Du versuchst `7"
			,"`), but catch a glimpse of yourself in the mirror and panic at the sight of a ghost!"=>"`) zu erschrecken, siehst dich dabei im Augenwinkel selbst im Spiegel und ger�tst in Panik, weil du einen Geist gesehen hast!"
		)
		,"`\$Ramius`) has lost their concentration on this person, you cannot haunt them now."=>"`\$Ramius`) kann sich nicht mehr auf diese Person konzentrieren. Du kannst sie jetzt nicht heimsuchen."
		,array(
			"`)You have `\$LOST `^"=>"`)Du hast `^"
			,"`) favor with `\$Ramius."=>"`) Gefallen bei `\$Ramius verloren`)!"
		)
		,"`)As you try to flee, you are summoned back to the fight!`n`n"=>"`)Als du zu fliehen versuchst, wirst du zum Kampf zur�ckberufen!`n`n"
		,"Return to the Graveyard"=>"Zur�ck zum Friedhof"
		,"Return to The Graveyard"=>"Zur�ck zum Friedhof"
		,"`b`&You have been defeated by `%"=>"`b`&Du wurdest erniedrigt von `%"
		,"`b`\$You have tormented "=>"`b`\$Du erniedrigst "
		,"You may not torment any more souls today."=>"Du kannst heute keine weiteren Seelen qu�len."
		,"`)`b`cThe Mausoleum`c`b"=>"`)`b`cDas Mausoleum`c`b"
		,array(
			"`#You receive `^"=>"`\$Ramius`# gibt dir daf�r `^"
			,"`# favor with `\$Ramius`#!`n`0"=>"`# Gefallen!`n`0"
		)
		,"Question `\$Ramius`0 about the worth of your soul"=>"Frage Ramius nach dem Wert deiner Seele"
		,"Haunt a foe (25 favor)"=>"Feind heimsuchen (25 Gefallen)"
		,"Resurrection (100 favor)"=>"Wiedererwecken (100 Gefallen)"
		,"Other"=>"Sonstiges"
		,"Ramius Favors"=>"Ramius Gefallen"
		,"Return to the mausoleum"=>"Zur�ck zum Mausoleum"
		,"Return to the Mausoleum"=>"Zur�ck zum Mausoleum"
		,"Torment"=>"Qu�len!"
		,"Flee"=>"Fliehen"
		,"The Graveyard"=>"Der Friedhof"
		,array(
			"`n`nYou have `6"=>"`n`nDu hast `6"
			,"`) favor with `\$Ramius`)."=>"`) Gefallen bei `\$Ramius`) gesammelt."
		)
		,array(
			"Restore Your Soul ("=>"Seele wiederherstellen ("
		 	,"favor)"=>"Gefallen)"
		)
		// battle (battle.php & common.php)
		,"You feel mortal again."=>"Du bist wieder sterblich."
		,"`n`&You feel godlike`n`n"=>"`n`&Du f�hlst dich gottgleich`n`n"
		,"`\$`c`b~ ~ ~ Fight ~ ~ ~`b`c`0"=>"`\$`c`b~ ~ ~ Kampf ~ ~ ~`b`c`0"
		,array(
			"You have encountered `^"=>"Du hast den Gegner `^"
			,"`@ which lunges at you with `%"=>"`@ entdeckt, der sich mit seiner Waffe `%"
			,"`@!`0`n`n"=>"`@ auf dich st�rzt!`0`n`n"
		)
		,"`2Level: `6Undead`0`n"=>"`2Level: `6Untoter`0`n"
		,"`2`bStart of round:`b`n"=>"`2`bBeginn der Runde:`b`n"
		,"`2`bEnd of Round:`b`n"=>"`2`bEnde der Runde:`b`n"
		,"`&The gods have suspended any special effects!`n"=>"`&Die G�tter verbieten den Einsatz jeder Spezialf�higkeit!`n"
		,"`\$'s skill allows them to get the first round of attack!`0`b`n`n"=>"`\$'s F�higkeiten erlauben deinem Gegner den ersten Schlag!`0`b`n`n"
		,"`\$ surprises you and gets the first round of attack!`0`b`n`n"=>"`\$ �berrascht dich und hat den ersten Schlag!`0`b`n`n"
		,"`b`\$Your skill allows you to get the first attack!`0`b`n`n"=>"`b`\$Dein K�nnen erlaubt dir den ersten Angriff!`0`b`n`n"
		,array(
			"`7`bYou execute a minor power move!`b`0`n"=>"`7`bDu holst zu einem kleinen Powerschlag aus!`b`0`n"
			,"`&`bYou execute a power move!!!`b`0`n"=>"`&`bDu holst zu einem Powerschlag aus!!!`b`0`n"
			,"`&`bYou execute a DOUBLE power move!!!`b`n"=>"`&`bDu holst zu einem DOPPELTEN Powerschlag aus!!!`b`n"
			,"`&`bYou execute a "=>"`&`bDu holst zu einem "
			," power move!!!`b`n"=>" Powerschlag aus!!!`b`n"
		)
		,"`4You are too busy trying to run away like a cowardly dog to try to fight `^"=>"`4Du bist zu besch�ftigt damit wegzulaufen wie ein feiger Hund und kannst nicht k�mpfen gegen `^"
		,"`&The gods have restored your special effects.`n`n"=>"`&Die G�tter gew�hren dir wieder alle deine speziellen F�higkeiten.`n`n"
		,array(
			"`4 tries to hit you but `\$MISSES!`n"=>"`4 versucht dich zu treffen, aber `\$TRIFFT NICHT!`n"
			,"`4 tries to hit you but you `^RIPOSTE`4 for `^"=>"`4 versucht dich zu treffen, aber dein `^GEGENSCHLAG`4 trifft mit `^"
			,"`4You try to hit "=>"`4Du versuchst "
			,"`4 but `\$MISS!`n"=>"`4 zu treffen, aber du `\$TRIFFST NICHT!`n"
			,"`4 but are `\$RIPOSTED `4for "=>"`4 zu treffen, aber sein `\$GEGENSCHLAG`4 trifft dich mit "
			,"Soulpoints"=>"Seelenpunkte"
			,"`4 points of damage!`n"=>"`4 Schadenspunkten!`n"
			,"`) points!"=>"`) Schadenspunkte!"
			,"`) damage."=>"`) Schadenspunkte."
			,"`7 damage."=>"`7 Schadenspunkten."
			,"`4You hit `^"=>"`4Du triffst `^"
			,"`4 hits you for `\$"=>"`4 trifft dich mit `\$"
			,"`2YOUR "=>"`2DEINE "
			," for `^"=>" mit `^"
			,"`) points."=>"`) Punkten."
			," health."=>" Gesundheitspunkte"
		)
		// end battle
		);
		break;
	case "gypsy.php":
		$replace = array(
		"Return to the village"=>"Zur�ck zum Dorf"
		// part for dealing gems (for anpera.net/logd )
		,"`6Vessa`5 tells you, that she doesn't have enough gems right now. You can come back later and try again.`n`n"=>"`6Vessa`5 teilt dir mit, dass sie nicht mehr so viele Edelsteine hat und bittet dich sp�ter noch einmal wiederzukommen.`n`n"
		,"`6Vessa`5 gives you the finger after you attempt to pay her less than her gems are worth.`n`n"=>"`6Vessa`5 zeigt dir den Stinkefinger, als du versuchst, ihr weniger zu zahlen als ihre Edelsteine Wert sind.`n`n"
		,"`6Vessa`5 raises her fist at you knowing you do not have any gems.`n`n"=>"`6Vessa`5 haut mit der Faust auf den Tisch und fragt dich, ob du sie veralbern willst. Du hast keinen Edelstein.`n`n"
		,"`6Vessa`5 accepts your gem and hands you 1500 gold coins in return.`n`n"=>"`6Vessa`5 nimmt deinen Edelstein und gibt dir daf�r 1500 Goldst�cke.`n`n"
		,array(
			"`nThe gypsy woman `6Vessa`5 insinuates that she deals with gems, too.`nRight now she has `#"=>"`nDie Zigeunerin `6Vessa`5 gibt dir auch zu verstehen, dass sie mit Edelsteinen handelt.`nMomentan hat sie `#"
			,"`5 gems in stock."=>"`5 Edelsteine auf Lager."
		)
		,array(
			"`6Vessa`5 quickly snatches up your `^"=>"`6Vessa`5 grapscht sich deine `^"
			,"`5 gold coins and hands you `#"=>"`5 Goldst�cke und gibt dir im Gegenzug `#"
			,"`5 gems in return.`n`n"=>"`5 Edelsteine.`n`n"
			,"`5 gem in return.`n`n"=>"`5 Edelstein.`n`n"
		)
		,"Buy 1 gem (4000 gold)"=>"Kaufe 1 Edelstein (4000 Gold)"
		,"Buy 2 gems (7800 gold)"=>"Kaufe 2 Edelsteine (7800 Gold)"
		,"Buy 3 gems (11400 gold)"=>"Kaufe 3 Edelsteine (11400 Gold)"
		,"Sell 1 gem for 1000 gold"=>"Verkaufe 1 Edelstein f�r 1000"
		,"Gypsy Tent"=>"Zigeuner Zelt"
		,"Purchase"=>"Kaufen"
		,"Return"=>"Zur�ck"
		,"Gems"=>"Edelsteine"
		// end of gems
		,array(
			"`5You offer the old gypsy woman your `^"=>"`5Du bietest der alten Zigeunerin deine `^"
			,"`5 gold for your gen-u-wine say-ance, however she informs you that the dead "=>"`5 Gold f�r die Beschw�rungssitzung. Sie informiert dich, dass die Toten "
			,"may be dead, but they ain't cheap."=>"zwar tot, aber nicht billig sind."
		)
		,"`5While in a deep trance, you are able to talk with the dead:`n"=>"`5Solange du in tiefer Trance bist, kannst du mit den Toten sprechen:`n"
		,"Snap out of your trance"=>"Erwache"
		,array(
			"`5You duck in to a gypsy tent behind `%Pegasus'`5 wagon which promises to let you talk with the deceased.  In typical gypsy style, the old woman sitting behind"=>"`5Du betrittst das Zigeuner Zelt hinter `%Pegasus`5' R�stungsladen, welches eine Unterhaltung mit den Verstorbenen verspricht. Im typischen Zigeunerstil sitzt eine alte Frau hinter "
			,"a somewhat smudgy crystal ball informs you that the dead only speak with the paying.  Your price is `^"=>"einer irgendwie schmierigen Kristallkugel. Sie sagt dir, dass die Verstorbenen nur mit den Bezahlenden reden. Der Preis ist `^"
			,"`5 gold."=>"`5 Gold."
		)
		,"Pay to talk to the dead"=>"Bezahle und rede mit den Toten"
		,"Forget it"=>"Vergiss es!"
		,"Superuser Entry"=>"Superusereintrag"
		,"says,"=>"sagt:"
		,"projects,"=>"wirft ein:"
		,"Next"=>"N�chste"
		,"Refresh"=>"Aktualisieren"
		,"Previous"=>"Vorherige"
		,"despairs,"=>"verzweifelt:"
		,"Project"=>"Einwerfen"
		);
		break;
	case "healer.php":
		$replace = array(
		"`#`b`cGolinda's Hut`c`b`n"=>"`#`b`cGolinda's H�tte`c`b`n"
		,"`#`b`cHealer's Hut`c`b`n"=>"`#`b`cH�tte des Heilers`c`b`n"
		,array(
			"`3A very petite and beautiful brunette looks up as you enter.  \"`6Ahh.. You must be "=>"`3Eine sehr zierliche und wunderh�bsche Br�nette schaut auf, als du eintrittst. \"`6Ah, Du musst "
			,"`6  I was told to expect you.  Come in.. come in!`3\" she exclaims.`n`nYou make your way deeper into the hut.`n`n"=>"`6 sein. Mir wurde gesagt, dass du kommen w�rdest. Komm rein... komm rein!`3\", ruft sie.`n`nDu gehst tiefer in die H�tte.`n`n"
		)
		,"`3You duck in to the small smoke filled grass hut.  The pungent aroma makes you cough, attracting the attention of a grizzled old person that does a remarkable job of reminding you of a rock, which probably explains why you didn't notice them until now.  Couldn't be your failure as a warrior.  Nope, definitely not.`n`n"=>"`3Du gehst geb�ckt in die rauchgef�llte Grash�tte.  Das stechende Aroma l�sst dich husten und zieht die Aufmerksamkeit einer uralten grauhaarigen Person auf dich, die den Job, dich an einen Felsen zu erinnern, bemerkenswert gut ausf�hrt. Das erkl�rt, dass du den kleinen Kerl bis jetzt nicht bemerkt hast. Kann ja nicht dein Fehler sein - als Krieger... Nop, definitiv nicht.`n`n"  
		,array(
			"`3\"`6Now.. Let's see here.  Hmmm. Hmmm. You're a bit banged up it seems.`3\"`n`n\"`5Uh, yeah.  I guess.  What will this cost me?`3\" you ask, looking sheepish. \"`5I don't normally get this hurt you know.`3\"`n`n\"`6I know.  I know.  None of you `^ever`6 does.  Anyhow, I can set you right as rain for `$`b"=>"`3\"`6Nun... lass uns mal sehen. Hmmm. Hmmm. Du siehst ein bisschen angeschlagen aus.`3\"`n`n\"`5�h... yeah. Ich sch�tze schon. Was wird mich das kosten?`3\", fragst du betreten, \"`5Weisst du, normalerweise werde ich nicht so leicht verletzt.`3\"`n`n\"`6Ich weiss, ich weiss. Niemand von euch wird `^jemals`6 verletzt. Aber egal. F�r `$`b"
			,"`b`6 gold pieces.  I can also give you partial doses at a lower price if you cannot afford a full potion,`3\" says Golinda, smiling."=>"`b`6 Goldst�cke mache ich dich wieder frisch wie einen Sommerregen. Ich kann dich auch zu einem niedrigeren Preis teilweise heilen, wenn du dir die volle Heilung nicht leisten kannst.`3\", sagt Golinda l�chelnd."
		)
		,array(
			"\"`6See you, I do.  Before you did see me, I think, hmm?`3\" the old thing remarks.  \"`6Know you, I do; healing you seek.  Willing to heal am I, but only if willing to pay are you.`3\"`n`n\"`5Uh, um.  How much?`3\" you ask, ready to be rid of the smelly old thing.`n`nThe old being thumps your ribs with a gnarly staff.  \"`6For you... `$`b"=>"\"`6Sehen kann ich dich. Bevor du sehen konntest mich, hmm?`3\" bemerkt das alte Wesen. \"`6Ich kenne dich, ja; Heilung du suchst. Bereit zu heilen dich ich bin, wenn bereit zu bezahlen du bist.`3\"`n`n\"`5Oh-oh. Wieviel?`3\" fragst du, bereit dich von diesem stingenden alten Dings ausnehmen zu lassen.`n`nDas alte Wesen pocht dir mit einem knorrigen Stab auf die Rippen: \"`6F�r dich... `$`b"
			,"`b`6 gold pieces for a complete heal!!`3\" it says as it bends over and pulls a clay vial from behind a pile of skulls sitting in the corner.  The view of the thing bending over to remove the vial almost does enough mental damage to require a larger potion.  \"`6I also have some, erm... 'bargain' potions available,`3\" it says as it gestures at a pile of dusty, cracked vials.  \"`6They'll heal a certain percent of your `idamage`i.`3\""=>"`b`6 Goldst�cke f�r eine komplette Heilung!!`3\". Dabei kr�mmt es sich und zieht ein Tonfl�schen hinter einem Haufen Sch�del hervor. Der Anblick dieses Dings, das sich �ber den Sch�delhaufen kr�mmt, um das Fl�schchen zu holen, verursacht wohl genug geistigen Schaden, um eine gr�ssere Flasche zu verlangen.  \"`6Ich auch habe einige - �hm... 'g�nstigere' Tr�nke im Angebot.`3\" sagt das Wesen, w�hrend es auf  einen verstaubten Haufen zerbrochener Tonkr�ge deutet. \"`6Sie werden heilen einen bestimmten Prozentsatz deiner `iBesch�digung`i.`3\" "
		)
		,"`3Golinda looks you over carefully.  \"`6Well, you do have that hangnail there, but other than that, you seem in perfect health! `^I`6 think you just came in here because you were lonely,`3\" she chuckles.`n`nRealizing that she is right, and that you are keeping her from other patients, you wander back out to the forest."=>"`3Golinda untersucht dich sehr sorgf�ltig. \"`6Nun, du hast diesen leicht eingewachsenen Zehennagel hier, aber ansonsten bist du vollkommen gesund. `^Ich`6 glaube, du bist nur hier her gekommen, weil du einsam warst.`3\", kichert sie.`n`nDu erkennst, dass sie Recht hat und dass du sie von ihren anderen Patienten abh�ltst. Deswegen gehst du zur�ck in den Wald."
		,"`3The old creature grunts as it looks your way. \"`6Need a potion, you do not.  Wonder why you bother me, I do.`3\" says the hideous thing.  The aroma of its breath makes you wish you hadn't come in here in the first place.  You think you had best leave."=>"`3Die alte Kreatur schaut in deine Richtung und grunzt: \"`6Einen Heiltrank du nicht brauchst. Warum du mich st�rst, ich mich frage.`3\" Der Geruch seines Atems l�sst dich w�nschen, du w�rst gar nicht erst gekommen. Du denkst, es ist das beste einfach wieder zu gehen."
		,array(
			"`3Golinda looks you over carefully.  \"`6My, my! You don't even have a hangnail for me to fix!  You are a perfect speciman of "=>"`3Golinda untersucht dich sehr sorgf�ltig. \"`6Ohje! Du hast nicht einmal einen eingewachsenen Zehennagel, den ich heilen k�nnte! Du bist ein Musterbeispiel an "
			,"womanhood"=>"Fraulichkeit"
			,"manhood"=>"M�nnlichkeit"
			,"!  Do come back if you get hurt, please,`3\" she says, turning back to her potion mixing.`n`n\"`6I will,`3\"you stammer, unaccountably embarrased as you head back out to the forest."=>"! Komm bitte wieder, wenn du verletzt wurdest`3\". Damit wendet sie sich wieder ihrer Tr�nkemischerei zu.`n`n\"`6Das werde ich`3\", stammelst du unglaublich verlegen und gehst zur�ck in den Wald."
		)
		,"`3The old creature glances at you, then in a `^whirlwind of movement`3 that catches you completely off guard, brings its gnarled staff squarely in contact with the back of your head.  You gasp as you collapse to the ground.`n`nSlowly you open your eyes and realize the beast is emptying the last drops of a clay vial down your throat.`n`n\"`6No charge for that potion.`3\" is all it has to say.  You feel a strong urge to leave as quickly as you can."=>"`3Die alte Kreatur blickt dich an und mit einem `^Wirbelwind einer Bewegung`3, die dich v�llig unvorbereitet erwischt, bringt sie ihren knorrigen Stab in direkten Kontakt mit deinem Hinterkopf. Du st�hnst und brichst zusammen.`n`nLangsam �ffnest du die Augen und bemerkst, dass dieses Biest gerade die letzten Tropfen aus einem Tonkrug in deinen Rachen sch�ttet.`n`n\"`6Dieser Trank kostenlos ist.`3\" ist alles, was es zu sagen hat. Du hast das dringende Bed�rfnis die H�tte so schnell wie m�glich zu verlassen."
		,"`3Expecting a foul concoction you begin to up-end the potion.  As it slides down your throat however, you taste cinnamon, honey, and a fruit flavor.  You feel warmth spread throughout your body as your muscles knit themselves back together.  Clear-headed and feeling much better, you hand Golinda the gold you owe and head back to the forest."=>"`3 Du erwartest ein fauliges Ges�ff und kippst den Trank herunter, aber als die Fl�ssigkeit dir den Rachen hinunter l�uft, schmeckst du Zimt, Honig und irgendetwas fruchtiges. Du f�hlst W�rme durch deinen K�rper str�men und deine Muskeln fangen an, sich von selbst zusammenzuf�gen. Mit klarem Kopf und wieder bei bester Gesundheit gibst du Golinda ihr Gold und verl�sst die H�tte in Richtung Wald. "
		,"`3With a grimace, you up-end the potion the creature hands you, and despite the foul flavor, you feel a warmth spreading through your veins as your muscles knit back together.  Staggering some, you hand it your gold and are ready to be out of here."=>"`3Mit verzerrtem Gesicht kippst du den Trank, den dir die Kreatur gegeben hat, runter. Trotz des fauligen Geschmacks f�hlst du, wie sich W�rme in deinen Adern ausbreitet und deine Muskeln heilen. Leicht taumelnd gibst du der Kreatur ihr Geld und verl�sst die H�tte."
		,array(
			"`3\"`6Tsk, tsk!`3\" Golinda murmers.  \"`6Maybe you should go visit the Bank and return when you have `b`\$"=>"`3\"`6Tss, tss!`3\", murmelt Golinda. \"`6Vielleicht solltest du erstmal zur Bank gehen und wiederkommen, sobald du `b`\$"
			,"`6`b gold?`3\" she asks.`n`nYou stand there feeling sheepish for having wasted her time.`n`n\"`6Or maybe a cheaper potion would suit you better?`3\" she suggests kindly."=>"`6`b Gold hast?`3\"`n`nDu f�hlst dich ziemlich bl�de, weil du ihre kostbare Zeit vergeudet hast.`n`n\"Oder vielleicht w�re ein billigerer Trank besser f�r dich?`3\", schl�gt sie freundilich vor."
		)
		,array(
			"`3The old creature pierces you with a gaze hard and cruel.  Your lightning quick reflexes enable you to dodge the blow from its gnarled staff.  Perhaps you should get some more money before you attempt to engage in local commerce.`n`nYou recall that the creature had asked for `b`\$"=>"`3Die alte Kreatur durchbohrt dich mit einem harten, grausamen Blick. Deine Blitzschnellen Reflexe erm�glichen dir, dem Schlag mit seinem knorrigen Stab auszuweichen. Vielleicht solltest du erst etwas Gold besorgen, bevor du versuchst, in den lokalen Handel einzusteigen. `n`nDir f�llt ein, dass die Kreatur nach `b`\$"
			,"`3`b gold."=>"`3`b Goldm�nzen gefragt hat."
		)
		// part from common.php
		,"Golinda's Hut"=>"Golinda's H�tte"
		,"Healer's Hut"=>"H�tte des Heilers"
		,"Look for Something to kill"=>"Etwas zum Bek�mpfen suchen"
		,"Go Slumming"=>"Herumziehen"
		,"Go Thrillseeking"=>"Nervenkitzel suchen"
		,array(
			"Take "=>"Nimm "
			," to Dark Horse Tavern"=>" zur Dark Horse Taverne"
		)
		,"Return to the Village"=>"Zur�ck zum Dorf"
		,"Seek out the Green Dragon"=>"Suche den Gr�nen Drachen"
		,"Other"=>"Sonstiges"
		,"The Outhouse"=>"Plumpsklo"
		// end common
		,array(
			"`n`n`#You have been healed for "=>"`n`n`#Du wurdest um "
			,"points!"=>" Punkte geheilt!"
		)
		,"Potions"=>"Tr�nke"
		,"`^Complete Healing`0"=>"`^Komplette Heilung`0"
		,"Back to the forest"=>"Zur�ck in den Wald"
		,"Back to the village"=>"Zur�ck ins Dorf"
		,"Return"=>"Zur�ck"
		,"gp"=>" Goldm�nzen"
		);
		break;
	case "hof.php":
		$replace = array(
		"`c`b`&Heroes of the realm`b`c"=>"`c`b`&Helden dieser Welt`b`c`n"
		,"`&There are no heroes in the land`0"=>"`&In diesem Land gibt es keine Helden`0"
		,"Return to the village"=>"Zur�ck ins Dorf"
		,array(
			"`bRank`b"=>"`bRang`b"
			,"`bDays`b"=>"`bTage`b"
			,"`bBest Days`b"=>"`bBeste Tage`b"
			,"unknown"=>"unbekannt"
		)
		);
		break;
	case "inn.php":
		$replace = array(
		"`c`bThe Boar's Head Inn`b`c"=>"`c`bDie Boar's Head Kneipe`b`c"
		,"You stroll down the stairs of the inn, once again ready for adventure!  "=>"Wiedermal bereit f�r's Abenteuer schlenderst du die Treppen der Kneipe runter. "
		,"You duck in to a dim tavern that you know well.  The pungent aroma of pipe tobacco fills "=>"Du tauchst in eine schummerige Kneipe ab, die du sehr gut kennst. Der stechende Geruch von Pfeifentabak erf�llt "
		,array(
			"  You wave to several patrons that you know, and wink at "=>"  Du winkst einigen deiner Kumpels und zwinkerst "
			,"`^Seth`0 who is tuning his harp by the fire."=>"`^Seth`0 zu, der seine Harfe beim Feuer stimmt. "
			,"`5Violet`0 who is serving ale to some locals."=>"`5Violet`0 zu, die ein paar einheimischen Ale serviert. "
			,"  Cedrik the innkeep stands behind his counter, chatting with someone.  You can't quite"=>"  Der Barkeeper Cedrik steht hinter seiner Theke und quatscht mit irgendjemandem. Du kannst nicht genau verstehen "
			," make out what he is saying, but it's something about "=>"was er sagt, aber es ist irgendwas �ber "
		)
		," Dag Durnick sits, sulking in the corner with a pipe clamped firmly in his mouth. "=>" Dag Durnick sitzt �bel gelaunt mit einer Pfeife fest im Mund in der Ecke. "
		,"`n`nThe clock on the mantle reads `6"=>"`n`nDie Uhr am Kamin zeigt `6"
		,"You go over to `5Violet`0 and help her with the ales she is carrying.  Once they are passed out, "=>"Du gehst r�ber zu `5Violet`0 und hilfst ihr dabei, ein paar Ales zu servieren. Als sie alle ausgeteilt sind, "
		,"she takes a cloth and wipes the sweat off of her brow, thanking you much.  Of course you didn't "=>"wischt sie sich mit einem Lappen den Schwei� von der Stirn und dankt dir herzlich. Nat�rlich war es "
		,"mind, as she is one of your oldest and truest friends!"=>"f�r dich selbstverst�ndlich, schlie�lich ist sie eine deiner �ltesten und besten Freundinnen!"
		,"You and `5Violet`0 gossip quietly for a few minutes about not much at all.  She offers you a pickle.  "=>"F�r ein paar Minuten tratscht du mit `5Violet`0 �ber alles und nichts. Sie bietet dir eine Essiggurke an. "
		,"You accept, knowing that it's in her nature to do so as a former pickle wench.  After a few minutes, "=>"Das liegt in ihrer Natur, da sie fr�her Gurken angebaut und verkauft hat. Du nimmst an. Nach ein paar Minuten " 
		,"Cedrik begins to cast burning looks your way, and you decide you had best let Violet get back to work."=>"bemerkst du die brennenden Blicke, die Cedrik immer h�ufiger in eure Richtung wirft und du beschliesst, dass es besser ist, Violet wieder ihre Arbeit machen zu lassen. "
		,"Violet looks you up and down very seriously.  Only a friend can be truly honest, and that is why you "=>"Violet schaut dich ernst von oben bis unten an. Nur ein echter Freund kann wirklich ehrlich sein und genau deswegen "
		,"asked her.  Finally she reaches a conclusion and states, \"`%"=>"hast du sie gefragt. Schlie�lich fasst sie einen Entschluss und sagt: \"`%"
		,"Your outfit doesn't leave much to the imagination, but some things are best not thought about at all!  Get some less revealing clothes as a public service!"=>"Dein Outfit l�sst nicht viel Spielraum f�r Fantasie, aber �ber manche Dinge sollte man auch wirklich nicht nachdenken. Du solltest etwas weniger freiz�gige Kleidung in der �ffentlichkeit tragen. "
		,"I've seen some lovely ladies in my day, but I'm afraid you aren't one of them."=>"Ich habe schon einige reizvolle Damen gesehn, aber ich f�rchte du bist keine davon."
		,"I've seen worse my friend, but only trailing a horse."=>"Ich habe schon schlimmeres gesehen, aber nur beim Verfolgen eines Pferdes."
		,"You're of fairly average appearance my friend."=>"Du bist ziemlicher Durchschnitt, mein Freund."
		,"You certainly are something to look at, just don't get too big of a head about it, eh?"=>"Du bist schon etwas zum Anschauen, aber lass dir das nicht zu sehr zu Kopfe steigen, ja?"
		,"You're quite a bit better than average!"=>"Du siehst schon ein bisschen besser aus als der Durchschnitt."
		,"Few women could count themselves to be in competition with you!"=>"Nur wenige Frauen k�nnen von sich behaupten, sich mit dir messen zu k�nnen!"
		,"I hate you, why, you are simply the most beautiful woman ever!"=>"Ich hasse dich. Warum? Weil du einfach die sch�nste Frau aller Zeiten bist!"
		,"You head over to cuddle Violet and kiss her about the face and neck, but she grumbles something about"=>"Du gehst r�ber zu Violet um sie zu knuddeln und sie auf Gesicht und Hals zu k�ssen, aber sie brummelt nur etwas "
		,"being  too  busy serving these pigs,"=>", dass sie zu besch�ftigt damit ist, diese Schweine zu bedienen. "
		,"\"that time of month,\""=>" �ber \"diese Zeit des Monats\"."
		,"\"a   little   cold...  *cough cough* see?\""=>" wie \"eine   leichte   Erk�ltung...  *hust hust* .. siehst du?\"."
		,"men all being pigs,"=>"dar�ber, dass alle M�nner Schweine sind."
		,"and  with a comment like that, you storm away from her!"=>" Nach so einem Kommentar l�sst du sie stehen und haust ab."
		,"You  and `5Violet`0 take some time to yourselves, and you leave the inn, positively glowing!"=>"Du und `5Violet`0 nehmt euch etwas Zeit f�r euch selbst und du verl�sst die Kneipe zuversichtlich strahlend!"
		,"You stare dreamily across the room at `5Violet`0, who leans across a table "=>"Du starrst vertr�umt durch den Raum auf `5Violet`0, die sich �ber einen Tisch beugt, "
		,"to serve a patron a drink.  In doing so, she shows perhaps a bit more skin "=>"um einem Gast einen Drink zu servieren. Dabei zeigt sie vielleicht etwas mehr Haut als "
		,"than is necessary, but you don't feel the need to object."=>"n�tig, aber du f�hlst absolut keinen Drang danach, ihr das vorzuhalten."
	 	,"You wink at `5Violet`0, and she gives you a warm smile in return."=>"Du zwinkerst `5Violet`0 zu und sie gibt dir ein warmes L�cheln zur�ck."
		,"You wink at `5Violet`0, but she pretends not to notice."=>"Du zwinkerst `5Violet`0 zu, doch sie tut so, als ob sie es nicht bemerkt h�tte."
		,"You stroll confidently across the room toward `5Violet`0.  Taking hold of her "=>"Selbstsicher schlenderst du Richtung `5Violet`0 durch den Raum. Du nimmst ihre Hand, "
		,"hand, you kiss it gently, your lips remaining for only a few seconds.  `5Violet`0 "=>"k�sst sie sanft, und h�ltst so f�r einige Sekunden inne. `5Violet`0 "
		,"blushes and tucks a strand of hair behind her ear as you walk away, then presses "=>"err�tet und streift eine Haarstr�hne hinter ihr Ohr. W�hrend du dich zur�ckziehst, presst sie "
		,"the back side of her hand longingly against her cheek while watching your retreat."=>"die R�ckseite ihrer Hand sehns�chtig an ihre Wange."
		,"You stroll confidently across the room toward `5Violet`0, and grab at her hand.  "=>"Selbstsicher schlenderst du Richtung `5Violet`0 durch den Raum und greifst nach ihrer Hand. "
		,"`n`nBut `5Violet`0 takes her hand back and asks if perhaps you'd like an ale."=>"`n`nAber `5Violet`0 zieht ihre Hand rasch zur�ck und fragt dich, ob du vielleicht ein Ale haben willst."
		,"Standing with your back against a wooden column, you wait for `5Violet`0 to wander "=>"Du lehnst mit deinem R�cken an einer h�lzernen S�ule und wartest, bis `5Violet`0 in "
		,"your way when you call her name.  She approaches, a hint of a smile on her face.  "=>"deine Richtung l�uft. Dann rufst du sie zu dir. Sie n�hert sich dir mit der Andeutung eines L�cheln im Gesicht. "
		,"You grab her chin, lift it slightly, and place a firm but quick kiss on her plump "=>"Du fasst ihr Kinn, hebst es etwas und presst ihr einen schnellen Kuss auf ihre prallen "
		,"your way when you call her name.  She smiles and apologizes, insisting that she is "=>"deine Richtung l�uft. Dann rufst du sie zu dir. Sie l�chelt und bedauert, dass sie "
		,"simply too busy to take a moment from her work."=>"mit ihrer Arbeit einfach zu besch�ftigt ist, um sich einen Moment f�r dich Zeit zu nehmen."
		,"Sitting at a table, you wait for `5Violet`0 to come your way.  When she does so, you "=>"Du sitzt an einem Tisch und lauerst auf deine Gelegenheit. Als `5Violet`0 bei dir vorbei kommt, "
		,"reach up and grab her firmly by the waist, pulling her down on to your lap.  She laughs "=>"umarmst du sie an der H�fte und ziehst sie auf deinen Schoss. Sie lacht "
		,"and throws her arms around your neck in a warm hug before thumping you on the chest, "=>"und wirft dir ihre Arme in einer warmen Umarmung um den Hals. Schliesslich klopft sie dir auf die Brust "
		,"standing up, and insisting that she really must get back to work."=>"und besteht darauf, dass sie wirklich wieder an die Arbeit gehen sollte."
		,"reach up to grab her by the waist, but she deftly dodges, careful not to spill the "=>"grabscht du nach ihrer H�fte, aber sie weicht geschickt aus, ohne auch nur einen Tropfen von "
		,"ale that she's carrying."=>"dem Ale zu versch�tten, das sie tr�gt."
		,"Waiting for `5Violet`0 to brush by you, you firmly palm her backside.  She turns and "=>"Du wartest darauf, bis `5Violet`0 an dir vorbeirauscht und gibst ihr einen klaps auf den Hintern. Sie dreht sich um und "
		,"gives you a warm, knowing smile."=>"gibt dir ein warmes, wissendes L�cheln."
		,"slaps you across the face.  Hard.  Perhaps you should go a little slower."=>"verpasst dir eine Ohrfeige. Eine kr�ftige! Vielleicht solltest du es etwas langsamer angehen. "
		,"Like a whirlwind, you sweep through the inn, grabbing `5Violet`0, who throws her arms "=>"Wie ein Wirbelwind braust du durch die Kneipe, schnappst dir `5Violet`0, die dir ihre Arme "
		,"around your neck, and whisk her upstairs to her room there.  Not more than 10 minutes later "=>"um den Hals wirft und tr�gst sie in ihren Raum nach oben. Kaum 10 Minuten sp�ter "
		,"you stroll down the stairs, smoking a pipe, and grinning from ear to ear.  "=>"stolzierst du, eine Pfeife rauchend und bis zu den Ohren grinsend, die Trppe wieder runter. "
		,"Like a whirlwind, you sweep through the inn, and grab for `5Violet`0.  She turns and "=>"Wie ein Wirbelwind fegst du durch die Kneipe und schnappst nach `5Violet`0. Sie dreht sich um und "
		,"slaps your face!  \"`%What sort of girl do you think I am, anyhow?`0\" she demands! "=>"schl�gt dir ins Gesicht! \"`%F�r was h�ltst du mich eigentlich?`0\" br�llt sie dich an. !"
		,"`5Violet`0 is working feverishly to serve patrons of the inn.  You stroll up to her "=>"`5Violet`0 arbeitet fieberhaft, um einige G�ste der Kneipe zu bedienen. Du schlenderst zu ihr r�ber "
		,"and take the mugs out of her hand, placing them on a nearby table.  Admidst her protests "=>"nimmst ihr die Becher aus der Hand und stellst sie auf den n�chsten Tisch. Unter ihrem Protest kniest du dich auf einem Knie vor sie hin und nimmst ihre Hand. "
		,"you kneel down on one knee, taking her hand in yours.  She quiets as you stare up at her "=>"Sie verstummt pl�tzlich. Du starrst zu ihr hoch "
		,"and utter the question that you never thought you'd utter.  She stares at you and you "=>"und �usserst die Frage, von der du nie f�r m�glich gehalten hast, dass du sie einmal stellen wirst. "
		,"immediately know the answer by the look on her face. "=>"Sie starrt dich an und du liest sofort die Antwort aus ihrem Gesicht. "
		,"`n`nIt is a look of exceeding happiness.  \"`%Yes!`0\" she says, \"`%Yes, yes yes!!!`0\""=>"`n`nEs ist ein Ausdruck �bersch�umender Freude. \"`%Ja! Ja, ja, ja!`0\" sagt sie. "
		,"Her final confirmations are buried in a flurry of kisses about your face and neck. "=>" Ihre letzten Best�tigungen gingen dabei in einem Sturm von K�ssen auf den Gesicht und deinen Hals unter. "
		,"`n`nThe next days are a blur; you and `5Violet`0 are married in the abbey down the street, "=>"`n`n`5Violet`0 und du heiraten in der Kirche am Ende der Strasse in "
		,"in a gorgeous ceremony with many frilly girly things."=>"einer prachtvollen Feier mit vielen rausgeputzten M�dels. "
		,"`n`nIt is a look of sadness.  \"`%No`0,\" she says, \"`%I'm not yet ready to settle down`0.\""=>"`n`nEs ist ein sehr trauriger Blick. Sie sagt: \"`%Nein, ich bin noch nicht bereit f�r eine feste Bindung.`0\""
		,"`n`nDisheartened, you no longer possess the will to pursue any more forest adventures today."=>"`n`nEntmutigt und entt�uscht hast du heute keine Lust mehr auf irgendwelche Abenteuer im Wald."
		,"You think you had better not push your luck with `5Violet`0 today."=>"Du denkst, es ist besser, dein Gl�ck mit `5Violet`0 heute nicht mehr herauszufordern."
		 ,"Seth looks at you expectantly."=>"Seth schaut dich erwartungsvoll an."
		,"Seth looks you up and down very seriously.  Only a friend can be truly honest, and that is why you "=>"Seth schaut dich ernst von oben bis unten an. Nur wahre Freunde k�nnen wirklich ehrlich sein, das ist der Grund, weshalb du "
		,"asked him.  Finally he reaches a conclusion and states, \"`%"=>"ihn gefragt hast. Schliesslich kommt er zu einem Schluss und sagt: \"`%"
		,"You make me glad I'm not gay"=>"Du machst mich gl�cklich, dass ich nicht schwul bin!"
		,"I've seen some handsome men in my day, but I'm afraid you aren't one of them."=>"Ich habe einige h�bsche M�nner in meinem Leben gesehen, aber ich f�rchte du bist keiner von ihnen."
		,"Few women would be able to resist you!"=>"Nur wenige Frauen k�nnten dir widerstehen!"
		,"I hate you, why, you are simply the most handsome man ever!"=>"Ich hasse dich! Warum? Weil du einfach der bestausehndste Mann aller Zeiten bist!"
		,"Seth clears his throat and drinks some water.  \"I'm sorry, my throat is just too dry.\""=>"Seth r�uspert sich und trinkt einen Schluck Wasser. \"Tut mir Leid, mein Hals ist einfach zu trocken.\""
		,"Seth clears his throat and begins:`n`n`^"=>"Seth r�uspert sich und f�ngt an:`n`n`^"
		,"`@Green Dragon`^ is green. `n`@Green Dragon`^ is fierce. `nI fancy for `na `@Green Dragon`^ to pierce. "=>"`@Gr�ner Drache`^ ist gr�n.`n`@Gr�ner Drache`^ ist wild.`nGr�nen Drachen w�nsch ich mir gekillt. "
		,"`n`n`0You gain TWO forest fights for today!"=>"`n`n`0Du erh�ltst ZWEI zus�tzliche Waldk�mpfe f�r heute!"
		,"Mireraband I scoff at thee and tickeleth your toes. `nFor they smell most foul and seethe a stench far greater than you know! "=>"Mireraband, Ich spotte euch und spuck auf euren Fu�.`nDenn er verstr�mt fauligen Gestank mehr als er mu�."
              		,"`n`n`0You feel jovial, and gain an extra forest fight."=>"`n`n`0Du f�hlst dich erheitert und bekommst einen extra Waldkampf."
		,array(
			"Membrain Man, Membrain Man. `nMembrain man hates "=>"Membrain Mann Membrain Mann.`nMembrain Mann hasst "
			,"`^ man. `nThey have a fight, Membrain wins. `nMembrain Man. "=>"`^ Mann.`nSie haben einen Kampf, Mambrain gewinnt.`nMembrain Mann. "
		)             
		,"`n`n`0You're not quite sure what to make of this... you merely back away, and think you'll visit Seth when he's feeling better.  Having"=>"`n`n`0Du bist dir nicht ganz sicher, was du davon halten sollst... du gehst lieber wieder weg und denkst, es ist besser, Seth wieder zu besuchen, wenn er sich besser f�hlt. "
		,"rested a while though, you think you could face another forest creature."=>"Nach einer kurzen Verschnaufpause k�nntest du wieder ein paar b�se Jungs verpr�geln."
		,"Gather 'round and I'll tell you a tale `nmost terrible and dark `nof Cedrik and his unclean beer `nand how he hates this bard! "=>"F�r eine Geschichte versammelt euch hier`neine Geschichte so schrecklich und hart`n�ber Cedrik und sein gepanschtes Bier`nund wie sehr er ihn hasst, mich, den Bard'."
		,"`n`n`0You realize he's right, Cedrik's beer is really nasty.  That's why most patrons prefer his ale.  Though you don't really gain anything from the tale from Seth, you do happen to notice a few gold on the ground!"=>"`n`n`0Du stellst fest, dass er Recht hat, Cedrik's Bier ist wirklich eklig. Das d�rfte der Grund daf�r sein, warum die meisten G�ste sein Ale bevorzugen. Du kannst der Geschichte von Seth nicht wirklich etwas abgewinnnen, aber du findest daf�r etwas Gold auf dem Boden. "
		,"So a pirate goes in to a bar with a steering wheel in his pants. `nThe bartender says, \"You know you have a steering wheel in your pants.\" `nThe pirate replies, \"Yaaarr, 'tis drivin' me nuts!\" "=>"Der gro�e gr�ne Drache hatte eine Gruppe Zwerge entdeckt und sie *schlurps* einfach aufgefuttert. Sein Kommentar sp�ter war: \"Die schmecken ja toll... aber... kleiner sollten sie wirklich nicht sein!\""
              		,"`n`n`0With a good hearty chuckle in your soul, you advance on the world, ready for anything!"=>"`n`n`0Mit einem guten herzlichen Kichern in deiner Seele r�ckst du wieder aus, bereit f�r was auch immer da kommen mag."
		,"Listen close and hear me well:  every second we draw even closer to death.  *wink*"=>"H�rt gut zu und nehmt es euch zu Herzen: Mit jeder Sekunde r�cken wir dem Tod etwas n�her. *zwinker*"
		,"`n`n`0Depressed, you head for home... and lose a forest fight!"=>"`n`n`0Deprimiert wendest du dich ab... und verlierst einen Waldkampf!"
		,"I love MightyE, MightyE weaponry, I love MightyE, MightyE weaponry, I love MightyE, MightyE weaponry, nothing kills as good as MightyE... WEAPONRY!"=>"Ich liebe MightyE, die Waffen von MightyE, ich liebe MightyE, die Waffen von MightyE, ich liebe MightyE, die Waffen von MightyE, nichts t�tet so gut wie die WAFFEN von ... MightyE!"
		,"`n`n`0You think Seth is quite correct... you want to go out and kill something.  You leave and think about bees and fish for some reason."=>"`n`n`0Du denkst Seth is ganz in Ordnung... jetzt willst du los um irgendwas zu t�ten. Aus irgendeinem Grund denkst du an Bienen und Fisch. "
		,"`0Seth seems to sit up and prepare himself for something impressive. He then burps loudly in your face.  \"`^Was that entertaining enough?`0\""=>"`0Seth richtet sich auf und scheint sich auf etwas eindrucksvolles vorzubereiten. Dann r�lpst er dir laut ins Gesicht. \"`^War das unterhaltsam genug?`0\""
		,"`n`n`0The smell is overwhelming, you feel a little ill and lose some hitpoints."=>"`n`n`0Der Gestank nach angedautem Ale ist �berw�ltigend. Dir wird etwas �bel und du verlierst ein paar Lebenspunkte."
		,"`0\"`^What is the sound of one hand clapping?`0\" asks Seth.  While you ponder this connundrum, Seth \"liberates\" a small entertainment fee from your purse."=>"`0\"`^Welches Ger�usch macht es, wenn man mit einer Hand klatscht?`0\", fragt Seth. W�hrend du �ber diese Scherzfrage nachgr�belst, \"befreit\" Seth eine kleine Unterhaltungsgeb�hr aus deinem Golds�ckchen."
		,"`0\"`^What is the sound of one hand clapping?`0\" asks Seth.  While you ponder this connundrum, Seth attempts to \"liberate\" a small entertainment fee from your purse, but doesn't find enough to bother with."=>"`0\"`^Welches Ger�usch macht es, wenn man mit einer Hand klatscht?`0\", fragt Seth. W�hrend du �ber diese Scherzfrage nachgr�belst, versucht Seth eine kleine Unterhaltungsgeb�hr aus deinem Golds�ckchen zu befreien, findet aber nicht, was er sich erhofft hat."
		,"`n`nYou lose 5 gold!"=>"`n`nDu verlierst 5 Gold!"
		,"What do you call a fish with no eyes?`n`nA fsshh."=>"Welcher Fuss muss immer zittern?`n`nDer Hasenfuss."
		,"`n`nYou groan as Seth laughs heartily.  Shaking your head, you notice a gem in the dust."=>"`n`nDu gr�hlst und Seth lacht herzlich. Kopfsch�ttelnd bemerkst du einen Edelstein im Staub."
		,"Seth plays a soft but haunting melody."=>"Seth spielt eine sanfte, aber mitreissende Melodie." 
 		,"`n`nYou feel relaxed, and your wounds seem to fade away."=>"`n`nDu f�hlst dich entspannt und erholt und deine Wunden scheinen sich zu schliessen."
		,"Seth plays a melancholy dirge for you."=>"Seth spielt dir ein d�steres Klagelied vor."
        		,"`n`nYou feel lower in spirits, you may not be able to face as many villians today."=>"`n`nDeine Stimmung f�llt und du wirst heute nicht mehr so viele B�sewichte erschlagen."
		,"The ants go marching one by one, hoorah, hoorah.`nThe ants go marching one by one, hoorah, hoorah!`nThe ants go marching one by one and the littlest one stops to suck his thumb,`nand they all go marching down, to the ground, to get out of the rain...`nbum bum bum`nThe ants go marching two by two, hoorah, hoorah!...."=>"Die Ameisen marschieren in Einerreihen, Hurra, Hurra!`nDie Ameisen marschieren in Einerreihen, Hurra, Hurra!`nDie Ameisen marschieren in Einerreihen, Hurra, Hurra, und die kleinste stoppt und nuckelt am Daumen.`nUnd sie alle marschieren in den Bau um vorm Regen abzuhaun.`nBumm, bumm, bumm.`nDie Ameisen marschieren in Zweierreihen, Hurra, Hurra! ... "
		,"`n`n`0Seth continues to sing, but not wishing to learn how high he can count, you quietly leave.`n`nHaving rested a while, you feel refreshed."=>"`n`n`0Seth singt immer weiter, aber du hast nicht den Wunsch herauszufinden, wie weit Seth z�hlen kann, deswegen verschwindest du leise. Nach dieser kurzen Rast f�hlst du dich erholt. "
		,"There once was a lady from Venus, her body was shaped like a ..."=>"Es war ein mal eine Dame von der Venus, ihr K�rper war geformt wie ein ..."
		,"`n`n`0Seth is cut short by a curt slap across his face!  Feeling rowdy, you gain a forest fight."=>"`n`n`0Seth wird durch einen barschen Schlag ins Gesicht unterbrochen. Du f�hlst dich rauflustig und gewinnst einen Waldkampf dazu."
		,"`n`n`0Seth is cut short as you burst out in laughter, not even having to hear the end of the rhyme.  Feeling inspired, you gain a forest fight."=>"`n`n`0Seth wird durch dein pl�tzliches lautes Gel�chter unterbrochen, das du ausst�sst, ohne seinen Reim vollst�ndig geh�rt haben zu m�ssen. So angespornt erh�ltst du einen zus�tzlichen Waldkampf!"
		,"Seth plays a rousing call-to-battle that wakes the warrior spirit inside of you."=>"Seth spielt einen st�rmischen Schlachtruf f�r dich, der den Kriegergeist in dir erweckt."
		,"Seth grins a big toothy grin.  My, isn't the dimple in his chin cute??"=>"Seth grinst ein breites Grinsen. Hach, ist dieses Gr�bchen in seinem Kinn nicht s�ss??"
		,"Seth seems preoccupied with your... eyes."=>"Seth scheint in Gedanken v�llig woanders zu sein ... bei deinen ... Augen."
		,"`n`n`0You receive one charm point!"=>"`n`n`0Du erh�ltst einen Charmepunkt!"
		,"Seth begins to play, but a lute string snaps, striking you square in the eye.`n`n`0\"`^Whoops, careful, you'll shoot your eye out kid!`0\""=>"Seth f�ngt an zu spielen, aber eine Saite seiner Laute rei�t pl�tzich und schl�gt dir flach ins Auge.`n`n`0\"`^Uuuups! Vorsicht, du wirst dir noch deine Augen ausschiessen, Mensch!`0\""
		,"`n`nYou lose some hitpoints!"=>"`n`nDu verlierst einige Lebenspunkte."
		,"Seth begins to play, but a rowdy patron stumbles past, spilling beer on you.  You miss the performance as you wipe the swill from your "=>"Seth f�ngt an zu spielen, als ein rauflustiger Gast vorbeistolpert und Bier auf dich versch�ttet. Du verpasst die ganze Vorstellung deswegen und reinigst das Ges�ff von deine(r/m) "
		,"`0Seth stares at you thoughtfully, obviously rapidly composing an epic poem...`n`n`^U-G-L-Y, You ain't got no aliby -- you ugly, yeah yeah, you ugly!"=>"`0Seth start dich gedankenvoll an. Offensichtlich komponiert er gerade ein episches Gedicht...`n`n`^H-�-S-S-L-I-C-H, du kannst dich nicht verstecken -- Du bist h�sslich, yeah, yeah, so h�sslich!"
             		,"`n`n`0Furious, you stomp out of the bar!  You gain a forest fight in your fury."=>"`n`n`0Aufgebracht st�rmst du aus der Bar! In deiner Wut bekommst du einen Waldkampf dazu."
 		,"`n`n`0If you had any charm, you'd have been offended, instead, Seth breaks a lute string."=>"`n`n`0Wenn du einen Charmepunkt h�ttest, h�ttest du ihn jetzt verloren. Aber so rei�t Seth nur eine Saite seiner Laute."
		,"`n`n`0Depressed, you lose a charm point."=>"`n`n`0Deprimiert verlierst du einen Charmepunkt."
		,"You  head  over  to  snuggle up to Seth  and  kiss him about the face and neck, but he grumbles something about"=>"Du gehst r�ber zu Seth, um ihn zu knuddeln und mit K�ssen zu �berh�ufen, aber er brummelt nur etwas "
		,"being   too  busy  tuning  his lute,"=>"dar�ber, dass er damit besch�ftigt ist, seine Laute zu stimmen."
		,"wanting  you  to  fetch  him a beer,"=>"dar�ber, dass er sich ein Bier holen will."
		,"and  with a comment like that, you storm away from him!"=>"Nach so einem Kommentar l�sst du ihn stehen und haust ab."
		,"You  and  Seth  take  some time to yourselves, and you leave the inn, positively glowing!"=>"Du und Seth nehmt euch etwas Zeit f�reinander und du verl�sst die Kneipe mit einem zuversichtlichen Strahlen!"
		,"Seth raises an eyebrow at you, and asks if you have something in your eye."=>"Seth hebt eine Augenbraue und fragt dich, ob du etwas im Auge hast."
		,"Seth smiles at you and says, \"`^My, what pretty eyes you have`0\""=>"Seth l�chelt dich an und sagt: \"`^Du hast wundersch�ne Augen`0\""
		,"Seth smiles, and waves... to the person standing behind you."=>"Seth l�chelt und winkt ... zu der Person hinter dir."
		,"Seth bends over and retrieves your hanky, while you admire his firm posterior."=>"W�hrend Seth sich b�ckt, um dir dein Taschentuch zur�ckzugeben, bewunderst du seinen knackigen Hintern."
		,"Seth bends over and retrieves your hanky, wipes his nose with it, and gives it back."=>"Seth hebt das Taschentuch auf, putzt sich damit die Nase und gibt es dir zur�ck."
		,"Seth places his arm around your waist, and escorts you to the bar where he buys you one of the Inn's fine swills."=>"Seth platziert seinen Arm um deine H�fte, geleitet dich an die Bar und kauft dir eines der k�stlichsten Getr�nke, die es in der Kneipe gibt."
		,"Seth apologizes, \"`^I'm sorry m'lady, I have no money to spare,`0\" as he turns out his moth-riddled pocket."=>"Seth bedauert: \"`^Tut mir Leid, meine Dame, ich habe kein Geld zu verschenken.`0\" Dabei st�lpt er seine mottenzerfressenen Taschen nach aussen."
		,"You walk up to Seth, grab him by the shirt, pull him to his feet, and plant a firm, long kiss right on his handsome lips.  He collapses after, hair a bit disheveled, and short on breath."=>"Du l�ufst auf Seth zu, packst ihn am Hemd, stellst ihn auf die Beine und dr�ckst ihm einen kr�ftigen, langen Kuss direkt auf seine attraktiven Lippen. Seth bricht fast zusammen, mit zerzausten Haaren und ziemlich atemlos."
		,"You duck down to kiss Seth on the lips, but just as you do so, he bends over to tie his shoe."=>"Du b�ckst dich zu Seth herunter, um ihn auuf die Lippen zu k�ssen, doch als sich eure Lippen gerade ber�hren wollten, b�ckt sich Seth, um sich den Schuh zuzubinden."
		,"Standing at the base of the stairs, you make a come-hither gesture at Seth.  He follows you like a puppydog."=>"Du stehst auf der ersten Treppenstufe und gibst Seth ein 'komm hierher' Zeichen. Er folgt dir wie eiin Schossh�ndchen."
		,"\"`^I'm sorry m'lady, but I have a show in 5 minutes`0\""=>"\`^Tut mir Leid meine Dame, aber ich habe in 5 Minuten einen Auftritt.`0\""
		,"Walking up to Seth, you simply demand that he marry you.`n`nHe looks at you for a few seconds.`n`n"=>"Du gehst zu Seth und verlangst ohne Umschweife von ihm, da� er dich heiratet.`n`nEr schaut dich ein paar Sekunden lang an.`n`n"
		,"\"`^Of course my love!`0\" he says.  The next weeks are a blur as you plan the most wonderous wedding, paid for entirely by Seth, and head on off to the deep forest for your honeymoon."=>"\"`^Nat�rlich, meine Liebe!`0\", sagt er. Die n�chsten wochen bist du damit besch�ftigt, eine gigantische Hochzeit vorzubereiten, die nat�rlich Seth zahlt, und danach geht es in den dunklen Wald in die Flitterwochen!"
		,"Seth says, \"`^I'm sorry, apparently I've given you the wrong impression, I think we should just be friends.`0\""=>"Seth sagt: \"`^Es tut mir Leid, offensichtlich habe ich einen falschen eindruck erweckt. Ich denke, wir sollten einfach nur Freunde sein.`0\""
		,"You think you had better not push your luck with `^Seth`0 today."=>"Du denkst, es ist besser, dein Gl�ck mit `^Seth`0 heute nicht mehr herauszufordern."
		,"You stroll over to a table, place your foot up on the bench and listen in on the conversation:`n"=>"Du schlenderst r�ber zu einem Tisch, stellst den Fu� auf die Bank und lauschst der Unterhaltung:`n"
		,"Cedrik looks at you sort-of sideways like.  He never was the sort who would trust a man any "=>"Cedrik schaut dich irgendwie schr�g an. Er war nie von der Sorte, die einem Mann viel weiter trauen, "
		,"farther than he could throw them, which gave dwarves a decided advantage, except in provinces "=>"als sie ihn werfen k�nnten, was Zwergen einen entscheidenden Vorteil verlieh. Mit Ausnhame von Regionen nat�rlich, "
		,"where dwarf tossing was made illegal.  Cedrik polishes a glass, holds it up to the light of the door as "=>"in denen Zwergenweitwurf verboten wurde.  Cedrik poliert ein Glas und h�lt es ins Licht, das durch die T�r hereinscheint, als ein Gast "
		,"another patron opens it to stagger out in to the street.  He then makes a face, spits on the glass "=>"die Kneipe verl��t. Dann verzieht er das Gesicht, spuckt auf das Glas "
		,"and goes back to polishing it.  \"`%What d'ya want?`0\" he asks gruffly."=>"und f�hrt mit der Politur fort. \"`%Was willst'n?`0\", fragt er dich schroff."
		,"\"`%You have gems, do ya?`0\" Cedrik asks.  \"`%Well, I'll make you a magic elixir for `^two gems`%!`0\""=>"\"`%Du hast Edelsteine, oder?`0\", fragt dich Cedrik. \"`%Nun, f�r `^zwei Edelsteine`% werd ich dir nen magischen Trank machen!`0\""
		,"`n`nGive him how many gems?"=>"`n`nWieviele Edelsteine gibst du ihm?"
		,"Cedrik stares at you blankly.  \"`%You don't have that many gems, `bgo get some more gems!`b`0\" he says."=>"Cedrik starrt dich an und sagt: \"`%Du hast nich so viele Edelsteine, `bzieh los und besorg dir noch welche!`b`0\""
		,"  Cedrik, knowing about your fundamental misunderstanding of "=>"  Cedrik, der �ber deine absolute mathematische Unf�higkeit bescheid weiss, "
		,"math, hands one of them back to you."=>"gibt dir einen davon zur�ck."
		,"  You drink the potion Cedrik hands you in exchange for your gems, and.....`n`n"=>"  Du trinkst den Trank, den Cedrik dir im Austausch f�r deine Edelsteine gegeben hat und......`n`n"
		,"`&You feel charming! `^(You gain charm points)"=>"`&Du f�hlst dich charmant! `^(Du erh�ltst Charmpunkte)"
		,"`&You feel vigorous! `^(You gain max hitpoints)"=>"`&Du f�hlst dich lebhaft! `^(Deine maximale Lebensenergie erh�ht sich permanent)"
		,"`&You feel healthy! `^(You gain temporary hitpoints)"=>"`&Du f�hlst dich gesund! `^(Du erh�ltst vor�bergehend mehr Lebenspunkte)"
		,"`&You feel completely directionless in life.  You should rest and make some important decisions about your life! `^(Your specialty has been reset)"=>"`&Du f�hlst dich v�llig ziellos in deinem Leben. Du solltest eine Pause machen und einige wichtige Entscheidungen �ber dein Leben treffen! `^(Dein Spezialgebiet wurde zur�ckgesetzt)"
		,"`@You double over retching from the effects of transformation potion as your bones turn to gelatin!`n`^(Your race has been reset and you will be able to chose a new one tomorrow.)"=>"`@Deine Knochen werden zu Gelatine und du musst vom Effekt des Tranks ordentlich w�rgen!`^(Deine Rasse wurde zur�ckgesetzt. Du kannst morgen eine neue w�hlen.)"
		,"`n`nYou feel as though your gems would be better used elsewhere, not on some smelly potion."=>"`n`nDu hast das unbestimmte Gef�hl, dass deine Edelsteine f�r etwas anderes als stinkende Tr�nke besser eingesetzt w�ren."
		,"How much would you like to offer him?"=>"Wie viel willst du ihm anbieten?"
		,"Cedrik stands there staring at you blankly"=>"Cedrik steht nur da und schaut dich ausdruckslos an."
		,"Cedrik leans over the counter toward you.  \"`%What can I do for you kid?`0\" he asks."=>"Cedrik lehnt sich zu dir �ber die Theke und fragt: \"`%Was kann ich f�r dich tun, kleiner?`0\""
		,"Cedrik begins to wipe down the counter top, an act that really needed doing a long time ago.  "=>"Cedrik f�ngt an, die Oberfl�che der Theke zu wischen, was eigentlich schon vor langer Zeit wieder einmal n�tig gewesen w�re.  "
		,"When he finished, your gems are"=>"Als er damit fertig ist, sind deine Edelsteine"
		,"When he finished, your gem is"=>"Als er damit fertig ist, ist dein Edelstein"
		,"When he finished, your gold is"=>"Als er damit fertig ist, ist dein Gold"
		," gone.  You inquire about the loss, and he stares blankly back at you."=>" verschwunden. Du fragst wegen deinem Verlust nach, aber Cedrik starrt dich nur mit leerem Blick an. "
		,"Pounding your fist on the bar, you demand an ale"=>"Du schl�gst mit der Faust auf die Bar und verlangst ein Ale"
		,", but Cedrik continues to clean the glass he was working on.  \"`%You've had enough lass,`0\" he declares."=>", aber Cedrik f�hrt unbek�mmert damit fort, das Glas weiter zu polieren, an dem er gerade arbeitet. \"`%Du hast genug gehabt M�del.`0\""
		,", but Cedrik continues to clean the glass he was working on.  \"`%You've had enough lad,`0\" he declares."=>", aber Cedrik f�hrt unbek�mmert damit fort, das Glas weiter zu polieren, an dem er gerade arbeitet. \"`%Du hast genug gehabt Bursche.`0\""
		,".  Cedrik pulls out a glass, and pours a foamy ale from a tapped barrel behind him.  "=>".  Cedrik nimmt ein Glas und schenkt sch�umendes Ale aus einem angezapften Fass hinter ihm ein. "
		,"He slides it down the bar, and you catch it with your warrior-like reflexes.  "=>"Er gibt dem Glas schwung und es rutscht �ber die Theke, wo du es mit deinen Kriegerreflexen f�ngst. "
		,"`n`nTurning around, you take a big chug of the hearty draught, and give "=>"`n`nDu drehst dich um, trinkst dieses herzhafte Ges�ff auf ex und gibst "
		," an ale-foam mustache smile.`n`n"=>" ein L�cheln mit deinem Ale-Schaum-Oberlippenbart. `n`n"
		,"You don't have enough money.  How can you have any ale if you don't have any money!?!"=>". Du hast aber nicht genug Geld bei dir. Wie kannst du ein Ale haben wollen, wenn du das Geld daf�r nicht hast?!?"
		,"Cedrik lays out a set of keys on the counter top, and tells you which key opens whose room.  The choice is yours, you may sneak in and attack any one of them."=>"Cedrik legt einen Satz Schl�ssel vor dich auf die Theke und sagt dir, welcher Schl�ssel wessen Zimmer �ffnet. Du hast die Wahl. Du k�nntest bei jedem reinschl�pfen und angreifen."
		,"Cedrik leans on the bar.  \"`%So you want to know about colors, do you?`0\" he asks."=>"Cedrik lehnt sich weiter �ber die Bar. \"`%Du willst also was �ber Farben wissen, hmm?`0\" "
		,"  You are about to answer when you realize the question was posed in the rhetoric.  "=>" Du willst gerade antworten, als du feststellst, dass das eine rhetorische Frage war. "
		,"Cedrik continues, \"`%To do colors, here's what you need to do.  First, you use a &#0096; mark "=>"Cedrik f�hrt fort: \`%Um Farbe in deine Texte zu bringen, musst du folgendes tun: Zuerst machst du ein &#0096; Zeichen "
		,"(found right above the tab key) followed by 1, 2, 3, 4, 5, 6, 7, !, @, #, $, %, ^, &.  Each of those corresponds with "=>" (Shift und die Taste links neben Backspace), gefolgt von 1, 2, 3, 4, 5, 6, 7, !, @, #, $, %, ^ oder &. Jedes dieser Zeichen entspricht "
		,"a color to look like this: `n`1&#0096;1 `2&#0096;2 `3&#0096;3 `4&#0096;4 `5&#0096;5 `6&#0096;6 `7&#0096;7 "=>"einer Farbe, die folgenderma�en aussieht: `n`1&#0096;1 `2&#0096;2 `3&#0096;3 `4&#0096;4 `5&#0096;5 `6&#0096;6 `7&#0096;7 "
		,"`% got it?`0\"  You can practice below:"=>"`% kapiert?`0\" Hier kannst du testen: "
		,"`0`n`nThese colors can be used in your name, and in any conversations you have."=>"`0`n`nDu kannst diese Farben in jedem Text verwenden, den du eingibst."
		,"\"`2I want to change my specialty,`0\" you announce to Cedrik.`n`n"=>"\"`2Ich will mein Spezialgebiet wechseln`0\", verk�ndest du Cedrik.`n`n"
		,"With out a word, Cedrik grabs you by the shirt, pulls you over the counter, and behind the "=>"Ohne ein Wort packt Cedrik dich am Hemd, zieht dich �ber die Theke und zerrt dich hinter die Fesser hinter ihm. "
		,"barrels behind him.  There, he rotates the tap on a small keg labeled \"Fine Swill XXX\""=>" Dann dreht am Hahn eines kleinen F�sschens mit der Aufschrift \"Feines Ges�ff XXX\""
		,"`n`nYou look around for the secret door that you know must be opening nearby when Cedrik "=>"`n`nDu schaust dich um und erwartest, dass irgendwo eine Gaheimt�r aufgeht, aber nichts passiert. Stattdessen "
		,"rotates the tap back, and lifts up a freshly filled foamy mug of what is apparently his fine swill, blue-green "=>"dreht Cedrik den Hahn wieder zur�ck und hebt einen frisch mit seinem vermutlich besten Gebr�u gef�llten Krug. Das Zeug sch�umt und ist von blau-gr�nlicher Farbe."
		,"tint and all."=>""
		,"`n`n\"`3What?  Were you expecting a secret room?`0\" he asks.  \"`3Now then, you must be more "=>"`n`n\"`3Was? Du hast einen geheimen Raum erwartet?`0\", fragt er dich. \"`3Also dann solltest du noch "
		,"careful about how loudly you say that you want to change your specialty, not everyone looks "=>"besser aufpassen, wie laut du sagst, dass du deine F�higkeiten �ndern willst. Nicht jeder sieht "
		,"favorably on that sort of thing.`n`n`0\"`3What new specialty did you have in mind?`0\""=>"mit Wohlwollen auf diese Art von Dingen.`n`nWelches neue Spezialgebiet hast du dir denn gedacht?`0\""
		,"\"`3Ok then,`0\" Cedrik says, You're all set.`n`n\"`2That's it?`0\" you ask him."=>"\"`3Ok, du hast es.`0\"`n`n \"`2Das war schon alles?`0\", fragst du ihn."
		,"`n`n\"`3Yep.  What'd you expect, some sort of fancy arcane ritual???`0\"  Cedrik "=>"`n`nCedrik f�ngt laut an zu lachen: \"`3Jup. Was hasten erwartet? Irgendne Art fantastisches und geheimnisvolles Ritual???`0\" "
		,"begins laughing loudly.  \"`3You're all right, kid... just don't ever play poker, eh?`0"=>"\"`3Du bist in Ordnung, Kleiner... spiel nur niemals Poker, ok?`0\""
		,"`n`n\"`3Oh, one more thing.  Your old use points and skill level still apply to that skill, "=>"`n`n\"Ach, nochwas. Obwohl du dein K�nnen in deiner alten Fertigkeit jetzt nicht mehr einsetzen kannst, hast du es immer noch, "
		,"you'll have to build up some points in this one to be very good at it.`0\""=>"deine neue Fertigkeit wirst du trainieren m�ssen, um wirklich gut darin zu sein.`0\""
		,"\"Aah, so that's how it is,\" Cedrik says as he puts the key he had retrieved back on to its hook "=>"\"Aah, so ist das also.\", sagt Cedrik und h�ngt den Schl�ssel, den er gerade geholt hat, wieder an seinen Haken hinter der Theke. "
		,"behind his counter.  Perhaps you'd like to get sufficient funds before you attempt to engage in "=>" Vielleicht solltest du erstmal f�r das n�tige Kleingeld sorgen, bevor du dich am "
		,"local commerce."=>"�rtlichen Handel beteiligst."
		,array(
			"You stroll over to the bartender and request a room.  He eyes you up and says that it will cost "=>"Du trottest zum Barkeeper und fragst nach einem Zimmer. Er betrachtet dich und sagt, das kostet "
			," for the night."=>" f�r die Nacht."
			,"`n`nYou debate the issue, not wanting to part with your money when the fields offer a place to sleep, "=>"`n`nDu willst dich nicht von deinem Gold trennen und f�ngst an dar�ber zu debattieren, dass man in den Feldern auch kostenlos "
			,"however, you realize that the inn is a considerably safer place to sleep, it is far harder for vagabonds to get you "=>" schlafen k�nnte. Schlie�lich siehst du aber ein, dass ein Zimmer in der Kneipe vielleicht der sicherere Platz zum Schlafen ist, da es schwieriger f�r Herumstreicher sein d�rfte, "
			,"in your room while you sleep."=>" in einen verschlossenen Raum einzudringen."
			,"Since you are such a fine person, he also offers you a rate of `\$"=>"Weil du so eine nette Person bist, bietet er dir zum Preis von `\$"
			,"`0 gold if you pay direct from the bank which includes a "=>"`0 Gold auch an, direkt von der Bank zu bezahlen. Der Preis beinhaltet "
			,"% transaction fee."=>"% �berweisungsgeb�hr."
			," gold transaction fee."=>" Gold �berweisungsgeb�hr."
		)
		,"You feel exhausted!  "=>"Du f�hlst dich ausgelaugt!  "
		,"`n`n`^You gain a charm point!"=>"`n`n`^Du erh�ltst einen Charmepunkt!"
		,"`n`n`\$You LOSE a charm point!"=>"`n`n`\$Du VERLIERST einen Charmepunkt!"
		,"`n`n`^You LOSE a charm point!"=>"`n`n`^Du VERLIERST einen Charmepunkt!"
		,"`n`n`0You gain a forest fight!"=>"`n`n`0Du erh�ltst einen Waldkampf dazu!"
		,"You don't have "=>"Du hast keine "
		,"You entered "=>"Deine Eingabe: "
		,"It looks like "=>"So sieht es aus: "
		,"You already paid for a room for the day."=>"Du hast heute schon f�r ein Zimmer bezahlt."
		,"Go to room"=>"Gehe ins Zimmer"
		,"`i(Attacked too recently)`i"=>"`i(Erst k�rzlich angegriffen)`i" 
		,"Refresh the list"=>"Liste aktualisieren"
		// part from "common.php"
		,"Previous"=>"Vorherige"
		,"Refresh"=>"Aktualisieren"
		,"Next"=>"N�chste"
		,"says,"=>"sagt:"
		// end of common
		,"Continue"=>"Weiter"
		,"Give him"=>"Gib ihm"
		,"Who's upstairs?"=>"Wer schl�ft oben?"
		,"Tell me about colors"=>"Erz�hl mir was �ber Farben"
		,"Switch specialty"=>"Spezialgebiet wechseln"
		,"Return to the inn"=>"Zur�ck an die Bar"
		,"Things to do"=>"Was machst du?"
		,"Flirt with Violet"=>"Flirte mit Violet"
		,"Chat with Violet"=>"Quatsche mit Violet"
		,"Talk to Seth the Bard"=>"Rede mit Seth dem Barden"
		,"Converse with patrons"=>"Mit Freunden unterhalten"
		,"Talk to Cedrik the Barkeep"=>"Spreche mit Barkeeper Cedrik"
		,"Talk to Dag Durnick"=>"Mit Dag Durnick sprechen"
		,"Other"=>"Sonstiges"
		,"Get a room (log out)"=>"Zimmer nehmen (Log out)"
		,"Wink"=>"Zwinkern"
		,"Kiss her hand"=>"Handkuss"
		,"Peck her on the lips"=>"K�sschen auf die Lippen"
		,"Sit her on your lap"=>"Setze sie auf deinen Scho�"
		,"Grab her backside"=>"Greif ihr an den Hintern"
		,"Carry her upstairs"=>"Trag sie nach oben"
		,"Marry her"=>"Heirate sie"
		,"Flutter Eyelashes"=>"Mit den Wimpern klimpern"
		,"Drop Hanky"=>"Taschentuch fallenlassen"
		,"Ask the bard to buy you a drink"=>"Den Barden nach einem Drink fragen"
		,"Ask him to buy you a drink"=>"Frage ihn nach einem Drink"
		,"Kiss the bard soundly"=>"K�sse den Barden ger�uschvoll"
		,"Kiss him soundly"=>"K�sse ihn ger�uschvoll"
		,"Completely seduce the bard"=>"Den Barden komplett verf�hren"
		,"Marry him"=>"Heirate ihn!"
		,"Flirt with Seth"=>"Flirte mit Seth"
		,"Ask Seth to entertain"=>"Fordere Seth auf, dich zu unterhalten"
		,"Ask Seth how he likes your new "=>"Frage Seth nach seiner Meinung �ber dein(e/n) "
		,"Gossip"=>"Tratsch"
		,"Bribe"=>"Bestechen"
		,"Gems"=>"Edelsteine"
		,array(
			"Show him your coupons for "=>"Zeige ihm deine Gutscheine f�r "
			," inn stays"=>" �bernachtungen"
		)
		,array(
			"Ask if your "=>"Frage, ob dich dein "
			," makes you look fat"=>" dick aussehen l�sst"
		)
		,"Dark Arts"=>"Dunkle K�nste"
		,"Mystical Powers"=>"Mystische Kr�fte"
		,"Thieving Skills"=>"Diebeskunst"
		,array(
			"`n`n`7You now feel "=>"`n`n`7Du f�hlst dich "
			,"stone cold sober"=>"absolut n�chtern"
			,"quite sober"=>"ziemlich n�chtern"
			,"barely buzzed"=>"kaum berauscht"
			,"pleasantly buzzed"=>"leicht berauscht"
			,"almost drunk"=>"fast betrunken"
			,"barely drunk"=>"leicht betrunken"
			,"solidly drunk"=>"ordentlich betrunken"
			,"sloshed"=>"besoffen"
			,"really hammered"=>"richtig zugedr�hnt"
			,"hammered"=>"zugedr�hnt"
			,"almost unconscious"=>"fast bewusstlos"
			,"`&You feel vigorous"=>"`&Du f�hlst dich lebhaft"
			,"`&You feel healthy!"=>"`&Du f�hlst dich gesund"
		)
		,"Return to the village"=>"Zur�ck zum Dorf"
		,"Add to the conversation?"=>"Beteilige dich an der Unterhaltung:"
		,array(
			"And what do you wish for?`n"=>"`nUnd was willst du daf�r?`n"
			," Charm`n"=>" Charme`n"
			," Vitality`n"=>" Lebenskraft`n"
			," Health`n"=>" Gesundheit`n"
			," Forgetfulness"=>" Vergesslichkeit`n"
		)
		,array(
			"`#You place "=>"`#Du platzierst "
			," gems on the counter."=>" Edelsteine auf der Theke."
		)
		,array(
			"`\$You were slain in "=>"`\$Du wurdest im "
			,"`\$ by `%"=>"`$ von `%"
			,"`\$.  They cost you 5% of your experience, and took any gold you had.  Don't you think it's time for some revenge?"=>"`\$ besiegt und um alles Gold beraubt, das du bei dir hattest. Das kostet dich 5% deiner Erfahrung. Meinst du nicht es ist Zeit f�r Rache?"
		)
		,array(
			"Pay "=>"Zahle "
			," gold from bank"=>" Gold von der Bank"
		)
		,"dragons."=>"Drachen. "
		,"fine ales."=>"leckeres Ale. "
		,"the air."=>"die Luft."
		,"lips."=>"Lippen."
		,"Give"=>"Weggeben"
		,"Attack"=>"Angreifen"
		);
		break;
	case "list.php":
		$replace = array(
		"Return to the village"=>"Zur�ck zum Dorf"
		,"Return to the graveyard"=>"Zur�ck zum Friedhof"
		,"Warriors Currently Online"=>"Diese Krieger sind gerade online"
		,"Warriors in the realm (Page "=>"Krieger in dieser Welt (Seite "
		,"Currently Online"=>"Gerade online"
		,"Login Screen"=>"zum Login"
		,array(
			"Search by name: "=>"Nach Name suchen: "
			,"Search"=>"Suchen"
		)
		,"`\$Too many names match that search.  Showing only the first 100.`0`n"=>"`\$Es treffen zu viele Namen auf diese Suche zu. Nur die ersten 100 werden angezeigt.`0`n"
		,array(
			"Alive"=>"Status"
			,"Location"=>"Ort"
			,"Sex"=>"Geschlecht"
			,"Last on"=>"Zuletzt online"
			,"`!Female`0"=>"`!Weiblich`0"
			,"`!Male`0"=>"`!M�nnlich`0"
			,"`3Boar's Head Inn`0"=>"`3Zimmer in Kneipe`0"
			,"`3The Fields`0"=>"`3Die Felder`0"
			,"Yesterday"=>"Gestern"
			," days"=>" Tage"
			,"1 day"=>"1 Tag"
			,"Today"=>"Heute"
			,"Now"=>"Jetzt"
			,"`1Yes`0"=>"`1Lebt`0"
			,"`4No`0"=>"`4Tot`0"
		)
		,"Write Mail"=>"Mail schreiben"
		,"Pages"=>"Alle Krieger"
		// ,"Page "=>"Seite "	// translates the charname title "Page" into "Seite" as well, so keep remarked.
		);
		break;
	case "logdnet.php":
		$replace = array(
			"Return to the login page"=>"Zur�ck zum Login"
			,"`@Below are a list of other LoGD servers that have registered with the LoGD Net."=>"`@Eine Liste mit anderen LoGD Servern, die beim LoDG-Netzwerk registriert sind.`n`n"
		);
		break;
	case "mail.php":
		$replace = array(
		"`\$`bYou cannot delete zero messages!  What does this mean?  You pressed \"Delete Checked\" but there are no messages checked!  What sort of world is this that people press buttons that have no meaning?!?`b`0"=>"`\$`bDu kannst 0 Nachrichten nicht l�schen! Was das hei�t? Du hast \"Markierte l�schen\" geklickt, aber es sind keine Nachrichten markiert. Was f�r eine Welt ist das nur, in der Leute Kn�pfe ohne Funktion dr�cken?!?`b`0"
		,"You cannot send that person mail, their mailbox is full!"=>"Die Mailbox dieser Person ist voll! Du kannst keine Nachricht schicken."
		,"Your message was sent!"=>"Deine Nachricht wurde gesendet!"
		,"Could not find the recipient, please try again."=>"Kontne den Empf�nger nicht finden. Bitte versuche es nochmal."
		,"`iAww, you have no mail, how sad.`i"=>"`iOoooh, du hast keine Mails. Wie schade.`i"
		,"Eek, no such message was found!"=>"Uff, so eine Nachricht wurde nicht gefunden!"
		,"You cannot reply to a system message.`n"=>"Du kannst nicht auf eine Systemnachricht antworten.`n"
		,"Could not find that person.`n"=>"Konnte diese Person nicht finden.`n"
		,array(
			"`^You have received a money transfer!`0"=>"`^Du hast eine �berweisung erhalten!`0"
			,"`6 has transferred `^"=>"`6 hat dir `^"
			,"`6 gold to your bank account!"=>"`6 Gold auf dein Bankkonto �berwiesen!"
		)
		,array(
			"`n`n`iYou have "=>"`n`n`iDu hast "
			," messages in your inbox.`nYou may only have "=>" Nachrichten in deiner Mailbox`nDu kannst h�chstens "
			," messages in your inbox.  `nMessages are deleted after "=>" Nachrichten hier speichern.`nNachrichten werden nach "
			," days"=>" Tagen gel�scht."
		)
		,"Write"=>"Mail schreiben"
		,"Check All"=>"Alle markieren"
		,"Delete Checked"=>"Markierte l�schen"
		,"`b`2From:`b `^"=>"`b`2Absender:`b `^"
		,"Subject: "=>"Betreff: "
		,"Address:"=>"Empf�nger:"
		,"Body:"=>"Text:"
		,array(
			"Reply"=>"Antworten"
			,"Del"=>"L�schen"
		)
		,array(
			"Old"=>"Alt"
			,"New"=>"Neu"
		)
		);
		break;
	case "motd.php":
		$replace = array(
		"You've attempted to defile the gods.  You are struck with a wand of forgetfulness.  Some of what you knew, you no longer know."=>"Du hast versucht die G�tter zu betr�gen. Du wurdest mit Vergessen bestraft. Einiges von dem, was du einmal gewusst hast, weisst du nicht mehr."
		,"Please see the beta message below."=>"Bitte beachte die Hinweise ganz unten."
		,"Are you sure you want to delete this item?"=>"Bist du sicher, dass dieser Eintrag gel�scht werden soll?"
		,"For those who might be unaware, this website is still in beta mode.  I'm working on it when I have time, which generally means a couple of changes a week.  Feel free to drop suggestions, I'm open to anything :-)"=>"F�r alle, die es noch nicht bemerkt haben: Diese Seite ist im BETA Status! MightyE und sein Team arbeiten daran, wenn sie Zeit haben. Seine �nderungen werden hier nach und nach �bernommen. W�nsche und Anregungen werden jederzeit angenommen. :-)"
		,"Interject your own commentary?"=>"Hinterlasse deinen eigenen Kommentar:"
		,"`@Commentary:`0`n"=>"`@Kommentare:`0`n"
		,array(
			"Add Poll"=>"Umfrage erstellen"
			,"Add MoTD"=>"MoTD hinzuf�gen"
		)
		,"`bPoll: "=>"`bUmfrage: "
		// part from "common.php"
		,"Previous"=>"Vorherige"
		,"Refresh"=>"Aktualisieren"
		,"Next"=>"N�chste"
		,"says,"=>"sagt:"
		// end of common
		);
		break;
	case "newday.php":
		$replace = array(
		"`2As a troll, and having always fended for yourself, the ways of battle are not foreign to you.`n`^You gain an attack point!"=>"`2Als Troll warst du immer auf dich alleine gestellt. Die M�glichkeiten des Kampfs sind dir nicht fremd.`n`^Du erh�ltst einen zus�tzlichen Punkt auf deinen Angriffswert!"
		,"`^As an elf, you are keenly aware of your surroundings at all times, very little ever catches you by surprise.`nYou gain a defense point!"=>"`^Als Elf bist du dir immer allem bewusst, was um dich herum passiert. Nur sehr wenig kann dich �berraschen.`nDu bekommst einen zus�tzlichen Punkt auf deinen Verteidigungswert!"
		,"`&As a human, your size and strength permit you the ability to effortlessly wield weapons, tireing much less quickly than other races.`n`^You gain an extra forest fight each day!"=>"`&Deine Gr��e und St�rke als Mensch erlaubt es dir, Waffen ohne gro�e Anstrengungen zu f�hren und dadurch l�nger durchzuhalten als andere Rassen.`n`^Du hast jeden Tag einen zus�tzlichen Waldkampf!"
		,"`#As a dwarf, you are more easily able to identify the value of certain goods.`n`^You gain extra gold from forest fights!"=>"`#Als Zwerg f�llt es dir leicht, den Wert bestimmter G�ter besser einzusch�tzen.`n`^Du bekommst mehr Gold durch Waldk�mpfe!"
		,"Where do you recall growing up?`n`n"=>"Wo bist du aufgewachsen?`n`n"
		,"In the swamps of Glukmoore</a> as a `2troll`0, fending for yourself from the very moment you crept out of your leathery egg, slaying your yet unhatched siblings, and feasting on their bones.`n`n"=>"In den S�mpfen von Glukmoore</a> als `2Troll`0, auf dich alleine gestellt seit dem Moment, als du aus der lederartigen H�lle deines Eis geschl�pft bist und aus den Knochen deiner ungeschl�pften Geschwister ein erstes Festmahl gemacht hast.`n`n"
		,"High among the trees</a> of the Glorfindal forest, in frail looking elaborate `^Elvish`0 structures that look as though they might collapse under the slightest strain, yet have existed for centuries.`n`n"=>"Hoch �ber den B�umen</a> des Waldes Glorfindal, in zerbrechlich wirkenden, kunstvoll verzierten Bauten der `^Elfen`0, die so aussehen, als ob sie beim leisesten Windhauch zusammenst�rzen w�rden und doch schon Jahrhunderte �berdauern.`n`n"
		,"On the plains in the city of Romar</a>, the city of `&men`0; always following your father and looking up to his every move, until he sought out the `@Green Dragon`0, never to be seen again.`n`n"=>"Im Flachland in der Stadt Romar</a>, der Stadt der `&Menschen`0. Du hast immer nur zu deinem Vater aufgesehen und bist jedem seiner Schritte gefolgt, bis er auszog den `@Gr�nen Drachen`0 zu vernichten und nie wieder gesehen wurde.`n`n"
		,"Deep in the subterranean strongholds of Qexelcrag</a>, home to the noble and fierce `#Dwarven`0 people whose desire for privacy and treasure bears no resemblance to their tiny stature.`n`n"=>"Tief in der Unterirdischen Festung Qexelcrag</a>, der Heimat der edlen und starken `#Zwerge`0, deren Verlangen nach Besitz und Reichtum in keinem Verh�ltnis zu ihrer K�rpergr�sse steht.`n`n"
		,"Choose your Race"=>"W�hle deine Rasse"
		,"Growing up as a child, you remember:`n`n"=>"Du erinnerst dich, dass du als Kind:`n`n"
		,"Killing a lot of woodland creatures (`\$Dark Arts`0)"=>"viele Kreaturen des Waldes get�tet hast (`\$Dunkle K�nste`0)"
		,"Dabbling in mystical forces (`%Mystical Powers`0)"=>"mit mystischen Kr�ften experimentiert hast (`%Mystische Kr�fte`0)"
		,"Stealing from the rich and giving to yourself (`^Thievery`0)"=>"von den Reichen gestohlen und es dir selbst gegeben hast (`^Diebeskunst`0)"
		,"`5Growing up, you recall killing many small woodland creatures, insisting that they were "=>"`5Du erinnerst dich, dass du damit aufgewachsen bist, viele kleine Waldkreaturen zu t�ten, weil du davon �berzeugt warst, sie haben sich gegen dich verschworen. "
		,"plotting against you.  Your parents, concerned that you had taken to killing the creatures "=>"Deine Eltern haben dir einen idiotischen Zweig gekauft, weil sie besorgt dar�ber waren, dass du die Kreaturen des Waldes mit "
		,"barehanded, bought you your very first pointy twig.  It wasn't until your teenage years that "=>"blo�en H�nden t�ten musst. Noch vor deinem Teenageralter hast du damit begonnen, "
		,"you began performing dark rituals with the creatures, dissapearing into the forest for days "=>"finstere Rituale mit und an den Kreaturen durchzuf�hren, wobei du am Ende oft tagelang im Wald verschwunden bist. "
		,"on end, no one quite knowing where those sounds came from."=>"Niemand ausser dir wusste damals wirklich, was die Ursache f�r die seltsamen Ger�usche aus dem Wald war... "
		,"`3Growing up, you remember knowing there was more to the world than the physical, and what you "=>"`3Du hast schon als Kind gewusst, dass diese Welt mehr als das physische bietet, woran du herumspielen konntest. "
		,"could place your hands on.  You realized that your mind itself, with training, could be turned "=>"Du hast erkannt, dass du mit etwas Training deinen Geist selbst in eine Waffe "
		,"in to a weapon.  Over time, you began to control the thoughts of small creatures, commanding "=>"verwandeln kannst. Mit der Zeit hast du gelernt, die Gedanken kleiner Kreaturen zu kontrollieren und ihnen deinen "
		,"them to do your bidding, and also to begin to tap in to the mystical force known as mana, "=>"Willen aufzuzwingen. Du bist auch auf die mystische Kraft namens Mana gestossen, "
		,"which could be shaped in to numerous elemental forms, fire, water, ice, earth, wind, and also "=>"die du in die Form von Feuer, Wasser, Eis, Erde, Wind bringen, und sogar "
		,"used as a weapon against your foes."=>"als Waffe gegen deine Feinde einsetzen kannst. "
		,"`6Growing up, you recall discovering that a casual bump in a crowded room could earn you "=>"`6Du hast schon sehr fr�h bemerkt, dass ein gew�hnlicher Rempler im Gedr�nge dir das Gold "
		,"the coin purse of someone otherwise more fortunate than you.  You also discovered that "=>"eines von Gl�ck bevorzugteren Menschen einringen kann. Ausserdem hast du entdeckt, "
		,"the back side of your enemies were considerably more prone to a narrow blade than the "=>"dass der R�cken deiner Feinde anf�lliger gegen kleine Klingen ist, als "
		,"front side was to even a powerful weapon."=>"deren Vorderseite gegen m�chtige Waffen. "
		,"You earn one dragon point each time you slay the dragon.  Advancements made by spending dragon points are permanent!"=>"Du bekommst 1 Drachenpunkt pro get�tetem Drachen. Die �nderungen der Eigenschaften durch Drachenpunkte sind permanent."
		,"It is a New Day!"=>"Ein neuer Tag hat begonnen!"	
		,"You feel refreshed enough to take on the world!`n"=>"Du f�hlst dich frisch und bereit f�r die Welt!`n"
		,"`2Today's interest rate: `^0% (Bankers in this village only give interest to those who work for it)`n"=>"Dein heutiger Zinssatz betr�gt `^0% (Die Bank gibt nur den Leuten Zinsen, die daf�r arbeiten)`n"
		,"`2Today's interest rate: `^"=>"`2Heutiger Zinssatz: `^"
		,"`2Gold earned from interest: `^"=>"`2Durch Zinsen verdientes Gold: `^"
		,"`2Interest Accrued on Dept: `^"=>"`2Anfallende Zinsen auf Schulden: `^"
		,"`2Hitpoints have been restored to `^"=>"`2Deine Gesundheit wurde wiederhergestellt auf `^"
		,"`n`%You're  married,  so there's no reason to keep up that perfect image, and you let yourself go a little today.`n"=>"`n`%Du bist verheiratet, es gibt also keinen Grund mehr, das perfekte Image aufrecht zu halten. Du l�sst dich heute ein bisschen gehen.`n"
		,"`bWhen  you  wake  up, you find a note next to you, reading`n`5Dear "=>"`bAls du heute aufwachst, findest du folgende Notiz neben dir im Bett:`n`5Liebste(r) "
		,"`5,`nDespite  many  great  kisses, I find that I'm simply no longer attracted to you the way I used to be.`n`n"=>"`5,`nTrotz vieler gro�artiger K�sse f�hle ich mich einfach nicht mehr zu dir hingezogen wie es fr�her war.`n`n"
		,"Call  me fickle, call me flakey, but I need to move on.  There are other warriors in the village, and I think"=>"Nenne mich wankelm�tig, aber ich muss weiterziehen. Es gibt andere Krieger in diesem Dorf und ich glaube, "
		,"some of them are really hot.  So it's not you, it's me, etcetera etceterea."=>"einige davon sind wirklich heiss. Es liegt also nicht an dir, sondern an mir, usw. usw."
		,"`n`nNo hard feelings, Love,`nSeth`b`n"=>"`n`nTrauer mir nicht nach, in Liebe,`nSeth`b`n"
		,"`n`nNo hard feelings, Love,`nViolet`b`n"=>"`n`nTrauer mir nicht nach, in Liebe,`nViolet`b`n"
		,"`&Coming off of a hangover, you lose 1 forest fight today"=>"`&Wegen deines schrecklichen Katers wird dir 1 Runde f�r heute abgezogen"
		,"`n`&Because you are human, you gain `^1`& forest fight for today!`n`0"=>"`n`&Weil du ein Mensch bist, bekommst du `^1`& Waldkampf zus�tzlich!`n`0"
		,"`@You gain an extra turn from points spent on `^"=>"`@Du bekommst eine Extrarunde f�r die Punkte auf `^"
		,"  This buy has expired.`n"=>"  Dieser Kauf ist damit abgelaufen.`n"
		,"`2Turns for today set to"=>"`2Runden f�r den heutigen Tag: " 
		,array(
			"`n`2You gain `^"=>"`nDu erh�hst deine Waldk�mpfe um `^"
			,"`2 forest fights from spent dragon points"=>"`2 durch verteilte Drachenpunkte "
		)
		,array(
			"`n`n`)You have been haunted by "=>"`n`n`)Du wurdest von "
			,"`), as a result, you lose a forest fight!"=>"`) erwischt und verlierst eine Runde!"
		)
		,array(
			"`n`@Golinda will be willing to see you for "=>"`n`@Golinda ist bereit, dich noch "
			," more days."=>" Tage weiter zu behandeln."
			," more day."=>" Tag zu behandeln."
		)
		,"`n`@Golinda will no longer treat you."=>"`n`@Golinda wird dich nicht l�nger behandeln."
		,array(
			"You have `^"=>"Du hast noch `^"
			,"`@ unspent dragon points.  How do you wish to spend them?`n`n"=>"`@ Drachenpunkte �brig. Wie willst du sie einsetzen?`n`n"
			,"`@ days left on this buy.`n"=>"`@ Tage von diesem Kauf �brig.`n"
		)
		,array(
			"`@You are resurrected!  This is your "=>"`@Du bist wiedererweckt worden!  Dies ist deine "
			," resurrection.`0`n"=>" Wiederauferstehung.`0`n"
		)
		,array(
			"`2For being interested in `&"=>"`2F�r dein Spezialgebiet `&"
			,"`2, you receive "=>"`2 erh�ltst du zus�tzlich "
			," extra `&"=>" Anwendung(en) in `&"
			,"`2 use for today.`n"=>"`2 f�r heute.`n"
			,"Thievery"=>"Diebesk�nste"
			,"Dark Arts"=>"Dunkle K�nste"
			,"Mystical Powers"=>"Mystische Kr�fte"
		)
		,array(
			"`n`&You strap your `%"=>"`n`&Du schnallst dein(e/n) `%"
			,"`n`&Because you have a "=>"`n`&Weil du ein(e/n) "
			,", you gain `^"=>" besitzt, bekommst du `^"
			," forest fights for today!`n`0"=>" Runden zus�tzlich.`n`0"
			,"`& to your back"=>"`& auf den R�cken "
			," and head out for some adventure.`0"=>" und ziehst los ins Abenteuer.`0"
		)
		,array(
			"Resurrected"=>"Auferstanden"
			,"Very Low"=>"Sehr schlecht"
			,"Low"=>"Schlecht"
			,"Very High"=>"Sehr gut"
			,"High"=>"Gut"
			,"`n`2You are in `^"=>"`n`2Dein Geist und deine Stimmung ist heute `^"
			,"`2 spirits today!`n"=>"`2!`n"
			,"`2As a result, you `^"=>"`2Deswegen `^"
			,"gain "=>"bekommst du zus�tzlich "
			,"lose "=>"verlierst du "
			," forest fights`2 for today!`n"=>" Runden`2 f�r heute.`n"
		)
		,array(
			"You were slain in the "=>"Im "
			," by `%"=>" hat dich `%"
			,"`\$.  They cost you 5% of your experience, and took any gold you had.  Don't you think it's time for some revenge?"=>"`\$ get�tet und dein Gold genommen. Ausserdem hast du 5% deiner Erfahrungspunkte verloren. Meinst du nicht auhc, es ist Zeit f�r Rache? "
		)
		,array(
			"You open your eyes to discover that a new day has been bestowed upon you, it is your `^"=>"Du �ffnest deine Augen und stellst fest, dass dir ein neuer Tag geschenkt ist. Dies ist dein `^"
			,"`0 day.  "=>"`0 Tag in diesem Land.  "
		)
		// part from "common.php"
		,"`^The gods are angry!"=>"`^Die G�tter sind w�tend!"
		,"`^The gods have grown bored with teasing you."=>"`^Es ist den G�ttern langweilig geworden, dich zu qu�len."
		,array(
			"`7The gods curse you, causing `^"=>"`7Die G�tter verfluchen dich und machen dir "
			,"`7 damage!"=>"`7 Schaden!"
		)
		,"`7The gods have elected not to tease you just now."=>"`7Die G�tter haben beschlossen, dich erstmal nicht zu qu�len."
		,"`6The gods are still angry with you!"=>"`6Die G�tter sind dir immer noch b�se!"
		,"For attempting to defile the gods, you have been smitten down!`n`n"=>"F�r den Versuch, die G�tter zu betr�gen, wurdest du niedergeschmettert!`n`n"
		,"`\$Ramius, Overlord of Death`) appears before you in a vision, siezing your mind with his, and wordlessly telling you that he finds no favor with you.`n`n"=>"`\$Ramius, der Gott der Toten`) erscheint dir in einer Vision. Daf�r, dass du versucht hast, deinen Geist mit seinem zu messen, sagt er dir wortlos, dass du keinen Gefallen mehr bei ihm hast.`n`n"
		// end of common
		,"`&Human`0"=>"`&Mensch`0"
		,"`#Dwarf`0"=>"`#Zwerg`0"
		,"Continue"=>"Weiter"
		,"Max Hitpoints + 5"=>"Max Lebenspunkte +5"
		,"Forest Fights + 1"=>"Waldk�mpfe +1"
		,"Attack + 1"=>"Angriff + 1"
		,"Defense + 1"=>"Verteidigung + 1"
		);
		break;
	case "news.php":
		$replace = array(
		"`1`b`c Nothing of note happened this day.  All in all a boring day. `c`b`0"=>"`1`b`c Es ist nichts erw�hnenswertes passiert. Alles in allem bisher ein langweiliger Tag. `c`b`0"
		// addnews for news
		,"`5 has been slain for trying to steal from `!MightyE`5's Weapons Shop."=>"`5 wurde beim Versuch in `!MightyE`5's Waffenladen zu stehlen niedergemetzelt."
		,"`5 has been slain by `!MightyE`5 for trying to steal from `#Pegasus`5' Armor Wagon."=>"`5 wurde von `!MightyE`5 f�r den Versuch, etwas aus `#Pegasus`5' R�stungsladen zu stehlen, erw�rgt."
		," was smote down for attempting to defile the gods (they tried to hack superuser pages)."=>" wurde f�r den Versuch, die G�tter zu besudeln, zu Tode gequ�lt! (Hackversuch gescheitert)"
		," and `5Violet`@ were seen heading up the stairs in the inn together."=>" und `5Violet`@ wurden dabei beobachtet, wie sie gemeinsam die Treppen in der Kneipe nach oben gingen. "
		," and `%Violet`& are joined today in joyous matrimony!!!"=>" und `%Violet`& haben heute den Bund der Ehe geschlossen!!!"
		," and `^Seth`& are joined today in joyous matrimony!!!"=>" und `^Seth`& haben heute den Bund der Ehe geschlossen!!!"
		," and `^Seth`@ were seen heading up the stairs in the inn together."=>" und `^Seth`@ wurden dabei beobachtet, wie sie gemeinsam die Treppen in der Kneipe nach oben gingen. "
		,"encountered strange powers in the forest, and was not seen again."=>"hat seltsame Kr�fte im Wald entdeckt und wurde nie wieder gesehen."
		,"has been gone for a while, and those who have looked for him do not come back."=>"ist f�r eine Weile verschwunden und jene, welche gesucht haben, kommen nicht zur�ck."
		,"'s body was found lying in an empty clearing."=>"'s lebloser K�rper wurde auf einer leeren Lichtung gefunden."
		," body was found on an altar in the woods."=>" K�rper wurde auf einem Altar im Wald gefunden."
		," remains were found charred upon an altar."=>" verkohlte �berreste wurden auf einem Altar gefunden."
		," body was found... being feasted on by rabbits!"=>" K�rper wurde gefunden... angeknabbert von Kaninchen!"
		,"weapons were found by a giant plant, but that's all anyone knows of what happend to her."=>"Waffen wurden bei einer gigantischen Pflanzen gefunden, aber das ist auch schon alles, was man �ber ihr Schicksal weiss."
		,"weapons were found by a giant plant, but that's all anyone knows of what happend to him."=>"Waffen wurden bei einer gigantischen Pflanzen gefunden, aber das ist auch schon alles, was man �ber sein Schiksal weiss."
		,"head was found... on a spike near an altar for the Gods."=>"Kopf wurde gefunden... auf einem Spiess in der N�he eines G�tteraltars."
		,"remains weren't very pretty when found..."=>"sterbliche �berreste waren nicht sehr ansehnlich, als sie gefunden wurden..."
		,array(
			"The charred and twisted body of "=>"Der verbrannte und verdrehte K�rper von "
			," was found impaled by "=>" wurde gefunden - durchbohrt mit "
		)
		,"was slain by the gods because he was filled with greed!"=>"wurde von den G�ttern geschlagen, da er von Gier zerfressen war!"
		,"was slain by the gods because she was filled with greed!"=>"wurde von den G�ttern geschlagen, da sie von Gier zerfressen war!"
		,"body was found in the woods, completely stripped of all gold."=>"K�rper wurde im Wald gefunden, allen Goldes beraubt."
		,"came home from the forest, a bit less than what she used to be."=>"kam aus dem Wald heim - etwas schw�cher als sie fr�her war."
		,"came home from the forest, a bit less than what he used to be."=>"kam aus dem Wald heim - etwas schw�cher als er fr�her war."
		,"committed suicide."=>"beging Selbstmord."
		,array(
			"Seth has left "=>"Seth hat "
			,"Violet has left "=>"Violet hat "
			,"`\$ to pursue \"other interests.\""=>"`\$ verlassen, um \"anderen Interessen\" nachzugehen."
		)
		,array(
			"`2Always cool, "=>"`2Cool, "
			," was seen walking around "=>" lief mit einem langen St�ck Klopapier an "
			," with a long string of toilet paper stuck to her foot.`n"=>"ihrem Fu� herum.`n"
			," with a long string of toilet paper stuck to his foot.`n"=>"seinem Fu� herum.`n"
		)
		,"was unmade by the gods"=>"wurde von den G�ttern aufgel�st"
		,array(
			" has earned the title `&"=>" hat sich den Titel `&"
			,"`# for having slain the `@Green Dragon`& `^"=>"`# f�r den `^"
			,"`# times!"=>"`#ten erfolgreichen Kampf gegen den `@Gr�nen Drachen`# verdient!"
		)
		,"has been resurrected by `\$Ramius`&."=>"wurde von `\$Ramius`& wiedererweckt."
		,"`) unsuccessfully haunted `7"=>"`) hat erfolglos heimgesucht `7"
		,"`) haunted `7"=>"`) hat heimgesucht `7"
		," was penalized for attempting to defile the gods."=>" wurde f�r den Versuch, die G�tter zu betr�gen, bestraft."
		,array(
			"`3 was slain attempting to rescue a prince from"=>"`3 starb beim Versuch, einen Prinzen aus "
			,"`3 was slain attempting to rescue a princess from"=>"`3 starb beim Versuch, eine Prinzessin aus "
			,"Wyvern Keep"=>"der Lindwurmfestung`3 zu befreien"
			,"Castle Slaag"=>"der Burg Slaag`3 zu befreien"
			,"Draco's Dungeon"=>"Draco's Kerker `3zu befreien"
		)
		,array(
			"`3 was hunted down by their master `^"=>"`3 wurde von Meister `^"
			,"`3 for being truant."=>"`3 wegen �berheblichkeit gejagt und gestellt."
		)
		,array(
			"`5 has been slain when "=>"`5 wurde geschlagen, als "
	 		," has slain the hideous creature known as `@The Green Dragon`&.  Across all the lands, people rejoice!"=>" hat die abscheuliche, als `@Gr�ner Drachen`& bekannte Kreatur besiegt. �ber alle L�nder freuen sich die Menschen!"
			,"His bones now litter the cave entrance, just like the bones of those who came before.`n"=>"Seine Knochen liegen nun am Eingang der H�hle, genau wie die der Krieger, die vorher kamen.`n"
			,"Her bones now litter the cave entrance, just like the bones of those who came before.`n"=>"Ihre Knochen liegen nun am Eingang der H�hle, genau wie die der Krieger, die vorher kamen.`n"
			," has been slain in the forest by "=>" wurde im Wald niedergemetzelt von "
			,"`) has been defeated in the graveyard by "=>"`) wurde auf dem Friedhof erniedrigt von "
			,"encountered `@The Green Dragon`5!!!  "=>"dem `@Gr�nen Drach�n`5 begegnete!!!  "
			,"`5 has challenged their master, "=>"`5 hat Meister "
			,"and lost!`n"=>" herausgefordert und verloren!`n"
			,"`3 has defeated her master, `%"=>"`3 hat ihren Meister `%"
			,"`3 has defeated his master, `%"=>"`3 hat seinen Meister `%"
			,"`3 to advance to level `^"=>"`3 besiegt, steigt auf Level `^"
			,"`3 on her `^"=>"`3 auf und feiert ihren `^"
			,"`3 on his `^"=>"`3 auf und feiert seinen `^"
			,"`3 by sneaking in to their room in the inn!"=>"`3 brutal in einem Zimmer in der Kneipe."
			,"`3 in fair combat in the fields."=>"`3 in einem fairen Kampf in den Feldern."
			,"gold bounty by turning in `4"=>"Gold f�r den Kopf von `4"
			," was completely buried when "=>" wurde komplett begraben, als "
			," became greedy digging in the mines"=>" in der Mine zu gierig wurde"
			,"`3 defeated `4"=>"`3 besiegt `4"
			," attacked "=>" angriff "
			,"`6The Inn"=>"`6einem Zimmer in der Kneipe"
			,"`@The Fields"=>"`@den Feldern"
			,"`3 collected `4"=>"`3 bekommt `4"
			,"'s head!"=>"!"
			,"`3 day!!"=>"`3 Tag!!"
			," she "=>" sie "
			," he "=>" er "
		)
		// end of addnews for news
		,"`!`bYou're dead, Jane!`b`0"=>"`!`bDu bist tot, Jane!`b`0"
		,"`!`bYou're dead, Jim!`b`0"=>"`!`bDu bist tot, Jim!`b`0"
		,"Continue"=>"Weiter"
		,"`c`b`!News for "=>"`c`b`!Neuigkeiten f�r "
		,"Today's news"=>"Heutige Neuigkeiten"
		,"Other"=>"Sonstiges"
		,"Village Square"=>"Dorfplatz"
		,"Login Screen"=>"Zum Login"
		,"Preferences"=>"Einstellungen"
		,"Land of Shades"=>"Reich der Toten"
		,"Previous News"=>"Vorherige Neuigkeiten"
		,"Next News"=>"N�chste Neuigkeiten"
		,"News"=>"Neuigkeiten"
		,"About this game"=>"�ber das Spiel"
		,"New Day"=>"Neuer Tag"
		,array(
			"`\$You were slain in "=>"`\$Du wurdest im "
			,"`\$ by `%"=>"`$ von `%"
			,"`\$.  They cost you 5% of your experience, and took any gold you had.  Don't you think it's time for some revenge?"=>"`\$ besiegt und um alles Gold beraubt, das du bei dir hattest. Das kostet dich 5% deiner Erfahrung. Meinst du nicht es ist Zeit f�r Rache?"
		)
		);
		break;
	case "outhouse.php":
		$replace = array(
		"This is the cleanest outhouse in the land!`n"=>"Dies ist das sauberste Plumpsklo im ganzen Land!`n"
		,array(
			"`7You pay your "=>"`7Du bezahlst die "
			," gold to the Toilet Gnome for the privilege of using the paid outhouse.`n"=>" Gold an den Klo-Gnom f�r die Erlaubnis, das private Klo zu benutzen.`n"
		)
		,"The Toilet Paper Gnome tells you if you need anything, just ask`n"=>"Der Klopapier-Gnom sagt dir noch, dass du einfach fragen sollst, wenn du noch etwas brauchst.`n"
		,array(
			"He politely turns "=>"Er dreht dir h�flich "
			,"his back to you and finishes cleaning the wash stand.`n"=>"seinen R�cken zu und schlie�t die Reinigung des Waschstandes ab.`n"
			,"She politely turns "=>"Sie dreht dir h�flich "
			,"her back to you and finishes cleaning the wash stand.`n"=>"ihren R�cken zu und schlie�t die Reinigung des Waschstandes ab.`n"
		)
		,"`2The smell is so strong your eyes tear up and your nose hair curls!`n"=>"`2Der furchtbare Gestank triebt dir Tr�nen in die Augen und deine Nasenhaare kr�useln sich!`n"
		,"After blowing his nose with it, the Toilet Paper Gnome gives you 1 sheet of single-ply TP to use.`n"=>"Nachdem er sich die Nase damit geputzt hat, �berreicht dir der Klopapier-Gnom ein Blatt einlagiges Klopapier.`n"
		,"After looking at the stuff covering his hands, you think you might not want to use it.`n`n"=>"Du entschliesst dich, dieses Teil lieber nicht zu benutzen, nachdem du seine H�nde gesehen hast.`n`n"
		,array(
			"While squating over the big hole "=>"Beinahe rutschst du in das gro�e Loch in der Mitte des Raumes, w�hrend du dar�ber in die Hocke gehst. "
			,"While standing over the big hole "=>"Beinahe rutschst du in das gro�e Loch in der Mitte des Raumes, w�hrend du dich dar�ber stellst. "
			," in the middle of the room with the TP Gnome observing you closeley; you almost slip in.`n"=>" Der Klopapier-Gnom beobachtet dich bei deinem Gesch�ft sehr genau.`n"
		)
		,"But you go ahead and take care of busines as fast as you can, you can only hold your breath so long.`n"=>"Du machst so schnell du kannst, denn so arg lange kannst du die Luft nicht anhalten.`n"
		,array(
			"`2Washing your hands is always a good thing.  You tidy up, straighten your "=>"`2H�nde waschen ist immer eine gute Sache. Du machst dich zurecht, bringst dein(e/n) "
			," in your reflection in the water, and head on your way.`0`n"=>" in Ordnung und betrachtest dein Spiegelbild im Wasser. Dann machst du dich wieder auf den Weg.`0`n"
		)
		,"`^The Wash Room Fairy blesses you!`n"=>"`^Die Waschraum-Fee segnet dich!`n"
		,array(
			"`7You receive `^"=>"`7Du bekommst `^"
			," `7gold for being sanitary and clean!`0`n"=>"`7 Gold f�r Hygiene und Sauberkeit!`0`n"
		)
		,"`&Aren't you the lucky one to find a gem there by the doorway!`0`n"=>"`&Bist du nicht ein Gl�ckspilz? Du findest einen Edelstein beim Eingang!`0`n"
		,"`&You gained a turn!`0`n"=>"`&Du hast eine Extrarunde erhalten!`0`n"
		,"`&Leaving the outhouse, you feel a little more sober!`n`0"=>"`&Du verl�sst das Kloh�uschen und f�hlst dich etwas n�chterner!`n`0"
		,array(
			"`&You notice a small bag containing `^"=>"`&Du bemerkst einen kleinen Beutel mit `^"
			," `7gold that someone left by the washstand.`0"=>" `7Gold, den hier wohl jemand vergessen hat.`0"
		)
		,"`2Your hands are soiled and real stinky!`n"=>"`2Deine H�nde sind schmutzig und stinken!`n"
		,"Didn't your mother teach you any better?`n"=>"Hat dir deine Mutter denn gar nichts beigebracht?`n"
		,array(
			"`nThe Toilet Paper Gnome has thrown you to the slimy, filthy floor and extracted "=>"`nDer Klopapier-Gnom hat dich auf den schleimigen, verdreckten Boden geschmissen und dir "
			,"gold pieces from you due to your slovenliness!`n"=>" Goldst�cke f�r deine Schlampigkeit abgenommen!`n"
			,"gold piece from you due to your slovenliness!`n"=>" Goldst�ck f�r deine Schlampigkeit abgenommen!`n"
		)
		,"Aren't you glad an embarassing moment like this isn't in the news?`n"=>"Bist du nicht auch froh, dass peinliche Momente wie dieser nicht in den News stehen?`n"
		,"`2The village has two outhouses, which it keeps way out here in the forest because of the "=>"`2Das Dorf verf�gt �ber 2 Kloh�uschen, die wegen der monsterabwehrenden Wirkung des Gestanks etwas "
		,"warding effect of their smell on creatures.`n`nIn typical caste style, there is a priviliged "=>"ausserhalb im Wald stehen.`n`nIn typischer Klassenmanier gibt es ein bevorzugtes und ein "
		,"warding effect of their smell on creatures.`n`n"=>"ausserhalb im Wald stehen.`n`n"
		,"outhouse, and an underpriviliged outhouse.  The choice is yours!`0`n`n"=>"heruntergekommenes H�uschen. Du hast die Wahl!`0`n`n"
		,"As you draw close to the Outhouses, you realize that you simply don't think you can bear the smell of another visit to the Outhouses today."=>"Als du dich den Plumpsklos n�herst, erkennst du, dass du den Gestank heute nicht noch einmal aushalten kannst."
		,"You really don't have anything left to relieve today!"=>"Du hast wirklich nichts mehr in dir, was du heute noch ablassen k�nntest."
		,"`n`n`7You return to the forest.`0"=>"`n`n`7Du kehrst in den Wald zur�ck.`0"
		,"Private Toilet: "=>"Private Toilette: "
		,array(
			"`2The Private Toilet costs `^"=>"`2Die private Toilette kostet `^"
			,"`2gold. Looks like you are going to have to hold it or use the Public Toilet!"=>"`2 Gold. Sieht so aus. als ob du es entweder aushalten, oder die �ffentliche Toilette benutzen musst!"
		)
		,"The Outhouses are closed for repairs.`nYou will have to hold it till tomorrow!"=>"Die Kloh�uschen sind wegen Reparaturarbeiten geschlossen.`nDu wirst es bis morgen aushalten m�ssen!"
		,"Wash your hands"=>"H�nde waschen"
		,"Leave"=>"Verlassen"
		,"Public Toilet:  (free)"=>"�ffentliche Toilette (kostenlos)"
		,"Hold it"=>"Aushalten"
		,"Golinda's Hut"=>"Golinda's H�tte"
		,"Healer's Hut"=>"H�tte des Heilers"
		,"Look for Something to kill"=>"Etwas zum Bek�mpfen suchen"
		,"Go Slumming"=>"Herumziehen"
		,"Go Thrillseeking"=>"Nervenkitzel suchen"
		,array(
			"Take "=>"Nimm "
			," to Dark Horse Tavern"=>" zur Dark Horse Taverne"
		)
		,"Return to the Village"=>"Zur�ck zum Dorf"
		,"Seek out the Green Dragon"=>"Suche den Gr�nen Drachen"
		,"Other"=>"Sonstiges"
		,"The Outhouse"=>"Plumpsklo"
		,"Toilets"=>"Toiletten"
		);
		break;
	case "petition.php":
		$replace = array(
		array(
			"`^Welcome to the Legend of the Green Dragon New Player Primer`n`n"=>"`^Willkommen bei Legend of the Green Dragon - Fibel f�r neue Spieler`n`n"
			,"`^Welcome to Legend of the Green Dragon. `n"=>"`^Willkommen bei Legend of the Green Dragon. `n"
			,"You wake up one day, and you're in a village for some reason.  You wander around, bemused, until you stumble upon the Village Square.  Once there you start asking lots of stupid questions.  People (who are mostly naked for some reason) throw things at you.  You escape by ducking into the Inn and find a rack of pamphlets by the door.  The title of the pamphlet reads: \"Everything You Wanted to Know About the LoGD, but Were Afraid to Ask.\"  Looking furtively around to make sure nobody's watching, you open one and read:`n"=>"Eines Tages wachst du in einem Dorf auf. Du weisst nicht warum. Verwirrt l�ufst du durch das Dorf, bis du schlisslich auf den Dorfplatz stolperst. Da du nun schonmal da bist, f�ngst du an, lauter dumme Fragen zu stellen. Die Leute (die aus irgendeinem Grund alle fast nackt sind) werfen dir alles m�gliche an den Kopf. Du entkommst in eine Kneipe, wo du in der n�he des Eingangs ein Regal mit Flugbl�ttern findest. Der Titel der Bl�tter lautet: \"Fragen, die schon immer fragen wolltest, es dich aber nie getraut hast\". Du schaust dich um, um sicherzu stellen, dass dich niemand beobachtet, und f�ngst an zu lesen:`n"
			,"\"So, you're a Newbie.  Welcome to the club.  Here you will find answers to the questions that plague you.  Well, actually you will find answers to the questions that plagued US.  So, here, read and learn, and leave us alone!\" `n"=>"\"Du bist also ein Newbie. Willkommen im Club. Hier findest du Antworten auf Fragen, die dich qu�len. Nun, zumindest findest du Antworten auf Fragen, die UNS qu�lten. So, und jetzt lese und lass uns in Ruhe!\"`n"
			,"What is the purpose of this game?"=>"Was ist das Ziel des Spiels?"
			,"To get chicks.`n"=>"M�dls aufreissen.`n"
			,"Seriously, though.  The purpose is to slay the green dragon.`n"=>"Nein, im ernst. Ziel des Spiels ist es, den gr�nen Drachen zu besiegen.`n"
			,"How do I find the green dragon?"=>"Wie finde ich den gr�nen Drachen?"
			,"Well, sort of.  You can't find her until you've reached a certain level. When you're at that level, it will be immediately obvious."=>"Ok, sowas in der Art. Du kannst ihn erst finden, wenn du ein bestimmtes Level erreicht hast. Sobald du soweit bist, wird es offensichtlich sein."
			,"How do I increase my level?"=>"Wie steigere ich mein Level?"
			,"Send us money."=>"Sende uns Geld."
			,"No, don't send money - you increase your experience by fighting creatures in the forest.  Once you've gotten enough experience, you can challenge your master in the village."=>"Nein, sende uns kein Geld - du steigerst dein Level, indem du gegen Monster im Wald k�mpfst. Sobald du genug Erfahrungspunkte gesammelt hast, kannst du deinen Meister im Dorf herausfordern."
			,"Well, you can send us money if you want (see PayPal link)"=>"Nun, du kannst uns trotzdem Geld schicken (PayPal Link)"
			,"Why can't I beat my master?"=>"Warum kann ich meinen Meister nicht besiegen?"
			,"He's far too wiley for the likes of you."=>"Er ist viel zu gerissen f�r Deinesgleichen."
			,"Did you ask him if you have enough experience?"=>"Hast du ihn gefragt, ob du schon genug Erfahrung hast?"
			,"Have you tried purchasing some armor or weapons in the village?"=>"Hast du mal versucht, dir eine R�stung oder bessere Waffen im Dorf zu kaufen?"
			,"I used up all my turns.   How do I get more?"=>"Ich habe alle meine Z�ge aufgebracht. Wie krieg ich mehr?"
			,"Send money."=>"Schicke Geld."
			,"No, put your wallet away.  There *are* a few ways to get an extra turn or two, but by and large you just have to wait for tomorrow.  When a new day comes you'll have more energy."=>"Nein, leg deinen Geldbeutel weg. Es *gibt* einige Wege, eine oder zwei Extrarunden zu bekommen, aber sonst musst du einfach bis morgen warten. Am n�chsten Tag wirst du wieder Energie haben."
			,"Don't bother asking us what those few ways are - some things are fun to find on your own."=>"Frag uns nicht, was diese M�glichkeiten sind - einige Dinge machen Spass, sie selber herauszufinden."
			,"When does a new day start?"=>"Wann beginnt ein neuer Tag?"
			,"Right after the old one ends."=>"Gleich nachdem der alte aufh�rt."
			,"Arghhh, you guys are killing me with your smart answers - can't you just give me a straight answer?"=>"Arghhh, ihr Typen bringt mich mit euren schlauen Antworten noch um - k�nnt ihr mir keine direkten Antworten geben?"
			,"Something's gone wrong!!!  How do I let you know?"=>"Irgendwas ist schiefgegangen!!! Wie kann ich euch informieren?"
			,"What if all I have to say is 'yo - sup?'?"=>"Was, wenn ich nur 'yo - was geht?' zu sagen habe?"
			,"Eat funny mushrooms."=>"Iss lustige Pilze"
			,"No, put that mushroom away, colors signify that the character was integral to the beta-testing process - finding a bug, helping to create creatures, etc, or being married to the admin.  (*cough*Appleshiner*cough*)"=>"Nein, leg die Pilze weg, Farben in Charakternamen zeigen an, dass jemand f�r den Betaprozess wichtig war. Also als Belohnung f�r gefundene Fehler, erschaffene Kreaturen, etc., oder mit dem Admin verheiratet zu sein (*hust*Appleshiner*hust*)"
			,"If you don't have something nice (or useful, or interesting, or creative that adds to the general revelry of the game) to say, don't say anything."=>"Wenn du nichst sch�nes (oder n�tzliches oder interessantes oder kreatives f�r die Stimmung des Spiels) zu sagen hast, sag einfach gar nichts."
			,"But if you do want to converse with someone, send them an email through Ye Olde Post Office."=>"Aber wenn du mit einer bestimmten Person quatschen willst, schicke eine Mail mit Ye Olde Post Office."
			,"How do I use emotes?"=>"Wie mache ich 'Aktionen'?"
			,"Type :: before your text."=>"Gebe :: (oder /me )vor deinem Text ein."
			,"What's an emote?"=>"Was ist eine 'Aktion'?"
			,"AnObviousAnswer punches you in the gut."=>"Offensichtlicheantwort schl�gt dir in die Weichteile."
			,"That's an emote.  You can emote in the village if you want to do an action rather than simply speaking."=>"Das ist eine 'Aktion'. Du kannst im Dorf statt nur zu 'sagen' auch 'Aktionen' darstellen."
			,"How do you get colors in your name?"=>"Wie bekommt man Farben in den Namen?"
			,"New Player Primer"=>"Fibel f�r neue Spieler"
			,"Frequently Asked Questions on Game Play (General)"=>"Fragen zum Gameplay (generell)"
			,"Frequently Asked Questions on Game Play (with spoilers)"=>"Fragen zum Gameplay (Spoiler!)"
			,"Frequently Asked Questions on Technical Issues"=>"Technische Fragen und Probleme"
			,"Sup dOOd, iz  it cool 2 uz  common IM wurds in the village?  Cuz u no, it's faster.  R u down wit that?"=>"Moin 41t3r, is es c00l, 411g3m31ne Ch47 W�rterz im D0rf zu v3rw3nd3n?"
			,"NO, for the love of pete, use full words and good grammar, PLEASE! These are not words: U, R, Ur, Cya, K, Kay, d00d, L8tr, sup, na and anything else like that!"=>"NEIN! Uns zu liebe benutze volle W�rte und gute Grammatik. BITTE!"
			,"Better yet, send a petition.  A petition should not say 'this doesn't work' or 'I'm broken' or 'I can't log in' or 'yo.  Sup?'  A petition *should* be very complete in describing *what* doesn't work.  Please tell us what happened, what the error message is (copy and paste is your friend), when it occurred, and anything else that may be helpful.  \"I'm broken\" is not helpful.  \"There are salmon flying out of my moniter when I log in\" is much more descriptive.  And humorous.  Although there's not much we can do about it.  In general, please be patient with these requests - many people play the game, and as long as the admin is swamped with 'yo - Sup?' petitions, it will take some time to sift through them."=>"Noch besser, sende eine Petition. In einer Petition sollte aber nicht 'Das geht nicht', 'Ich bin kaputt', oder 'Jo, was geht?' stehen. In einer Petition *sollte* m�glichst genau und komplett beschrieben werden, *was* nicht funktioniert. Bitte teile uns mit, was passiert ist, wie die Fehlermeldung war (kopiere sie rein), wann sie erschien und alles, was hilfreich sein k�nnte. \"Das is kaputt\" ist nicht hilfreich. \"Da fliegt immer ein Lachs aus meinem Monitor, wenn ich mich einlogge\" ist wesentlich genauer. Und witziger. Auch wenn wir daran nicht viel �ndern k�nnten.`nBitte habe Geduld. Viele Leute spielen das Spiel und wenn die Admins mit 'Jo - was geht?'-Nachrichten ausgelastet sind, dauert es mit der Antwort manchmal eine Weile."
			,"Well, okay, new days correspond with the clock in the village (can also be viewed in the inn).  When the clock strikes midnight, expect a new day to begin.  The number of times a clock in LoGD strikes midnight per calendar day may vary by server.  Beta server has 4 play days per calendar day, SourceForge server has 2.  Other servers depend on the admin.`nThis server has"=>"Naja, gut. Neue Tage h�ngen mit der Uhr im Dorf (und in der Kneipe) zusammen. Wenn die Uhr Mitternacht anzeigt, erwarte den neuen Tag. Wie oft am Tag die Uhr in LoGD Mitternacht zeigt, variiert von Server zu Server. Der BETA-Server hat 4, der SourceForge Server 2 Spieltage pro Kalendertag. Die Anzahl der Tage bestimmt der Admin. Auf diesem Server gibt es "
			," days per calendar day."=>" Spieltage pro Kalendertag."
			,"`c`bSpecific and technical questions`b`c"=>"`c`bSpezielle und technische Fragen`b`c"
			,"How can I have been killed by another player while I was currently playing?"=>"Wie kann es sein, dass ich von einen anderen Spieler get�tet wurde, obwohl ich gerade selbst gespielt habe?"
			,"The biggest cause of this is someone who began attacking you while you were offline, and completed the fight while you were online.  This can even happen if you have"=>"Der Hauptgrund daf�r ist, wenn jemand einen Angriff auf dich angefangen hat, w�hrend du offline warst, ihn aber erst beendet hat, als du online warst. Das kann sogar passieren, wenn du "
			,"been playing nonstop for the last hour, when someone starts a fight, they are forced by the game to finish it at some point.  If they start a fight with you, and close"=>"stundenlang ununterbrochen spielst. Wenn jemand einen Kampf anf�ngt, zwingt das Spiel ihn, diesen Kampf zu beenden. Wenn du also angegriffen wirst, und der Angreifer schliesst den Browser bevor der Kampf zuende ist, "
			,"their browser, the next time they log on, they will have to finish the fight.  You will lose the lesser of the gold you had on hand when they attacked you, or the gold"=>"muss er diesen Kampf bei seinem n�chsten Login zuende bringen. Du wirst aber immer das wenigere Gold verlieren, wenn du besiegt wirst. Das heisst, wenn du am Anfang des Kampfes 1 Gold hattest, und am Ende 2000, "
			,"on hand when they finished the fight.  So if you logged out with 1 gold on hand, they attack you, you log on, accumulate 2000 gold on hand, and they complete the fight,"=>"wird der Angreifer nur 1 Gold bekommen. Ist es andersrum, wird er ebenfalls nur 1 Gold bekommen."
			,"they will only come away from it with 1 gold.  The same is true if you logged out with 2000 gold, and when they completed killing you, you only had 1 gold."=>" "
			,"Why did it say I was killed in the fields when I slept in the inn?"=>"Warum wurde ich in den Feldern get�tet, obwohl ich in der Kneipe geschlafen habe?"
			,"The same thing can happen where someone started attacking you when you were in the fields, and finished after you had retired to the inn for the day.  Keep in mind"=>"Das ist im Prinzip das selbe wie oben. Es kann sein, dass ein Kampf angefangen wurde, als du in den Feldern warst, aber erst beendet wurde, als du in der Kneipe warst. Denke immer daran, "
			,"that if you are idle on the game for too long, you become a valid target for others to attack you in the fields.  If you're going to go away from your computer for"=>"dass du leicht in den Feldern angegriffen werden kannst, wenn du lange Zeit nichts machst, ohne dich auszuloggen. Nach einer gewissen Zeit der Inaktivit�t loggt das Spiel dich automatisch in die Felder aus. "
			,"a few minutes, it's a good idea to head to the inn for your room first so that you don't risk someone attacking you while you're idle."=>" Es ist also eine gute Idee, sich ein Zimmer zu nehmen, wenn ein paar Minuten vom Computer weg muss, damit man nicht so leicht angegriffen werden kann."
			,"The game tells me that I'm not accepting cookies, what are they and what do I do?"=>"Das Spiel erz�hlt mir, ich akzeptiere keine Cookies. Was sind Cookies und was kann ich tun?"
			,"Cookies are little bits of data that websites store on your computer so they can identify you from other players.  Sometimes if you have a firewall it will block cookies, and some web browsers will let you block cookies.  Check the documentation for your browser or firewall, or look around in its preferences for settings to modify whether or not you accept cookies.  You need to at least accept session cookies to play the game, though all cookies are better."=>"Cookies (Kekse) sind kleine Datenh�ppchen, die eine Internetseite auf deinem Computer speichert, damit sie dich von anderen Besuchern unterscheiden kann. Einige Firewalls lassen Cookies nicht durch und viele Browser blockieren Cookies in der Standardeinstellung. Lese im Handbuch oder der Hilfedatei deiner Firewall oder deines Browsers nach, wie du Cookies durchl�sst, oder durchsuche mal die Optionen und Einstellungen. Es m�ssen mindestens \"Session Cookies\" akzeptiert werden, aber alle Cookies w�ren besser."
			,"Warning, the FAQs below might contain some spoilers, so if you really want to discover things on your own, you'd be better off not reading too far.  This is not a manual.  It's a self-help pamphlet."=>"Warnung! Die folgenden FAQs k�nnten einige Spoiler enthalten. Wenn du also lieber auf eigene Faust entdecken willst, solltest du hier nicht weiter lesen. Dies ist keine Anleitung. Es ist eine Selbsthilfebrosch�re."
			,"How do you get gems?"=>"Wie bekommt man Edelsteine?"
			,"To the mines with you!!`n"=>"In die Minen mit dir!!`n"
			,"Actually, you can't mine them.  (Well, you can, but only if you get luck and find the mine.  Warning though, mines can be dangerous.) Gems can be found in the forest during 'special events' that happen randomly - if you play often enough, you're bound to stumble across one at some point. Gems can also be gotten very occasionaly from a forest fight."=>"Nein, du kannst nicht danach graben. (Ok, du kannst doch, aber nur wenn du Gl�ck hast und die Mine findest. Aber Achtung! Minen k�nnen gef�hrlich sein.) Edelsteine k�nnen bei zuf�lligen \"Besonderen Ereignissen\" im Wald gefunden werden. Wenn du oft genug spielst, stolperst du an einigen Punkten ganz sicher �ber welche. Gelegentlich k�nnen auch Edelsteine bei Waldk�mpfen gefunden werden."
			,"  Lastly, you can get a gem for free just for voting for this server at Top Web Games (see the link off of the village)."=>" Zu guter letzt kannst du auch einen kostenlosen Edelstein bekommen, wenn du bei Top Web Games f�r diesen Server stimmst (siehe Link im Dorf)."
			,"Why do some people seem to have so many hitpoints at a low level?"=>"Warum scheinen manche Spieler mit niedrigem Level so eine Menge Lebenspunkte zu haben?"
			,"Cause they're bigger than you."=>"Weil sie gr�sser sind als du."
			,"No, really, they *are* bigger than you.  You'll be big too someday."=>"Nein, ehrlich, sie *sind* gr�sser als du. Du wirst auch eines Tages gross sein."
			,"Does that have something to do with the titles that people have?"=>"Hat das was mit den Titeln der Leute zu tun?"
			,"But of course!"=>"Aber klar!"
			,"Indeed, every time you kill the dragon, you get a new title and return to level one.  So low level players with titles have had opportunities to embiggen themselves.  (see Hall of Fame)"=>"Jedesmal, wenn du den Drachen killst, bekommst du einen neuen Titel und wirst wieder Level 1. Also hatten Spieler mit Titel und niedrigem Level die Chance, sich zu steigern. (Siehe Ruhmeshalle)"
			,"Why does that old man keep hitting me with an ugly/pretty stick in the forest?"=>"Warum schl�gt mich dieser alte Mann im Wald st�ndig mit einem h�sslichen/h�bschen Stock?"
			,"You look like a pinata!"=>"Du siehst aus wie eine Pinata!"
			,"It's a special event that can add or remove charm."=>"Nein, das ist ein besonderes Ereignis, das dir Charme geben oder nehmen kann."
			,"Well, what's the point of charm?"=>"Wozu ist Charme gut?"
			,"Well, actually, that *is* the point.  Visit some folks at the inn, and you ought to be able to figure this one out.  The more charm you have, the more successful you'll be wooing said folks."=>"Nun, das *ist* tats�chlich der Sinn. Besuche einige Personen in der Kneipe und du wirst diesen Punkt verstehen. Je mehr Charme du hast, umso erfolgreicher wird dein Werben beim Volk ankommen."
			,"I saw the man in the forest and he hit me with his ugly stick, but it says I'm uglier than the stick, and I made it lose a charm point. What's going on?"=>"ich hab den alten Mann im Wald gesehen und er hat mich mit seinem h�sslichen Stock geschlagen, aber es hiess, ich w�re h�sslicher als sein Stock und der Stock hat einen Charmpunkt verloren. Was ist da los?"
			,"You're clearly the least charming person on the planet.  And if you're the person who actually *asked* this question, you're also the dumbest. Use a little power of inference, wouldja?  No.  Really."=>"Du bist ganz klar, das abstossendste Wesen auf diesem Planeten. Und wenn du die Person bist, die gerade diese Frage gestellt hat, dann bist du auch noch die d�mmste. Zieh mal deine eigenen R�ckschl�sse. Also wirklich."
			,"Okay, we did say you were the dumbest, so: it means you currently have zero charm points."=>"Okay, wir haben gesagt, du w�rst der D�mmste, also: Es bedeutet, dass du gerade 0 Charmpunkte hast."
			,"How do I check my charm?"=>"Wie kann ich meinen Charme sehen?"
			,"Take a peek in the mirror once in a while."=>"Schau ab und zu mal in den Spiegel."
			,"We jest - there's no mirror.  You'll have to ask a friend how you look today - the responses may be vague, but they'll give you a clue how you're doing."=>"Wir scherzen - es gibt keinen Spiegel. Du musst einen Freund fragen, wie du heute aussiehst. Die Antwort kann ungenau sein, aber sie gibt dir einen Anhaltspunkt, wie es mit dir steht."
			,"How do we go to other villages?"=>"Wie kommen wir in andere D�rfer?"
			,"Take the train downtown.  We're talking downtown."=>"Nimm den Zug."
			,"Actually, there aren't any other villages to travel to.  Any references to them (i.e. Eythgim folks you meet in the forest) only exist to give the game more depth."=>"Tats�chlich gibt es keine anderen D�rfer. Jede Erw�hnung anderer D�rfer oder L�nder (z.B. Eythgim folks im Wald) dient nur dazu, dem Spiel mehr Tiefe zu geben."
			,"Who is the Management?"=>"Wer ist das Management?"
			,"Appleshiner and Foilwench are in charge of this FAQ,  but if something goes wrong, email MightyE.  He's in charge of everything else."=>"Appleshiner und Foilwench haben die Verantwortung f�r diese FAQ, aber wenn etwas schiefgeht, schicke eine E-Mail an MightyE. Er ist f�r alles andere verantwortlich. Oder Frage zuerst den Admin des Servers." 
			,"How did they get to be so darn attractive, anyway?"=>"Wie wird man so verdammt attraktiv?"
			,"Lots of at-home facials, my dear!!  MightyE especially enjoys the Grapefruit Essence Facial Masque."=>"Durch ne Menge Gesichtsmasken, mein Lieber!! MightyE bevorzugt speziell eine Maske aus Grapefruit Essenz."
			," is turning out to be a fairly expansive game, with a lot of areas to explore.  It's easy to get lost with all that there is to do out there,"=>" wird langsam zu einem ordentlich ausgedehnten Spiel mit einer Menge zu erforschen. Es ist leicht sich bei all dem, was man da draussen tun kann, zu verirren, "
			,"so keep in mind that the village square is pretty much the center of the game.  This area will give you access to most other areas that you can get to, with a few exceptions"=>"deshalb sehe den Dorfplatz am besten als das Zentrum des Spiels an. Dieser Bereich erm�glicht dir den Zugang zu den meisten anderen Gebieten des Spiels - mit einigen Ausnahmen"
			,"(we'll talk about those in a little while).  If you ever get lost, or are not sure what's going on, head to the village square and regain your bearings."=>" (wir behandeln diese in wenigen Augenblicken). Wenn du dich jemals irgendwo verlaufen hast, versuch zum Dorfplatz zur�ck zu kommen und versuche dort, der Lage wieder Herr zu werden."
			,"Your first day in the world can be very confusing!  You're presented with a lot of information, and you don't need almost any of it!  It's true!  One thing you should"=>"Dein erster Tag in dieser Welt kann sehr verwirrend sein! Du wirst von einer Menge Informationen erschlagen und brauchst dabei fast keine davon. Das ist wahr! Etwas, das du "
			,"probably keep an eye on though, are your hit points.  This is found under \"Vital Info.\"  No matter what profession you choose, in the end, you are some kind of warrior"=>"vielleicht im Auge behalten solltest, sind deine Lebenspunkte (Hitpoints). Diese Information findest du in der \"Vital Info\". Egal, welche Spezialit�t du gew�hlt hast, am Ende bist du eine Art Krieger "
			,"or fighter, and so you need to learn how to do battle.  The best way to do this is to look for creatures to kill in the forest.  When you find one, check it out, and make"=>"oder K�mpfer, und musst lernen zu k�mpfen. Der beste Weg ist dazu, im Wald Monster zum t�ten zu suchen. Wenn du einen Gegner gefunden hast, �berpr�fe ihn gut und stelle "
			,"sure that it's not a higher level than you, because if it is, you might not live through the fight.  Keep in mind that you can always try to run away from something that"=>"sicher, dass er kein h�heres Level als du selbst hat. Weil in diesem Fall �berlebst du den Kampf vielleicht nicht. Denke immer daran, dass du jederzeit versuchen kannst, zu fliehen, "
			,"you encountered, but some times it might take several tries before you get away.  You might want to buy armor and weapons in the village square in order to give yourself"=>"aber das klappt manchmal nicht auf Anhieb! Um eine bessere Chance gegen die Monster im Wald zu haben , kannst du im Dorf "
			,"a better chance against these creatures out in the forest.`n"=>"R�stungen und Waffen kaufen.`n"
			,"Once you have defeated a creature, you'll notice that you're probably a little hurt.  Head on over to the Healer's Hut, and you can get patched up in short order.  While"=>"Wenn du eine Kreatur besiegt hast, wirst du feststellen, dass du m�glicherweise verletzt bist. Gehe in die H�tte des Heilers, dort kannst du innerhalb k�rzester Zeit wieder zusammengeflickt werden. "
			,"you're level 1, healing is free, but as you advance, it becomes more and more expensive.  Also keep in mind that it's more expensive to heal 1 point, then later heal 1 point"=>"Solang du Level 1 bist, kostet die Heilung nichts, aber wenn du aufsteigst, wird die Heilung teurer und teurer. Bedenke auch, dass es teurer ist, einzelne Lebenspunkte zu heilen, als sp�ter "
			,"again than it is to heal 2 in one shot.  So if you're trying to save up some money, and you're barely hurt, you might risk a fight or two while you're a little hurt, and "=>"mehrere gleichzeitig. Wenn du also etwas Gold sparen willst und nicht allzu schwer verletzt bist, kannst durchaus mal mehr als 1 Kampf rislieren, "
			,"heal the damage from several fights in one shot.`n"=>"bevor du zum Heiler rennst."
			,"After you've killed a few creatures, you should head back to the village, in to Bluspring's Warrior Training, and talk to your master.  Your master will tell you when"=>"Nachdem du ein paar Monster gekillt hast, solltest du mal im Dorf in Bluspring's Trainingslager vorbeischauen und mit deinem Meister reden. Er wird dir sagen, "
			,"you are ready to challenge him, and when you are ready, you should give him a shot (make sure you're healed up first though!).  Your master won't kill you if you lose,"=>"ob du bereit bist, ihn herauszufordern. Und wenn du bereit bist, sorge daf�r, dass du ihn auch besiegst (als vorher heilen)! Dein Meister wird dich nicht t�ten wenn du verlierst, "
			,"instead he'll give you a complimentary healing potion and send you on your way."=>"stattdessen gibt er dir eine komplette Heilung und schickt dich wieder auf den Weg."
			,"You can only challenge your master once a day."=>"Du kannst deinen Meister nur einmal am Tag herausfordern."
			,"Death is a natural part of any games that contains some kind of combat.  In Legend of the Green Dragon, being dead is only a temporary condition.  When you die, you'll"=>"Der Tod ist ein nat�rlicher Teil in jedem Spiel, das irgendwelche K�mpfe enth�lt. In Legend of the Green Dragon ist der Tod nur ein vor�bergehender Zustand. Wenn du stirbst, verlierst"
			,"lose any money that you had on hand (money in the bank is safe!), and some of the experience you've accumulated.  While you're dead, you can explore the land of the shades"=>" du normalerweise alles Gold, das du dabei hast (Gold auf der Bank ist sicher!) und etwas von deiner gesammelten Erfahrung. Wenn du tot bist, kannst du das Land der Schatten und den Friedhof erforschen. "
			,"and the graveyard.  In the graveyard, you'll find Ramius the Overlord of Death.  He has certain things that he would like you to do for him, and in return, he will grant"=>"Auf dem Friedhof wirst du Ramius, den Gott der Toten finden. Er hat einige Dinge, die du f�r ihn tun kannst, und als Gegenleistung "
			,"you special powers or favors.  The graveyard is one of those areas that you can't get to from the Village Square.  In fact, while you're dead, you can't go to the village"=>" wird er dir spezielle Kr�fte oder Gefallen gew�hren. Der Friedhof ist einer der Pl�tze, die du vom Dorfplatz aus nicht erreichen kannst. Umgekehrt kommst du nicht ins Dorf, "
			,"square at all!`n"=>" solange du tot bist.`n"
			,"Unless you can convince Ramius to resurrect you, you'll remain dead until the next game day.  There are "=>"Solang es dir nicht gelingt, Ramius davon zu �berzeugen, dich wieder zu erwecken, bleibst du tot - zumindest bis zum n�chsten Spieltag. Es gibt "
			," game days each real day.  These "=>" Spieltage pro echtem Tag. Diese Tage fangen an, "
			,"occur when the clock in the village square reaches midnight."=>"sobald die Uhr im Dorf Mitternacht zeigt."
			,"As stated just above, there are "=>"Wie oben erw�hnt, gibt es "
			,"When you get "=>"Wenn dein neuer Tag anf�ngt, "
			,"a new day, you'll be granted new forest fights, interest on gold you have in the bank (if the bankers are pleased with your performance!), and a lot of your other"=>"werden dir neue Waldk�mpfe (Runden), Zinsen bei der Bank (wenn der Bankier mit deiner Leitung zufrieden ist) gew�hrt, und viele deiner anderen "
			,"statistics will be refreshed.  You'll also be resurrected if you were dead, and get another chance to take on the world.  If you don't log on over the course of an "=>"Werte werden aufgefrischt. Ausserdem wirst du wiederbelebt, falls du tot warst. Wenn du ein paar Spieltage nicht einloggst, bekommst du die verpassten Spieltage "
			,"entire game day, you'll miss your opportunity to partake in that game day (this means that new game days are only assigned when you actually log on, being away from the"=>"nicht beim n�chsten Login zur�ck. Du bist w�hrend deiner Abwesenheit sozusagen nicht am Geschehen dieser Welt beteiligt."
			,"game for a few days won't grant you a whole bunch of new days).  Forest fights, pvp battles, special power usages and other things that get refreshed on a daily basis do"=>"Waldk�mpfe, PvP-K�mpfe, Spezielle F�higkeiten und andere Dinge, die sich t�glich zur�cksetzen, summieren sich "
			,"NOT get carried over from one day to the next (you can't build up a whole bunch of them)."=>"NICHT �ber mehrere Tage auf."
			,"contains a PvP element, where players can attack each other.  As a new player, you are protected from PvP for your first "=>" enth�lt ein PvP-Element (PvP=Player vs. Player = Spieler gegen Spieler), wo Spieler andere Spieler angreifen k�nnen. Als neuer Spieler bist du die ersten "
			,"You should now have a pretty good idea of how the basics of the game work, how to advance, and how to protect yourself.  There's a whole lot more to the world, so explore it!"=>"Du solltest jetzt eine ziemlich gute Vorstellung davon haben, wie dieses Spiel in den Grundz�gen funktioniert, wie du weiterkommst und wie du dich selbst sch�tzt. Es gibt aber noch eine Menge mehr in dieser Welt, also erforsche sie!"
			,"Don't be afraid of dieing, particularly when you're young, as even when you're dead, there's yet more stuff to do!"=>"Hab keine Angst davor zu sterben, besonders dann nicht, wenn du noch jung bist. Selbst wenn du tot bist, gibt es noch eine Menge zu tun!"
			," game days or until you accumulate "=>" Spieltage, oder bis du "
			,"When you die in PvP, you only lose gold you had on hand, and "=>"Wenn du bei einem PvP-Kampf stirbst, verlierst du alles Gold, das du bei dir hast, und "
			,"% of your experience.  You won't lose any turns in the forest, or any other stats.  If you attack someone else in"=>"% deiner Erfahrungspunkte. Du verlierst keine Waldk�mpfe und auch sonst nichts. Wenn du selbst jemanden angreifst,"
			,"If you buy a room in the inn when you decide to quit the game, you'll protect yourself from casual attacking.  The only way for someone to attack you when you're in the inn"=>"Wenn du dir in der Kneipe ein Zimmer nimmst, um dich auszuloggen, sch�tzt du dich vor gew�hnlichen Angriffen. Der einzige Weg, jemanden in der Kneipe anzugreifen, ist "
			,"is for them to bribe the bartender, which can be a costly procedure.  Quitting to the fields means that someone can attack you with out having to pay money to the bartender.  You"=>"den Barkeeper zu bestechen, was eine kostspielige Sache sein kann. Zum Ausloggen \"In die Felder verlassen\" (oder sich �berhaupt nicht ausloggen) bedeutet, dass du von jedem angegriffen werden kannst, ohne dass er Gold daf�r bezahlen m�sste. Du "
			,"cannot be attacked while you are online, only while you are offline, so the more  you play, the more protected you are ;-).  Also, if you are attacked and die, no one else can"=>"kannst nicht angegriffen werden, solange du online bist, nur wenn du offline bist. Je l�nger du also spielst, umso sicherer bist du ;-). Ausserdem kann dich niemand mehr angreifen, wenn du bereits bei einem Angriff get�tet worden bist,"
			,"attack you again until you log on again, so don't worry that you'll be attacked 30 or 40 times in one night.  Logging back in to the game will make you a viable PvP target again"=>"also brauchst du nicht zu bef�rchten, in einer Nacht 30 oder 40 mal niedergemetzelt zu werden. Erst wenn du dich wieder eingeloggt hast, wirst du wieder angreifbar "
			,"if you've already been killed today."=>" wenn du get�tet wurdest."
			,"PvP, you can get "=>" kannst du "
			,"% of the experience they had, and any gold they had on hand.  If you attack someone else and lose, however, you'll lose "=>"% seiner Erfahrungspunkte und all sein Gold bekommen. Wenn du aber verlierst, verlierst du selbst "
			,"% of your experience, and you'll lose"=>"% deiner Erfahrung und alles Gold. "
			,"any gold that you had on hand.  If someone else attacks you and they lose, you'll gain the gold they had on hand, and "=>"Wenn dich jemand angreift und verliert, bekommst du sein Gold und "
			,"% of their experience.  You can only attack someone who is"=>"% seiner Erfahrungspunkte. Du kannst nur jemanden angreifen, der etwa dein Level hat, "
			,"close to your level, so don't worry that as a level 1, some big level 15 player is going to come along and beat on you."=>"also keine Angst, dass dich mit Level 1 ein Level 15 Charakter niedermetzelt. Das geht nicht. "
			,", unless"=>" Erfahrungspunkte gesammelt hast immun gegen Angriffe - es sei denn, du "
			,"you choose to attack another player.  Some servers might have the PvP aspect turned off, in which case there is no chance that you'll be attacked by any other players.  You"=>"greifst selbst einen anderen Spieler an, dann verf�llt deine Immunit�t. Einige Server haben die PvP-Funktion deaktiviert, dort kannst du also �berhaupt nicht angegriffen werden (und auch selbst nicht angreifen). Du "
			,"can tell if the server you play on has PvP turned off by looking in the Village Square for \"Slay Other Players.\"  If it's not there, you can't engage (or be engaged) in PvP.`n"=>"kannst im Dorf erkennen, ob PvP m�glich ist, wenn es dort \"K�mpfe gegen andere Spieler\" gibt. Gibt es das nicht, ist PvP deaktiviert."
			,"You can't.`n"=>"Gar nicht.`n"
			,"~Thank you,`n"=>"~Danke,`n"
			,"the Management.`n"=>"das Management.`n"
			,"`^`bThe Village Square`b`n`@"=>"`^`bDer Dorfplatz`b`n`@"
			,"`^`bYour first day`b`n`@"=>"`^`bDein erster Tag`b`n`@"
			,"`^`bDeath`b`n`@"=>"`^`bTod`b`n`@"
			,"`^`bNew Days`b`n`@"=>"`^`bNeue Tage`b`n`@"
			,"`^`bPvP (Player versus Player)`b`n`@"=>"`^`bPvP (Spieler gegen Spieler)`b`n`@"
			,"`^`bReady to take on the world!`b`n`@"=>"`^`bBereit f�r die neue Welt!`b`n`@"
			,"Contents:"=>"Inhalt:"
			,"`c`bGeneral questions`b`c"=>"`c`bAllgemeine Fragen`b`c"
			,"Contents"=>"Inhaltsverzeichnis"
		)
		,array(
			"Your Character's Name: "=>"Name deines Characters: "
			,"Your email address: "=>"Deine E-Mail Adresse: "
			,"Description of the problem:`n"=>"Beschreibe dein Problem:`n"
			,"Please be as descriptive as possible in your petition.  If you have questions about how the game works,"=>"Bitte beschreibe das Problem so pr�zise wie m�glich. Wenn du Fragen �ber das Spiel hast, "
			,"please check out the "=>"check die "
			,"Petitions about game mechanics will more than"=>"Anfragen, die das Spielgeschehen betreffen, werden "
			,"likely not be answered unless they have something to do with a bug."=>"nicht bearbeitet - es sei denn, sie haben etwas mit einem Fehler zu tun."
		)
		,array(
			"Your petition has been sent to the server admin.  Please be patient, most server admins"=>"Deine Anfrage wurde an die Admins gesendet. Bitte hab etwas Geduld, die meisten Admins"
			,"have jobs and obligations beyond their game, so sometimes responses will take a while to be received."=>" haben Jobs und Verpflichtungen ausserhalb dieses Spiels. Antworten und Reaktionen k�nnen eine Weile dauern."
		)
		);
		break;
	case "prefs.php":
		$replace = array(
		"Your character has been deleted!"=>"Dein Charakter wurde gel�scht!"
		,"Login Page"=>"Zum Login"
		,"Return to the village"=>"Zur�ck ins Dorf"
		,"Return to the news"=>"Zur�ck zu den News"
		,"`#Your password is too short.  It must be at least 4 characters.`n"=>"`#Dein Passwort ist zu kurz. Es muss mindestens 4 Zeichen lang sein.`n"
		,"`#Your passwords do not match.`n"=>"`#Deine Passw�rter stimmen nicht �berein,`n"
		,"`#Your password has been changed.`n"=>"`#Dein Passwort wurde ge�ndert.`n"
		,"`n`\$You cannot modify your bio, it's been blocked by the administrators!`0`n"=>"`n`\$Du kannst deine Beschreibung nicht �ndern. Der Admin hat diese Funktion blockiert.`0`n"
		,"`#Your email cannot be changed, system settings prohibit it.  (Emails may only be changed if the server allows more than one account per email).  Use the Petition link to ask the server administrator to change your email address if this one is no longer valid.`n"=>"`#Die E-Mail Adresse kann nicht ge�ndert werden, die Systemeinstellungen verbieten es. (E-Mail Adressen k�nnen nur ge�ndert werden, wenn der Server mehr als einen Account pro Adresse zu��sst.) Sende eine Petition, wenn du deine Adresse �ndern willst, weil sie nicht mehr l�nger g�ltig ist.`n"
		,"`#That is not a valid email address.`n"=>"`#Das ist keine g�ltige E-Mail Adresse.`n"
		,"Send email when you get new Ye Olde Mail?"=>"E-Mail senden, wenn du eine Ye Olde Mail bekommst?"
		,"Send email for system generated messages?"=>"E-Mail bei Systemmeldungen senden (z.B. Niederlage im PvP)?"
		,"Allow profanity in received Ye Olde Poste messages?"=>"Kein Wortfilter f�r Ye Olde Mail?"
		,"Language (Not Yet Complete)"=>"Sprache (noch nicht w�hlbar)"
		,"Short Character Biography (255 chars max)`n"=>"Kurzbeschreibung des Charakters (Maximal 255 Zeichen)`n"
		,"`b`@Aww, your administrator has decided you're not allowed to have any skins.  Complain to them, not me."=>"`b`@Argh, dein Admin hat entschieden, da� du keine Skins benutzen darfst. Beschwer dich bei ihm, nicht bei mir."
		,"`c`b`\$ERROR!!!`b`c`&Unable to open the templates folder!  Please notify the administrator!!"=>"`c`b`\$FEHLER!!!`b`c`&Kann den Ordner mit den Skins nicht finden. Bitte benachrichtige den Admin!!"
		,array(
			"New Password: "=>"Neues Passwort: "
			," (leave blank if you don't want to change it)`n"=>" (lasse das Feld leer, wenn du es nicht �ndern willst)`n"
			,"Retype: "=>"Wiederholen: "
			,"Email address: "=>"E-Mail Adresse: "
		)
		,"Preferences"=>"Voreinstellungen"
		,"Settings Saved"=>"Einstellungen gespeichert."
		,"Save"=>"Speichern"
		,array(
			"Are you sure you wish to delete your character?"=>"Willst du deinen Charakter wirklich l�schen?"
			,"Delete Character"=>"Charakter l�schen"
		)
		);
		break;
	case "pvp.php":
		$replace = array(
		array(
			"`4You head out to the fields, where you know some unwitting warriors are sleeping.`n`nYou have `^"=>"`4Du machst dich auf in die Felder, wo einige unwissende Krieger schlafen.`n`nDu hast noch `^"
			,"`4 PvP fights left for today."=>"`4 PvP K�mpfe heute."
		)
		,"Return to the inn"=>"Zur�ck zur Kneipe"
		,"List Warriors"=>"Krieger auflisten"
		,"Return to the Village"=>"Zur�ck ins Dorf"
		,"Return to the village"=>"Zur�ck ins Dorf"
		,"`\$Oops:`4 That user is currently engaged by someone else, you'll have to wait your turn!"=>"`\$Uuuups:`4 Dieser Krieger ist gerade anderweitig ... besch�ftigt. Du wirst etwas auf deine Chance warten m�ssen!"
		,"`\$Error:`4 That user is now online."=>"`\$Fehler:`4 Dieser Krieger ist inzwischen online."
		,"`\$Error:`4 That user is not in a location that you can attack them."=>"`\$Fehler:`4 Dieser Krieger befindet sich nicht an einen Ort, wo du ihn angreifen kannst."
		,"`\$Error:`4 That user is not alive."=>"`\$Fehler:`4 Dieser Krieger lebt nicht."
		,"`4Judging by how tired you are, you think you had best not engage in another player battle today."=>"`4Du bist zu m�de, um heute einen weiteren Kampf mit einem Krieger zu riskieren."
		,"`\$Error:`4 That user was not found!  How'd you get here anyhow?"=>"`\$Fehler:`4 Dieser Krieger wurde nicht gefunden. Darf ich fragen, wie du �berhaupt hier her gekommen bist?"
		,"Your honor prevents you from running"=>"Deine Ehre verbietet es dir wegzulaufen"
		,"Your honor prevents you from using a special ability"=>"Deine Ehre verbietet es dir, deine besonderen F�higkeiten einzusetzen."
		,"`b`&You have been slain by `%"=>"`b`&Du wurdest besiegt von `%"
		,"`4All gold on hand has been lost!`n"=>"`4Alles Gold, das du bei dir hattest, hast du verloren!`n"
		,"% of experience has been lost!`n"=>"% deiner Erfahrung ging verloren!`n"
		,"You may begin fighting again tomorrow."=>"Du kannst morgen wieder k�mpfen."
		,"`b`\$You have slain "=>"`b`\$Du erledigst "
		,"`#You recieve `^"=>"`#Du findest `^"
		,array(
			"`#You also recieve `^"=>"`#Ausserdem bekommst du das Kopfgeld in H�he von `^"
			,"`# in bounty gold!`n"=>"`# Gold!`n"
		)
		,array(
			"You receive `^"=>"Du bekommst insgesamt `^"
			,"total experience!"=>"Erfahrungspunkte!"
			,"`#***Because of the simplistic nature of this fight, you are penalized `^"=>"`#*** Weil dieser Kampf so leicht war, verlierst du `^"
			,"`# experience! `n"=>"`# Erfahrungspunkte! `n"
			,"`#***Because of the difficult nature of this fight, you are awarded an additional `^"=>"`#*** Durch die hohe Schwierigkeit des Kampfes erh�ltst du zus�tzlich `^"
		)
		,"Daily news"=>"T�gliche News"
		// part from "common.php"
		,"`\$Warning!`^ Since you were still under PvP immunity, but have chosen to attack another player, you have lost this immunity!!`n`n"=>"`\$Warnung!`^ Da du selbst noch vor PvP gesch�tzt warst, aber jetzt selbst einen anderen Spieler angreifst, hast du deinen Immunit�t verloren!!`n`n"
		,array(
			"`\$Warning!`^ Players are immune from Player vs Player (PvP) combat for their first "=>"`\$Warnung!`^ Innerhalb der ersten "
			," days in the game or until they have earned "=>" Tage in dieser Welt, oder bis sie "
			," experience, or until they attack another player.  If you choose to attack another player, you will lose this immunity!`n`n"=>" Erfahrungspunkte gesammelt haben, sind alle Spieler vor PvP-Angriffen gesch�tzt. Wenn du einen anderen Spieler angreifst, verf�llt diese Immunit�t f�r dich!`n`n"
		)
		// end common		
		// battle (battle.php & common.php)
		,"You feel mortal again."=>"Du bist wieder sterblich."
		,"`n`&You feel godlike`n`n"=>"`n`&Du f�hlst dich gottgleich`n`n"
		,"`\$`c`b~ ~ ~ Fight ~ ~ ~`b`c`0"=>"`\$`c`b~ ~ ~ Kampf ~ ~ ~`b`c`0"
		,array(
			"You have encountered `^"=>"Du hast `^"
			,"`@ which lunges at you with `%"=>"`@ gefunden. Dein Gegner st�rzt sich mit seiner Waffe `%"
			,"`@!`0`n`n"=>"`@ auf dich!`0`n`n"
		)
		,"`2Level: `6Undead`0`n"=>"`2Level: `6Untoter`0`n"
		,"`2`bStart of round:`b`n"=>"`2`bBeginn der Runde:`b`n"
		,"`2`bEnd of Round:`b`n"=>"`2`bEnde der Runde:`b`n"
		,"`&The gods have suspended any special effects!`n"=>"`&Die G�tter verbieten den Einsatz jeder Spezialf�higkeit!`n"
		,"'s bodyguard protects them!`n`n"=>" ist durch einen Leibw�chter gesch�tzt!`n`n"
		,"The bodyguard seems to have fallen asleep."=>"Der Leibw�chter scheint eingeschlafen zu sein."
		,"`\$'s skill allows them to get the first round of attack!`0`b`n`n"=>"`\$'s F�higkeiten erlauben deinem Gegner den ersten Schlag!`0`b`n`n"
		,"`\$ surprises you and gets the first round of attack!`0`b`n`n"=>"`\$ �berrascht dich und hat den ersten Schlag!`0`b`n`n"
		,"`b`\$Your skill allows you to get the first attack!`0`b`n`n"=>"`b`\$Dein K�nnen erlaubt dir den ersten Angriff!`0`b`n`n"
		,array(
			"`7`bYou execute a minor power move!`b`0`n"=>"`7`bDu holst zu einem kleinen Powerschlag aus!`b`0`n"
			,"`&`bYou execute a power move!!!`b`0`n"=>"`&`bDu holst zu einem Powerschlag aus!!!`b`0`n"
			,"`&`bYou execute a DOUBLE power move!!!`b`n"=>"`&`bDu holst zu einem DOPPELTEN Powerschlag aus!!!`b`n"
			,"`&`bYou execute a "=>"`&`bDu holst zu einem "
			," power move!!!`b`n"=>" Powerschlag aus!!!`b`n"
		)
		,"`4You are too busy trying to run away like a cowardly dog to try to fight `^"=>"`4Du bist zu besch�ftigt damit wegzulaufen wie ein feiger Hund und kannst nicht k�mpfen gegen `^"
		,"`&The gods have restored your special effects.`n`n"=>"`&Die G�tter gew�hren dir wieder alle deine speziellen F�higkeiten.`n`n"
		,array(
			"'s bodyguard hits you for `\$"=>"'s Leibw�chter trifft dich mit `\$"
			,"'s bodyguard tries to it you but `\$MISSES`7!"=>"'s Leibw�chter schl�gt zu, aber `\$TRIFFt NICHT`7!"
			,"`4 tries to hit you but `\$MISSES!`n"=>"`4 versucht dich zu treffen, aber `\$TRIFFT NICHT!`n"
			,"`4 tries to hit you but you `^RIPOSTE`4 for `^"=>"`4 versucht dich zu treffen, aber dein `^GEGENSCHLAG`4 trifft mit `^"
			,"`4You try to hit "=>"`4Du versuchst "
			,"`4 but `\$MISS!`n"=>"`4 zu treffen, aber du `\$TRIFFST NICHT!`n"
			,"`4 but are `\$RIPOSTED `4for "=>"`4 zu treffen, aber sein `\$GEGENSCHLAG`4 trifft dich mit "
			,"Soulpoints"=>"Seelenpunkte"
			,"Hitpoints"=>"Lebenspunkte"
			,"`4 points of damage!`n"=>"`4 Schadenspunkten!`n"
			,"`) points!"=>"`) Schadenspunkte!"
			,"`) damage."=>"`) Schadenspunkte."
			,"`7 damage."=>"`7 Schadenspunkten."
			,"`4You hit `^"=>"`4Du triffst `^"
			,"`4 hits you for `\$"=>"`4 trifft dich mit `\$"
			,"`2YOUR "=>"`2DEINE "
			," for `^"=>" mit `^"
			,"`) points."=>"`) Punkten."
			," health."=>" Gesundheitspunkte"
		)
		,"Fight"=>"K�mpfen!"
		// end battle
		);
		break;
	case "referral.php":
		$replace = array(
		"Return to the Lodge"=>"Zur�ck zur Lodge"
		,array(
			"You will automatically receive 25 points for each person that you refer to this website who makes it to level 4."=>"Du bekommst automatisch 25 Punkte f�r jeden geworbenen Charakter, der es bis Level 4 schafft."
			,"How does the site know that I referred a person?"=>"Woher weiss die Seite, dass ich eine Person geworben habe?"
 			,"Easy!  When you tell your friends about this site, give out the following link:"=>"Kleinigkeit! Wenn du Freunden von dieser Seite erz�hlst, gib ihnen einfach folgenden Link:"
			,"and the site will know that you were the one who sent them here.  When they reach level 4 for the first time, you'll get your points!"=>"Dadurch wird die Seite wissen, dass du derjenige warst, der ihn hergeschickt hat. Wenn er dann zum ersten Mal Level 4 erreicht, bekommst du deine Punkte!"
			,"Accounts which you referred:"=>"Accounts, die du geworben hast:"
			,"Awarded"=>"Belohnt"
		)
		,"None"=>"Keiner"
		,"Welcome to Legend of the Green Dragon"=>"Willkommen bei Legend of the Green Dragon"
		,array(
			"`@Legend of the Green Dragon is a remake of the classic BBS Door Game Legend of the Red Dragon."=>"`@Legend of the Green Dragon ist ein Remake des klassischen BBS Spiels Legend of the Rad Dragon."
			,"Adventure in to the classic realm that was one of the world's very first multiplayer roleplaying games!"=>"Komm rein und nehme am Abenteuer in einem Realm teil, der eines der ersten Multiplayer Rollenspiele der Welt darstellte!"
		)
		,"Create a character"=>"Charakter erstellen"
		,"Login Page"=>"Zum Login"
		);
		break;
	case "rock.php":
		$replace = array(
		"`b`c`2The Veteran's Club`0`c`b"=>"`b`c`2Der Club der Veteranen`0`c`b"
		,"`n`n`4Something in you compels you to examine the curious rock.  Some dark magic, locked up in age old horrors."=>"`n`n`4Irgendetwas in dir zwingt dich, den merkw�rdig aussehenden Felsen zu untersuchen. Irgendeine dunkle Magie, gefangen in uraltem Grauen."
 		,"`n`nWhen you arrive at the rock, an old scar on your arm begins to throb in succession with a mysterious light that "=>"`n`nAls du am Felsen ankommst, f�ngt eine alte Narbe an deinem Arm im an zu pochen. Das Pochen ist mit einem r�stelhaften Licht synchron, "
		,"now seems to come from the rock.  As you stare at it, the rock shimmers, shaking off an illusion.  You realize that this is "=>"das jetzt von dem Felsen zu kommen scheint. Gebannt starrst du auf den schimmernden Felsen, der eine Sinnest�uschung von dir absch�ttelt. Du erkennst, da� das mehr "
 		,"more than a rock.  It is, in fact, a doorway, and over the threshold, you see others, bearing an identical scar to yours.  It "=>"als ein Felsbrocken ist. Tats�chlich ist es ein Eingang, �ber dessen Schwelle du andere wie dich siehst, die auch die selbe Narbe wie du tragen. Sie "
		,"somehow reminds you of the head of one of the great serpents from legend.  You have discovered The Veteran's Club."=>" erinnert dich irgendwie an den Kopf einer dieser riesigen Schlangen aus Legenden. Du hast den Club der Veteranen entdeckt."
		,"You approach the curious looking rock.  After staring, and looking at it for a little while, it continues to look just like a curious looking rock.`n`n"=>"Du n�herst dich dem seltsam aussehenden Felsen. Nachdem du ihn eine ganze Weile angestarrt hast, bleibt es auch weiterhin nur ein seltsam aussehnder Felsen.`n`n"
		,"Bored, you decide to return to the village."=>"Gelangweilt gehst du zum Dorfplatz zur�ck."
		,"Return to the village"=>"Zur�ck zum Dorf"
		,"Boast here"=>"hier angeben"
		,"drunkenly boasts,"=>"prahlt betrunken:"
		,"boasts,"=>"prahlt:"
		,"says,"=>"sagt:"
		// part from "common.php"
		,"Previous"=>"Vorherige"
		,"Refresh"=>"Aktualisieren"
		,"Next"=>"N�chste"
		// end of common
		);
		break;
	case "shades.php":
		$replace = array(
		array(
			"`\$You walk among the dead now, you are a shade.  Everywhere around you are the souls of those who have fallen in battle, in old age, "=>"`\$Du wandelst jetzt unter den Toten, du bist nur noch ein Schatten. �berall um dich herum sind die Seelen der in alten Schlachten und bei "
			,"and in grievous accidents.  Each bears telltale signs of the means by which they met their end."=>"gelegentlichen Unf�llen gefallenen K�mpfer. Jede tr�gt Anzeichen der Niedertracht, durch welche sie ihr Ende gefunden haben. "
			,"Their souls whisper their torments, haunting your mind with their despair:`n"=>"Sie fl�stern ihre Qualen und plagen deinen Geist mit ihrer Verzweiflung.`n"
		)
		,"Despair"=>"Verzweifeln:"
		,"The Graveyard"=>"Zum Friedhof"
		,"Return to the news"=>"Zur�ck zu den News"
		,"Superuser Grotto"=>"Adminbereich"
		,"despairs, "=>"verzweifelt: "
		,"projects, "=>"wirft ein: "
		// part from "common.php"
		,"Previous"=>"Vorherige"
		,"Refresh"=>"Aktualisieren"
		,"Next"=>"N�chste"
		// end common
		);
		break;
	case "stables.php":
		$replace = array(
		array(
			"`7Behind the inn, and a little to the left of Pegasus Armor, is as fine a stable as one"=>"`7Hinter der Kneipe, etwas links von Pegasus' Waffen, befindet sich ein Stall, "
			,"might expect to find in any village.  "=>"wie man ihn in jedem Dorf erwartumgsgem�� findet.  "
			,"In it, Merick, a burly looking dwarf tends to various beasts."=>"Darin k�mmerst sich Merick, ein st�mmig wirkender Zwerg, um verschiedene Tiere."
			,"You approach, and he whirls around, pointing a pitchfork in your general direction, \"`&Ach, "=>"Du n�herst dich ihm, als er pl�tzlich herumwirbelt und seine Heugabel in deine ungef�hre Richtung streckt. \"`&Ach, "
			,"sorry m'lass, I dinnae hear ya' comin' up on me, an' I thoht"=>"'tschuldigung min M�dl, heb dich nit kommen h�rn un heb gedenkt, "
			,"sorry m'lad, I dinnae hear ya' comin' up on me, an' I thoht"=>"'tschuldigung min Jung, heb dich nit kommen h�rn un heb gedenkt, "
			,"fer sure ye were Cedrik; he what been tryin' to improve on his dwarf tossin' skills.  Naahw, wha'"=>"du bischt sicha Cedrik, der ma widda sein Zwergenweitwurf ufbessern will. Naaahw, wat"
			,"can oye do fer ya?`7\" he asks.  "=>" kann ich f�r disch tun?`7\""
		)
		,"`7\"`&Ach, thar dinnae be any such beestie here!`7\" shouts the dwarf!"=>"`7\"`&Ach, ich heb keen solches Tier da!`7\" ruft der Zwerg!"
		,"`7\"`&Aye, tha' be a foyne beestie indeed!`7\" comments the dwarf.`n`n"=>"`7\"`&Ai, ich heb wirklich n paar feine Viecher hier!`7\" kommentiert der Zwerg.`n`n"
		,array(
			"`7Merick looks at you sorta sideways.  \"`&'Ere, whadday ya think yeer doin'?  Cannae ye see that "=>"`7Merick schaut dich schief von der Seite an. \"`&�hm, was gl�ubst du was du hier machst? Kanns u nich sehen, dass "
			," costs `^"=>" `^"
			,"`& gold an' `%"=>"`& Gold und `%"
			,"`& gems?`7\""=>"`& Edelsteine kostet?`7\""
		)
		,array(
			"`7You hand over the reins to your "=>"`7Du �bergibst dein(e/n) "
			," and the purchase price of your new critter, and Merick leads out a fine new `&"=>" und bezahlst den Preis f�r dein neues Tier. Merick f�hrt ein(e/n) sch�ne(n/s) neue(n/s) `&"
			,"`7You hand over the purchase price of your new critter, and Merick leads out a fine `&"=>"`7Du bezahlst den Preis f�r dein neues Tier und Merick f�hrt ein(e/n) sch�ne(n/s) neue(n/s) `&"
			,"`7 for you!`n`n"=>"`7 f�r dich heraus!`n`n"
		)
		,array(
			"`7As sad as it is to do so, you give up your precious "=>"`7So schwer es dir auch f�llt, dich von dein(er/em) "
			,", and a lone tear escapes your eye.`n`n"=>" zu trennen, tust du es doch und eine Tr�ne entkommt deinen Augen.`n`n"
		)
		,"Sell your "=>"Verkaufe dein(e/n) "
		,array(
			"However, the moment you spot the "=>"Aber in dem Moment, wo du die "
			,"`n`nMerick offers you `^"=>"`n`n`&Merick bietet dir `^"
			,"`& gold and `%"=>"`& Gold und `%"
			,"`& gems for your "=>"`& Edelsteine f�r dein(e/n) "
			," and "=>" und "
			,"`7 gems"=>"`7 Edelsteine"
			,", you find that you're feeling quite a bit better."=>" siehst, f�hlst du dich schon wieder besser."
		)
		,"`7Creature: `&"=>"`7Kreatur: `&"
		,"`7Description: `&"=>"`7Beschreibung: `&"
		,array(
			"`7Cost: `^"=>"`7Kosten: `^"
			,"`& gold, `%"=>"`& Gold, `%"
			,"`& gems`n"=>"`& Edelsteine`n"
		)
		,"Buy this creature"=>"Dieses Tier kaufen"
		,"Examine "=>"Begutachte "
		,"Return to the village"=>"Zur�ck ins Dorf"
		);
		break;
	case "train.php":
		$replace = array(
		"Bluspring's Warrior Training"=>"Bluspring's Trainingslager f�r Krieger"
		,"You call yourself an Elf?? Maybe Half-Elf! Come back when you've been better trained."=>"Sowas nennt sich Elf?? Halb-Elf h�chstens! Komm wieder, wenn du mehr trainiert hast."
		,"It is only fitting that another Elf should best me.  You make good progress."=>"Es ist nur passend, dass ein anderer Elf sich mit mir messen konnte. Du machst gute Fortschritte."
		,"The sound of conflict surrounds you.  The clang of weapons in grizzly battle inspires your warrior heart. "=>"Der Klang von Kampf umf�ngt dich. Das Geklirr von Waffen in m�chtigen K�mpfen l�sst dein Kriegerherz h�her schlagen. "
		,"You think that, perhaps, you've seen enough of your master for today, the lessons you learned earlier prevent you from so willingly "=>"Du bist der Meinung, dass du heute vielleicht schon genug von deinem Meister hast. Die Lektion, die du heute gelernt hast, h�lt dich davon ab, dich nochmal so bereitwillig "
		,"subjecting yourself to that sort of humiliation again."=>"einer derartigen Dem�tigung zu unterwerfen."
		,array(
			"You approach `^"=>"Furchtsam n�herst du dich `^"
			,"`0 timidly and inquire as to your standing in his class."=>"`0, um ihn zu fragen, ob du bereits in der selben Klasse wie er k�mpfst. "
		)
		,"`0 says, \"Gee, your muscles are getting bigger than mine...\""=>"`0 sagt: \"Gee, deine Muskeln werden ja gr�sser als meine...\""
		,array(
			"`0 states that you will need `%"=>"`0 ist der Meinung, dass du noch mindestens `5"
			,"`0 more experience before you are ready to challenge him in battle."=>"`0 Erfahrungspunkte mehr brauchst, bevor du bereit bist, ihn zu einem Kampf herauszufordern. "
		)
		,array(
			"`0 has heard of your prowess as a warrior, and heard of rumors that you think"=>"`0 ist deine Tapferkeit als Krieger zu Ohren gekommen, und er hat Ger�chte geh�rt, dass du glaubst, "
			,"you are so much more powerful than him that you don't even need to fight him to prove anything.  His ego is"=>"du bist so viel m�chtiger als er, dass du nichteinmal gegen ihn k�mpfen m�sstest, um irgendetwas zu beweisen. Das hat sein Ego "
			,"understandably bruised, and so he has come to find you.  `^"=>"verst�ndlicherweise verletzt. So hat er sich aufgemacht, dich zu finden. `^"
			,"`0 Demands an immediate"=>"`0 fordert einen sofortigen "
			,"battle from you, and your own pride prevents you from refusing his demand."=>"Kampf von dir und dein eigener Stolz hindert dich daran, seine Forderung abzulehnen."
		)
		,"With a flurry of blows you dispatch your master.`n"=>"Mit einem Wirbelsturm aus Schl�gen schl�gst du deinen Meister nieder.`n"
		,"`n`nBeing a fair person, your master gives you a healing potion before the fight begins."=>"`n`nAls fairer K�mpfer gibt dir dein Meister vor dem Kapmf einen Heiltrank."
		,"Your pride prevents you from running from this conflict!"=>"Dein Stolz verbietet es dir, vor diesem Kampf wegzulaufen! "
		,"Your pride prevents you from using any special abilities during the fight!"=>"Dein Stolz verbietet es dir, w�hrend des Kampfes Gebrauch von deinen besonderen F�higkeiten zu machen. "
		,"You stroll in to the battle grounds.  Younger warriors huddle together and point as you pass by.  "=>"Du bummelst �ber den �bungsplatz. J�ngere Krieger dr�ngen sich zusammen und deuten auf dich, als du vor�ber l�ufst.  "
		,"You know this place well.  Bluspring hails you, and you grasp her hand firmly.  There is nothing "=>"Du kennst diesen Platz gut. Bluspring gr��t dich und du gibts ihr einen starken H�ndedruck. Au�er Erinnerungen "
		,"left for you here but memories.  You remain a moment longer, and look at the warriors in training "=>"gibt es hier nichts mehr f�r dich. Du bleibst noch eine Weile und siehst den jungen Kriegern beim Training zu, bevor du "
		,"before you turn to return to the village."=>"zum Dorf zur�ckkehrst. "
		,"Return to the Village"=>"Zur�ck ins Dorf"
		,"Return to the village"=>"Zur�ck ins Dorf"
		,"Fight Your Master"=>"Gegen den Meister antreten"
		,"Superuser Gain level"=>"Superuser Level erh�hen"
		,"`n`nYour master is `^"=>"`n`nDein Meister ist `^"
		,"Question Master"=>"Meister befragen"
		,"Challenge Master"=>"Meister herausfordern"
		,"`b`\$You have defeated "=>"`b`\$Du bezwingst deinen Meister "
		,"`#You advance to level `^"=>"`#Du steigst auf zu Level `^"
		,"Your maximum hitpoints are now `^"=>"Deine maximalen Lebenspunkte sind jetzt `^"
		,"You gain an attack point!`n"=>"Du bekommst einen Angriffspunkt dazu!`n"
		,"You gain a defense point!`n"=>"Du bekommst einen Verteidigungspunkt dazu!`n"
		,"You have a new master.`n"=>"Du hast jetzt einen neuen Meister.`n"
		,"None in the land are mightier than you!`n"=>"Keiner im Land ist m�chtiger als du!`n"
		,"`&`bYou have been defeated by `%"=>"`&`bDu wurdest besiegt von `%"
		,"`\$ halts just before delivering the final blow, and instead extends a hand to help you to your feet, and hands you a complimentary healing potion.`n"=>"`\$ h�lt vor dem vernichtenden Schlag inne und reicht dir stattdessen seine Hand, um dir auf die Beine zu helfen. Er verabreicht dir einen kostenlosen Heiltrank.`n"
		// from database
		,array(
			"Well done "=>"Gut gemacht "
			,", I should have guessed you'd grown some."=>", ich h�tte wissen sollen, dass du etwas gewachsen bist."
			,"As I thought, "=>"Wie ich es mir gedacht habe, "
			,", your skills are no match for my own!"=>", dein K�nnen reicht an das meine nicht heran."
			,", you really know how to use your "=>", du weisst wirklich etwas anzufangen mit "
			,"You should have known you were no match for my "=>"Du h�ttest wissen m�ssen, dass du keine Chance hast gegen mein "
			,"Aah, defeated by the likes of you!  Next thing you know, Mireraband will be hunting me down!"=>"Aah! Besiegt von jemandem wie dir! Als n�chstes wird mich wohl Mireraband fertigmachen."
			,"Haha, maybe you should go back to Mireraband's class."=>"Haha, vielleicht solltest du zur�ck in die Klasse von Mireraband."
			,"Ha!  Hahaha, excellent fight "=>"Ha! Hahaha, exzellenter Kampf "
			,"!  Haven't had a battle like that since I was in the RAF!"=>"! Hab so einen Kampf schon nicht mehr erlebt, seit ich damals in der RAF war!"
			,"Back in the RAF, we'd have eaten the likes of you alive!  Go work on your skills some old boy!"=>"Damals in der RAF haben wir deinesgleichen lebendig gefr�hst�ckt. Geh an deinen Fertigkeiten arbeiten, alter Knabe."
			,"Your mind is greater than mine.  I concede defeat."=>"Dein Geist ist st�rker als meiner. Ich gebe auf."
			,"Your mental powers are lacking.  Meditate on this failure and perhaps some day you will defeat me."=>"Deine mentalen Kr�fte haben noch Schw�chen. Meditiere �ber dein Versagen und vielleicht wirst du mich eines Tages besiegen k�nnen."
			,"Ach!  Y' do hold yer "=>"Ach!  Du f�hrst dein "
			," with skeel!"=>" mit K�nnen!"
			,"Har!  Y' do be needin moore praktise y' wee cub!"=>"Har! Du brauchst noch viel �bung!" 
			,"Hmm, mayhaps I underestimated you."=>"Hmm, eventunnel hab ich dich untersch�tzt."
			,"As I thought."=>"Wie ich dachte."
			,", I can see that great things lie in the future for you!"=>", Ich sehe grosse Taten in deiner Zukunft liegen."
			,"You are becoming powerful, but not yet that powerful."=>"Du wirst zwar m�chtig, aber nicht so m�chtig bis jetzt."
			,"Perhaps I should have considered your "=>"Vielleicht h�tte ich etwas nehmen sollen wie dein "
			,"Perhaps you'll reconsider my twin swords before you try that again?"=>"Vielleicht solltest du mal �ber ein Twin Sword nachdenken, bevor du es nochmal versuchst."
			,"Your style was superior, your form greater.  I bow to you."=>"Dein Stil war �berlegen, deine Verfassung besser. Ich verneige mich vor dir."
			,"Learn to adapt your style, and you shal prevail."=>"Lerne deinen Stil anzupassen und du k�nntest siegen."
			,"Wow, how did you dodge all those halos?"=>"Wow, wie konntest du all diese Halos austricksen?"
			,"Watch out for that last halo, it's coming back this way!"=>"Vorsicht for diesem letzten Halo, er kommt hierher zur�ck!"
			,"I can accept that you defeated me, because after all elves are immortal while you are not, so the victory will be mine."=>"Ich kann akzeptieren, dass du mich besiegt hast, weil Elfen sind unsterblich, du aber nicht. So wird der Sieg am Ende doch mein sein."
			,"Do not forget that elves are immortal.  Mortals will likely never defeat one of the fey."=>"Vergiss nicht, dass Elfen unsterblich sind. Sterbliche werden wahrscheinlich niemals einen von uns besigen."
			,"If I could have picked up this sword, I probably would have done better!"=>"Wenn ich dieses Schwert h�tte aufheben k�nnen, w�re ich wahrscheinlich besser gewesen."
			,"Haha, I couldn't even pick the sword UP and I still won!"=>"Haha, ich konnte nichtmal das Schwert aufheben und hab trotzdem gewonnen!"
			,"Well, you evaded my touch.  I salute you!"=>"Nun, du konntest meiner Ber�hrung ausweichen. Ich gratuliere dir."
			,"Watch out for my touch next time!"=>"H�te dich das n�chste Mal vor meiner Ber�hrung!" 
		)
		// end database
		// battle (battle.php & common.php)
		,"You feel mortal again."=>"Du bist wieder sterblich."
		,"`n`&You feel godlike`n`n"=>"`n`&Du f�hlst dich gottgleich`n`n"
		,"`\$`c`b~ ~ ~ Fight ~ ~ ~`b`c`0"=>"`\$`c`b~ ~ ~ Kampf ~ ~ ~`b`c`0"
		,array(
			"You have encountered `^"=>"Du stehst `^"
			,"`@ which lunges at you with `%"=>"`@ gegen�ber, der sich mit seiner Waffe `%"
			,"`@!`0`n`n"=>"`@ auf dich st�rzt!`0`n`n"
		)
		,"`2`bStart of round:`b`n"=>"`2`bBeginn der Runde:`b`n"
		,"`2`bEnd of Round:`b`n"=>"`2`bEnde der Runde:`b`n"
		,"`&The gods have suspended any special effects!`n"=>"`&Die G�tter verbieten den Einsatz jeder Spezialf�higkeit!`n"
		,"`\$'s skill allows them to get the first round of attack!`0`b`n`n"=>"`\$'s F�higkeiten erlauben deinem Gegner den ersten Schlag!`0`b`n`n"
		,"`\$ surprises you and gets the first round of attack!`0`b`n`n"=>"`\$ �berrascht dich und hat den ersten Schlag!`0`b`n`n"
		,"`b`\$Your skill allows you to get the first attack!`0`b`n`n"=>"`b`\$Dein K�nnen erlaubt dir den ersten Angriff!`0`b`n`n"
		,array(
			"`7`bYou execute a minor power move!`b`0`n"=>"`7`bDu holst zu einem kleinen Powerschlag aus!`b`0`n"
			,"`&`bYou execute a power move!!!`b`0`n"=>"`&`bDu holst zu einem Powerschlag aus!!!`b`0`n"
			,"`&`bYou execute a DOUBLE power move!!!`b`n"=>"`&`bDu holst zu einem DOPPELTEN Powerschlag aus!!!`b`n"
			,"`&`bYou execute a "=>"`&`bDu holst zu einem "
			," power move!!!`b`n"=>" Powerschlag aus!!!`b`n"
		)
		,"`4You are too busy trying to run away like a cowardly dog to try to fight `^"=>"`4Du bist zu besch�ftigt damit wegzulaufen wie ein feiger Hund und kannst nicht k�mpfen gegen `^"
		,"`&The gods have restored your special effects.`n`n"=>"`&Die G�tter gew�hren dir wieder alle deine speziellen F�higkeiten.`n`n"
		,array(
			"`4 tries to hit you but `\$MISSES!`n"=>"`4 versucht dich zu treffen, aber `\$TRIFFT NICHT!`n"
			,"`4 tries to hit you but you `^RIPOSTE`4 for `^"=>"`4 versucht dich zu treffen, aber dein `^GEGENSCHLAG`4 trifft mit `^"
			,"`4You try to hit "=>"`4Du versuchst "
			,"`4 but `\$MISS!`n"=>"`4 zu treffen, aber du `\$TRIFFST NICHT!`n"
			,"`4 but are `\$RIPOSTED `4for "=>"`4 zu treffen, aber sein `\$GEGENSCHLAG`4 trifft dich mit "
			,"Hitpoints"=>"Lebenspunkte"
			,"`4 points of damage!`n"=>"`4 Schadenspunkten!`n"
			,"`) points!"=>"`) Schadenspunkte!"
			,"`) damage."=>"`) Schadenspunkte."
			,"`7 damage."=>"`7 Schadenspunkten."
			,"`4You hit `^"=>"`4Du triffst `^"
			,"`4 hits you for `\$"=>"`4 trifft dich mit `\$"
			,"`2YOUR "=>"`2DEINE "
			," for `^"=>" mit `^"
			,"`) points."=>"`) Punkten."
			," health."=>" Gesundheitspunkte"
		)
		,"Fight"=>"K�mpfen!"
		// end battle
		,array(
			"You ready your "=>"Du machst dich mit "
			," and approach `^"=>" bereit und n�herst dich Meister `^"
			,"`0.`n`nA small crowd of onlookers "=>"`0.`n`nEine kleine Menge Zuschauer "
			,"has gathered, and you briefly notice the smiles on their faces, but you feel confident.  You bow before `^"=>"hat sich versammelt und du bemerkst das grinsen in ihren Gesichtern. Aber du f�hlst dich selbstsicher. Du verbeugst dich vor `^"
			,"a perfect spin-attack, only to realize that you are holding NOTHING!"=>"einen perfekten Drehangriff aus, nur um zu bemerken, dass du NICHTS in den H�nden hast!"
			,"`0 stands before you holding your weapon."=>"`0 steht vor dir - mit deiner Waffe in der Hand."
			,"`0, and execute "=>"`0, und f�hrst "
			,"Meekly you retrieve your "=>"Kleinlaut nimmst du "
			,", and slink out of the training grounds to the sound of boisterous guffaw's."=>" entgegen und schleichst unter dem schallenden Gel�chter der Zuschauer vom Trainingsplatz."
			," and "=>" und "
		)
		,array(
			"You gain a level in"=>"Du steigst 1 Level auf in"
			,"only"=>" damit fehlen dir noch"
			,"more skill levels until you gain an extra use point!"=>"Fertigkeitspunkte, um eine weitere Anwendung pro Tag zu erhalten!"
			,"you gain an extra use point!"=>"du hast eine zus�tzliche Anwendung erhalten!"
			,"Thievery"=>"Diebesk�nsten"
			,"Dark Arts"=>"Dunklen K�nsten"
			,"Mystical Powers"=>"Mystische Kr�fte"
		)
		);
		break;
	case "weapons.php":
		$replace = array(
		"`c`b`&MightyE's Weapons`0`b`c"=>"`c`b`&MightyE's Waffen`0`b`c"
		,"`!MightyE `7stands behind a counter and appears to pay little attention to you as you enter, "=>"`!MightyE `7 steht hinter einem Ladentisch und scheint dir nur wenig Interesse entgegen zu bringen, als du eintrittst."
		,"but you know from experience that he has his eye on every move you make.  He may be a humble "=>"Aus Erfahrung weisst du aber, dass er jede deiner Bewegungen misstrauisch beobachtet. Er mag ein bescheidener "
		,"weapons merchant, but he still carries himself with the grace of a man who has used his weapons "=>"Waffenh�ndler sein, aber er tr�gt immer noch Grazie eines Mannes in sich, der seine Waffen gebraucht hat, "
		,"to kill mightier ".($session[user][gender]?"women":"men")." than you.`n`n"=>"um st�rkere ".($session[user][gender]?"Frauen":"M�nner")." als dich zu t�ten.`n`n"
		,"The massive hilt of a claymore protrudes above his shoulder; its gleam in the torch light not "=>"Der massive Griff eines Claymore ragt ragt hinter seiner Shulter hervor, dessen Schimmer im Licht der Fackeln "
		,"much brighter than the gleam off of `!MightyE's`7 bald forehead, kept shaved mostly as a strategic "=>"viel heller wirkt, als seine Glatze, die er mehr zum strategischen Vorteil rasiert h�lt, "
		,"advantage, but in no small part because nature insisted that some level of baldness was necessary. "=>"obwohl auch die Natur bereits auf einem bestimmten Level der Kahlk�pgigkeit besteht. "
		,"`n`n`!MightyE`7 finally nods to you, stroking his goatee and looking like he wished he could "=>"`n`n`!MightyE`7 nickt dir schliesslich zu und w�nscht sich, w�hrend er seinen Spitzpart streichelt, "
		,"have an opportunity to use one of these weapons."=>"eine Gelegenheit um eine seiner Waffen benutzen zu k�nnen."
		,"Peruse Weapons"=>"Waffen anschauen"
		,"Return to the village"=>"Zur�ck ins Dorf"
		,"`7You stroll up the counter and try your best to look like you know what most of these contraptions do. "=>"`7Du schlenderst durch den Laden und tust dein Bestes so auszusehen, als ob du w��test, was die meisten dieser Objekte machen. "
		,array(
			"`!MightyE`7 looks at you and says, \"`#I'll give you `^"=>"`!MightyE`7 schaut dich an und sagt \"`#Ich gebe dir `^"
			,"tradein value for your `5"=>"Gold f�r `5"
			,"`#.  Just click on the weapon you wish to buy, what ever 'click' means`7,\" and "=>"`#. Klicke einfach auf die Waffe, die du kaufen willst... was auch immer 'klick' bedeuten mag`7 \". " 
		)
		,"looks utterly confused.  He stands there a few seconds, snapping his fingers and wondering if that is what "=>"Dabei schaut er v�llig verwirrt. Er steht ein paar Sekunden nur da, schnippt mit den Fingern und fragt sich, ob das "
		,"is meant by \"click,\" before returning to his work: standing there and looking good."=>"mit 'klicken' gemeint sein k�nnte, bevor er sich wieder seiner Arbeit zuwendet: Herumstehen und gut aussehen.`n`n"
		,"`!MightyE`7 looks at you, confused for a second, then realizes that you've apparently taken one too many bonks on the head, and nods and smiles."=>"`!MightyE`7 schaut dich eine Sekunde lang verwirrt an und kommt zu dem Schluss, da� du ein paar Schl�ge zuviel auf den Kopf bekommen hast. Schliesslich nickt er und grinst. "
		,array(
			"Waiting until `!MightyE`7 looks away, you reach carefully for the `5"=>"W�hrend du wartest, bis `!MightyE`7 in eine andere Richtung schaut, n�herst du dich vorsichtig dem `5"
			,"`7, which you silently remove from the rack upon which "=>"`7 und nimmst es leise vom Regal. "
		)
		,"it sits.  Secure in your theft, you turn around and head for the door, swiftly, quietly, like a ninja, only to discover that upon reaching "=>"Deiner fetten Beute gewiss drehst du dich leise, vorsichtig, wie ein Ninja, zur T�r, nur um zu entdecken, "
		,"the door, the ominous `!MightyE`7 stands, blocking your exit.  You execute a flying kick.  Mid flight, you hear the \"SHING\" of a sword "=>"dass `!MightyE`7 drohend in der T�r steht und die den Weg abschneidet. Du versuchst einen Flugtritt. Mitten im Flug h�rst du das \"SCHING\" eines Schwerts, "
		,"leaving its sheath.... your foot is gone.  You land on your stump, and `!MightyE`7 stands in the doorway, claymore once again in its back holster, with "=>"das seine Scheide verl�sst.... dein Fu� ist weg. Du landest auf dem Beinstumpf und `!MightyE`7 steht immer noch im Torbogen, das Schwert ohne Gebrauchsspuren wieder im  Halfter und mit "
		,"no sign that it had been used, his arms folded menacingly across his burly chest.  \"`#Perhaps you'd like to pay for that?`7\" is all he has "=>"vor der st�mmigen Brust bedrohlich verschr�nkten Armen. \"`#Vielleicht willst du daf�r bezahlen?`7\" ist alles, was er sagt, "
		,"to say as you collapse at his feet, lifeblood staining the planks under your remaining foot."=>"w�hrend du vor seinen F��en zusammen brichst und deinen Lebenssaft unter deinem dir verbliebenen Fu� �ber den Boden aussch�ttest. "
		,"`b`&You have been slain by `!MightyE`&!!!`n"=>"`b`&Du wurdest von `!MightyE`& niedergemetzelt!!!`n"
		,"`4All gold on hand has been lost!`n"=>"`4Er hat sich alles Gold genommen, das du dabei hattest!`n"
		,"`410% of experience has been lost!`n"=>"`410% deiner Erfahrung ging verloren!`n"
		,"You may begin fighting again tomorrow."=>"Du kannst morgen wieder k�mpfen."
		,array(
			"`!MightyE`7 takes your `5"=>"`!MightyE`7 nimmt dein `5" 
			,"and promptly puts a price on it, setting it out for display with the rest of his weapons. "=>", stellt es aus und h�ngt sofort ein neues Preisschild dran. "
			,"`n`nIn return, he hands you a shiny new `5"=>"`n`nIm Gegenzug h�ndigt er dir ein gl�nzendes neues `5"
			,"which you swoosh around the room, nearly taking off `!MightyE`7's head, which he "=>"aus, das du probeweise im Raum schwingst. Dabei schl�gst du `!MightyE`7' fast den Kopf ab. "
			,"deftly ducks; you're not the first person to exuberantly try out a new weapon."=>"Er duckt sich so, als ob du nicht der erste bist, der seine neue Waffe sofort ausprobieren will..."
		)
		,array(
			"Damage"=>"Schaden"
			,"Cost"=>"Preis"
		)
		,"Return to the village"=>"Zur�ck zum Dorf"
		,"Try again?"=>"Nochmal versuchen?"
		,"Daily news"=>"T�gliche News"
		);
		break;
// Start Superuser parts -- remove to increase server performance

// End Superuser
	}
	return replacer($input,$replace);
}

?>