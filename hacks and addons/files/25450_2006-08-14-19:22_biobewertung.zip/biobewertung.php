<?
/*
  
  +-----------------------------------+
  | DIESE BOX BITTE NICHT ENTFERNEN   |
  +-----------------------------------+
  | Idee by: Lynera                   |
  | Made by: Draza�ar                 |
  | http://logd.legend-of-vinestra.de |
  | drazaar@legend-of-vinestra.de     |
  | including parts by Blackfin       |
  | including parts of avatars.php    |
  | including parts of bios.php       |
  +-----------------------------------+
  
############# INSTALLATION ##############

SQL:
ALTER TABLE `accounts` ADD `biobew2` INT( 11 ) NOT NULL DEFAULT '0' ;
ALTER TALBE `accounts` ADD `biobewertdatum` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00' ;

--prefs.php:
suche:
        output("$msg");
	output("`nEinstellungen gespeichert");
f�ge darunter ein:
        $session['user']['biotime'] = date('Y-m-d H:i:s');
        
--superuser.php:
an gew�nschter Position einf�gen:
        addnav("Biobewertungen","biobewertung.php");
        
--dragon.php:
suche (2x):
        ,"name"=>1
f�ge darunter ein (2x):
        ,"biotime"=>1
        ,"biobew2"=>1
        ,"biobewertdatum"=>1
        
biobewertung.php ins root Verzeichnis laden.
Fertig.
        
############# INSTALLATION ##############

*/

############# EINSTELLUNGEN #############

define('MAXPOINTS', 75);         # Maximale Punkte, die man verteilen kann f�r eine Bio
define('TIERBIOINSTALLED', FALSE);       # Auf FALSE setzen, wenn es KEINE Tierbio gibt
define('TIERBIO', 'tierbio');   # Nur n�tig, wenn TIERBIOINSTALLED auf TRUE gesetzt ist. Name des Feldes f�r die Tierbio.
define('SYSTEMMAIL', TRUE);     # Auf FALSE stellen, wenn beim Bewerten KEINE Systemmail an den User geschickt werden soll.
define('SERVERNAME', 'Vinestra');       # Name deines Servers, steht in der Systemmail.

define('MAX_AVATAR_WIDTH', 400);        # Welche Breite darf ein Avatar maximal haben?
define('MAX_AVATAR_HEIGHT', 400);       # Welche H�he darf ein Avatar maximal haben?

############# EINSTELLUNGEN #############




require_once "common.php";
isnewday(2);
page_header("Bio - Bewertungssystem");
$out .= "`\$`b`cBIO BEWERTUNGEN`0`c`b`n`n`n";


if(!function_exists("stripcolors")){            //THX Blackfin
        function stripcolors($input) {
                $myout = preg_replace('/[`]./',"",$input);	
                return $myout ;
        }
}

if(!function_exists("getthisdate")){             //THX Blackfin
        function getthisdate($inputtext) {
                  $now_day = date("d") ;
                  $now_date = date("Y-m")."-".$now_day ;	
                  $yes_day =   $now_day -1 ;	
                  $two_days_before_day =   $now_day -2 ;	
                  $yesterday_date = date("Y-m")."-".$yes_day;
                  $two_days_before_date = date("Y-m")."-".$two_days_before_day;
                  
                  if($inputtext=="0000-00-00 00:00:00") $this_postdate = "`\$ unbekannt`0";
                  
                  $this_poststring = $inputtext ;
                  $this_tempdate = substr($this_poststring,0,10) ; 
                  $this_temptime = substr($this_poststring,10,6) ; 
	  			 
                  if($this_tempdate == $now_date) {
                          $this_postdate = "`@Heute um ".$this_temptime."`0" ;
                  }elseif($this_tempdate == $yesterday_date) { 
                          $this_postdate = "`^Gestern um ".$this_temptime."`0" ;
                  }elseif($this_tempdate == $two_days_before_date) { 
                          $this_postdate = "`qVorgestern um ".$this_temptime."`0" ;	
                  }else $this_postdate = date("d.m.Y u\m G:i",strtotime($this_poststring)) ;
                  return $this_postdate ;
        }
}

function bnav($name,$to,$header=FALSE){
    if($header) addnav($header);
    addnav($name,"biobewertung.php?op=".$to);
}

$table = FALSE;

if(!isset($_GET['order'])){
        $order = "acctid";
        $dir = "ASC";
        $ordbef = "acctid";
}else{
        $order = $_GET['order'];
        $ordbef = $_GET['ordbef'];
        $dir = $_GET['dir'];
        if($ordbef==$order && $dir=="ASC" && $_GET['change']==1) $dir = "DESC" ;
        elseif($ordbef==$order && $dir=="DESC" && $_GET['change']==1) $dir = "ASC" ;
        $ordbef =  $order ;
        if(isset($_GET['islen']))  $order = " LENGTH(".$_GET['order'].") " ;
}


$playersperpage = 50;
if($_GET['op']=="notchecked"){
        $sql = "SELECT count(`acctid`) AS c FROM `accounts` WHERE `biobew2` < 1";
}
elseif($_GET['op']=="checked"){
        $sql = "SELECT count(`acctid`) AS c FROM accounts WHERE `biobew2` > 0";
}
$result = db_query($sql);
$row = db_fetch_assoc($result);
$totalplayers = $row['c'];
$page = 1;
if ($_GET['page']) $page = (int)$_GET['page'];
$pageoffset = $page;
if ($pageoffset > 0) $pageoffset--;
$pageoffset *= $playersperpage;
$from = $pageoffset+1;
$to = min($pageoffset+$playersperpage, $totalplayers);
$limit = "$pageoffset,$playersperpage";


bnav("Unbewertete Bios","notchecked","Auswahl");
bnav("Bewertete Bios","checked");
bnav("Spieler suchen","search");
addnav("Zur�ck");
addnav("Zur�ck zur Grotte","superuser.php");
addnav("Zur�ck zum Weltlichen","village.php");
if(@file_exists("superlist2.php")) addnav("Zur Kriegerliste","superlist2.php");

if(!isset($_GET['op'])){
        $out .= "`b`&`iUnbewertete Bios`i ~ Spieler, deren Bios noch nicht bewertet wurden. Du kannst hier die Bio eines Spieler ansehen, editieren, sperren oder bewerten. `n `n
                 `iBewertete Bios`i ~ Spieler deren Bios bereits einmal bewertet wurden. Du kannst hier die Bio eines Speilers ansehen, editieren, sperren oder neu bewerten. `n`n
                 `iSpieler suchen`i ~ Suche einen bestimmten Spieler.";
}

switch($_GET['op']){
    case 'checked':
        $out .= "`c`bBiobewertungen - Bewertete Bios`b`c`n`n";
        
        $sql = "SELECT `name`, `acctid`, `login`, `bio`, `biotime`, `biobew2`, `biobewertdatum`".(TIERBIOINSTALLED?", `".TIERBIO."`":"")." FROM `accounts` WHERE `biobew2` > 0 ORDER BY ".$order." ".$dir." LIMIT $limit";
        $result = db_query($sql);
        
        $link = "biobewertung.php?op=checked&change=1&dir=".$dir."&ordbef=".$ordbef."&order=";
        $addition1 = "<td align='center'>".($_GET['op']=="search"?"erhaltene Punkte":"<a href='".$link."biobew2&page=".$page."'>erhaltene Punkte</a>")."</td>
                      <td align='center'>".($_GET['op']=="search"?"bewertet am":"<a href='".$link."biobewertdatum&page=".$page."'>bewertet am</a>")."</td>";
        addnav("",$link."biobew2&page=".$page);
        addnav("",$link."biobewertdatum&page=".$page);
        
        addnav("Seiten");
        for($i = 0; $i < $totalplayers; $i+= $playersperpage){
            $pnum = ($i/$playersperpage+1);
            $min = ($i+1);
            $max = min($i+$playersperpage,$totalplayers);
            addnav("Seite $pnum ($min-$max)", "biobewertung.php?op=checked&dir={$dir}&ordbef={$ordbef}&order={$order}&page={$pnum}");
        }
        $table = TRUE;
    break;
    case 'notchecked':
        $out .= "`c`bBiobewertungen - Unbewertete Bios`b`c`n`n";
        
        $sql = "SELECT `name`, `acctid`, `login`, `bio`, `biotime`".(TIERBIOINSTALLED?", `".TIERBIO."`":"")." FROM `accounts` WHERE `biobew2` = 0 ORDER BY ".$order." ".$dir." LIMIT $limit";
        $result = db_query($sql);
        
        $link = "biobewertung.php?op=notchecked&change=1&dir=".$dir."&ordbef=".$ordbef."&order=";
        addnav("",$link."regday&page=".$page);
        
        addnav("Seiten");
        for($i = 0; $i < $totalplayers; $i+= $playersperpage){
            $pnum = ($i/$playersperpage+1);
            $min = ($i+1);
            $max = min($i+$playersperpage,$totalplayers);
            addnav("Seite $pnum ($min-$max)", "biobewertung.php?op=notchecked&dir={$dir}&ordbef={$ordbef}&order={$order}&page={$pnum}");
        }
        $table = TRUE;
    break;
    case 'search':
        switch($_GET['act']){
            case '':
                $out .= "<form action='biobewertung.php?op=search&act=searched' method='POST'>
                 <input name='name'><input type='submit' class='button' value='suchen'>";
                addnav("","biobewertung.php?op=search&act=searched");
                $table = FALSE;
            break;
            case 'searched':
                $search="%";
                for ($x=0;$x<strlen($_POST['name']);$x++){
                    $search .= substr($_POST['name'],$x,1)."%";
                }
                //$out .= $search;
                $sql = "SELECT `name`, `acctid`, `biobew2`, `biotime`, `bio`".(TIERBIOINSTALLED?", `".TIERBIO."`":"")." FROM `accounts` WHERE `name` LIKE '".addslashes($search)."' ORDER BY `acctid` ASC";
                //$out .= $sql;
                $result = db_query($sql);
                
                $addition1 = "<td align='center'> Bewertet? </td>";
                
                $table = TRUE;
            break;
        }
    break;
    case 'showbio':
        $what = $_GET['what'];
        switch($what):
            case 'bioonly':
                $b = TRUE;
            break;
            case 'tieronly':
                $t = TRUE;
            break;
            case 'both':
                $o = TRUE;
            break;
        endswitch;
        $userid = $_GET['userid'];
        
        $sql = "SELECT `acctid`, `name`, `login`, `biobew2`, `avatar`, `bio`".(TIERBIOINSTALLED?", `".TIERBIO."`":"").", `biotime`, `donation`, `donationspent`, `sex` FROM `accounts` WHERE `acctid` = ".$userid;
        $result = db_query($sql);
        $row = db_fetch_assoc($result);
        
        $donation = $row['donation']-$row['donationspent'];
        $avasize = getimagesize($row['avatar']);
        $avawidth = $avasize[0];
        $avaheight = $avasize[1];
        if($avawidth>MAX_AVATAR_WIDTH) $width = "width='".MAX_AVATAR_WIDTH."'";
        if($avaheight>MAX_AVATAR_HEIGHT) $height = "height='".MAX_AVATAR_HEIGHT."'";
        $avatar = $row['avatar']?"<img src='".$row['avatar']."' alt='".$row['login']."s Avatar' ".$width." ".$height.">":"`c`i`0Kein Avatar`i`c";
        $bio = $row['bio']?stripslashes($row['bio']):"`iKeine Bio`i";
        if(TIERBIOINSTALLED) $tierbio = $row[TIERBIO]?$row[TIERBIO]:"`c`iKeine Tierbio`i`c";
        $pic = "<img src='./images/".($row['sex']?"fe":"")."male.gif' alt='".($row['sex']?"weiblich":"m�nnlich")."'";
        $biolock = ">>> ".($row['biotime']=="9999-12-31 23:59:59"?"<a href='biobewertung.php?op=biounlock&userid=".$userid."&what=".$what."'>Bio entsperren</a>":"<a href='biobewertung.php?op=biolock&userid=".$userid."&what=".$what."'>Bio sperren</a>")." <<<";
        
        
        $out .= "<table border='0' cellspacing='1' cellpadding='3' bgcolor='#999999'>
                   <tr class='trhead'> 
                     <td align='center' colspan='4'> `&Infos zu <a href=\"mail.php?op=write&to=".rawurlencode($row['login'])."\" target=\"_blank\" onClick=\"".popup("mail.php?op=write&to=".rawurlencode($row['login'])."").";return false;\"><img src='images/newscroll.GIF' width='16' height='16' alt='Mail schreiben' border='0'></a> `b`&".$row['login']."`b`0 </td>
                   </tr>
                   <tr class='trdark'>
                     <td align='center' colspan='4'>
                       <form action='biobewertung.php?op=points&userid=".$userid."&what=".$what."' method='POST'>
                       `&>>>> `b".($row['biobew2']?"Neu bewerten":"Bewerten")."`b <input name='amt'>
                       <input type='submit' class='button' value='Best�tigen'> <<<<
                     </td>
                   </tr>
                   <tr class='trlight'>
                     <td> `b`&Titel + Name:`b </td><td> ".$row['name']." </td>
                     <td> `b`&Donationpunkte:`b </td><td> ".$donation."/".$row['donation']." </td>
                   </tr>
                   <tr class='trlight'>
                     <td> `b`&Bewertet?`b </td><td> ".($row['biobew2']?"`@Ja `0(".$row['biobew2']." Punkte)":"`\$Nein")." </td>
                     <td> `b`&Geschlecht`b: </td><td> ".($row['sex']?"weiblich":"m�nnlich")." ".$pic." </td>
                   </tr>
                   <tr class='trlight'>
                     <td ".(TIERBIOINSTALLED?"":"colspan='2'")."> `b`&Wortanzahl der Bio:`b </td><td ".(TIERBIOINSTALLED?"":"colspan='2'")."> ".str_word_count(stripcolors($row['bio']))." </td>
                     ".(TIERBIOINSTALLED?"<td> `b`&Wortanzahl der Tierbio:`b </td><td> ".str_word_count(stripcolors($row[TIERBIO]))." </td>":"")."
                   </tr>
                   <tr class='trlight'>
                     <td> `b`&Avatar:`b ".($row['avatar']!=""?"`n`n`n >>><a href='biobewertung.php?op=blockava&userid=".$userid."&what=".$what."'>Avatar entfernen</a><<<":"")." </td><td colspan='3' align='center'> ".$avatar." </td>
                   </tr>";
          if($b || $o){
          $out .=" <tr class='trhead'>
                     <td align='center' colspan='4'> `&Bio von <a href=\"mail.php?op=write&to=".rawurlencode($row['login'])."\" target=\"_blank\" onClick=\"".popup("mail.php?op=write&to=".rawurlencode($row['login'])."").";return false;\"><img src='images/newscroll.GIF' width='16' height='16' alt='Mail schreiben' border='0'></a> `b`&".$row['login']."`b`0 </td>
                   </tr>
                   <tr class='trlight'>
                     <td colspan='2' align='center'> `&>>><a href='biobewertung.php?op=editbio&userid=".$userid."&what=".$what."&what2=bio'> Bio editieren </a><<< </td>
                     <td colspan='2' align='center'> `&".$biolock." </td>
                   </tr>
                   <tr class='trdark'>
                     <td colspan='4'> ".$bio." </td>
                   </tr>";
          }
          if($t || $o){
          $out .= (TIERBIOINSTALLED?"<tr class='trhead'>
                     <td align='center' colspan='4'> `&Tierbio von <a href=\"mail.php?op=write&to=".rawurlencode($row['login'])."\" target=\"_blank\" onClick=\"".popup("mail.php?op=write&to=".rawurlencode($row['login'])."").";return false;\"><img src='images/newscroll.GIF' width='16' height='16' alt='Mail schreiben' border='0'></a> `b`&".$row['login']."`b`0 </td>
                   </tr>
                   <tr class='trlight'>
                     <td colspan='4' align='center'> `&>>><a href='biobewertung.php?op=editbio&userid=".$userid."&what=".$what."&what2=".TIERBIO."'> Tierbio editieren </a><<< </td>
                   </tr>
                   <tr class='trdark'>
                     <td colspan='4'> ".$tierbio." </td>
                   </td>":"");
          }
        addnav("","biobewertung.php?op=points&userid=".$userid."&what=".$what);
        addnav("","biobewertung.php?op=editbio&userid=".$userid."&what=".$what."&what2=bio");
        addnav("","biobewertung.php?op=editbio&userid=".$userid."&what=".$what."&what2=".TIERBIO);
        addnav("","biobewertung.php?op=blockava&userid=".$userid."&what=".$what);
        addnav("","biobewertung.php?op=biounlock&userid=".$userid."&what=".$what);
        addnav("","biobewertung.php?op=biolock&userid=".$userid."&what=".$what);
        
        $nav = FALSE;
        addnav("Aktionen");
        addnav("Bio von ".$row['login']." (bio.php)","bio.php?char=".rawurlencode($row['login'])."&ret=".urlencode($_SERVER['REQUEST_URI']));
        addnav("User editieren","user.php?op=edit&userid=".$userid);
        bnav("Unbewertete Bios","notchecked","Auswahl");
        bnav("Bewertete Bios","checked");
        bnav("Spieler suchen","search");
        addnav("Zur�ck");
        addnav("Zur�ck zur Grotte","superuser.php");
        addnav("Zur�ck zum Weltlichen","village.php");
        if(@file_exists("superlist2.php")) addnav("Zur�ck zur Kriegerliste","superlist2.php");
    break;
    case 'points':
        $amt = $_POST['amt'];
        $userid = $_GET['userid'];
        $what = $_GET['what'];
        
        $sql = "SELECT `name`, `login`, `donation`, `donationspent`, `sex`, `biobew2` FROM `accounts` WHERE `acctid` = ".$userid;
        $result = db_query($sql);
        $row = db_fetch_assoc($result);
        
        $donation = $row['donation'] - $row['donationspent'];
        $new1 = $donation + $amt;
        $new2 = $row['donation'] + $amt;
        
        if(!is_numeric($amt)){
                $out .= "`b`&Du kannst Donationpunkte nur in Form einer `iZahl`i verteilen.`nBitte korrigiere deine Eingabe!`b";
                $nav = FALSE;
                bnav($row['login']."s Bio","showbio&userid=".$userid."&what=".$what,"Nochmal probieren");
        }
        elseif($amt > MAXPOINTS){
                $out .= "`b`&Mehr als `i`^".MAXPOINTS."`i `&Punkte f�r eine Biographie zu vergeben ist doch �bertrieben...`nBitte korrigiere deine Eingabe!`b";
                $nav = FALSE;
                bnav($row['login']."s Bio","showbio&userid=".$userid."&what=".$what,"Nochmal probieren");
        }
        elseif(($amt+$row['biobew2']) > MAXPOINTS){
                $out .= "`b`&`i".$row['name']."`i `&hat f�r ".($row['sex']?"ihre":"seine")." Bio schon genug Punkte bekommen!`nBitte korrigiere deine Eingabe!`b";
                $nav = FALSE;
                bnav($row['login']."s Bio","showbio&userid=".$userid."&what=".$what,"Nochmal probieren");
        }
        elseif($amt<0 && (($row['biobew2']+$amt) < 0)){
                //$out .= $row['biobew2']+$amt;
                $out .= "`b`&Es w�re unfair einen Spieler mit einer Bio zu bestrafen, anstatt zu belohnen!`nBitte korrigiere deine Eingabe!`b";
                $nav = FALSE;
                bnav($row['login']."s Bio","showbio&userid=".$userid."&what=".$what,"Nochmal probieren");
        }
        elseif($amt == 0){
                $out .= "`b`&Es w�re mehr als sinnlos `i0`i Punkte zu verteilen.`nBitte korrigiere deine Eingabe!";
                $nav = FALSE;
                bnav($row['login']."s Bio","showbio&userid=".$userid."&what=".$what,"Nochmal probieren");
        }
        elseif($row['biobew2']>0 && $amt>0){
                $out .= "`b`&Willst du wirklich `i".$row['name']."s`i `&Bio mit `^`i".$amt."`i`& zus�tzlichen Punkten neu bewerten?`n".($row['sex']?"Sie":"Er")." h�tte dann `^`i".$new1."/".$new2."`i `&Donationpunkte und insgesamt `^`i".($row['biobew2']+$amt)."`i`& Punkte durch die Bewertung ".($row['sex']?"ihrer":"seiner")." Bio erhalten.
                        `c<table border='0' cellpadding='5'>
                          <tr>
                            <td><form action='biobewertung.php?op=points2&userid=".$userid."&amt=".$amt."&how=oldp' method='POST'>
                                <input type='submit' class='button' value='Ja'>
                                </form>
                            </td><td>
                                <form action='biobewertung.php?op=showbio&userid=".$userid."&what=".$what."' method='POST'>
                                <input type='submit' class='button' value='Nein'>
                                </form>
                            </td>
                          </tr>
                        </table>`c";
                addnav("","biobewertung.php?op=showbio&userid=".$userid."&what=".$what);
                addnav("","biobewertung.php?op=points2&userid=".$userid."&amt=".$amt."&how=oldp");
                $nav = FALSE;
        }
        elseif($row['biobew2']>0 && $amt<0){
                $number = $amt*(-1);
                $out .= "`b`&Willst du `i".$row['name']." `^".$number."`i `&Punkte f�r ".($row['sex']?"ihre":"seine")." Bio abziehen?`n".($row['sex']?"Sie":"Er")." h�tte somit `^`i".$new1."/".$new2." `i`&Donationpunkte und insgesamt `i`^".($row['biobew2']+$amt)."`i `&Punkte erhalten.
                        `c<table border='0' cellpadding='5'>
                          <tr>
                            <td><form action='biobewertung.php?op=points2&userid=".$userid."&amt=".$amt."&how=oldv' method='POST'>
                                <input type='submit' class='button' value='Ja'>
                                </form>
                            </td><td>
                                <form action='biobewertung.php?op=showbio&userid=".$userid."&what=".$what."' method='POST'>
                                <input type='submit' class='button' value='Nein'>
                                </form>
                            </td>
                          </tr>
                        </table>`c";
                addnav("","biobewertung.php?op=showbio&userid=".$userid."&what=".$what);
                addnav("","biobewertung.php?op=points2&userid=".$userid."&amt=".$amt."&how=oldv");
                $nav = FALSE;
        }else{
                $out .= "`b`&Willst du wirklich `i".$row['name']."`^ ".$amt."`i `&Punkte f�r ".($row['sex']?"ihre":"seine")." Bio geben?`n`nDamit w�rden ".($row['sex']?"ihre":"seine")." Donationpunkte von `^`i".$donation."/".$row['donation']."`i `&auf `^`i".$new1."/".$new2."`i `&steigen.
                        `c<table border='0' cellpadding='5'>
                          <tr>
                            <td><form action='biobewertung.php?op=points2&userid=".$userid."&amt=".$amt."&how=new' method='POST'>
                                <input type='submit' class='button' value='Ja'>
                                </form>
                            </td><td>
                                <form action='biobewertung.php?op=showbio&userid=".$userid."&what=".$what."' method='POST'>
                                <input type='submit' class='button' value='Nein'>
                                </form>
                            </td>
                          </tr>
                        </table>`c";
                addnav("","biobewertung.php?op=showbio&userid=".$userid."&what=".$what);
                addnav("","biobewertung.php?op=points2&userid=".$userid."&amt=".$amt."&how=new");
                $nav = FALSE;
        }
    break;     
    case 'points2':
        $how = $_GET['how'];
        switch($how):
            case 'oldp':
                $p = TRUE;
            break;
            case 'oldv':
                $v = TRUE;
            break;
            case 'new':
                $n = TRUE;
            break;
        endswitch;
        
        $userid = $_GET['userid'];
        $amt = $_GET['amt'];
        
        $number = $amt*(-1);
        $out .= "`b`&Transaktion abgeschlossen.`nBio bewertet.`nSystemmail geschickt.";
        
        if($p && SYSTEMMAIL) systemmail($userid,"`^Erneute Biobewertung!","`qDeine Biographie wurde noch einmal bewertet, nachdem du sie noch einmal verbessert hast! Du hast `^".$amt." `qPunkte hinzubekommen.`n`nMit freundlichen Gr��en,`ndas ".SERVERNAME." `qTeam.");
        if($v && SYSTEMMAIL) systemmail($userid,"`^Erneute Biobewertung!","`qDeine Biographie wurde noch einmal bewertet! Allerdings gefiel sie uns nicht mehr so gut, weshalb dir `^".$number." `qPunkte abgezogen wurden.`n`nMit freundlichen Gr��en,`ndas ".SERVERNAME." `qTeam.");
        if($n && SYSTEMMAIL) systemmail($userid,"`^Biobewertung!","`qDeine Biographie wurde bewertet. F�r die M�he, die du dir gegeben hast, bekommst du `^".$amt." `qPunkte.`n`nMit freundlichen Gr��en,`ndas ".SERVERNAME." `qTeam");
        
        $sql = "UPDATE `accounts` SET `biobew2` = `biobew2`+".$amt.", `biobewertdatum` = NOW(), `donation` = `donation`+".$amt." WHERE `acctid` = ".$userid;
        db_query($sql);
        if($userid == $session['user']['acctid']){
                $session['user']['biobew2'] += $amt;
                $session['user']['donation'] += $amt;
                $session['user']['bewertdatum'] = date('Y-m-d H:i:s');
        }
    break; 
    case 'blockava':
        $userid = $_GET['userid'];
        $what = $_GET['what'];
        $sql = "SELECT `login` FROM `accounts` WHERE `acctid` = ".$userid;
        $result = db_query($sql);
        $row = db_fetch_assoc($result);
        
        $sql = "UPDATE `accounts` SET `avatar` = '' WHERE `acctid` = ".$userid;
        db_query($sql);
        systemmail($userid,"Dein Avatar wurde entfernt","Der Administrator hat beschlossen, dass dein Avatar unangebracht ist, oder nicht funktionierte, und hat ihn entfernt.`n`nWenn du dar�ber diskutieren willst, benutze bitte den Link zur Hilfeanfrage.");
        
        $out .= "`b`&Avatar entfernt!`b";
        
        $nav = FALSE;
        bnav($row['login']."s Bio","showbio&userid=".$userid."&what=".$what,"Zur�ck");
    break;
    case 'editbio':
        $userid = $_GET['userid'];
        $what = $_GET['what'];
        $what2 = $_GET['what2'];
        $sql = "SELECT `".$what2."`, `name`, `login` FROM `accounts` WHERE `acctid` = ".$userid;
        $result = db_query($sql);
        $row = db_fetch_assoc($result);
        
        $out .= "`b`&".($what2=="bio"?"Bio":"Tierbio")." von `i".$row['name']."`i `&editieren:`n`n`n";
        $rawout .= "<form action='biobewertung.php?op=editbio2&what=".$what."&what2=".$what2."&userid=".$userid."' method='POST'>
                    <textarea class='input' name='bio' cols='50' rows='10'>".stripslashes($row[$what2])."</textarea>
                    <input type='submit' class='button' value='Editieren'>";
        //$out .= $what2;
        //$out .= $sql;
        
        $nav = FALSE;
        addnav("","biobewertung.php?op=editbio2&what=".$what."&what2=".$what2."&userid=".$userid);
        bnav($row['login']."s Bio","showbio&userid=".$userid."&what=".$what,"Zur�ck");
    break;
    case 'editbio2':
        $what = $_GET['what'];
        $what2 = $_GET['what2'];
        $userid = $_GET['userid'];
        $bio = stripslashes($_POST['bio']);
        
        $sql = "UPDATE `accounts` SET `".$what2."` = '".$bio."' WHERE `acctid` = ".$userid;
        db_query($sql);
        
        $sql = "SELECT `login` FROM `accounts` WHERE `acctid` = ".$userid;
        $result = db_query($sql);
        $row = db_fetch_assoc($result);
        
        $out .= "`b`&Bio ge�ndert!";
        
        $nav = FALSE;
        bnav($row['login']."s Bio","showbio&userid=".$userid."&what=".$what,"Zur�ck");
    break;
    case 'biounlock':
        $userid = $_GET['userid'];
        $what = $_GET['what'];
        $sql = "UPDATE `accounts` SET `biotime` = '0000-00-00 00:00:00', `biobew2` = 0 WHERE `acctid` = ".$userid;
        db_query($sql);
        $out .= "`b`&Bio entsperrt!";
        
        $sql = "SELECT `login` FROM `accounts` WHERE `acctid` = ".$userid;
        $result = db_query($sql);
        $row = db_fetch_assoc($result);
        $nav = FALSE;
        bnav($row['login']."s Bio","showbio&userid=".$userid."&what=".$what,"Zur�ck");
    break;
    case 'biolock':
        $userid = $_GET['userid'];
        $what = $_GET['what'];
        $sql = "SELECT `login`, `donation`, `biobew2` FROM `accounts` WHERE `acctid` = ".$userid;
        $result = db_query($sql);
        $row = db_fetch_assoc($result);
        
        $donation = $row['donation'] - $row['biobew2'];
        $sql = "UPDATE `accounts` SET `bio` = '`iGesperrt aufgrund unangebrachten Inhalts`i'".(TIERBIOINSTALLED?", `".TIERBIO."` = '`iGesperrt aufgrund unangebrachten Inhalts`i'":"").", `biotime` = '9999-12-31 23:59:59', `biobew2` = 0, `donation` = ".$donation." WHERE `acctid` = ".$_GET['userid'];
        db_query($sql);
        systemmail($userid,"Deine Biographie wurde gesperrt","Der Administrator hat beschlossen, dass deine Kurzbeschreibung unangebracht ist und hat sie gesperrt.`n`nWenn du dar�ber diskutieren willst, benutze bitte den Link zur Hilfeanfrage.");
        
        $out .= "`b`&Bio gesperrt!";
        
        
        $nav = FALSE;
        bnav($row['login']."s Bio","showbio&userid=".$userid."&what=".$what,"Zur�ck");
    break;
}

if($table){
        $tierbio1 = TIERBIOINSTALLED?"`&/ Tierbio":"";
        $tierbio2 = TIERBIOINSTALLED?"`&/`0 <a href='".$link."tierbio&islen=1&page=".$page."'>Tierbio</a>":"";
        
        $out .= "<table border='0' cellpadding='2' cellspacing='1' bgcolor='#999999'>
                   <tr class='trhead'>
                     <td align='center'>".($_GET['op']=="search"?"ID":"<a href='".$link."acctid&page=".$page."'>ID</a>")."</td>
                     <td>".($_GET['op']=="search"?"Name":"<a href='".$link."login&page=".$page."'>Name</a>")."</td>
                     <td align='center'>".($_GET['op']=="search"?"Wortanzahl`nBio":"Wortanzahl`n<a href='".$link."bio&islen=1&page=".$page."'>Bio</a>")." ".($_GET['op']=="search"?$tierbio1:$tierbio2)." </td>
                     <td align='center'>".($_GET['op']=="search"?"zuletzt`ngeupdated":"<a href='".$link."biotime&page=".$page."'>zuletzt`ngeupdated</a>")."</td>
                     ".$addition1."
                     <td align='center'>Ansehen / Bewerten</td>";  
        
        addnav("",$link."acctid&page=".$page);
        addnav("",$link."login&page=".$page);
        addnav("",$link."bio&islen=1&page=".$page);
        addnav("",$link."tierbio&islen=1&page=".$page);
        addnav("",$link."biotime&page=".$page);
        
        for($i=1;$i<db_num_rows($result);$i++){
            $row = db_fetch_assoc($result);
            
            $bio = str_word_count(stripcolors($row['bio']));
            if(TIERBIOINSTALLED) $tierbio = str_word_count(stripcolors($row[TIERBIO]));
            
            if($_GET['op']=="checked") $addition2 = "<td align='center'> ".$row['biobew2']." </td>
                                                         <td align='center'> ".getthisdate($row['biobewertdatum'])." </td>";
            elseif($_GET['op']=="search") $addition2 = "<td align='center'> ".($row['biobew2']?"`@Ja`0":"`\$Nein`0")." </td>";

            $out .= "<tr class='".($i%2?"trdark":"trlight")."'>
                       <td align='center'> ".$row['acctid']." </td>
                       <td> ".$row['name']." </td>
                       <td align='center'> ".$bio." ".(TIERBIOINSTALLED?"/ ".$tierbio."":"")." </td>
                       <td align='center'> ".getthisdate($row['biotime'])." </td>
                       ".$addition2."
                       <td align='center'> <a href='biobewertung.php?op=showbio&userid=".$row['acctid']."&what=bioonly'>Bio</a>".(TIERBIOINSTALLED?"<br /><a href='biobewertung.php?op=showbio&userid=".$row['acctid']."&what=tieronly'>Tierbio</a><br /><a href='biobewertung.php?op=showbio&userid=".$row['acctid']."&what=both'>Beide</a>":"")."</td>";   

            addnav("","biobewertung.php?op=showbio&userid=".$row['acctid']."&what=bioonly");
            addnav("","biobewertung.php?op=showbio&userid=".$row['acctid']."&what=tieronly");
            addnav("","biobewertung.php?op=showbio&userid=".$row['acctid']."&what=both");
        }
}
output($out,true);
rawoutput($rawout);
page_footer();
?>