<?

if(!isset($session)) exit();

$sn = 'forest.php?op=';

switch($_GET['op']){
        case 'leave':
                switch(e_rand(1,2)){
                        case 1:
                                output('`n`n`@So schnell du kannst machst du dich aus dem Staub! Du bist ja schlie�lich kein M�rder, oder? Dummerweise arbeitet der Kerl *wirklich* bei der Stadt und nun ist er zu h�chst ver�rgert. So ver�rgert, dass er dich f�r Vogelfrei erkl�rt.`n`n
                                        `^Du bist f�r ALLE Spieler in den Feldern nun sichtbar. Auch in der Taverne bist du nicht mehr so sicher, wie zuvor.');
                                
                                $session['user']['free'] = 1;
                                $session['user']['specialinc'] = '';
                        break;
                        case 2:
                                output('`n`n`@Dir gelingt die Flucht. Ehe der Kerl dich �berhaupt richtig erkannt hat, bist du �ber alle Berge...');
                                
                                $session['user']['specialinc'] = '';
                        break;
                }
        break;
        
        case 'accept':
                $session['user']['gold']+=1000;
                
                switch(e_rand(1,4)){
                        case 1:
                                output('`n`n`@Davon �berzeugt der Stadt zu helfen ziehst du los, doch irgendwie hast du selbst nach einigen Stunden den Kerl noch nicht gefunden. Na ja, wenigstens hast du keinen Schaden erlitten, au�er, dass du nun nicht mehr ganz so fit bist.`n`n
                                        `^Du verlierst `%2 `^Waldk�mpfe.');
                                
                                $session['user']['turns']-=2;
                                $session['user']['specialinc'] = '';
                        break;
                        case 2:
                                output('`n`n`@Davon �berzeugt der Stadt zu helfen ziehst du los, doch irgendwie hast du selbst nach einigen Stunden den Kerl noch nicht gefunden. Irgendwann gibst du die Suche auf und alsbald hast du den Vorfall auch schon wieder vergessen. Leider hat ihn der Mann von der Stadt nicht vergessen und zudem ist er �u�erst w�tend dar�ber, dass du deine Aufgabe nicht erledigt hast, schlie�lich hat er dich bezahlt. Als Rache erkl�rt er dich f�r Vogelfrei!`n`n
                                         `^Du bist f�r ALLE Spieler in den Feldern nun sichtbar. Auch in der Taverne bist du nicht mehr so sicher, wie zuvor.');
                                
                                $session['user']['free']=1;
                                $session['user']['specialinc'] = '';
                        break;
                        case 3:
                        case 4:
                                output('`n`n`@Davon �berzeugt der Stadt zu helfen ziehst du los, nach einiger Zeit findest du den Knilch auch endlich! Mit einem w�tenden Kampfschrei st�rzst du dich auf ihn!');
                                $badguy = array(
                                                'creaturename'=>'`2Di`geb`8ischer `gGn`2om`0',
                                                'creaturelevel'=>$session['user']['level'],
                                                'creatureweapon'=>'`Tverrosteter `7Dolch`0',
                                                'creatureattack'=>$session['user']['attack']+2,
                                                'creaturedefense'=>$session['user']['defence']+2,
                                                'creaturehealth'=>round($session['user']['maxhitpoints']*1.25,0),
                                                'diddamage'=>0);
                                $session['user']['badguy'] = createstring($badguy);
                                $battle = true;
                                
                                $session['user']['specialinc'] = 'free.php';
                        break;
                }
        break;
        case 'run':
                output('`n`n`b`^Du wurdest f�r diesen Kampf bezahlt! Du kannst nicht wegrennen!`b`0');
                
                $battle = true;
        break;
        case 'fight':
                $battle = true;
        break;
        default:
                if($session['user']['free'] == 0){
                        output('`n`n`@Du schlenderst durch den Wald, als pl�tzlich vor dir ein Mann auftaucht. Geh�llt in einen Umhang nickt er dir knapp zu. Und noch bevor du deinen Gru� an ihn richten konntest, f�ngt er auch schon an zu sprechen: `n`n
                                `i`&"Siehst kr�ftig aus '.($session['user']['sex']?'M�del':'Bursche').', vielleicht k�nntest du ja ne Aufgabe f�r mich erledigen? `n
                                Ich arbeite f�r die Stadt und suche gerade jemanden, der einen Gnom erledigt, der schon seit Ewigkeiten sein Unwesen in der Stadt treibt. Gerade ist er wieder in ein Haus eingebrochen. Wenn du dich auf die Suche machst und ihn erledigst, bekommst du von mir 1000 Goldm�nzen. Na, ist das nicht ein Angebot?"`i `n`n
                                `@1000 Goldm�nzen? Warum auch nicht, denkst du dir. Andererseits wei�t du ja nicht, ob du dem Mann trauen kannst. Vielleicht will er sich auch nur ein Kopfgeld sparen. `n`n
                                Was willst du tun?');
                
                        $session['user']['specialinc'] = 'free.php';
                        
                        addnav('Aktionen');
                        addnav('Gnom suchen',$sn.'accept');
                        addnav('Zur�ck in den Wald',$sn.'leave');
                }
                else{
                        output('`n`n`@Du schlenderst durch den Wald, als pl�tzlich vor dir ein Mann auftaucht. Geh�llt in einen Umhang nickt er dir knapp zu. Anscheinend hat er dich nicht erkannt, aber daf�r hast du IHN erkannt. Es ist der Kerl, der dich bereits einmal f�r vogelfrei erkl�rt hat! Dank ihm hast du ein Haufen Probleme am Hals. So schnell du kannst machst du dich aus dem Staub...');
                        
                        $session['user']['specialinc'] = '';
                        
                        addnav('Aktionen');
                        addnav('Zur�ck in den Wald',$sn);
                }

        break;
}


if($battle){
        include('battle.php');
        if($victory){
                $badguy = array();
                $session['user']['badguy'] = '';
                
                $gems = e_rand(2,3);
                $gold = e_rand(($session['user']['level']*200),($session['user']['level']*300));
                
                switch(e_rand(1,2)){ 
                        case 1:  
                                output('`n`n`@Du machst kurzen Prozess mit dem kleinen Wicht. Auftrag erf�llt und es war noch einfacher, als du gedacht h�ttest. Zufrieden kehrst du in den Wald zur�ck, aber zuvor kn�pfst du dem Gnom noch seine sieben Sachen ab. `n`n
                                        `^Du bekommst `%'.$gems.' `^Edelsteine und `%'.$gold.' `^Gold.');
                        break;
                        case 2: 
                                output('`n`n`@Du machst kurzen Prozess mit dem kleinen Wicht. Auftrag erf�llt und es war noch einfacher, als du gedacht h�ttest. Zufrieden kehrst du in den Wald zur�ck, aber zuvor kn�pfst du dem Gnom noch seine sieben Sachen ab. `n`n
                                        `^Du bekommst `%'.$gems.' `^Edelsteine und `%'.$gold.' `^Gold. `n`n
                                        `@Als du jedoch sp�ter wieder in die Stadt zur�ckkehrst, stellst du fest, dass du wegen Mordes als vogelfrei eingestuft wurdest! `n`n
                                        `^Du bist f�r ALLE Spieler in den Feldern nun sichtbar. Auch in der Taverne bist du nicht mehr so sicher, wie zuvor.');
                        break;
                }
                
                $session['user']['specialinc'] = '';
        } 
        elseif($defeat){
                $badguy = array();
                $session['user']['badguy'] = '';
                
                output('`n`n`@Schlecht, der Gnom hat dich besiegt! `n`n
                        `^Du verlierst 10% deiner Erfahrung, `n
                        du verlierst all dein Gold!');
                
                $session['user']['alive'] = false;
                $session['user']['hitpoints'] = 0;
                $session['user']['gold'] = 0;
                $session['user']['experience'] *= 0.9;
                addnav('T�gliche News','news.php');
                $session['user']['specialinc'] = '';                
        }
        else{
                fightnav(true,true);
                $session['user']['specialinc'] = 'free.php';
        }
}
?>