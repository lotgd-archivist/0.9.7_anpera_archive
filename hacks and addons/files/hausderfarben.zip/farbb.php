<?
// Idee & Umsetzung
// Morpheus aka Apollon in 2006
// Mail to morpheus@magic.ms
// Farbtest aus der darkhorse.php �bernommen
// gewidmet meiner �ber alles geliebten Blume
require_once "common.php";

$mn=$session['user']['name'];
$cost=$session['user']['level'];

page_header("Das Haus der Farben");
if ($_GET[op]==""){
	output("`3Du betrittst ein Haus, das von au�en eher schlicht und grau wirkt, von innen aber recht gem�tlich und feundlich.");
	output("`3Hinter einem schlichten Schreibtisch sitzt eine Frau mit elfischen Gesichtsz�gen, die aber recht klein geraten ist f�r eine Elfe und gerade in ihre Papiere vertieft ist.");
	output("`3Als sie Dich erblickt, legt sie diese bei Seite, steht auf und kommt auf Dich zu:`n`n\"`7Ah, sch�n Dich zu sehen $mn`7, Du m�chtest also eine Farbberatung von mir in Anspruch nehmen.");
	output("`7Gegen einen kleinen Obulus von `^$cost Gold`7 sollte das kein Problem sein.`3\"");
	addnav("Ja bitte","farbb.php?op=ber");
	addnav("Lieber doch nicht","village.php");
}
if ($_GET[op]=="ber"){
        if ($session['user']['gold']<$cost){
		output("`3Sei mustert Dich von oben bis unten, sch�ttelt dann den Kopf und setzt sich wieder:\"`7Du solltest erst einmal gen�gend Gold verdienen, dann kann ich Dir gerne weiter helfen.`3\"");
	addnav("Weiter","village.php");
	}else{
		output("`3Du bezahlst den geforderten Preis und sie nimmt Dich mit in ein kleines Hinterzimmer, das rustikal eingerichtet ist, wei�t Dir einen Platz an einem Tisch zu, geht zu einem gro�en B�cherregal und kommmt mit einem gro�en, dicken Buch zur�ck.");
		$session['user']['gold']-$cost;
		addnav("Weiter","farbb.php?op=farben");
	}
}
if ($_GET[op]=="farben"){
		output("`3\"`7In diesem Buch befinden sich verschiedene Beispiele f�r Fabkombinationen, jeweils f�r lange und kurze Namen, alle dargestellt mit Hilfe eine langen und eines kurzen Namens.");
		output("`7Sieh Dir alles in Ruhe an und notiere Dir, wenn Dir etwas gef�llt, die entsprechenden Farbcodes auf einen Zettel, und nun viel Spa�.`3\"`n`n");
		output("`3Mit diesen Worten verl��t sie das Zimmer wieder und Du schl�gst das Inhaltsverzeichnis des Buches auf.`n`n");
		output("`\$Grunds�tzlich gilt, um Farben zu erzeugen, benutzt Du zuerst das ` Zeichen ",true); 
		output("`6(Shift und die Taste links neben Backspace)`\$, danach dann 1, 2, 3, 4, 5, 6, 7, 8, 9, !, @, #, $, %, ^, Q, T, t, g, v, V oder &, denn jedes dieser Zeichen entspricht einer Farbe. "); 
		output("Wie die Farben im einzelnen aussehen, siehst Du hier:`n`n");
		output("`n`11 `22 `33 `44 `55 `66 `77 `88 `99 "); 
		output("`n`!! `@@ `## `\$\$ `%% `^^ `qq `QQ `&& `n"); 
		output("`TT `tt `RR `rr `VV `vv `gg`n`n"); 
		output("`\$Egal, was Du auch schreibst, Du kannst diese Farben immer verwenden, und nun zu den m�glichen Kombinationen.");
		output("<form action=\"$REQUEST_URI\" method='POST'>",true);
		output("Deine Eingabe: ".str_replace("`","&#0096;",HTMLEntities($_POST[testtext]))."`n",true);
		output("Sieht so aus: ".$_POST[testtext]." `n");
		output("<input name='testtext'><input type='submit' class='button' value='Test'></form>",true);
		output("`0`n`nDu kannst diese Farben in jedem Text verwenden, den du eingibst.");
		addnav("",$REQUEST_URI);
		addnav("Helle Farben","farbb.php?op=hell");
		addnav("Dunkle Farben","farbb.php?op=dunkel");
		addnav("Hell-Dunkel gemischt","farbb.php?op=hedu");
		addnav("Dunkel-Hell gemischt","farbb.php?op=duhe");
		addnav("Kunterbunt","farbb.php?op=kubu");
		addnav("Zur�ck","village.php");
}
if ($_GET[op]=="hell"){
	output("`3Beispiele f�r helle Farbkombinationen, demonstriert anhand der Namen `& Otto`3, `&Thomas`3 und `&Reinhold`3.`n`n");
	output("`\$O`6tt`\$o `3 entspricht \$O 6tt \$o.`n");
	output("`\$Th`6om`\$as `3 entspricht \$Th 6om \$as.`n");
	output("`\$Re`6in`\$ho`6ld `3 entspricht \$Re 6in \$ho 6ld.`n`n");
	output("`\$O`&tt`\$o `3 entspricht \$O &tt \$o.`n");
	output("`\$Th`&om`\$as `3 entspricht \$Th &om \$as.`n");
	output("`\$Re`&in`\$ho`&ld `3 entspricht \$Re &in \$ho &ld.`n`n");
	output("`3Vergi� nicht, vor die Zahlen/Buchstaben/Symbole erst noch das ` Zeichen zu setzen, damit eine Farbe erzeugt wird! ",true); 
	addnav("Zur�ck zum Inhaltsverzeichnis","farbb.php?op=inha");
}
if ($_GET[op]=="dunkel"){
	output("`3Beispiele f�r dunkle Farbkombinationen, demonstriert anhand der Namen `& Otto`3, `&Thomas`3 und `&Reinhold`3.`n`n");
	output("`5O`Ttt`5o `3 entspricht 5O Ttt 5o.`n");
	output("`5Th`Tom`5as `3 entspricht 5Th Tom 5as.`n");
	output("`5Re`Tin`5ho`Tld `3 entspricht 5Re Tin 5ho Tld.`n`n");
	output("`1O`Vtt`1o `3 entspricht 1O Vtt 1o.`n");
	output("`1Th`Vom`1as `3 entspricht 1Th Vom 1as.`n");
	output("`1Re`Vin`1ho`Vld `3 entspricht 1Re Vin 1ho Vld.`n`n");
	output("`3Vergi� nicht, vor die Zahlen/Buchstaben/Symbole erst noch das ` Zeichen zu setzen, damit eine Farbe erzeugt wird! ",true); 
	addnav("Zur�ck zum Inhaltsverzeichnis","farbb.php?op=inha");
}
if ($_GET[op]=="hedu"){
	output("`3Beispiele f�r hell-dunkel Farbkombinationen, demonstriert anhand der Namen `& Otto`3, `&Thomas`3 und `&Reinhold`3.`n`n");
	output("`#O`1tt`#o `3 entspricht #O 1tt #o.`n");
	output("`#Th`1om`#as `3 entspricht #Th 1om #as.`n");
	output("`#Re`1in`#ho`1ld `3 entspricht #Re 1in #ho 1ld.`n`n");
	output("`@O`Ttt`@o`3 entspricht @O Ttt @o.`n");
	output("`@Th`Tom`@as `3 entspricht @Th Tom @as.`n");
	output("`@Re`Tin`@ho`Tld `3 entspricht @Re Tin @ho Tld.`n`n");
	output("`3Vergi� nicht, vor die Zahlen/Buchstaben/Symbole erst noch das ` Zeichen zu setzen, damit eine Farbe erzeugt wird! ",true); 
	addnav("Zur�ck zum Inhaltsverzeichnis","farbb.php?op=inha");
}
if ($_GET[op]=="duhe"){
	output("`3Beispiele f�r dunkel-hell Farbkombinationen, demonstriert anhand der Namen `& Otto`3, `&Thomas`3 und `&Reinhold`3.`n`n");
	output("`!O`8tt`!o `3 entspricht !O 8tt !o.`n");
	output("`!Th`8om`!as `3 entspricht !Th 8om !as.`n");
	output("`!Re`8in`!ho`8ld `3 entspricht !Re 8in !ho 8ld.`n`n");
	output("`TO`ttt`To`3 entspricht TO ttt To.`n");
	output("`TTh`tom`Tas `3 entspricht TTh tom Tas.`n");
	output("`TRe`tin`Tho`tld `3 entspricht TRe tin Tho tld.`n`n");
	output("`3Vergi� nicht, vor die Zahlen/Buchstaben/Symbole erst noch das ` Zeichen zu setzen, damit eine Farbe erzeugt wird! ",true); 
	addnav("Zur�ck zum Inhaltsverzeichnis","farbb.php?op=inha");
}
if ($_GET[op]=="kubu"){
	output("`3Beispiele f�r kunterbunte Farbkombinationen, demonstriert anhand der Namen `& Otto`3, `&Thomas`3 und `&Reinhold`3.`n`n");
	output("`3O`@t`vt`2o `3 entspricht 3O @t vt 2o.`n");
	output("`2T`Th`@o`tm`3a`4s `3 entspricht 2T Th @o tm 3a 4s.`n");
	output("`6R`3e`^i`2n`gh`@o`ql`td `3 entspricht 6R 3e ^i 2n gh @o ql td.`n`n");
	output("`3Vergi� nicht, vor die Zahlen/Buchstaben/Symbole erst noch das ` Zeichen zu setzen, damit eine Farbe erzeugt wird! ",true); 
	addnav("Zur�ck zum Inhaltsverzeichnis","farbb.php?op=inha");
}
if ($_GET[op]=="inha"){
	output("`3Welche Seite willst Du Dir nun ansehen?");
		addnav("Helle Farben","farbb.php?op=hell");
		addnav("Dunkle Farben","farbb.php?op=dunkel");
		addnav("Hell-Dunkel gemischt","farbb.php?op=hedu");
		addnav("Dunkel-Hell gemischt","farbb.php?op=duhe");
		addnav("Kunterbunt","farbb.php?op=kubu");
		addnav("Namen Testen","farbb.php?op=farben");
		addnav("Danke, genug Farbe","village.php");
}
page_footer();
?>