<?php
/* coded by Ithil dae (alias Abraxas)
* Email: questbraxel@web.de
* April 2005
* www.zum-tanzenden-troll.de ; www.tanzender-troll.de
* v 0.01
* Wer einen Rhechtschraibfeler findet darf ihn behalten.
*
* Abeg�ndert und ges�ubert von Garlant
* Support auf Anfrage bei garlant@timeofmagic.de und bei Anpera.net
*/

require_once("common.php");
page_header("Aeris das Blumenm�dchen");
output("`c`b`&Aeris das Blumenm�dchen`0`b`c`n`n");

if ($_GET['op']==""){
addnav("Zur�ck","gardens.php");

output("`rSch�chtern steht sie da, ihr Kleid is dreckig, ihr Blick r�hrt von Trauer...`n
Aeris ist die H�terin dieser Wundersch�nen Blumen. Sie Hegt und pflegt dieser als w�ren es ihre kinder.`n
Du kommst zu der Stelle des Gartens, an der sie ihren Blumenladen hat. `8\"Kommt herein und seht euch um\"`r, sagt sie zu dir.");
if ($session['user']['gold'] > 10)  addnav("Einzelne Blumen");
if ($session['user']['gold'] > 10)  addnav("Ein G�nsebl�mchen - 10","blumenmaedchen.php?op=send&op2=gift2");
if ($session['user']['gold'] > 25)  addnav("Eine Wild Rose - 25 Gold","blumenmaedchen.php?op=send&op2=gift3");
if ($session['user']['gold'] > 50)  addnav("Eine Rote Rose - 50 Gold","blumenmaedchen.php?op=send&op2=gift4");
if ($session['user']['gold'] > 80)  addnav("Eine Wei�e Rose - 80 Gold","blumenmaedchen.php?op=send&op2=gift5");
if ($session['user']['gold'] > 80)  addnav("Eine Schwarze Rose - 80 Gold","blumenmaedchen.php?op=send&op2=gift6");
if ($session['user']['gold'] > 100) addnav("Blumenstr�use");
if ($session['user']['gold'] > 100) addnav("Straus G�nsebl�mchen - 100 Gold","blumenmaedchen.php?op=send&op2=gift7");
if ($session['user']['gold'] > 250) addnav("Straus Wild Rosen - 250 Gold","blumenmaedchen.php?op=send&op2=gift8");
if ($session['user']['gold'] > 700) addnav("Straus Rote Rosen - 700 Gold","blumenmaedchen.php?op=send&op2=gift9");
if ($session['user']['gold'] > 1000) addnav("Straus Wei�e Rosen - 1000 Gold","blumenmaedchen.php?op=send&op2=gift10");
if ($session['user']['gold'] > 1000) addnav("Straus Schwarze Rosen - 1000 Gold","blumenmaedchen.php?op=send&op2=gift11");

  if ($session['user']['gold'] > 10){
    output("`n<a href=\"blumenmaedchen.php?op=send&op2=gift2\">Ein G�nsebl�mchen - 10 Gold</a><br>",true);
    addnav("","blumenmaedchen.php?op=send&op2=gift2");
  }
    if ($session['user']['gold'] > 25){
    output("`n<a href=\"blumenmaedchen.php?op=send&op2=gift3\">Eine Wild Rose - 25 Gold</a><br>",true);
    addnav("","blumenmaedchen.php?op=send&op2=gift3");
  }
    if ($session['user']['gold'] > 50){
    output("`n<a href=\"blumenmaedchen.php?op=send&op2=gift4\">Eine Rote Rose - 50 Gold</a><br>",true);
    addnav("","blumenmaedchen.php?op=send&op2=gift4");
  }
    if ($session['user']['gold'] > 80){
    output("`n<a href=\"blumenmaedchen.php?op=send&op2=gift5\">Eine Wei�e Rose - 80 Gold</a><br>",true);
    addnav("","blumenmaedchen.php?op=send&op2=gift5");
  }
    if ($session['user']['gold'] > 80){
    output("`n<a href=\"blumenmaedchen.php?op=send&op2=gift6\">Eine Schwarze Rose - 80 Gold</a><br>",true);
    addnav("","blumenmaedchen.php?op=send&op2=gift6");
  }
    if ($session['user']['gold'] > 100){
    output("`n<a href=\"blumenmaedchen.php?op=send&op2=gift7\">Straus G�nsebl�mchen - 100 Gold</a><br>",true);
    addnav("","blumenmaedchen.php?op=send&op2=gift7");
  }
    if ($session['user']['gold'] > 250){
    output("`n<a href=\"blumenmaedchen.php?op=send&op2=gift8\">Straus Wild Rosen - 250 Gold</a><br>",true);
    addnav("","blumenmaedchen.php?op=send&op2=gift8");
  }
    if ($session['user']['gold'] > 700){
    output("`n<a href=\"blumenmaedchen.php?op=send&op2=gift9\">Straus Rote Rosen  - 700 Gold</a><br>",true);
    addnav("","blumenmaedchen.php?op=send&op2=gift9");
  }
    if ($session['user']['gold'] > 1000){
    output("`n<a href=\"blumenmaedchen.php?op=send&op2=gift10\">Straus Wei�e Rosen - 1000 Gold</a><br>",true);
    addnav("","blumenmaedchen.php?op=send&op2=gift10");
  }
    if ($session['user']['gold'] > 1000){
    output("`n<a href=\"blumenmaedchen.php?op=send&op2=gift11\">Straus Schwarze Rosen - 1000 Gold</a><br>",true);
    addnav("","blumenmaedchen.php?op=send&op2=gift11");
  }

output("</ul>",true);

}

if ($_GET['op']=="send"){
addnav("Zur�ck","gardens.php");
$gift=$_GET['op2'];
if (isset($_POST['search']) || $_GET['search']>""){
if ($_GET['search']>"") $_POST['search']=$_GET['search'];
$search="%";
for ($x=0;$x<strlen($_POST['search']);$x++){
$search .= substr($_POST['search'],$x,1)."%";
}
$search="name LIKE '".$search."' AND ";
if ($_POST['search']=="weiblich") $search="sex=1 AND ";
if ($_POST['search']=="m�nnlich") $search="sex=0 AND ";
}else{
$search="";
}
$ppp=25; // Player Per Page to display
if (!$_GET[limit]){
$page=0;
}else{
$page=(int)$_GET[limit];
addnav("Vorherige Seite","blumenmaedchen.php?op=send&op2=$gift&limit=".($page-1)."&search=$_POST[search]");
}
$limit="".($page*$ppp).",".($ppp+1);
$sql = "SELECT login,name,level,sex,acctid FROM accounts WHERE $search locked=0 AND acctid<>".$session[user][acctid]." AND lastip<>'".$session[user][lastip]."' AND charm>1 ORDER BY login,level LIMIT $limit";
$result = db_query($sql);
if (db_num_rows($result)>$ppp) addnav("N�chste Seite","blumenmaedchen.php?op=send&op2=$gift&limit=".($page+1)."&search=$_POST[search]");
output("`r`n�bergl�cklich strahlt dich Aeris an.`n \"F�r wen sind die Blumen denn bestimmt?\"`n`n");
output("<form action='blumenmaedchen.php?op=send&op2=$gift' method='POST'>Nach Name suchen: <input name='search' value='$_POST[search]'><input type='submit' class='button' value='Suchen'></form>",true);
addnav("","blumenmaedchen.php?op=send&op2=$gift");
output("<table cellpadding='3' cellspacing='0' border='0'><tr class='trhead'><td>Name</td><td>Level</td><td>Geschlecht</td></tr>",true);
for ($i=0;$i<db_num_rows($result);$i++){
$row = db_fetch_assoc($result);
output("<tr class='".($i%2?"trlight":"trdark")."'><td><a href='blumenmaedchen.php?op=send2&op2=$gift&name=".HTMLEntities($row['acctid'])."'>",true);
output($row['name']);
output("</a></td><td>",true);
output($row['level']);
output("</td><td align='center'><img src='images/".($row['sex']?"female":"male").".gif'></td></tr>",true);
addnav("","blumenmaedchen.php?op=send2&op2=$gift&name=".HTMLEntities($row['acctid']));
}
output("</table>",true);
}
if ($_GET['op']=="send2"){
$name=$_GET['name'];
$effekt="";
if ($_GET['op2']=="gift2"){
  $gift="G�nsebl�mchen";
  $session['user']['gold']-=10;
  $effekt="Ich lieeeebe `^G�nsebl�mchen";
}
if ($_GET['op2']=="gift3"){
  $gift="Wild Rose";
  $session['user']['gold']-=25;
  $effekt="Ich lieeeebe `@Wild Rosen`0.";
}
if ($_GET['op2']=="gift4"){
  $gift="Rote Rose";
  $session['user']['gold']-=50;
  $effekt="Ich lieeeebe `4Rote Rosen`0`n und dich auch";
}
if ($_GET['op2']=="gift5"){
  $gift="Wei�e Rose";
  $session['user']['gold']-=80;
  $effekt="Ich lieeeebe `&Wei�e Rosen`0";
}
if ($_GET['op2']=="gift6"){
  $gift="Schwarze Rose";
  $session['user']['gold']-=80;
  $effekt="Ich lieeeebe `~Schwarze Rosen`0.";
}
if ($_GET['op2']=="gift7"){
  $gift="Straus G�nsebl�mchen";
  $session['user']['gold']-=100;
  $effekt="Ohh, wie niedlich. Ein Paar `^G�nebl�mlein`0.";
}
if ($_GET['op2']=="gift8"){
  $gift="Straus Wild Rosen";
  $session['user']['gold']-=250;
  $effekt="Zwar hat diese Rosenart Stacheln, aber das St�rt dich bei dem Anblick der wundersch�nen Rosen nicht.";
}
if ($_GET['op2']=="gift9"){
  $gift="Straus Rote Rosen";
  $session['user']['gold']-=700;
  $effekt="Du bermerkst, dass dich da wer sehr zu m�gen scheint. `nDie `4Roten Rosen`0 sind wundersch�n.";
}
  if ($_GET['op2']=="gift10"){
  $gift="Straus Wei�e Rosen";
  $session['user']['gold']-=1000;
  $effekt="Die `&We�en Rosen`0 erinnern dich an etwas, du wei�t nur nicht was.";
}
if ($_GET['op2']=="gift11"){
  $gift="Straus Schwarze Rosen";
  $session['user']['gold']-=1000;
  $effekt="Du betrachtest den Straus `~Schwarze Rosen`0 und wei�t das diese etwas besonderes und zugleich �u�erst selten sind.";
}
$mailmessage=$session['user']['name'];
$mailmessage.="`7 hat dir ein Geschenk geschickt.  Du �ffnest es. Es ist ein/e `6";
$mailmessage.=$gift;
//you can change the following the match what you name your gift shop
$mailmessage.="`7 aus dem Blumenladen.`n".$effekt;
systemmail($name,"`2Blumen erhalten!`2",$mailmessage);
output("`rMit leuchtenden Augen nimmt Aeris die M�nze entgegen. \"Ich danke euch!\"`n
murmelt sie sch�chtern und l�uft los um die $gift zu �berbringen...");

addnav("Weiter","gardens.php");
}

page_footer();
?>
