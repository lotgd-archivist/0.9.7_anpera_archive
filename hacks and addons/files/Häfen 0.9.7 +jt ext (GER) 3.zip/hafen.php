<?php
/*
                                �@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@�
                                �                                                      �
                                �  Idee und Umsetzung                                  �
                                �  Morpheus aka Apollon                                �
                                �  2006 by Morpheus                                    �
                                �  F�r Morpheus-lotgd.de.vu                            �
                                �  Mail to Morpheus@magic.ms or Apollon@magic.ms       �
                                �  gewidmet meiner �ber alles geliebten Blume          �
                                �                                                      �
                                @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
*/
require_once "common.php";
addcommentary();
checkday();

if ($session['user']['alive']){ }else{
	redirect("shades.php");
}
addnav("Der Hafen");
addnav("Zur�ck nach XXX","XXX.php");
addnav("Die Bootsanleger","anleger.php");
page_header("Der Hafen von XXX");
output("`^`c`bDer Hafen`b`c`n`@Du kommst in den Hafen von XXX, die Luft riecht nach Salz, Wasser und frisch gefangenem Fisch.");
output("  Von hier aus starten Schiffe auf das Meer, um frische Meersfr�chte zu fangen und auf Entdeckungsfahrt, in der Hoffnung, auf neue St�dte und L�nder zu treffen, um das Angebot an Handelswaren in unseren Orten zu erh�hen.");
output("  Links vom Platz kannst Du den schoensten Sandstrand sehen, den man sich vorstellen kann. Ein gro�er Menhir steht in der Mitte des Hafenplatzes,");
$sql = "SELECT * FROM news WHERE 1 ORDER BY newsid DESC LIMIT 1";
$result = db_query($sql) or die(db_error(LINK));
$row = db_fetch_assoc($result);
output("auf dem du die neueste Meldung lesen kannst:`0`n`n`c`i$row[newstext]`i`c`n");
if (getsetting('activategamedate','0')==1) output("`qWir schreiben den `^".getgamedate()."`q im Zeitalter des Drachen.`n");
output("Die Uhr am Leuchtturm zeigt `^".getgametime()."`q Uhr.`n");
output("Das heutige Wetter ist `^".$settings['weather']."`q.`0");
output("`n`n`%`@In der N�he reden einige Dorfbewohner:`n`n");
viewcommentary("hafenXXX","Hinzuf�gen:",25);
page_footer();

?>