<?php
/*
                                �@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@�
                                �                                                      �
                                �  Idee und Umsetzung                                  �
                                �  Morpheus aka Apollon                                �
                                �  2006 f�r �r Morpheus-lotgd.de.vu                    �
                                �  By Morpheus                                         �
                                �  Mail to Morpheus@magic.ms or Apollon@magic.ms       �
                                �  gewidmet meiner �ber alles geliebten Blume          �
                                �  Der Teil "Verdinest" bei den Fischern wurde der     �
                                �  tagleohn.php von Fly entlehnt und angepa�t          �
                                �                                                      �
                                @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
*/
require_once "common.php";
checkday();
page_header("Die Bootsanleger");
if ($_GET['op']=="") {
	output("`9`c`bDie Bootsanleger`b`c`n`6");
	output("`7Du kommst zu den Stegen, an denen die Schiffe fest machen, um ihre Ladung zu l�schen und Passagiere auf zu nehmen.");
	output("`7An den Stegen herrscht gesch�ftiges Treiben, Fischer entladen ihren Fang, Galleonen werden von Kisten entladen, Passagiere gehen von und an Bord und mitten in all dem Treiben ist ein Stand, an dem eine Fischersfrau frische Fische verkauft.");
	addnav("Zur�ck zum Hafen","hafen.php");
	addnav("Fischstand","anleger.php?op=fisch");
	addnav("Boote");
	addnav("Passagierschiff","anleger.php?op=passagier");
	addnav("Fischerboot","anleger.php?op=fischer");
}
if ($_GET['op']=="fisch"){
	$laco=$session[user][level]*10;
	$moco=$session[user][level]*9;
	$heco=$session[user][level]*8;
	output("`g`nHinter einem Karren, der mit `&Eis `ggef�llt ist, steht eine alte Fischersfrau mit faltigem Gesicht und grauen Haaren, ihr Haar ist unter einem Kopftuch verschwunden und sie tr�gt eine `2gr�ne `gSch�rze �ber ihrem `&wei�`g-`9blauen `gHemd.");
	output("`gAuf dem Karren kannst Du verschiedene, kleine Spazialit�ten sehen, die sie verkauft. Sie gr��t Dich mit einem m�den L�cheln und fragt Dich, was Du gerne m�chtest.");
	addnav("`qLachsbr�tchen `^($laco Gold)","anleger.php?op=lachs");
	addnav("`#Rollmopsbr�tchen `^($moco Gold)","anleger.php?op=mops");
	addnav("`6Br�tchen mit `TBrathering `^($heco Gold)","anleger.php?op=brat");
	addnav("Zur�ck zum Anleger","anleger.php");
}
if ($_GET['op']=="lachs"){
	if ($session[user][gold]>=($session[user][level]*12) && $session[user][turns]>0){
		output("`gDie alte Fischerin nickt, greift in ihren Karren und gibt Dir ein Br�tchen mit Lachs darauf, w�hrend Du ihr den Preis aush�ndigst.");
			switch(e_rand(1,9)){ 
				case 1:
				case 2:
				output("`gGenu�voll bei�t Du in das Br�tchen und schmeckst, wie frisch der Fisch noch ist und wie gut er Dir tut.");
				$session[user][gold]-=($session[user][level]*10);
				$session[user][hitpoints]*=1.1;
				break;
				case 3:
				case 4:
				output("`gGenu�voll bei�t Du in das Br�tchen und schmeckst, wie frisch der Fisch noch ist.");
				$session[user][gold]-=($session[user][level]*10);
				break;
				case 5:
				case 6:
				output("`gGenu�voll bei�t Du in das Br�tchen und schmeckst, da� der Lachs wohl leider nicht mehr so ganz frisch war.");
				output("`gDir wird �bel und Du mu�t Dich �bergeben.");
				$session[user][gold]-=($session[user][level]*10);
				$session[user][hitpoints]*=0.9;
				break;
				case 7:
				output("`gGenu�voll bei�t Du in das Br�tchen und schmeckst, wie frisch der Fisch noch ist.");
				output("`gPl�tzlich bei�t Du auf etwas Hartes: ein kleiner Stein, unglaublich!");
				$session[user][gold]-=($session[user][level]*10);
				$session[user][hitpoints]*=0.95;
				break;
				case 8:
				output("`gGenu�voll bei�t Du in das Br�tchen und schmeckst, wie frisch der Fisch noch ist.");
				output("`gPl�tzlich bei�t Du auf etwas Hartes: ein `@Edelstein`g!!");
				$session[user][gold]-=($session[user][level]*10);
				$session[user][gemss]+=1;
				break;
				case 9:
				output("`gGenu�voll bei�t Du in das Br�tchen und schmeckst, wie frisch der Fisch noch ist.");
				output("`gGierig schlingst Du es runter und verschluckst Dich. R�chelnd liegst Du da, ein Seemann versucht noch, Dir zu helfen, doch es ist zu sp�t, Du bist erstickt!");
				$session['user']['alive']=false;
				$session['user']['hitpoints']=0;
				$session['user']['gold']=0;
				$session['user']['experience']*=0.97;
				addnews("`4".$session['user']['name']." `5hat zu gierig das Essen verschlungen und ist daran erstickt.");
				addnav("T�gliche News","news.php");
				break;
			}
	}else if ($session[user][turns]<=0){
		output("`gDie alte Fischerin sieht Dich von oben bis unten an:`9Nej, Du schaust mir mide aus, gej lieb� slafen.");
	}else{
		output("`gDie alte Fischerin sieht Dich von oben bis unten an:`9Nej, Du schaust mir nich aus, als ob Du Dir's leusten k�nnst.");
		}
	addnav("Zur�ck zum Anleger","anleger.php");
}
if ($_GET['op']=="mops"){
	if ($session[user][gold]>=($session[user][level]*9) && $session[user][turns]>0){
		output("`gDie alte Fischerin nickt, greift in ihren Karren und gibt Dir ein Br�tchen mit Rollmops darauf, w�hrend Du ihr den Preis aush�ndigst.");
			switch(e_rand(1,9)){ 
				case 1:
				case 2:
				output("`gGenu�voll bei�t Du in das Br�tchen und schmeckst, mit wieviel Liebe es zubereitet wurde und wie gut es Dir tut.");
				$session[user][gold]-=($session[user][level]*9);
				$session[user][hitpoints]*=1.05;
				$session[user][drunkenness]-=5;
				break;
				case 3:
				case 4:
				output("`gGenu�voll bei�t Du in das Br�tchen und schmeckst, mit wieviel Liebe es zubereitet wurde.");
				$session[user][gold]-=($session[user][level]*9);
				$session[user][drunkenness]-=5;
				break;
				case 5:
				case 6:
				output("`gGenu�voll bei�t Du in das Br�tchen und schmeckst, das der Fisch wohl leider nicht mehr so ganz frisch war.");
				output("`gDir wird �bel und Du mu�t Dich �bergeben.");
				$session[user][gold]-=($session[user][level]*9);
				$session[user][hitpoints]*=0.9;
				break;
				case 7:
				output("`gGenu�voll bei�t Du in das Br�tchen und schmeckst, wie frisch der Fisch noch ist.");
				output("`gPl�tzlich bei�t Du auf etwas Hartes: ein kleiner Stein, unglaublich!");
				$session[user][gold]-=($session[user][level]*9);
				$session[user][hitpoints]*=0.95;
				break;
				case 8:
				output("`gGenu�voll bei�t Du in das Br�tchen und schmeckst, wie frisch der Fisch noch ist.");
				output("`gPl�tzlich bei�t Du auf etwas Hartes: ein `^Goldklumpen `gim Wert von `250 Gold`g!!!");
				$session[user][gold]-=($session[user][level]*9);
				$session[user][drunkenness]-=5;
				$session[user][gold]+=250;
				break;
				case 9:
				output("`gGenu�voll bei�t Du in das Br�tchen und schmeckst, wie frisch der Fisch noch ist.");
				output("`gGierig schlingst Du es runter und verschluckst Dich. R�chelnd liegst Du da, ein Seemann versucht noch, Dir zu helfen, doch es ist zu sp�t, Du bist erstickt!");
				$session['user']['alive']=false;
				$session['user']['hitpoints']=0;
				$session['user']['gold']=0;
				$session['user']['experience']*=0.97;
				addnews("`4".$session['user']['name']." `5hat zu gierig das Essen verschlungen und ist daran erstickt.");
				addnav("T�gliche News","news.php");
				break;
			}
	}else if ($session[user][turns]<=0){
		output("`gDie alte Fischerin sieht Dich von oben bis unten an:`9Nej, Du schaust mir mide aus, gej lieb� slafen.");
	}else{
		output("`gDie alte Fischerin sieht Dich von oben bis unten an:`9Nej, Du schaust mir nich aus, als ob Du Dir's leusten k�nnst.");
		}
	addnav("Zur�ck zum Anleger","anleger.php");
}
if ($_GET['op']=="brat"){
	if ($session[user][gold]>=($session[user][level]*10) && $session[user][turns]>0){
		output("`gDie alte Fischerin nickt, greift in ihren Karren und gibt Dir ein Br�tchen mit Brathering darauf, w�hrend Du ihr den Preis aush�ndigst.");
			switch(e_rand(1,9)){ 
				case 1:
				case 2:
				output("`gGenu�voll bei�t Du in das Br�tchen und schmeckst, wie gut der Hering gebraten wurde und wie gut es Dir tut.");
				$session[user][gold]-=($session[user][level]*10);
				$session[user][hitpoints]*=1.1;
				break;
				case 3:
				case 4:
				output("`gGenu�voll bei�t Du in das Br�tchen und schmeckst, wie gut der Hering gebraten wurde.");
				$session[user][gold]-=($session[user][level]*10);
				break;
				case 5:
				case 6:
				output("`gGenu�voll bei�t Du in das Br�tchen und schmeckst, das der Fisch wohl leider nicht mehr so ganz frisch war.");
				output("`gDir wird �bel und Du mu�t Dich �bergeben.");
				$session[user][gold]-=($session[user][level]*10);
				$session[user][hitpoints]*=0.9;
				break;
				case 7:
				output("`gGenu�voll bei�t Du in das Br�tchen und schmeckst, wie frisch der Fisch noch ist.");
				output("`gPl�tzlich zipt und sticht es in Deinem Mund, weil noch zuviel Gr�ten in dem Fisch sind. `4AUA!");
				$session[user][gold]-=($session[user][level]*10);
				$session[user][hitpoints]*=0.95;
				break;
				case 8:
				output("`gGenu�voll bei�t Du in das Br�tchen und schmeckst, wie gut der Hering gebraten wurde.");
				output("`gPl�tzlich bei�t Du ein St�ck ab, das wohl von den G�ttern ber�hrt wurde und Deinen Geist befl�gelt!!!");
				$session[user][gold]-=($session[user][level]*10);
				$session[user][experience]*=1.1;
				break;
				case 9:
				output("`gGenu�voll bei�t Du in das Br�tchen und schmeckst, wie gut der Hering gebraten wurde.");
				output("`gGierig schlingst Du es runter und verschluckst Dich. R�chelnd liegst Du da, ein Seemann versucht noch, Dir zu helfen, doch es ist zu sp�t, Du bist erstickt!");
				$session['user']['alive']=false;
				$session['user']['hitpoints']=0;
				$session['user']['gold']=0;
				$session['user']['experience']*=0.97;
				addnews("`4".$session['user']['name']." `5hat zu gierig das Essen verschlungen und ist daran erstickt.");
				addnav("T�gliche News","news.php");
				break;
			}
	}else if ($session[user][turns]<=0){
		output("`gDie alte Fischerin sieht Dich von oben bis unten an:`9Nej, Du schaust mir mide aus, gej lieb� slafen.");
	}else{
		output("`gDie alte Fischerin sieht Dich von oben bis unten an:`9Nej, Du schaust mir nich aus, als ob Du Dir's leusten k�nnst.");
		}
	addnav("Zur�ck zum Anleger","anleger.php");
}
if ($_GET['op']=="fischer") {
	output("`g`nDu gehst zu den Fischerbooten, wo flei�ige H�nde noch dabei sind, den letzten Fang zu entladen und gesch�ftiges Treiben herrscht.");
	output("`gEine Zeit lang siehst Du dem Treiben zu, bis Dich ein alter Kapit�n anspricht: `9\"Na mejn ".($session[user][sex]?"M�del ":"Junge ").", mogst Dir wat dazu verdienen? Od� willst nu�r 'n b�schen frische Seeluft schnupp�n?\"");
	addnav("Was dazu verdienen","anleger.php?op=verdienst");
	addnav("Zur�ck zum Anleger","anleger.php");
}
if ($_GET['op']=="verdienst") {
	$gold = $session[user][level]*27;
	if ($session[user][turns]>4){
		output("`gDer alte Seeb�r nickt:`9Jut, ich k�nnd Di� folgendes onbieden:"); 
		output("`9Du k�nndest f��`^ $gold Gold `3jei Runde "); 
			switch(e_rand(1,3)){ 
				case 1: 
				$work = 1; 
				output("`9Fisch� aus'm Loderaum schlebben un oinkisten."); 
				break; 
				case 2: 
				$work = 2; 
				output("`9Fischkisten vom Kudd� schlebben."); 
				break; 
				case 3: 
				$work = 3; 
				output("`9dat Deck son b�schen schrubben, wa!."); 
				break; 
				case 4: 
				$work = 4; 
				output("`9son poor olle Fisch� k�bben un ausnehjmen."); 
				break; 
			} 
		addnav("5 Runden arbeiten","anleger.php?op=arb&op2=$work&op3=5"); 
		if ($session[user][turns]>9){ addnav("10 Runden arbeiten","anleger.php?op=arb&op2=$work&op3=10");} 
		if ($session[user][turns]>20){ addnav("20 Runden arbeiten","anleger.php?op=arb&op2=$work&op3=20");} 
	}else{ 
		output("`gDer alte Seeb�r schaut Dich von oben bis unten an:`9Nej, Du bis wohl doch schon 'n b�schen m�d� f�� hoide."); 
	} 
	addnav("Zur�ck zum Anleger","anleger.php"); 
} 
else  if ($_GET[op]=="arb"){ 
	$work = $_GET[op2]; 
	$rounds =   $_GET[op3]; 
	$gold = $session[user][level]*27*$rounds; 
	$session[user][turns]-=$rounds; 
	$session[user][gold]+= $gold; 
	output("`n`gDu arbeitest $rounds Runden und "); 
		switch($work){ 
		case 1: 
		output("`gschleppst Fische aus dem Laderaum nach drau�en, wo Du sie in Kisten packst.");
				switch(e_rand(1,4)){
					case 1:
					output("`gDabei f�llt einem der toten Tiere `@ein Edelstein `gaus dem Maul, den Du rasch einsteckst.");
					$session[user][gems]+=1;
					break;
					case 2:
					output("`gDabei `4verhebst `gDu Dich b�se und verlierst ein paar Lebenspunkte.");
					$session[user][hitpoints]*=0.95;
					break;
					case 3:
					output("`gDabei lernst Du von den alten Fischern etwas �ber das Leben in der Welt.");
					$session[user][experience]*=1.03;
					break;
					case 4:
					output("`gDabei f�llt einem der anderen ein Kiste auf Deinen Kopf und Du verlierst ein wenig an Erfahrung dadurch.");
					$session[user][experience]*=0.98;
					break;
				}
		addnews($session['user']['name']." half im Hafen, Fische aus dem Kutter zu laden.");
		break; 
		case 2: 
		output("`gschleppst Kiste �ber Kiste vom Fischkutter, was Dich ganz sch�n mit nimmt und ins Schwitzen bringt.");
		$session[user][turns]-=1; 
		addnews($session['user']['name']." half im Hafen, Fischkisten vom Kutter zu schleppen.");
		break; 
		case 3: 
		output("`gschrubbst das Deck, bis es blitzt und blinkt,"); 
				switch(e_rand(1,4)){
					case 1:
					output("`gals der 1. Maat vorbei kommt mit einer Kiste Fischabf�lle, die ihm aus der Hand gleitet und sich auf Decke verteilt, was ihm nat�rlich sehr peinlich ist.");
					output("`gEr hilft Dir beim erneuten Reinigen und zahlt Dir 100 Gold als Entschuldigung, doch vor lauter Frust verlierst Du 1 Charmepunkt");
					$session[user][gold]+=100;
					$session[user][charm]-=1;
					break;
					case 2:
					output("`gwobei Du an einer gebrochenen Planke h�ngen bleibst und Dich verletzt.");
					$session[user][hitpoints]*=0.95;
					break;
					case 3:
					output("`gwobei Du den Gespr�chen der alten Fischersleute lauscht und ein wenig �ber die Welt lernst.");
					$session[user][experience]*=1.02;
					break;
					case 4:
					output("`gwobei Du Dir, als Du wieder aufstehen willst, den Kopf b�se anhaust und prompt etwas Erfahrung verlierst.");
					$session[user][experience]*=0.98;
					break;
				}
		addnews($session['user']['name']." schrubbte das Deck auf einem Fischkutter.");
		break; 
		case 4: 
		output("`gk�pfst, entschuppst und nimmst Fische aus so viel Du kannst.");
				switch(e_rand(1,4)){
					case 1:
					output("`gDoch hast Du die Sch�rtze, die Dir angeboten wurde, abgelehnt und jetzt bist Du ganz voll Fischblut und -schuppen, kein sch�ner Anblick!");
					output("`gDu verlierst 2 Charmepunkte!");
					$session[user][charm]-=2;
					break;
					case 2:
					output("`gDu machst Faxen wie ein Clown dabei, was sich derart r�cht, da� Du Dich b�se schneidest.");
					$session[user][hitpoints]*=0.9;
					break;
					case 3:
					output("`gBei der Arbeit hilft Dir der Smutje, der Dir vieles aus der gro�en, weiten Welt berichtet, wodurch Du einiges lernst.");
					$session[user][experience]*=1.1;
					break;
					case 4:
					output("`gIm Inneren eines gro�en Fisches findest Du `@ 2Edelsteine `gund `^314 Gold`g.");
					output("`gLaut jubelnd springst Du auf und st��t Dir dabei b�se den Kopf.");
					$session[user][hitpoints]*=0.93;
					$session[user][experience]*=0.95;
					$session[user][gold]+=314;
					$session[user][gems]+=2;
					break;
				}
		addnews($session['user']['name']." nahm jede Menge Fische aus.");
		break; 
	} 
	output(" `gNach getaner Arbeit gehst Du zu dem alten Kapit�n, Dir Deine`^ $gold `gbei ihm ab zu holen."); 
	output(" `9Na, da hast Du jo gonze Arbeit gelejstet! wenn Du wied� mal Gold brauchst, komm oinfach vobei, n�!");
	addnav("Zur�ck zum Anleger","anleger.php");
}
if ($_GET['op']=="passagier") {
	output("`g`nDu gehst zu dem Pier, an dem mehrere, gro�e Segelschiffe liegen, die offenbar zu Bef�rderung von Fracht und Passagieren gedacht sind.");
	output("`gEs herrscht ein reger Betrieb, Kisten werden be- und entladen, Arbeiter laufen umher, zwischendrin Katzen, die um Fische zanken und Kinder, die dort spielen.`n");
	output("`gEhrf�rchtig betrachtest Du die gro�en Schiffe, die offensichtlich schon so manchem Sturm getrotzt und so manche Seemeile gefahren haben.");
	addnav("Schiff nach XXX","reisen.php");
	addnav("Ein Forschungsreise machen","anleger.php?op=forsch");
	addnav("Zur�ck zum Anleger","anleger.php");
}
if ($_GET['op']=="forsch") {
	output("`g`nDu gehst zu den kleineren Schiffen, die Abenteurern geh�ren, die f�r die richtige Summe, zu allem bereit sind und fragst, ob Du jemand anheuern kannst, um eine Forschungsreise zu machen.");
	output("`gDie Kapit�ne w�rden gerne, teilen Dir aber mit, da� im Moment kein Schiffe auslaufen k�nnen, weil");
		switch(e_rand(1,6)){ 
			case 1:
			output("`gein gro�er Sturm im Anflug ist.");
			addnav("Zur�ck zum Pier","anleger.php?op=passagier");
			break;
			case 2:
			output("`gdie Hafeneinfahrt versandet ist und die Schiffe zu tief liegen, um durch zu kommen.");
			addnav("Zur�ck zum Pier","anleger.php?op=passagier");
			break;
			case 3:
			output("`geine Riesenkrake sein Unwesen in den Gew�ssern vor der Stadt treibt.");
			addnav("Zur�ck zum Pier","anleger.php?op=passagier");
			break;
			case 4:
			output("`gdie Matrosen im Moment streiken.");
			addnav("Zur�ck zum Pier","anleger.php?op=passagier");
			break;
			case 5:
			output("`g2 fremde M�chte Krieg f�hren und alle Schiffe versenken, die sie treffen.");
			addnav("Zur�ck zum Pier","anleger.php?op=passagier");
			break;
			case 6:
			output("`gdie Pest au�erhalb unseres Landes herrscht.");
			addnav("Zur�ck zum Pier","anleger.php?op=passagier");
			break;
		}
}
page_footer();
?>