<?php
/*
                                �@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@�
                                �                                                      �
                                �  Idee und Umsetzung                                  �
                                �  Morpheus aka Apollon & Lilith                       �
                                �  2006 f�r logd.at(LoGD 0.9.7 +jt ext (GER) 3)        �
                                �  �nderung und Verbesserung in 2008                   �
                                �  By Morpheus                                         �
                                �  F�r Morpheus-lotgd.de.vu                            �
                                �  Mail to Morpheus@magic.ms or Apollon@magic.ms       �
                                �  gewidmet meiner �ber alles geliebten Blume          �
                                �                                                      �
                                @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
*/
require_once "common.php";
page_header("REISEN");
if($_GET['op']==""){
	output("`g`nDu gehst zum Hafenmeister und fragst ihn, wann wieder Schiffe auslaufen und er zeigt auf ein Tafel, die hinter ihm an der Wand h�ngt:`n`n");
	output("`6Schiff nach XXX:`n");
	output("`6Auslaufen in K�rze, Kosten `^1000 Gold`n");
	addnav("B�ro des Hafenmeisters");
	if ($session[user][gold]>999){
		if ($session[user][reisen]>0){
			addnav("Schiff nach XXX","reisen.php?op=hin");
			addnav("Zur�ck zum Anleger","anleger.php?op=passagier");
		}else{
			addnav("Zur�ck zum Anleger","anleger.php?op=passagier");
		}
	}else{
		addnav("Zur�ck zum Anleger","anleger.php?op=passagier");
	}
}
if ($_GET[op]=="hin"){
	output("`c`b`7Das Schiff`0`b`c`n");
	output("`gDu freust Dich und legst dem Hafenmeister das Gold f�r die Reise auf den Tisch.");
	output("`gAnschlie�end gehst Du an Bord, die Reise beginnt und");
		switch(e_rand(1,17)){
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
	   		output("`gverl�uft ganz nach Plan, ohne besondere Vorkomnisse.");
	   		$session[user][gold]-=1000;
			$session['user']['ort']=13;
			addnav("Weiter","hafen1.php");
	   		break;
			case 6:
			case 7:
			case 8:
			case 9:
			case 10:
	   		output("`gverl�uft ganz nach Plan, au�er da� Du Seekrank wirst und Dich st�ndig �bergeben mu�t.");
			$session[user][hitpoints]*=0.8;
			$session[user][gold]-=1000;
			$session['user']['ort']=13;
			addnav("Weiter","hafen1.php");
	   		break;
			case 11:
			case 12:
			case 13:
			case 14:
			case 15:
	   		output("`gmitten auf der hohen See gibt es einen Zwischenfall,");
				switch(e_rand(1,10)){
					case 1:
	   				output("`geine `9riesige Kracke `ggreift das Schiff an!");
					$_SESSION['tmp']['mons']="`9Riesige Kracke`0";
					$_SESSION['tmp']['waff']="Riesige Tentakel";
	   				break;
					case 2:
	   				output("`gein `9Riesenhai `ggreift das Schiff an!");
					$_SESSION['tmp']['mons']="`9Riesenhai`0";
					$_SESSION['tmp']['waff']="Scharfe Z�hne";
	   				break;
					case 3:
	   				output("`gein Schiff mit `TOrk Piraten `ggreift das Schiff an!");
					$_SESSION['tmp']['mons']="`TOrk Piraten`0";
					$_SESSION['tmp']['waff']="Entermesser";
	   				break;
					case 4:
	   				output("`gein Schiff mit `Vabtr�nnigen Wikingern `ggreift das Schiff an!");
					$_SESSION['tmp']['mons']="`VAbtr�nnige Wikinger`0";
					$_SESSION['tmp']['waff']="Kampf�xte";
	   				break;
					case 5:
	   				output("`gein `9Wass`#erd`9�mon `ggreift das Schiff an!");
					$_SESSION['tmp']['mons']="`9Wass`#erd`9�mon`0";
					$_SESSION['tmp']['waff']="Scharfer Wasserstrahl";
	   				break;
					case 6:
	   				output("`gein `'Luftgeist `ggreift das Schiff an!");
					$_SESSION['tmp']['mons']="`#Luftgeist`0";
					$_SESSION['tmp']['waff']="Windpfeile";
	   				break;
					case 7:
	   				output("`gein Schiff mit `&�gyptischen Piraten `ggreift das Schiff an!");
					$_SESSION['tmp']['mons']="`&�gyptische Piraten`0";
					$_SESSION['tmp']['waff']="Krumms�bel";
	   				break;
					case 8:
	   				output("`geine `qRiesengarnelle `ggreift das Schiff an!");
					$_SESSION['tmp']['mons']="`qRiesengarnelle`0";
					$_SESSION['tmp']['waff']="Lange Fangarme";
	   				break;
					case 9:
	   				output("`gein `9b�sartiger Wassermann `ggreift das Schiff an!");
					$_SESSION['tmp']['mons']="`9B�sartiger Wassermann`0";
					$_SESSION['tmp']['waff']="Dreizack";
	   				break;
					case 10:
	   				output("`geine `9b�sartige Nixe `ggreift das Schiff an!");
					$_SESSION['tmp']['mons']="`9B�sartige Nixe`0";
					$_SESSION['tmp']['waff']="Riesenwellen";
	   				break;
				}
			addnav("Weiter","reisen.php?op=kampf");
	   		break;
			case 16:
					output("`gbeginnt auch ganz normal, bis ein Sturm auf zieht.");
					output("`gDer Kapit�n tut, was er kann, doch er kommt nicht gegen das Wetter an, das Schiff kentert und sinkt mit Mann und Maus.");
					output("`gDu kannst Dich, zusammen mit wenigen �berlebenden, auf ein Beiboot retten und treibst, v�llig ersch�pft und halb tot, zur�ck nach XXX.");
					$session[user][hitpoints]=1;
					$session[user][gold]-=2000;
	      				$session[user][turns]-=5;
					addnav("Weiter","hafen.php");
	   		break;
			case 17:
			output("`gbeginnt auch ganz normal, bis ein Sturm aufzieht.");
			output("`gDer Kapit�n tut, was er kann, doch er kommt nicht gegen das Wetter an, das Schiff kentert und sinkt mit Mann und Maus.");
			$session['user']['alive']=false;
			$session['user']['hitpoints']=0;
			$session['user']['gold']=0;
			$session['user']['experience']*0.97;
			addnews($session['user']['name']." ertrank auf einer Seereise.");
			addnav("T�gliche News","news.php");
			break;
		}
}
if ($_GET['op']=="kampf"){
	$mon=$_SESSION['tmp']['mons'];
	$waf=$_SESSION['tmp']['waff'];
	$badguy = array(
        	"creaturename"=>"$mon`0",
        	"creaturelevel"=>$session[user][level], 
        	"creatureweapon"=>"$waf",
        	"creatureattack"=>$session['user']['attack'],
        	"creaturedefense"=>$session['user']['defence'],
        	"creaturehealth"=>round($session['user']['maxhitpoints']*0.5,0),
		"diddamage"=>0);
    		$session['user']['badguy']=createstring($badguy);
	$_GET['op']="fight";
}
if ($_GET[op]=="run"){
        output("`c`b`\$Du denkst daran zu fliehen, aber auf dem Schiff gibt es kein Entkommen!`0`b`c`n");
        $battle=true;
}
if ($_GET['op']=="fight"){
	$battle=true;
}
if ($battle){
	include ("battle.php");
	$mon=$_SESSION['tmp']['mons'];
	if ($victory){
		output("`n`6Du hast $mon `6besiegt und das Schiff setzt seinen Weg fort.`0");
		$gold=(e_rand(100,300));
		$session['user']['gold']+=$gold;
		$session['user']['experience']*=1.02;
		$badguy=array();
		$session[user][badguy]="";
		addnav("W?Weiter","reisen.php?op=hin");
	}elseif($defeat){
		output("`VDu wurdest von $mon `Vbesiegt und bist jetzt `4TOT`V!");
		$session['user']['hitpoints']=0;
		$session['user']['gold']=0;
		$session['user']['experience']*=0.95;
		addnews("`^$n `3wurde von $mon `3, auf einem Schiff auf dem Weg nach `6Artep`3, get�tet!");
		addnav("T�gliche News","news.php");
	}else{
		fightnav();
	}
}
page_footer();
?>