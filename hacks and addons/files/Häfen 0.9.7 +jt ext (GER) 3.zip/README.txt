Hafen, Bootsanleger und die Reisen
//Idee und Umsetzung
//Morpheus aka Apollon
//2006 f�r Morpheus.Lotgd(LoGD 0.9.7 +jt ext (GER) 3)
//Mail to Morpheus@magic.ms or Apollon@magic.ms
//gewitmet meiner �ber alles geliebten Blume

EINBAUANLEITUNG:
================

A. Hafen & Hafen1

1. Hafen �ffnen und in den addnavs xxx durch den Namen des Ortes und der entsprechenden php Datei ersetzen.

2. Im Text die XXX durch den Namen des Ortes ersetzen, in dem der Hafen sein soll.

3. In der php Datei, die zu dem Ort geh�rt (z.B. villgae.php) an passender Stelle einen Link setzen
   
   addnav("Zum Hafen","hafen.php");

4. Hafen1 �ffnen und in den addnavs xxx durch den Namen des Ortes und der entsprechenden php Datei ersetzen.

5. Im Text die XXX durch den Namen des Ortes ersetzen, in dem der Hafen1 sein soll.

6. In der php Datei, die zu dem Ort geh�rt (z.B. sanela.php) an passender Stelle einen Link setzen
   
   addnav("Zum Hafen","hafen1.php");



B. Anleger & Anleger1

1. Die Datei anleger �ffnen und im Teil ganz unten, passagier, den Namen des Zielhafens f�r die xxx eingeben (Stadt, in der der Hafen1 liegt).

2. Die Datei anleger1 �ffnen und im Teil ganz unten, passagier, den Namen des Zielhafens f�r die xxx eingeben (Stadt, in der der Hafen liegt).




C. reisen & reisen1

1. Die Datei reisen �ffenn und oben f�r die XXX den Namen der Zielsatdt eingeben (wo der Hafen1 liegt)

2. In case 11 den Namen der Ausgangsstadt einf�gen (wo der Hafen liegt).

3. Die Datei reisen1 �ffenn und oben f�r die XXX den Namen der Zielsatdt eingeben (wo der Hafen liegt)

4. In case 11 den Namen der Ausgangsstadt einf�gen (wo der Hafen1 liegt).


Die Dateien sind willk�rlich duplizierbar, soviel H�fen, wie eben ben�tigt werden, lassen sich herstellen mit eben so vielen anlegern und reisen. In den H�fen/Anlegern k�nnen noch beliebig viele Sachen verlinkt werden wie ein Strand, Fischh�ndler, u.s.w. F�r die Forschungsreisen lasse ich mir grade etwas einfallen, sobald es fertig ist und erprobt, werde ich es im Threat posten bzw. dem ZIP hinzu f�gen.
Noch etwas: ich habe nichts dagegen, wenn die Texte und Preis dem Server angepa�t werden, aber ich bitte darum, das copyright zu beachten und zu belassen.
Nun viel Spa� damit...