<?php

    output("`3Du betrittst den grossen Markt und siehst einen grossen Menschenauflauf. Alle dr�ngen sich auf die "
      ."verschiedensten St�nde zu, links steht ein grosser Obststand, gegen�ber ein Stand f�r Gem�se. W�hrend du "
      ."die Strasse entlang gehst, auf der Suche nach etwas intressantem, musterst du die unterschiedlichsten "
      ."St�nde, Personen und Gegenst�nde.`0");

    $angebote = markt_query_items("%",5,0);

    rawoutput('<br /><br /><br /><br /><br />'
      .'<table border="0" cellpadding="2" cellspacing="1" bgcolor="#999999" align="center" width="60%">'
      .'<tr class="trhead"><td colspan="7"><center><font size="2"><b>Die 5 neusten Gegenst�nde</font></b></center></td></tr>'
      .'<tr class="trdark">'
        .'<td>Item</td>'
        .'<td>Itemklasse</td>'
        .'<td>Angeboten von</td>'
        .'<td>Wert 1</td>'
        .'<td>Wert 2</td>'
        .'<td style="color: #FFFF00;">Goldpreis</td>'
        .'<td style="color: #FF00FF;">Edelsteinpreis</td>'
      .'</tr>');

    if($angebote['rows'] == 0)
    {
      rawoutput('<tr class="trdark"><td colspan="7"><i>Keine Items vorhanden</i></td></tr>');
    }
    else
    {
      $i = 0;
      while($row = db_fetch_assoc($angebote['result']))
      {
        $class = ($i%2?"trdark":"trlight");
        rawoutput('<tr class="'.$class.'">'
            .'<td>'.$row['name'].'</td>'
            .'<td>'.$row['class'].'</td>'
            .'<td>'.yeoldemail($row['ownerlogin'],true).appoencode($row['ownername'].'`0',false).'</td>'
            .'<td style="color: #FFFFFF;">'.$row['value1'].'</td>'
            .'<td style="color: #FFFFFF;">'.$row['value2'].'</td>'
            .'<td style="color: #FFFF00;">'.$row['gold'].'</td>'
            .'<td style="color: #FF00FF;">'.$row['gems'].'</td>'
          .'</tr>'
          .'<tr class="'.$class.'">'
            .'<td colspan="7"><i>'.appoencode($row['description'].'`0',false).'</i></td>'
          .'</tr>');
        $i++;
      }
    }
    rawoutput("</table>");
    
?>
