<?php

  $injection = '';
  
  switch($_GET['itemclass'])
  {
    case 'moebel':
      $class = 'M�bel';
      $injection = "`value1` = 0 ";
      break;
      
    case 'schmuck':
      $class = 'Schmuck';
      $injection = "`value1` = 0 ";
      break;
      
    case 'beute':
      $class = 'Beute';
      break;
      
    default:
      $class = MARKT_DEFAULT_ITEMCLASS;
  }
  
  $itemid = (int)$_GET['item'];
  define('GOLD',(int)$_POST['gold']);
  define('GEMS',(int)$_POST['gems']);
  
  output('`3Der Gegenstand wurde soeben erfolgreich ins Angebot �bernommen.`n'
    .'Vielen Dank,`n~`^Die Dorfverwaltung`0');

  markt_insert_useritem($itemid,$injection);
?>
