<?php

  switch($_GET['itemclass'])
  {
    case 'moebel':
      $class = 'M�bel';
      break;
    case 'schmuck':
      $class = 'Schmuck';
      break;
    case 'beute':
      $class = 'Beute';
      break;
    default:
      $class = MARKT_DEFAULT_ITEMCLASS;
  }
  
  $itemid = (int)$_GET['item'];
  
  $items = markt_select_useritem_byid($itemid);
  $itemrow = $items['row'];
  
  output('`c`3`nDu m�chtest also das Item "`^'.$itemrow['name'].'`3" anbieten?`n'
    .'Dann m�ssen wir nur noch wissen, wie teuer du es anbieten m�chtest.`0`c`n');
    
    
  $formlink = $filename.'?op=sellitems3&itemclass='.$_GET['itemclass'].'&item='.$itemrow['id'];
  addnav('',$formlink);
  
  rawoutput('<br /><br /><form action="'.$formlink.'" method="POST">'
    .'<table align="center">'
    .'<tr>'
      .'<td><span style="color: #FFFF00">Goldpreis</span></td>'
      .'<td><input type="text" size="5" name="gold" value="0" /></td>'
    .'</tr>'
    .'<tr>'
      .'<td><span style="color: #FF00FF">Edelsteinpreis</span></td>'
      .'<td><input type="text" size="5" name="gems" value="0" /></td>'
    .'</tr>'
    .'<tr>'
      .'<td align="center" colspan="2"><input type="submit" value="Anbieten" class="button" /></td>'
    .'</tr>'
    .'</table>'
    .'</form>'
  );

?>
