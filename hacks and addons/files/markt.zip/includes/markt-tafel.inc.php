<?php
/*
    Diese komplette Datei z�hlt zu den Speziell markierten Stellen, die in den
    Nutzungsbediennungen erw�hnt werden!
    Was das heisst, kannst du dir denken...
*/

addcommentary();

output('`n`3Ruhig ist hier die Atmosph�re. Abgelegen vom grossen Trubel steht hier eine '
  .'Gedenktafel die es Wert ist, einmal gelesen zu werden:`n`n`c`^'
  .'D\'anthe Nephilea,`n'
  .'Usstan plynnil nindol wiles er\'griff whol dos,`n'
  .'t\'yin dos ph\' ussta ssussun wun nindol oloth.`n'
  .'Wun ril drada Usstan talinth ulu dos,`n'
  .'Wun ril drada Usstan ssinssrigg dos.`n'
  .'Ka l\' Sssiks elggat,`n'
  .'ka nau Elemmiire pholor l\' olath Anulo,`n'
  .'ka usstan dwalc lu\' er\'griff ussta jiv\'undusen telanth ulu uns\'aa: "Dos ph\' dro",`n'
  .'Usstan ajak, nindel dos zhahus l\' ust j\'nesst, nindel ssinssrigg ussta ji... Ji mzilt...`n'
  .'Usstan lle\'warin dos... Lu\' usstan daewl, nindel dos ajak *dos* pholor nindol ssin draeval,`n'
  .'lu\' doer rath ulu uns\'aa... Usstan\'bal tlus feithin, er\'griff whol dos, Nephilea.`n'
  .'Drill Usstan phlith dos, Ang�iath, Usstan phlith dos whol nindol dos inbal xunor...`n`n'
  .'~Wasili'
  .'`3`c`n`n');


viewcommentary('markt-tafel');
?>
