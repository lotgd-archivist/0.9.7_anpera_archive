<?php

$itemid = (int)$_GET['item'];

    // Gew�nschtes Item aus der Datenbank nehmen
    $itemrow = markt_select_item($itemid);
    // Na? Wer jemand schneller?
    //   Gib wenigstens was sch�nes aus, ja? :)
    if($itemrow === false)
    {
      output('`3Gerade als du den Gegenstand deiner W�nsche schnappen m�chstest, kommt dir eine Hand zuvor, und entreisst '
        .'genau `4diesen`3 Gegenstand aus deinem Blickfeld.`n'
        .'`5So gehts halt den Langsamen`3, denkst du, und seufzt, w�hrend du dich weiter umschaust.`0');

      // Man gebe dem User wenigstens die M�glichkeit, �hnliche Items zu suchen
      $back = true;
      $backlink = $filename.'?op=showitems&itemclass='.$_GET['itemclass'];
    }
    else
    {
      $row = $itemrow['row'];

      define('HASNT_GOLD',($session['user']['gold'] >= $row['gold']?$row['gold']:true));
      define('HASNT_GEMS',($session['user']['gems'] >= $row['gems']?$row['gems']:true));
      define('IS_MULTI',ac_check($row));

      // Begin der �berpr�fungen
      if(HASNT_GOLD === true || HASNT_GEMS === true)
      {
        output('`3Mit tr�ben Blicke blickst du zu Boden, da der Verk�ufer mit ernster Stimme '
          .'dir gerade erkl�rt hat, dass bei ihm nicht gefeilscht wird.`0');

        // Retour-Link
        $back = true;
        $backlink = $filename.'?op=showitems&itemclass='.$_GET['itemclass'];
      }
      elseif(IS_MULTI === true)
      {
        output('`3Der Verk�ufer lacht dich gen�sslich an. "`2Glaubst du eigentlich, dass ich nicht weiss '
          .'dass ein Verwandter von dir diesen Gegenstand angeboten hat? Verschwinde!`3".`0');

        // Retour-Link
        $back = true;
        $backlink = $filename.'?op=showitems&itemclass='.$_GET['itemclass'];
      }
      else
      {
        // Item umtragen
        $doneit = markt_update_item($itemid);
        // Letzte Chance, dass wer schneller war
        if($doneit === false)
        {
          output('`3Gerade als du den Gegenstand deiner W�nsche schnappen m�chstest, kommt dir eine Hand zuvor, und entreisst '
            .'genau `4diesen`3 Gegenstand aus deinem Blickfeld.`n'
            .'`5So gehts halt den Langsamen`3, denkst du, und seufzt, w�hrend du dich weiter umschaust.`0');

          // Man gebe dem User wenigstens die M�glichkeit, �hnliche Items zu suchen
          $back = true;
          $backlink = $filename.'?op=showitems&itemclass='.$_GET['itemclass'];
        }
        else
        {
          output('`3Schnell gibst du dem Verk�ufer das verlangte Geld, und machst dich mit dem '
            .'Gegenstand deiner Begierde aus dem Staub. `5Ha`3, denkst du gl�cklich, `5Endlich hab '
            .'ich es. Gl�ck gehabt`3. Doch bist du wirklich Gl�cklich damit?`0');

          $session['user']['gold'] -= HASNT_GOLD;
          $session['user']['gems'] -= HASNT_GEMS;
        }
      }
    }

?>
