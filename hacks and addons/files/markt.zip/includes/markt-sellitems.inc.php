<?php

  switch($_GET['itemclass'])
  {
    case 'moebel':
      $class = 'M�bel';
      break;
    case 'schmuck':
      $class = 'Schmuck';
      break;
    case 'beute':
      $class = 'Beute';
      break;
    default:
      $class = MARKT_DEFAULT_ITEMCLASS;
  }

  //  Wenn _GET['sort'] nicht gesetzt, nach "name" sortieren
  //  Ansonsten nach dem Feld sortieren, dass in _GET['sort'] �bergeben wurde
  if(!isset($_GET['sort'])) $sort = 'name';
  else $sort = $_GET['sort'];

  //  Wenn _GET['sortby'] nicht gesetzt ist mit "ASC" sortieren
  //  Wenn _GET['sortby'] gesetzt ist, $sortby mit dem Wert belegen
  if(!isset($_GET['sortby'])) $sortby = 'ASC';
  else $sortby = $_GET['sortby'];

  //  Wird f�r die Links ben�tigt: Wie soll neu sortiert werden?
  //  Wenn nach "DESC" sortiert wurde, neu nach ASC und verkehrt rum.
  $newsort = ($sortby == 'DESC'?'ASC':'DESC');

  //  Wieviele Seiten wurden bereits zur�ck gescrollt?
  //  Nicht angegeben? Also keine.
  //  Angegeben? Also $scroll mit dem Wert f�llen.
  if(!isset($_GET['scroll'])) $scroll = 0;
  else $scroll = $_GET['scroll'];

  //  Gegenst�nde pro Seite
  $limit = 30;
  //  Startpunkt f�r den Query
  $start = $scroll*$limit;

  // Die Links f�r die Tabelle vorbereiten
  $sortlink = array(
    $filename.'?op=sellitems&itemclass='.$_GET['itemclass'].'&sort=name&sortby='.$newsort.'&scroll='.$scroll,
    $filename.'?op=sellitems&itemclass='.$_GET['itemclass'].'&sort=value1&sortby='.$newsort.'&scroll='.$scroll,
    $filename.'?op=sellitems&itemclass='.$_GET['itemclass'].'&sort=value2&sortby='.$newsort.'&scroll='.$scroll,
    $filename.'?op=sellitems&itemclass='.$_GET['itemclass'].'&sort=gold&sortby='.$newsort.'&scroll='.$scroll,
    $filename.'?op=sellitems&itemclass='.$_GET['itemclass'].'&sort=gems&sortby='.$newsort.'&scroll='.$scroll,
  );
  // Und dieselbigen nat�rlich erlauben.
  addnav('',$sortlink[0]);
  addnav('',$sortlink[1]);
  addnav('',$sortlink[2]);
  addnav('',$sortlink[3]);
  addnav('',$sortlink[4]);
    
  // Sortierargument f�r den Query vorbereiten
  $orderstring = 'ORDER BY `'.$sort.'` '.$sortby;

  $items = markt_select_useritems($class,$limit,$start,$orderstring);

  // rawoutput('<br /><br /><br /><br /><br />'
  rawoutput('<br />'
    .'<table border="0" cellpadding="2" cellspacing="1" bgcolor="#999999" align="center" width="60%">'
    .'<tr class="trhead">'
      .'<td><a href="'.$sortlink[0].'"><strong>Item</strong></a></td>'
      .'<td><a href="'.$sortlink[1].'"><strong>Wert 1</strong></a></td>'
      .'<td><a href="'.$sortlink[2].'"><strong>Wert 2</strong></a></td>'
      .'<td style="color: #FFFF00;"><a href="'.$sortlink[3].'"><strong>Goldwert</strong></a></td>'
      .'<td style="color: #FF00FF;"><a href="'.$sortlink[4].'"><strong>Edelsteinwert</strong></a></td>'
      .'<td><strong>Optionen</strong></td>'
    .'</tr>');

    if($items['rows'] == 0)
    {
      rawoutput('<tr class="trdark"><td colspan="7"><i>Keine Items dieser Klasse vorhanden</i></td></tr>');
    }
    else
    {
      $i = 0;
      while($row = db_fetch_assoc($items['result']))
      {
        $class = ($i%2?"trdark":"trlight");
        
        $formlink = $filename.'?op=sellitems2&itemclass='.$_GET['itemclass'].'&item='.$row['id'];
        addnav('',$formlink);
        
        rawoutput('<tr class="'.$class.'">'
            .'<td>'.$row['name'].'</td>'
            .'<td style="color: #FFFFFF;">'.$row['value1'].'</td>'
            .'<td style="color: #FFFFFF;">'.$row['value2'].'</td>'
            .'<td style="color: #FFFF00;">'.$row['gold'].'</td>'
            .'<td style="color: #FF00FF;">'.$row['gems'].'</td>'
            .'<td><a href="'.$formlink.'">[Anbieten ]</a></td>'
          .'</tr>'
          .'<tr class="'.$class.'">'
            .'<td colspan="7"><i>'.appoencode($row['description'].'`0',false).'</i></td>'
          .'</tr>');
        $i++;
      }
    }
    rawoutput("</table>");
    
?>
