<?php

    output('`3Du schreitest neugierig zu einem Stand ');

    //  Wenn _GET['sort'] nicht gesetzt, nach "entrydate" sortieren
    //  Ansonsten nach dem Feld sortieren, dass in _GET['sort'] �bergeben wurde
    if(!isset($_GET['sort'])) $sort = 'entrydate';
    else $sort = $_GET['sort'];

    //  Wenn _GET['sortby'] nicht gesetzt ist und $sort nicht "entrydate" ist (=> Spezialfall)
    //    mit "ASC" sortieren
    //  Wenn _GET['sortby'] nicht gesetzt ist, aber $sort "entrydate" ist,
    //    mit "DESC" sortieren
    //  Wenn _GET['sortby'] gesetzt ist, $sortby mit dem Wert belegen
    if(!isset($_GET['sortby']) AND $sort != 'entrydate') $sortby = 'ASC';
    elseif(!isset($_GET['sortby']) AND $sort == 'entrydate') $sortby = 'DESC';
    else $sortby = $_GET['sortby'];

    //  Wenn _GET['sorttable'] nicht gesetzt ist, als Tabelle "itemtransfer" annehmen
    //  Wenn nicht, $sorttable den entsprechenden Wert zuweisen.
    if(!isset($_GET['sorttable'])) $sorttable = 'itemtransfer';
    else $sorttable = $_GET['sorttable'];

    //  Wird f�r die Links ben�tigt: Wie soll neu sortiert werden?
    //  Wenn nach "DESC" sortiert wurde, neu nach ASC und verkehrt rum.
    $newsort = ($sortby == 'DESC'?'ASC':'DESC');

    //  Wieviele Seiten wurden bereits zur�ck gescrollt?
    //  Nicht angegeben? Also keine.
    //  Angegeben? Also $scroll mit dem Wert f�llen.
    if(!isset($_GET['scroll'])) $scroll = 0;
    else $scroll = $_GET['scroll'];

    //  Gegenst�nde pro Seite
    $limit = 30;
    //  Startpunkt f�r den Query
    $start = $scroll*$limit;

    // Sortierargument f�r den Query vorbereiten
    $orderstring = 'ORDER BY `'.$sorttable.'`.`'.$sort.'` '.$sortby;

    // Die Links f�r die Tabelle vorbereiten
    $sortlink = array(
      $filename.'?op=showitems&itemclass='.$_GET['itemclass'].'&sorttable=items&sort=name&sortby='.$newsort.'&scroll='.$scroll,
      $filename.'?op=showitems&itemclass='.$_GET['itemclass'].'&sorttable=accounts&sort=login&sortby='.$newsort.'&scroll='.$scroll,
      $filename.'?op=showitems&itemclass='.$_GET['itemclass'].'&sorttable=items&sort=value1&sortby='.$newsort.'&scroll='.$scroll,
      $filename.'?op=showitems&itemclass='.$_GET['itemclass'].'&sorttable=items&sort=value2&sortby='.$newsort.'&scroll='.$scroll,
      $filename.'?op=showitems&itemclass='.$_GET['itemclass'].'&sorttable=itemtransfer&sort=gold&sortby='.$newsort.'&scroll='.$scroll,
      $filename.'?op=showitems&itemclass='.$_GET['itemclass'].'&sorttable=itemtransfer&sort=gems&sortby='.$newsort.'&scroll='.$scroll,
      $filename.'?op=showitems&itemclass='.$_GET['itemclass'].'&sorttable=itemtransfer&sort=entrydate&sortby='.$newsort.'&scroll='.$scroll,
    );
    // Und dieselbigen nat�rlich erlauben.
    addnav('',$sortlink[0]);
    addnav('',$sortlink[1]);
    addnav('',$sortlink[2]);
    addnav('',$sortlink[3]);
    addnav('',$sortlink[4]);
    addnav('',$sortlink[5]);
    addnav('',$sortlink[6]);

    // Spezifischer Item-Text
    switch($_GET['itemclass'])
    {
      case "moebel":
        output(', bei dem du verschiedene `^M�bel`3 siehst.`0`n`n');

        $angebote = markt_query_items("M�bel",$limit,$start,$orderstring);

        rawoutput('<br /><br /><br /><br /><br />'
          .'<table border="0" cellpadding="2" cellspacing="1" bgcolor="#999999" align="center" width="60%">'
          .'<tr class="trhead">'
            .'<td><a href="'.$sortlink[0].'"><strong>Item</strong></a></td>'
            .'<td><a href="'.$sortlink[1].'"><strong>Angeboten von</strong></a></td>'
            .'<td width="40px"><a href="'.$sortlink[2].'"><strong>Wert 1</strong></a></td>'
            .'<td width="40px"><a href="'.$sortlink[3].'"><strong>Wert 2</strong></a></td>'
            .'<td style="color: #FFFF00;"><a href="'.$sortlink[4].'"><strong>Goldpreis</strong></a></td>'
            .'<td style="color: #FF00FF;"><a href="'.$sortlink[5].'"><strong>Edelsteinpreis</strong></a></td>'
            .'<td><a href="'.$sortlink[6].'"><strong>Eingegangen am</strong></a></td>'
            .'<td><strong>Optionen</strong></td>'
          .'</tr>');

        if($angebote['rows'] == 0)
        {
          rawoutput('<tr class="trdark"><td colspan="8"><i>Keine Items vorhanden</i></td></tr>');
        }
        else
        {
          $i = 0;

          while($row = db_fetch_assoc($angebote['result']))
          {
            $class = ($i%2?"trdark":"trlight");

            $formlinks = array(
              $filename.'?op=buy&itemclass='.$_GET['itemclass'].'&item='.$row['itemid'],
              $filename.'?op=superuserdrop&itemclass='.$_GET['itemclass'].'&item='.$row['itemid'],
            );

            if($row['seller'] != ACCTID) addnav('',$formlinks[0]);
            if(MARKT_ADMIN) addnav('',$formlinks[1]);

            rawoutput('<tr class="'.$class.'">'
                .'<td>'.$row['name'].'</td>'
                .'<td>'.yeoldemail($row['ownerlogin'],true).appoencode($row['ownername'].'`0',false).'</td>'
                .'<td style="color: #FFFFFF;">'.$row['value1'].'</td>'
                .'<td style="color: #FFFFFF;">'.$row['value2'].'</td>'
                .'<td style="color: #FFFF00;">'.$row['gold'].'</td>'
                .'<td style="color: #FF00FF;">'.$row['gems'].'</td>'
                .'<td>'.date('d.m-Y h:i',strtotime($row['entrydate'])).'</td>'
                .'<td>'
                  .($row['seller'] == ACCTID?'':'<a href="'.$formlinks[0].'"><span style="color: #00bb00;">[ Kaufen ]</span></a><br />')
                  .(MARKT_ADMIN?'<a href="'.$formlinks[1].'"><span style="color: #bb0000;">[ Del ]</span></a>':'')
                .'</td>'
              .'</tr>'
              .'<tr class="'.$class.'">'
                .'<td colspan="8"><i>'.appoencode($row['description'].'`0',false).'</i></td>'
              .'</tr>');
            $i++;
          }
        }
        rawoutput("</table>");
        
        $total = $angebote['count'];
        if($total > $limit)
        {
          for ($i=0;$i<$total;$i+=$limit)
          {
            $pagenum = ($i/$limit);
            $pagelink = $filename.'?op=showitems&itemclass='.$_GET['itemclass'].'&scroll='.($pagenum);
            $pagename = 'Seite '.($pagenum+1).' ('.($i+1).' - '.min($i+$limit,$total).')';
            addnav($pagename,$pagelink);
          }
        }
        break;

      ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        
      case "schmuck":
        output(', bei dem du die sch�nsten `^Schmuckst�cke`3 siehst, die du jemals gesehen hast.`0`n`n');

        $angebote = markt_query_items("Schmuck",$limit,$start,$orderstring);

        rawoutput('<br /><br /><br /><br /><br />'
          .'<table border="0" cellpadding="2" cellspacing="1" bgcolor="#999999" align="center" width="60%">'
          .'<tr class="trhead">'
            .'<td><a href="'.$sortlink[0].'"><strong>Item</strong></a></td>'
            .'<td><a href="'.$sortlink[1].'"><strong>Angeboten von</strong></a></td>'
            .'<td width="40px"><a href="'.$sortlink[2].'"><strong>Wert 1</strong></a></td>'
            .'<td width="40px"><a href="'.$sortlink[3].'"><strong>Wert 2</strong></a></td>'
            .'<td style="color: #FFFF00;"><a href="'.$sortlink[4].'"><strong>Goldpreis</strong></a></td>'
            .'<td style="color: #FF00FF;"><a href="'.$sortlink[5].'"><strong>Edelsteinpreis</strong></a></td>'
            .'<td><a href="'.$sortlink[6].'"><strong>Eingegangen am</strong></a></td>'
            .'<td><strong>Optionen</strong></td>'
          .'</tr>');

        if($angebote['rows'] == 0)
        {
          rawoutput('<tr class="trdark"><td colspan="8"><i>Keine Items vorhanden</i></td></tr>');
        }
        else
        {
          $i = 0;

          while($row = db_fetch_assoc($angebote['result']))
          {
            $class = ($i%2?"trdark":"trlight");

            $formlinks = array(
              $filename.'?op=buy&itemclass='.$_GET['itemclass'].'&item='.$row['itemid'],
              $filename.'?op=superuserdrop&itemclass='.$_GET['itemclass'].'&item='.$row['itemid'],
            );

            if($row['seller'] != ACCTID) addnav('',$formlinks[0]);
            if(MARKT_ADMIN) addnav('',$formlinks[1]);

            rawoutput('<tr class="'.$class.'">'
                .'<td>'.$row['name'].'</td>'
                .'<td>'.yeoldemail($row['ownerlogin'],true).appoencode($row['ownername'].'`0',false).'</td>'
                .'<td style="color: #FFFFFF;">'.$row['value1'].'</td>'
                .'<td style="color: #FFFFFF;">'.$row['value2'].'</td>'
                .'<td style="color: #FFFF00;">'.$row['gold'].'</td>'
                .'<td style="color: #FF00FF;">'.$row['gems'].'</td>'
                .'<td>'.date('d.m-Y h:i',strtotime($row['entrydate'])).'</td>'
                .'<td>'
                  .($row['seller'] == ACCTID?'':'<a href="'.$formlinks[0].'"><span style="color: #00bb00;">[ Kaufen ]</span></a><br />')
                  .(MARKT_ADMIN?'<a href="'.$formlinks[1].'"><span style="color: #bb0000;">[ Del ]</span></a>':'')
                .'</td>'
              .'</tr>'
              .'<tr class="'.$class.'">'
                .'<td colspan="8"><i>'.appoencode($row['description'].'`0',false).'</i></td>'
              .'</tr>');
            $i++;
          }
        }
        rawoutput("</table>");

        $total = $angebote['count'];
        if($total > $limit)
        {
          for ($i=0;$i<$total;$i+=$limit)
          {
            $pagenum = ($i/$limit);
            $pagelink = $filename.'?op=showitems&itemclass='.$_GET['itemclass'].'&scroll='.($pagenum);
            $pagename = 'Seite '.($pagenum+1).' ('.($i+1).' - '.min($i+$limit,$total).')';
            addnav($pagename,$pagelink);
          }
        }
        break;
        
      ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      case "beute":
        output(', bei dem du die verschiedene, von Waldkreaturen erbeutenen Gegenst�nde siehst.`0`n`n');

        $angebote = markt_query_items("Beute",$limit,$start,$orderstring);

        rawoutput('<br /><br /><br /><br /><br />'
          .'<table border="0" cellpadding="2" cellspacing="1" bgcolor="#999999" align="center" width="60%">'
          .'<tr class="trhead">'
            .'<td><a href="'.$sortlink[0].'"><strong>Item</strong></a></td>'
            .'<td><a href="'.$sortlink[1].'"><strong>Angeboten von</strong></a></td>'
            .'<td width="40px"><a href="'.$sortlink[2].'"><strong>Wert 1</strong></a></td>'
            .'<td width="40px"><a href="'.$sortlink[3].'"><strong>Wert 2</strong></a></td>'
            .'<td style="color: #FFFF00;"><a href="'.$sortlink[4].'"><strong>Goldpreis</strong></a></td>'
            .'<td style="color: #FF00FF;"><a href="'.$sortlink[5].'"><strong>Edelsteinpreis</strong></a></td>'
            .'<td><a href="'.$sortlink[6].'"><strong>Eingegangen am</strong></a></td>'
            .'<td><strong>Optionen</strong></td>'
          .'</tr>');

        if($angebote['rows'] == 0)
        {
          rawoutput('<tr class="trdark"><td colspan="8"><i>Keine Items vorhanden</i></td></tr>');
        }
        else
        {
          $i = 0;

          while($row = db_fetch_assoc($angebote['result']))
          {
            $class = ($i%2?"trdark":"trlight");

            $formlinks = array(
              $filename.'?op=buy&itemclass='.$_GET['itemclass'].'&item='.$row['itemid'],
              $filename.'?op=superuserdrop&itemclass='.$_GET['itemclass'].'&item='.$row['itemid'],
            );

            if($row['seller'] != ACCTID) addnav('',$formlinks[0]);
            if(MARKT_ADMIN) addnav('',$formlinks[1]);

            rawoutput('<tr class="'.$class.'">'
                .'<td>'.$row['name'].'</td>'
                .'<td>'.yeoldemail($row['ownerlogin'],true).appoencode($row['ownername'].'`0',false).'</td>'
                .'<td style="color: #FFFFFF;">'.$row['value1'].'</td>'
                .'<td style="color: #FFFFFF;">'.$row['value2'].'</td>'
                .'<td style="color: #FFFF00;">'.$row['gold'].'</td>'
                .'<td style="color: #FF00FF;">'.$row['gems'].'</td>'
                .'<td>'.date('d.m-Y h:i',strtotime($row['entrydate'])).'</td>'
                .'<td>'
                  .($row['seller'] == ACCTID?'':'<a href="'.$formlinks[0].'"><span style="color: #00bb00;">[ Kaufen ]</span></a><br />')
                  .(MARKT_ADMIN?'<a href="'.$formlinks[1].'"><span style="color: #bb0000;">[ Del ]</span></a>':'')
                .'</td>'
              .'</tr>'
              .'<tr class="'.$class.'">'
                .'<td colspan="8"><i>'.appoencode($row['description'].'`0',false).'</i></td>'
              .'</tr>');
            $i++;
          }
        }
        rawoutput("</table>");

        $total = $angebote['count'];
        if($total > $limit)
        {
          for ($i=0;$i<$total;$i+=$limit)
          {
            $pagenum = ($i/$limit);
            $pagelink = $filename.'?op=showitems&itemclass='.$_GET['itemclass'].'&scroll='.($pagenum);
            $pagename = 'Seite '.($pagenum+1).' ('.($i+1).' - '.min($i+$limit,$total).')';
            addnav($pagename,$pagelink);
          }
        }
        break;
    }
    
?>
