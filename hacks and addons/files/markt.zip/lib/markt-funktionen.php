<?php


// array markt_query_items(string itemclass [,int limit [,int start[, string sortby]]])
function markt_query_items($class,$limit = 5,$start = 0,$orderby = 'ORDER BY `itemtransfer`.`entrydate` DESC ')
{
  $sql = 'SELECT `itemtransfer`.*, '
    .'`items`.`name`, '
    .'`items`.`class`, '
    .'`items`.`value1`, '
    .'`items`.`value2`, '
    .'`items`.`hvalue`, '
    .'`items`.`description`, '
    .'`accounts`.`name` AS "ownername", '
    .'`accounts`.`login` AS "ownerlogin" '
    
    .'FROM `itemtransfer` '
    
    .'INNER JOIN `accounts` '
    .'ON `accounts`.`acctid` = `itemtransfer`.`seller` '
    
    .'LEFT JOIN `items` '
    .'ON `items`.`id` = `itemtransfer`.`itemid` '
    
    .'WHERE `items`.`class` LIKE "'.addslashes(stripslashes($class)).'" '
    .'AND `accounts`.`locked` = "0" '
    .'AND `itemtransfer`.`buyer` = "0" '
    .$orderby.' '
    .'LIMIT '.$start.','.$limit.'';
    
  $result = db_query($sql);
  $rows = db_num_rows($result);
  
  $sql2 = 'SELECT count(`itemtransfer`.`itemid`) AS "count" '

    .'FROM `itemtransfer` '

    .'INNER JOIN `accounts` '
    .'ON `accounts`.`acctid` = `itemtransfer`.`seller` '

    .'LEFT JOIN `items` '
    .'ON `items`.`id` = `itemtransfer`.`itemid` '

    .'WHERE `items`.`class` LIKE "'.addslashes(stripslashes($class)).'" '
    .'AND `accounts`.`locked` = "0" '
    .'AND `itemtransfer`.`buyer` = "0" '
    .$orderby.' ';
  $row2 = db_fetch_assoc(db_query($sql2));
  
  
  return array("result"=>$result,"rows"=>$rows,"sql"=>$sql,'count'=>$row2['count']);
}

// array markt_select_item(int itemid)
function markt_select_item($itemid)
{
  $sql = 'SELECT `itemtransfer`.*, '
    .'`items`.`name`, '
    .'`items`.`class`, '
    .'`items`.`value1`, '
    .'`items`.`value2`, '
    .'`items`.`hvalue`, '
    .'`items`.`description`, '
    .'`accounts`.`name` AS "ownername", '
    .'`accounts`.`login` AS "ownerlogin" '

    .'FROM `itemtransfer` '

    .'INNER JOIN `accounts` '
    .'ON `accounts`.`acctid` = `itemtransfer`.`seller` '

    .'LEFT JOIN `items` '
    .'ON `items`.`id` = `itemtransfer`.`itemid` '

    .'WHERE `itemtransfer`.`itemid` = "'.addslashes(stripslashes($itemid)).'" '
    .'AND `accounts`.`locked` = "0" '
    .'AND `itemtransfer`.`buyer` = "0" '
    .'LIMIT 1';

  $result = db_query($sql);
  $rows = db_num_rows($result);
  
  // Wenn wer schneller war "false" zur�ck geben, damit man auf einen Fehler pr�fen kann.
  if($rows === 0)
    return false;
  else
    return array('result'=>$result,'rows'=>$rows,'sql'=>$sql,'row'=>db_fetch_assoc($result));
}

// bool markt_update_item(int itemid)
function markt_update_item($itemid)
{
  $sql = 'UPDATE `items` SET '
    .'`owner` = "'.ACCTID.'" '
    .'WHERE owner = 0 '
    .'AND `id` = "'.$itemid.'"';

  $result = db_query($sql);
  
  $return = false;
  
  if(db_affected_rows() == 1)
  {
    db_query('UPDATE `itemtransfer` SET `buyer` = "'.ACCTID.'" WHERE `itemid` = "'.$itemid.'"');
    $return = true;
  }
  
  return $return;
}

// array markt_select_useritems(string itemclass [,int limit [,int start[, string sortby]]])
function markt_select_useritems($class,$limit = 5,$start = 0,$orderby = 'ORDER BY `name` DESC ')
{
  $sql = 'SELECT * '
    .'FROM `items` '

    .'WHERE `owner` = "'.ACCTID.'" '
    .'AND `class` = "'.$class.'" '
    .$orderby.' '
    .'LIMIT '.$start.','.$limit.'';

  $result = db_query($sql);
  $rows = db_num_rows($result);

  return array("result"=>$result,"rows"=>$rows,"sql"=>$sql);
}

function markt_select_useritem_byid($itemid)
{
  $sql = 'SELECT * '
    .'FROM `items` '

    .'WHERE `owner` = "'.ACCTID.'" '
    .'AND `id` = "'.$itemid.'" '
    
    .'LIMIT 1';

  $result = db_query($sql);
  $rows = db_num_rows($result);
  
  return array('result'=>$result,'rows'=>$rows,'sql'=>$sql,'row'=>db_fetch_assoc($result));
}

function markt_insert_useritem($itemid,$injection)
{
  $sql = 'UPDATE `items` '
    .'SET `owner` = 0 '
    .$injection
    .'WHERE `id` = "'.$itemid.'" '
    .'AND `owner` = "'.ACCTID.'" ';
    
  db_query($sql);
  $affected = db_affected_rows();
  
  $sql = 'INSERT INTO `itemtransfer` '
    .'(`itemid`,`seller`,`gold`,`gems`,`entrydate`) VALUES'
    .'("'.$itemid.'","'.ACCTID.'","'.GOLD.'","'.GEMS.'",NOW())';
  
  db_query($sql);

  return $affected;
}

function markt_query_selleditems()
{
  $sql = 'SELECT `itemtransfer`.*, '
    .'`items`.`name`, '
    .'`items`.`class`, '
    .'`items`.`value1`, '
    .'`items`.`value2`, '
    .'`items`.`hvalue`, '
    .'`items`.`description`, '
    .'`accounts`.`name` AS "buyername", '
    .'`accounts`.`login` AS "buyerlogin" '

    .'FROM `itemtransfer` '

    .'INNER JOIN `accounts` '
    .'ON `accounts`.`acctid` = `itemtransfer`.`buyer` '

    .'LEFT JOIN `items` '
    .'ON `items`.`id` = `itemtransfer`.`itemid` '

    .'WHERE `itemtransfer`.`buyer` > "0" '
    .'AND `accounts`.`locked` = "0" '
    .'AND `itemtransfer`.`seller` = "'.ACCTID.'" ';

  $result = db_query($sql);
  $rows = db_num_rows($result);
  
  return array('result'=>$result,'rows'=>$rows,'sql'=>$sql);
}

function markt_delete_selleditem($itemid)
{
  $sql = 'DELETE FROM `itemtransfer` '
    .'WHERE `itemid` = "'.$itemid.'" '
    .'AND `seller` = "'.ACCTID.'"';

  db_query($sql);
  return $sql;
}

?>
