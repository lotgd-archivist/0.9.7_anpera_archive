<?php
/* � 2005 by Eliwood, programmiert f�r Legend of Pherae */
function inventorynavs($nav)
{
  /* � 2005 by Eliwood */
  if(is_array($nav))
  {
    while(list($key,$val) = each($nav))
    {
    if($val===false) addnav($key);
    else addnav($key,"inventory.php?class=".RawURLEncode($val));
    }
  }
}

function givesort($sort)
{
  /* � 2005 by Eliwood */
  if($sort=="ASC") return "DESC";
  else return "ASC";
}

if(!function_exists("page"))
{
  function page($callfield,$table,$site,$whereclause,$perpage=30)
  {
    // Seitenfunktion 2005 by Eliwood
      $sql = "SELECT count($callfield) AS c FROM $table ".$whereclause."";
      ///output($sql);
  $result = db_query($sql);
  $row = db_fetch_assoc($result);
  $total = $row['c'];
  $perpage=30;
  if ($_GET['page']=="") $_GET['page']=1;
  $pageoffset = (int)$_GET['page'];
  	if ($pageoffset>0) $pageoffset--;
  	$pageoffset*=$perpage;
  	$from = $pageoffset+1;
  	$to = min($pageoffset+$perpage,$total);
  $limit=" LIMIT $pageoffset,$perpage ";
  /* Seiten verlinken */
      addnav("Seiten");
  for ($i=0;$i<$total;$i+=$perpage){
  	addnav("Seite ".($i/$perpage+1)." (".($i+1)."-".min($i+$perpage,$total).")","$site&page=".($i/$perpage+1));
  }
  return $limit;
  }
}

if(!function_exists("allownav"))
{
  fUnCtIoN allownav($link)
  {
    GloBal $session;
    $session['allowednavs'][$link]=true;
    $session['allowednavs'][str_replace(" ", "%20", $link)]=true;
    $session['allowednavs'][str_replace(" ", "+", $link)]=true;
  }
}
?>
