<?php

// 24072004

require_once "common.php";

/***************
 **  SETTINGS **
 ***************/
$turnsperday = getsetting("turns",10);
$maxinterest = ((float)getsetting("maxinterest",10)/100) + 1; //1.1;
$mininterest = ((float)getsetting("mininterest",1)/100) + 1; //1.1;
//$mininterest = 1.01;
$dailypvpfights = getsetting("pvpday",3);

if ($_GET['resurrection']=="true") {
	$resline = "&resurrection=true";
} else if ($_GET['resurrection']=="egg") {
	$resline = "&resurrection=egg";
} else {
	$resline = "";
}

// $resline = $_GET['resurrection']=="true" ? "&resurrection=true" : "" ;
/******************
 ** End Settings **
 ******************/
if (count($session['user']['dragonpoints']) <$session['user']['dragonkills']&&$_GET['dk']!=""){
	array_push($session['user']['dragonpoints'],$_GET[dk]);
	switch($_GET['dk']){
	case "hp":
		$session['user']['maxhitpoints']+=5;
		break;
	case "at":
		$session['user']['attack']++;
		break;
	case "de":
		$session['user']['defence']++;
		break;	
	}
}
if (count($session['user']['dragonpoints'])<$session['user']['dragonkills'] && $_GET['dk']!="ignore"){
	page_header("Drachenpunkte");
	addnav("Max Lebenspunkte +5","newday.php?dk=hp$resline");
	addnav("Waldk�mpfe +1","newday.php?dk=ff$resline");
	addnav("Angriff + 1","newday.php?dk=at$resline");
	addnav("Verteidigung + 1","newday.php?dk=de$resline");
	//addnav("Ignore (Dragon Points are bugged atm)","newday.php?dk=ignore$resline");
	output("`@Du hast noch `^".($session['user']['dragonkills']-count($session['user']['dragonpoints']))."`@  Drachenpunkte �brig. Wie willst du sie einsetzen?`n`n");
	output("Du bekommst 1 Drachenpunkt pro get�tetem Drachen. Die �nderungen der Eigenschaften durch Drachenpunkte sind permanent.");
	/* Gesinnung by Horus */


}else if ((int)$session['user']['gesinnung']==0){
if ($HTTP_GET_VARS['setgesinnung']===NULL){

		addnav("","newday.php?setgesinnung=1$resline");
		addnav("","newday.php?setgesinnung=2$resline");
		addnav("","newday.php?setgesinnung=3$resline");

page_header("Deine Gesinnung");

output("Zwischen Gut und B�se herrscht schon seit langer Zeit Krieg. Aber welcher Gesinnung geh�rst `$ du`0 an?`n`n");


output("<a href='newday.php?setgesinnung=1$resline'>Du bist Gut</a>`n",true);

output("<a href='newday.php?setgesinnung=2$resline'>Du bist Neutral</a>`n",true);

output("<a href='newday.php?setgesinnung=3$resline'>Du bist B�se</a>`n",true);


addnav("Gut","newday.php?setgesinnung=1$resline");
addnav("Neutral","newday.php?setgesinnung=2$resline");
addnav("B�se","newday.php?setgesinnung=3$resline");


}


else


{


addnav("Weiter","newday.php?continue=1$resline");
		switch($HTTP_GET_VARS['setgesinnung']){




case 1:

			  page_header("Gut");

output("`2Du streifst mit der Gesinnung `bGut`b durch die Welt. du versuchst immer wieder das Richtige zutun, wobei du immer versuchst dem B�sen entgegen zusehen.");
				


				break;

case 2:

			  page_header("Neutral");

output("`7Du streifst mit der Gesinnung `bNeutral`b durch die Welt. Du entscheidest dich weder f�r die Gute noch f�r die B�se Seite. Du handelst so wie du es f�r richtig h�lst.");
				


				break;


case 3:

			  page_header("B�se");

output("`$ Du streifst mit der Gesinnung `bB�se`b durch die Welt. Du versuchst das Gute f�r immer aus zul�schen. Du trotzt vor nichts zur�ck. Das einzige was du willst ist Chaos.");
				


				break;

}
		$session['user']['gesinnung']=$HTTP_GET_VARS['setgesinnung'];
	}
}else if (!$session['user']['race'] || $session['user']['race']=="Unbekannt"|| $session['user']['race']=="0") 
{
     page_header("Ein wenig �ber deine Vorgeschichte"); 
     $sql = "SELECT * FROM race WHERE raceid='{$_GET['setrace']}' LIMIT 1"; 
     $result = db_query($sql); 
     $row = db_fetch_assoc($result); 
     if ($_GET['setrace']!="") 
     { 
          $session['user']['race'] = ($row['color'].$row['name']); 
          switch($_GET['setrace']) 
          { 
               case $row['raceid']: 
               output("{$row['story']}"); 
               $bonus = unserialize($row['bonus']); 
               $session['user']['maxhitpoints']+=(int)$bonus['lp']; 
               $session['user']['defence']+=(int)$bonus['def']; 
               $session['user']['attack']+=(int)$bonus['atk']; 
               break; 
          } 
          if ($session['user']['weaponvalue']<0) 
          $session['user']['attack']+=$session['user']['weapondmg']; 
          if ($session['user']['armorvalue']<0) 
          $session['user']['defence']+=$session['user']['armordef']; 
          addnav("Weiter","newday.php?continue=1$resline"); 
          if ($session['user']['dragonkills']==0 && $session['user']['level']==1) 
          { 
               addnews("`#{$session[user][name]} `#hat unsere Welt betreten. Willkommen!"); 
          } 
     } 
     else 
     { 
          if (!$session['user']['superuser']) 
          $sql = "SELECT * FROM race WHERE dk<='{$session['user']['dragonkills']}' AND active=1 ORDER BY category,name,raceid";   else 
          $sql = "SELECT * FROM race WHERE dk<='{$session['user']['dragonkills']}' ORDER BY category,name,raceid"; 
          $result = db_query($sql); 
          $category = ""; 
          while ($row = db_fetch_assoc($result)) 
          { 
               if ($category!=$row['category']) 
               { 
                    addnav($row['category']); 
                    $category = $row['category']; 
               } 
               $link = "newday.php?setrace={$row['raceid']}$resline"; 
               addnav("{$row['color']} {$row['name']}",$link); 
               output("<a href=\"$link\">".$row['link']."</a>`n`n",true); 
               addnav("",$link); 
          } 
     }
  }else if ((int)$session['user']['specialty']==0){
  if ($HTTP_GET_VARS['setspecialty']===NULL){
		addnav("","newday.php?setspecialty=1$resline");
		addnav("","newday.php?setspecialty=2$resline");
		addnav("","newday.php?setspecialty=3$resline");
		page_header("Ein wenig �ber deine Vorgeschichte");
		
		output("Du erinnerst dich, dass du als Kind:`n`n");
		output("<a href='newday.php?setspecialty=1$resline'>viele Kreaturen des Waldes get�tet hast (`\$Dunkle K�nste`0)</a>`n",true);
		output("<a href='newday.php?setspecialty=2$resline'>mit mystischen Kr�ften experimentiert hast (`%Mystische Kr�fte`0)</a>`n",true);
		output("<a href='newday.php?setspecialty=3$resline'>von den Reichen gestohlen und es dir selbst gegeben hast (`^Diebeskunst`0)</a>`n",true);
		addnav("`\$Dunkle K�nste","newday.php?setspecialty=1$resline");
		addnav("`%Mystische Kr�fte","newday.php?setspecialty=2$resline");
		addnav("`^Diebesk�nste","newday.php?setspecialty=3$resline");
  }else{
	  addnav("Weiter","newday.php?continue=1$resline");
		switch($HTTP_GET_VARS['setspecialty']){
		  case 1:
			  page_header("Dunkle K�nste");
				output("`5Du erinnerst dich, dass du damit aufgewachsen bist, viele kleine Waldkreaturen zu t�ten, weil du davon �berzeugt warst, sie haben sich gegen dich verschworen. ");
				output("Deine Eltern haben dir einen idiotischen Zweig gekauft, weil sie besorgt dar�ber waren, dass du die Kreaturen des Waldes mit blo�en H�nden t�ten musst. ");
				output("Noch vor deinem Teenageralter hast du damit begonnen, finstere Rituale mit und an den Kreaturen durchzuf�hren, wobei du am Ende oft tagelang im Wald verschwunden bist. ");
				output("Niemand au�er dir wusste damals wirklich, was die Ursache f�r die seltsamen Ger�usche aus dem Wald war...");
				break;
			case 2:
			  page_header("Mystische Kr�fte");
				output("`3Du hast schon als Kind gewusst, dass diese Welt mehr als das Physische bietet, woran du herumspielen konntest. ");
				output("Du hast erkannt, dass du mit etwas Training deinen Geist selbst in eine Waffe verwandeln kannst. ");
				output("Mit der Zeit hast du gelernt, die Gedanken kleiner Kreaturen zu kontrollieren und ihnen deinen Willen aufzuzwingen. ");
				output("Du bist auch auf die mystische Kraft namens Mana gestossen, die du in die Form von Feuer, Wasser, Eis, Erde, Wind bringen und sogar als Waffe gegen deine Feinde einsetzen kannst.");
				break;
			case 3:
			  page_header("Diebesk�nste");
				output("`6Du hast schon sehr fr�h bemerkt, dass ein gew�hnlicher Rempler im Gedr�nge dir das Gold eines vom Gl�ck bevorzugteren Menschen einbringen kann. ");
				output("Au�erdem hast du entdeckt, dass der R�cken deiner Feinde anf�lliger gegen kleine Klingen ist, als deren Vorderseite gegen m�chtige Waffen.");
				break;
		}
		$session['user']['specialty']=$HTTP_GET_VARS['setspecialty'];
	}
}//Anfang Klasse ausw�hlen
		else if ((int)$session['user']['admin']==0){{
	page_header("W�hle eine Klasse");
	if ($_GET['setadmin']!=""){
		$session['user']['admin']=(int)($_GET['setadmin']);
		switch($_GET['setadmin']){
			case "1":
			output("`i`b`c`9RP`3G-`#C`3ha`9ra`0`i`b`c`n");
			output("Diese Chara's haben keinen Wald und sind ausschlieslich am RPG interessiert.`0");
			break;
			case "2":
			output("`i`b`c`lMi`4x-`\$C`4ha`lra`0`i`b`c`n");
			output("Diese Chara's k�nnen in den Wald k�mpfen und sind auch am RPG interessiert, doch haben diese gewisse Einschr�nkungen.`0");
			break;
			case "3":
			output("`i`b`c`kLe`qve`2l-C`gha`kra`0`i`b`c`n");
			output("Diese Charas Leveln ausschlieslich und sind �berhaupt nicht am RPG interessiert.");
	    break;
	    case "4":
			output("`i`b`c`\$Spezielle-Chara`0`i`b`c`n");
			output("Diese Charaktere sind nur von Admins vergebbar, da sie RPG und Level ohne Einschr�nkungen nutzen k�nnen und somit anderen gegen�ber einen Vorteil haben.");
	    break;
        }		
}
else{
		output("Was ist deine Klasse?`n`n");
		output("<a href='newday.php?setadmin=1$resline'>`9RP`3G-`#C`3ha`9ra`0 sind Accounts die nur f�r das RPG da sind und nicht Leveln k�nnen.</a>`n`n",true);
		output("<a href='newday.php?setadmin=2$resline'>`lMi`4x-`\$C`4ha`lra`0 sind Accounts die Leveln und RPG'n k�nnen, aber daf�r eingeschr�nkt.</a>`n`n",true);
		output("<a href='newday.php?setadmin=3$resline'>`kLe`gve`2l-C`gha`kra`0 sind Accounts die nur Leveln und kein RPG machen.</a>`n`n",true);
    if($session['user']['superuser']>=3) output("<a href='newday.php?setadmin=4$resline'>`\$Spezielle-Chara`0 sind Accounts die alles k�nnen, daher werden sie nur von Admin vergeben.</a>`n`n",true);

		addnav("W�hle dein Reich");
		addnav("RPG-Chara","newday.php?setadmin=1$resline");
		addnav("Mix-Chara","newday.php?setadmin=2$resline");
		addnav("Level-Chara","newday.php?setadmin=3$resline");
		if($session['user']['superuser']>=3) addnav("Spezielle-Chara","newday.php?setadmin=4$resline");
		
		addnav("","newday.php?setadmin=1$resline");
		addnav("","newday.php?setadmin=2$resline");
		addnav("","newday.php?setadmin=3$resline");
    if($session['user']['superuser']>=3) addnav("","newday.php?setadmin=4$resline");  
  }
 }
 
 if($session['user']['admin']>0){
addnav("Weiter","newday.php?continue=1$resline");
		 }
		}else{
  if ($session['user']['slainby']!=""){
		page_header("Du wurdest umgebracht!");
		output("`\$Im ".$session['user']['killedin']." hat dich `%".$session['user']['slainby']."`\$ get�tet und dein Gold genommen. Ausserdem hast du 5% deiner Erfahrungspunkte verloren. Meinst du nicht auch, es ist Zeit f�r Rache?");
		addnav("Weiter","newday.php?continue=1$resline");
	  $session['user']['slainby']="";
	}else{
		page_header("Es ist ein neuer Tag!");
		$interestrate = e_rand($mininterest*100,$maxinterest*100)/(float)100;
		output("`c<font size='+1'>`b`#Es ist ein neuer Tag!`0`b</font>`c",true);
if (!$session['user']['prefs']['nosounds']) output("<embed src=\"media/newday.wav\" width=10 height=10 autostart=true loop=false hidden=true volume=100>",true);

		if ($session['user']['alive']!=true){
			$session['user']['resurrections']++;
			output("`@Du bist wiedererweckt worden! Dies ist der Tag deiner ".ordinal($session['user']['resurrections'])." Wiederauferstehung.`0`n");
			$session['user']['alive']=true;
		}
		$session[user][age]++;
		$session[user][seenmaster]=0;
		output("`c<img src='http://www.shibaya-logd.de/Lacroya/images/tag.jpg'>`c`n`n",true);
		output("Du �ffnest deine Augen und stellst fest, dass dir ein neuer Tag geschenkt wurde. Dies ist dein `^".ordinal($session['user']['age'])."`0 Tag in diesem Land. ");
		output("Du f�hlst dich frisch und bereit f�r die Welt!`n");
		output("`2Runden f�r den heutigen Tag: `^$turnsperday`n");


		if ($session[user][goldinbank]<0 && abs($session[user][goldinbank])<(int)getsetting("maxinbank",10000)){
			output("`2Heutiger Zinssatz: `^".(($interestrate-1)*100)."% `n");
			output("`2Zinsen f�r Schulden: `^".-(int)($session['user']['goldinbank']*($interestrate-1))."`2 Gold.`n");
		}else if ($session[user][goldinbank]<0 && abs($session[user][goldinbank])>=(int)getsetting("maxinbank",10000)){
			output("`4Die Bank erl�sst dir deine Zinsen, da du schon hoch genug verschuldet bist.`n");
			$interestrate=1;
		}else if ($session[user][goldinbank]>=0 && $session[user][goldinbank]>=(int)getsetting("maxinbank",10000) && $session['user']['turns']<=getsetting("fightsforinterest",4)){
			$interestrate=1;
			output("`4Die Bank kann dir heute keinen Zinsen zahlen. Sie w�rde fr�her oder sp�ter an dir pleite gehen.`n");
		}else if ($session[user][goldinbank]>=0 && $session[user][goldinbank]<(int)getsetting("maxinbank",10000) && $session['user']['turns']<=getsetting("fightsforinterest",4)){
			output("`2Heutiger Zinssatz: `^".(($interestrate-1)*100)."% `n");
			output("`2Durch Zinsen verdientes Gold: `^".(int)($session['user']['goldinbank']*($interestrate-1))."`n");
		}else{
			$interestrate=1;
			output("`2Dein heutiger Zinssatz betr�gt `^0% (Die Bank gibt nur den Leuten Zinsen, die daf�r arbeiten)`n");
		}


/*
		if ($session['user']['turns']>getsetting("fightsforinterest",4) && $session['user']['goldinbank']>=0) {
			$interestrate=1;
			output("`2Today's interest rate: `^0% (Bankers in this village only give interest to those who work for it)`n");
		}else{
			output("`2Today's interest rate: `^".(($interestrate-1)*100)."% `n");
			if (abs($session['user']['goldinbank'])>(int)getsetting("maxinbank",10000)){
				 if ($session['user']['goldinbank']>=0 ){
					output("`4Die Bank kann dir heute keinen Zinsen zahlen. Sie w�rde fr�her oder sp�ter an dir pleite gehen.`n");
				}else{
					output("`4Die Bank erl�sst dir deine Zinsen, da du schon hoch genug verschuldet bist.`n");
				}
				$interestrate=1;
			}else if ($session['user']['goldinbank']>=0 ){
				output("`2Gold earned from interest: `^".(int)($session['user']['goldinbank']*($interestrate-1))."`n");
			}else{
				output("`2Zinsen f�r Schulden: `^".-(int)($session['user']['goldinbank']*($interestrate-1))."`2 Gold.`n");
			}
		}
*/
		output("`2Deine Gesundheit wurde wiederhergestellt auf `^".$session['user']['maxhitpoints']."`n");
		$skills = array(1=>"Dunkle K�nste","Mystische Kr�fte","Diebesk�nste");
		$sb = getsetting("specialtybonus",1);
		output("`2F�r dein Spezialgebiet `&".$skills[$session['user']['specialty']]."`2, erh�ltst du zus�tzlich $sb Anwendung(en) in `&".$skills[$session['user']['specialty']]."`2 f�r heute.`n");
		$session['user']['darkartuses'] = (int)($session['user']['darkarts']/3) + ($session['user']['specialty']==1?$sb:0);
		$session['user']['magicuses'] = (int)($session['user']['magic']/3) + ($session['user']['specialty']==2?$sb:0);
		$session['user']['thieveryuses'] = (int)($session['user']['thievery']/3) + ($session['user']['specialty']==3?$sb:0);
		//$session['user']['bufflist']=array(); // with this here, buffs are always wiped, so the preserve stuff fails!
		if ($session['user']['marriedto']==4294967295 || $session['user']['charisma']==4294967295){
			output("`n`%Du bist verheiratet, es gibt also keinen Grund mehr, das perfekte Image aufrecht zu halten. Du l�sst dich heute ein bisschen gehen.`n Du verlierst einen Charmepunkt.`n");
			$session['user']['charm']--;
			if ($session['user']['charm']<=0){
				output("`n`bAls du heute aufwachst, findest du folgende Notiz neben dir im Bett:`n`5".($session[user][sex]?"Liebste":"Liebster")."");
				output("".$session['user']['name']."`5.");
				output("`nTrotz vieler gro�artiger K�sse, f�hle ich mich einfach nicht mehr so zu dir hingezogen wie es fr�her war.`n`n");
				output("Nenne mich wankelm�tig, aber ich muss weiterziehen. Es gibt andere Krieger".($session[user][sex]?"innen":"")." in diesem Dorf und ich glaube, ");
				output("einige davon sind wirklich heiss. Es liegt also nicht an dir, sondern an mir, usw. usw.");
  				$sql = "SELECT acctid,name FROM accounts WHERE locked=0 AND acctid=".$session[user][marriedto]."";
  				$result = db_query($sql) or die(db_error(LINK));
				$row = db_fetch_assoc($result);
				$partner=$row[name];
				if ($partner=="") $partner = $session[user][sex]?"Seth":"Violet";
				output("`n`nSei nicht traurig!`nIn Liebe, $partner`b`n");
				addnews("`\$$partner `\$hat {$session['user']['name']}`\$ f�r \"andere Interessen\" verlassen!");
				if ($session['user']['marriedto']==4294967295) $session['user']['marriedto']=0;
				if ($session['user']['charisma']==4294967295){
					 $session['user']['charisma']=0;
					$session['user']['marriedto']=0;
					$sql = "UPDATE accounts SET charisma=0,marriedto=0 WHERE acctid='$row[acctid]'";
					db_query($sql);
					systemmail($row['acctid'],"`\$Wieder solo!`0","`6Du hast `&{$session['user']['name']}`6 verlassen. ".($session[user][sex]?"Sie":"Er")." war einfach widerlich in letzter Zeit.");
				}
			}
		}

		//clear all standard buffs
		$tempbuf = unserialize($session['user']['bufflist']);
		$session['user']['bufflist']="";
		$session['bufflist']=array();
		while(list($key,$val)=@each($tempbuff)){
			if ($val['survivenewday']==1){
				$session['bufflist'][$key]=$val;
				output("{$val['newdaymessage']}`n");
			}
		}

		reset($session['user']['dragonpoints']);
		$dkff=0;
		while(list($key,$val)=each($session['user']['dragonpoints'])){
			if ($val=="ff"){
				$dkff++;
			}
		}
		if ($session[user][hashorse]){
			 $session['bufflist']['mount']=unserialize($playermount['mountbuff']);

		 if ($session['user']['animal']!='') {
			 $session['bufflist']['mount']['name']=$session['user']['animal'].' `&('.$session['bufflist']['mount']['name'].'`&)';
		 }
			
		}

		if ($dkff>0) output("`n`2Du erh�hst deine Waldk�mpfe um `^$dkff`2 durch verteilte Drachenpunkte!"); 
		$r1 = e_rand(-1,1);
		$r2 = e_rand(-1,1);
		$spirits = $r1+$r2;
		if ($_GET['resurrection']=="true"){
			addnews("`&{$session['user']['name']}`& wurde von `\$Ramius`& wiedererweckt.");
			$spirits=-6;
			$session['user']['deathpower']-=100;
			$session['user']['restorepage']="village.php?c=1";
		}
		if ($_GET['resurrection']=="egg"){
			addnews("`&{$session['user']['name']}`& hat das `^goldene Ei`& benutzt und entkam so dem Schattenreich.");
			$spirits=-6;
			//$session['user']['deathpower']-=100;
			$session['user']['restorepage']="village.php?c=1";
			savesetting("hasegg",stripslashes(0));
		}
		$sp = array((-6)=>"Auferstanden",(-2)=>"Sehr schlecht",(-1)=>"Schlecht","0"=>"Normal",1=>"Gut",2=>"Sehr gut");
		output("`n`2Dein Geist und deine Stimmung ist heute `^".$sp[$spirits]."`2!`n");
		if (abs($spirits)>0){
			output("`2Deswegen `^");
			if($spirits>0){
				output("bekommst du zus�tzlich ");
			}else{
				output("verlierst du ");
			}
			output(abs($spirits)." Runden`2 f�r heute.`n");
		}
		$rp = $session['user']['restorepage'];
		$x = max(strrpos("&",$rp),strrpos("?",$rp));
		if ($x>0) $rp = substr($rp,0,$x);
		if (substr($rp,0,10)=="badnav.php"){
			addnav("Weiter","news.php");
		}else{
			addnav("Weiter",preg_replace("'[?&][c][=].+'","",$rp));
		}
		
		$session['user']['laston'] = date("Y-m-d H:i:s");
		$bgold = $session['user']['goldinbank'];
		$session['user']['goldinbank']*=$interestrate;
		$nbgold = $session['user']['goldinbank'] - $bgold;

		if ($nbgold != 0) {
			//debuglog(($nbgold >= 0 ? "earned " : "paid ") . abs($nbgold) . " gold in interest");
		}
		$session['user']['turns']=$turnsperday+$spirits+$dkff;
		if ($session[user][maxhitpoints]<6) $session[user][maxhitpoints]=6;
		$session['user']['hitpoints'] = $session[user][maxhitpoints];
		$session['user']['spirits'] = $spirits;
		$session['user']['playerfights'] = $dailypvpfights;
		$session['user']['transferredtoday'] = 0;
		$session['user']['amountouttoday'] = 0;
		$session['user']['seendragon'] = 0;
		$session['user']['sradsuch'] = 0;
		$session['user']['seenmaster'] = 0;
		$session['user']['girl'] = 0;
		$session['user']['einsatz'] = 10;
		$session['user']['seenlover'] = 0;
		$session['user']['witch'] = 0;
		$session['user']['sanela']['turm']=0;
		$session['user']['sanela']['grotte']=0;
		$session['user']['sanela']['kirche']=0;
		$session['user']['sanela']['sanela']=0;
		$session['user']['sanela']['haganir']=0;
		$session['user']['sanela']['haganirschmiede']=0;
		$session['user']['sanela']['schwimm']=0;
		$session['user']['sanela']['huegel']=0;
		$session['user']['sanela']['strand']=0;
		$session['user']['usedouthouse'] = 0;
		$session['user']['seenAcademy'] = 0;
		$session['user']['gotfreeale'] = 0;
		$session['user']['special_taken']=0;
		$session['user']['fedmount'] = 0;
		$session['user']['deadtreepick']=0;
		if ($_GET['resurrection']!="true" && $_GET['resurrection']!="egg" ){
			$session['user']['soulpoints']=50 + 5 * $session['user']['level'];
			$session['user']['gravefights']=getsetting("gravefightsperday",10);
			$session['user']['reputation']+=5;
		}
		$session['user']['seenbard'] = 0;
		$session['user']['element'] = 0;
		$session['user']['seenminx'] = 0;
		$session['user']['boughtroomtoday'] = 0;
		$session['user']['lottery'] = 0;
		$session['user']['recentcomments']=$session['user']['lasthit'];
		$session['user']['lasthit'] = date("Y-m-d H:i:s");
		if ($session['user']['drunkenness']>66){
		  output("`&Wegen deines schrecklichen Katers wird dir 1 Runde f�r heute abgezogen.");
			$session['user']['turns']--;
		}
		
// following by talisman & JT
//Set global newdaysemaphore

       $lastnewdaysemaphore = convertgametime(strtotime(getsetting("newdaysemaphore","0000-00-00 00:00:00")));
       $gametoday = gametime();
        
        if (date("Ymd",$gametoday)!=date("Ymd",$lastnewdaysemaphore)){
            $sql = "LOCK TABLES settings WRITE";
            db_query($sql);

           $lastnewdaysemaphore = convertgametime(strtotime(getsetting("newdaysemaphore","0000-00-00 00:00:00")));
                                                                                
            $gametoday = gametime();
            if (date("Ymd",$gametoday)!=date("Ymd",$lastnewdaysemaphore)){
                //we need to run the hook, update the setting, and unlock.
                savesetting("newdaysemaphore",date("Y-m-d H:i:s"));
                $sql = "UNLOCK TABLES";
                db_query($sql);
                                                                                
			require_once "setnewday.php";	

            }else{
                //someone else beat us to it, unlock.
                $sql = "UNLOCK TABLES";
                db_query($sql);
				output("Somebody beat us to it");
            }
        }

	output("`nDer Schmerz in deinen wetterf�hligen Knochen sagt dir das heutige Wetter: `6".$settings['weather']."`@.`n");
//Mondphasen by Morpheus
	output("`n`9Am `#Himmel `9sind die `62 Monde`9, `^Teri `9und `^Akaku `9zu sehen. `6Teri `9ist `^".$settings['mond1']."`9, `6Akaku `9ist `^".$settings['mond2']."`9.`n`0");
//Mondphasen Ende
	if ($_GET['resurrection']==""){
		if ($session['user']['specialty']==1 && $settings['weather']=="Regnerisch"){
			output("`^`nDer Regen schl�gt dir aufs Gem�t, aber erweitert deine Dunklen K�nste. Du bekommst eine zus�tzliche Anwendung.`n");
			$session[user][darkartuses]++;
			}	
		if ($session['user']['specialty']==2 and $settings['weather']=="Gewittersturm"){
			output("`^`nDie Blitze f�rdern deine Mystischen Kr�fte. Du bekommst eine zus�tzliche Anwendung.`n");
			$session[user][magicuses]++;
			}	
		if ($session['user']['specialty']==3 and $settings['weather']=="Neblig"){
			output("`^`nDer Nebel bietet Dieben einen zus�tzlichen Vorteil. Du bekommst eine zus�tzliche Anwendung.`n");
			$session[user][thieveryuses]++;
			}		
	}
//End global newdaysemaphore code and weather mod.

		if ($session['user']['hashorse']){
			//$horses=array(1=>"pony","gelding","stallion");
			//output("`n`&You strap your `%".$session['user']['weapon']."`& to your ".$horses[$session['user']['hashorse']]."'s saddlebags and head out for some adventure.`0");
			//output("`n`&Because you have a ".$horses[$session['user']['hashorse']].", you gain ".((int)$session['user']['hashorse'])." forest fights for today!`n`0");
			//$session['user']['turns']+=((int)$session['user']['hashorse']);
			output(str_replace("{weapon}",$session['user']['weapon'],"`n`&{$playermount['newday']}`n`0"));
			if ($playermount['mountforestfights']>0){
				output("`n`&Weil du ein(e/n) {$playermount['mountname']} besitzt, bekommst du `^".((int)$playermount['mountforestfights'])."`& Runden zus�tzlich.`n`0");
				$session['user']['turns']+=(int)$playermount['mountforestfights'];
			}
		}else{
			output("`n`&Du schnallst dein(e/n) `%".$session['user']['weapon']."`& auf den R�cken und ziehst los ins Abenteuer.`0");
		}
	if ($session['user']['prison']) $session['user']['prisondays']--;
		//zus�tzliche Waldk�mpfe & Anwendungen f�r bestimmte Rassen: 
     $sql = "SELECT * FROM race WHERE colorname='".$session['user']['race']."'"; 
     $result = db_query($sql); 
     //print $result; 
     $row = db_fetch_assoc($result); 
     //print_r($row); 
     $bonus = unserialize($row['bonus']); 
     //print_r($bonus); 
     $buff = unserialize($row['buff']);                //  switch{case true: return;continue;break;default} 
     if (is_array($buff)) 
     $session['bufflist']['race'] = $buff; 
     $session['user']['turns'] += $bonus['wk']; 
     if ($bonus['wk']!=0) 
     output("`2`nDa du ein {$session[user][race]}`2 bist,".((int)$bonus['wk']>0 ? " bekommst du zus�tzliche `^".(int)$bonus['wk']."`2 Waldk�mpfe f�r heute.`n" 
     : " verlierst du `^".(int)$bonus['wk']*(-1)."`2 Waldk�mpfe f�r heute.`n").""); 
     // print_r($bonus); 
     $session['user']['darkartuses'] +=((int)$bonus['da']); 
     $session['user']['magicuses'] +=((int)$bonus['mk']);  
     $session['user']['thieveryuses'] +=((int)$bonus['tv']); 
// END
		if ($session['user']['race']==3) {
			$session['user']['turns']++;
			output("`n`&Weil du ein Mensch bist, bekommst du `^1`& Waldkampf zus�tzlich!`n`0");
		}
		$config = unserialize($session['user']['donationconfig']);
		if (!is_array($config['forestfights'])) $config['forestfights']=array();
		reset($config['forestfights']);
		while (list($key,$val)=each($config['forestfights'])){
			$config['forestfights'][$key]['left']--;
			output("`@Du bekommst eine Extrarunde f�r die Punkte auf `^{$val['bought']}`@.");
			$session['user']['turns']++;
			if ($val['left']>1){
				output(" Du hast `^".($val['left']-1)."`@ Tage von diesem Kauf �brig.`n");
			}else{
				unset($config['forestfights'][$key]);
				output(" Dieser Kauf ist damit abgelaufen.`n");
			}
		}
		if ($config['healer'] > 0) {
			$config['healer']--;
			if ($config['healer'] > 0) {
				output("`n`@Golinda ist bereit, dich noch {$config['healer']} weitere Tage zu behandeln.");
			} else {
				output("`n`@Golinda wird dich nicht l�nger behandeln.");
				unset($config['healer']);
			}
		}
		if ($config['goldmineday']>0) $config['goldmineday']=0;
		$session['user']['donationconfig']=serialize($config);
		if ($session['user']['hauntedby']>""){
			output("`n`n`)Du wurdest von {$session['user']['hauntedby']}`) heimgesucht und verlierst eine Runde!");
			$session['user']['turns']--;
			$session['user']['hauntedby']="";
		}
		// Ehre & Ansehen
		if ($session['user']['reputation']<=-50){
			$session['user']['reputation']=-50;
			output("`n`8Da du aufgrund deiner Ehrenlosigkeit h�ufig Steine in den Weg gelegt bekommst, kannst du heute 1 Runden weniger k�mpfen. Au�erdem sind deine Feinde vor dir gewarnt.`nDu solltest dringend etwas f�r deine Ehre tun!");
			$session['user']['turns']--;
			$session['user']['playerfights']--;
		}else if ($session['user']['reputation']<=-30){
			output("`n`8Deine Ehrenlosigkeit hat sich herumgesprochen! Deine Feinde sind vor dir gewarnt, weshalb dir heute 1 Spielerkampf weniger gelingen wird.`nDu solltest dringend etwas f�r deine Ehre tun!");
			$session['user']['playerfights']--;
		}else if ($session['user']['reputation']<-10){
			output("`n`8Da du aufgrund deiner Ehrenlosigkeit h�ufig Steine in den Weg gelegt bekommst, kannst du heute 1 Runde weniger k�mpfen.");
			$session['user']['turns']--;
		}else if ($session['user']['reputation']>=30){
			if ($session['user']['reputation']>50) $session['user']['reputation']=50;
			output("`n`9Da du aufgrund deiner gro�en Ehrenhaftigkeit das Volk auf deiner Seite hast, kannst du heute 1 Runde und 1 Spielerkampf mehr k�mpfen.");
			$session['user']['turns']++;
			$session['user']['playerfights']++;
		}else if ($session['user']['reputation']>10){
			output("`n`9Da du aufgrund deiner gro�en Ehrenhaftigkeit das Volk auf deiner Seite hast, kannst du heute 1 Runde mehr k�mpfen.");
			$session['user']['turns']++;
		}
}if ($session['user']['schuhe']==1){
                        output("`n`9Durch deine Wanderstiefel erh�hlst du `^1 `9Waldkampf mehr.`n`n");
                        $session['user']['turns']++;
                }if ($session['user']['schuhe']==2){
                        output("`n`9Durch deine Sportschuhe erh�hlst du `^2 `9Waldk�mpfe mehr.`n`n");
                        $session['user']['turns']+=2;
                }if ($session['user']['schuhe']==3){
                        output("`n`9Durch deine Lederstiefel erh�hlst du `^2 `9Waldk�mpfe mehr.`n`n");
                        $session['user']['turns']+=3;
                }if ($session['user']['schuhe']==4){
                        output("`n`9Durch deine Drachen Stiefel erh�hlst du `^4 `9Waldk�mpfe mehr.`n`n");
                        $session['user']['turns']+=4;
                }if ($session['user']['armband']==1){
                        if ($session['user']['ause']==1){
                        output("`nDurch dein Goldenes Armband erh�hlst du 1 Verteidigung mehr.`n`n");
                        $session['user']['defence']-=1;
                        $session['user']['defence']+=1;
                        }else{
                        output("`nDurch dein Goldenes Armband erh�hlst du 1 Verteidigung mehr.`n`n");
                        $session['user']['defence']+=1;
                        $session['user']['ause']=1;
                        }
                }if ($session['user']['armband']==2){
                        if ($session['user']['ause']==1){
                        output("`nDurch deine Drachen Armband erh�hlst du 2 Verteidigungspunkte mehr.`n`n");
                        $session['user']['defence']-=2;
                        $session['user']['defence']+=2;
                        }else{
                        output("`nDurch dein Drachen Armband erh�hlst du 2 Verteidigung mehr.`n`n");
                        $session['user']['defence']+=2;
                        $session['user']['ause']=1;
                        }
                }if ($session['user']['klamotten']==1){
                         if ($session['user']['kuse']==1){
                        output("`nDurch dein Weises Kleid erh�hlst du 1 Angriff mehr.`n`n");
                        $session['user']['attack']-=1;
                        $session['user']['attack']+=1;
                        }else{
                        output("`nDurch dein Weises Kleid erh�hlst du 1 Angriff mehr.`n`n");
                        $session['user']['attack']+=1;
                        $session['user']['kuse']=1;
                        }
                }if ($session['user']['klamotten']==2){
                        if ($session['user']['kuse']==1){
                        output("`nDurch dein Drachenleder Kleid erh�hlst du 2 Angriffe mehr.`n`n");
                        $session['user']['attack']-=2;
                        $session['user']['attack']+=2;
                        }else{
                        output("`nDurch dein Drachenleder Kleid erh�hlst du 2 Angriff mehr.`n`n");
                        $session['user']['attack']+=2;
                        $session['user']['kuse']=1;
                        }
                }if ($session['user']['klamotten']==3){
                        if ($session['user']['kuse']==1){
                        output("`nDurch dein Schwarzes Jacket erh�hlst du 1 Angriff mehr.`n`n");
                        $session['user']['attack']-=1;
                        $session['user']['attack']+=1;
                        }else{
                        output("`nDurch dein Schwarzes Jacket erh�hlst du 1 Angriff mehr.`n`n");
                        $session['user']['attack']+=1;
                        $session['user']['kuse']=1;
                        }
                }if ($session['user']['klamotten']==4){
                        if ($session['user']['kuse']==1){
                        output("`nDurch dein Drachenleder Jacket erh�hlst du 2 Angriffe mehr.`n`n");
                        $session['user']['attack']-=2;
                        $session['user']['attack']+=2;
                        }else{
                        output("`nDurch dein Drachenleder Jacket erh�hlst du 2 Angriff mehr.`n`n");
                        $session['user']['attack']+=2;
                        $session['user']['kuse']=1;
                        }
                }

		$session['user']['drunkenness']=0;
		$session['user']['bounties']=0;
if ($session['user']['frisur']<=80){
                $session['user']['frisur']+=1;
                }else{
                $session['user']['frisur']+=0;
                }
if ($session['user']['nagel']<=50){
                $session['user']['nagel']+=1;
                }else{
                $session['user']['nagel']+=0;
                }
			if ($session['user']['blut']==5){ 
		$session['user']['blut']+=0; 
		}else{ 
		$session['user']['blut']+=1; 
	} 
		$session['user']['drabru']=0; 
		$session['user']['draker']=0; 
		$session['user']['drakerp']=0; 
		$session['user']['drakers']=0; 
		$session['user']['drasch']=0; 
		$session['user']['dragru']=0;
		// Buffs from items
		$sql="SELECT * FROM items WHERE (class='Fluch' OR class='Geschenk' OR class='Zauber') AND owner=".$session[user][acctid]." ORDER BY id";
		$result=db_query($sql);
		for ($i=0;$i<db_num_rows($result);$i++){
		  	$row = db_fetch_assoc($result);
			if (strlen($row[buff])>8){
				$row[buff]=unserialize($row[buff]);
				if ($row['class']!='Zauber') $session[bufflist][$row[buff][name]]=$row[buff];
				if ($row['class']=='Fluch') output("`n`G$row[name]`G nagt an dir.");
				if ($row['class']=='Geschenk') output("`n`1$row[name]`1: $row[description]");
			}
			if ($row[hvalue]>0){
				$row[hvalue]--;
				if ($row[hvalue]<=0){
					db_query("DELETE FROM items WHERE id=$row[id]");
					if ($row['class']=='Fluch') output(" Aber nur noch heute.");
					if ($row['class']=='Zauber') output("`n`Q$row[name]`Q hat seine Kraft verloren.");
				}else{
					$what="hvalue=$row[hvalue]";
					if ($row['class']=='Zauber') $what.=", value1=$row[value2]";
					db_query("UPDATE items SET $what WHERE id=$row[id]");
				}
			}
		}		
	}
page_footer();
?>
