<?php
/*
    Ein Waldspecial der besonderen Art
    
    Autor: Eliwood
    <http://eliwood.dyndns.org>
    
    Ben�tigt das Bild "klavier3stufen.jpg" im "images"-Verzeichnis!
    
    Achtung! Um volle Geheimhaltung zu gew�hrleisten, wird noch folgendes in der source.php gebraucht:

      Nach:
        ($subdir=="//"?"/":$subdir)."chat.php"=>"X",

      F�ge hinzu:
     	  ($subdir=="//"?"/":$subdir)."special/klaviercode.php"=>"X",
*/

if(!isset($session['user'])) header('Location: ../index.php');

$session['user']['specialinc'] = 'klaviercode.php';
$session['user']['specialmisc'] = unserialize($session['user']['specialmisc']);

switch($_GET['boo'])
{
  case '':
    output('`5Seltsam sieht es hier aus`3, denkst du, w�hrend du ein verfallenes Kloster betrittst. '
      .'�berall liegen Skelette rum, w�hrend du, auf der Suche nach einem Schatz, durch die G�nge schreitest.`n'
      .'Genau kannst du es nicht beurteilen, wie lange du schon unterwegs bist, aber nach einer gewissen Zeit kommst du '
      .'in einen grossen Saal, der zum gr�ssten Teil noch erhalten ist. Eine riesige `^Orgel`3 steht auf der anderen Seite.`n'
      .'Du lenkst deine Schritte zu der `^Orgel`3, und setzt dich, um dich auszuruhen, auf den Stuhl vor den eigentlichen Tasten. '
      .'�ber den Tasten ist ein St�ck verblichenes Pergament, auf dem du folgende Worte lesen kannst:`0`n');

    output('`c`2Reisender, der du Suchst einen Schatz,`n'
          .'du nahe vor dem Ziele bist.`n'
          .'Die richtigen Tasten sollst du treffen,`n'
          .'da sonst dein Tot unser Gefallen ist.`n'
          .'So h�re gut unsre letzten Worte,`n'
          .'Und rate gut - Sonst geschehen Morde:`0`n`n`c');
    $rand = e_rand(10,29);
    switch(TRUE)
    {
      case ($rand >= 10 && $rand < 20):
        // Fisch
        $session['user']['specialmisc']['klaviercode'] = "Fis;c;h'";
        $session['user']['specialmisc']['x'] = 3;
        $session['user']['specialmisc']['press'] = array();
        
        output('`c`2Wasser umgibt uns, ist unser Leben,`n'
          .'sorgt f�r Nahrung, ist also unser Segen.`n'
          .'Feinde gibts viele, der Mensch ist nur einer,`n'
          .'Er jagt uns mit W�rmer, uns mag ja keiner.`n`n'
          .'3 Stufe hinbab und du bist am Ziel,`n'
          .'Doch denk dran, vielleicht ist es dir zuviel...`n`n`n');
        break;
      case ($rand >=20 && $rand < 30):
        // N-ade-l
        $session['user']['specialmisc']['klaviercode'] = "a;d;e";
        $session['user']['specialmisc']['x'] = 3;
        $session['user']['specialmisc']['press'] = array();
        
        output('`c`2Spitz ich bin, aufgehoben in Frauenhand,`n'
          .'komm ich zur Geltung als Werkzeug, viellicht f�r ein Band.`n`n'
          .'Du kennst nur die Mitte, Mensch, du fieser Vagabund, `n'
          .'Der Anfang und das Ende ist dir Unbekannt, wir ziehen dich un unseren Schlund.`n'
          .'Auf der gleichen Stufe liegt dein Ziel,`n'
          .'Doch denk dran, vielleicht ist es dir zuviel...`n`n`n');
        break;
    }
    
    addnav('Ich bin bereit!','forest.php?boo=akzept');
    addnav('Ich verschwinde!','forest.php?boo=verschwind');
    break;
    
  case 'verschwind':
    $hplost = $session['user']['level']*15;
    
    if ($hplost >= $session['user']['maxhitpoints']) {
		  $hplost = $session['user']['maxhitpoints']-1;
		}
    
    $session['user']['hitpoints'] -= $hplost;
    if($session['user']['hitpoints'] <= 0) $session['user']['hitpoints'] = 1;
    
    $session['user']['specialinc'] = "";
    
    output('`3Schnell nimmst du deine Beine in die Hand und verschwindest, ohne auch '
      .'nur einen Gedanken an das R�tsel zu verschwenden. Bei deinem voreiligen Verschwinden verlierst du `^'
      .$hplost.' Lebenspunkte`3, da du �ber einen Stein gestolpert bist.');
    break;

  case 'akzept':
    if(isset($_GET['press']))
    {
      $_GET['press'] = RawUrlDecode($_GET['press']);
			$session['user']['specialmisc']['press'][] = $_GET['press'];
    }
    if(count($session['user']['specialmisc']['press']) == $session['user']['specialmisc']['x'])
    {
      $gedruckt = stripslashes(implode(";",$session['user']['specialmisc']['press']));
      $richtig = $session['user']['specialmisc']['klaviercode'];
      
      if($gedruckt == $richtig)
      {
        output('`3Lichtstrahlen brechen aus der Orgel, und ber�hren dich. Du hast keine Angst, '
          .'denn du weisst, dass du das R�tsel der Orgel gel�st hast, und erwartest sehns�chtig deine '
          .'Belohnung.`n`n');
          
        switch(e_rand(1,3))
        {
          case 1:
          case 2:
            $gold = e_rand($session['user']['level']*10,$session['user']['level']*100);
            output('Der Lichstrahl wandelt sich zu Gold und zu einem Edelstein.`n`n`#Du bekommst `^'
              .$gold.' Goldst�cke`3 und `5einen Edelstein`3.`nDu freust dich mit deinem neuen Schatz, und verl�sst '
              .'das Kloster.`0`n`n');

            $session['user']['gold'] += $gold;
            $session['user']['gems']++;
            break;
          case 3:
            $hp = e_rand(1,3);
            
            output('Der Lichstrahl w�rmt dich. Nach einer Zeitlang merkst du, dass du im Wald '
              .'l�nger leben wirst als vorher.`n`n'
              .'`#Du bekommst `^'.$hp.'`# zus�tzliche Lebenspunkte!!`0`n`n');
            break;
        }
        
        $session['user']['specialinc'] = "";
      }
      else
      {
        output('`3Die Orgel beginnt zu beben. Langsam st�rzen Teile der Orgal hinunter, panisch willst '
          .'du aufstehen, doch irgendetwas h�lt dich fest. Du hast keine Zeit mehr, um zu schauen, was es ist, '
          .'du siehst nur noch eine Orgelfl�te aus Gold, so gross wie du selbst, auf dich st�rzen. Dann siehst du '
          .'schw�rze, und weisst, dass du nun `$Tot`3 bist.`n`n'
          .'`#Du verlierst all dein Gold!'
          .'Du verlierst `^15%`# deiner Erfahrung!`n`n'
          .'`3Du findest dich bei Ramius wieder...`0');

        $session['user']['gold'] = 0;
        $session['user']['alive'] = false;
        $session['user']['hitpoints'] = 0;
        $session['user']['experience']*=0.85;
        
        
        addnews('`5'.$session['user']['name'].'`5 hat beim R�tsel der Orgel den Tot gefunden!`0');
        addnav('T�gliche News','news.php');
        $session['user']['specialinc'] = "";
      }
    }
    else
    {
    
  
    $ausgabe = <<<HTML
    <table align="center" width="422" height="515">
      <tr>
        <td>
          <img src="images/klavier3stufen.gif" width="422" height="515" alt="Klaviertastatur" usemap="#Klavier" style="border: none;">
        </td>
      </tr>
    </table>
    

<map name="Klavier">
    <!--
      Eine Septime unter der normalen
      H�henpunkte:
        Oben: 2
        Mitte: 90
        Unten: 173
    -->
    <area shape="poly" coords="2,2, 40,2, 40,90, 66,90, 60,173, 2,173"
          href="#C" alt="C">
    <area shape="poly" coords="62,90, 82,90, 82,2, 100,2, 100,90, 120,90, 120,173, 62,173"
          href="#D" alt="D">
    <area shape="poly" coords="122,90, 142,90, 142,2, 180,2, 180,173, 122,173"
          href="#E" alt="E">
    <area shape="poly" coords="182,2, 220,2, 220,90, 240,90, 240,173, 182,173"
          href="#F" alt="F">
    <area shape="poly" coords="242,90, 262,90, 262,2, 280,2, 280,90, 300,90, 300,173, 242,173"
          href="#G" alt="G">
    <area shape="poly" coords="302,90, 322,90, 322,2, 340,2, 340,90, 360,90, 360,173, 302,173"
          href="#A" alt="A">
    <area shape="poly" coords="362,90, 382,90, 382,2, 420,2, 420,173, 362,173"
          href="#H" alt="H">
    <!--
      Die Normale Septime
      H�henpunkte:
        Oben: 175
        Mitte: 260
        Unten: 343
    -->
    <area shape="poly" coords="2,175, 40,175, 40,260, 66,260, 60,343, 2,343"
          href="#c" alt="c">
    <area shape="poly" coords="62,260, 82,260, 82,175, 100,175, 100,260, 120,260, 120,343, 62,343"
          href="#d" alt="d">
    <area shape="poly" coords="122,260, 142,260, 142,175, 180,175, 180,343, 122,343"
          href="#e" alt="r">
    <area shape="poly" coords="182,175, 220,175, 220,260, 240,260, 240,343, 182,343"
          href="#f" alt="f">
    <area shape="poly" coords="242,260, 262,260, 262,175, 280,175, 280,260, 300,260, 300,343, 242,343"
          href="#g" alt="g">
    <area shape="poly" coords="302,260, 322,260, 322,175, 340,175, 340,260, 360,260, 360,343, 302,343"
          href="#a" alt="a">
    <area shape="poly" coords="362,260, 382,260, 382,175, 420,175, 420,343, 362,343"
          href="#h" alt="h">
    <!--
      Die Eingestrichene Septime
      H�henpunkte:
        Oben: 345
        Mitte: 430
        Unten: 513
    -->
    <area shape="poly" coords="2,345, 40,345, 40,260, 66,260, 60,513, 2,513"
          href="#c%27" alt="c'">
    <area shape="poly" coords="62,430, 82,430, 82,345, 100,345, 100,90, 120,90, 120,513, 62,513"
          href="#d%27" alt="d'">
    <area shape="poly" coords="122,90, 142,90, 142,345, 180,345, 180,513, 122,513"
          href="#e%27" alt="r'">
    <area shape="poly" coords="182,345, 220,345, 220,430, 240,430, 240,513, 182,513"
          href="#f%27" alt="f'">
    <area shape="poly" coords="242,430, 262,430, 262,345, 280,345, 280,430, 300,430, 300,513, 242,513"
          href="#g%27" alt="g'">
    <area shape="poly" coords="302,430, 322,430, 322,345, 340,345, 340,430, 360,430, 360,513, 302,513"
          href="#a%27" alt="a'">
    <area shape="poly" coords="362,430, 382,430, 382,345, 420,345, 420,513, 362,513"
          href="#h%27" alt="h'">

    <!--
      Die tiefen Halbt�ne
      H�henpunkte:
        Oben: 2
        Unten: 89
    -->

    <area shape="rect" coords="41,2, 60,89"
          href="#Cis" alt="Cis">
    <area shape="rect" coords="62,2, 81,89"
          href="#Des" alt="Des">

    <area shape="rect" coords="101,2, 120,89"
          href="#Dis" alt="Dis">
    <area shape="rect" coords="122,2, 141,89"
          href="#Es" alt="Es">

    <area shape="rect" coords="221,2, 240,89"
          href="#Fis" alt="Fis">
    <area shape="rect" coords="242,2, 261,89"
          href="#Ges" alt="Ges">

    <area shape="rect" coords="281,2, 300,89"
          href="#Gis" alt="Gis">
    <area shape="rect" coords="302,2, 321,89"
          href="#As" alt="As">

    <area shape="rect" coords="341,2, 360,89"
          href="#Ais" alt="Ais">
    <area shape="rect" coords="362,2, 380,89"
          href="#B" alt="B">


    <!--
      Die normalen Halbt�ne
      H�henpunkte:
        Oben: 175
        Unten: 259
    -->

    <area shape="rect" coords="41,175, 60,259"
          href="#cis" alt="cis">
    <area shape="rect" coords="62,175, 81,259"
          href="#des" alt="des">

    <area shape="rect" coords="101,175, 120,259"
          href="#dis" alt="dis">
    <area shape="rect" coords="122,175, 141,259"
          href="#es" alt="es">

    <area shape="rect" coords="221,175, 240,259"
          href="#fis" alt="fis">
    <area shape="rect" coords="242,175, 261,259"
          href="#ges" alt="ges">

    <area shape="rect" coords="281,175, 300,259"
          href="#gis" alt="gis">
    <area shape="rect" coords="302,175, 321,259"
          href="#as" alt="as">

    <area shape="rect" coords="341,175, 360,259"
          href="#ais" alt="ais">
    <area shape="rect" coords="362,175, 380,259"
          href="#b" alt="b">


    <!--
      Die hohen Halbt�ne
      H�henpunkte:
        Oben: 345
        Unten: 429
    -->

    <area shape="rect" coords="41,345, 60,429"
          href="#cis%27" alt="cis">
    <area shape="rect" coords="62,345, 81,429"
          href="#des%27" alt="des">

    <area shape="rect" coords="101,345, 120,429"
          href="#dis%27" alt="dis">
    <area shape="rect" coords="122,345, 141,429"
          href="#es%27" alt="es">

    <area shape="rec%27t" coords="221,345, 240,429"
          href="#fis" alt="fis">
    <area shape="rect" coords="242,345, 261,429"
          href="#ges%27" alt="ges">

    <area shape="rect" coords="281,345, 300,429"
          href="#gis%27" alt="gis">
    <area shape="rect" coords="302,345, 321,429"
          href="#as%27" alt="as">

    <area shape="rect" coords="341,345, 360,429"
          href="#ais%27" alt="ais">
    <area shape="rect" coords="362,345, 380,429"
          href="#b%27" alt="b">


  </map>
  
HTML;
    $ausgabe = str_replace('href="#','href="forest.php?boo=akzept&press=',$ausgabe);
    
    addnav('','forest.php?boo=akzept&press=C');
    addnav('','forest.php?boo=akzept&press=D');
    addnav('','forest.php?boo=akzept&press=E');
    addnav('','forest.php?boo=akzept&press=F');
    addnav('','forest.php?boo=akzept&press=G');
    addnav('','forest.php?boo=akzept&press=A');
    addnav('','forest.php?boo=akzept&press=H');
    
    addnav('','forest.php?boo=akzept&press=c');
    addnav('','forest.php?boo=akzept&press=d');
    addnav('','forest.php?boo=akzept&press=e');
    addnav('','forest.php?boo=akzept&press=f');
    addnav('','forest.php?boo=akzept&press=g');
    addnav('','forest.php?boo=akzept&press=a');
    addnav('','forest.php?boo=akzept&press=h');
    
    addnav('','forest.php?boo=akzept&press='.RawUrlEncode('c\''));
    addnav('','forest.php?boo=akzept&press='.RawUrlEncode('d\''));
    addnav('','forest.php?boo=akzept&press='.RawUrlEncode('e\''));
    addnav('','forest.php?boo=akzept&press='.RawUrlEncode('f\''));
    addnav('','forest.php?boo=akzept&press='.RawUrlEncode('g\''));
    addnav('','forest.php?boo=akzept&press='.RawUrlEncode('a\''));
    addnav('','forest.php?boo=akzept&press='.RawUrlEncode('h\''));
    
    addnav('','forest.php?boo=akzept&press=Cis');
    addnav('','forest.php?boo=akzept&press=Des');
    addnav('','forest.php?boo=akzept&press=Dis');
    addnav('','forest.php?boo=akzept&press=Es');
    addnav('','forest.php?boo=akzept&press=Fis');
    addnav('','forest.php?boo=akzept&press=Ges');
    addnav('','forest.php?boo=akzept&press=Gis');
    addnav('','forest.php?boo=akzept&press=As');
    addnav('','forest.php?boo=akzept&press=Ais');
    addnav('','forest.php?boo=akzept&press=B');

    addnav('','forest.php?boo=akzept&press=cis');
    addnav('','forest.php?boo=akzept&press=des');
    addnav('','forest.php?boo=akzept&press=dis');
    addnav('','forest.php?boo=akzept&press=es');
    addnav('','forest.php?boo=akzept&press=fis');
    addnav('','forest.php?boo=akzept&press=ges');
    addnav('','forest.php?boo=akzept&press=gis');
    addnav('','forest.php?boo=akzept&press=as');
    addnav('','forest.php?boo=akzept&press=ais');
    addnav('','forest.php?boo=akzept&press=b');
    
    addnav('','forest.php?boo=akzept&press='.RawUrlEncode('cis\''));
    addnav('','forest.php?boo=akzept&press='.RawUrlEncode('des\''));
    addnav('','forest.php?boo=akzept&press='.RawUrlEncode('dis\''));
    addnav('','forest.php?boo=akzept&press='.RawUrlEncode('es\''));
    addnav('','forest.php?boo=akzept&press='.RawUrlEncode('fis\''));
    addnav('','forest.php?boo=akzept&press='.RawUrlEncode('ges\''));
    addnav('','forest.php?boo=akzept&press='.RawUrlEncode('gis\''));
    addnav('','forest.php?boo=akzept&press='.RawUrlEncode('as\''));
    addnav('','forest.php?boo=akzept&press='.RawUrlEncode('ais\''));
    addnav('','forest.php?boo=akzept&press='.RawUrlEncode('b\''));
    
    
    rawoutput($ausgabe);
    }
    break;
}

?>
