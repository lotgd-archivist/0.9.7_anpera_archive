<?php
/*************************
*   Script by -[HoRuS]-  *
*                        *
*       Spielhaus        *
*                        *
*************************/

require_once "common.php";
page_header("Spielhaus");

switch($_GET['op']){
default:
   output("`c`b`5Spielhaus`c`b`5Du betrittst ein gro�es Geb�ude. Das ganze Geb�ude besteht nur aus einem Raum.
   Im Raum verteilt gibt es verschiedene Tische. An manchen wird gespielt und an den anderen nur geredet.`n`n
   Du schaust in deinen Beutel und siehst, dass du ");
   if($session['user']['m�nzen']==0){
      output("`^`ikeine `i`5M�nzen mehr besitzt.");
   }
   else if(($session['user']['m�nzen']>0) && ($session['user']['m�nzen']<2)) {
      output("`^ eine `5M�nze besitzt.");
   }
   else {
      output("`^$session['user']['m�nzen'] `5M�nzen besitzt.");
   }
   addnav("Spielhaus");
   addnav("Spielm�nzen kaufen","spiel.php?op=buycoin");
   addnav("M�nzen eintauschen","spiel.php?op=tradecoins");
   addnav("Spiele");
   addnav("Black Jack","spiel.php?op=blackjack");
   addnav("Poker","spiel.php?op=poker");
   addnav("Wege");
   addnav("Zur�ck zum Dorf","village.php");
break;

case"buycoin":
   output("`c`b`5M�nzen kaufen`c`b`5Du kommst an einen kleinen Tisch.
      Hinter dem Tisch steht eine junge Elfe die dich anl�chelt. `n
      `2Hallo. Brauchen sie M�nzen?`n`5Du schaust die Elfe an die dich immer noch anl�chelt und schaust dann auf die Preisliste.`n`n
      `c`91 M�nze - `^500 Gold`9`n5 M�nzen - `^2000 Gold`9`n`n
      `c`5Du merkst das die Preise nicht ganz billig sind, aber ohne die M�nzen kannst du leider nicht mit den anderen Spielen.");
   addnav("Anzahl");
   addnav("1 M�nze","spiel.php?op=onecoin");
   addnav("5 M�nzen","spiel.php?op=fivecoins");
   addnav("Wege");
   addnav("Zur�ck zum Spielhaus","spiel.php");
break;

case"onecoin":
   if($session['user']['gold']<500){
      output("`2Tut mir Leid, aber sie haben nicht genug Gold dabei. Kommen sie sp�ter nochmal! Ich stehe ihnen rund um die Uhr zur Verf�gung.");
      addnav("Wege");
      addnav("Zur�ck zum Spielhaus","spiel.php");
   }
   else {
      output("`2Eine M�nze also? `n`5Die Elfe nimmt dein Gold und gibt dir eine `^M�nze`5.`n`2Mit dieser M�nze k�nnen sie hier bezahlen.");
      $session['user']['gold']-=500;
      $session['user']['m�nzen']+=1;
      addnav("wege");
      addnav("Zur�ck zum Spielhaus","spiel.php");
   }
break;

case"fivecoins":
   if($session['user']['gold']<1999){
      output("`2Tut mir Leid, aber sie haben nicht genug Gold dabei. Kommen sie sp�ter nochmal! Ich stehe ihnen rund um die Uhr zur Verf�gung.");
      addnav("Wege");
      addnav("Zur�ck zum Spielhaus","spiel.php");
   }
   else {
      output("`2F�nf M�nze also? `n`5Die Elfe nimmt dein Gold und gibt dir f�nf `^M�nzen`5.`n`2Mit diesen M�nzen k�nnen sie hier bezahlen.");
      $session['user']['gold']-=2000;
      $session['user']['m�nzen']+=5;
      addnav("Wege");
      addnav("Zur�ck zum Spielhaus","spiel.php");
   }
break;

//BLACK JACK
case"blackjack":
   output("`5`c`bBlack Jack`c`bDu kommst an einen kleinen runden Tisch. An einem Ende des Tisches sitzt ein Elf mit einem Kartenspiel in der Hand.
   Er schaut dich an und sagt dann:`n`2Lust auf eine Runde `^Black Jack?`n`5Du schaust ihn an und siehst dann ein Blatt vor dir,
   auf dem die Black Jack Regeln drauf stehen.`n`n`gSpiel: Black Jack`n`nRegeln: Der spieler kriegt eine Karte.
   Jede Karte bringt unterschiedlich viele Punkte von `$ 1-10`g auf das Konto des Spielers.
   Der Spieler kann jederzeit eine neue Karte nehmen, oder das Spiel beenden.
   Sollte der Spieler am Ende ein Konto unter oder gleich 21 zuhaben hat er gewonnen, sofern das Haus kein gr��eres Blatt hat.`n`n
   Kosten: `^2 M�nzen `gEinsatz");
   addnav("Black Jack");
   addnav("Spielen","spiel.php?op=playblackjack");
   addnav("Wege");
   addnav("Zur�ck zum Spielhaus","spiel.php");
   $session['user']['black']=false;
break;

case"playblackjack":
   if($session['user']['m�nzen']<2){
      output("`5`c`bBlack Jack`c`bDer Elf schaut dich vewirrt an. `n`2Komm wieder wenn du Genug `^M�nzen`2 dabei hast!");
      addnav("Wege");
      addnav("Zur�ck zum Spielhaus","spiel.php");
   } else {
      $session['user']['m�nzen']-=2;
      output("`5`c`bBlack Jack`c`bDer Elf mischt die Karten und gibt dir dann deine erste Karte.`n Es ist eine ");

      //swich rausgenommen
      $getcard = e_rand(1,10);
      $session['user']['black']+=$gecard;
      output("`^".$getcard."`5.");
      //

      output("`n`5Dein Kontostand betr�gt momentan `^");
      output($session['user']['black']);
      output("`5 Punkte");
      output("`n`5M�chtest du noch eine Karte?");
      addnav("Black Jack");
      addnav("Noch eine Karte","spiel.php?op=blackjackcontinue");
      addnav("Beenden","spiel.php?op=blackjackend");
   }
break;

case"blackjackend":
   if($session['user']['black']>21){
      output("`5`c`bBlack Jack`c`bDer Elf schaut dich traurig an. `n`2Tut mir Leid, aber dein Kontostand ist leider �ber `^21 `2.
      Damit gewinnt das Haus. Komm ein anderes mal wieder.`n`5Traurig verl�sst du den Tisch.");
      $session['user']['black']=false;
      addnav("Wege");
      addnav("Zur�ck zum Spielhaus","spiel.php");
   }
   else if($session['user']['black']==21){
      output("`5`c`bBlackJack`c`bDer Elf schaut dich beeindruckt an.`n `2Wow. Genau `^21`2. Das ist der Wahnsinn.
      Daf�r gibt es `^10 M�nzen`5!`n`5Mit einem Strahlen im Gesicht verl�sst du den Tisch.");
      $session['user']['m�nzen']+=10;
      $session['user']['black']=false;
      addnav("Wege");
      addnav("Zur�ck zum Spielhaus","spiel.php");
   } else {
      output("`5Der Elf schaut dich ernst an. `2`nHmmm... `^");
      output($session['user']['black']);
      output(" `2Punkte also.`n`5Der Elf zieht seine Karten und... ");

      switch(e_rand(1,8)){
         case 1:
              output("`@GEWINNT!`n`5Er grinst dich an, und du musst dich damit abfinden nichts gewonnen zuhaben. Traurig verl�sst du den Tisch.");
              $session['user']['black']=false;
         break;

         case 4:
              output("`@GEWINNT!`n`5Er grinst dich an, und du musst dich damit abfinden nichts gewonnen zuhaben. Traurig verl�sst du den Tisch.");
              $session['user']['black']=false;
         break;

         case 5:
              output("`@GEWINNT!`n`5Er grinst dich an, und du musst dich damit abfinden nichts gewonnen zuhaben. Traurig verl�sst du den Tisch.");
              $session['user']['black']=false;
         break;

         case 2:
              output("`$ VERLIERT!`n`5Damit hast du gegen das Haus gewonnen. Du erh�ltst `^4 M�nzen`5. Strahlend verl�sst du den Tisch");
              $session['user']['black']=false;
              $session['user']['m�nzen']+=4;
         break;

         case 6:
              output("`$ VERLIERT!`n`5Damit hast du gegen das Haus gewonnen. Du erh�ltst `^4 M�nzen`5. Strahlend verl�sst du den Tisch");
              $session['user']['black']=false;
              $session['user']['m�nzen']+=4;
         break;

         case 7:
         output("`$ VERLIERT!`n`5Damit hast du gegen das Haus gewonnen. Du erh�ltst `^4 M�nzen`5. Strahlend verl�sst du den Tisch");
              $session['user']['black']=false;
              $session['user']['m�nzen']+=4;
         break;

         case 3:
              output("`6 UNENTSCHIEDEN!`n`5Der Elf hat genau den selben Punktestand wie du. Du kriegst deine `^2 M�nzen`5 wieder.
              Du verl�sst den Tisch.");
              $session['user']['black']=false;
              $session['user']['m�nzen']+=2;
         break;

         case 8:
              output("`6 UNENTSCHIEDEN!`n`5Der Elf hat genau den selben Punktestand wie du. Du kriegst deine `^2 M�nzen`5 wieder.
              Du verl�sst den Tisch.");
              $session['user']['black']=false;
              $session['user']['m�nzen']+=2;
         break;
      }
      addnav("Wege");
      addnav("Zur�ck zum Spielhaus","spiel.php");
   }
break;

case"blackjackcontinue":
   output("`5`c`bBlack Jack`c`bDer Elf gibt dir eine weitere Karte. `nEs ist eine ");

   //swich rausgenommen
   $getcard = e_rand(1,10);
   $session['user']['black']+=$getcard;
   output("`^".$getcard."`5.");
   //

   output("`n`5Dein Kontostand betr�gt momentan `^");
   output($session['user']['black']);
   output("`5 Punkte");

   if($session['user']['black']>21){
      output("`n`n`5Der Elf schaut dich traurig an. `n`2Tut mir Leid, aber dein Kontostand ist bereits �ber `^21 `2.
      Damit gewinnt das Haus. Komm ein anderes mal wieder.`n`5Traurig verl�sst du den Tisch.");
      addnav("Wege");
      addnav("Zur�ck zum Spielhaus","spiel.php");
   }
   else if($session['user']['black']==21){
      output("`5Der Elf schaut dich beeindruckt an.`n `2Wow. Genau `^21`2. Das ist der Wahnsinn. Daf�r gibt es `^10 M�nzen`5!`n
      `5Mit einem Strahlen im Gesicht verl�sst du den Tisch.");
      $session['user']['m�nzen']+=10;
      $session['user']['black']=false;
      addnav("Wege");
      addnav("Zur�ck zum Spielhaus","spiel.php");
   } else {
      output("`n`5M�chtest du noch eine Karte?");
      addnav("Black Jack");
      addnav("Noch eine Karte","spiel.php?op=blackjackcontinue");
      addnav("Beenden","spiel.php?op=blackjackend");
   }
break;

case"tradecoins":
   output("`5`c`bM�nzen eintauschen`c`bDu kommst an einen gro�en Tisch. Auf dem Tisch stehen die verschiedensten Preise.
   Hier kannst du deine M�nzen gegen Preise eintauschen.`nDu schaust in deinen Beutel und siehst, dass du ");
   if($session['user']['m�nzen']==0){
      output("`^`ikeine `i`5M�nzen mehr besitzt.");
   }
   else if($session['user']['m�nzen']<2){
      output("`^ eine `5M�nze besitzt.");
   } else {
      output("`^");
      output($session['user']['m�nzen']);
      output(" `5 M�nzen besitzt.");
      addnav("Eintauschen");
      addnav("Wege");
      addnav("Zur�ck zum Spielhaus","spiel.php");
   }
break;

//POKER
case"poker":
   output("`5`c`bPoker`c`bDu kommst an einen Tisch. Hinter dem Tisch steht ein Elf. Er hat ein Kartenspiel in der Hand.`n
   `2Na, Lust auf eine Runde Poker, du gegen das Haus?`n`5Du schaust ihn kurz an und siehst adnn die Pokerregeln neben dir liegen.`n`n
   `gSpiel: Poker`n`nRegeln: Jeder Spieler kriegt 5 Karten. Derjenige mit dem besseren Blatt gewinnt. Dies ist Poker Barquox Art.
   Es gibt kein Kartenaustausch!`n`nKosten: `^4 M�nzen`5`n`nWillst du an dem Spiel teilnehmen?");
   addnav("Poker");
   addnav("Mitspielen","spiel.php?op=pokerplay");
   addnav("Wege");
   addnav("zur�ck zum Spielhaus","spiel.php");

   $session['user']['pokeryou']=false;
   $session['user']['pokerenemie']=false;
break;

case"pokerplay":
   if($session['user']['m�nzen']<4){
      output("`5`c`bPoker`c`bDer Elf schaut dich verwirrt an.`n`2Komm wieder wenn du die M�nzen daf�r hast!");
      addnav("Wege");
      addnav("Zur�ck zum Spielhaus","spiel.php");
   } else {
      output("`5`c`bPoker`c`bDer Elf gibt dir 5 Karten.`n`nSpielverlauf:`n`nDEIN Blatt: ");
      $session['user']['m�nzen']-=4;

      switch(e_rand(1,8)){

         case 1:
              $session['user']['pokeryou']+=0;
              output("`^NICHTS!`5`n`nGegner Blatt: ");
         break;

         case 2:
              $session['user']['pokeryou']+=1;
              output("`^Ein P��rchen!`5`n`nGegner Blatt: ");
         break;

         case 3:
              $session['user']['pokeryou']+=2;
              output("`^Zwei P��rchen!`5`n`nGegner Blatt: ");
         break;

         case 4:
              $session['user']['pokeryou']+=3;
              output("`^Dreier P��rchen!`5`n`nGegner Blatt: ");
         break;

         case 5:
              $session['user']['pokeryou']+=4;
              output("`^Full House!`5`n`nGegner Blatt: ");
         break;

         case 6:
              $session['user']['pokeryou']+=5;
              output("`^Kleine Stra�e!`5`n`nGegner Blatt: ");
         break;

         case 7:
              $session['user']['pokeryou']+=6;
              output("`^Gro�e Stra�e!`5`n`nGegner Blatt: ");
         break;

         case 8:
              $session['user']['pokeryou']+=7;
              output("`^4 Aas!`5`n`nGegner Blatt: ");
         break;
      }
      switch(e_rand(1,8)){

         case 1:
              $session['user']['pokerenemie']+=0;
              output("`^NICHTS!`5`n`n`n");
         break;

         case 2:
              $session['user']['pokerenemie']+=1;
              output("`^Ein P��rchen!`5`n`n`n");
         break;

         case 3:
              $session['user']['pokerenemie']+=2;
              output("`^Zwei P��rchen!`5`n`n`n");
         break;

         case 4:
              $session['user']['pokerenemie']+=3;
              output("`^Dreier P��rchen!`5`n`n`n");
         break;

         case 5:
              $session['user']['pokerenemie']+=4;
              output("`^Full House!`5`n`n`n");
         break;

         case 6:
              $session['user']['pokerenemie']+=5;
              output("`^Kleine Stra�e!`5`n`n`n");
         break;

         case 7:
              $session['user']['pokerenemie']+=6;
              output("`^Gro�e Stra�e!`5`n`n`n");
         break;

         case 8:
              $session['user']['pokerenemie']+=7;
              output("`^4 Aas!`5`n`n`n");
         break;
      }

      if(($session['user']['pokeryou']) > ($session['user']['pokerenemie'])){
         output("`5Du hast GEWONNEN! Du erh�lst `^8 M�nzen`5.");
         $session['user']['m�nzen']+=8;
      }
      else if(($session['user']['pokeryou']) < ($session['user']['pokerenemie'])){
         output("`5Du hast VERLOREN! Das Haus gewinnt.");
      } else {
         output("`5Gleichstand! Du kriegst deinen `^Einsatz`5 wieder!");
         $session['user']['m�nzen']+=4;
      }
      addnav("Wege");
      addnav("Zur�ck zum Spielhaus","spiel.php");
   }
break;
}
page_footer();
?>