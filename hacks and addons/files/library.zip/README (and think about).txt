Bibirs Bibliothek
Version 1.4
(c) bibir <logd_bibir@email.de> & Chaosmaker <webmaster@chaosonline.de>

Einbau:

- Tabellenstruktur wie in der sulib.php enthalten in der Datenbank erstellen
- library.php in der village.php verlinken
- sulib.php in der Admin-Grotte verlinken
- configuration.php:
  Finde: "topwebid"=>"ID f�r Top Web Games (wenn du dort registriert bist),int",
  F�ge danach ein: "libdp"=>"Donationpoints f�r neue B�cher in der Bibliothek,int",
- �ber die sulib.php Themen anlegen (erst dann k�nnen die User B�cher dazu schreiben!)