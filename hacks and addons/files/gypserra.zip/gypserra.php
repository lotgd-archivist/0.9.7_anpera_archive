<?
/**
* _______________________________________________
* | gypseraa.php: Addon um Inseln zu erstellen  |
* |                                             |
* |                                             |
* | mit diesem Addon kann sich jeder beliebig   |
* | viele Inseln erstellen, man ben�tigt dazu   |
* | nur das Hafenviertel und muss nur die Namen |
* | in den entsprechenden Variablen anpassen.   |
* |                                             |
* | �2009 by Liath www.germany-project.de/logd  |
* | programmiert in der LoGD DragonSlayer 2.5   |
* | idee abgekupfert von Gimmick & Aragorn      |
* |                                             |
* | fertiggestellt:                             |
* | am 09. Februar 2009 um 14�� Uhr             |
* |                                             |
* | Benutzung, Ver�nderungen, Versch�nerungen,  |
* | oder auch eigene Anpassungen sind erlaubt,  |
* | solange dieser Header beibehalten wird und  |
* | die Datei im Source offen gehalten wird.    |
* |                                             |
* | Changelog:                                  |
* |                                             |
* �����������������������������������������������
* 
* Eigene Ver�nderungen d�rfen ab hier
* gekennzeichnet werden:
* _______________________________________________ 
* | Author:                                     |
* | Changed:                                    |
* | Date:                                       |
* �����������������������������������������������
* 
**/

/**
* 
* Einbauanleitung:
* 
* Pr�fe die untenstehenden Einstellungen und passe Sie gegebenfalls an Deinen Server an.
* Die nicht ben�tigten Navigationsvariablen kannst Du entweder l�schen oder auskommentieren.
* 
* Ich habe bei mir auf der Insel einen 2. Wald eingerichtet, 
* eine Anleitung dazu findest Du auf: http://anpera.homeip.net/phpbb3/
* 
* desweiteren habe ich mir einfach die healer.php, die stables.php und die bank.php genommen
* alle addnavs und die Namen angepasst und als gypserra_*.php hochgeladen. Das gleiche kannst
* Du nat�rlich auch tun, denn diese Dateien sind im Paket nicht enthalten. Du kannst nat�rlich 
* jederzeit noch weitere Orte in die Navigation einf�gen.
* 
* suche in der common.php
  define('USER_LOC_HOUSE',2);
* 
* f�ge darunter ein:
  define('USER_LOC_GYPSERRA',4);
* oder eine andere ID Deiner Wahl
* 
* suche:
  if ($row['location']==USER_LOC_HOUSE)
  {
       $str_output .= '`3Im Haus`0';
  }
* 
* f�ge darunter ein:
  if ($row['location']==USER_LOC_GYPSERRA)  // USER_LOC_GYPSERRA muss auf den Dorfnamen angepasst werden
  {
  $str_output .= '`3In Gypserra`0';         // auch hier den Namen auf das entsprechende Dorf anpassen
  }
* 
* Diese Datei lade einfach in Deinen LoGD Rootordner hoch und gib den Dateinamen in der:
* 
* hafen.php bei $zfile = 'gypserra_hafen.php'; und den Inselnamen bei $ziel = 'Gypserra'; an
* gypserra_hafen.php bei $ofile = 'gypserra_hafen.php'; den Dateinamen, bei $ort = 'Gypserra'; den Inselnamen und
* bei $ortid = '4'; die Inselid, so wie Du Sie oben festgelegt hast.
* 
* �ffne list.php und news.php und suche in beiden :
  if ($session['user']['alive'])
  {
        addnav('Zur�ck');
        addnav('Zum Dorfplatz','village.php');
        addnav('Zum Marktplatz','market.php');
  }
* 
* und ersetze in beiden durch: (InselID beachten)
  if ($session['user']['alive']) {
        if ($session['user']['location']==4) { 
            addnav("Zur�ck");
            addnav("Zum Dorfplatz","gypserra.php");
        }
        else {
            addnav("Zur�ck");
            addnav("Zum Dorfplatz","village.php");
            addnav("Zum Marktplatz","market.php");
        }
  }
* 
* Alles speichern, hochladen, fertig 
* Das wars. Ich w�nsche Dir viel Spass mit Deiner neuen Insel
* 
*/


require_once "common.php";
define ("is_tournament",getsetting("tournament_c",9)-2);
checkday();

// Einstellungen f�r die Insel
$einwohner = 'Gypserraner';                  // Name der Einwohner
$name = 'Gypserra';                          // Name der Insel
$pic = './images/gypserra.jpg';              // Bild im Dorf
$scrolltext = '1';                           // Nachrichten im Scrolltext erlauben = '0' aus '1' an
$dorf = getsetting('townname','Jardelna');   // hier wird bestimmt wie das Hauptdorf heisst
$w = get_weather();                             
//festlegen der Navigation (wenn nicht vorhanden einfach auskommentieren)
$insel = 'gypserra.php';
$hafen = 'gypserra_hafen.php';
$wald = 'gypserra_forest.php';
$kirche = 'gypserra_kirche.php';
$bar = 'gypserra_bar.php';
$heiler = 'gypserra_healer.php';
$casino = 'gypserra_casino.php';
$bank = 'gypserra_bank.php';
$stall = 'gypserra_stables.php';
$knappen = 'knappschaft.php';

// auslesen der aktuellsten Nachrichten
$sql = "SELECT * FROM news ORDER BY newsid DESC LIMIT 1";
$result = db_query($sql) or die(db_error(LINK));
$news_m = mysql_result($result, 0, "newstext");

page_header("die Insel $name");

// Anzeige des Datums, der Uhrzeit und des n�chsten Turniers
if (is_file($pic)) { output('<div align="center"><img border="0" src="'.$pic.'" alt="die Insel '.$name.'"></div>`n`n'); }
if ($scrolltext==1) {
    output("`n<table align=\"center\"><tr><td width=450><FONT SIZE='2'><marquee align=\"middle\" scrollamount=\"4\" scrolldelay=\"4\">`i{$news_m}`i</marquee></td></tr></table>`n",true);
}
else { output("`c$news_m`c`n"); }

if (getsetting('activategamedate','0')==1) output('`c`@Wir schreiben den `^'.getgamedate().'`@ im Zeitalter des Drachen.`n`c');
output('`c`@Die magische Sonnenuhr zeigt `^'.getgametime().'`@. ');
output('`@Das heutige Wetter: `6'.$w['name'].'`@.`c ');

// Kommentarfunktion
addcommentary();
output("`n`n`%`@Auf dem Dorplatz reden einige ".$einwohner.":`n");
viewcommentary("$name","Hinzuf�gen",25);

if ($_GET['op']==""){        
    addnav("Heldenstrasse");
    if ($wald) { addnav("in den Wald","$wald"); }
    if ($healer) { addnav("Esmeralda","$healer"); }
    addnav("Tavernenstrasse");
    if ($bar) { addnav("Bar","$bar"); }
    if ($casino) { addnav("Casino","$casino"); }
    addnav("Marktstrasse");
    if ($bank) { addnav("Die Bank","$bank"); }
    if ($stall) { addnav("Dwericks St�lle","$stall"); }
    if ($knappen) { addnav("Knappschaft","$knappen"); }
    addnav("andere Orte");
    if ($kirche) { addnav("Zur Kirche","$kirche"); }
    if ($hafen) { addnav("Zum Hafen","$hafen"); }
    addnav("Informationen");
    
    addnav("Neuigkeiten","news.php");
    addnav("Einwohnerliste","list.php");
    if ($session['user']['superuser']>0) {
        addnav('Admin');
        addnav('Admin Grotte','superuser.php');  
        if(su_check(SU_RIGHT_NEWDAY)) {
            addnav('Neuer Tag','superuser.php?op=newday');
        }
        addnav('Lemming spielen','superuser.php?op=iwilldie');
    }
    addnav('Logout');
    addnav("unterm Baum schlafen","login.php?op=logout&loc=".$session['user']['location'],true);
}

page_footer();
?>