<?
/**
* _______________________________________________
* | hafen.php: f�r die Reise nach Gypserra      |
* |                                             |
* | mit diesem Addon wird einem die �berfahrt   |
* | nach Gypserra erm�glicht. Integriert ist    |
* | eine Werft in der man sich eigene Schiffe   |
* | kaufen, verkaufen oder reparieren kann.     |
* |                                             |
* | �2009 by Liath www.germany-project.de/logd  |
* | programmiert in der LoGD DragonSlayer 2.5   |
* | idee abgekupfert von Gimmick & Aragorn      |
* |                                             |
* | fertiggestellt:                             |
* | am 10. Februar 2009 um 18�� Uhr             |
* |                                             |
* | Benutzung, Ver�nderungen, Versch�nerungen,  |
* | oder auch eigene Anpassungen sind erlaubt,  |
* | solange dieser Header inkl. Einbauanleitung |
* | beibehalten wird und die Datei im Source    | 
* | offen gehalten wird.                        |
* |                                             |
* | Changelog:                                  |
* |                                             |
* �����������������������������������������������
* 
* Eigene Ver�nderungen d�rfen ab hier
* gekennzeichnet werden:
* _______________________________________________ 
* | Author:                                     |
* | Changed:                                    |
* | Date:                                       |
* �����������������������������������������������
* 
**/

/**
*
* Einbauanleitung:
* 
* Um dieses Addon zu verwenden sind einige �nderungen notwendig.
* Als erstes pr�f die Einstellungen unten und pass sie gegebenfalls an Deinen Server an
* Danach lade die Datei in den Root von Deinem LoGD, sobald das geschehen ist, verlinke
* das Hafenviertel folgendermassen am Ort Deiner Wahl:
* 
* addnav("Hafenviertel","hafen.php");
* 
* falls noch nicht geschehen, beachte die Einbauanleitung in der schiffe.php
* 
* Ich w�nsche Dir viel Spass mit Deinem neuen Hafenviertel
* 
*/


require_once "common.php";
checkday(); 
page_header("Hafenviertel");

// bestimmen der Navigation
$ziel = 'Jardelna';
$zfile = 'hafen.php';
$ort = 'Gypserra';
$ortid = '4';
$ofile = 'gypserra_hafen.php';
$herk = 'zur�ck ins Dorf';
$hfile = 'gypserra.php';

// setzen der Arrays f�r die Schiffe und die ben�tigten Waldk�mpfe 
$runden = array(0 => "5",1 => "4",2 => "3",3 => "2",4 => "1",5 => "0");
$sname = array(0 => "Keins",1 => "Dein Floss",2 => "Dein Hausboot",3 => "Deine Dschunke",4 => "Deine Galeere",5 => "Deine Galeone");

// Zufallsevents an und ausschalten
$randomeffects = '1';

// bestimmen verschiedener Werte
$u = $session['user'];
$name = $u['name'];
$round = $runden[$u['schiff']];

// festlegen der Bildnamen
$pic = './images/gypserra_hafen.jpg';
$schiff = array(0 => "Keins",1 => "floss",2 => "hausboot",3 => "dschunke",4 => "galeere",5 => "galeone");
$schiffpic = "./images/".$schiff[$u['schiff']].".jpg";

output("`^`c`bHafenviertel`b`c`6");
addnav("Hafenviertel");
if ($_GET['op']==""){    
    if (is_file($pic)) { output('<div align="center"><img border="0" src="'.$pic.'" alt="der Hafen"></div>`n`n'); }
    output ("`cDu verl�sst das Dorf Richtung Hafen, vor Dir erstreckt sich ein langer Strand. Links davon siehst Du eine kleine Werft in der Du Dir ein eigenes Schiff kaufen kannst, weiter rechts liegt am Kai ein altes, 
            vergammeltes Schiff, welches Du auch f�r die �berfahrt nach ".$ziel." mieten kannst. Vor dem Schiff steht ein kleines Schild, wodrauf Du erkennen kannst, das Dich eine �berfahrt 750 Goldst�cke kosten w�rde, 
            desweiteren w�rde der Kapit�n eine lange Route fahren, so das Du 10 Waldk�mpfe einb�ssen m�sstest, bis Du endlich in ".$ziel." angekommen bist.`n`n`c 
    ");
    if ($u['schiffstatus']<1) {
        $session['user']['schiff']=0;
        output("Als Du am Hafen ankommst bemerkst Du den j�mmerlichen Zustand Deines Schiffes, da kann Dir selbst in der Werft niemand mehr helfen. Du wirst Dir wohl ein neues Schiff kaufen m�ssen.
                H�ttest Du mal besser aufgepasst und das Schiff rechtzeitig reparieren lassen
        ");
    }
    if ($u['schiff']>0) { addnav("nach $ziel","$ofile?op=schiff"); }
    else { addnav ("nach $ziel","$ofile?op=kahn"); }
    addnav("Umgebung");
    addnav("$herk","$hfile"); 
}
if ($_GET['op']=="schiff"){
    
    if ($u['turns']>$round){
        if (is_file($schiffpic)) { output('<div align="center"><img border="0" src="'.$schiffpic.'" alt="Dein Schiff"></div>`n`n'); }
        output ("Du betrittst Dein Schiff und machst Dich auf die Reise nach ".$ziel.", voller Hoffnung das die �berfahrt problemlos ablaufen wird verziehst Du Dich in Deine Kaj�te und legst 
                Dich ersch�pft in Deine Koje. Gerade als Du in den sch�nsten Tr�umen bist ist die Fahrt auch schon zu Ende.");
        addnav ("nach $ziel","$zfile?op=arrive");
        addnav("Zur�ck zum Hafen","$ofile");
        $session['user']['turns']-=$round;
    }
    else {
        output ("Du bist zu ersch�pft um zu verreisen, ruh Dich lieber noch etwas aus.");
        addnav("Zur�ck zum Hafen","$ofile");
    }    
}
if ($_GET['op']=="kahn"){
    if ($session['user']['gold']>749){
        if ($session['user']['turns']>10){
        output ("`yDu steigst auf den alten Kahn der Dich nach ".$ziel." bringt und suchst Dir ein gem�tliches Pl�tzchen zum ausruhen, wohlwissend das diese �berfahrt etwas l�nger dauern wird.
                Ersch�pft von den vielen K�mpfen und Reisen schl�fst Du auf Deck ein und wirst vom Kapit�n des Schiffes unsanft aus Deinen Tr�umen gerissen. Ihr seid endlich angekommen`n");
        addnav ("$ziel","$zfile?op=arrive");
        $session['user']['gold']-=750;
        $session['user']['turns']-=10;
        }
        else {
            output("Du bist zu ersch�pft um nach ".$ziel." Reisen zu k�nnen, Ruhe Dich etwas aus und komme dann wieder");
            addnav("zum Hafen","$ofile");
            addnav("$herk","$hfile");
        }
    }
    else {
        output("F�r Umsonst nimmt Dich niemand mit nach ".$ziel.", sieh zu das Du den Kapit�n bezahlen kannst oder bleib wo der Pfeffer w�chst");
        addnav("$herk","$hfile");
    }
}
if ($_GET['op']=="arrive"){
    $rand = e_rand(1,8);
    $session['user']['schiffstatus']-=1;
    if ($rand==3) {
            $pic = './images/schiff_unruhe.jpg';
            if (is_file($schiffpic)) { output('<div align="center"><img border="0" src="'.$pic.'" alt="Tumult an Deck"></div>`n`n'); }
            output("Deine Reise wird durch eine grosse Aufruhr an Deck j�h unterbrochen, alle scheinen wild schreiend durcheinander zu laufen. M�de und genervt st�rmst Du an Deck um zu schauen was dort los ist",true);
            addnav("an Deck","$ofile?op=event");
    } else {
        $pic = './images/ankunft2.jpg';
        if (is_file($schiffpic)) { output('<div align="center"><img border="0" src="'.$pic.'" alt="Ankunft"></div>`n`n'); }
        output("Deine Reise verlief ohne gr�ssere Komplkationen, gut erholt und den Dingen harrend die da kommen werden verl�sst Du das Schiff und erkundest die Umgebung",true);
        addnav("Schiff verlassen","$ofile");
        $session['user']['location']=$ortid;
    }
}

if ($_GET['op']=="event"){
    switch (e_rand(1,10)) {
        case 1:
            $pic = './images/schiff_ungeheuer.jpg';
            if (is_file($schiffpic)) { output('<div align="center"><img border="0" src="'.$pic.'" alt="ein Monster"></div>`n`n'); }
            switch (e_rand(1,2)) {
                case 1:                    
                    $schaden = e_rand(2,10);                    
                    output("Du st�rmst an Deck und erstarrst f�r eine Weile...  
                            vor Deinem Schiff hat sich eine riesige Ungestalt aufget�rmt und versucht Dein Schiff zu zerschmettern.  
                            Schnell treibat Du Deine Mannschaft zusammen und mit letzter Kraft und gerade noch rechtzeitig k�nnt Ih der Gefahr entkommen.
                            Leider m�sst Ihr nun einen Umweg fahren der Dich 3 Waldk�mpfe kosten wird und durch die harte Nacht leidet auch Deine Gesundheit,
                            so da� Du einiges an Lebenspunkten verlierst. ",true);
                    $session['user']['schiffstatus']-=$schaden;
                    if ($session['user']['schiffstatus']>0) {
                            output("Dein Schiff wurde um ".$schaden."% besch�digt.",true);
                    }
                    else {
                            output("Dein Schiff wurde dabei vollst�ndig zerst�rt. Du musst weiter schwimmen",true);
                            $session['user']['schiff']=0;   
                    }
                    $session['user']['hitpoints']*=0.85;
                    $session['user']['turns']-=3;
                    addnav("nach $ort","$ofile");
                break;
                case 2:
                    $schaden = e_rand(10,15);
                    output("Du st�rmst an Deck und erstarrst f�r eine Weile...  
                            vor Deinem Schiff hat sich eine riesige Ungestalt aufget�rmt und versucht Dein Schiff zu zerschmettern.  
                            Du rufst Deine Mannschaft zusammen und versuchst gemeinsam mit ihr das Monster zu bek�mpfen, mit allen Mitteln greift Ihr das Monster an
                            welches sich auf Dich st�rzt und mit einem schnellen Biss erledigt... Du bist tot und kannst Ramius nun von diesem schrecklichen
                            Ungeheuer berichten, Du hast dabei Dein ganzes Gold verloren ",true);
                    $session['user']['schiffstatus']-=$schaden;
                    if ($session['user']['schiffstatus']>0) {
                            output("und Dein Schiff hat dabei ziemlich an Schaden genommen, welches mit letzter 
                            Kraft von den letzten verbliebenen Matrosen zur�ck in den Hafen gebracht wurde",true);
                    }
                    else {
                            output("und Dein Schiff wurde dabei vollst�ndig zerst�rt.",true);
                            $session['user']['schiff']=0;   
                    }
                    addnews("Bei der �berfahrt nach ".$ort." wurde ".$name." zu einem Snack f�r ein Seeungeheuer");
                    $session['user']['gold']=0;
                    $session['user']['hitpoints']=0;
                    redirect("shades.php");
                break;
            }
        break;        
        case 2:
            $pic = './images/schiff_unwetter.jpg';
            $schaden = e_rand(3,7);
            if (is_file($schiffpic)) { output('<div align="center"><img border="0" src="'.$pic.'" alt="ein Unwetter"></div>`n`n'); }
            output("Du st�rmst an Deck und erstarrst f�r eine Weile...  
             Ein riesiges Unwetter hat sich am Himmel zusammengezogen, schnell pfeifst Du Deine Mannschaft zusammen,
             um eine Katastrophe zu vermeiden l�sst Du alle Segel einziehen und die st�rksten M�nner an die Ruder gehen.
             Durch diese Verz�gerung und den enormen Kraftaufwand verz�gert sich Deine fahrt um einige Tage, so da� Du
             5 Waldk�mpfe und einiges an Energie verlierst. ",true);
            $session['user']['schiffstatus']-=$schaden;
            if ($session['user']['schiffstatus']>0) {
                output("Dein Schiff wurde um ".$schaden."% besch�digt.",true);
            }
            else {
                output("Dein Schiff wurde dabei vollst�ndig zerst�rt. Du musst weiter schwimmen",true);
                $session['user']['schiff']=0;   
            }
            $session['user']['hitpoints']*=0.75;
            $session['user']['turns']-=5;
            addnav("nach $ort","$ofile");
        break;
        case 3:
            $pic = './images/schiff_piraten.jpg';
            $schaden = e_rand(2,5);
            if (is_file($schiffpic)) { output('<div align="center"><img border="0" src="'.$pic.'" alt="Piratenangriff"></div>`n`n'); }
            output("Du st�rmst an Deck und erstarrst f�r eine Weile...  
             Schnell erkennst Du den Grund der Panik die ausgebrochen ist, Piraten setzen gerade an Dein Schiff zu Entern. 
             Entschlossen greifst Du zur Waffe und weist Deine Leute an bis zum letzten zu k�mpfen. Nach einigen Stunden 
             harter und unerbittlicher K�mpfe gelingt es Euch die Piraten zur�ckzuschlagen und die Reise fortzusetzen. 
             Dennoch hat Dich dieses Erlebnis einige Zeit und Energie gekostet. Aber Gl�ck im Ungl�ck, einer der Piraten hat 
             seinen Beutel verloren, in dem Du 10000 Gold und 5 Edelsteine findest. ",true);
            $session['user']['schiffstatus']-=$schaden;
            if ($session['user']['schiffstatus']>0) {
                output("Dein Schiff wurde um ".$schaden."% besch�digt.",true);
            }
            else {
                output("Dein Schiff wurde dabei vollst�ndig zerst�rt. Du musst weiter schwimmen",true);
                $session['user']['schiff']=0;   
            }
            $session['user']['hitpoints']*=0.50;
            $session['user']['turns']-=2;
            $session['user']['gold']+=10000;
            $session['user']['gems']+=5;
            addnav("nach $ort","$ofile");
        break;
        case 4:
            $pic = './images/schiff_untergang.jpg';
            $schaden = e_rand(5,15);
            if (is_file($schiffpic)) { output('<div align="center"><img border="0" src="'.$pic.'" alt="Dein Schiff geht unter"></div>`n`n'); }
            output("Du st�rmst an Deck und erstarrst f�r eine Weile...  
             Voller entsetzen musst Du feststellen, da� ihr mit irgendetwas grossem zusammengestossen seid. Bewegungsuntauglich liegt Dein Schiff
             kurz vor der Insel fest und kann nicht mehr weiter fahren. Wutschnaubend rennst Du zum Kapit�n und verlangst eine Erkl�rung daf�r. 
             Da Du den letzten Rest nun schwimmen musst, kostet Dich das ganze erheblich an Zeit und Kraft, um das Schiff k�mmert sich der Kaipt�n.
             So das es f�r Deine R�ckreise wieder im Hafen liegt. ",true);
            $session['user']['schiffstatus']-=$schaden;
            if ($session['user']['schiffstatus']>0) {
                output("Dein Schiff wurde um ".$schaden."% besch�digt.",true);
            }
            else {
                output("Dein Schiff wurde dabei vollst�ndig zerst�rt. Du musst weiter schwimmen",true);
                $session['user']['schiff']=0;   
            }
            $session['user']['hitpoints']*=0.25;
            $session['user']['turns']-=10;
            addnav("nach $ort","$ofile");
        break;
        case 5:
            $pic = './images/schiff_notfall.jpg';
            if (is_file($schiffpic)) { output('<div align="center"><img border="0" src="'.$pic.'" alt="eine Hilfsaktion"></div>`n`n'); }
            output("Als Du gerade nach dem rechten sehen willst, wirst Du beinahe von einem Matrosen umgerannt, der mit einem Rettungsring in Richtung Bug l�uft, 
                wie Du dort abgekommen bist, siehst Du ein kleines Boot mitten auf dem Meer treiben, voll mit Leuten die irgendwo Schiffbruch erlitten haben m�ssen.
                Du reagierst prompt, schnappst Dir ebenfalls einen Rettungsring und springst ins Wasser. Dort schwimmst Du unverz�glich zum rumtreibenden Boot und
                k�mmerst Dich um die notleidenden und hilfst ihnen auf das Schiff. Sp�ter erf�hrst Du das Du soeben den Sohn des K�nigs gerettet hast. �berrascht 
                von Deinem Mut und Deiner Hilfsbereitschaft �berreicht er Dir einen schweren Beutel, in dem Du 25000 Gold und 25 Edelsteine entdeckst. 
                Die ganze Hilfsaktion hat Dich leider ein bisschen Zeit gekostet.",true);
            $session['user']['turns']-=2;
            $session['user']['gold']+=25000;
            $session['user']['gems']+=25;
            addnav("nach $ort","$ofile");
        break;
        case 6:
            $pic = './images/nahrungknapp.jpg';
            if (is_file($schiffpic)) { output('<div align="center"><img border="0" src="'.$pic.'" alt="Nahrung ist knapp"></div>`n`n'); }
            output("Als Du verschlafen auf Deck ankommst siehst Du wie Deine Mannschaft M�de und tr�ge und mit knurrenden M�gen an Bord dahinsiecht. Unsere Nahrung ist verdorben
                    Sir, wir m�ssen schnell einen Zwischenstop einlegen und neue Nahrung an Bord nehmen. Dieses Zwischenfall wird Dich 25000 Gold und weitere 5 Waldk�mpfe kosten",true);
            $session['user']['turns']-=5;
            $session['user']['goldinbank']-=25000;
            addnav("nach $ort","$ofile");
        break;        
        case 7:
            $pic = './images/flaute.jpg';
            if (is_file($schiffpic)) { output('<div align="center"><img border="0" src="'.$pic.'" alt="eine Flaute"></div>`n`n'); }
            output("Als Du am Deck ankommst siehst Du Deine Mannschaft verzweifelt rumsitzen, Sir wir haben schon seit 2 Tagen kein laues L�ftchen mehr gehabt. Wenn das so weiter geht
                    werden uns bald die Vorr�te ausgehen. Kurzerhand beschliesst Du, da� die Mannschaft erstmal Rudern soll, wovon diese scheinbar garnicht begeistert ist. Du verlierst
                    dadurch 5 Runden und musst der Mannschaft zum Dank eine Feier spendieren, die Dich 25000 Gold und 5 Edelsteine kostet.",true);
            $session['user']['turns']-=5;
            $session['user']['goldinbank']-=25000;
            $session['user']['gems']-=5;
            addnav("nach $ort","$ofile");
        break;        
        case 8:
            $pic = './images/meuterei.jpg';
            if (is_file($schiffpic)) { output('<div align="center"><img border="0" src="'.$pic.'" alt="eine Meuterei"></div>`n`n'); }
            output("Als Du am Deck ankommst erwarten Dich Deine Matrosen schon, kurzerhand binden sie Dich am grossen Mast fest und erkl�ren Dir, das sie sich f�r die kleine Heuer nicht
                    l�nger ausbeuten lassen. Nach 2 Tagen z�her Verhandlungen befreien Sie Dich und ihr kommt mit erheblicher Versp�tung am Ziel an. Das ganze hat Dich einiges an Kraft,
                    45000 Gold und 10 Edelsteine gekostet.",true);
            $session['user']['hitpoints']*=0.75;
            $session['user']['turns']-=5;
            $session['user']['goldinbank']-=45000;
            $session['user']['gemsinbank']-=10;
            addnav("nach $ort","$ofile");
        break;        
        case 9:
            $pic = './images/seuche.jpg';
            if (is_file($schiffpic)) { output('<div align="center"><img border="0" src="'.$pic.'" alt="eine Seuche"></div>`n`n'); }
            output("Als Du gerade nach dem rechten sehen willst, bemerkst Du �berall kranke und kreidebleiche Matrosen rumliegen. Ihr habt eine Seuche an Bord die wohl durch verdorbene
                    Lebensmittel ausgel�st wurde. Mit letzter Kraft und erheblicher Versp�tung kommt Ihr endlich am Hafen an, wo Du sofort �rzte auf das Schiff kommen l�sst die sich um
                    die Leute k�mmern. Das ganze kostet Dich 2 Waldk�mpfe, 25000 Gold und 5 Edelsteine f�r die Behandlung der Leute.",true);
            $session['user']['turns']-=2;
            $session['user']['gold']-=25000;
            $session['user']['gems']-=5;
            addnav("nach $ort","$ofile");
        break;
        case 10:
            $pic = './images/schatzinsel.jpg';
            if (is_file($pic)) { output('<div align="center"><img border="0" src="'.$pic.'" alt="eine Schatzinsel"></div>`n`n'); }
            output("Als Du gerade nach dem rechten sehen willst, siehst Du wie die gesamte Schiffsbesatzung in heller Aufruhr auf dem Deck ruml�uft. Sir, ruft einer
                    schaut nur da vorn, das ist die Sagenumwobene Insel der Piraten, dort verstecken sie all Ihre Beute. Diese kleine Verz�gerung nimmst Du gern in kauf
                    und steuerst auf die kleine Insel zu. Dort angekommen entdeckst Du eine riesige Schatztruhe. In ihr befinden sich 50000 Gold und 25 Edelsteine",true);
            $session['user']['turns']-=2;
            $session['user']['gold']+=50000;
            $session['user']['gems']+=25;
            addnav("nach $ort","$ofile");
        break;
    }
}

page_footer(); 
?> 