<?php
/**
* _______________________________________________
* | werft.php: eine Werft f�r eigene Schiffe    |
* | geh�rt zum Hafenviertel �2009 by Liath      |
* |                                             |
* | mit diesem Addon kann man eine Werft am     |
* | Hafen verlinken, in der man Schiffe:        |
* | kaufen, verkaufen und reparieren kann       |
* |                                             |
* | �2009 by Liath www.germany-project.de/logd  |
* | programmiert in der LoGD DragonSlayer 2.5   |
* |                                             |
* | fertiggestellt:                             |
* | am 10. Februar 2009 um 17�� Uhr             |
* |                                             |
* | Benutzung, Ver�nderungen, Versch�nerungen,  |
* | oder auch eigene Anpassungen sind erlaubt,  |
* | solange dieser Header inkl. Einbauanleitung |
* | beibehalten wird und die Datei im Source    | 
* | offen gehalten wird.                        |
* |                                             |
* | Changelog:                                  |
* |                                             |
* �����������������������������������������������
* 
* Eigene Ver�nderungen d�rfen ab hier
* gekennzeichnet werden:
* _______________________________________________ 
* | Author:                                     |
* | Changed:                                    |
* | Date:                                       |
* �����������������������������������������������
* 
**/

/**
 
* Einbauanleitung:
* 
* Um dieses Addon zu verwenden sind einige �nderungen notwendig.
* Als erstes pr�f die Einstellungen unten und pass sie gegebenfalls an Deinen Server an
* Danach lade die Datei in den Root von Deinem LoGD, sobald das geschehen ist, erstelle
* in der Datenbank mit folgendem SQL Befehl die notwendigen Eintr�ge:
* 
* ALTER TABLE `accounts` ADD `schiff` int(11) unsigned NOT NULL default '0';
* ALTER TABLE `accounts` ADD `schiffstatus` int(11) unsigned NOT NULL default '0';
* 
* danach �ffne die dragon.php und such 2x nach ,"gems"=>1 danach trag folgendes beide male ein: 
* ,"schiff"=>1
* ,"schiffstatus"=>1
* 
* als n�chstes kommt die Eintragung in die Vitalinfo:
* 
* ich glaube in der Standard anpera 0.9.7. ext ist das die common.php in der DS 2.5 ist das die /lib/output.lib.php
* 
* dort suche nach: 
* .templatereplace('statrow',array('title'=>'R�stung','value'=>$u['armor']))
* 
* trage darunter ein:
* .templatereplace("statrow",array("title"=>"Schiff (".$schiffstatus."%)","value"=>"".$schiffe[$u['schiff']]."".'<br>'.grafbar(100,$schiffstatus)))
* 
* Datei speichern, hochladen fertig
* 
* Jetzt musst Du die hafen.php �ffnen, Anleitung beachten, die Einstellungen anpassen, speichern und hochladen
* 
* Ich w�nsche Dir viel Spass mit Deinem neuen Hafenviertel
* 
*/

require_once "common.php";
page_header("Die Werft");
checkday();

// Festlegen der Einkaufspreise
$flossgold = 25000; // Floss
$flossgems = 10;
$habogold = 75000; // Hausboot
$habogems = 25;
$dschgold = 100000; // Dschunke
$dschgems = 35;
$galgold = 200000; // Galeere
$galgems = 50;
$gaogold = 250000; // Galeone
$gaogems = 75;

// Festlegen der Prozents�tze zur Ermittlung des Restverkaufswertes und der Reparaturkosten
$verkauf = .75;
$reparatur = .01;

// Festlegen der Bilddateinamen f�r die Schiffe (Endung .jpg wird automatisch angef�gt)
$schiffpic = array(1 => "floss",2 => "hausboot",3 => "dschunke",4 => "galeere",5 => "galeone");

// Bestimmung des Accountnamens, der Anrede und des Geschlechts
$u = $session['user'];
$anr = ($u['sex']?"`gWerte`7":"`gWerter`7");
$name = $u['name'];

// festlegen und berechnen verschiedener Werte (nicht �ndern)
$schiff = array(1 => "ein Floss",2 => "ein Hausboot",3 => "eine Dschunke",4 => "eine Galeere",5 => "eine Galeone");
$gokosten = array(1 => $flossgold,2 => $habogold,3 => $dschgold,4 => $galgold,5 => $gaogold);
$gekosten = array(1 => $flossgems,2 => $habogems,3 => $dschgems,4 => $galgems,5 => $gaogems);
$rgo = round(((($gokosten[$u['schiff']]*$reparatur)/100)*$u['schiffstatus']),0);
$rge = round(((($gekosten[$u['schiff']]*$reparatur)/100)*$u['schiffstatus']),0);
$vgo = round(((($gokosten[$u['schiff']]*$verkauf)/100)*$u['schiffstatus']),0);
$vge = round(((($gekosten[$u['schiff']]*$verkauf)/100)*$u['schiffstatus']),0);


if ($_GET['op']==""){
    
    $pic = './images/werft.jpg';
    if (is_file($pic)) { output('<div align="center"><img border="0" src="'.$pic.'" alt="die Werft"></div>`n`n'); }
    output('`c`7Du betrittst die kleine Werft am Ende des Hafens, hier bist Du am richtigen Ort falls Du die Reisen auf dem alten Kahn leid bist und Dir ein eigenes anst�ndiges Schiff zulegen willst.`c`n`n');
    output("Hinter Dir siehst Du eine Preistafel h�ngen:`n`n
            `b`7Verkauf:`b`n
            `7kleines Floss: `t".$gokosten[1]." Gold `7und `4".$gekosten[1]." Edelsteine`n
            `7schickes Hausboot: `t".$gokosten[2]." Gold `7und `4".$gekosten[2]." Edelsteine`n
            `7pr�chtige Dschunke: `t".$gokosten[3]." Gold `7und `4".$gekosten[3]." Edelsteine`n
            `7grosse Galeere: `t".$gokosten[4]." Gold `7und `4".$gekosten[4]." Edelsteine`n
            `7riesige Galeone: `t".$gokosten[5]." Gold `7und `4".$gekosten[5]." Edelsteine`n`n
    ");
    if (!$u['schiff']){
        
	    addnav("Schiffe kaufen");
    	addnav("Floss", "werft.php?op=kauf&id=1");
	    addnav("Hausboot", "werft.php?op=kauf&id=2");
    	addnav("Dschunke", "werft.php?op=kauf&id=3");
    	addnav("Galeere", "werft.php?op=kauf&id=4");
	    addnav("Galeone", "werft.php?op=kauf&id=5");
	} 
    else {
        
        output("`7Der Werftleiter begr�sst Dich freundlich: `dSeid mir Willkommen ".$anr." ".$name.", `dwie ich sehe besitzt Ihr bereits `g".$schiff[$u['schiff']]."`7. 
                Schnell schreibt der Werftleiter folgendes Angebot auf einen Zettel und h�lt ihn Dir unter die Nase:`n`n");
        output("`tAnkauf: `t".$vgo." Gold `7und `4".$vge." Edelsteine`n");
        if ($u['schiffstatus']<100) { output("`tReparatur: `t".$rgo." Gold `7und `4".$rge." Edelsteine`n"); }
                
        addnav("Dein Schiff");
		addnav("Schiff verkaufen","werft.php?op=sell");
        if ($u['schiffstatus']<100) {
            addnav("Schiff reparieren","werft.php?op=rep");
        }
	}
    addnav("Zur�ck");
    addnav("Zur�ck zum Hafen","hafen.php");

}
else if ($_GET['op']=="kauf") {
    if ($u['gold']>=$gokosten[$_GET['id']] && $u['gems']>=$gekosten[$_GET['id']]) {
	    if ($_GET['id']=="1") {
            $pic = './images/'.$schiffpic[$_GET['id']].'.jpg';
            if (is_file($pic)) { output('<div align="center"><img border="0" src="'.$pic.'" alt="'.$schiff[$_GET['id']].'"></div>`n`n'); }
			output("`7Der Werftleiter zieht Dich zu einem alten verrotteten Floss und l�chelt verschmitzt. `dIst das nicht ein Prachtexemplar? Genau das richtige f�r Sie.");
            output("");
        }
	    else if ($_GET['id']=="2") {
            $pic = './images/'.$schiffpic[$_GET['id']].'.jpg';
            if (is_file($pic)) { output('<div align="center"><img border="0" src="'.$pic.'" alt="'.$schiff[$_GET['id']].'"></div>`n`n'); }
			output("`7Der Werftleiter zieht Dich zu einem kleinen schicken Hausboot, ganz aus dem feinsten Holz gebaut. `dDas w�re Ideal um sich von den Strapazen zu entspannen und in Ruhe auf Segelschaft zu gehen`7, meint er.");
        }
	    else if ($_GET['id']=="3") {
            $pic = './images/'.$schiffpic[$_GET['id']].'.jpg';
            if (is_file($pic)) { output('<div align="center"><img border="0" src="'.$pic.'" alt="'.$schiff[$_GET['id']].'"></div>`n`n'); }
			output("`7Der Werftleiter zieht Dich zu einer mittelgrossen Dschunke, `dDie ist in tadellosem Zustand und kaum gebraucht`7, bemerkt er. Tats�chlich sieht sie wirklich erstklassig aus.");
        }
	    else if ($_GET['id']=="4") {
            $pic = './images/'.$schiffpic[$_GET['id']].'.jpg';
            if (is_file($pic)) { output('<div align="center"><img border="0" src="'.$pic.'" alt="'.$schiff[$_GET['id']].'"></div>`n`n'); }
			output("`7Der Werftleiter zeigt Dir eine prachtvolle Galeere. `dDamit seid Ihr beinahe unbesiegbar, falls in den Meeren irgendwelche Gefahren auf Euch lauern sollten. `7Allerdings ist diese prachtvolle Galeere auch nicht grad billig wie Du bemerkst");
        }
	    elseif ($_GET['id']=="5") {
            $pic = './images/'.$schiffpic[$_GET['id']].'.jpg';
            if (is_file($pic)) { output('<div align="center"><img border="0" src="'.$pic.'" alt="'.$schiff[$_GET['id']].'"></div>`n`n'); }
			output("`7Der Werftleiter zieht Dich zu einer riesigen, umwerfend sch�nen Galeone. `dDies ist unser prachtvollstes Schiff merkt er an. Damit seid Ihr schnell und reist ausgesprochen komfortabel. Allerdings wird Euch dieses Schiff ein kleines Verm�gen kosten.");
        }
    }
    else {
        output("`7Es tut mir leid ".$anr." ".$name.", `7aber zu verschenken haben wir nichts. Bitte kommen Sie wieder wenn Sie gen�gend Gold und Edelsteine dabei haben um eins unserer Schiffe kaufen zu k�nnen.`n`n");
    }
    
    addnav("Schiff kaufen?");
    addnav("das nehm ich","werft.php?op=kaufok&id=".$_GET['id']);
    addnav("lieber nicht","werft.php");
    addnav("Zur�ck");
    addnav("Zur�ck zum Hafen","hafen.php");
}
else if ($_GET['op']=="kaufok") {
    
    $pic = './images/werft.jpg';
    if (is_file($pic)) { output('<div align="center"><img border="0" src="'.$pic.'" alt="die Werft"></div>`n`n'); }
    output("`7Schnell zieht der Werftleiter Dich in seinen kleinen Raum, wo er seine Buchhaltung f�hrt, kassiert die `t".$gokosten[$_GET['id']]." Gold `7und `4".$gekosten[$_GET['id']]." Edelsteine `7von Dir und �berreicht
            Dir eine Besitzurkunde �ber Dein neues Schiff. `dIch w�nsche Ihnen mit Ihrem neuen Schiff viel Vergn�gen ".$anr." ".$name." `7ruft er Dir hinterher, doch Du hast die Werft schon fast verlassen um Deine Neuerwerbung zu bestaunen.
    ");
    
    $session['user']['schiff']=$_GET['id'];
    $session['user']['schiffstatus']=100;
    $session['user']['gold']-=$gokosten[$_GET['id']];
    $session['user']['gems']-=$gekosten[$_GET['id']];
    
    addnav("Zur�ck");
    addnav("Zur�ck zur Werft","werft.php");
    addnav("Zur�ck zum Hafen","hafen.php");
}    
else if ($_GET['op']=="rep") {

    $schiff = array(1 => "Ihr Floss",2 => "Ihr Hausboot",3 => "Ihre Dschunke",4 => "Ihre Galeere",5 => "Ihre Galeone");
    $pic = './images/werft.jpg';
    if (is_file($pic)) { output('<div align="center"><img border="0" src="'.$pic.'" alt="die Werft"></div>`n`n'); }

    if ($u['gold']>=$rgo && $u['gold']>=$rge) {
        output("`7Sehr gerne, wir werden uns umgehend um `d".$schiff[$u['schiff']]." `7k�mmern ".$anr." ".$name.". `7Nicht lang und Sie werden `d".$schiff[$u['schiff']]." `7bald wieder voll nutzen k�nnen. Wie ich sehe haben sie den Preis von
                `t".$rgo." Gold `7und `4".$rge." Edelsteinen `7schon bezahlt. Sollten Sie bald wieder eine Reparatur ben�tigen, kommen Sie ruhig vorbei. 
        ");
        $session['user']['gold']-=$rgo;
        $session['user']['gems']-=$$rge;
        $session['user']['schiffstatus']=100; 
    }
    else {
        output("`7Tut mir leid ".$anr." ".$name." `7aber wenn Sie den Preis von `t".$rgo." Gold `7und `4".$rge." Edelsteinen `7f�r die Reparatur f�r `d".$schiff[$u['schiff']]." `7nicht bezahlen k�nnen, k�nnen wir Ihnen leider nicht weiter helfen.
                Bitte kommen Sie wieder wenn Sie genug Gold und Edelsteine dabei haben.
        ");
    }
    addnav("Zur�ck");
    addnav("zur Werft","werft.php");
    addnav("zum Hafen","hafen.php");
}
else if ($_GET['op']=="sell") {

    $schiff = array(1 => "Ihr Floss",2 => "Ihr Hausboot",3 => "Ihre Dschunke",4 => "Ihre Galeere",5 => "Ihre Galeone");
    $pic = './images/werft.jpg';
    if (is_file($pic)) { output('<div align="center"><img border="0" src="'.$pic.'" alt="die Werft"></div>`n`n'); }

    output("`7Guten Tag ".$anr." ".$name.", `7wie ich geh�rt habe m�chten Sie `d".$schiff[$u['schiff']]." `7wieder verkaufen. Es tut mir leid, wenn Sie damit nicht zufrieden waren, vielleicht kann ich Ihnen daf�r ja ein anderes Schiff anbieten.
            Schauen Sie sich ruhig um und sagen mir Bescheid, wenn ich noch etwas f�r Sie tun kann. Gehen Sie zum Bootsmann dort dr�ben, der wird Ihnen Ihre `t".$vgo." Gold `7und `4".$vge." Edelsteine `7sofort auszahlen. Bitte beehren Sie uns bald wieder.
    ");
    
    $session['user']['gold']+=$vgo;
    $session['user']['gems']+=$vge;
    $session['user']['schiff']=0;
    $session['user']['schiffstatus']=0;
    
    addnav("Zur�ck");
    addnav("zur Werft","werft.php");
    addnav("zum Hafen","hafen.php");
}

page_footer();
?>