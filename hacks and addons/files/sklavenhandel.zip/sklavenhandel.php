<?
//****************************************//
// Der Sklavenhandel			//
// Idee: Onepeople/Barra		//
// Umsetzung: Barra /Yasu			//
//www.nebelstadt.de		//
//****************************************//



require_once "common.php";
page_header("Der Sklavenhandel");
switch ($_GET['op']){
  case 'anbieten':
    $sql="SELECT * FROM accounts WHERE acctid =".$session['user']['slave'];
		$result = db_query($sql);
		$partner = db_fetch_assoc($result);
		addnav('weg hier','sklavenhandel.php');
    output("`n `t Der Sklavenhandel`n`n   Hier kannst du Deinen Sklaven ".$partner['name']."`t  zum verkauf  anbieten. 
    Aber sei dir bewusst dar�ber, das du das nicht ungeschehen machen kannst und deinen Sklaven auch nicht zur�ckkaufen kannst.
    `n Willst du deinen Sklaven wirklich verkaufen?
    `n
    `n
    `n
    `n<a href='sklavenhandel.php?op=ja'>`cJa ich will ".$partner['name']." verkaufen`c</a>
    `n<a href='sklavenhandel.php'> `cNein lieber Doch nicht`c</a>",true);
    addnav('','sklavenhandel.php?op=ja');
    addnav('','sklavenhandel.php');
  break;
  case 'ja':
    $sql="SELECT * FROM accounts WHERE acctid =".$session['user']['slave'];
		$result = db_query($sql);
		$partner = db_fetch_assoc($result);
    $right=$partner['rplevel'];
		$false=10;
		$points=($right*$false );
    $akt=$partner['kriegerlevel'];
    $val=($points * $akt);
    $preis = floor($points);

    output("`n`t Dein Sklave ".$partner['name']."`t hat ein Aktivit�tslevel von ".$partner['rplevel'].".
    `t Das heist, dein Sklave ist ".$preis." Edelsteine und ".$val."  Goldst�cke wert");

    $session['user']['gold']+=$val;
    $session['user']['gems']+=$preis;
    $session['user']['master']=0;
    $session['user']['slave']=0;
    $sql = "UPDATE accounts SET master='Marduk' WHERE acctid = ".$partner['acctid'];
    db_query($sql);
    $sql = "INSERT INTO marduk Values ('',".$partner['acctid'].",'".$partner['name']."','".$partner['login']."',".$partner['rplevel'].",".$partner['kriegerlevel'].")";
    db_query($sql);
    systemmail($partner['acctid']
    ,"`^Verkauft!`0"
    ,"`@".$session['user']['name']."`& hat Dich f�r ".$preis." Edelsteine und ".$val." Gold verkauft. Du geh�rst nun dem Sklavenh�ndler Marduk");
    addnav("weg hier","sklavenhandel.php");
  break;
  case 'kauf':
    $sql="SELECT * FROM marduk";
		$result = db_query($sql);
		$sklaven = db_fetch_assoc($result);
    $right=$sklaven['gempreis'];
		$false=10;
		$points=($right+$false );
    $akt=$sklaven['goldpreis'];
    $val=($points * $akt);
    $preis = floor($points);
    rawoutput("
    <table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999'>
    <tr class='trhead'><td><b>Name</b></td><td><b>Gempreis</b></td><td><b>Goldpreis</b></td>
    <tr class='".($i%2?"trdark":"trlight")."'><td>");
    
    $link="sklavenhandel.php?op=kauf2&char=".rawurlencode($sklaven['sid']);
    output("<a href='".$link."' >`^".$sklaven['sname']."</a>`0",true);   
    addnav("",$link);
    
    rawoutput("</td><td>");
    output("`^".$preis." Edelsteine`0");
    rawoutput("</td><td>");
    output("`^$val Gold`0");
    rawoutput("</td><td>
    </table>");
    
    addnav("Weg","sklavenhandel.php");
  break;
  case 'kauf2':
    $sql="SELECT * FROM marduk INNER JOIN accounts WHERE acctid=sid";
		$result = db_query($sql);
		$sklaven = db_fetch_assoc($result);
    $right=$sklaven['gempreis'];
		$false=10;
		$points=($right+$false );
    $akt=$sklaven['goldpreis'];
    $val=($points * $akt);
    $preis = floor($points);

    if($session['user']['gold']<$val ||$session['user']['gems']<$preis){
      output(" `n`n`y Das kannst du dir wohl nicht leisten");
    }else{
      $result = db_query("SELECT * FROM accounts INNER JOIN marduk WHERE sid=acctid");
      $row = db_fetch_assoc($result);

      $idmaster=$session['user']['acctid'];
      $idslave=$row['acctid'];

      output("`&Gratulation. Du hast ".$row['name']." erworben.");
      $session['user']['gold']-=$val;
      $session['user']['gems']-=$preis;
      $session['user']['master']=1;
      $session['user']['slave']=$idslave;

      systemmail($row['acctid']
      ,"`^Gekauft!`0"
      ,"`@".$session['user']['name']."`& hat dich vom Slavenh�ndler Marduk befreit. 
      Du bist damit dessen offizielles Eigentum ! Zum Zeichen deiner Sklavschaft wurde dir von der Inquisition ein Mal am Nacken gegeben, 
      sowie ein Armband das verhindert das du deinen Gebieter angreifst. 
      Es ist Dir fortan verboten, die offenen Pl�tze ohne die Anwesenheit deines Eigent�mers zu betreten, 
      das serum hat keinerlei Wirkung mehr auf Dich, sodass Inquisuitoren dich sofort bannen werden, sobald du gegen deine Auflagen verst�st.");
      $sql = "UPDATE accounts SET slave=1,master=".$idmaster.",erlaubniss=1 WHERE acctid = ".$row['acctid'];
      db_query($sql);
      $sql2 = "DELETE FROM marduk WHERE marduk.si` = ".$row['acctid'];
      db_query($sql2);
    }
    savesetting("amtskasse" ,getsetting("amtskasse",0)+ $val);
    addnav("Hehe","sklavenhandel.php");
  break;
  case 'beginn':
    $sql="SELECT * FROM accounts  WHERE acctid=".$session['user']['acctid'];
		$result = db_query($sql);
		$one = db_fetch_assoc($result);

    output(" Du hast dich entschlossen ein Leben in Sklavschaft in Yorlii Che el zu leben. 
    Diese Entcsheidung ist, falls du sie hioer best�tigst eine Entscheidung die nicht mehr R�ckg�ngig gemachht werden kann.
    `n
    `n Bis ein Eigent�umer f�r dich gefunden wurde, oder  du es dir leisten kannst eine Ausgangserlaubniss zu erwerben, 
    kannst du das Sklavenviertel nicht verlassen. Sobald du erworben wurdest,ist Dein Herr/Herrin f�r Dich verantwortlich. 
    Jener verteilt Ausgangserlaubniss oder Rundenspenden, etc.`n`n Bist du dir wirklich sicher das du ein Leben in Sklavschaft w�hlst?`n`n`n");
    addnav(" Ich bin sicher","sklavenhandel.php?op=sklaveja");
    addnav(" Lieber doch nicht","sklavenhandel.php?op=sklavenein");
  break;
  case 'sklaveja':
    $sql="SELECT * FROM accounts  WHERE acctid=".$session['user']['acctid'];
		$result = db_query($sql);
		$one = db_fetch_assoc($result);
    output("`n`n`y Du hast Dich f�r ein Leben in Sklavschaft entschieden,du f�hlst dich �lter als noch zu Beginn. 
    Du geh�rst bis dich jemand erwirbt dem Sklavenh�ndler Marduk. 
    Er ist ein grausamer Herr und f�hrt sein Regiment �ber die Sklaven mit harter Hand. ");
    $sql1 = "INSERT INTO marduk Values ('',".$one['acctid'].",'".$one['name']."','".$one['login']."',".$one['rplevel'].",".$one['kriegerlevel'].")";
    db_query($sql1);
    $session['user']['age']++;
    addnav(" Na gro�artig","sklavenhandel.php");
  break;
  case 'sklavenein':
    $session['user']['slave']=0;
    $session['user']['master']=0;
    output(" `n`n`y Du hast dich entschlossen, dein Leben nicht in Sklavschaft zu beginnen. ");
    if($session['user']['verbot']==1){
      output("`n`n`yDa du aber ein verbotenes Wesen laut Inquisition bist, musst Du immer damit Rechnen, 
      das man dein wahres ICH erkennt und Dich verr�t.`nDu bekommst eine Tarnung von 5 Tagen, danach musst du Dich selbst Tarnen. 
      Im Wohnviertel auf dem Schwarzmarkt findest du Dina, welche die Seren verkauft, welche Dein Leben bisweilen retten k�nnen.");
      $session['user']['tarn']=5;
    }
    addnav(" Nichts wie weg","village.php");
  break;
  case 'sklavenviertel':
    page_header(" Sklavenviertel");
    $session['user']['ort']='6';
    $session['user']['standort']='`X Das Sklavenviertel';
    output(" `c`n`b`y Das Sklavenviertel von Nebelstadt`b`c`n`n`nIn der Mitte eines gro�en Platyes findest du das Haus von Marduk dem Sklavenh�ndler, 
    bei ihm hast du deinen tribut yu entrichten und ihn kannst du um die Ausgangserlaubniss bitten,sobald du dich als w�rdig erwiesen hast.
    Palisaden umgibt dessen Langhaus und eine zerfallene Barake, in der die Sklaven sich zur Ruhe begeben.
    Wachen sorgen daf�r das keiner fliehen kann und nur allzuoft, vermag man die gepeinigten Schreie der ungehorsamen Sklaven h�ren,
    welche die Katze des Oberaufseherszu sp�ren bekommen.");
    addnav("Marduks Langhaus","sklavenhandel.php?op=marduk");
    addnav(" Gemeinschaftsbaraken","sklavenhandel.php?op=schlafen");
    addnav(" Sklavenviertel","sklavenhandel.php");
    if(!$session['user']['slave']==1 ||!$session['user']['erlaubniss']==0){
      addnav("Ins Dorf","village.php");
    }
    addcommentary();
    viewcommentary('sklavenviertel','Hinzuf�gen',25);
    page_footer();
  break;
  case 'marduk':
    page_header(" Marduks langhaus");
    output("`n`n`n`SMarduks Langhaus      
    `n`nPrunk und Reichtum zeugen vom Erfolg des Sklavenh�ndlers.
    K�rbe mit feinen Gew�rzen,Stapel mit feinen Stofen stehen entlang der W�nde,
    Peitschen und Ketten zeugen von der harten Hand des H�ndlers.`nHochgewachsen und schlank, steht Marduk vor die. 
    Z�ge wie aus stein gemei�elt, die rauhe Haut von der farbe poliiertten Holz, spricht Gerissenheit und K�lte aus dem tiefblauen Blick. 
    Du wei�t instinktiv,das du dich mit diesem hier,besser nicht anlegen solltest. 
    `XWas Willst du?`S ert�hnt rauh die Stimme des Sklavenhalters w�hrend er dich absch�tzend mustert.
    `n`nWas wirst du antworten?");
    if($session['user']['master']==1){
      addnav("Sklaven verkaufen","sklavenhandel.php?op=anbieten");
    }
    if($session['user']['master']==0 && $session['user']['slave']==0){
      addnav("Sklaven kaufen", "sklavenhandel.php?op=kauf");
    }
    if($session['user']['master']=="Marduk" && $session['user']['rpposts']>300 && $session['user']['gems']>9){
      addnav(" Ausgangserlaubniss einholen","sklavenhandel.php?op=erlaubniss");
    }

    addnav(" Nichts..","sklavenhandel.php?op=sklavenviertel");
    page_footer();
  break;
  case 'erlaubniss':
    output("`n`y Du kaufst dir f�r 10 Edelsteine eine Ausgangserlaubniss f�r einen Tag.`n`n");
    $session['user']['erlaubniss']=1;
    $session['user']['gems']-=10;
  break;
  case'schlafen':
    page_header("Barrake");
    output(" `n`n`y Die Gemeinschaftsbarrake der Sklaven. Hier essen, schlafen und bisweilen sterben die Waren des H�ndlers.`n`n");
    addcommentary();
    viewcommentary('gemein','Hinzuf�gen',25);
    addnav("L?Einschlafen (Log Out)","login.php?op=logout");
    addnav(" Zur�ck","sklavenhandel.php?=op=sklavenviertel");
    page_footer();
  break;
  default:
    page_header("Der Sklavenhandel");
    output("`y Der Sklavenmarkt`n`n Du betrittst den Eingang zum Sklavenviertel Yorlii Che'els. 
    Zwischen den Palisaden bahnst du dir einen Weg, vorbei an zwei kr�ftigen Wchen, an dessen G�rteln jeweils eine neunschw�nzige Katze zu finden ist. 
    Du musterst die beiden kurz und weist genau, das du dich mit denen Besser nicht anlegen solltest.
    `n`n`n`n`n`n");
    addcommentary();
    viewcommentary('handel_main','Hinzuf�gen',25);
    addnav("Zum Sklavenviertel","sklavenhandel.php?op=sklavenviertel");
    addnav("Zum Dorf","village.php");
    rawoutput("<a href='http://www.nebelstadt.de'>�by Barra von Nebelstadt</a>");
    $session['user']['standort']='`X Sklavenmarkt';
    $session['user']['ort']='6';
}


page_footer();
?>