ALTER TABLE `houses` ADD `level` SMALLINT DEFAULT 0;
ALTER TABLE `houses` ADD `ausbauten` VARCHAR( 255 ) NULL ;

INSERT INTO `settings`(`setting`,`value`) VALUES ('zimmerausnahmen','office schatz schlafzimmer');

CREATE TABLE `hauslevels` (
  `level` tinyint(3) unsigned NOT NULL auto_increment,
  `name` varchar(32) default NULL,
  `gold` mediumint(9) default NULL,
  `gems` smallint(6) default NULL,
  `keys` tinyint(4) default NULL,
  `goldchest` mediumint(9) default NULL,
  `gemschest` smallint(6) default NULL,
  `zimmer` smallint(6) unsigned default 0,
  PRIMARY KEY  (`level`),
  UNIQUE KEY `name` (`name`)
);

INSERT INTO `hauslevels` VALUES (1, '`TVerschlag`0', 0, 0, 3, 0, 15000, 25);
INSERT INTO `hauslevels` VALUES (2, '`2H�uschen`0', 1000, 2, 4, 1, 17500, 30);
INSERT INTO `hauslevels` VALUES (3, '`%Haus`0', 1500, 3, 5, 2, 22500, 35);
INSERT INTO `hauslevels` VALUES (4, '`QGeh�ft`0', 2500, 5, 7, 3, 27500, 45);
INSERT INTO `hauslevels` VALUES (5, '`vLandgut`0', 5000, 10, 9, 5, 35000, 60);
INSERT INTO `hauslevels` VALUES (6, '`4Schl�sschen`0', 10000, 20, 10, 7, 50000, 75);
INSERT INTO `hauslevels` VALUES (7, '`$Jagtschloss`0', 20000, 35, 12, 10, 75000, 100);

CREATE TABLE `zimmer` (
  `zimmerid` smallint(5) unsigned NOT NULL auto_increment,
  `name` varchar(32) default NULL,
  `link` varchar(128) default NULL,
  `label` varchar(32) NOT NULL,
  `level` tinyint(3) unsigned NOT NULL default '1',
  `aktiv` tinyint(3) unsigned NOT NULL default '0',
  `gold` mediumint unsigned not null default '0',
  `gems` smallint unsigned not null default '0',
  PRIMARY KEY  (`zimmerid`),
  UNIQUE KEY `label` (`label`)
) AUTO_INCREMENT=2 ;

INSERT INTO `zimmer` VALUES (1, 'gemeinschaftsraum', 'nhouses.php?op=drin&go=gemeinschaftsraum', 'Gemeinschaftsraum', 1, 1, 0, 0);