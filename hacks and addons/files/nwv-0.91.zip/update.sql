# update von 0.7 auf 0.8
ALTER TABLE `zimmer` ADD 
	`gold` MEDIUMINT UNSIGNED NOT NULL default '0';
ALTER TABLE `zimmer` ADD
	`gems` SMALLINT UNSIGNED NOT NULL default '0';

ALTER TABLE `hauslevels` ADD
	`zimmer` SMALLINT(6) UNSIGNED default 0;

ALTER TABLE `houses` ADD
	`ausbauten` VARCHAR( 255 ) NULL ;