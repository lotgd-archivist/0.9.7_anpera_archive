<?php
	// Zimmer.php - Hier kommen die Zimmer-Klassen der Module f�r das Wohnviertel hinein.
	// Die als "Basismodul" gekennzeichneten Klasen sollten nie entfernt werden - sie geh�ren zur Ausgangsversion!

	// Die Daten des aktuellen Hauses sind immer �ber $haus verf�gbar!
	// Mit $this->back l�sst sich die Navigation vereinfachen

define('KINDER',(bool) getsetting("kindermod",false));	// Wenn Kindermod installiert ist bitte in der nhmaster auf aktiv stellen!

class zimmer {
		// MASTER-KLASSE - NUR VER�NDERN WENN IHR EUCH WIRKLICH SICHER SEID!!!
	var $id, $name, $level, $label, $linker, $aktiv;
	var $gold = 0;
	var $gems = 0;

	function einlesen($daten) {
		$this->id			= $daten['zimmerid'];
		$this->name 	= $daten['name'];
		$this->linker	= $daten['link'];
		$this->label	= $daten['label'];
		$this->level	= $daten['level'];
		$this->aktiv	= $daten['aktiv'];
		$this->gold		= $daten['gold'];
		$this->gems		= $daten['gems'];
		if(empty($this->level)) $this->level = 0;
	}	// Ende Funktion

	function finddata($id) {
		$sql = "SELECT * FROM `zimmer` WHERE zimmerid = ".$id." LIMIT 1";
		$result = db_query($sql) or die(db_error(LINK));
		$this->einlesen(db_fetch_assoc($result));
	}	// Ende Funktion

	function adminausgabe() {
		$ausgabe  = "<form action='nhmaster.php?op=zimmerweiter&zimmer=".$this->id."' method='POST'>\n";
		$ausgabe .= "<table cellspacing=4 cellpadding=2><tr class='trhead'><td>Eigenschaft</td><td>Wert/Inhalt</td></tr>";
		$ausgabe .= "<tr class='trdark'><td>ID - Unver�nderbar!</td><td><div style='background-color=black; color=white; border=1px #CCCCCC solid;'>".$this->id."</div></td></tr>\n";
		$ausgabe .= "<tr class='trlight'><td>Name - Unver�nderbar!</td><td><div style='background-color=black; color=white; border=1px #CCCCCC solid;'>".$this->name."</div></td></tr>\n";
		$ausgabe .= "<tr class='trdark'><td>Link</td><td><input name='linker' size='40' value='".$this->linker."'></td></tr>\n";
		$ausgabe .= "<tr class='trlight'><td>Label</td><td><input name='label' size='32' maxlength='32' value='".$this->label."'></td></tr>\n";
		$ausgabe .= "<tr class='trdark'><td>Level</td><td><input name='level' size='3' value='".$this->level."'></td></tr>\n";
		$ausgabe .= "<tr class='trlight'><td>Aktiv</td><td><select name='aktiv'>\n<option ".($this->aktiv?"selected":"")." value='1'>Ja</option><option ".(!$this->aktiv?"selected":"")." value='0'>Nein</option></select></td></tr>\n";
		$ausgabe .= "<tr class='trdark'><td>Gold-Baukosten</td><td><input name='gold' size='6' maxlength='7' value='".$this->gold."'></td></tr>\n";
		$ausgabe .= "<tr class='trlight'><td>Gems-Baukosten</td><td><input name='gems' size='3' maxlength='4' value='".$this->gems."'></td></tr>\n";
		$ausgabe .= "<tr><td><input type='submit' value='Abschicken'></td><td><input type='reset' value='Zur�cksetzten'></td></tr>\n";
		$ausgabe .= "</table></form>\n";
		addnav("","nhmaster.php?op=zimmerweiter&zimmer=".$this->id);
		return $ausgabe;
	}
}	// Ende Klasse


class office extends zimmer {
	// B�ro zur �berwachung der Schl�ssel etc.
	// Basismodul!
	var $back;
		// Konstruktor
	function office() {
		$this->back ="nhouses.php?op=drin&go=".$_GET['go'];
		switch($_GET['act']) {
			case "upgrade": 	$this->upgrade();			break;
			case "goupgrade": $this->goupgrade();		break;
			case "takekey":		$this->takekey();			break;
			case "givekey":		$this->givekey();			break;
			case "rename":		$this->benennen(); 		break;
			case "desc":			$this->desc(); 				break;
			case "zimmerdrin":$this->zimmerdrin(); 	break;
			case "zimmerbau":	$this->zimmerbau(); 	break;
			case "abbau":			$this->abbau(); 			break;
			case "verkauf":		redirect("nhouses.php?op=verkaufen"); break;
			default: 					$this->basis();
		}	// Ende Switch
	}	// Ende Konstruktor

		// Methoden
	function basis() {
		global $session, $haus;
		if ($session['user']['acctid']==$haus->besitzerid){
			output("`2`b`c".$haus->name."`b, `&ein ".$haus->level->name."`&`n `bDein Arbeitszimmer`b `c`");
			output("`@Du gehst in dein Arbeitszimmer. Ein gro�er Schreibtisch steht inmitten des Raumes. Dahinter ein gro�er bequemer Sessel.`n");
			output("Sogleich setzt du dich hinein, siehst die Post durch und erledigst sonstige Verwaltungangelegenheiten des Hauses`n`n");
			output("`b`&Schatz�bersicht:`b `^Gold: ".$haus->gold." `2vorhanden, noch Platz f�r `^".schatz::goldleft()."`2;");
			output("`#Edelsteine: ".$haus->gems." `2vorhanden, noch Platz f�r `#".schatz::gemsleft()."`2`n`n");
			output("`2In deinem Haus befinden sich insgesammt `^".count($haus->ausbauten)."`2 zus�tzliche Zimmer - auf der aktuellen Stufe kannst du also noch `^");
			output($haus->level->zimmer - (count($haus->ausbauten))."`2 weitere Zimmer anbauen. `i`6(".count($haus->ausbauten)." von ".$haus->level->zimmer.")`i`0`n`n");
			$chat="Mit deinen Mietern besprechen";
				addnav("Das Haus");
					addnav("Haus ausbauen",$this->back."&act=upgrade");
					addnav("Haus umbenennen",$this->back."&act=rename");
					addnav("Beschreibung �ndern",$this->back."&act=desc");
					addnav("Haus verkaufen",$this->back."&act=verkauf");
				addnav("Die Zimmer");
					if(count($haus->ausbauten) > 0) addnav("Angebaute Zimmer",$this->back."&act=zimmerdrin");
					if(count($haus->ausbauten) < $haus->level->zimmer) addnav("Zimmer anbauen",$this->back."&act=zimmerbau");
				addnav("Die Bewohner");
					addnav("Einladen",$this->back."&act=givekey");
					addnav("n?Herauswerfen",$this->back."&act=takekey");
		}else{
			output("`2`b`c".$haus->name."`b, `&ein ".$haus->level->name."`&`n `bDas Arbeitszimmer des Hausbesitzers.`b `c`");
			output("`@Du gehst in dein Arbeitszimmer. Ein gro�er Schreibtisch steht inmitten des Raumes. Dahinter ein gro�er bequemer Sessel.`n");
			output("Mit Neid siehst du dich um. Dein Vermieter sitzt auf dem Sessel hinter dem Schreibtisch und sieht von einem Pergament auf, das er gerade gelesen hat");
			$chat="Mit dem Hausbesitzer besprechen";
		}
		viewcommentary("office-".$haus->id,"$chat:",30,"meint");
		output("`n`n`n<table border='0'><tr><td>`2`bDie Schl�ssel:`b `0</td></tr><tr><td valign='top'>",true);
		$sql = "SELECT items.*,accounts.acctid AS aid,accounts.name AS besitzer FROM items LEFT JOIN accounts ON accounts.acctid=items.owner WHERE value1=".$haus->id." AND class='Schl�ssel' ORDER BY id ASC";
		$result = db_query($sql) or die(db_error(LINK));
		for ($i=1;$i<=db_num_rows($result);$i++){
			$item = db_fetch_assoc($result);
			if ($item['besitzer']==""){
				output("`n`2".$i.": `4`iVerloren`i`0");
			}else{
				output("`n`2$i: `&".$item['besitzer']."`0");
			}
			if ($item['aid']==$haus->besitzerid) output(" (der Eigent�mer) ");
			if ($item['hvalue']>0 && $item['owner']>0) output(" `ischl�ft hier`i");
		}
		output("</td><tr></table>",true);
		addnav("Im Haus");
			addnav("Zur�ck zum Flur","nhouses.php?op=drin");
	}	// Ende Funktion

	function zimmerdrin() {
		global $haus;
		output("`2In deinem Haus befinden sich `^".count($haus->ausbauten)."`2 zus�tzliche Zimmer - auf der aktuellen Stufe kannst du also noch `^");
		output($haus->level->zimmer - (count($haus->ausbauten))."`2 weitere Zimmer anbauen. `i`6(".count($haus->ausbauten)." von ".$haus->level->zimmer.")`i`0`n");
		output("`^Folgende Zimmer sind bereits in diesem Haus gebaut:`0`n`n");
		output("<table border='1' cellspacing='2' cellpadding='2' align='center'><tr class='trhead'>
		<td>Nr</td><td>Name</td><td>Ab Level</td><td>Gold</td><td>Gems</td><td>ops</td></tr>",true);
		foreach($haus->ausbauten as $key=>$val) {
			$zimmer = new zimmer;
			$zimmer->finddata($val);
			$b = ($key%2==0?"trlight":"trdark");
			$c = ($key%2==0?"`9":"`^");
			output("<tr class='$b'><td>$c".$val."</td><td>$c".$zimmer->label."</td><td>$c".$zimmer->level."</td><td>$c".$zimmer->gold."</td><td>$c"
			.$zimmer->gems."</td><td><a href='".$this->back."&act=abbau&zid=".$zimmer->id."'>entfernen</td></tr>",true);
			addnav("",$this->back."&act=abbau&zid=".$zimmer->id);
		}
		output("</table>",true);
		if(count($haus->ausbauten) < $haus->level->zimmer) addnav("Zimmer anbauen",$this->back."&act=zimmerbau");
		addnav("Zur�ck ins Arbeitszimmer",$this->back);
	}	// Ende Funktion

	function zimmerbau() {
		global $haus, $session;
		if(empty($_GET['bau'])) {
			$sql = "SELECT * FROM `zimmer` WHERE aktiv = 1 ";
			for($i=0;$i< count($haus->ausbauten);$i++) {
				$sql .= "AND `zimmerid` <> ".$haus->ausbauten[$i]." ";
			}	// Ende FOR
			$result = db_query($sql) or die(db_error(LINK));
			if(db_num_rows($result) > 0) {
				output("`^Folgende Zimmer k�nnen noch angebaut werden:`n`n`0");
				output("<table border='1' cellspacing='2' cellpadding='2' align='center'><tr class='trhead'><td>Nr</td><td>Name</td><td>Gold</td><td>Gems</td><td>Ops</td></tr>",true);
				//output("<table border='1' cellspacing='2' cellpadding='2' align='center'><tr class='trhead'><td>Nr</td><td>Name</td><td>Ops</td></tr>",true);
				for($i=0;$i < db_num_rows($result);$i++) {
					$row = db_fetch_assoc($result);
					$zimmer = new zimmer;
					$zimmer->einlesen($row);
					$b = ($i%2==0?"trlight":"trdark");
					$c = ($i%2==0?"`9":"`^");
					output("<tr class='$b'><td>$c".$zimmer->id."</td><td>$c".$zimmer->label."</td><td>$c".$zimmer->gold."</td><td>$c".$zimmer->gems."</td><td><a href='".$this->back."&act=zimmerbau&bau=true&zid=".$zimmer->id."'>Bau</a></td></tr>",true);
					//output("<tr class='$b'><td>$c".$zimmer->id."</td><td>$c".$zimmer->label."</td><td><a href='".$this->back."&act=zimmerbau&bau=true&zid=".$zimmer->id."'>Bau</a></td></tr>",true);
					addnav("",$this->back."&act=zimmerbau&bau=true&zid=".$zimmer->id);
				}	// Ende FOR
				output("</table>",true);
			} else {
				output("Es stehen keine weiteren Ausbauten zur Verf�gung.");
			}	// Ende ELSE
		} else {
			$zimmer = new zimmer;
			$zimmer->finddata($_GET['zid']);
			if($session['user']['gold'] >= $zimmer->gold && $session['user']['gems'] >= $zimmer->gems) {
				output("`@Du baust das Zimmer ".$zimmer->label." in dein Haus ein!`n");
				if($zimmer->gold == 0 && $zimmer->gems == 0) {
					output("Da dieses Zimmer kostenlos ist, musst du nichts bezahlen!");
				} else {
					output("Daf�r bezahlst du `^".$zimmer->gold." Goldst�cke`@ und `#".$zimmer->gems." Edelsteine`0`n");
					$session['user']['gold'] -= $zimmer->gold;
					$session['user']['gems'] -= $zimmer->gems;
				}
				$haus->ausbauten[(count($haus->ausbauten)+1)] = $zimmer->id;
			}	else {
				output("`4Du hast leider nicht gen�gend Gold und/oder Edelsteine, um dieses Zimmer zu bauen!`0");
			}	// Ende ELSE
		}	// Ende ELSE
		addnav("Zur�ck ins Arbeitszimmer",$this->back);
	}	// Ende Funktion

	function abbau() {
		global $haus;
		if(empty($_GET['zid'])) redirect($this->back);
		if($_GET['validate'] == 'ja') {
			$zimmer = new zimmer;
			$zimmer->finddata($_GET['zid']);
			output("Das Zimmer `#\"".$zimmer->label."\" `6wird nun entfernt.");
			$key = array_search($_GET['zid'],$haus->ausbauten);
			unset($haus->ausbauten[$key]);
		} else {
			$zimmer = new zimmer;
			$zimmer->finddata($_GET['zid']);
			output("`6M�chtest du das Zimmmer `#\"".$zimmer->label."\" `6wirklich aus deinem Haus entfernen? Alle investierten Mittel gehen dann verloren!");
			addnav("Aktionen");
			addnav("Ja, entfernen!",$this->back."&act=abbau&zid=".$_GET['zid']."&validate=ja");
		}
		addnav("Zur�ck");
		addnav("Arbeitszimmer",$this->back);
	}	// Ende Funktion

	function desc() {
		global $haus;
		if (!$_POST['desc']){
			output("`2Hier kannst du die Beschreibung f�r dein Haus �ndern.`n`nDie aktuelle Beschreibung lautet:`0".$haus->text."`0`n");
			output("`0<form action='".$this->back."&act=desc' method='POST'>",true);
			output("`n`2Gebe eine Beschreibung f�r dein Haus ein:`n<input name='desc' maxlength='250' size='50'>`n",true);
			output("<input type='submit' class='button' value='Abschicken'>",true);
			addnav("",$this->back."&act=desc");
		}else{
			output("`2Die Beschreibung wurde ge�ndert.`n`0".stripslashes($_POST['desc'])."`2.");
			$haus->text = $_POST['desc'];
		}
		addnav("Zur�ck ins Arbeitszimmer",$this->back);
	}	// Ende Funktion

	function benennen() {
		global $session, $haus;
		if (!$_POST['housename']){
			output("`2Das Haus umbenennen kostet `^1000`2 Gold und `#1`2 Edelstein.`n`n");
			output("`0<form action='".$this->back."&act=rename' method='POST'>",true);
			output("`nGebe einen neuen Namen f�r dein Haus ein: <input name='housename' maxlength='25'>`n",true);
			output("<input type='submit' class='button' value='Umbenennen'>",true);
			addnav("",$this->back."&act=rename");
		}else{
			if ($session['user']['gold']<1000 || $session['user']['gems']<1){
				output("`2Das kannst du nicht bezahlen.");
			}else{
				output("`2Dein Haus `@".$haus->name."`2 hei�t jetzt `@".stripslashes($_POST['housename'])."`2.");
				$haus->name = $_POST['housename'];
				$session['user']['gold']-=1000;
				$session['user']['gems']-=1;
			}
		}
		addnav("Zur�ck zum Arbeitszimmer",$this->back);
	} // Ende Funktion

	function upgrade() {
		global $session, $haus;
		output("`c`b`@Hausausbau`b`c`n");
		output("`2Dein Haus hat das Level:`$ ".$haus->level->level."`2, damit ist es ein ".$haus->level->name."!`n");
		if($haus->level->level < ausbaustufe::levels()) {
			$next = new ausbaustufe($haus->level->level + 1);
			output("`6Der n�chste Ausbau w�rde also`$ ".$next->gold."`^ Gold`6 und `$ ".$next->gems." `^Edelsteine`6 kosten.`n");
			if($session['user']['gold']>=$next->gold && $session['user']['gems']>=$next->gems) {
				output("`@Du Hast genug `^Gold `@und `^Edelsteine`@ dabei, um dein Haus auf Stufe`$ ".$next->name." `@auszubauen!");
				addnav("Ausbau auf Stufe ".$next->level,$this->back."&act=goupgrade&von=user");
			} else {
				output("`4Aber leider hast du nicht genug dabei.");
			}
			if($haus->gold >= $next->gold && $haus->gems >= $next->gems) {
				output("`n`n`@Des weiteren w�ren im Haus gen�gend Goldst�cke und Edelsteine, um den Ausbau zu finanzieren.`n");
				addnav("Ausbau auf Stufe".$next->level." aus dem Hausschatz",$this->back."&act=goupgrade&von=haus");
			} else {
				output("`n`n`4Des weiteren w�ren im Haus leider nicht gen�gend Goldst�cke und Edelsteine.`n");
			}
		} else {
			output("`$ `bDamit hat es bis auf weiteres das maximale Level erreicht!`b");
		}
		addnav("Zur�ck ins Arbeitszimmer",$this->back);
	}	// Ende Funktion

	function goupgrade() {
		global $session, $haus;
		$next = new ausbaustufe($haus->level->level + 1);
		$addkeys=$next->keys - $haus->level->keys;
		output("`9Dein Haus wurde auf die Stufe`$ ".$next->name." `9Ausgebaut.`nEs hat jetzt neue Funktionen!`n");
		output("`9Nun kannst du zus�tzlich ".($next->zimmer - $haus->level->zimmer)." weitere Zimmer anbauen!`n`n");
		output("`^Au�erdem bekommst du`$ ".$addkeys." `^neue Schl�ssel!`n");
		if($_GET['von']=="haus") {
			output("Du bezahlst die Kosten direkt aus dem Hausschatz.");
			$haus->gold -= $next->gold;
			$haus->gems -= $next->gems;
		} else {
			output("Du bezahlst die Kosten von dem Verm�gen, das du bei dir tr�gst.");
			$session['user']['gold']-=$next->gold;
			$session['user']['gems']-=$next->gems;
		}
		for ($i=$haus->level->keys+1;$i < $next->keys;$i++){
			$sql = "INSERT INTO items (name,owner,class,value1,value2,gold,gems,description) VALUES ('Hausschl�ssel',".$haus->besitzerid.",'Schl�ssel',".$haus->id.",".$i.",0,0,'Schl�ssel f�r Haus Nummer ".$haus->id."')";
			db_query($sql);
			if (db_affected_rows(LINK)<=0) output("`\$Fehler`^: Dein Inventar konnte nicht aktualisiert werden! Bitte benachrichtige den Admin. ");
		}
		$haus->levelup();
		addnav("Zur�ck ins Arbeitszimmer",$this->back);
	}	// Ende Funktion

	function takekey() {
		global $session;
		global $haus;
		if (!$_POST['ziel']){
			$sql = "SELECT items.*,accounts.acctid AS aid,accounts.login AS itembesitzer FROM items LEFT JOIN accounts ON accounts.acctid=items.owner WHERE value1=".$haus->id." AND class='Schl�ssel' ORDER BY id ASC";
			$amt = "";
//			$sql = "SELECT owner FROM items WHERE value1=".$haus->id." AND class='Schl�ssel' ORDER BY value2 ASC";
			$result = db_query($sql) or die(db_error(LINK));
			output("<form action='".$this->back."&act=takekey' method='POST'>",true);
			output("`2Wem willst du den Schl�ssel wegnehmen? <select name='ziel'>",true);
			for ($i=0;$i<db_num_rows($result);$i++){
				$item = db_fetch_assoc($result);
//				$sql = "SELECT acctid,name,login FROM accounts WHERE acctid=".$item['owner']." ORDER BY login DESC";
//				$result = db_query($sql) or die(db_error(LINK));
//				$row = db_fetch_assoc($result);
				if ($amt != $item['aid'] && $item['aid'] != $haus->besitzerid)
					output("<option value=\"".rawurlencode($item['itembesitzer'])."\">".preg_replace("'[`].'","",$item['itembesitzer'])."</option>",true);
				$amt = (int)$item['aid'];
			}
			output("</select>`n`n",true);
			output("<input type='submit' class='button' value='Schl�ssel abnehmen'></form>",true);
			addnav("",$this->back."&act=takekey");
		}else{
			$sql = "SELECT acctid,name,login,gold,gems FROM accounts WHERE login='".$_POST['ziel']."' AND locked=0";
			$result = db_query($sql);
			$row = db_fetch_assoc($result);
			output("`2Du verlangst den Schl�ssel von `&".$row['name']."`2 zur�ck.`n");
			//$sql = "SELECT owner FROM items WHERE value1=".$haus->id." AND class='Schl�ssel' AND owner<>.".$haus->besitzer." ORDER BY id ASC";
			//$result = db_query($sql) or die(db_error(LINK));
			$goldgive=round($haus->gold/(db_num_rows($result)+1));
			$gemsgive=round($haus->gems/(db_num_rows($result)+1));
			systemmail($row['acctid'],"`@Schl�ssel zur�ckverlangt!`0","`&".$session['user']['name']."`2 hat den Schl�ssel zu Haus Nummer `b".$haus->id."`b (".$haus->name."`2) zur�ckverlangt. Du bekommst `^".$goldgive."`2 Gold auf die Bank und `#".$gemsgive."`2 Edelsteine aus dem gemeinsamen Schatz ausbezahlt!");
			output($row['name']."`2 bekommt `^".$goldgive."`2 Gold und `#".$gemsgive."`2 Edelsteine aus dem gemeinsamen Schatz.");
			$sql = "UPDATE items SET owner=".$haus->besitzerid.",hvalue=0 WHERE owner=".$row['acctid']." AND class='Schl�ssel' AND value1=".$haus->id;
			db_query($sql);
			$sql = "UPDATE accounts SET goldinbank=goldinbank+$goldgive,gems=gems+$gemsgive WHERE acctid=".$row['acctid'];
			db_query($sql);
			$haus->gold -= $goldgive;
			$haus->gems -= $gemsgive;
			$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'office-".$haus->id."',".$session['user']['acctid'].",'/me `^nimmt ".$row['name']."`^ einen Schl�ssel ab. ".$row['name']."`^ bekommt einen Teil aus dem Schatz.')";
			db_query($sql) or die(db_error(LINK));
		}
		addnav("Zur�ck zum Arbeitszimmer",$this->back);
	}	// Ende Funktion

	function givekey() {
		global $session, $haus;
		if (!$_POST['ziel']) {
			output("`2Einen Schl�ssel f�r dieses Haus hat:`n`n");
			$sql = "SELECT items.*,accounts.name AS besitzer FROM items LEFT JOIN accounts ON accounts.acctid=items.owner WHERE value1=".$haus->id." AND class='Schl�ssel' AND owner<>".$session['user']['acctid']." ORDER BY value2 ASC";
			$result = db_query($sql) or die(db_error(LINK));
			for ($i=0;$i < db_num_rows($result);$i++){
				$item = db_fetch_assoc($result);
				output("`c`& ".$item['besitzer']."`0`c");
			}
			$sql = "SELECT value2 FROM items WHERE value1=".$haus->id." AND class='Schl�ssel' AND owner=".$haus->besitzerid." ORDER BY id ASC";
			$result = db_query($sql) or die(db_error(LINK));
			if (db_num_rows($result)>0) {
				output("`n`2Du kannst noch `b".db_num_rows($result)."`b Schl�ssel vergeben.");
				output("<form action='".$this->back."&act=givekey' method='POST'>",true);
				output("An wen willst du einen Schl�ssel �bergeben? <input name='ziel'>`n", true);
				output("<input type='submit' class='button' value='�bergeben'></form>",true);
				output("`n`nWenn du einen Schl�ssel vergibst, wird der Schatz des Hauses gemeinsam genutzt. Du kannst einem Mitbewohner zwar jederzeit den Schl�ssel wieder wegnehmen, ");
				output("aber er wird dann einen gerechten Anteil aus dem gemeinsamen Schatz bekommen.");
				addnav("",$this->back."&act=givekey");
			}else{
				output("`n`2Du hast keine Schl�ssel mehr �brig. Vielleicht kannst du in der J�gerh�tte noch einen nachmachen lassen?");
			}
		} else {
			if ($_GET['subfinal']==1){
				$sql = "SELECT acctid,name,login,lastip,emailaddress,dragonkills,level,sex FROM accounts WHERE name='".addslashes(rawurldecode(stripslashes($_POST['ziel'])))."' AND locked=0";
			} else {
				$ziel = stripslashes(rawurldecode($_POST['ziel']));
				$name="%";
				for ($x=0;$x < strlen($ziel);$x++){
					$name.=substr($ziel,$x,1)."%";
				}
				$sql = "SELECT acctid,name,login,lastip,emailaddress,dragonkills,level,sex FROM accounts WHERE name LIKE '".addslashes($name)."' AND locked=0";
			}
			$result = db_query($sql);
			if (db_num_rows($result) == 0) {
				output("`2Es gibt niemanden mit einem solchen Namen. Versuchs nochmal.");
			} elseif(db_num_rows($result) > 100) {
				output("`2Es gibt �ber 100 Krieger mit einem �hnlichen Namen. Bitte sei etwas genauer.");
			} elseif(db_num_rows($result) > 1) {
				output("`2Es gibt mehrere m�gliche Krieger, denen du einen Schl�ssel �bergeben kannst.`n");
				output("<form action='".$this->back."&act=givekey&subfinal=1' method='POST'>",true);
				output("`2Wen genau meinst du? <select name='ziel'>",true);
				for ($i=0;$i < db_num_rows($result);$i++){
					$row = db_fetch_assoc($result);
					output("<option value=\"".rawurlencode($row['name'])."\">".preg_replace("'[`].'","",$row['name'])."</option>",true);
				}
				output("</select>`n`n",true);
				output("<input type='submit' class='button' value='Schl�ssel �bergeben'></form>",true);
				addnav("",$this->back."&act=givekey&subfinal=1");
			} else {
				$row = db_fetch_assoc($result);
				$sql = "SELECT owner FROM items WHERE owner=".$row['acctid']." AND value1=".$haus->id." AND class='Schl�ssel' ORDER BY id ASC";
				$result = db_query($sql) or die(db_error(LINK));
				$item = db_fetch_assoc($result);
				if ($row['login'] == $session['user']['login']) {
					output("`2Du kannst dir nicht selbst einen Schl�ssel geben.");
				} elseif ($item['owner']==$haus->besitzerid) {
					output("`2".$row['name']."`2 hat bereits einen Schl�ssel!");
				} elseif ($row['level']<5 && $row['dragonkills']<1){
					output("`2".$row['name']."`2 ist noch nicht lange genug um Dorf, als dass du ".($row['sex']?"ihr":"ihm")." vertrauen k�nntest. Also beschlie�t du, noch eine Weile zu beobachten.");
				} else {
					$sql = "SELECT value2 FROM items WHERE value1=".$haus->id." AND class='Schl�ssel' AND owner=".$haus->besitzerid." ORDER BY id ASC LIMIT 1";
					$result = db_query($sql) or die(db_error(LINK));
					$knr = db_fetch_assoc($result);
					$knr=$knr['value2'];
					output("`2Du �bergibst `&".$row['name']."`2 einen Schl�ssel f�r dein Haus. Du kannst den Schl�ssel zum Haus jederzeit wieder wegnehmen, aber ".$row['name']."`2 wird dann ");
					output("einen gerechten Anteil aus dem gemeinsamen Schatz des Hauses bekommen.`n");
					systemmail($row['acctid'],"`@Schl�ssel erhalten!`0","`&".$session['user']['name']."`2 hat dir einen Schl�ssel zu Haus Nummer `b".$haus->id."`b (".$haus->name."`2) gegeben!");
					$sql = "UPDATE items SET owner=".$row['acctid'].",hvalue=0 WHERE owner=".$haus->besitzerid." AND class='Schl�ssel' AND value1=".$haus->id." AND value2=$knr";
					db_query($sql);
					$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'office-".$haus->id."',".$session['user']['acctid'].",'/me `^gibt ".$row['name']."`^ einen Schl�ssel.')";
					db_query($sql) or die(db_error(LINK));
				}
			}
		}
		addnav("Zur�ck zum Arbeitszimmer",$this->back);
	}	// Ende Funktion
} // Ende Klasse

class schlafzimmer extends zimmer {
	// Das Schlafzimmer - verbinge Zeit mit einem Partner oder logge dich einfach sicher aus.
	// Basisklasse!
	var $back;

		// Konstruktor
	function schlafzimmer() {
		$this->back ="nhouses.php?op=drin&go=".$_GET['go'];
		switch($_GET['act']) {
			case 'logout': 		$this->logout(); break;

			default:	 				$this->basis(); break;

		}	// Ende Switch
	}	// Ende Funktion

	function logout() {
		global $session;
		if ($session['user']['housekey']!=$session['housekey']){
			$sql = "UPDATE items SET hvalue=".$session['housekey']." WHERE value1=".(int)$session['housekey']." AND owner=".$session['user']['acctid']." AND class='Schl�ssel'";
			db_query($sql) or die(sql_error($sql));
		}
		debuglog("logged out in a house");
		$session['user']['location']=2;
		$session['user']['loggedin']=0;
		$sql = "UPDATE accounts SET loggedin=0,location=2 WHERE acctid = ".$session['user']['acctid'];
		db_query($sql) or die(sql_error($sql));
		$session=array();
		redirect("index.php");
	}	// Ende Funktion

	function basis() {
		global $haus, $session;
		output("`2`b`c".$haus->name."`b, `&ein ".$haus->level->name."`&`n `bDein Schlafzimmer`b`c`n");
		if($session['user']['marriedto']>0){
			$lover = lover('name`, `acctid`, `login');
			output("`2Du betrittst das Schlafzimmer von `^".$lover['name']."`2 und dir.`n Ein gro�es Bett steht im Raum, sowie einige Schr�nke und andere Alltagsgegenst�nde.");
			output("Aber im allgemeinen ist diese Zimmer gem�tlicher eingerichtet, als der Rest des Hauses, um ein paar sch�ne Stunden zu zweit verbringen zu k�nnen");
			if($session['user']['sex']==0) {
				$male=$session['user']['acctid'];
				$female=$lover['acctid'];
			} else {
				$male=$lover['acctid'];
				$female=$session['user']['acctid'];
			}
			$gesammt="haus-".$haus->id."privat-".$male."_".$female;
//############################## Kindermod-Bereich ##############################//
			if(KINDER===true) {	// Entsprechende Konstante wird ganz oben definiert!
				switch($_GET['act']) {
					case 'geschuetzt':
					$lover = lover('name`, `sex');
					output("`nAls ".$lover['name']. "`q, eigentlich nur f�r kurz, in euren Schlafgem�chern vorbei schaut ziehst Du ".($lover['sex']?'sie':'ihn')." ins Bett und ihr liebt euch den ganzen restlichen Tag heiss und innig.");
					output("`nIhr bleibt schmussend noch ein wenig liegen...`n`n");
					break;

					case 'kind':
					$lover = lover('*');
					if($session['user']['sex'] != $lover['sex'])	$kindokay = true;
					else $kindokay = false;

					if($session['user']['superuser'] >= 2) $session['user']['sexheute'] = 0;

					if($session['user']['sexheute'] + $lover['sexheute'] < 6) {
						debuglog("hatte mit " . $lover['acctid'] . "-" . $lover['name'] . " sex.");
						if($lover['acctid'] < $session['user']['acctid']) {
							$spielera = $lover['acctid'];
							$spielerb = $session['user']['acctid'];
						} else {
							$spielera = $session['user']['acctid'];
							$spielerb = $lover['acctid'];
						}
						$sqlsex = "SELECT * FROM sexwermitwem WHERE spielera = $spielera AND spielerb = $spielerb";
						$resultsex = db_query($sqlsex) or die(db_error(LINK));
						if($rowsex = db_fetch_assoc($resultsex))
							$sqlsex = "UPDATE sexwermitwem SET sexzahl = sexzahl + 1 WHERE spielera = ".$spielera." AND spielerb = ".$spielerb;
						else
							$sqlsex = "INSERT INTO sexwermitwem VALUES($spielera, $spielerb, 1)";

						db_query($sqlsex) or die(db_error(LINK));

						if($kindokay) {
							if($session['user']['sex'])
								$empf = $session['user']['ssempf'];
							else
								$empf = $lover['ssempf'];

						$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'$gesammt', ".$session['user']['acctid'].",'/me `&hat mit ".$lover[name]." `&geschlafen.')";
						$result = db_query($sql) or die(db_error(LINK));
						if($session['user'][ssstatus] == 0 && $lover[ssstatus] == 0) {
							if(e_rand()%9 == $empf)
								$schwanger = true;
							else
								if(e_rand()%9 == $empf)
									$schwanger = true;
								else
									$schwanger = false;
							}
						} else {
							$sql = "INSERT INTO commentary values(0, 'inn-" . $_GET[sop] . "', " . $session['user']['acctid'] . ", '/me `&hat mit " . $lover[name] . " `&geschlafen',now())";
							$result = db_query($sql) or die(db_error(LINK));
						}
						$session['user']['sexheute']++;
						$session['user']['charm'] += 1;

						$sql2 = "UPDATE accounts set charm = charm + 1, sexheute = sexheute + 1 WHERE acctid ='".$lover['acctid']."'";
						db_query($sql2) or die(db_error(LINK));

						if($schwanger) {
							if($session['user']['sex'])	{
								// frau
								debuglog("ist von " . $lover['acctid'] . "-" . $lover['name'] . " schawanger");
								$session['user']['ssstatus'] = 1;
								$session['user']['sstritte'] = 0;
								$session['user']['ssmonat'] = 19;
								$session['user']['sserzeug'] = $lover['acctid'];

								$sql2 = "UPDATE accounts set charm = charm + 10 WHERE acctid=".$lover['acctid'];
								db_query($sql2) or die(db_error(LINK));
								$session['user']['charm'] += 10;
							} else {
								debuglog("hat " . $lover['acctid'] . "-" . $lover['name'] . " geschw�ngert");
								$sql2 = "UPDATE accounts set charm = charm + 10, ssstatus = 1, ssmonat = 19, sstritte = 0, sserzeug = " . $session['user']['acctid'] . " WHERE acctid='".$lover['acctid']."'";
								db_query($sql2) or die(db_error(LINK));
								$session['user']['charm'] += 10;
							}
						}
						if($session['user']['superuser'] > 2) {
							$bufflist = unserialize(stripslashes($lover['bufflist']));
							$bufflist['goettlichersex'] = array("name"=>"`%G�ttliches Andenken","rounds"=>100,"wearoff"=>"Die Errinerung verfliegt f�r heute!","atkmod"=>1.75,"roundmsg"=>"Du denkst immer noch an den g�ttlich intimen Stunden...","activate"=>"offense");
							$sql2 = "update accounts set sexgoettlich = 100, bufflist = '" . addslashes(serialize($bufflist)) . "' WHERE acctid='".$lover['acctid']."'";
							db_query($sql2) or die(db_error(LINK));
						}
						if($lover['superuser'] > 2) {
							$session['user']['sexgoettlich'] = 100;
							$session['bufflist']['goettlichersex'] = array("name"=>"`%G�ttliches Andenken","rounds"=>100,"wearoff"=>"Die Errinerung verfliegt f�r heute!","atkmod"=>1.75,"roundmsg"=>"Du denkst immer noch an den g�ttlich intimen Stunden...","activate"=>"offense");
						}
					} else {
						output("`n`nIrgendwie seit ihr nicht in der Stimmung dazu...`n");
					}

					if($session['user']['superuser'] >= 2) {
						output("`n`nDebug`n");
						output("Sex heute: " . $session['user']['sexheute'] . "`n");
						output("Sex gesamt: " . $session['user'][sexgesamt] . "`n");
						output("Empf�ngnis: " . $empf . "`n");
					}
					break;

					default:
					addnav("Sich Lieben");
					addnav("Gesch�tzt",$this->back."&act=geschuetzt");
					addnav("Ungesch�tzt",$this->back."&act=kind");
					break;
				}	// Ende Switch
				output("`n");
			}	// Ende IF
//############################# /Kindermod-Bereich ##############################//
			viewcommentary($gesammt,"Hinzuf�gen",25);
		} else {
		output("`@Du betrittst dein Schlafzimmer. Ein gem�tlicher Raum mit einem Bett nur f�r dich!");
		}
		addnav("Schlafzimmer");
		addnav("Log Out",$this->back."&act=logout");
		addnav("Im Haus");
		addnav("Zur�ck zum Flur","nhouses.php?op=drin");
	}	// Ende Funktion
}	// Ende Klasse

class schatz extends zimmer {
	// Die Schatzkammer, hie rlagern Gold und Edelsteine!
	// Basisklasse!
	var $back, $goldleft, $gemsleft, $maxtotake;

		// Konstruktor
	function schatz() {
		global $haus, $session;
		$this->back ="nhouses.php?op=drin&go=".$_GET['go'];
		$this->goldleft = $this->goldleft();
		$this->gemsleft = $this->gemsleft();
		$this->maxtotake = (getsetting("transferreceive",3) - $session['user']['transferredtoday']) * ($session['user']['level']*getsetting("transferperlevel",25));
		switch($_GET['act']) {
			case 'gebegold': 		$this->gebegold(); break;
			case 'nehmegold':		$this->nehmegold();	break;
			case 'gebegems':		$this->gebegems(); break;
			case 'nehmegems':		$this->nehmegems(); break;
			case 'allesnehmen': $this->allesnehmen(); break;

			default:							$this->basis(); break;
		}	// Ende Switch
	}	// Ende Funktion

	function gemsleft() {
		global $haus;
		return $haus->level->gemschest - $haus->gems;
	}	// Ende Funktion

	function goldleft() {
		global $haus;
		return $haus->level->goldchest - $haus->gold;
	}	// Ende Funktion

	function basis() {
		global $haus, $session;
		output("`2`b`c".$haus->name."`b, `&ein ".$haus->level->name."`&`n `bDie Schatzkammer`b `c`");
		if ($haus->text) output("`0`c".$haus->text."`c`n");
		output("`2Du und deine Mitbewohner haben `^".$haus->gold."`2 Goldst�cke und `#".$haus->gems."`2 Edelsteine im Haus gelagert.`n");
		output("`2Damit ist in der Schatztuhe noch platz f�r `^".$this->goldleft." `2Goldst�cke und `#".$this->gemsleft."`2 Edelsteine.`n");
		viewcommentary("schatz-".$haus->id,"Ins Hausbuch eintragen:",30,"merkt an");
		addnav("Gold");
		addnav("Deponieren",$this->back."&act=gebegold");
		addnav("Mitnehmen",$this->back."&act=nehmegold");
		addnav("Edelsteine");

		addnav("Deponieren",$this->back."&act=gebegems");
		addnav("Mitnehmen",$this->back."&act=nehmegems");
		addnav("Im Haus");
			addnav("Zur�ck in den Flur","nhouses.php?op=drin");
	}	// Ende Funktion

	function gebegold() {
		global $haus, $session;
		$maxout = $session['user']['level']*getsetting("maxtransferout",25);
		if (!$_POST['gold']){
			$transleft = $maxout - $session['user']['amountouttoday'];
			output("`2Du darfst heute noch `^$transleft`2 Gold deponieren und in der Schatztruhe ist noch Platz f�r weitere `^".($haus->level->goldchest - $haus->gold)."`2 Gold.`n");
			output("`2<form action='".$this->back."&act=gebegold' method='POST'>",true);
			output("`nWieviel Gold deponieren? <input type='gold' name='gold'>`n`n",true);
			output("<input type='submit' class='button' value='Deponieren'>",true);
			addnav("",$this->back."&act=gebegold");
		}else{
			$amt=abs((int)$_POST['gold']);
			if ($amt>$session['user']['gold']){
				output("`2So viel Gold hast du nicht dabei.");
			}else if(($haus->level->goldchest - $haus->gold)==0){
				output("`2Der Schatz ist voll.");
			}else if($amt>($haus->level->goldchest - $haus->gold)){
				output("`2Du gibst alles, aber du bekommst beim besten Willen nicht so viel in den Schatz.");
			}else if ($amt<0){
				output("`2Wenn du etwas aus dem Schatz nehmen willst, versuche nicht, etwas negatives hineinzutun.");
			}else if ($session['user']['amountouttoday']+$amt > $maxout) {
				output("`2Du darfst nicht mehr als `^$maxout`2 Gold pro Tag deponieren.");
			}else{
				$haus->gold+=$amt;
				$session['user']['gold']-=$amt;
				$session['user']['amountouttoday']+= $amt;
				output("`2Du hast `^$amt`2 Gold deponiert. Insgesamt befinden sich jetzt `^".$haus->gold."`2 Gold im Haus.");
				$sql="INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'schatz-".$haus->id."',".$session['user']['acctid'].",'/me `@deponiert `^$amt`@ Gold.')";
				db_query($sql) or die(db_error(LINK));
			}
		}
		addnav("Zur�ck zur Schatzkammer",$this->back."&go=schatz");
	}	// Ende Funktion

	function nehmegold() {
		global $haus, $session;
		$maxtfer = $session['user']['level']*getsetting("transferperlevel",25);
		if (empty($_POST['gold'])){
			$transleft = getsetting("transferreceive",3) - $session['user']['transferredtoday'];
			output("`2Es befindet sich `^".$haus->gold."`2 Gold in der Schatztruhe des Hauses.`nDu darfst heute noch $transleft x bis zu `^$maxtfer`2 Gold mitnehmen.`n");
			output("`@Du kannst auch all dein heute noch aufnehmbares Gold in einem Rutsch mitnehmen. Das w�ren dann: `^".$this->maxtotake." `2Goldst�cke.`n");
			output("`2<form action='".$this->back."&act=nehmegold' method='POST'>",true);
			output("`nWieviel Gold mitnehmen? <input type='gold' name='gold'>`n`n",true);
			output("<input type='submit' class='button' value='Mitnehmen'>",true);
			addnav("",$this->back."&act=nehmegold");
			addnav("Alles Gold nehmen (`^".$this->maxtotake."`9)",$this->back."&act=allesnehmen");
		}else{
			$amt=abs((int)$_POST['gold']);
			if ($amt>$haus->gold){
				output("`2So viel Gold ist nicht mehr da.");
			}else if ($maxtfer<$amt){
				output("`2Du darfst maximal `^$maxtfer`2 Gold auf einmal nehmen.");
			}else if ($amt<0){
				output("`2Wenn du etwas in den Schatz legen willst, versuche nicht, etwas negatives herauszunehmen.");
			}else if($session['user']['transferredtoday']>=getsetting("transferreceive",3)){
				output("`2Du hast heute schon genug Gold bekommen. Du wirst bis morgen warten m�ssen.");
			}else{
				$haus->gold-=$amt;
				$session['user']['gold']+=$amt;
				$session['user']['transferredtoday']++;
				output("`2Du hast `^$amt`2 Gold genommen. Insgesamt befindet sich jetzt noch `^".$haus->gold."`2 Gold im Haus.");
				$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'schatz-".$haus->id."',".$session['user']['acctid'].",'/me `\$nimmt `^$amt`\$ Gold.')";
				db_query($sql) or die(db_error(LINK));
			}
		}
		addnav("Zur�ck zur Schatzkammer",$this->back."&go=schatz");
	}	// Ende Funktion

	function gebegems() {
		global $haus, $session;
		if (!$_POST['gems']){
			output("`2In der Schatztruhe ist noch Platz f�r weitere `^".($haus->level->gemschest - $haus->gems)."`2 Edelsteine.`n");
			output("`2<form action='".$this->back."&act=gebegems' method='POST'>",true);
			output("`nWieviele Edelsteine deponieren? <input type='gems' name='gems'>`n`n",true);
			output("<input type='submit' class='button' value='Deponieren'>",true);
			addnav("",$this->back."&act=gebegems");
		}else{
			$amt=abs((int)$_POST['gems']);
			if ($amt>$session['user']['gems']){
				output("`2So viele Edelsteine hast du nicht.");
			}else if(($haus->level->gemschest - $haus->gems)==0){
				output("`2Der Schatz ist voll.");
			}else if($amt>($haus->level->gemschest - $haus->gems)){
				output("`2Du gibst alles, aber du bekommst beim besten Willen nicht so viel in den Schatz.");
			}else if ($amt<0){
				output("`2Wenn du etwas aus dem Schatz nehmen willst, versuche nicht, etwas negatives hineinzutun.");
			}else{
				$haus->gems+=$amt;
				$session['user']['gems']-=$amt;
				output("`2Du hast `#$amt`2 Edelsteine deponiert. Insgesamt befinden sich jetzt `#".$haus->gems."`2 Edelsteine im Haus.");
				$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'schatz-".$haus->id."',".$session['user']['acctid'].",'/me `@deponiert `#$amt`@ Edelsteine.')";
				db_query($sql) or die(db_error(LINK));
			}
		}
		addnav("Zur�ck zur Schatzkammer",$this->back."&go=schatz");
	}	// Ende Funktion

	function nehmegems() {
		global $haus, $session;
		if (!$_POST['gems']){
			output("`2Es befinden sich `#".$haus->gems."`2 Edelsteine in der Schatztruhe des Hauses.`n`n");
			output("`2<form action='".$this->back."&act=nehmegems' method='POST'>",true);
			output("`nWieviele Edelsteine mitnehmen? <input type='gems' name='gems'>`n`n",true);
			output("<input type='submit' class='button' value='Mitnehmen'>",true);
			addnav("",$this->back."&act=nehmegems");
		}else{
			$amt=abs((int)$_POST['gems']);
			if ($amt>$haus->gems){
				output("`2So viele Edelsteine sind nicht mehr da.");
			}else if ($amt<0){
				output("`2Wenn du etwas in den Schatz legen willst, versuche nicht, etwas negatives herauszunehmen.");
			}else{
				$haus->gems-=$amt;
				$session['user']['gems']+=$amt;
				output("`2Du hast `#$amt`2 Edelsteine genommen. Insgesamt befinden sich jetzt noch `#".$haus->gems."`2 Edelsteine im Haus.");
				$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'schatz-".$haus->id."',".$session['user']['acctid'].",'/me `\$nimmt `#$amt`\$ Edelsteine.')";
				db_query($sql) or die(db_error(LINK));
			}
		}
		addnav("Zur�ck zur Schatzkammer",$this->back."&go=schatz");
	}	// Ende Funktion

	function allesnehmen() {
		global $haus, $session;
		if($this->maxtotake > $haus->gold) $this->maxtotake = $haus->gold;
		$session['user']['gold'] += $this->maxtotake;
		$saetze = ceil($this->maxtotake / ($session['user']['level']*getsetting("transferperlevel",25)));
		$haus->gold -= $this->maxtotake;
		output("`2Du nimmst dir alles noch aufzunehmende Gold: `^".$this->maxtotake." `2Taler.`n Damit verbrauchst du `^ $saetze S�tze an Gold, die du nehmen darfst!");
		$session['user']['transferredtoday'] += $saetze;
		addnav("Zur�ck zum Schatzkammer",$this->back);
		$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'schatz-".$haus->id."',".$session['user']['acctid'].",'/me `\$nimmt sich seinen Tagessatz von `^".$this->maxtotake." Goldst�cken.')";
		db_query($sql) or die(db_error(LINK));
	}	// Ende Funktion
}	// Ende Klasse

class gemeinschaftsraum extends zimmer {
			// Konstruktor
	function gemeinschaftsraum() {
		$this->basis();
	}	// Ende Funktion

	function basis() {
		global $haus;
		output("`2`b`c".$haus->name."`b, `&ein ".$haus->level->name."`&`n `bDer Gemeindschaftsraum`b `c`n");
		output("`2Du betrittst den Gemeindschaftsraum des Hauses. Hier k�nnen sich die Bewohner in Ruhe unterhalten.");
		output("In der Ecke prasselt ein warme Kaminfeuer und einige bequeme Sessel laden dazu ein, hier ein wenig zu verweilen...`n`n");
		viewcommentary("gem_raum-".$haus->id,"Mit deinen Mitbewohnen unterhalten",25);
		addnav("Zur�ck zum Flur","nhouses.php?op=drin");
	}	// Ende Funtion
}	// Ende Klasse

class kueche extends zimmer {
	var $back;
	// Konstruktor
	function kueche() {
		$this->back ="nhouses.php?op=drin&go=".$_GET['go'];
		$this->basis();
 	}   // Ende Funktion

	function basis() {
		global $haus, $session;
		output("`2`b`c".$haus->name."`b, `&ein ".$haus->level->name."`&`n `bDie K�che`b `c`n");
		output("`2Du betrittst die K�che des Hauses, schaust dich um und durchsuchst sogleich die Schr�nke nach etwas essbarem.");
		output("Ein kleiner Ofen spendet die n�tige W�rme in der K�che und dient ebenso als 'Backofen'... `n Du setzt dich davor und geniest deine mahlzeit... `n`n");
		output("`2`b`cIn der K�che`c`b`n`n");
		output("`2Es ist jetzt `^".getgametime()."`2 Uhr, und du befindest dich in der K�che.`n");
		output("Und es ziemlich still in der K�che, du siehst dich ein wenig um und genie�t die ruhige Atmosph�re...`n`n`n");
		$kitchen = "kitchen-".$haus->id;
		$link = $this->back;
		switch($_GET['act']){
      // drinks
			case "saft":
			$saft = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'".$kitchen."',".$session['user']['acctid'].",'/me `&holt eine Karaffe voller Orangensaft hervor und sch�ttet ein.')";
			db_query($saft) or die(db_error(LINK));
			redirect($link);
			break;

			case "tee":
			$tee = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'".$kitchen."',".$session['user']['acctid'].",'/me `&hat einen Kessel Tee zubereitet.')";
			db_query($tee) or die(db_error(LINK));
			redirect($link);
			break;

			case "kaffe":
			$kaffe = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'".$kitchen."',".$session['user']['acctid'].",'/me `&hat vor, noch eine Weile wach zu bleiben, und sich deshalb eine Kanne Kaffee zubereitet.')";
			db_query($kaffe) or die(db_error(LINK));
			redirect($link);
			break;

			case "ale":
			if($session['user']['drunkenness']<=66) {
				$ale = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'".$kitchen."',".$session['user']['acctid'].",'/me `&ist in Partystimmung und sticht ein F��chen Ale an!')";
				db_query($ale) or die(db_error(LINK));
				$session['user']['drunkenness']+=33;
				redirect($link);
			} else {
				output("`qDu hast f�r heute genug Getrunken, schlafe erstmal deinen Rausch aus!");
			}
			break;

			case "wein":
			if($session['user']['drunkenness']<=76)	{
				$wein = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'".$kitchen."',".$session['user']['acctid'].",'/me `&m�chte etwas feiern und entkorkt eine Flasche leckeren Rotweines.')";
				db_query($wein) or die(db_error(LINK));
				$session['user']['drunkenness']+=38;
				redirect($link);
			} else{
				output("`qDu hast f�r heute genug Getrunken, schlafe erstmal deinen Rausch aus!");
			}
			break;
			// end of drinks
      // meals
			case "frustuck":
			$frustuck = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'".$kitchen."',".$session['user']['acctid'].",'/me `&hat Br�tchen geholt und Eier gekocht. Sobald jemand den Tisch deckt, gibt es Fr�hst�ck!')";
			db_query($frustuck) or die(db_error(LINK));
			redirect($link);
			break;

			case "mittagessen":
			$mittagessen = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'".$kitchen."',".$session['user']['acctid'].",'/me `&hat Hunger bekommen und einen kurzen Mittagssnack zubereitet.')";
			db_query($mittagessen) or die(db_error(LINK));
			redirect($link);
			break;

			case "abendessen":
			$abendessen = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'".$kitchen."',".$session['user']['acctid'].",'/me `&stellt sich f�r zwei Stunden in die K�che und kocht f�r alle ein herrliches Mahl!')";
			db_query($abendessen) or die(db_error(LINK));
			redirect($link);
			break;

			case "snack":
			$snack = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'".$kitchen."',".$session['user']['acctid'].",'/me `&braucht mal was f�r zwischendurch.')";
			db_query($snack) or die(db_error(LINK));
			redirect($link);
			break;
      // end of meals
   }	// Ende SWITCH
      viewcommentary($kitchen,"Mit deinen Mitbewohnen unterhalten",25);
   // kitchen nav
   addnav("Getr�nke");
   addnav("Saft",$this->back."&act=saft");
   addnav("Tee",$this->back."&act=tee");
   addnav("Kaffee",$this->back."&act=kaffe");
   addnav("Ale",$this->back."&act=ale");
   addnav("Wein",$this->back."&act=wein");
   addnav("Mahlzeiten");
   addnav("Fr�hst�ck",$this->back."&act=frustuck");
   addnav("Mittagessen",$this->back."&act=mittagessen");
   addnav("Abendessen",$this->back."&act=abendessen");
   addnav("Snack",$this->back."&act=snack");
   addnav("Zur�ck");
    addnav("Zur�ck zum Flur","nhouses.php?op=drin");
   }   // Ende Funtion
}	// Ende Klasse

class lagune extends zimmer {
	var $back;
		// Konstruktor
	function lagune() {
		$this->back ="nhouses.php?op=drin&go=".$_GET['go'];
		$this->basis();
	} // Ende Funktion

	function basis() {
		global $haus, $session;
		addcommentary();
			// Verheiratet?
		if($session['user']['marriedto']==$haus->besitzerid || $session['user']['acctid']==$haus->besitzerid && $session['user']['marriedto']){
			output('`qDu trittst durch eine unscheinbare T�r auf den Weg zur blauen Lagune. '.'Es ist angenehm warm, kein Wunder, denn in dem sch�n verstecktem Ort scheint die '.'Sonne immerfort. Der Sand ist weich und warm, und das Wasser hell und klar. Es wirkt '.'einladend.`n');
			output('Am anderen Ufer siehst Du die hellen Wasserf�lle, alles ist in '.'liebevolles Licht getaucht und Du sp�rst, hier kannst Du Dich hingeben, '.'denn keiner st�rt Euch hier.`n');
			$lagune = "lagune-".$haus->id;
			switch($_GET['act'])	{
				case "soap":
				$soap = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'".$lagune."',".$session['user']['acctid'].",'/me `&cremt Dir z�rtlich den R�cken ein.')";
				db_query($soap) or die(db_error(LINK));
				redirect($this->back);
				break;

				case "shampoo":
				$shampoo = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'".$lagune."',".$session['user']['acctid'].",'/me `&w�scht sich die Haare um Dir zu gefallen.')";
				db_query($shampoo) or die(db_error(LINK));
				redirect($this->back);
				break;

				case "stroke":
				$stroke = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'".$lagune."',".$session['user']['acctid'].",'/me `&streichelt z�rtlich �ber Deine duftende Haut.')";
				db_query($stroke) or die(db_error(LINK));
				redirect($this->back);
				break;

				case "love":
				$love = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'".$lagune."',".$session['user']['acctid'].",'/me `&zieht Dich z�rtlich zu sich ins Wasser um Dich zu f�hlen!')";
				db_query($love) or die(db_error(LINK));
				redirect($this->back);
				break;

				case "duft":
				$duft = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'".$lagune."',".$session['user']['acctid'].",'/me `&macht Kerzen und Duft�l ins Wasser, um Dich "."zu verw�hnen.')";
				db_query($duft) or die(db_error(LINK));
				redirect($this->back);
				break;
			}	// Ende Switch
			viewcommentary($lagune,"sich gegenseitig verw�hnen:",20,"fl�stert z�rtlich");
				// lagune nav
			addnav("Aktionen");
			addnav("Eincremen",$this->back."&act=soap");
			addnav("Haarewaschen",$this->back."&act=shampoo");
			addnav("Streicheln",$this->back."&act=stroke");
			addnav("Lieben (Gesch�tzt)",$this->back."&act=love");
			addnav("Duftkerzen",$this->back."&act=duft");
		}else{
			output("Du r�ttelst ein wenig an der T�r - verschlossen.`n");
			output("Tja, in der privaten Lagune hast du eben nichts zu suchen.");
		}	// Ende ELSE
		addnav("Zur�ck zum Flur","nhouses.php?op=drin");
	}	// Ende Funktion
} // Ende Klasse

class kinderzimmer extends zimmer {
	var $back;
	// Buffs:
	var $buffA = array("name" => "`2Kinderfreude"
				,"roundmsg" => "Die Freude �ber dein Kind gibt dir Kaft"
				,"wearoff" => "Die starke Freude verblasst."
				,"rounds" => "75"
				,"atkmod" => "1.10"
				,"survivenewday" => "0"
				,"activate" => "roundstart");
	var $buffB = array("name" => "`2Kindergl�ck"
				,"roundmsg" => "Das gl�ckliche L�chelnd deines Kindes macht dich aufmerksamer"
				,"wearoff" => "Die Erinnerung an das L�cheln deines Kinder verblasst"
				,"rounds" => "75"
				,"defmod" => "1.10"
				,"survivenewday" => "0"
				,"activate" => "roundstart");
	var $buffC = array("name" => "`4Angst ums Kind"
				,"roundmsg" => "Die Angst um dein Kind l�sst dich unaufmerksamer K�mpfen"
				,"wearoff" => "Du bist dir nun sicher, das es deinem Kind gut geht"
				,"rounds" => "75"
				,"atkmod" => "0.95"
				,"defmod" => "0.95"
				,"survivenewday" => "0"
				,"activate" => "roundstart");
	function kinderzimmer() {
		$this->back = "nhouses.php?op=drin&go=".$_GET['go'];
		$this->basis();
	}	// Ende Funktion

	function basis() {
		global $session;
			// Maximal ein eigenes Kind abrufen, nur zur bestimmung ob Elter oder nicht.
		if(KINDER) {
			$kinder = (bool) db_num_rows(db_query("SELECT id FROM `kinder` WHERE mama=".$session['user']['acctid']." OR papa=".$session['user']['acctid']." LIMIT 1"));
			if($_GET['machen']=="kind") {
				output("Du gehtst zu deinem Kind uns besch�ftigst dich eine Weile mit ihm.`n");
				switch(e_rand(0,5)) {
					case 0:
					output("`2Dir bleibt noch einige Zeit im Ged�chtnis h�ngen, wie sher sich dein Kind �ber deinen Besuch freute.");
					$session['bufflist']['kind'] = $this->buffB;
					break;

					case 1:
					output("`3Du spielst eine Weile mit deinem Kind unf f�hlst dich danach ebenso gut, wie dein Spr�ssling selbst.");
					$session['bufflist']['kind'] = $this->buffA;
					break;

					case 2:
					output("`4Zwar besch�ftigst du dich eine Weile mit deinem Kind, aber irgendwie wirst du danach das gef�hl nicht los, das es sich gerade nicht wohl f�hlt...");
					$session['bufflist']['kind'] = $this->buffC;
					break;

					default:
					output("Du k�mmerst dich eine Weile um dein Kind und bemerkst dabei gar nicht, wie schnell die Zeit vergeht.");
					$session['user']['turns']--;
				}	// Ende SWITCH
			} elseif($kinder==true) {
				output("Du betrittst das Kinderzimmer und entdeckst sofort dein Kind, das friedlich vor sich hin spielt.`n");
				output("M�chtest du dich nicht ein wenig mit ihm besch�ftigen?");
				addnav("Mit Kind Spielen",$this->back."&machen=kind");
			} else {
				output("Da du keine Kinder hast, siehst du auch keinen Sinn darin, ins Kinderzimmer zu gehen.");
			}
		} else {
			output("Da es in dieser Welt keine Kinder gibt, braucht man auch keine Kinderzimmer....");
		}
		addnav("Zur�ck zum Flur","nhouses.php?op=drin");
	}	// Ende Funktion
}	// Ende Klasse
?>