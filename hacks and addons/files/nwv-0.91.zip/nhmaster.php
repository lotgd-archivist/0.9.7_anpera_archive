<?php
require_once "common.php";
require_once "classes.php";
isnewday(2);
page_header("Einstellungen f�r das Wohnviertel");
output("`c`b`&Einstellungen f�r das Wohnviertel`b`c`n");

$setup = array(
	"Hausbau,title",
	"baukostengold"=>"Goldkosten zum Bau eines Hauses,int",
	"baukostengems"=>"Edelsteinkosten zum Bau eines Hauses,int",
	"abwannbauen"=>"Ab Wievielen Drachenkills darf man ein Haus bauen,int",
	"kindermod"=>"Ist die Kindermodifikation von -Dom installiert?,bool"
);
$daten=array(
		"level"=>"Level",
		"name"=>"Name der Ausbaustufe",
		"gold"=>"Ausbaukosten in Gold",
		"gems"=>"Ausbaukostem in Edelsteinen",
		"keys"=>"Schl�ssel auf dieser Stufe",
		"zimmer"=>"Zimmerslots f�r Ausbauten",
		"goldchest"=>"Platz f�r wieviele Goldst�cke",
		"gemschest"=>"Platz f�r wieviele Edelsteine"
);

switch($_GET['op']) {
	case 'speichern':
	reset($_POST);
	while (list($key,$val)=each($_POST)){
		savesetting($key,stripslashes($val));
		output("`@Setze $key auf ".stripslashes($val)."`n");
	}
	break;
	
	case 'level':
	output("`b`cFolgende Ausbaustufen gibt es bereits - zum editieren anklicken`b`c`n");
	output("<table cellpadding=2 cellspacing=1 bgcolor='#999999' align='center'><tr class='trhead'><td>ID</td><td>Name</td><td>Goldkosten</td><td>Gemkosten</td>",true);
	output("<td>Goldschatz</td><td>Gemschatz</td><td>Schl�ssel</td><td>Zimmer</td><td>Ops</td></tr>",true);
	$loch = 0;
	for($i=1;$i<=ausbaustufe::hoechste();$i++) {
		$level = new ausbaustufe($i);
		$bgcolor=($i%2==1?"trlight":"trdark");
		$c=($i%2==1?"`9":"`6");
		if(empty($level->id) && empty($level->name)) {
			output("<tr class='$bgcolor'><td colspan='7' align='center'>`4FEHLER - Kein Datensatz vorhanden -> \"`iLoch`i\"!</td></tr>",true);
			$loch++;
		} else {
			output("<tr class='$bgcolor'><td>$c".$level->level."</td><td><a href='nhmaster.php?op=edit&id=".$level->level."'>".$level->name."</a></td><td>$c".$level->gold."</td><td>$c".$level->gems."</td>",true);
			output("<td>$c".$level->goldchest."</td><td>$c".$level->gemschest."</td><td>$c".$level->keys."</td><td>$c".$level->zimmer."</td><td><a href='nhmaster.php?op=delete&id=".$level->level."'>del</a></td></tr>",true);
			addnav("","nhmaster.php?op=edit&id=".$level->level);
			addnav("","nhmaster.php?op=delete&id=".$level->level);
		}
	}
	output("</table>",true);
		// Fehler�berpr�fungen:
	if($loch > 0) {
		output("`n`c`b`$ Achtung! Es ".(($loch=1)?"ist":"sind")." ".$loch." ".(($loch=1)?"\"`iLoch`i\"":"\"`iL�cher`i\"")." vorhanden!`b`c`n");
		output("`6Beim Pr�fen ist aufgefallen, das gewisse Positionen in der Reihe der Ausbaustufen vorhanden sind.`n");
		output("Da diese schwerwiegende Fehler herbeif�hren k�nnen, sollten sie schnellsten behoben werden!`n`n");
		output("`#Die Pr�fung ergab: `^".ausbaustufe::levels()." `#Level sind eingetragen, das h�chste jedoch hat den Wert `^".ausbaustufe::hoechste().".`n`n");
		$sql = "SELECT level, name FROM hauslevels";
		$result = db_query($sql) or die(db_error(LINK));
	}	else {
		output("`n`c`b`@Scheinbar keine Fehler vorhanden!`b`c");
	}
	addnav("Aktionen");
	addnav("Neue Stufe Erstellen","nhmaster.php?op=create");
	addnav("Sonstiges");
	break;
	
	case 'delete':
	if(!$_GET['id']) redirect('nhmaster.php?op=level');
	if($_GET['validate']=="ja") {
		$sql = "DELETE FROM `hauslevels` WHERE `level` = ".$_GET['id'];
		db_query($sql) or die(db_error(LINK));
		output("L�schvorgang f�r die Ausbaustufe mit der ID ".$_GET['id']." erfolgreich abgeschlossen!");
	} else {
		output("`4Achtung: Soll die Ausbaustufe mit der ID ".$_GET['id']." wirklich gel�scht werden?");
		addnav("Aktionen");
		addnav("Ja!","nhmaster.php?op=delete&id=".$_GET['id']."&validate=ja");
		addnav("Abbruch und Sonstiges");
	}
	break;
	
	case 'create':
	$id = ausbaustufe::hoechste() + 1;
	output("<form action='nhmaster.php?op=editieren' method='POST'>",true);
	output("<table><tr bgcolor='#666666'><td colspan='2'>`^`bErstellungsparameter f�r Ausbaustufe ".$id."`b`0</td><td>`6(Sonst h�chste Stufe)`0</td></tr>",true);
	addnav("","nhmaster.php?op=editieren");
	$last = new ausbaustufe($id - 1);
	reset($daten);
	while(list($key,$val)=each($daten)) {
		$level = ($key=="level"?"value='$id'":"");
		output("<tr><td nowrap='nowrap' valign='top'>".$val."</td><td><input name='".$key."' $level ></td><td align='center'>`6".$last->$key."`0</td></tr>",true);
	}
	output("<tr><td><input type='submit' value='Speichern'></td><td colspan='2'><input type='reset' value='Zur�cksetzen'></td></tr></table></form>",true);
	break;
	
	case 'edit':
	if(!$_GET['id']) redirect('nhmaster.php?op=level');
	$level = new ausbaustufe($_GET['id']);
	
	addnav("Aktionen");
	addnav("L�schen!","nhmaster.php?op=delete&id=".$_GET['id']);
	addnav("Sonstiges");
	output("<form action='nhmaster.php?op=editieren' method='POST'>",true);
	output("<table><tr><td colspan='2' bgcolor='#666666'>`^`bEinstellungen f�r Ausbaustufe ".$_GET['id']."`b`0</td></tr>",true);
	addnav("","nhmaster.php?op=editieren");
	reset($daten);
	while(list($key,$val)=each($daten)) {
		output("<tr><td nowrap='nowrap' valign='top'>".$val."</td><td><input name='".$key."' value='",true);
		rawoutput($level->{$key});
		output("'></td></tr>",true);
	}
	output("<tr><td><input type='submit' value='Speichern'></td><td><input type='reset' value='Zur�cksetzen'></td></tr></table></form>",true);
	break;
	
	case 'editieren':
	output("`^`bFehler�berpr�fung:`b`n `6Hier wird nun auf diverse Fehlerverurschande M�glichkeiten getestet:`n`n");
	$schalter = array("a"=>false,"b"=>false);
	$sql = "SELECT level, name FROM hauslevels ORDER BY level ASC";
	$result = db_query($sql) or die(db_error(LINK));
	for($i=0;$i<=db_num_rows($result);$i++) {
		$row = db_fetch_assoc($result);
		// Pr�fung auf eventuell zu �berschreibenden Level:
		if($schalter['a'] == false && $row['level'] == $_POST['level']) {
			$schalter['a'] = true;
			output("`6Es besteht bereits eine Ausbaustufe mit der angegeben Nummer - wenn du nun speicherst, wird diese unwiederbringlich �berschreiben!`n");
			output("Wenn du allerdings nur eine Ausbaustufe um�nderst und in diesem Moment keine neue erstellst, ist das kein Problem!`n`n");
			// Pr�fung auf gleiche Namen:
		}
		if($row['name'] == $_POST['name']) {
			$schalter['b'] = true;
			output("Der eingegebene Name besteht bereits einmal bei einer anderen Ausbaustufe (".$row['level']."). Du solltets einen anderen w�hlen!`n");
			output("Wenn du allerdings nur eine Ausbaustufe um�nderst und in diesem Moment keine neue erstellst, ist das kein Problem!`n");
		}
		$highest = $row['level'];
	}
	output("`n`n");
	// Abschlie�ende Analyse:
	if($schalter['a'] || $schalter['b']) {
		output("`4Da Hinweise aufgetreten sind, solltest du deine Eingaben noch einmal �berpr�fen!`n");
	} else {
		output("`@Deine Daten scheinen soweit korrekt zu sein!`n");
	}
	addnav("Was jetzt?");
		addnav("Daten neu eingeben","nhmaster.php?op=edit&id=".(($_POST['level']>ausbaustufe::levels())?ausbaustufe::levels():$_POST['level']));
		addnav("Abschicken und Speichern!","nhmaster.php?op=eintragen");
	addnav("Sonstiges");
	output("`2Ansonsten werden nun folgende Daten gespeichert:`n");
	$first = true;
	if($schalter['a'] == true) $query = "UPDATE `hauslevels` SET ";	// Wenn bereits ein Datensatz unter dieser Nummer besteht
	else $query = "INSERT INTO `hauslevels` SET ";									// Wenn noch kein Datensatz unter dieser Nummer besteht
	foreach($daten as $key=>$val) {
		if(!$first) {
			$query .= ", ";
			output(", ");
		}
		$query .= "`".$key."` = '".$_POST[$key]."'";
		output("Setze ".$key." auf '");
		rawoutput($_POST[$key]);
		output("'`n");
		$first = false;
	}
	if($schalter['a'] == true) $query .= " WHERE level = ".$_POST['level'];
	output("`n`n QUERY: ");
	rawoutput($query);
	$session['hausausbauquery'] = $query;
	break;
	
	case 'eintragen':
	if(empty($session['hausausbauquery'])) {
		output("`4Fehler, der Query wurde nicht richtig �bertragen! Bitte noch einmal versuchen!");
	} else {
		db_query($session['hausausbauquery']) or die(db_error(LINK));
		output("`@Alles OK, die Daten wurden eingetragen und sind nun verwendbar!");
	}
	addnav("Zur�ck");
	break;
	
	case 'check':
	$col = new collector();
	$col->pruefung();
	break;
	
	case 'weiter':
	$col = new collector();
	$col->weiterverarbeitung();
	break;
	
	case 'mmaster':
	$col = new collector();
	output($col->ausgabe,true);
	addnav("Operationen");
	addnav("Pr�fung durchf�hren","nhmaster.php?op=check");
	addnav("Sonstiges");
	break;
	
	case 'zimmeredit':
	if(!$_GET['zimmer']) redirect("nhmaster.php");
	include_once("zimmer.php");
	$zimmer = new zimmer;
	$zimmer->finddata((int) $_GET['zimmer']);
	output($zimmer->adminausgabe(),true);
	break;
	
	case 'zimmerweiter':
	$sql = "UPDATE `zimmer` SET `link` = '".$_POST['linker']."', `label` = '".$_POST['label']."', `level` = ".((int) $_POST['level'])."
	, `aktiv` = ".((int) $_POST['aktiv']).", `gold` = ".((int) $_POST['gold']).", `gems` = ".((int) $_POST['gems'])." WHERE `zimmerid` = ".((int) $_GET['zimmer']);
	db_query($sql) or die(db_error(LINK));
	output("Die Einstellungen wurden erfolgreich eingetragen.`n");
	break;
	
	default:
	output("<form action='nhmaster.php?op=speichern' method='POST'>",true);
	addnav("","nhmaster.php?op=speichern");
	showform($setup,$settings);
	output("</form>",true);
	break;
}
addnav("Modulmaster","nhmaster.php?op=mmaster");
addnav("Hauslevel-Editor","nhmaster.php?op=level");
addnav("�bersicht","nhmaster.php");
addnav("Zur�ck zur Grotte","superuser.php");
page_footer();
?>