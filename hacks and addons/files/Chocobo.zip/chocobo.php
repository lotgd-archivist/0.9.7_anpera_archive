<?php
/* Made by Eichi Version 0.3
Einbau:
�ffne: grassyfield.php (special)
suche:
output("`n`c`#Du stolperst auf eine grasbewachsene Lichtung.`c")

f�ge danach ein:

output("`n`c`#Du siehst auf der Lichtung ganz viele G�nsebl�mchen und Chocobospuren, du freust dich und tollst vergn�gt herum oder entspannst dich auf dieser herrlichen Lichtung.`c");
output("`n`c`#Auch andere scheinen sich hier herumzutreiben, schau dich doch mal etwas um und lass es dir mal so richtig gut gehen!`c`n`n");
addnav("Chocobos suchen","chocobo.php");

save & close

Die neue grassyfield.php ins special-Verzeichnis, die chocobo.php ins root-Verzeichnis und die 401_mods_de_chocobo.mid ins media-Verzeichnis uploaden.
Viel Spa�, Eichi
*/
require_once "common.php";
page_header("Chocobo-Such-Spiel");
if ($_GET['op']==""){

 output("<embed src=\"media/401_mods_de_chocobo.mid\" width=10 height=10 autostart=true loop=true hidden=false volume=100>",true);
output("Du folgst den Spuren der Chocobos und hoffst auf einen Chocobo zu treffen und diesen zu fangen, viel Gl�ck!");
addnav("Doch lieber zur�ck","forest.php?op=return");
addnav("Suchen!","chocobo.php?op=chocobo");
}
if ($_GET['op']=="chocobo")
{
switch(e_rand(1,5))
{
case 1:
output("Du suchst nach einem Chocobo, kannst aber keins finden.`n");
output("Durch die lange Suchaktion verlierst du zwei Waldk�mpfe!");
if ($session['user']['turns']>0) $session['user']['turns']-=2;
addnav("Zur�ck","chocobo.php");
break;
case 2:
output("Du achtest, so eiffrig die Chococobs zu finden, nicht mehr darauf wo die Spuren hinf�hren, so dass du dich verlaufen hast.`n`n");
output("Du befindest dich wieder im Wald, durch die Suchaktion verlierst du einen Waldkampf.");
if ($session['user']['turns']>0) $session['user']['turns']-=1;
addnav("Weiter","forest.php?op=return");
break;
case 3:
output("Du findest einen Chocobo auf anhieb, friedlich frisst er Gras.`n");
output("Heimlich schleichst du dich von hinten ran und �berw�ltigst ihn, du hast einen Chocobo gefangen!");
addnav("Weiter","chocobo.php?op=win");
break;
case 4:
output("Du triffst auf einen Chocobo, doch er bemerkt dich, entweder du versuchst ihn nun zu �berw�ltigen oder l�sst ihn davon kommen.`n");
output("Versuchst du es zu fangen?");
addnav("Weglaufen","forest.php?op=return");
addnav("Fangen!","chocobo.php?op=chocobofight");
break;
case 5:
output("Du bist in eine Falle getreten, schwer verletzt f�llst du in Ohnmacht, vielleicht hast du ja gl�ck und es findet dich Jemand, der Heiler zum Beispiel!`n");
addnav("In Ohnmacht fallen","healer.php");
$session['user']['hitpoints']=1;
break;
}
}

if ($_GET['op']=="fight")
{
$battle=true;
}
if ($battle)
{
include ("battle.php");
if ($victory)
{
output("`nDu hast den ".$badguy['creaturename']." `4geschlagen und er scheint sich dir zu unterwerfen, Hurra!.`0");
$badguy=array();
$session['user']['badguy']="";
$session['chocobo']+=1;
}
elseif($defeat)
{
output("Der Chocobo rennt davon, zu dumm!");
addnews($session['user']['name']." ist zu bl�d ein Chocobo zu fangen!");
output("Du verlierst 20% deiner Erfahrung.`n");
$session['user']['experience']=round($session['user']['experience']*0.8);
addnav("Zur�ck in den Wald","forest.php?op=return");
}
else
{
fightnav();
}
}
if($session['chocobo']==1){
$session['chocobo']+=1;
addnav("Weiter","chocobo.php?op=win");
}
if ($_GET['op']=="win")
{
output("Der Chocobo beschlie�t dich zu begleiten und dir als Reittier zu dienen, herzlichen Gl�ckwunsch!");
$session['bufflist']['Chocobo'] = array("name"=>"`^Chocobo","rounds"=>250,"wearoff"=>"`&Der Chocobo ist m�de und verschwindet wieder.`0","tavern"=>1,"defmod"=>3,"atkmod"=>2,"minioncount"=>2,"minbadguydamage"=>5,"maxbadguydamage"=>5,"roundmsg"=>"Der Chocobo k�mpft mit dir und bietet dir auf seinem R�cken eine bessere Position f�r den Kampf!`0","activate"=>"offense");
addnav("Weiter","forest.php?op=return");
}
if ($_GET['op']=="chocobofight")
{
output("Der Chocobo f�hlt sich gest�rt und wird es dir nicht einfach machen sich fangen zu lassen!`n");
addnav("K�mpfe","chocobo.php?op=fight");
$badguy = array(
"creaturename"=>"`tCh`^o`tco`^bo`0"
,"creaturelevel"=>15
,"creatureweapon"=>"`QS`qc`Qh`qn`Qa`qb`Qe`ql`0"
,"creatureattack"=>32
,"creaturedefense"=>32
,"creaturehealth"=>320
,"diddamage"=>0);
$session['user']['badguy']=createstring($badguy);
$atkflux = e_rand(0,$session['user']['dragonkills']*2);
$defflux = e_rand(0,($session['user']['dragonkills']*2-$atkflux));
$hpflux = ($session['user']['dragonkills']*2 - ($atkflux+$defflux)) * 5;
$badguy['creatureattack']+=$atkflux;
$badguy['creaturedefense']+=$defflux;
$badguy['creaturehealth']+=$hpflux;
}
page_footer();
?>
