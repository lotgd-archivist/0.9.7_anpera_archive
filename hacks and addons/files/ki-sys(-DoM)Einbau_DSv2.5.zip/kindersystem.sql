-
--- Diese SQL-Befehle im PHPMYADMIN ausf�hren
-


ALTER TABLE accounts ADD famsystem tinyint(4) NOT NULL default '0';
ALTER TABLE accounts ADD maxkinder tinyint(4) NOT NULL default '0';
ALTER TABLE accounts ADD sexstatus tinyint(4) NOT NULL default '0';
ALTER TABLE accounts ADD sexgoettlich bigint(20) NOT NULL default '0';
ALTER TABLE accounts ADD sexheute tinyint(4) NOT NULL default '0';
ALTER TABLE accounts ADD sexgesamt bigint(20) NOT NULL default '0';
ALTER TABLE accounts ADD inn_zimmer tinyint(4) default NULL;
ALTER TABLE accounts ADD ssstatus enum('0','1') NOT NULL default '0';
ALTER TABLE accounts ADD ssmonat tinyint(4) NOT NULL default '0';
ALTER TABLE accounts ADD ssempf tinyint(4) NOT NULL default '0';
ALTER TABLE accounts ADD sserzeug bigint(20) NOT NULL default '0';
ALTER TABLE accounts ADD sstritte tinyint(4) NOT NULL default '0';
ALTER TABLE accounts ADD ssgescha tinyint(4) NOT NULL default '0';
ALTER TABLE accounts ADD ssgeschb tinyint(4) NOT NULL default '0';


  CREATE TABLE `sexwermitwem` (
  `spielera` bigint(20) NOT NULL default '0',
  `spielerb` bigint(20) NOT NULL default '0',
  `sexzahl` bigint(20) NOT NULL default '0',
  KEY `spielera` (`spielera`,`spielerb`)
) TYPE=MyISAM;


CREATE TABLE `hzsex` (
  `spielera` bigint(20) NOT NULL default '0',
  `spielerb` bigint(20) NOT NULL default '0',
  KEY `spielera` (`spielera`),
  KEY `spielerb` (`spielerb`)
) TYPE=MyISAM;


CREATE TABLE `kinder` (
  `id` bigint(20) NOT NULL auto_increment,
  `mama` bigint(20) NOT NULL default '0',
  `papa` bigint(20) NOT NULL default '0',
  `name` varchar(50) NOT NULL default '',
  `geschlecht` tinyint(4) NOT NULL default '0',
  `gebdat` varchar(50) NOT NULL default '',
  `unehelich` tinyint(4) NOT NULL default '0',
  `info` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=419 ;

