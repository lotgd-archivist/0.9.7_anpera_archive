<?
// Einbauanleitung f�r das Kindersystem von -DoM f�r die Dragonslayerversion 2.5
// alle Angaben ohne Gew�hr, ich habs bei mir so eingebaut und es l�uft...
// bei folgesch�den �bernehme ich nat�rlich keine Haftung ;)
// Einbauanleitung f�r das Ki-Sys zum gr�sstenteil von -DoM f�r die DSv2.5 ge�ndert von Liath

/*
#####################
�ffne bio.php

suche:

// Daten abrufen
                    $result = db_query("SELECT
                    activated, ".($session['user']['profession'] == PROF_GUARD || $session['user']['profession'] == PROF_GUARD_HEAD ? '((maxhitpoints/30)+(attack*1.5)+(defence)) AS strength, ' : '')."
                    login,loggedin,laston,accounts.name,level,jobname,sex,title,specialty,hashorse,acctid,age,marriedto,pvpflag,charisma,charm,weapon,
                    armor,imprisoned,profession,resurrections,dragonkills,monsterkills,race,housekey,punch,reputation,marks,battlepoints,kutsche,schiff,
                    guildid,guildfunc,guildrank,expedition,r.name AS racename

                    
f�ge am ende hinzu: 

,ssstatus,ssmonat

suche:

if ($row['marriedto']){
    if ($row[marriedto]==4294967295) {
        output('`^Verheiratet mit: `@'.($row['sex']?'Seth':'Violet').'`n');
    }
    elseif ($row['charisma']==4294967295 || $row['charisma']==999){
        $sql = "SELECT name FROM accounts WHERE acctid='{$row['marriedto']}'";
        $result = db_query($sql);
        $partner = db_fetch_assoc($result);
        output("`^".(($row[charisma]==999)?"Verlobt":"Verheiratet")." mit: `@{$partner['name']}`n");
    }
}

f�ge danach hinzu:

if($row[ssstatus] > 0 && $row[ssmonat] <= 64)
{
    output("`^Ist Schwanger`n");
}    

if($row[sex])
    $sqlkin = "SELECT * FROM kinder where mama = " . $row[acctid];
else
    $sqlkin = "SELECT * FROM kinder where papa = " . $row[acctid];
    
    $resultkin = db_query($sqlkin);
    
    $kinder = array();
    while ($rowkin = db_fetch_assoc($resultkin)) 
    {
        array_push($kinder, $rowkin[name]);
    }
if($kinder[0] != "")
{
    if($row[sex])
        output("`^Ist Mutter von:`@ ");
    else
        output("`^Ist Vater von:`@ ");
    
        output(implode(", ", $kinder));
        output("`0`n");
}


###############################
bio.php speichern und schliessen

�ffne dragon.php
###############################

suche:

,"deathpower"=>1

f�ge danach hinzu:

    ,"sexstatus"=>1
    ,"sexheute"=>1
    ,"sexgesamt"=>1
    ,"ssstatus"=>1
    ,"ssmonat"=>1
    ,"ssempf"=>1
    ,"sserzeug"=>1
    
###############################
dragon.php speichern und schliessen

�ffne houses_private.php
###############################


suche:

    if ($session['user']['acctid']==$session['private']) {

        addnav('Verwaltung');

        addnav('B?Beschreibung �ndern','houses_private.php?op=desc');
        addnav('E?Einladen','houses_private.php?op=geben');
        addnav('A?Ausladen','houses_private.php?op=nehmen');
        addnav('r?Aufr�umen','houses_private.php?op=sauber');
        //addnav('Kommentarl�nge �ndern','houses_private.php?op=c_le_change');
    }
    
    
f�ge danach hinzu:

    if ($session['marriedto']>=0) {
        addnav("Sex");
        addnav("gesch�tzt","houses_private.php?op=drin&act=geschuetzt");
        addnav("ungesch�tzt","houses_private.php?op=drin&act=kind");
        addnav('Verschiedenes');
    }
    

suche:

case 'desc':

        $int_max_length = getsetting('housedesclen',500);

        $owner= false;
        // Feststellen, ob Hausbesitzer oder nicht
        if($session['user']['housekey'] == $session['housekey']) {
            $owner = true;
            $sql = 'SELECT private_description AS description FROM houses WHERE houseid='.$session['housekey'];
        }
        else {
            $sql = 'SELECT description,id FROM items WHERE tpl_id="privb" AND value1='.$session['housekey'].' AND owner='.$session['private'];
        }
        $res = db_query($sql);
        $house = db_fetch_assoc($res);

        if($_GET['act'] == 'ok') {
            $desc = closetags(stripslashes($_POST['description']),'`c`i`b');
            $desc = strip_tags($desc,'<img>');
            $desc = substr($desc,0,$int_max_length);

            if(!$owner) {
                item_set(' id='.$house['id'], array('description'=>$desc) );

            }
            else {
                $sql = 'UPDATE houses SET private_description="'.addslashes($desc).'" WHERE houseid='.$session['housekey'];
                db_query($sql);
            }
            redirect('houses_private.php');
        }

        $link = 'houses_private.php?op=desc&act=ok';
        addnav('',$link);
        addnav('Zur�ck','houses_private.php');

        $str_output .= '<form action=\''.$link.'\' method=POST>';
        $arr_form = array(    'desc_pr'=>'Vorschau:,preview,description',
        'description'=>'`2Gebe eine Beschreibung f�r dein Haus ein:`n,textarea,40,20,'.$int_max_length);

        output($str_output,true);
        showform($arr_form,$house,false,'�bernehmen!');
        $str_output = '</form>';

        break;
        
        
f�ge danach hinzu:

case 'drin':
        $sql = "select * from accounts where acctid = " . $session['user']['marriedto'];
        $result = db_query($sql) or die(db_error(LINK));
        $row3 = db_fetch_assoc($result);    
    if($_GET['act'] == 'geschuetzt')
        {
        output("`nAls " . $row3["name"] . "`q, eigentlich nur f�r kurz, in euren Schlafgem�chern vorbei schaut ziehst Du " . ($session['user']['sex']?'ihn':'sie') . " ins Bett und ihr liebt euch den ganzen restlichen Tag heiss und innig.");
        output("`nIhr bleibt schmusend noch ein wenig liegen...`n`n");
        addnav('h?Eigenes Gemach','houses_private.php?private='.$session['user']['acctid'].'&housekey='.$session['housekey']);
        systemmail($session['user']['marriedto'],"`%Du hattest Sex!`0","`%".$session['user']['name']." hat Dich gerade verf�hrt, da Ihr aber gesch�tzten Verkehr hattet brauchst Du vor einer Schwangerschaft keine Sorgen haben");    
        }
    if($_GET['act'] == 'kind')
        {    
        output("`nDu ziehst " . $row3["name"] . "`q z�rtlich an Dich ran und verw�hnst " . ($session['user']['sex']?'ihn':'sie') . " nach allen Regeln der Kunst und bereitest Euch beiden einen wundervollen Abend.");
        output("`nV�llig ersch�pft und ausgelaugt bleibt Ihr beide noch im Bett liegen und geniesst die Zweisamkeit.`n`n");
        systemmail($session['user']['marriedto'],"`%Du hattest Sex!`0","`%".$session['user']['name']." hat Dich gerade verf�hrt, da Ihr ungesch�tzten Verkehr hattet k�nnte es passieren das Ihr bald ein Kind zusammen bekommt");
        if($session["user"]["sex"] != $row3["sex"])
            $kindokay = true;
        else
            $kindokay = false;
    
        if($session["user"]["superuser"] >= 1)
            $session["user"]["sexheute"] = 0;
            
        if($session["user"]["sexheute"] + $row3["sexheute"] < 6)
        {
            debuglog("hatte mit " . $row3["acctid"] . "-" . $row3["name"] . " sex");
            
            if($row3["acctid"] < $session["user"]["acctid"])
            {
                $spielera = $row3["acctid"];
                $spielerb = $session["user"]["acctid"];
            }
            else
            {
                $spielera = $session["user"]["acctid"];
                $spielerb = $row3["acctid"];
            }
            
            $sqlsex = "SELECT * FROM sexwermitwem WHERE spielera = $spielera AND spielerb = $spielerb";
            $resultsex = db_query($sqlsex) or die(db_error(LINK));
            if($rowsex = db_fetch_assoc($resultsex))
                $sqlsex = "UPDATE sexwermitwem SET sexzahl = sexzahl + 1 WHERE spielera = $spielera AND spielerb = $spielerb";
            else
                $sqlsex = "INSERT INTO sexwermitwem VALUES($spielera, $spielerb, 1)";
                
            db_query($sqlsex) or die(db_error(LINK));

            if($kindokay)
            {
                if($session['user']['sex'])
                    $empf = $session['user']['ssempf'];
                else
                    $empf = $row3['ssempf'];
                
                // $sql = "insert into commentary values(0, 'private-".$row["houseid"] . "', " . $session["user"]["acctid"] . ", '/me `&hat mit " . $row3["name"] . " `&geschlafen',now())";
                // $result = db_query($sql) or die(db_error(LINK));

                if($session["user"]["ssstatus"] == 0 && $row3["ssstatus"] == 0)
                {
                    if(e_rand()%9 == $empf)
                        $schwanger = true;
                    else
                        if(e_rand()%9 == $empf)
                            $schwanger = true;
                        else
                            $schwanger = false;
                }
            }
            else
            {
                // $sql = "insert into commentary values(0, 'inn-" . $HTTP_GET_VARS["sop"] . "', " . $session["user"]["acctid"] . ", '/me `&hat mit " . $row3["name"] . " `&geschlafen',now())";
                // $result = db_query($sql) or die(db_error(LINK));
            }
            $session["user"]["sexheute"]++;
            $session["user"]["charm"] += 1;

            $sql2 = "update accounts set charm = charm + 1, sexheute = sexheute + 1 WHERE acctid ='".$row3["acctid"]."'"; 
            db_query($sql2) or die(db_error(LINK)); 
            
            
            if($schwanger)
            {
                if($session['user']['sex'])
                { // frau
                    debuglog("ist von " . $row3["acctid"] . "-" . $row3["name"] . " schwanger");
                    addnews($session['user']['name']." ist soeben von ".$row3["name"]." geschw�ngert worden. Alle Einwohnern gratulieren dazu.");
                    $session["user"]["ssstatus"] = 1;
                    $session["user"]["sstritte"] = 0;
                    $session["user"]["ssmonat"] = 64;
                    $session["user"]["sserzeug"] = $row3["acctid"];
    
                    $sql2 = "update accounts set charm = charm + 10 WHERE acctid=".$row3[acctid]; 
                    db_query($sql2) or die(db_error(LINK)); 
                    $session["user"]["charm"] += 10;
                }
                else
                {
                    debuglog("hat " . $row3["acctid"] . "-" . $row3["name"] . " geschw�ngert");
                    $sql2 = "update accounts set charm = charm + 10, ssstatus = 1, ssmonat = 19, sstritte = 0, sserzeug = " . $session[user][acctid] . " WHERE acctid='".$row3[acctid]."'"; 
                    db_query($sql2) or die(db_error(LINK)); 
                    $session["user"]["charm"] += 10;
                    }
            }
            if($session["user"]["superuser"] >=1)
            {
                $bufflist = unserialize(stripslashes($row3['bufflist']));
                $bufflist['goettlichersex'] = array("name"=>"`%G�ttliches Andenken","rounds"=>100,"wearoff"=>"Die Errinerung verfliegt f�r heute!","atkmod"=>1.75,"roundmsg"=>"Du denkst immer noch an den g�ttlich intimen Stunden...","activate"=>"offense");
                $sql2 = "update accounts set sexgoettlich = 100, bufflist = '" . addslashes(serialize($bufflist)) . "' WHERE acctid='".$row3[acctid]."'"; 
                db_query($sql2) or die(db_error(LINK)); 
            }
            if($row3["superuser"] >=1)
            {
                $session["user"]["sexgoettlich"] = 100;
                $session['bufflist']['goettlichersex'] = array("name"=>"`%G�ttliches Andenken","rounds"=>100,"wearoff"=>"Die Errinerung verfliegt f�r heute!","atkmod"=>1.75,"roundmsg"=>"Du denkst immer noch an den g�ttlich intimen Stunden...","activate"=>"offense");
            }
        }
        else
            output("`n`nIrgendwie seit ihr nicht in der Stimmung dazu...`n");
        if($session["user"]["superuser"] >= 2)
        {
            output("`n`nDebug`n");
            output("Sex heute: " . $session["user"]["sexheute"] . "`n");
            output("Sex gesamt: " . $session["user"]["sexgesamt"] . "`n");
            output("Empf�ngnis: " . $empf . "`n");
        }
        addnav('h?Eigenes Gemach','houses_private.php?private='.$session['user']['acctid'].'&housekey='.$session['housekey']); 
    }
            output('`n');
            break;
            
            
###############################
houses_private.php speichern und schliessen

�ffne hof.php
###############################

suche:

else if ($_GET['op']=="paare")
{
    output("In einem Nebenraum der Ruhmeshalle findest du eine Liste mit Helden ganz anderer Art. Diese Helden Meistern gemeinsam die Gefahren der Ehe!`n`n");
    $sql = "SELECT acctid,name,marriedto FROM accounts WHERE sex=0 AND charisma=4294967295 ORDER BY acctid DESC";
    output('`c`b`&Heldenpaare dieser Welt`b`c`n');
    output("<table cellspacing=0 cellpadding=2 align='center'><tr><td><img src=\"images/female.gif\">`b Name`b</td><td></td><td><img src=\"images/male.gif\">`b Name`b</td></tr>",true);
    $result = db_query($sql) or die(db_error(LINK));
    if (db_num_rows($result)==0)
    {
        output("<tr><td colspan=4 align='center'>`&`iIn diesem Land gibt es keine Paare.`i`0</td></tr>",true);
    }
    for ($i=0; $i<db_num_rows($result); $i++)
    {
        $row = db_fetch_assoc($result);
        $sql2 = "SELECT name FROM accounts WHERE acctid=".$row['marriedto']."";
        $result2 = db_query($sql2) or die(db_error(LINK));
        $row2 = db_fetch_assoc($result2);
        output("<tr class='".($i%2?"trlight":"trdark")."'><td>`&$row2[name]`0</td><td>`) und `0</td><td>`&",true);
        output("$row[name]`0</td></tr>",true);
    }
    output("</table>",true);
}

f�ge dnach hinzu:

else if ($_GET[op]=="kinder")
    {
    output("In einem Nebenraum der Ruhmeshalle findest du eine Liste mit allen Kindern und Jugendlichen die noch keine Helden sind!`n`n");
    $sql = "SELECT * FROM kinder";
    $result = db_query($sql);
    output("<table><tr class=trhead><td>Name</td><td>&nbsp;</td><td>Mama</td><td>Papa</td><td>Geburtsdatum</td><td>Information</td></tr>", true);
    while ($row = db_fetch_assoc($result)) {
        output("<tr class=".($i%2?"trlight":"trdark")."><td>" . $row[name], true);
        if($row['geschlecht'] == 1)
            output("<td>`c<img src=images/female.gif>`c</td>", true);
        else
            output("<td>`c<img src=images/male.gif>`c</td>", true);
            
        output("</td>", true);
        
        $sqlm = "SELECT name FROM accounts WHERE acctid = " . $row[mama];
        $resultm = db_query($sqlm) or die(db_error(LINK));
        if($rowm = db_fetch_assoc($resultm)) 
            output("<td>" . $rowm[name] . "</td>", true);
        else
            output("<td>`c---`c</td>", true);
        $sqlp = "SELECT name FROM accounts WHERE acctid = " . $row[papa];
        $resultp = db_query($sqlp) or die(db_error(LINK));
        if($rowp = db_fetch_assoc($resultp)) 
            output("<td>" . $rowp[name] . "</td>", true);
        else
            output("<td>`c---`c</td>", true);
        output("<td>" . $row[gebdat] . "</td><td>" . $row[info] . "</td></tr>", true);
    }
    output("</table>",true);
}

###############################
hof.php speichern und schliessen

�ffne newday.php
###############################

suche:

    // Buffs
    $tempbuf = unserialize($session['user']['bufflist']);
    $session['user']['bufflist']='';
    $session['bufflist']=array();
    if(is_array($tempbuff))
    {
        foreach($tempbuff as $key => $val)
        {
            if ($val['survivenewday']==1){
                $session['bufflist'][$key]=$val;
                output("{$val['newdaymessage']}`n");
            }
        }
    }
    // END Buffs


f�ge danach hinzu:

if ($session['user']['sex'] == 1) {
            $session['user']['ssempf'] = e_rand()%9;
        if($row['ssstatus'] == 1 && $row['ssmonat'] <= 16)
        {
            output("Da deine Frau schwanger ist, bist Du ein wenig aufgeregt... gut Du bist sehr aufgeregt`n");
            $session['bufflist']['schwanger'] = array("name"=>"`&Deine Frau ist schwanger","rounds"=>1000000,"wearoff"=>"Irgendwas stimmt nicht mehr.","defmod"=>0.2,"roundmsg"=>"`9Du bist abgelenkt an den Gedanken das Du bald Vater wirst.","activate"=>"offense");
        }

            
        if($session['user']['ssstatus'] == 1)
        {
            $session['user']['ssmonat']--;
            if($session['user']['ssmonat'] <= 16)
            {
                if($session['user']['ssmonat'] > 0)
                {
                    output("Du bist schwanger... Also pass auf dich auf`n");
                    $session['bufflist']['schwanger'] = array("name"=>"`&Schwangerschaft","rounds"=>1000000,"wearoff"=>"Irgendwas stimmt nicht mehr.","defmod"=>0,"roundmsg"=>"`9Du versucht deinen Bauch zu sch�tzen und nimmst so jeden anderen Treffer in kauf.","activate"=>"offense");
                    if($session['user']['superuser'] >= 2)
                        output("Noch " . $session['user']['ssmonat'] . " Tage");
                }
                else
                {
                    
                    $sql = "SELECT * FROM accounts WHERE acctid = ".$session['user']['marriedto'];
                    $result = db_query($sql) or die(db_error(LINK));
                    $row = db_fetch_assoc($result);
                    
                    $zwilling = e_rand()%25;
                    if($zwilling == 1)
                    {
                        $session['user']['ssstatus'] = 0;
                        $geschlechta = e_rand()%2;
                        $geschlechtb = e_rand()%2;
                        output("`&Du bist bist heute Mutter geworden... Es sind Zwillinge! Vergiss nicht die neuen Erdenb�rger in der Kappelle zu taufen, sonst wird niemals jemand wissen das es ihn gibt und das w�re doch traurig!`n");
                        
                        if($geschlechta == $geschlechtb && $geschlechtb == 1)
                            $t = "Es sind zwei M�dchen!`n";
                        else if($geschlechta == $geschlechtb && $geschlechtb == 0)
                            $t = "Es sind zwei Jungs!`n";
                        else
                            $t = "Es ist ein M�dchen und ein Junge!`n";
    
                        output($t);
                     
                        systemmail($session['user']['marriedto'],"`%Du bist Vater!`0","`&Deine Frau {$session['user']['name']}`6 hat heute ein zwei wundersch�ne Babies zur Welt gebracht, vergesst nicht sie im Tempel zu taufen. " . $t);
                        systemmail($session['user']['acctid'],"`%Du bist Mutter!`0","`&Du`6 hast heute zwei wundersch�ne Babies zur Welt gebracht, vergesst nicht sie im Tempel zu taufen. " . $t);
                        addnews($session['user']['name']." & ".$row['name']." sind heute Eltern geworden.");
                        if($session['user']['sserzeug'] != $session['user']['marriedto'])
                            $unehelich = 1;
                        else
                            $unehelich = 0;
                        $sqlkind = "INSERT INTO kinder VALUES ('', '" . $session['user']['acctid'] .  "', '" . $session['user']['sserzeug'] .  "', '', '" . $geschlechta . "', '" . getgamedate() . "', $unehelich, '');";
                        db_query($sqlkind) or die(db_error(LINK));
                        $sqlkind = "INSERT INTO kinder VALUES ('', '" . $session['user']['acctid'] .  "', '" . $session['user']['sserzeug'] .  "', '', '" . $geschlechtb . "', '" . getgamedate() . "', $unehelich, '');";
                        db_query($sqlkind) or die(db_error(LINK));
                    }
                    else
                    {
                        $session['user']['ssstatus'] = 0;
                        $geschlecht = e_rand()%2;
                        output("`&Du bist bist heute Mutter geworden... Vergiss nicht den neuen Erdenb�rger in der Kappelle zu taufen, sonst wird niemals jemand wissen das es ihn gibt und das w�re doch traurig!`n");
                        
                        if($geschlecht == 1)
                            $t = "Es ist ein M�dchen!";
                        else
                            $t = "Es ist ein Junge!";
                            
                        output($t);
                        
                        systemmail($session['user']['marriedto'],"`%Du bist Vater!`0","`&Deine Frau {$session['user']['name']}`6 hat heute ein wundersch�nes Baby zur Welt gebracht, vergesst nicht es im Tempel zu taufen. " . $t);
                        systemmail($session['user']['acctid'],"`%Du bist Mutter!`0","`&Du`6 hast heute ein wundersch�nes Baby zur Welt gebracht, vergesst nicht es im Tempel zu taufen. " . $t);
                        addnews($session['user']['name'] . " & " . $row['name'] . " sind heute Eltern geworden.");
                        if($session['user']['sserzeug'] != $session['user']['marriedto'])
                            $unehelich = 1;
                        else
                            $unehelich = 0;
                        $sqlkind = "INSERT INTO kinder VALUES ('', '" . $session['user']['acctid'] .  "', '" . $session['user']['sserzeug'] .  "', '', '" . $geschlecht . "', '" . getgamedate() . "', $unehelich, '');";
                        db_query($sqlkind) or die(db_error(LINK));
                    }
                    // KIND BEKOMMEN
                }
            }
        }
        
        $session[user][sexheute] = 0;

        if($session[user][sexgoettlich] > 0)
        {
            $session[user][sexgoettlich]--;
            output("`&Du errinerst dich an die sch�nen Stunden die Du mit einem Gott verbracht hast`n");
            $session['bufflist']['goettlichersex'] = array("name"=>"`%G�ttliches Andenken","rounds"=>$session[user][sexgoettlich],"wearoff"=>"Die Errinerung verfliegt f�r heute!","atkmod"=>1.75,"roundmsg"=>"Du denkst immer noch an den g�ttlich intimen Stunden...","activate"=>"offense");
        }
    }
    
###############################
newday.php speichern und schliessen

�ffne user.php
###############################

suche:

            "guildid"=>"GildenID,int",
            "guildrank"=>"Gildenrang (1-".count($dg_default_ranks)."),int",
            "guildfunc"=>"Funktion in der Gilde,enum".$guildfuncs,
            
            
f�ge danach hinzu:

            "Kindersystem,title",
            "ssstatus"=>"Schwanger?,enum,0,Nein,1,Ja",
            "ssmonat"=>"Schwangerschafts Monat (64 Std),int",
            "sserzeug"=>"ID des Vaters,int",
            
            
###############################
user.php speichern und schliessen

�ffne lib/output_lib.php
###############################

suche:

        $charstat=appoencode(templatereplace('statstart')
        .templatereplace('stathead',array('title'=>'Vital-Info'))
        .templatereplace('statrow',array('title'=>'Name','value'=>appoencode($u['name'],false)))
        ,true);
        
ersetze mit:

        $ssm = $session['user']['ssmonat'];            
        if ($ssm >= 63) { $sss = "Noch nichts zu sehen"; }
        else if ($ssm >= 53) { $sss = "Kleiner Bauch"; }
        else if ($ssm >= 21) { $sss = "Dicker Bauch"; }
        else if ($ssm >= 5) { $sss = "Sehr dicker Bauch"; }
        else if ($ssm >= 1) { $sss = "Hochschwanger"; }
        
        $charstat=appoencode(templatereplace('statstart')
        .templatereplace('stathead',array('title'=>'Vital-Info'))
        .templatereplace('statrow',array('title'=>'Name','value'=>appoencode($u['name'],false)))
        .($session['user']['ssstatus']?templatereplace('statrow',array('title'=>'Schwanger','value'=>$sss)):'')            
        ,true);

###############################
lib/output_lib.php speichern und schliessen

Ende

falls irgendwelche anderen von mir vorgenommenen �nderungen mit reingerutscht sein sollten bitte ich dies zu verzeihen
desweiteren hab ich kleine Modifikationen vorgenommen (Systemmails und News hinzugef�gt)
*/
?>