<?php
/**
 * @desc  NEW SOURCE.PHP by ALUCARD :>
 * @longdesc Die Source.php zeigt nur noch explizit freigegebene Dateien an und sieht h�bscher aus als das Original.
 * Dies ist eine spezielle angepasste Version f�r die Ver�ffentlichung im Anpera Forum
 * @author Alucard
 * @version V1.0 for DS v2.5
 * @copyright Alucard for Atrahor.de (2006)
 */

require_once 'common.php';

/**
 * Trage hier alle Dateien ein, die durch den Sourcecodeeditor angezeigt werden
 */
$legal_files = array(

);

$url=$_GET['url'];
$dir = str_replace("\\","/",dirname($url)."/");
$subdir = str_replace("\\","/",dirname($_SERVER['SCRIPT_NAME'])."/");

while(substr($subdir,0,2)=="//" ){
     $subdir = substr($subdir,1);
}

$legal_dirs = array(
	array('dir'=>$subdir,'td'=>1),
	array('dir'=>$subdir.'special/','td'=>1),
);

$str_out = '<html><head><title>Quellcodeviewer der Dragonslayer-Edition</title><link href="newstyle.css" rel="stylesheet" type="text/css"><style type="text/css">
					@import url(templates/colors.css);
				</style></head><body bgcolor="#000000" text="#CCCCCC"><table cellpadding=5 cellspacing=0 width="100%"><tr><td class="popupheader"><b>Quellcodeviewer der Dragonslayer-Edition</b></td></tr><tr><td valign="top" width="100%">';

$str_out .= '`c`b`&Quellcodeviewer der Dragonslayer-Edition : '.$logd_version.'`0`b`c`n`n';
$str_out .= 'Anmerkung: Dies ist nur ein Auszug aus dem Source. Um das jeweils aktuelle, vollst�ndige Release zu erhalten,
                        ist eine Anfrage mit g�ltiger Email-Adresse erforderlich. Ebenso sollte darin die Serveradresse bzw.
                        sonstiger Verwendungszweck aufgef�hrt sein. Was wir uns unbedingt verbitten, ist Diebstahl unserer Arbeit
                        ohne Nennung des Copyrights.`n
                        Falls beim Lesen des Source ein Bug entdeckt werden sollte, bitten wir um sofortige Meldung per Anfrage!`n`n';

if($session['message'] != '') {
	output('`n`b'.$session['message'].'`b`n`n');
	$session['message'] = '';
}

function in_dir( $dir ){
	global $legal_dirs;
	foreach($legal_dirs as $d){
		if( $d['dir'] == $dir ){
			return 1;
		}
	}
	return 0;
}

switch($_GET['op'])
{
	case 'show':
		$file = urldecode($_GET['file']);
		$check = preg_replace('/(.*?)\//','',$file);
		$dir = str_replace( $check, '', $file );
		$file = '.'.$file;


		$str_out .= '`n`c`&`b'.$file.'`b`c`n';
		$str_out .= '<a href="source.php">zur�ck</a>`n';
		if($session['user']['superuser']>0 || (in_array( $check, $legal_files )) && in_dir( $dir ))
		{
			$buffer = highlight_file( $file, true );
			$rows = count(explode('<br />',$buffer));
			$znr = '';
			for($i=1; $i <= $rows; $i++) {
				$znr .= "$i:<br />";
			}
			$buffer = '<code><nobr>'.$buffer.'</nobr></code>';
			$str_out .= '<table style="width: 100%;padding:0px;margin:0px;" cellspacing="0">
							<tr>
								<td style="text-align: right; width: 25px; background: #AFAFAF; border-right: 1px solid #000000;">
									<code><nobr>'.$znr.'</nobr></code>
								</td>
								<td style="background: #EFEFEF;" valign="top">';
			output($str_out,true);
			$output .= $buffer;
			$str_out =			'</td>
							</tr>
						</table>';
		}
		else
		{
			$str_out .= '`4`b<big><big>Datei kann nicht angezeigt werden!</big></big>`b`n';
		}
	break;



	// Standardansicht, Auswahl
	default:
		$session['disablevital'] = false;
		$files = array();
		foreach( $legal_dirs as $curr_dir ){
			$d 		  = dir('./'.$curr_dir['dir']);
			$files[$curr_dir['dir']] = array();
			while (false !== ($entry = $d->read())) {
				$end = substr($entry,strrpos($entry,"."));
				if( $end != '.php' && $end != '.lib.php' ){
					continue;
				}
				$files[$curr_dir['dir']][] = $entry;
			}
			sort($files[$curr_dir['dir']]);
		}


		$str_out .= '`c<table cellspacing="2" cellpadding="2"><tr>';
		$lasttd = 1;
		foreach( $legal_dirs as $curr_dir ){
			if( $lasttd ){
				$str_out .= '<td valign="top"><table cellspacing="2" cellpadding="2">';
			}
			$str_out .= '<tr class="trhead"><td colspan="4">`c.'.$curr_dir['dir'].'`c</td></tr>';
			foreach( $files[$curr_dir['dir']] as $file ){
				if($session['user']['superuser'] == 0)
				{
					if( !in_array( $file, $legal_files ) )
					{
						continue;
					}
				}
				$style = ($style == 'trlight' ? 'trdark' : 'trlight');

				$showlink = 'source.php?op=show&file='.urlencode($curr_dir['dir'].$file);


				$str_out .= '<tr class="'.$style.'">
								<td>'.$file.'</td>
								<td><nobr>[ <a href="'.$showlink.'">show</a> ]</nobr></td>
							</tr>';
			}
			//$str_out .= '';
			if( $curr_dir['td'] ){
				$str_out .= '</table></td>';
			}
			$lasttd = $curr_dir['td'];
		}
		$str_out .= '</tr></table>`c';

		break;

}
$str_out .= '</td></tr><tr><td bgcolor="#000000" align="center">'.$logd_version.'</td></tr>

	           </table></body></html>';
output($str_out, true );
echo $output;
?>