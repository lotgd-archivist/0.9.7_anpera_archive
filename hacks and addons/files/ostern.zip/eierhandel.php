<?

#####################################
#                                   #
#            Osterspezial           #
#            f�r den Wald           #
#            von Midgar             #
#  http://www.logd-midgar.de/logd/  #
#        von Sefan Freihagen        #
#       mit Unterst�tzung von       #
#     Laserian, Amon Chan und mfs   #
#          Texte von Charina        #
#            Ostern  2008           #
#            Frohe Ostern           #
#                                   #
#####################################

require_once "common.php";
page_header("Eierhandel");
function bild($dn){
    global $session;
    $pic = "images/$dn";
    output("`n`c<img src='$pic'>`c`n",true);
}
bild("eierhandel.jpg");
if ($_GET[op]==""){
   output("`n`n`c`b`@De`&r E`^ie`&r`^ha`&nd`@el`c`n`n`b");
   output("`n`n`@Du gehst gelangweilt durch den gro�en Wald. Und hoffst endlich mal auf Abwechslung.
   Denn egal wo du hin schaust �berall nur B�ume und Gr�nzeug. Deine Waffe nervt dich auch schon.
   Denn du hast sie schon lange nicht mehr gel�st. Doch die kriegst du nicht runter. Deswegen packst
   du w�tend dein kleines Messer und zerschneidest den G�rtel und schmei�t deine Waffe vor Wut weit
   weg. Erst jetzt merkst du vor Dummheit: `&\"Was mach ich jetzt, wenn ich angegriffen werde? Ich
   sterbe dann wahrscheinlich.\" `@Du �berlegst was du machst.`n`n");
   addnav("Deine Waffe suchen gehen","forest.php?op=suchen");
   addnav("Einen Stock nehmen","forest.php?op=stock");
   $session[user][specialinc] = "eierhandel.php";
}

if ($_GET[op]=="suchen"){
   output("`n`n`@Du trampelst hinter deiner Waffe hinter her und merkst, dass du nun ganz wo anders
   bist. Es ist ein sch�nes weites Feld, das von dem Licht sehr hell beleuchtet wird. Und die
   verschiedenen Blumen riechen einfach wundervoll. Du bist im 7. Himmel so wundervoll riechen die
   Blumen. Dann bemerkst du deine Waffe zwischen dem Gr�nzeug. Du folgst dieser schnell. Aber du
   merkst, dass sie immer tiefer in das Feld gezogen wird. Dann springst du rasch auf deine Waffe
   zu und packst sie stolz. Und hebst diese gl�cklich in die Luft. Du h�rst eine seltsame hohe Stimme:
   `&\"Hallo, du langes etwas, lass seltsames Ding liegen. Es mir geh�ren, habs gefunden.\" `@Dann siehst
   du verwirrt umher und merkst ein H�schen h�lt sich an deiner Waffe fest. Du fragst es verwirrt:
   `&\"Du kannst sprechen? Aber Moment mal das ist meine Waffe. Ich brauche sie dringender als du.\"
   `@Auf deine Frage antwortet das H�schen mit einem seltsamen Nicken. Kurz danach sagt es: `&\"Du
   seltsames Ding wollen? Dann m�ssen du mir Eier abkaufen. Eins kostet 10 Glitzer.\"`@`n`n");
   addnav("Eierkauf");
   addnav("Du kaufst 1 Ei f�r 10 Gold",",forest.php?op=einei");
   addnav("Du kaufst 5 Eier f�r 50 Gold","forest.php?op=eier");
   addnav("Du kaufst nichts","forest.php?op=nichts");
   $session[user][specialinc] = "eierhandel.php";
}

if ($_GET[op]=="stock"){
   output("`n`n`@Du nimmst einen Stock als Waffe und setzt deinen Weg fort.
   Als du den Stock genauer betrachtest siehst du, dass es deine Waffe ist.
   Du atmest erleichtert auf, weil du schon dachtest deine sch�ne Waffe w�re nun verloren.
   Du bleibst erstmal noch ein wenig hier sitzen, der Schock war etwas zu viel dich.`n`n");
   $session['user']['turns']-=3;
   addnav("Zur�ck zum Wald","forest.php");
}

if ($_GET[op]=="einei"){
   output("`n`n`@Das H�schen bedankt sich sehr f�r deinen Kauf und verschwindet ohne dich weiter
   zu st�ren. Und nun hast du ein Ei und deine Waffe. Als du den Weg zur�ck suchst, merkst du,
   dass die Eier, alles angemalte Edelsteine sind. Und nun bist du eigentlich reicher als zuvor
   und gehst stolz weiter jagen.`n`n");
   $session['user']['gems']+=1;
   addnav("Zur�ck zum Wald","forest.php");
}

if ($_GET[op]=="eier"){
   output("`n`n`@Das H�schen bedankt sich sehr f�r deinen Kauf und verschwindet ohne dich weiter
   zu st�ren. Und nun hast du f�nf Eier und deine Waffe. Als du den Weg zur�ck suchst, merkst du,
   dass die Eier, alles angemalte Edelsteine sind. Und nun bist du eigentlich reicher als zuvor
   und gehst stolz weiter jagen.`n`n");
   $session['user']['gems']+=5;
   addnav("Zur�ck zum Wald","forest.php");
}

if ($_GET[op]=="nichts"){
   output("`n`n`@Du willst nichts kaufen, denn deine Mutter hat dir gesagt: `&\"Kaufe nichts von
   Fremden.\" `@Deswegen gehst du einfach so weg mit deiner Waffe. Pl�tzlich merkst du wie du
   unten angeknabbert wirst. Als du runter blickst, bemerkst du hunderte von H�schen. Du bist
   v�llig entsetzt und schl�gst um dich. Damit sie dich in Ruhe lassen. Doch pl�tzlich merkst
   du, die H�schen haben dir deine Beine weg geknabbert und du landest beinlos bei Ramius.`n`n");
   $session['user']['hitpoints']=0;
   addnav("Ramius besuchen","shades.php");
   addnews($session[user][name]." `@hat `&seine `^Beine `@wegen `&w�tenden `^H�ndlerh�schen `@verloren!");
}

$copyright ="<div align='center'><a href=http://www.logd-midgar.de/logd/ target='_blank'>&copy;`^Mi`&dg`@ar`0</a></div>";
output("`n`n`n`n$copyright`n ",true);

page_footer();
?>