<?

#####################################
#                                   #
#            Osterspezial           #
#            f�r den Wald           #
#            von Midgar             #
#  http://www.logd-midgar.de/logd/  #
#        von Sefan Freihagen        #
#       mit Unterst�tzung von       #
#     Laserian, Amon Chan und mfs   #
#      Texte von Brenna Hravani     #
#            Ostern  2008           #
#            Frohe Ostern           #
#                                   #
#####################################
require_once "common.php";
page_header("L�mmer");

if (!isset($session)) exit();

if ($_GET[op]==""){
   output("`n`c`@Die `&Sch�`^ferin`c");
   output("`n`n`@Du erkundest gerade einen Pfad, als dir eine eingez�unte
   Wiese auff�llt. Du k�nntest sie auch gar nicht verfehlen, da ein
   Ohrenbet�ubender L�rm herrscht. Die Wiese ist voller bl�kender L�mmchen,
   kleiner wei�er Fellb�ndel mit vier Beinen, die von einem wild kl�ffenden
   Hund zusammen getrieben werden. Am Rande steht eine h�bsche Sch�ferin,
   die ihrem Hund laute Anweisungen zuruft. Du verstehst kein Wort, f�hrst
   es jedoch auf den allgemein herrschenden Ger�uschpegel zur�ck. Interessiert
   an dem ganzen Trara trittst du n�her und lehnst dich gegen den Zaun.`n`n");
   addnav("Weiter","forest.php?op=weiter");
   $session[user][specialinc] = "laemmer.php";
}

if ($_GET[op]=="weiter"){
   output("`n`n`@Das M�dchen mit den komischen Z�pfen und dem seltsamen Stab in
   der Hand wird auf dich aufmerksam und schenkt dir ein schmelzendes L�cheln.
   `&\"Seid gegr��t!\" `@rufst du ihr zu, um den L�rm zu �bert�nen, und erwiderst
   ihr L�cheln. `&\"Tach ..\" `@entgegnet die Sch�ferin. `&\"Komma bei mich bei!\"
   `@Bitte was?, denkst du dir und verstehst kein Wort. `&\"Ey, gez komma hea!\"
   `@wiederholt sie, als du nicht reagierst, und winkt dich zu sich. Ach, du
   sollst zu ihr kommen. Warum sagte sie das nicht gleich? Beh�nde springst
   du �ber den Zaun und gehst zu ihr. Was sie wohl wollen k�nnte..`n`n");
   addnav("Weiter","forest.php?op=weiter2");
   $session[user][specialinc] = "laemmer.php";
   }

if ($_GET[op]=="weiter2"){
   output("`n`n`&\"Is datt nichn schicket Remmidemmi?\" `@fragt sie dich und zeigt
   auf das Gewusel vor euch. Verwirrt blickst du sie an, verstehst kein Wort
   von dem, was sie da sagt. `&\"Waddema eemt.\" `@meint sie und geht auf den
   Haufen zu. Sie erteilt ihrem Hund ein paar Befehle und dieser trennt eins
   der s��en L�mmchen von der Herde und auf sie zu. Scheinbar ohne gro�e
   Anstrengung hebt sie das Tierchen hoch und kommt wieder zu dir zur�ck.
   `&\"Na los, mach datt M�h ma ei.\" `@Du hast nicht die leiseste Ahnung, was
   sie wollen k�nnte, fragst dich eher, was f�r eine Sprache sie da spricht.
   Die Sch�ferin rollt mit den Augen, als du einfach nicht reagierst, sondern
   nur dumm aus der W�sche schaust. `&\"Du solls datt M�h ei machen.\" `@wiederholt
   sie und streichelt das kleine Schaf. Ach so, du sollst es streicheln.
   Zumindest glaubst du, dass sie das meint.`n`n
   <a href='forest.php?op=streicheln'>Willst du das Schaf streicheln?</a>`n`n
   <a href='forest.php?op=n_streicheln'>Lieber nicht das Schaf streicheln.</a>`n`n",true);
   addnav("","forest.php?op=streicheln");
   addnav("","forest.php?op=n_streicheln");
   addnav("Schaf streicheln","forest.php?op=streicheln");
   addnav("Schaf nicht streicheln","forest.php?op=n_streicheln");
   $session[user][specialinc] = "laemmer.php";
}


if ($_GET[op]=="streicheln"){
   $zufall=e_rand(1,10);
       switch($zufall) {
       case 1:
       case 2:
       output("`@Z�gernd streckst du die Hand aus, stets darauf gefasst, diese
       blitzschnell wieder zur�ck zu ziehen. Du ber�hrst das weiche Fell des
       L�mmchens, welches dich aus s��en Knopfaugen ansieht und ein leises
       M���h von sich gibt. V�llig hingerissen versenkst du deine Finger in
       den wei�en Locken und nimmst dem M�dchen das kleine B�ndel ab. Ein
       �ngstlicher Blick gilt jedoch dem Hund, der sich leise knurrend n�hert.
       Die Sch�ferin grinst und meint: `&\"Der tut nix. Der will nur spieln.\"
       `@Einen Satz, den du sogar verstehst, doch siehst du sie eher zweifelnd an.`n`n

       Diese Zweifel sind sogar berechtigt. Scharfe Z�hne graben sich in deinen
       Arm und zerren daran. Du jaulst vor Schmerz auf und l�sst das Lamm fallen,
       das - gl�cklicherweise unverletzt - zur�ck zur Herde trottet. Die Sch�ferin
       baut sich vor dem Hund auf und schimpft: `&\"Sitz! Sons krisse ein vor die
       Omme!\" `@Der Hund l�sst los, kneift den Schwanz ein und setzt sich mit
       h�ngendem K�pfchen hin. Du reibst dir den schmerzenden Arm, als das M�dchen
       sich an dich wendet: `&\"Tut mich leid.\" `@Sie zuckt mit den Schultern und
       geht mit ihrem Hund davon. Kein sonderlich denkw�rdiges, aber daf�r
       lehrreiches Zusammentreffen. Dein Ausl�ndisch hat sich auf jeden Fall verbessert.`n`n");
       $session['user']['experience']*=1.05;
       $session['user']['hitpoints']*=.95;
       addnav("Zur�ck zum Wald","forest.php");
       break;

       case 3:
       case 4:
       case 5:
       case 6:
       case 7:
       case 8:
       case 9:
       case 10:
       output("`@Z�gernd streckst du die Hand aus, stets darauf gefasst, diese
       blitzschnell wieder zur�ck zu ziehen. Du ber�hrst das weiche Fell des
       L�mmchens, welches dich aus s��en Knopfaugen ansieht und ein leises
       M���h von sich gibt. V�llig hingerissen versenkst du deine Finger in
       den wei�en Locken und nimmst dem M�dchen das kleine B�ndel ab. Ein
       �ngstlicher Blick gilt jedoch dem Hund, der sich leise knurrend n�hert.
       Die Sch�ferin grinst und meint: `&\"Der tut nix. Der will nur spieln.\"
       `@Einen Satz, den du sogar verstehst, doch siehst du sie eher zweifelnd an.`n`n

       Wie sich herausstellt, waren die Zweifel jedoch v�llig unberechtigt. Nach
       einem scharfen Blick von ihr, wedelt der Hund einmal kurz mit der Rute
       und l�sst sich zu ihren F��en nieder. Begeistert kraulst du das possierliche
       Tierchen und spielst mit ihm. Schmunzelnd beobachtet dich das M�dchen und
       krault derweil den Sch�ferhund. Die Stunden dort zaubern ein strahlendes
       L�cheln auf dein Gesicht und du verabschiedest dich gl�cklich. `&\"Mach gut!\"
       `@meint die Sch�ferin und wendet sich der Herde zu. `&\"Gl�ck auf!\" `@Ein letzter
       Wink und sie ist weg. Gl�ck was?, denkst du dir, sinnst aber nicht l�nger
       dar�ber nach und gehst ebenfalls.");
       $session['user']['charm']+=5;
       $session['user']['turns']-=5;
       addnav("Zur�ck zum Wald","forest.php");
       break;
       }
}

if ($_GET[op]=="n_streicheln"){
   output("`n`n`@Nicht sicher, was du von dem ganzen Kauderwelsch halten sollst,
   was die Sch�ferin da von sich gibt, l�sst du deine H�nde bei dir.
   Kopfsch�ttelnd trittst du einen Schritt zur�ck und murmelst etwas
   Unverst�ndliches. `&\"Dann nich..\" `@meint sie Schulterzuckend und geht mit
   dem L�mmchen auf den Armen von dannen. Du schaust ihnen nur kurz nach
   und machst dich ebenfalls auf den Heimweg.`n`n");
   $session['user']['experience']*=.95;
   addnav("Zur�ck zum Wald","forest.php");
}
$copyright ="<div align='center'><a href=http://www.logd-midgar.de/logd/ target='_blank'>&copy;`^Mi`&dg`@ar`0</a></div>";
output("`n`n`n`n$copyright`n ",true);
page_footer();
?>