<?

#####################################
#                                   #
#            Osterspezial           #
#            f�r den Wald           #
#            von Midgar             #
#  http://www.logd-midgar.de/logd/  #
#        von Sefan Freihagen        #
#       mit Unterst�tzung von       #
#     Laserian, Amon Chan und mfs   #
#          Texte von Kerma          #
#            Ostern  2008           #
#            Frohe Ostern           #
#                                   #
#####################################
require_once "common.php";
page_header("Osterschl�ge");
function bild($dn){
    global $session;
    $pic = "images/$dn";
    output("`n`c<img src='$pic'>`c`n",true);
}
if (!isset($session)) exit();
bild("osterschlage.jpg");
if ($_GET[op]==""){
   output("`n`c`@Di`&e O`^st`@ers`^ch`&l�`@ge`c");
   output("`n`n`@Du gehst, gehst und gehst deinen Weg bis dir so elend
   langweilig ist, dass du anf�ngst zu schreien. Deine F��e tragen dich
   weiter. Pl�tzlich kommst du in einem seltsamen Dorf an. Du hast dieses
   Dorf nie gesehen; du kratzt dich am Kopf. Pl�tzlich siehst du wie Leute
   aus den Gassen springen. Nur M�nner! Du schaust entsetzt hin�ber. Du
   denkst: `&\"Verdammt, was wollen die? Mit den Ruten?\" `@Die M�nner mustern
   dich. Sie wissen nicht Recht, ob sie dich mit ihren Ruten schlagen sollen
   oder nicht, denn sie kennen dich nicht. Mit einem male kommen aus der
   n�chsten Schenke einige Frauen heraus. Die M�nner st�rmen auf die Frauen
   zu und schlagen diese mit den Ruten. Zu deiner Verwunderung bekommen
   die M�nner einige Goldst�cke.`n
   Was tust du?`n`n
   <a href='forest.php?op=rute'>Eine Rute schnappen und Frauen hauen.</a>`n`n
   <a href='forest.php?op=abhauen'>Lieber abhauen bevor du geschlagen wirst.</a>`n`n",true);
   addnav("","forest.php?op=rute");
   addnav("","forest.php?op=abhauen");
   addnav("Mitmachen","forest.php?op=rute");
   addnav("Lieber abhauen","forest.php?op=abhauen");
   $session[user][specialinc] = "osterschlage.php";
}

if ($_GET[op]=="abhauen"){
   output("`n`n`@Du drehst dich um und l�ufst um dein Leben. Pl�tzlich stolperst
   du �ber eine Klippe und f�llst hunderte von Metern tief. Man h�rt nur noch ein
   `^\"Platsch!\" `@und deine Innereien liegen verteilt am Grund. Im n�chsten Moment
   bist du bei Ramius und bettelst um Gnade doch er erh�rt dich nicht.`n`n");
   $session['user']['alive']=0;
   $session['user']['hitpoints']=0;
   addnav("Ramius besuchen","shades.php");
   addnews($session[user][name]." `@landet `&als `^Brei `@bei `&Ramius.
   `^Nachdem `@er `&vor `^Bauern `@fl�chten `&wollte.");
   }

if ($_GET[op]=="rute"){
   $goldstuecke=e_rand(50,100);
   $goldstuecke2=$goldstuecke*10;
   output("`n`n`@Du schnappst dir die n�chste Rute, die an einem Haus angelehnt ist
   l�ufst auf eine Frau zu und schl�gst sie. Pl�tzlich, anstatt Gold zu bekommen
   bekommst du eine Ohrfeige. Du schreist auf: `&\"Auu�! Was soll denn das?\" `@Die
   Frau erkl�rt dir, es soll symbolisch geschlagen werden und nicht Schl�ge mit
   Schmerzen. Denn so ein Schlag zeigt der Frau, dass ihre Gesundheit und Sch�nheit
   erhalten bleibt. Frauen die nicht geschlagen werden, sind dann meist beleidigt.
   Auf einmal verstehst du alles. Du l�ufst den Frauen hinter her und schl�gst sie
   geschmeidig. F�r jeden Schlag bekommst du einige Goldst�cke. Am Schluss hast du `^"
   .$goldstuecke2." Goldst�cke `@bekommen. Fr�hlich gehst du wieder deinen gewohnten Weg,
   doch diesmal ohne Langeweile.`n`n");
   $session['user']['gold']+=$goldstuecke2;
   addnav("Zur�ck zum Wald","forest.php");
}
$copyright ="<div align='center'><a href=http://www.logd-midgar.de/logd/ target='_blank'>&copy;`^Mi`&dg`@ar`0</a></div>";
output("`n`n`n`n$copyright`n ",true);
page_footer();
?>