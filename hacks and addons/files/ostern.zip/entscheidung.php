<?

#####################################
#                                   #
#            Osterspezial           #
#            f�r den Wald           #
#            von Midgar             #
#  http://www.logd-midgar.de/logd/  #
#        von Sefan Freihagen        #
#       mit Unterst�tzung von       #
#     Laserian, Amon Chan und mfs   #
#      Texte von Brenna Hravani     #
#            Ostern  2008           #
#            Frohe Ostern           #
#                                   #
#####################################
 require_once "common.php";
page_header("Entscheidung");

if (!isset($session)) exit();


if ($_GET[op]==""){
   output("`n`c`@Die `&Entsch`^eidung`c");
   output("`n`n`@Du wanderst einen Weg entlang und erfreust dich an den Narzissen,
   die am Wegesrand wachsen. W�hrend du dar�ber nachsinnst, ob du deinem Herzblatt
   nicht einen Strau� pfl�cken solltest, entdeckst du pl�tzlich etwas Buntes in
   dem ganzen Gr�n. Neugierig, wie du nun einmal bist, beugst du dich hinab, um
   dieses Ding n�her zu betrachten. Erstaunt stellst du fest, dass es sich um ein
   bemaltes Ei handelt. Die Farben und Muster gefallen dir so gut, dass du es
   kurzerhand einsteckst.`n`n
   Du wanderst weiter, doch schon nach wenigen Metern siehst du wieder etwas Buntes
   aufblitzen. Ein weiteres Ei, welches du ebenfalls einsteckst. Du l�sst deinen Blick
   schweifen und rechts und links vom Wegesrand entdeckst du weitere bunte Flecken im
   Gras. Du blickst zum Ende des Pfades und was du dort ausmachen kannst, l�sst dich
   an deinem Verstand zweifeln. Du reibst dir die Augen, doch auch nach dieser Aktion
   bleibt das Bild das Gleiche.`n`n
   Ein kleines, flauschiges H�schen, das einen riesigen Korb voller bunter Eier auf
   seinem R�cken tr�gt, hoppelt darauf entlang. Ab und an greift es sich ein Ei und
   wirft es ins hohe Gras. Um der Sache auf den Grund zu gehen, eilst du hinter dem
   Langohr her und holst es auch bald ein, obwohl du so viele Eier einsammelst, wie
   du tragen kannst. `&\"He da!\" `@rufst du ihm zu und der Hase wendet sich dir zu. Die
   schwarzen Knopfaugen werden riesengro�, als es die ganzen bunten Eier auf deinen
   Armen sieht. `&\"Aber, die sind doch f�r die Kinder!\" `@echauffiert es sich und wackelt
   aufgebracht mit den �hrchen. `&\"Leg sie sofort dahin zur�ck, wo du sie gefunden hast!\"
   `@verlangt es von dir, doch du bist so verwirrt, dass du es nur anstarrst. Ein
   sprechender Hase? Der Eier versteckt? Ja, ist denn heut schon Ostern?`n`n
   `&\"Was ist nun?\" `@fragt es dich, nachdem du eine Weile stumm auf das Fellkn�uel hinab
   gestarrt hast. Wirst du der Aufforderung nachkommen? Oder beh�ltst du die aufgesammelten
   Eier?`n`n
   <a href='forest.php?op=ja'>Ja, ich lege die Eier zur�ck.</a>`n`n
   <a href='forest.php?op=nein'>Nein, ich behalte sie lieber.</a>`n`n",true);
   addnav("","forest.php?op=ja");
   addnav("","forest.php?op=nein");
   addnav("Eier zur�cklegen","forest.php?op=ja");
   addnav("Eier behalten","forest.php?op=nein");
   $session[user][specialinc] = "entscheidung.php";
}

if ($_GET[op]=="nein"){
   output("`n`n`@Du denkst dar�ber nach, kommst jedoch zu dem Ergebnis, dass du sie viel
   lieber f�r dich behalten m�chtest. `&\"N�!\" `@entgegnest du entschieden und legst sch�tzend
   die Arme um deine Beute. `&\"Was??\" `@quiekt das H�schen emp�rt und das kleine Stimmchen
   �berschl�gt sich fast. `&\"Das wird dir noch leid tun!\" `@droht es dir dann und hoppelt von
   dannen. Kichernd, denn du glaubst dem Fellkn�uel kein Wort - was konnte es dir auch schon
   gro� tun, gehst du den Weg zur�ck, den du gekommen bist. Die Eier verstaust du sorgf�ltig
   in einem Beutel, doch schon nach kurzer Zeit h�rst du ein leises `^\"Plopp\"`@. Verwundert schaust
   du dich um, kannst jedoch nichts finden, was dieses Ger�usch verursachen k�nnte. So gehst du
   weiter, h�rst es aber bald wieder. Und wieder. Und wieder.. Moment, wird dein Beutel nicht
   leichter? Du schaust direkt nach und tats�chlich: Ein buntes Ei nach dem anderen l�st sich
   in Luft auf! Von weit her h�rst du ein h�misches Lachen und meinst die Worte `&\"Ich habe dich
   gewarnt!\" `@ausmachen zu k�nnen. Vielleicht h�ttest du nicht so habgierig sein sollen!`n`n");
   $session['user']['gems']-=5;
   $session['user']['turns']-=5;
   $session['user']['charm']-=5;
   addnav("Zur�ck zum Wald","forest.php");
   }

if ($_GET[op]=="ja"){
   output("`n`n`@Ohne ein Wort zu verlieren gehorchst du und bringst deine Beute dorthin
   zur�ck, wo du sie gefunden hast. Unter den wachsamen Blicken des H�schens, der dir die
   ganze Zeit folgt, deponierst du die zerbrechlichen Dinger wieder im Gras. `&\"So, ist�s fein.\"
   `@lobt der Hase dich und scheint zu l�cheln. Du erwiderst das L�cheln, ob wohl du dich
   nicht ganz wohl in deiner Haut f�hlst. Nachdem du auch das letzte Ei zur�ck gelegt hast,
   strahlt der Flauschehase dich an. `&\"Der Dank der Kinder ist dir sicher!\" `@meint er und
   h�pft aufgeregt auf und ab. `&\"W..wer bist du?\" `@ringst du dich dazu durch zu fragen und
   wartest gespannt auf die Antwort. `&\"Na, der Osterhase!\" `@entgegnet er, erstaunt dar�ber,
   dass du nicht wei�t, wer er ist. Osterhase! Wusstest du es doch! Grinsend siehst du nun
   auf den drolligen Kerl hinab, der dich aufmerksam beobachtet hat. `&\"Da du so nett warst
   und die Eier wieder versteckt hast, darfst du f�nf von ihnen behalten!\" `@meint es gro�z�gig
   und verabschiedet sich von dir. Das H�schen hoppelt den Weg wieder zur�ck und wirft alle
   paar Meter ein Ei in die B�sche. Sobald es aus deinem Blickfeld verschwunden ist, nimmst
   du f�nf der bunten Eier wieder an dich und machst dich auf den Weg nach Hause.`n`n");
   $session['user']['gems']+=5;
   $session['user']['turns']+=5;
   $session['user']['charm']+=5;
   addnav("Zur�ck zum Wald","forest.php");
}
$copyright ="<div align='center'><a href=http://www.logd-midgar.de/logd/ target='_blank'>&copy;`^Mi`&dg`@ar`0</a></div>";
output("`n`n`n`n$copyright`n ",true);
page_footer();
?>