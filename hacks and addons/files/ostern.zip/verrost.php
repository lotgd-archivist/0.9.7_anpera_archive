<?

#####################################
#                                   #
#            Osterspezial           #
#            f�r den Wald           #
#            von Midgar             #
#  http://www.logd-midgar.de/logd/  #
#        von Sefan Freihagen        #
#       mit Unterst�tzung von       #
#     Laserian, Amon Chan und mfs   #
#          Texte von Kerma          #
#            Ostern  2008           #
#            Frohe Ostern           #
#                                   #
#####################################

require_once "common.php";
function bild($dn){
    global $session;
    $pic = "images/$dn";
    output("`n`c<img src='$pic'>`c`n",true);
}

if (!isset($session)) exit();

page_header("Verregnete Ostern");
bild("verrost.jpg");

if ($_GET[op]==""){
   output("`n`n`@Ve`6rr`^eg`@ne`&te `^Os`@te`&rn");
   output("`n`n `@Du gehst durch das Buschwerk am Rande der Wiese, mit
   seinen Bewohnern. Gedankenverloren gehst du weiter und weiter.
   Ohne eigentlich zu wissen wo du hin willst. Die Sonne scheint
   in diesem Moment leicht auf deine Schultern und auf deinen Kopf.
   Pl�tzlich sp�rst du etwas nasses und unangenehmes am R�cken.
   `&\"Wasser!\", `@kreischst du als ob dein R�cken brennen w�rde.
   Doch es ist dir einfach nur kalt, deswegen kreischst du wie ein
   kleines M�dchen. Dann denkst du: `&\"Regnet es!?\" `@Du h�ltst deine
   Hand unglaubw�rdig in die H�he. Irgendwie regnet es.`n`n
   Was willst du tun?`n
   Dem Regen <a href='forest.php?op=laufen'>davon laufen</a>
   oder doch etwas <a href='forest.php?op=schauen'>genauer
   hinschauen?</a>`n`n",true);
   addnav("","forest.php?op=laufen");
   addnav("","forest.php?op=schauen");
   addnav("Vorm Regen weglaufen","forest.php?op=laufen");
   addnav("Genauer hinschauen","forest.php?op=schauen");
   $session[user][specialinc] = "verrost.php";
}

if ($_GET[op]=="laufen"){
   output("`n`n `@Du kreischst wie ein Weltmeister und nimmst deine
   F��e in die H�nde und l�ufst, soweit deine Ausdauer es erlaubt.
   Irgendwann kommst du wieder da an wo du Anfangs standest. Nun
   regnet es hier nicht mehr. Doch du gehst lieber weiter jagen.
   Denn Regen passt dir nicht so.`n`n");
   addnav("Zur�ck zum Wald","forest.php");
   $session[user][specialinc] = "verrost.php";
}

if ($_GET[op]=="schauen"){
   output("`n`n `@Du schaust umher und erkennst, dass dies von
   Binomischen Wesen stammt und nicht vom Wetter. Deswegen
   schaust du die Ursache. Du sagst zu dir: `&\"Wo sind die
   Drecksviecher?\"  `@Du siehst die Ursache: `bKleinkinder`b,
   nun rufst du: `&\"Ich hasse Kinder!\" `@Die Kinder lachen dich
   aus. Du schaust die mit gehobener Augenbraue an. Die Kinder
   zittern vor Angst, als du deine Waffe hebst. Die Kinder
   erkl�ren dir, dass es ein Osterbrauch aus ihrem Dorf sei.
   Du verstehst es, denn du warst fr�her auch mal ein Kind.
   So drehst du dich um und lachst vor dich hin und setzt
   deinen Weg fort. Pl�tzlich sp�rst du wieder eine Fl�ssigkeit
   am R�cken, diese ist irgendwie warm. Du ahnst was es ist du
   schaust auf deine Schulter und siehst eine gelbe Fl�ssigkeit.
   Pl�tzlich h�rst du die Kinder lachen. Vor Wut drehst du dich
   um und siehst wie die Kinder, ihre Hosen zurecht zupfen. Dein
   Kopf l�uft rot an, vor Wut. Und du rennst hinter den B�lgern
   her. Die Kinder sind schneller als du gedacht hast. Nach
   einiger Zeit bringt dich dein Asthma zum halten und du gehst
   mit angepinkelter R�stung weiter. Man h�rt dich n�rgeln:
   `&\"Dumme Br�uche!\" `@Aber eins wundert dich, du hast nicht wie
   sonst bei solchen Begegnungen etwas bekommen. Eigentlich schon
   und zwar eine gelbe R�stung. Zus�tzlich riecht es nicht gerade
   angenehm, du verlierst f�nf Charmpunkte. Mit diesem Gedanken
   wanderst du weiter.`n`n");
   $session['user']['charm']-=5;
   addnav("Zur�ck zum Wald","forest.php");
}

$copyright ="<div align='center'><a href=http://www.logd-midgar.de/logd/ target='_blank'>&copy;`^Mi`&dg`@ar`0</a></div>";
output("`n`n`n`n$copyright`n ",true);

page_footer();
?>