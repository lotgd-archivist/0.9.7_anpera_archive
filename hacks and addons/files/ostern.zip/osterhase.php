<?php
#####################################
#                                   #
#            Osterspezial           #
#         f�r die Osterwiese        #
#            von Midgar             #
#  http://www.logd-midgar.de/logd/  #
#       von Laserian und mfs        #
#       mit Unterst�tzung von       #
#            Amon Chan              #
#         Texte von calamus         #
#           Ostern 2008             #
#           Frohe Ostern            #
#                                   #
#####################################
require_once "common.php";
page_header("Osterhase");
function bild($dn){
    global $session;
    $pic = "images/$dn";
    output("`n`c<img src='$pic'>`c`n",true);
}
bild("osterhase.jpg");
switch($_GET['op']){
default:
$session['user']['specialinc'] = "osterhase.php";
output("`@Vor Dir h�rst Du ein Ger�usch und willst schon Deine Waffe ziehen, als ein Hase mit
einem K�rbchen voll buntbemalter Eier �ber den Pfad h�pft.
Er guckt Dich kurz an und zwinkert mit dem Auge, dann h�pft er weiter seines Weges,
immer wieder kurz anhaltend und ein Ei aus dem K�rbchen auf ein St�ckchen Wiese legend.
`n`n
Hase? bunte Eier? Ostereier! - Du hast den Osterhasen gesehen.
Fr�hlich h�pfend setzt Du Deinen Weg fort. Du erh�lst `^3 Charmepunkte`@.");
$session['user']['charm']+=3;
addnav("Zur�ck zum Wald","forest.php?op=weiter");
break;
case "weiter":
output("`@Du hoppelst weiter zur wilden Osterwiese.");
addnav("Weiter","forest.php");
break;
}
$copyright ="<div align='center'><a href=http://www.logd-midgar.de/logd/ target='_blank'>&copy;`^Mi`&dg`@ar`0</a></div>";
output("`n`n`n`n$copyright`n ",true);
page_footer();
?>