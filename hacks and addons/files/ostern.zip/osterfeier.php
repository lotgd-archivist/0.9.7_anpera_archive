<?php
#####################################
#                                   #
#            Osterspezial           #
#         f�r die Osterwiese        #
#            von Midgar             #
#  http://www.logd-midgar.de/logd/  #
#       von Laserian und mfs        #
#       mit der Unterst�tzung von   #
#             Amon Chan             #
#         Texte von calamus         #
#           Ostern 2008             #
#           Frohe Ostern            #
#                                   #
#####################################
require_once "common.php";
page_header("Osterfeier");
switch($_GET['op']){
default:
$session['user']['specialinc'] = "osterfeier.php";
output("`@Du kommst an einen Pfad, aus dessen Richtung Du fr�hliche Musik h�ren kannst.
Tiefe Spuren von Wagenr�dern haben sich in den Boden gegraben.
Wirst Du dem Pfad folgen und nachsehen, was dort los ist?");
addnav("Zur�ck zum Wald","forest.php?op=zurueck");
addnav("Pfad folgen","forest.php?op=weiter");
break;
case "zurueck":
    output("`@Du denkst du solltest lieber zur�ck gehen.");
    addnav("Wald","forest.php");
break;
case "weiter":
output("`@Du folgst den tiefen R�derspuren, die Musik wird immer lauter.
Inzwischen kannst Du auch verf�hrerischen Geruch nach Braten riechen.
Du kommst auf eine Lichtung, auf der mehrere Wagen stehen.
Eine Gruppe von Menschen macht fr�hliche Musik. �ber einem Feuer wird ein Lamm gegrillt.
Ein kleines M�dchen kommt, sagt `&\"wir feiern Ostern, Du feierst doch mit?\" `@, nimmt Dich
bei der Hand und zieht Dich zu der Gruppe. Eine junge Frau reicht Dir einen Teller mit
Lammfleisch, das Du gen�sslich isst. Du feierst ein wenig mit und gehst dann gut ges�ttigt und
erholt in den Wald zur�ck. Du sp�rst, dass Du Kraft f�r `^3 zus�tzliche Waldk�mpfe`@ hast.");
$session['user']['turns']+=3;
addnav("Weiter","forest.php");
break;
}
$copyright ="<div align='center'><a href=http://www.logd-midgar.de/logd/ target='_blank'>&copy;`^Mi`&dg`@ar`0</a></div>";
output("`n`n`n`n$copyright`n ",true);
page_footer();
?>