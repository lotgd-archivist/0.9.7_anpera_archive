<?php
#####################################
#                                   #
#            Osterspezial           #
#            f�r den Wald           #
#            von Midgar             #
#  http://www.logd-midgar.de/logd/  #
#       von Laserian und mfs        #
#       mit Unterst�tzung von       #
#       Laserian und Amon Chan      #
#          Texte von Shana          #
#            Ostern  2008           #
#            Frohe Ostern           #
#                                   #
#####################################
require_once "common.php";
page_header("Wildes Osterei");
switch($_GET['op']){
default:
$session['user']['specialinc']="killerhase.php";
    output("`@Munter l�ufst du durch den Wald, wo jede einzelne Pflanze viel gr�sser ist als du jemals
    sein wirst. Aber das ist dir egal. Bisher konnte dir hier keiner etwas B�ses. Pah, die kleinen Monster die hier genau
    wie in den ganzen Gegenden um Midgar herum. Sei es der Wald, die Eisebene oder diese Wald. Sch�n
    der Vogelgesang der dir von dem leichten Wind zugetragen wird. Tr�gt er zu deinen mutigen Gedanken bei die dich als
    unbesiegbar aussehen lassen. Kaum
    gedacht schon funkeln dir zwei gl�hend rote �ugelchen entgegen. Sitzen sie stechend auf dich geheftet in dem Gesicht eines
    Hasen. Aber was f�r ein Hase. Nicht so ein kleiner niedlicher Hoppler. Nein es ist ein Killerhase, ein Monsterhase der dir
    da gegen�ber hockt und die Z�hne bleckt. Was machst du? Gehst du wieder um und versuchst dem Biest zu entkommen oder willst
    du dich an ihm vorbei dr�cken. Willst du gar den Kampf mit der langohrigen Bestie aufnehmen?  ");
    addnav("Das ist mir nicht geheuer","forest.php?op=zurueck");
    addnav("Das sehe ich mir n�her an","forest.php?op=weiter");
break;
case "zurueck";
    output("`@Da dir das ganze nicht geheuer ist gehst du zur�ck in das dichte Gew�chs der hoch gewachsenen Pflanzenwelt.
    Du stolperst allerdings und rutscht einen kleinen Abhang hinunter. Nun weisst du nicht mehr wo du bist und verl�ufst dich
    vollkommen. Bis du wieder deinen Weg gefunden hast und dich auskennst ist einige Zeit vergangen, sodass du 5 Runden verlierst.");
    $session['user']['turns']-=5;
    addnav("Zur�ck","forest.php");
break;
case "weiter";
$session['user']['specialinc']="killerhase.php";
    output("`[`@Von brennender Neugier erf�llt stampfst Du durch das hoch gewachsene Gras
    Je n�her Du dem unheimlichen Riesenhasen kommst, desto unheimlicher erscheint Dir das monstr�s grosse Tier.
    Zu gross und unheimlich aussehend mit den stechend roten Augen, lautet Dein Urteil. Stechend fixieren dich die roten
    Augen immer noch und obwohl das weisse Fell weich aussieht und dieser Hase in kleinerer Ausf�hrung wirklich niedlich
    aussehen k�nnte wirkt er gar bedrohlich auf dich.
    Und auch das Z�hne, die dir weiss und gross entgegen blitzen scheinen nicht f�r Karotten gemacht zu sein.
    Nachdem Du Deine Inspektion abgeschlossen hast, wendest Du Dich ab, um wieder in den Wald zu gehen. Das Tier ist dir nicht
    geheuer und warum ein Risiko eingehen?
    Doch dann bemerkst Du aus dem Augenwinkel heraus eine Bewegung und drehst Dich wieder um.
    Mit aufgerissenen Augen starrst Du auf die Stelle, an der nun g�hnende Leere herrscht.
    Von dem Riesenhasen ist nichts mehr zu sehen. Wo ist er nur hin? Suchend drehst Du Dich im Kreis, bis du ihn gefunden hast.
    Mit bedrohlicher Miene, bewegt der grosse Hase sich auf Dich zu. Was machst Du?");
    addnav("Nichts wie weg","forest.php?op=weg");
    addnav("Aus dem mach ich Osterbraten","forest.php?op=kampf2");
break;
case "weg";
output("`@Mit einem spitzen Schrei auf den Lippen, k�mpfst Du Dich durch das hohe Gras und rennst zur�ck gen dem sicheren
Wald. Die Monster dort, kennst Du wenigstens.`n");
switch(e_rand(1,2)){
case 1:
    output("`@Nach Atem ringend erreichst Du den Wildwiesenrand und h�lst erst an, als die Lichtung nicht mehr zu sehen ist.
    Ersch�pft durch die Flucht, verlierst Du einen Waldkampf.");
    $session['user']['turns']-=1;
break;
case 2:
    output("`@R�ckblickend sch�mst Du Dich wegen Deiner Feigheit. Vielleicht wollte er ja nur M�hrchen haben?
    Du verlierst 5 Charmepunkte.");
    $session['user']['charm']-=5;
break;
}
    addnav("Zur�ck","forest.php");
break;
case "kampf2";
$session['user']['specialinc']="killerhase.php";
    output("`@Mutig ziehst Du Deine eigene Waffe, die neben dem grossen Tier wie ein Zahnstocher wirkt und stellst Dich dem Riesenhasen entgegen.");
    addnav("Angriff","forest.php?op=kampf");
break;
case "kampf";

$mod=1+round($session['user']['dragonkills']/10.0);
$badguy = array(
"creaturename"=>"`&Killerhase`0"
,"creaturelevel"=>$session['user']['level']
,"creatureweapon"=>"`&Nagez�hne des Killerhasen`0"
,"creatureattack"=>$session['user']['attack']*$mod
,"creaturedefense"=>$session['user']['defense']*$mod
,"creaturehealth"=>$session['user']['hitpoints']*$mod*2
,"diddamage"=>0);
$session['user']['badguy']=createstring($badguy);

$_GET['op']="fight";

if($_GET['op']=="run"){

        output("`c`b`\$Es gelingt dir nicht zu entkommen.`0`b`c`n`n");
        $battle=true;
}

if($_GET['op']=="fight"){
    $battle=true;
     $session[user][specialinc]="xmas10.php";
}

if ($battle) {
    include("battle.php");
        if ($victory){
             $badguy=array();
               $session['user']['badguy']="";
$session['user']['specialinc']="";
output("`n`@Von dem b�sen Killerhasen ist nichts mehr zu sehen. Nur die Augen liegen rot gl�hend in Form von Eiern auf dem Boden
vor deinen F�ssen. Stattdessen erscheint vor dir ein weisser Hase mit freundlichen Antlitz und warm funkelnde Iriden.
Leise seine warme Stimme die dir seine Worte zutr�gt. \"`&Danke mein tapferer Held, dass du mich aus diesem Monsterleib
befreit hast. Ein Magier der b�sartig gesinnt ist und Ostern hasst hat mich in den K�rper gebannt. Er hat mich vor
langer langer Zeit gefangen genommen und bis heute konnte keiner die wilde Kreatur besiegen. Die Leute sollten Ostern
hassen lernen wenn sie mir dem Osterhasen begegnen und bemerken wie b�sartig ich doch w�re. Dabei war es nur der K�rper
der so kampflustig war. Nun muss ich mich aber sputen damit ich noch die Eier austragen kann und sch�ne Osternester f�r
die Bewohner von Midgar verstecken kann. Mein Dank sollen diese Rubineier sein. Nimm sie dir und erfreue dich an deinem
Reichtum.`@\" Du beugst dich herab und nimmst die Rubineier auf die sich in deiner Hand zu gl�nzenden Edelsteinen verwandeln.
Als du dich bei dem Hasen bedanken willst bemerkst du das er davon gehoppelt ist und du nun hier alleine mit deinem Reichtum
stehst. Gl�cklich ziehst du deiner Wege.
Gl�cklich nimmst Du sie an Dich.");
$session['user']['gems']+=e_rand(3,8);
$session['user']['experience']+=$session['user']['level']*500;
addnews("`&Juhu! ".$session['user']['name']." `&rettete den Osterhasen und ist der Held der Wald.`0");
addnav("Zur�ck","forest.php");
}
elseif($defeat)
        {
        $badguy=array();
                output("`@Der Killerhase l�sst sich pl�tzlich auf Dich fallen und begr�bt Dich unter sich. Du bist tot!");
                $session[user][alive]=false;
                $session[user][hitpoints]=0;
                addnews("`&Ohje! ".$session['user']['name']." `&liegt nun unter einem Hasen begraben. Ob es ein neues
                Osterei wird was der Hase da ausbr�tet? Ramius wird es wissen.`0");




                addnav("T�gliche News","news.php");
}
else
{
fightnav(true,true);
  }
}
break;
case "fight";
    $battle=true;
     $session[user][specialinc]="killerhase.php";
if ($battle) {
    include("battle.php");
        if ($victory){
             $badguy=array();
               $session['user']['badguy']="";
$session['user']['specialinc']="";
output("`@Von dem b�sen Killerhasen ist nichts mehr zu sehen. Nur die Augen liegen rot gl�hend in Form von Eiern auf dem Boden
vor deinen F�ssen. Stattdessen erscheint vor dir ein weisser Hase mit freundlichen Antlitz und warm funkelnde Iriden.
Leise seine warme Stimme die dir seine Worte zutr�gt. \"`&Danke mein tapferer Held, dass du mich aus diesem Monsterleib
befreit hast. Ein Magier der b�sartig gesinnt ist und Ostern hasst hat mich in den K�rper gebannt. Er hat mich vor
langer langer Zeit gefangen genommen und bis heute konnte keiner die wilde Kreatur besiegen. Die Leute sollten Ostern
hassen lernen wenn sie mir dem Osterhasen begegnen und bemerken wie b�sartig ich doch w�re. Dabei war es nur der K�rper
der so kampflustig war. Nun muss ich mich aber sputen damit ich noch die Eier austragen kann und sch�ne Osternester f�r
die Bewohner von Midgar verstecken kann. Mein Dank sollen diese Rubineier sein. Nimm sie dir und erfreue dich an deinem
Reichtum.\" Du beugst dich herab und nimmst die Rubineier auf die sich in deiner Hand zu gl�nzenden Edelsteinen verwandeln.
Als du dich bei dem Hasen bedanken willst bemerkst du das er davon gehoppelt ist und du nun hier alleine mit deinem Reichtum
stehst. Gl�cklich ziehst du deiner Wege.
Gl�cklich nimmst Du sie an Dich.");
$session['user']['gems']+=e_rand(3,8);
$session['user']['experience']+=$session['user']['level']*500;
addnav("Zur�ck","xmaswald.php");
}
elseif($defeat)
        {
        $badguy=array();
                output("``@Der Killerhase l�sst sich pl�tzlich auf Dich fallen und begr�bt Dich unter sich. Du bist tot!");
                $session[user][alive]=false;
                $session[user][hitpoints]=0;
                addnews("`&Ohje! ".$session['user']['name']." `&liegt nun unter einem Hasen begraben. Ob es ein neues
                Osterei wird was der Hase da ausbr�tet? Ramius wird es wissen.`0");



                addnav("T�gliche News","news.php");
}
else
{
fightnav(true,true);
  }
}
break;
}
$copyright ="<div align='center'><a href=http://www.logd-midgar.de/logd/ target='_blank'>&copy;`^Mi`&dg`@ar`0</a></div>";
output("`n`n`n`n$copyright`n ",true);
page_footer();
?>