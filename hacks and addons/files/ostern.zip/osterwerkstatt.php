<?php
#####################################
#                                   #
#            Osterspezial           #
#           f�r den Wald            #
#            von Midgar             #
#  http://www.logd-midgar.de/logd/  #
#            von Calamus            #
#     mit der Unterst�tzung von     #
#    Laserian, Amon Chan und mfs    #
#         Texte von Calamus         #
#            Ostern  2008           #
#            Frohe Ostern           #
#                                   #
#####################################
require_once "common.php";
page_header("Osterwerkstatt");
function bild($dn){
    global $session;
    $pic = "images/$dn";
    output("`n`c<img src='$pic'>`c`n",true);
}

if (!isset($session)) exit();
bild("osterwerkstatt.jpg");
if ($_GET[oster]==""){
        output("`@Aufmerksam gehst Du durch den Wald, als Du querab vom Weg ein Ger�usch h�rst. ");
        output("Du bleibst stehen und lauscht genauer. Es h�rt sich wie Gackern an - jedenfalls nicht gef�hrlich, ");
        output("aber doch ziemlich aufgeregt. Neugierig, wie Du nun mal bist, gehst Du dem Ger�usch entgegen ");
        output("und je n�her Du kommst, desto deutlicher h�rst Du, dass es wirklich Gackern ist. Vor dir lichtet ");
        output("sich der Wald und in dem Moment, als Du aus dem Wald auf eine Lichtung tritts, ");
        output("kr�ht lauthals ein Hahn.`n`n");
        output("Auf der Lichtung siehst Du zwei H�user, auf dem einen Giebel ist kunstvoll ein Hase ");
        output("abgebildet, auf dem anderen ein bunter Hahn. ");
        output("`@Was wirst Du tun - klopfst Du an der T�r mit dem Hasenbild oder an der T�r mit dem Bild des Hahns?");
        addnav("Gehe�zum�Hasen-Haus","forest.php?oster=hase");
        addnav("Gehe�zum�bunter Hahn-Haus","forest.php?oster=hahn");
        $session[user][specialinc]="osterwerkstatt.php";
}else if ($_GET[oster]=="hase"){
        $session[user][turns]++;
        output("`@Du klopfst an das Haus mit dem Bild das Hasen und trittst in das Haus. ");
        output("Du kommst in einen grossen Raum mit lauter Tischen an denen H�schen sitzen. ");
        output("Jedes H�schen hat einen Pinsel in der Hand und eine Palette mit bunt angemischten Farben ");
        output("in der Hand. Tuben mit roter, gelber und blauer Farbe liegen auf den Tischen, ");
        output("K�rbchen mit weissen Eiern stehen auf der einen Seite, K�rbchen mit ");
        output("bunten Eiern auf der anderen Seite, ");
        output("vor den H�schen in einem Eierbecher siehst Du das Ei, das jeweils gerade in Arbeit ist.`n`n");
        output("Hier kommen also all die h�bschen Ostereier her. Ein alter Hase deutet auf einen freien Stuhl ");
        output("und eifrig machst auch Du Dich an die Arbeit und malst Eier an.`n`n");
        output("Nach einiger Zeit lobt Dich der alte Hase und bedankt sich f�r Deine Hilfe und gibt Dir ");
        output("ein besonders sch�n bemaltes Ei.`n`n");
        output("Du h�ttest in der Zeit `^3 Waldk�mpfe `@machen k�nnen, aber das Geschenk des alten Hasen ");
        output("l�sst Dich gl�cklich sein. Du siehst viel sch�ner aus und f�hlst Dich viel st�rker.");
        $session[user][charm]+=3;
        $session[user][turns]-=3;
        $session[user][attack]+=3;
        $session[user][defence]+=3;
        addnav("Zur�ck�zum Wald","forest.php");
        addnews($session[user][name]. "�`@hat `&die `^Osterwerkstatt `@gefunden, `&hat `^fleissig `@geholfen
        `&und `^wurde `@viel `&besser. `^Vielleicht `@solltest `&auch `^Du `@die `&Osterwerkstatt `^suchen...");
        $session[user][specialinc]="";
}else if ($_GET[oster]=="hahn"){
        $session[user][turns]++;
        output("`@Du klopfst an das Haus mit dem bunten Hahn und trittst in ");
        output("das Haus. Nun weist Du, woher das Gackern kam - in mehreren Etagen siehst Du Hennen ");
        output("auf Stangen hocken, hinter sich eine Holzrinne, in die jeweils von lautem Gegacker begleitet ");
        output("Ei um Ei f�llt. Langsam rollen die Eier die Rinnen herunter und landen in grossen, ");
        output("mit Stroh ausgelegten Nestern. Aus diesen Nestern sammeln ein paar H�schen die Eier ");
        output("in grosse K�rbe. Auf dem Mittelgang zwischen den Stangen l�uft ein ");
        output("bunter Hahn auf und ab und bedenkt seine Hennen von ");
        output("Zeit zu Zeit mit einem lauten Kikeriki.`n`n");
        output("Als Dich der Hahn sieht deutet er auf ein volles Nest und den leeren Korb davor und ");
        output("eifrig beginnst Du die Eier in das K�rbchen zu stapeln..`n`n");
        output("Nach einiger Zeit lobt Dich der Hahn und bedankt sich f�r Deine Hilfe mit einem ");
        output("Beutelchen, das er Dir gibt.`n`n");
        output("Du h�ttest in der Zeit `^3 Waldk�mpfe `@machen k�nnen, aber Du f�hlst Dich viel erfahrener. ");
        output("Als Du das Beutelchen �ffnest, siehst Du Gold und Edelsteine.");
        $session[user][gold]+=1000;
        $session[user][gems]+=10;
        $session[user][experience]+=1000;
        $session[user][turns]-=3;
        addnav("Zur�ck�zum Wald","forest.php");
        addnews($session[user][name]. "�`@hat `&die `^Osterwerkstatt `@gefunden, `&hat `^fleissig `@geholfen
        `&und `^wurde `@viel `&reicher. `^Vielleicht `@solltest `&auch `^Du `@die `&Osterwerkstatt `^suchen...");
        $session[user][specialinc]="";
}
$copyright ="<div align='center'><a href=http://www.logd-midgar.de/logd/ target='_blank'>&copy;`^Mi`&dg`@ar`0</a></div>";
output("`n`n`n`n$copyright`n ",true);
page_footer();
?>