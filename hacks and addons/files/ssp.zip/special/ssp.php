<?php
/**
* Waldspecial   : Schere-Stein-Papier
* Autor         : Liath
* Server        : http://germany-project.de/logd
* Datum         : 15. M�rz 2009
* 
* Kontakt       : Liath@mircportal.de 
* Forum         : http://anpera.homeip.net/phpbb3/viewtopic.php?f=43&t=4836
* 
* Beschreibung  :
* 
*   Man trifft im Wald auf einen kleinen Gnom, der einen auf eine Runde Schere-Stein-Papier einl�d.
*   Dabei kann man, je nach Einstellung, Edelsteine, Gold oder Ansehen gewinnen/verlieren
* 
*   Der Gewinn/Verlust kann in den Variablen ganz einfach eingestellt werden, ansonsten ist nichts
*   weiter zu tun, ausser das Special in den entsprechenden Ordner hochzuladen und gegebenenfalls
*   freizuschalten
* 
* Anmerkung     :
* 
*   Dieses ist mein erstes Waldspecial, bei Fehlern meldet Euch bitte bei mir direkt oder im Forum
*/

if (!isset($session)) exit();

// maximale Eins�tze
$gems = '5';
$gold = '2500';
$reputation = '5';

$session['user']['specialinc']='ssp.php';

if($_GET['op']=='play') {
    
    $bet = $_GET['bet'];
    $set = $_GET['set'];
    
    output("`n`nAlso gut, fangen wir an. Wir w�hlen beide gleichzeitig Schere, Stein oder Papier.`n`n
            Schere schneidet Papier, Papier bedeckt den Stein und Stein zerst�rt die Schere. Die Regeln sind Dir ja bestimmt bekannt, so das wir direkt anfangen k�nnen
    `n`n`n`n");
    
    
    
    output("<table align='center'><tr><td>
    <a href='forest.php?op=choose&own=scissor&set=$set&bet=$bet'><img src='./images/ssp/ssp-scissor.gif' border='0'></a>
    <a href='forest.php?op=choose&own=stone&set=$set&bet=$bet'><img src='./images/ssp/ssp-stone.gif' border='0'></a>
    <a href='forest.php?op=choose&own=paper&set=$set&bet=$bet'><img src='./images/ssp/ssp-paper.gif' border='0'></a>
    </td></tr></table>`n`n");    
  
    addnav("","forest.php?op=choose&own=scissor&set=$set&bet=$bet");    
    addnav("","forest.php?op=choose&own=stone&set=$set&bet=$bet");
    addnav("","forest.php?op=choose&own=paper&set=$set&bet=$bet");
    
    addnav("Schere","forest.php?op=choose&own=scissor&set=$set&bet=$bet");
    addnav("Stein","forest.php?op=choose&own=stone&set=$set&bet=$bet");
    addnav("Papier","forest.php?op=choose&own=paper&set=$set&bet=$bet");    
}

else if($_GET['op']=='choose') {
    
    $bet = $_GET['bet'];
    $set = $_GET['set'];
    $scissor = "<img src='./images/ssp/ssp-scissor.gif' border='0'>";
    $stone = "<img src='./images/ssp/ssp-stone.gif' border='0'>";
    $paper = "<img src='./images/ssp/ssp-paper.gif' border='0'>";
    
    switch(e_rand(1,3)) {
        case 1:
            $choose = 'scissor';
        break;
        case 2:
            $choose = 'stone';
        break;
        case 3:
            $choose = 'paper';
        break;
    }
    
    if($_GET['own']=='scissor') {
        
        if ($choose=='scissor') { 
        
            output("`^`c`n`nIhr schwingt Eure H�nde hin und her, nach einer kleinen Weile zeigt:`n`n`n`n`n`c 
                    ".$scissor."`b`4Deine Hand: `n`n
                    ".$scissor."Gegners Hand: `n 
                    `n`n`b`gAaargh, ein Unentschieden. Naja da kann man nichts machen. Vielleicht gewinn ich, ���hm... Du ja das n�chste mal
            ");
            $session['user']['specialinc'] = "";
            addnav("zur�ck","forest.php");
            
        }
        else if ($choose=='stone') {            
            
            output("`^`c`n`nIhr schwingt Eure H�nde hin und her, nach einer kleinen Weile zeigt:`n`n`n`n`n`c 
                    ".$scissor."`b`4Deine Hand: `n`n
                    ".$stone."Gegners Hand: `n
                    `n`n`b`gHah, ich hab Dich besiegt. Das wird Dich einiges kosten mein Freund.
            ");
            switch ($_GET['set']) {
                case 'gems':
                    $session['user']['gems']-=$bet;
                    output("`n`n`^�Du verlierst ".$bet." Edelsteine");
                break;
                case 'gold':
                    $session['user']['gold']-=$bet;
                    output("`n`n`^�Du verlierst ".$bet." Goldst�cke");
                break;
                case 'reputation':
                    $session['user']['reputation']-=$bet;
                    output("`n`n`^�Du verlierst ".$bet." Ansehen");
                break;
            }
            $session['user']['specialinc'] = "";
            addnav("zur�ck","forest.php");
            
        }
        else if ($choose=='paper') {            
            
            output("`^`c`n`nIhr schwingt Eure H�nde hin und her, nach einer kleinen Weile zeigt:`n`n`n`n`n`c 
                    ".$scissor."`b`4Deine Hand: `n`n
                    ".$paper."Gegners Hand: `n
                    `n`n`b`gSo ein Mist, hab ich doch tats�chlich verloren, also gut... hier ist Dein Gewinn.
            ");
            switch ($_GET['set']) {
                case 'gems':
                    $session['user']['gems']+=$bet;
                    output("`n`n`^�Du gewinnst ".$bet." Edelsteine");
                break;
                case 'gold':
                    $session['user']['gold']+=$bet;
                    output("`n`n`^�Du gewinnst ".$bet." Goldst�cke");
                break;
                case 'reputation':
                    $session['user']['reputation']+=$bet;
                    output("`n`n`^�Du gewinnst ".$bet." Ansehen");
                break;
            }
            $session['user']['specialinc'] = "";
            addnav("zur�ck","forest.php");
            
        }        
    }
    else if($_GET['own']=='stone') {
        
        if ($choose=='stone') { 
        
            output("`^`c`n`nIhr schwingt Eure H�nde hin und her, nach einer kleinen Weile zeigt:`n`n`n`n`n`c 
                    ".$stone."`b`4Deine Hand: `n`n
                    ".$stone."Gegners Hand: `n
                    `n`n`b`gAaargh, ein Unentschieden. Naja da kann man nichts machen. Vielleicht gewinn ich, ���hm... Du ja das n�chste mal
            ");
            $session['user']['specialinc'] = "";
            addnav("zur�ck","forest.php");
            
        }
        else if ($choose=='paper') {
                    
            output("`^`c`n`nIhr schwingt Eure H�nde hin und her, nach einer kleinen Weile zeigt:`n`n`n`n`n`c 
                    ".$stone."`b`4Deine Hand: `n`n
                    ".$paper."Gegners Hand: `n    
                    `n`n`b`gHah, ich hab Dich besiegt. Das wird Dich einiges kosten mein Freund.
            ");
            switch ($_GET['set']) {
                case 'gems':
                    $session['user']['gems']-=$bet;
                    output("`n`n`^�Du verlierst ".$bet." Edelsteine");
                break;
                case 'gold':
                    $session['user']['gold']-=$bet;
                    output("`n`n`^�Du verlierst ".$bet." Goldst�cke");
                break;
                case 'reputation':
                    $session['user']['reputation']-=$bet;
                    output("`n`n`^�Du verlierst ".$bet." Ansehen");
                break;
            }
            $session['user']['specialinc'] = "";
            addnav("zur�ck","forest.php");
            
        }
        else if ($choose=='scissor') {            
            
            output("`^`c`n`nIhr schwingt Eure H�nde hin und her, nach einer kleinen Weile zeigt:`n`n`n`n`n`c 
                    ".$stone."`b`4Deine Hand: `n`n
                    ".$scissor."Gegners Hand: `n
                    `n`n`b`gSo ein Mist, hab ich doch tats�chlich verloren, also gut... hier ist Dein Gewinn.
            ");
            switch ($_GET['set']) {
                case 'gems':
                    $session['user']['gems']+=$bet;
                    output("`n`n`^�Du gewinnst ".$bet." Edelsteine");
                break;
                case 'gold':
                    $session['user']['gold']+=$bet;
                    output("`n`n`^�Du gewinnst ".$bet." Goldst�cke");
                break;
                case 'reputation':
                    $session['user']['reputation']+=$bet;
                    output("`n`n`^�Du gewinnst ".$bet." Ansehen");
                break;
            }
            $session['user']['specialinc'] = "";
            addnav("zur�ck","forest.php");
            
        }        
    }
    else if($_GET['own']=='paper') {
        
        if ($choose=='paper') { 
        
            output("`^`c`n`nIhr schwingt Eure H�nde hin und her, nach einer kleinen Weile zeigt:`n`n`n`n`n`c 
                    ".$paper."`b`4Deine Hand: `n`n
                    ".$paper."Gegners Hand: `n
                    `n`n`b`gAaargh, ein Unentschieden. Naja da kann man nichts machen. Vielleicht gewinn ich, ���hm... Du ja das n�chste mal
            ");
            $session['user']['specialinc'] = "";
            addnav("zur�ck","forest.php");
            
        }
        else if ($choose=='scissor') {
                    
            output("`^`c`n`nIhr schwingt Eure H�nde hin und her, nach einer kleinen Weile zeigt:`n`n`n`n`n`c 
                    ".$paper."`b`4Deine Hand: `n`n
                    ".$scissor."Gegners Hand: `n    
                    `n`n`b`gHah, ich hab Dich besiegt. Das wird Dich einiges kosten mein Freund.
            ");
            switch ($_GET['set']) {
                case 'gems':
                    $session['user']['gems']-=$bet;
                    output("`n`n`^�Du verlierst ".$bet." Edelsteine");
                break;
                case 'gold':
                    $session['user']['gold']-=$bet;
                    output("`n`n`^�Du verlierst ".$bet." Goldst�cke");
                break;
                case 'reputation':
                    $session['user']['reputation']-=$bet;
                    output("`n`n`^�Du verlierst ".$bet." Ansehen");
                break;
            }
            $session['user']['specialinc'] = "";
            addnav("zur�ck","forest.php");
            
        }
        else if ($choose=='stone') {            
            
            output("`^`c`n`nIhr schwingt Eure H�nde hin und her, nach einer kleinen Weile zeigt:`n`n`n`n`n`c 
                    ".$paper."`b`4Deine Hand: `n`n
                    ".$stone."Gegners Hand: `n 
                    `n`n`b`gSo ein Mist, hab ich doch tats�chlich verloren, also gut... hier ist Dein Gewinn.
            ");
            switch ($_GET['set']) {
                case 'gems':
                    $session['user']['gems']+=$bet;
                    output("`n`n`^�Du gewinnst ".$bet." Edelsteine");
                break;
                case 'gold':
                    $session['user']['gold']+=$bet;
                    output("`n`n`^�Du gewinnst ".$bet." Goldst�cke");
                break;
                case 'reputation':
                    $session['user']['reputation']+=$bet;
                    output("`n`n`^�Du gewinnst ".$bet." Ansehen");
                break;
            }
            $session['user']['specialinc'] = "";
            addnav("zur�ck","forest.php");
            
        }        
    }    
}

else if($_GET['op']=='leave') {
    $session['user']['specialinc'] = "";
    redirect('forest.php');   
}
else {

    if ($session['user']['gems'] > 0) {
     
        if ($session['user']['gems'] >= $gems) { $bet = $gems; }
        else { $bet = $session['user']['gems']; }
        $set = 'gems';
        
        output("`^Auf Deinen Streifz�gen durch den Wald begegnest Du einem kleinen Gnom. `n`n`gAah ein Opf.. ��hm Mitspieler, sei mir gegr�sst ".$session['user']['name']."
                `n`n`gM�chtest Du ein kleines Spiel mit mir spielen? Du kennst Doch sicherlich das Spiel Schere-Stein-Papier. Lass uns doch um ein paar Edelsteine
                spielen, sagen wir um $bet von Deinen Klunkern. Du hast doch bestimmt welche dabei.`n
        ");
    }
    else if ($session['user']['gold'] > 0) {
        
        if ($session['user']['gold'] >= $gold) { $bet = $gold; }
        else { $bet = $session['user']['gold']; }
        $set = 'gold';
        
        output("`^Auf Deinen Streifz�gen durch den Wald begegnest Du einem kleinen Gnom. `gAah ein Opf.. ��hm Mitspieler, sei mir gegr�sst ".$session['user']['name']."
                `n`n`gM�chtest Du ein kleines Spiel mit mir spielen? Du kennst Doch sicherlich das Spiel Schere-Stein-Papier. Lass uns doch um ein paar Goldst�cke
                spielen, sagen wir um $bet von Deinen Goldst�cken. Du hast doch bestimmt welche dabei.`n
        ");
    }
    else {
        
        $bet = $reputation;
        $set = 'reputation';
        
        output("`^Auf Deinen Streifz�gen durch den Wald begegnest Du einem kleinen Gnom. `gAah ein Opf.. ��hm Mitspieler, sei mir gegr�sst ".$session['user']['name']."
                `n`n`gM�chtest Du ein kleines Spiel mit mir spielen? Du kennst Doch sicherlich das Spiel Schere-Stein-Papier. Lass uns doch einfach nur so spielen, dadurch
                kann sich h�chstens Dein Ansehen ver�ndern.`n
        ");
    }
    
    addnav("mitspielen","forest.php?op=play&bet=$bet&set=$set");
    addnav("weiter gehen","forest.php?op=leave");    
}
?>