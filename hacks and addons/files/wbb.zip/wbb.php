<?php
	/***************************************************************
	 ** Script WBB in LoGD einbinden by Spanky                    **
	 ** Meldet euch bei Fragen im Forum www.anpera.net ;)         **
	 ***************************************************************
	 ** Dieser Hack bewirkt Folgendes:                            **
	 ** - Wenn ein User erstellt wird, wird auch im WBB ein User  **
	 **   erstellt                                                **
	 ** - Wenn ein User gelöscht wird (Inaktivität, Löschen durch **
	 **   User, Löschen durch Admin), wird auch der User im WBB   **
	 **   gelöscht                                                **
	 **                                                           **
	 **             Viel Spaß und Erfolg mit dem Hack!            **
	 ***************************************************************/	 
	 
	// ----------EDITIERE FOLGENDE DATEN----------
	define('WBBHOST','localhost'); //MySQL Host (WBB)
	define('WBBUSER','meinuser'); //Username der Datenbank (WBB)
	define('WBBPASS','meinpasswort'); //Passwort (WBB)
	define('WBBDBNAME','meinedb'); //Datenbankname (WBB)
	define('WBBPREFIX','bb1_'); //Prefix des WBB (Standard: bb1_)
	
	
	function wbbquery($sql) {

		$connectwbb = mysql_connect(WBBHOST,WBBUSER,WBBPASS) or die ('Fehler beim Verbinden!'.mysql_error());
		mysql_select_db(WBBDBNAME, $connectwbb);
		$qry = @mysql_query($sql);
		if(!$sql) {
		echo 'MySQL Fehler: '.$sql.' - '.$mysql_error().'('.$mysql_errno().')';
		die();
		}		
		mysql_close($connectwbb);
		
		require_once('dbconnect.php');
		global $DB_HOST;
		global $DB_USER;
		global $DB_PASS;
		global $DB_NAME;
		
		$reconnect = mysql_connect($DB_HOST,$DB_USER,$DB_PASS) or die ('Fehler beim Verbinden!'.mysql_error());
		mysql_select_db($DB_NAME, $reconnect) or die ('Fehler beim Auswählen der Datenbank!');
		
		return $qry;
		
	}
?>
