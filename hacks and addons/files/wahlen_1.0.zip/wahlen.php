<? 

// Wahlen von Yorlii Che'el: http://www.child-of-mystik-moon.de/lotgd// 
// Von Newbi, mit gro�em Danke an einen geduldigen DOM, der Newbifragen beantwortet hat// 



require_once "common.php"; 
page_header("Wahlen"); 
switch ($_GET['op']){ 


case 'ende': 
$sql= "UPDATE accounts SET buergermeister = 0 "; 
db_query($sql); 
output("Die Wahl ist beendet"); 
addnav(" Wahlergebnisse","wahlen.php"); 
break; 

case 'nimm': 
output("`#Du kr�nst den neuen F�rsten`n"); 
$sql = "UPDATE accounts SET buergermeister= 1 WHERE acctid='$id'"; 
db_query($sql); 

$sql = "UPDATE accounts SET getvote= 0 WHERE getvote >= 0 "; 
db_query($sql); 
if ($session[user][superuser]>=2)addnav("Ende","wahlen.php?op=beenden"); 
break; 

case 'beenden': 
$sql = "UPDATE accounts SET getvote= 0 WHERE getvote >= 0 "; 
db_query($sql); 
$sql = "UPDATE accounts SET gavevote= '0' WHERE gavevote >= 0 "; 
db_query($sql); output("Die Wahl ist beendet."); 
$session[user][gavevote]==0; 
if ($session[user][superuser]>=2) addnav("Dorf","village.php"); 
break; 

default: 
output("`cDas Wahlzimmer`c`n`n`n`bEin freundlich dreiblickender Elf reicht Dir ein Pergament mit den aktuellen Wahlergebnissen`n`n"); 
if ($session[user][superuser]>=2)addnav ("Wahlen beenden","wahlen.php?op=ende"); 
addnav("Dorf","village.php"); 


output("`c`7Kandidaten `n`n<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999'>",true); 
output("<tr class='trhead'><td><b>Name</b></td><td><b>APs</b></td><td>Stimmen</td> <td>Aktionen</td>",true); 


$sql="SELECT * FROM accounts WHERE getvote > 0 ORDER BY getvote DESC "; 

$result=db_query($sql); 
for ($i=0;$i<db_num_rows($result);$i++){ 
$row = db_fetch_assoc($result); 

output("<tr class='".($i%2?"trdark":"trlight")."'><td>",true); 
output("$row[name]`n"); 
output("</td><td>",true); 
output("$row[battlepoints]`n"); 
output("</td><td>",true); 
output("$row[getvote]`n"); 
output("</td><td>",true); 

if ($session[user][superuser]>=2) output("<a href='wahlen.php?op=nimm&id=$row[acctid]&login=$login'>`0[`^Kr�nen`0]</a>",true); 
if ($session[user][superuser]<=0) output("<a href=\"mail.php?op=write&to=".rawurlencode($row['login'])."\" target=\"_blank\" onClick=\"".popup("mail.php?op=write&to=".rawurlencode($row['login'])."").";return false;\"><img src='images/newscroll.GIF' width='16' height='16' alt='Mail schreiben' border='0'></a>",true); 
addnav("", "wahlen.php?op=nimm&id=$row[acctid]&login=$login"); 

} 
output("</table>`c",true); 
addnav("","bio.php?char=".rawurlencode($row['login']).""); 

addnav("Dorf","village.php"); 

break; 
}//switch op end //Danke Naria

page_footer(); 
?> 
