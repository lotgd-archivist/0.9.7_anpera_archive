Einbauanleitung Wahlen

ALTER TABLE `accounts`ADD `getvote` INT (11) unsigned NOT NULL default '0';
ALTER TABLE `accounts`ADD `buergermeister` INT (11) unsigned NOT NULL default '0';

( wenn  wahlzimmer von Horus vorhanden n�chsten Teil ausfallen lassen)
ALTER TABLE `accounts`ADD `gavevote` INT (11) unsigned NOT NULL default '0';


�ffne bio.php


SUCHE:
$result = db_query("SELECT login,

F�ge danach ein:
buergermeister,getvote,

SUCHE: 
page_header("Charakter Biographie: ".preg_replace("'[`].'","",$row[name]));


f�ge danach ein:
addnav('Aktionen');
 if ($session[user][gavevote]<=3 &&  (getsetting("wahl",0)==1))
 addnav('Vote','bio.php?op=vote&char='.$_GET['char']);

SUCHE:
output("`^`nBiographie f�r $row[name]`n`n"); 


F�ge danach ein
if ($row[buergermeister]==1 && $row[sex]==1) output("`^ (B�rgermeisterin von Name deiner Stadt)");
if($row[buergermeister]==1 && $row[sex]==0) output("`^(B�rgermeister von Name deiner Stadt)");


SUCHE:
if ($_GET[ret]==""){
	addnav("Zur Liste der Krieger","list.php");
}else{

	$return = preg_replace("'[&?]c=[[:digit:]-]+'","",$_GET[ret]);
	$return = substr($return,strrpos($return,"/")+1);
	addnav("Zur�ck",$return);


f�ge DAVOR ein:

if ($_GET['op']=="vote") {

$sql = "UPDATE accounts SET getvote=getvote + 1 WHERE login='$_GET[char]'"; 
db_query($sql);

output("`^`c `n$row[name]`^s Stimmen`c`n `^Du  hast $row[name] `^Deine Stimme gegeben`n`n");
$session[user][gavevote]++;

output("`^Damit hat $row[name] `^insgesamt `@$row[getvote] `^Stimmen.");

}
 

SAFE AND UP

�FFNE index.php

SUCHE:

$newplayer=stripslashes(getsetting("newplayer",""));
if ($newplayer!="") output("`vUnser j�ngster Spieler ist: `^$newplayer`@!`0`n");

f�ge danach ein:
$sql="SELECT * FROM accounts WHERE buergermeister  > 0"; 
        $result=db_query($sql); 
        for ($i=0;$i<db_num_rows($result);$i++){ 
                      $row = db_fetch_assoc($result); 
$name  =$row['name']; output("`vB�rgermeister ist: $name");}

SAFE AND UP



 Wenn  palast von Montekar  vorhanden( dient einzig dazu, das die daten automatisch �bernommen werden und man den B�rgermeister nicht mehr per hand einstellen muss)

SUCHE:

###   EINSTELLUNGEN    ###

f�ge danach ein:
 $sql="SELECT * FROM accounts WHERE buergermeister  = 1"; 
        $result=db_query($sql); 
        for ($i=0;$i<db_num_rows($result);$i++){ 
                      $row = db_fetch_assoc($result); 

 SUCHE:
$name  = ""; //Name des Herrschers
$name2 = ""; //Name der rechten Hand des Herrschers
$g     = ""; //Geschlecht des Herrschers, 0=> m�nnlich, 1=> weiblich
$dorf  = ""; //Name des Dorfes
$id    =  0; //Account-ID des Herrschers


Ersetze mit:
$name  =$row['name']; //Name des Herschers
$name2 = " "; //Name der rechten Hand des Herrschers
$g     =$row[sex]; //Geschlecht des Herrschers, 0=> m�nnlich, 1=> weiblich
$dorf  = " "; //Name des Dorfes
$id    =$row[acctid]; //Account-ID des Herrschers

SAFE AND UP
 

�FFNE configuration.php

suche:
 "N�tzliche Informationen,title",

f�ge danach ein

"wahl"=>"Findet Wahl statt?,enum,0,Nein,1,Ja",

SAVE AND UP



wahlen.php ins ROOT und im Dorfamt oder an passender Stelle verlinken

FERTIG




