<?

/*
Dink allows you to buy favor with Ramius.

find:
$playersperpage=100;
change it to your number of users.
This script needs to be altered for large servers. See list.php for that code snippet.

Drop this in your main folder.
Place addnav link to dink.php where you want.
*/

/* orginal author unknown. creds anyway ;-)

- translation into german by    gargamel@silienta-logd.de
- dink's service only available for the player himself
- changed variable handling in navs which makes arrays for deathpower
  and costs superflous.
- erweiter von Morpheus um eine Beschr�nkung auf 4 Eink�ufe pro DK
ALTER TABLE `accounts` ADD `dink` INT(10) UNSIGNED NOT NULL DEFAULT '0'; 
*/
require_once "common.php";
$name=$session['user']['name'];
$dika=$session['user']['dink'];
page_header("Dink�s Kiosk des Todes");

if ($_GET[op]==""){
	output("`6Dink besitzt die Weisheit und Macht, Dir etwas �ber den `$ Tod`6 zu lehren. Aber f�r seine Dienste verlangt er Edelsteine!`n`0");
	output("`6�ber der Tafel mit den Preisen kannst Du eine Schild sehen, auf dem folgendes zu lesen ist:`n`n`0");
	output("`4Ich, RAMIUS, Herr aller Toten, gebiete hiermit, da� ein jeder nur `^4 mal`4 bei Dink einkaufe!`0");
	output("`4Will er wieder hier einkaufen, so mu� er erst den Drachen besiegen, bevor er wieder `^4 mal `4bei ihm kaufen kann.`n`n`0");
	output("`6Wie aus dem Nichts erschallt pl�tzlich eine dumpfe Stimme, die Dich, ehrfurchtsvoll, zusammen zucken l��t:`n`n`0");
	output("`4Du,`3 $name`4, hast hier bereits `^$dika `4mal gekauft, seit Du den `@GR�NEN `4besiegt hast!`n`n`0");
	addnav("4 Gems - 10 Gefallen","dink.php?op=buy&price=4&fav=10");
	addnav("9 Gems - 30 Gefallen","dink.php?op=buy&price=9&fav=30");
	addnav("16 Gems - 50 Gefallen","dink.php?op=buy&price=16&fav=50");
	addnav("Zur�ck zur H�lle","thehell.php");

}else if($_GET[op]=="buy"){
	$price = $_GET['price'];
	$favor = $_GET['fav'];
	if ($session['user']['gems']>=$price){
		if ($session['user']['dink']>3){ 
			output("`6Dink lacht lau, sch�ttelt denKopf und zeigt auf das Schild unter der Preistafel.`n`0");
		}else{
			output("`6Dink bedankt sich bei Dir f�r `$ $price Edelsteine `6und gibt Dir Unterricht in Tod.`n Du erh�lst daf�r `$ $favor Gefallen!`n`0");
			$session['user']['gems']-=$price;
			$session['user']['deathpower']+=$favor;
			$session['user']['dink']+=1;
		}
	}else{
		output("`6Dink ist recht erbost �ber Deinen Versuch, ihm bei der Bezahlung zu betr�gen. Er packt Dich und schmeisst Dich zur�ck in die H�lle.`n`0");
	}
	addnav("Zur�ck zur H�lle","thehell.php");
}
page_footer();
?> 