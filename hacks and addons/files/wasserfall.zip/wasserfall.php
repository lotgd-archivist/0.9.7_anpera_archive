<?php

require_once "common.php";
checkday();
page_header("Der Wasserfall");

  /****************Diese Box darf nicht entfehrnt werden*************
   **		      				**  
   **	             Wasserfall by Alkatar (Alkatar@gmx.net)	**
   **		  Selbstmordscript mit Statistik		**
   **		       www.kaldacin.de.vu		**
   **		      				**  
   ************************************************************************/
/*
Einbauanleitung:

Im phpmyadmin ausf�hren:

INSERT INTO `settings` ( `setting` , `value` )VALUES ('sprung', '0');
INSERT INTO `settings` ( `setting` , `value` )VALUES ('todessprung', '0');
INSERT INTO `settings` ( `setting` , `value` )VALUES ('lebendsprung', '0');
INSERT INTO `settings` ( `setting` , `value` )VALUES ('nichtsprung', '0');


Dann einfach irgendwo verlinken, ich habs im Wald verlinkt, dann w�re das:
�ffne common.php

Suche:
addnav("P?Plumpsklo","outhouse.php");

F�ge davor ein:
addnav("W?Wasserfall","wasserfall.php");

Sonst einfach irgendwo 
addnav("W?Wasserfall","wasserfall.php");
einf�gen.

Wer die Statistik noch in den Spieleinstellungen �ndern m�chte muss noch folgendes machen:

�ffne configuration.php

Suche:
"lowslumlevel"=>"Mindestlevel bei dem perfekte K�mpfe eine Extrarunde geben,int",


F�ge danach ein:
	"Statistik Wasserfall,title",
	"sprung"=>"Gesprungen,int",
	"todessprung"=>"Gestorben,int",
	"lebendsprung"=>"�berlebt,int",
	"nichtsprung"=>"Abgehauen,int",
*/


if ($_GET[op]=="")
{
	output("`!Du h�rst ein lautes Rauschen und beschlie�t, diesem nachzugehen. 
		Nach wenigen Minuten kommst du zu einer Klippe an der ein kleiner Bach herunterflie�t. 
		Da die Klippe sich sehr hoch �ber dem darunter entstandenem See befindet, beschlie�t du, 
		eine kurze Rast einzulegen und die Aussicht zu genie�en. 
		Nach ein paar Minuten bemerkst du unten im See ein helles Blinken und du denkst dir, 
		dass da unten Edelsteine liegen k�nnten. Doch willst du den Sprung wirklich wagen?? 
		Es scheint schon einer den Sprung gewagt zu haben, da unten auf einem Felsen ein K�rper liegt und sich nicht bewegt. 
		Doch in deinem Kopf schwirrt immer noch der Gedanke herum, 
		dass dort unten jede Menge Edelsteine liegen k�nnten und die Person dort unten auch noch etwas Wertvolles dabei haben k�nnte.`n`n
	");
	output("Auf einem Schild steht neben dem Wasserfall steht eine Statistik:`n");
	$sprung=getsetting("sprung","0");
	$tot=getsetting("todessprung","0");
	$lebend=getsetting("lebendsprung","0");
	$nicht=getsetting("nichtsprung","0");
	Output("`$ `c<table>
			<tr><td>Gesprungen:</td><td>".$sprung."</td></tr>
			<tr><td>�berlebt:</td><td>".$lebend."</td></tr>
			<tr><td>Gestorben:</td><td>".$tot."</td></tr>
			<tr><td>Abgehauen:</td><td>".$nicht."</td></tr>
		    </table>`c",true);
	addnav("Springen","wasserfall.php?op=sprung");
	addnav("Weggehen","wasserfall.php?op=weg");  	//Leute die Zuviel Angsthaben werden gez�hlt
	//addnav("Weggehen","village.php"); 		 //Leute die Zuviel Angsthaben werden nicht gez�hlt
}

if ($_GET[op]=="weg")
{
savesetting("nichtsprung",getsetting("nichtsprung","0")+1);
addnews($session[user][name]." kommt mit gestrichen vollen Hosen aus Richtung Wasserfall gelaufen...");
output("`!Du hast `b`$ Angst`!`b!! `nDu drehst dich um und haust ab, schaust aber noch einmal hinter dich und siehst wie wie von Geisterhand 
	auf dem Schild bei Abgehauen erscheint...`nNun rennst du mit endg�ltig gestrichen vollen Hosen ins Dorf.
");
	addnav("Zum Dorf","village.php");
}

if ($_GET[op]=="sprung")
{
	savesetting("sprung",getsetting("sprung","0")+1);
	switch(e_rand(1,10)){ 
		case 1: 
		case 2: 
		case 3: 
		case 4: 
		case 5: 
		case 6: 
		case 7: 
  			output("`$ Du wachst in den Schatten wieder auf und wei�t erstmal nicht warum du hier bist. `n
				Ein nettes Gespenst kl�rt dich dar�ber auf, 
				dass du in einen See gesprungen bist und auf einem Stein aufgekommen bist. 
				Schlagartig kommt die Erinnerung wieder. `n
				Wie konntest du nur so habgierig sein und nur wegen ein paar Edelsteinen den Sprung riskieren?? `n
				Egal, jetzt ist es zu sp�t.
			");
			$session[user][alive]=false;
		        $session[user][hitpoints]=0;
			savesetting("todessprung",getsetting("todessprung","0")+1);
			addnav("T�gliche News","news.php");
			addnews($session[user][name]." sprang den Wasserfall hinunter, schlug mit dem Kopf auf einem Stein auf und starb");
		break;
		case 8: 
		case 9:
		case 10: 
			$gold=e_rand(1,10) * 100;
			$gems=e_rand(1,3);
			output("`!Du tauchst ein in das klare, warme Wasser des Sees und beginnst nach dem Funkeln zu suchen. `n
				Nach kurzer Zeit bemerkst du einige Edelsteine auf dem Grund des Sees und holst sie dir. `n`n
				Du hast`$ ".$gems."`! Edelsteine gefunden !`n
				Erfreut �ber den Reichtum, tauchst du wieder auf und kletterst zu dem Toten.`n 
				Sein Geldbeutel ist ihm aus der Tasche gefallen. Dadurch erparst du dir das Durchsuchen des Toten. `n
				Schnell nimmst du den Beutel an dich und gehst zur�ck zum See.`n
				Du hast`$ ".$gold."`! Gold gefunden !`n Da es hier nichts mehr zu  tun gibt, kletterst du zur�ck nach oben und gehst ins Dorf.
			");
			addnews($session[user][name]." �berlebt den Sprung vom Wasserfall und erbeutet ".$gold." Gold und ".$gems." Edelsteine");
			savesetting("lebendsprung",getsetting("lebendsprung","0")+1);
			$session[user][gold]+=$gold;
			$session[user][gems]+=$gems;
			addnav("Zur�ck zum Dorf","village.php");
		break; 
		} 
}
page_footer();
?>