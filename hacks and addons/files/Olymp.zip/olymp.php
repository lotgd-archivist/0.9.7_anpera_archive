<?php
/*_____________________________________________________________
  |Der Olymp, ein Ort f�r Veteranen                           |
  |von Lord Eliwood                                           |
  |___________________________________________________________|
*/
/*___________________________________________________________________________________
  |Installation:                                                                     |
  |f�ge irgendwo im Dorf folgendes ein:                                              |
  |if (($session['user']['dragonkills']>=x) || ($session['user']['superuser']>=2))   |
  |addnav("Olymp","olymp.php");                                                      |
  |Wobei x durch die Anzahl DKs zu ersetzen ist, ab der man ein Gott ist(Unter- etc. |
  |__________________________________________________________________________________|
*/
require_once "common.php";
page_header("Seltsame Lichtung");
addcommentary();

output("`c`b`&Olymp`c`b`n`n");
output("Ein heiliger Ort, hoch �ber den Wolken. Du siehst verschiedene besch�ftigte G�tter und L�den, wie Hepaistos Schmiede.");
output("Ein Weg f�hrt zum Gott Zeus, andere G�tter rennen �ber den Dorfplatz. Da du nun auch einer aus ihren Reihen bist, bist du");
output("kein niederes Objekt mehr, du geh�rtst nun nicht mehr zu denen, du bist nun ein Gott.`n`n");
//addnav("Hephaistos' Schmiede","gottschmiede.php"); Kann ich nicht mitliefern, da des Haganirs Schmiede ist mit umgeschriebenen Texten
addnav("Zeus' Trohn","zeus.php");
addnav("Kratos' Waffenshop","kratos.php");
addnav("Zelos' R�stungen","zelos.php");
addnav("Zur�ck zur Stadt","village.php");

output("`n`n`%`@In der N�he sprechen einige G�tter:`n");
viewcommentary("olymp","Hinzuf�gen",25,"spricht");
page_footer();
?>