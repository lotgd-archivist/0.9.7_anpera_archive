<?php
//damokles.php
//code: Hadriel
//idea: Hadriel
//for other servers

// Add in SQL:

//INSERT INTO items (name,class,description,gold) VALUES ('Schwert des Damokles','Beute.Prot','Ein altes, m�chtiges Schwert',1);

//Let's set variables
$_gold=3000; //gold if quest ok
$_gems=3;    //gems if quest ok

$iddem=db_query("SELECT name,id FROM items WHERE name='Schwert des Damokles' AND owner=".$session[user][acctid]);
$id=db_fetch_assoc($iddem);
//Let's do the code
switch($_GET[op]){
  
  case "":
  case "search":
  $session[user][specialinc]="damokles.php";
  addnav("Zur�ck","forest.php?op=flee");
  if(!$session[user][prefs][damoklesq]){
  output("`6Du kommst an eine dicht bewaldete und bewucherte Stelle im Wald, als du ohne vorwarnung einem Pfeil knapp entgehst.");
  output("\"`t".($session[user][sex]?"Puh, mein M�dl":"Puh, mein Jungchn").", das w�re fast daneben gegangen. Du hast gl�ck, dass ich dich mit meinem Bogen nicht erwischt hab, bin n�mlich nicht so gut im Treffen.`6\"");
  output("`6Er mustert dich \"`tDu hast nich zuf�llig mein Schwert gesehen? Ich suche es seit langem... vielleicht kannst du es ja f�r mich holen! �brigens, mein Name ist `6Damokles`q!`6\"");
  addnav("Damokles");
  addnav("Annehmen","forest.php?op=getquest");
  }
  if($session[user][prefs][damoklesq]=="ok" && db_num_rows($iddem)>0){
  output("`6Freudig h�pft Damokles aus seinem Versteck. \"`t".($session[user][sex]?"Danke, mein M�dl":"Danke, mein Jungchn").", du hast das Schwert gefunden! K�nntest du mir es eventuell geben? Ich werde dich daf�r auch belohnen!`6\" ");
  addnav("Damokles");
  addnav("Gib ihm sein Schwert","forest.php?op=hasquest&id=$id[id]");
  }
  if($session[user][prefs][damoklesq]=="ok" && db_num_rows($iddem)<=0){
  output("`6Du kommst erneut an die stelle, wo du Damokles zum ersten mal gesehen hast. Jedoch ist er nicht hier. K�nnte es vielleicht daran liegen, dass du sein Schwert nicht dabei hast?");
  }
    break;
  case "getquest":
  $session[user][specialinc]="";
  output("`6Du beschliesst, Damokles zu helfen. \"`tAber wehe, du findest es nicht!`6\"");
  $session[user][prefs][damoklesq]="ok";
  addnav("Zur�ck","forest.php");
    break;
  case "hasquest":
  $session[user][specialinc]="";
  output("`6Damokles `tbedankt sich bei dir und gibt dir $_gold `^Gold `qund $_gems `%Edelsteine`q. Freudig machst du dich auf den Weg in den Wald");
  $session[user][prefs][damoklesq]="";
  db_query("DELETE FROM items WHERE id=$_GET[id]");
  $session[user][gold]+=$_gold;
  $session[user][gems]+=$_gems;
  addnav("Zur�ck","forest.php");
    break;
  case "flee":
    
    $session[user][specialinc]="";
    output("`6Du versuchst so schnell wie m�glich von hier zu verschwinden... ");
  switch(e_rand(1,4)){
    case 1:
    case 2:
    case 3:
      output("`6Ersch�pft erreichst du den Dorfrand.");
      if($session[user][turns]>=3){
      $session[user][turns]-=3;
      }else{
      $session[user][turns]=0;
      }
    addnav("Zur�ck","forest.php");
      break;
    case 4:
    output("`6Doch dabei trittst du in eine Falle! J�mmerlich stirbst du.");
    $session[user][alive]=false;
    $session[user][hitpoints]=0;
    $session[user][gold]=0;
    $session[user][experience]*=0.95;
    addnav("T�gliche News","news.php");
    addnews($session[user][name]."`6 fand ein spitzes Grab und ruht nun in Frieden");
      break;
    }
    break;
    }

?>