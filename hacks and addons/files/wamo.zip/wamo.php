<?php
//Idee und Umsetzung
//Morpheus f�r www.morpheus-lotgd.de.vu
//Mail to Morpheus@magic.ms
//Gewidmet meiner �ber alles geliebten Blume
require_once "common.php";
$m1=$settings['mond1'];
$m2=$settings['mond2'];
if ($session['user']['alive']){ 
}else{
	redirect("shades.php");
}
page_header("Die Monde");
if($_GET_VARS['op']==""){
	output("`c`b`6Die Monde`0`b`c");
	output("`3Du trittst auf eine kleine Lichtung und blickst, durch das dichte `2La`@ub`2we`@rk `3des Waldes, zwischen den an dieser Stelle etwas lichten BAumwipfeln, nach oben, wo Du die Monde von Simahr erkennen kannst.`n");
	output("`6Schmiedel `9ist `^$m1`9, `6Karulda `9ist `^$m2`9 am Firnament zu erkennen.`0`n");
	addnav("Zur�ck","forest.php");
}
page_footer();
?>