<?php

if (!isset($session)) exit();

page_header('Die Drachenh�le');

switch( $_GET['op'] ) {
	
	case '':
		
		output('`@Als du auf der Suche nach einem Gegner durch den Wald l�ufst, kannst du hinter einigen B�schen und B�umen eine H�hle ausmachen. Du entschlie�t Dich dazu '.
			   'durch das Gestr�p hin�ber zur H�hle zu gehen. An der H�hle angekommen, siehst Du Kratzspuren auf dem Boden und an den H�hlenw�nden. Dir wird klar, dass dies die '.
			   'H�hle des `bgr�nen Drachen`b ist.`n`nWillst Du in die H�hle gehen oder lieber wie ein kleines Kind davon rennen?`0');
		addnav('Aktionen');
		addnav('H�hle betreten','forest.php?op=hoehle');
		addnav('Davon rennen','forest.php?op=go');
		
		$session['user']['specialinc'] = 'hoehle.php';
	
	break;
	
	case 'go':
		
		output('`@Du entschlie�t dich dazu dein Leben zu retten, nimmst die Beine in die H�nde und rennst davon.`0');
		addnav('Aktionen');
		addnav('In den Wald','forest.php');
		addnews('`$'.$session['user']['name'].' `$konnte seine Angst nicht kontrollieren und fl�chtete vor einer H�hle!');
		$session['user']['specialinc'] = '';
	
	break;
	
	case 'hoehle':
		
		switch( mt_rand(1,20) ) {
		
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
			case 6:
			case 7:
				
				output('`@Du betritst die H�hle und musst leider feststellen, dass diese leer ist. Als du dich genauer umsiehst, kannst du in einer Ecke noch einen Sack '.
					   'erkennen. Da du diese H�hle nicht mit leeren H�nden verlassen willst, nimmst du diesen an Dich und gehst.`0`n`n');
				
				$gold = mt_rand(1,($session['user']['level']*$session['user']['dragonkills'])+mt_rand(1,1000));
				$gems = mt_rand(1,20);
				$session['user']['gold']+=$gold;
				$session['user']['gems']+=$gems;
				
				output('`@Als du den Sack �ffnest, fallen `^'.$gold.' Goldst�cke`@ und `#'.$gems.'`@ Edelsteine vor dir auf den Boden.`0');
				addnews('`&'.$session['user']['name'].' `&versuchte sich als H�hlenforscher und wurde daf�r reich belohnt.`0');
			
			break;
		
			case 8:
			case 9:
			case 10:
			case 11:
			case 12:
			
				output('`@Du betrittst die H�hle und kannst in der Mitte etwas schimmern sehen. Als du auf dieses Schimmern zugehst, kannst du das Ei des `bgr�nen Drachen`b erkennen. '.
					   'Gerade als Du das Ei einpacken wolltest, sp�rst Du einen unangenehmen Ruck der Dich von den F��en rei�t. ');
					  
				switch( mt_rand(1,2) ) {
					
					case 1:
						
						output('Du schl�gst mit dem Kopf gegen einen Stein und f�llst in Ohnmacht. Als du wieder aufwachst, befindest du dich in der Unterwelt.`n`n`$Du bist tot.`0');
						addnews('`$'.$session['user']['name'].' `$versuchte das Drachenei zu stehlen und wurde mit dem Tode bestraft.`0');
						$session['user']['alive'] = 0;
						$session['user']['hitpoints'] = 0;
						
					break;
					
					case 2:
						
						output('Du wirst mit voller Wucht gegen die H�hlenwand geschlagen. Langsam kommt der `bgr�ne Drache`b auf Dich zu. Als dieser inneh�lt, ergreifst Du die '.
							   'Gelegenheit und rennst davon.`n`n');
							   
						$gold = mt_rand(1,($session['user']['level']*$session['user']['dragonkills'])+mt_rand(1,100));
						$gems = mt_rand(1,20);
						$session['user']['gold'] -= $gold;
						$session['user']['gems'] -= $gems;
						
						output('Auf deiner Flucht verlierst Du `^'.$gold.' Goldst�cke`@ und `#'.$gems.' Edelsteine.');
						addnews('`$'.$session['user']['name'].' `$floh vor einem `@`bgr�nen Drachen`b`$ und verlor dabei Hab und Gut.`0');
					
					break;
				
				}
			
			break;
			
			case 13:
			case 14:
			case 15:
			case 16:
				
				output('`@Du betritst die H�hle und erkennst in der Mitte ein Schimmern. Als du auf dieses Schimmern zugehst, erkennst du, dass dieses Schimmern eine kleine Fee ist. '.
					   'Als du dir die Fee ansiehst, siehst Du das sie festgebunden wurde und befreist sie sofort.`n`n`^Als Dank daf�r erh�lst du von der `b5 Charmpunkte`b!`0');
				addnews('`^'.$session['user']['name'].' `^hat eine Fee gerettet und wurde als Belohnung charmanter!`0');
				$session['user']['charm'] += 5;
			
			break;
			
			case 17:
			case 18:
				
				output('`@Du betritst die H�hle und musst leider feststellen das diese leer ist. Entt�uscht ziehst du wieder in den Wald.`0');
				addnews('`&'.$session['user']['name'].'`& versuchte sich als H�hlenforscher. Versagte jedoch kl�glich.`0');
			
			break;
			
			case 19:
			case 20:
				
				if( getsetting('hasdragonegg',0) ) {
					
					output('`@Du betritst die H�hle und musst leider feststellen das diese leer ist. Du hast damit gerechnet, dass hier ein Drachnei zu finden ist. Doch scheinbar '.
						   'war schon jemand vor dir da.`0');
					addnews('`$'.$session['user']['name'].'`$ wollte sich das Drachenei schnappen. Doch das Drachenei war schon weg.`0');
				
				} else {
					
					output('`@Du betritst die H�hle und kannst in der Mitte der H�hle ein kleines Ei sehen. Schnell gehst Du auf dieses Ei zu und verstaust es in deinem Rucksack.`n`n');
					
					switch( mt_rand(1,2) ) {
							
						case 1:
							
							output('Gerade als du die H�hle verlassen willst, betritt der `bgr�ne Drache`b diese. Du presst dich mit dem R�cken in eine dunkle Nische in der Wand und '.
								   'hoffst, dass er Dich nicht siehst.`n`n');
								  
							switch( mt_rand(1,2) ) {
								
								case 1:
									
									output('Du hast Gl�ck. Der `bgr�ne Drache`b fliegt wieder davon. Schnell rennst Du aus der H�hle in den Wald und willst das Ei aus deinem Rucksack '.
										   'holen. ');
									
									switch( mt_rand(1,2) ) {
										
										case 1:
										
											output('Doch als du in deinen Rucksack greifst, ber�hren deine Finger etwas schleimiges. Als du in den Rucksack hineinsiehst, '.
												   'kannst du erkennen, dass das Drachenei zerplatzt ist. Wom�glich als du dich gegen die Wand gedr�ckt hast. Entt�uscht gehst '.
												   'du zur�ck in den Wald.`0');
											addnews('`$'.$session['user']['name'].'`$ fand das Drachnei in einer H�hle und verlor es im selben Moment wieder.`0');
										
										break;
										
										case 2:
											
											output('Tastest dann doch nur danach um zu pr�fen ob es heile geblieben ist. Als Du es mit deinen Fingern ber�hrst, f�ngst Du an '.
												   'zu grinsen und gehst zur�ck in den Wald!');
											addnews('`@'.$session['user']['name'].'`@ fand das Drachenei in einer H�hle im Wald.`0');
											savesetting('hasdragonegg',1);
											$owner = $session['user']['acctid'];
											savesetting('dragoneggowner',$owner);
										
										break;
									
									}
								
								break;
								
								case 2:
									
									output('Doch das Gl�ck ist nicht auf deiner Seite. Als der `bgr�ne Drache`b merkt, dass sein Ei gestohlen wurde, st��t dieser einen Feuerstrahl aus '.
										   'der die ganze H�hle in brannt setzt.`n`n`$Du bist tot.`0');
									$session['user']['alive'] = 0;
									$session['user']['hitpoints'] = 0;
									addnews('`$'.$session['user']['name'].'`$ wurde von einem `b`@gr�nen Drachen`b`$ get�tet, als er das Drachenei stehlen wollte.`0');
								
								break;
						
							}
						
						break;
						
						case 2:
						
							output('Freude strahlend gehst du zur�ck in den Wald.');
							addnews('`@'.$session['user']['name'].'`@ fand das Drachenei in einer H�hle im Wald.`0');
							savesetting('hasdragonegg',1);
							
											$owner = $session['user']['acctid'];
											savesetting('dragoneggowner',$owner);
						
						break;
					
					}
				
				}
				
			break;
		
		}
		
		switch( $session['user']['alive'] ) {
			
			case 0:
				
				addnav('Aktionen');
				addnav('Zu den Schatten','shades.php');
			
			break;
			
			case 1:
				
				addnav('Aktionen');
				addnav('In den Wald','forest.php');
			
			break;
		
		}
		
		$session['user']['specialinc'] = '';
	
	break;

}

page_footer();

?>