<?php

require_once 'common.php';

page_header('Das Drachenei');

switch( $_GET['op'] ) {
	
	case 'brueten':
		
		output('`@Du gehst in einen der hinteren Stallungen und legst das Drachnei ins Heu.`n`n');
				
		rawoutput('<form action="dragonegg.php?op=brueten2" method="POST">Wieviele Runden m�chtest Du br�ten? <input name="brueten"><input type="submit" class="button" value="Br�ten!"></form>');
				
		output('Du kannst heute noch maximal '.(getsetting('bruetenday',20)-getsetting('gebruetet',0)).' Runden br�ten.');
		addnav('','dragonegg.php?op=brueten2');
				
		addnav('Aktionen');
		addnav('Zur�ck','stables.php');
	
	break;
	
	case 'brueten2':
		
		switch( $_POST['brueten'] ) {
			
			case ( $_POST['brueten'] <= 20 AND getsetting('gebruetet',0) < 20 AND ($_POST['brueten']+getsetting('gebruetet',0)) <= getsetting('bruetenday',20) ):
				
				$bruet = getsetting('maxbruet',0)-$_POST['brueten'];
				savesetting('gebruetet',($_POST['brueten']+getsetting('gebruetet',0)));
				savesetting('maxbruet',stripslashes($bruet));
				output('`@Du hast erfolgreich '.$_POST['brueten'].' Runden gebr�tet. Du kannst heute noch maximal '.(getsetting('bruetenday',20)-getsetting('gebruetet',0)).
					   ' Runden br�ten.'.$bruet);
				
				if( getsetting('gebruetet',0) ==  20 ) {
					
					addnews('`2'.$session['user']['name'].'`2 hat sich mit dem Drachnei im Heu vergraben und wartet darauf das es schl�pft.`0');
				
				}
				
				if( getsetting('maxbruet',2000) == 0 ) {
				
					$body = '`@Hallo '.$session['user']['name'].',`n`nes freut mich Dir mitteilen zu k�nnen, dass soeben dein Drache aus dem Drachnei geschl�pft ist.`n`n'.
							'Du kannst ihn dir jetzt bei mir in den St�llen abholen.`n`nLiebe Gr��e,`nMerick.';
					systemmail($session['user']['acctid'],'`@Dein neues Tier!`0',$body);
				
				}
				
				addnav('Aktionen');
				addnav('Zum Stadtplatz','village.php');
			
			break;
			
			case ( $_POST['brueten'] <= 20 AND getsetting('gebruetet',0) < 20 AND ($_POST['brueten']+getsetting('gebruetet',0)) > getsetting('bruetenday',20) ):
				
				output('`@Du kannst keine '.$_POST['brueten'].' runden br�ten. Du kannst heute noch maximal '.(getsetting('bruetenday',20)-getsetting('gebruetet',0)).
					   ' Runden br�ten.');
				addnav('Aktionen');
				addnav('Zur�ck','dragonegg.php?op=brueten');
			
			break;
			
			case ( $_POST['brueten'] > 20 ):
				
				output('`@Du kannst keine '.$_POST['brueten'].' runden br�ten. Du kannst heute noch maximal '.(getsetting('bruetenday',20)-getsetting('gebruetet',0)).
					   ' Runden br�ten.');
				addnav('Aktionen');
				addnav('Zur�ck','dragonegg.php?op=brueten');
			
			break;
			
			case ( getsetting('gebruetet',0) >= 20 ):
				
				output('`@Du hast heute bereits 20 Runden gebr�tet. Komm morgen wieder!');
				addnav('Aktionen');
				addnav('Zum Stadtplatz','village.php');
			
			break;
		
		}
	
	break;
	
	case 'holen':
		
		output('`@Du sagst Merick, dass du deinen Drachen gerne abholen w�rdest. Er geht kurz hin�ber zu einem der St�lle und f�hrt deinen Drachen an einer Leine zu Dir.`n`n'.
			   '`bHerzlichen Gl�ckwunsch. Du besitzt nun einen gr�nen Drachen!`b`0');
		
		savesetting('hasdragonegg',stripslashes(0));
		savesetting('dragoneggowner',stripslashes(0));
		savesetting('gebruetet',stripslashes(0));
		savesetting('maxbruet',2000);
		
		$row = db_fetch_assoc(db_query('SELECT * FROM mounts WHERE mountname="`@Der gr�ne Drache`0"'));
		$session['user']['hashorse'] = $row['mountid'];
		$playermount = getmount($row['mountid']);
		
		addnav('Aktionen');
		addnav('Zum Stadtplatz','village.php');
}

page_footer()

?>