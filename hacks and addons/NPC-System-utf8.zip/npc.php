<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * *
* NPC-Verwaltungsdatei für das NPC-System
* Geschrieben von Auric@tharesia.de (Aug-Sep 2007)
* Freigegeben unter der GNU-GPL
* Version 1.0
* * * * * * * * * * * * * * * * * * * * * * * * * * * * */

require_once "common.php";
require_once "lib/npc.class.php";
checkday();
$outnames = array('name' => 'Name', 'text' => 'Beschreibung', 'avatar' => 'Avatar', 'grant' => 'Benutzer');

switch ($_GET['op']) {
	case 'start':
		page_header("NPC-Verwaltung");
		$line = "`c`b`%NPC-Übersicht`b`c`n";
		if ($session['user']['npc']) { // Bereits Aktiviert
			$npcs = npc::getAllOf($session['user']['acctid'], false);
			$rows = array(0 => '');
			foreach (array('buy', 'name', 'text', 'avatar', 'grant') as $val) {
				$b = npc::getCost(strtoupper($val));
				$cost[$val] = $b['price'];
				if ($val != 'buy')
					for($i = 0, $max = count($npcs); $i < $max; $i++) {
						$npc = $npcs[$i];
						if (npc::canbuy(strtoupper($val))) {
							$rows[$i] .= "\t\t<td><a href='npc.php?op=edit&id=" . $npc->getId() . "&what=" . $val . "'>`6" . $outnames[$val] . "`0</a></td>";
							addnav('', "npc.php?op=edit&id=" . $npc->getId() . "&what=" . $val);
						} else
							$rows[$i] .= "\t\t<td>`4X`0</td>\n";
					}
			}
			$line .= "`5Da du es bereits bis hier her geschafft hast, darfst du neue N(on)P(layer)C(haracter)s bzw. N(icht)S(pieler)C(haraktere) zu erstellen.`n";
			$line .= "Die Erstelung eines solchen NPCs kostet dich jeweils `4" . $cost['buy'] . " Punkte`5, dafür kannst du den NPC dann allerdings unbegrenzt Nutzen. Weitere Kosten fallen nur an, ";
			$line .= "wenn du den NPC grundlegen ändern wilst, ihm also einen neuen Namen geben willst (`4" . $cost['name'] . " Punkte`5) oder seine Beschreibung ändern möchtest (`4" . $cost['text'] . " Punkte`5). ";
			if (((int) $cost['avatar']) > 0)
				$line .= "Das Ändern des Avatars für einen NPC kostet hingegen `4" . $cost['avatar'] . " Punkte";
			$line .= "Für jeweils `4" . $cost['grant'] . "`5 Punkte kannst du einem weiteren Spieler (maximal " . getsetting('NPC_GRANT_MAX', 5) . ") Zugriff auf einen NPC gewähren.`n";
			$line .= "`qDiese Kosten dienen dazu, es sinnvoll zu gestalten, auch mehr als einen NPC zu besitzten`n `iHinweis: Du kannst nur die Orte für den Kauf von NPC-Optionen betreten, für die du ausreichend Punkte hast`i`n`n";
			$line .= "`c`9`b(Mit 'Punkte' sind hier übrigends deine `i" . (npc::getCurrency() == 'rp' ? 'RP-Punkte' : 'Donationpoints') . "`i gemeint)`b`0`c`n`n";
			output($line);
			if (npc::canbuy('BUY')) {
				addnav("Operationen");
				addnav("NPC erstellen", "npc.php?op=create");
			}
			
			if (count($npcs) > 0) {
				$table = "<table border=1><tr><th>NPC</th><th colspan='4'>Verändern</th></tr>\n";
				for($i = 0, $max = count($rows); $i < $max; $i++) {
					$table .= "\t<tr class='" . ($i % 2 == 0 ? 'trlight' : 'trdark') . "'>\n\t\t<td>" . $npcs[$i]->getName() . "</td>\n" . $rows[$i] . "\t</tr>\n";
				}
				$table .= "</table>";
				output($table, true);
			}
		} else { // Noch nicht aktiviert
			$cost = npc::getCost('ACTIVATE');
			$line .= "`qNoch gehörst du nicht zum Kreis der Eingeweihten, die Zugriff auf NPCs haben. Du darfst also noch keine NPCs erstellen oder steuern.`n";
			$line .= "Wenn du dem jedoch abhilfe schaffen willst, musst du zunächst `4" . $cost['price'] . " " . ($cost['cur'] == 'dp' ? 'Donationpoints' : 'RP-Punkte') . "`q bezahlen.`n";
			$line .= "Danach wirst du auf alle NPC-Funktionen zugriff haben und auch fremde NPCs nutzen können, wenn sie dir zur Verfügung gestellt werden.`n";
			if (npc::canbuy('ACTIVATE')) {
				$line .= "`^Glücklicherweise hast du ausreichend Punkte um die Kosten zu bezahlen.";
				addnav("Freischalten");
				addnav("Bezahlen (" . $cost['price'] . " " . ($cost['cur'] == 'dp' ? 'Donationpoints' : 'RP-Punkte') . ")", "npc.php?op=activate");
			} else {
				$line .= "`4Doch leider hast du nicht genügend Punkte. Du wirst wohl später wiederkommen müssen.";
			}
			output($line);
		}
		break;
	
	case 'bio':
		if (empty($_GET['id']))
			redirect('npc.php');
		$npc = new npc($_GET['id']);
		output($npc->printBio(), true);
		if ($_GET['ret']) {
			$return = preg_replace("'[&?]c=[[:digit:]-]+'", "", $_GET['ret']);
			$return = substr($return, strrpos($return, "/") + 1);
			addnav("Zurück", $return);
		}
		break;
	
	case 'edit':
		$npc = new npc($_GET['id']);
		page_header("NPC-Veränderung");
		$link = "npc.php?op=update&what=" . $_GET['what'] . "&id=" . $_GET['id'];
		addnav('', $link);
		$line = "`c`^`bNPC-Veränderung`b`0`c`n <form action='" . $link . "' method='POST'>";
		switch ($_GET['what']) {
			case 'name':
				$line .= "`6Der aktuelle Name deines NPCs ist: " . $npc->getName() . "`6. Du kannst ihn hier ändern: `n<input name='val' value='";
				output($line, true);
				rawoutput($npc->getName());
				output("' /> <input type='submit' value='Ändern'></form>", true);
				break;
			case 'text':
				$line .= "`6Hier kannst du die Beschreibung von " . $npc->getName() . " `6ändern:`n<textarea name='val' rows='10' cols='100'>";
				output($line, true);
				rawoutput($npc->getText());
				output("</textarea>`n<input type='submit' value='Ändern' /></form>", true);
				break;
			case 'avatar':
				$line .= "`6Hier kannst du den Avatar von " . $npc->getName() . " `6ändern: `n<input name='val' value='" . $npc->getAvatar() . "' />";
				$line .= " <input type='submit' value='Ändern' /></form>";
				output($line, true);
				break;
			case 'grant':
				$users = $npc->getAllPlayers();
				$line .= "`6Folgende Spieler haben Zugriff auf " . $npc->getName() . "`6:`n";
				$line .= "<table border='1'><thead>\n\t<tr><th>Entfernen</th><th>Spieler</th></tr>\n";
				$line .= "</tbody><tfoot>\n<tr><th>`9Erlauben für:</th><th><input name='val' /></th></tr>\n<tbody>";
				$light = false;
				foreach ($users as $id => $name) {
					if ($id == $npc->getErsteller())
						continue;
					$line .= "<tr class='" . ($light ? 'trdark' : 'trlight') . "'><td><input type='checkbox' style='margin:0; width:100%;' name='users[]' value='" . $id . "' /></td>";
					$line .= "<td>" . $name . "</td></tr>";
					$light = !$light;
				}
				$line .= "</tbody></table><input type='submit' value='Abschicken' />`n";
				$line .= "`c`i`^(Über die Unterste Zeile kannst du weiteren Leuten den Zugriff gewähren)`0`i`c";
				output($line, true);
				break;
		}
		break;
	
	case 'update':
		$npc = new npc($_GET['id']);
		if ($_GET['what'] != 'grant') {
			page_header("NPC-Veränderung abgeschlossen!");
			$line = "`c`b`@NPC-Veränderung abgeschlossen!`0`b`c`n";
			if ($npc->change(($_GET['what'] == 'name' ? 'name' : $_GET['what']), $_POST['val'])) {
				$cost = npc::getCost(strtoupper($_GET['what']));
				$line .= "`2Die Änderung wurde erfolgreich durchgeführt!`n`n";
				$line .= "`3(Der/Die " . $outnames[$_GET['what']] . " wurde erfolgreich auf '" . $_POST['val'] . "'`3 gesetzt; ";
				$line .= "Du hast dafür " . $cost['price'] . " Punkte bezahlt)`n";
			} else {
				$line .= "`4Es ist ein Fehler aufgetreten: Du scheinst nicht genügend Punkte zu haben!";
			}
		} else {
			page_header("Überprüfung der Änderungsbefehle");
			if (empty($_GET['valid'])) {
				$line = '';
				if (!empty($_POST['users'])) {
					$line .= "`n`n`b`qFolgenden Spielern wird der Zugriff auf " . $npc->getName() . "`q entzogen:`b`0`n";
					$line .= "<ul>";
					$all = $npc->getAllPlayers();
					foreach ($_POST['users'] as $usr) {
						if (!empty($all[$usr]))
							$line .= "\t<li>" . $all[$usr] . "</li>\t<input type='hidden' name='users[] value='" . $usr . "' />\n";
					}
					$line .= "</ul>`n`n";
				}
				if (!empty($_POST['val'])) {
					$string = "%";
					for($x = 0; $x < strlen($_POST['val']); $x++)
						$string .= substr($_POST['val'], $x, 1) . "%";
					$sql = "SELECT acctid ,name FROM accounts WHERE name LIKE '" . addslashes($string) . "'";
					$result = db_query($sql);
					$line .= "`^`bBitte gib an, wem genau du den Zugriff erlauben willst:`b`0\n\t<select name='val' size='1'>\n";
					for($i = 0; $i < db_num_rows($result); $i++) {
						$row = db_fetch_assoc($result);
						$line .= "\t\t<option value='" . $row['acctid'] . "'>" . strip_tags($row['name']) . "</option>\n";
					}
					$line .= "\t</select>`n";
				}
				if (empty($line)) {
					$line = "Du hast keinerlei Änderungen übergeben, bitte versuche es noch einmal!";
				} else {
					$line = "`c`b`@Überprüfung der Änderungsbefehle`0`b`c`n<form action='npc.php?op=update&id=" . $_GET['id'] . "&what=grant&valid=true' method='POST'>" . $line;
					$line .= "`n`n<input type='submit' value='Änderungen bestätigen' /></form>";
					addnav("", "npc.php?op=update&id=" . $_GET['id'] . "&what=grant&valid=true");
				}
			} else { // Bestätigt!
				page_header("NPC-Veränderung abgeschlossen!");
				$line = "`c`b`@NPC-Veränderung abgeschlossen!`0`b`c`n";
				$npc->grantAcces($_POST['val']);
			}
		}
		output($line, true);
		break;
	
	case 'create':
		page_header("NPC-Schöpfung");
		$line = "`c`b`^NPC-Schöpfung`0`b`c`n";
		$line .= "`3Hier kannst du nun einen neuen NPC erschaffen. Gib die gewünschten Werte einfach in die folgenden Felder ein:`n";
		$line .= "<form action='npc.php?op=insert' method='POST'>\n";
		$line .= "<label for='npcname' style='width:65px; float:left;display:block;'>Name</label><input id='npcname' name='name' maxlength='64' />`n";
		$line .= "<label for='npcavatar' style='width:65px; float:left;display:block;'>Avatar</label><input id='npcavatar' name='avatar' maxlength='255' />`n";
		$line .= "<label for='npctext'>Bescheibender Text</label>`n<textarea id='npctext' name='text' rows='10' cols='100'></textarea>`n";
		$line .= "<input type='submit' value='Weiter zur Bestätigung' /></form>";
		output($line, true);
		addnav('', 'npc.php?op=insert');
		break;
	
	case 'insert':
		page_header("NPC-Schöpfung (Abschluss)");
		if (empty($_GET['valid'])) {
			$names = npc::checkNameUsed($_POST['name']);
			if($names !== false) { //Namensverifikation fehlgeschlagen
				$line = "`c`4`bNamenskonflikt`b`0`c`n`\$Der Name `&'".$_POST['name']."`&'`$ ist leider schon in Nutzung - er kollidiert mit den folgenden:`9`n";
				for($i=0;$i < count($names); $i++) {
					$line .= sprintf("%s: '%s'`n",$names[$i]['typ'], $names[$i]['name']);
				}
				$line .= "`n`n`^bBitte ändere den Namen und versuche es noch einmal:`b`n";
				$line .= "<form action='npc.php?op=insert' method='POST'>\n";
				output($line, true);
				$line = "<label for='npcname' style='width:65px; float:left;display:block;'>Name</label><input id='npcname' name='name' maxlength='64' value='".$_POST['name']."' /><br />\n";
				$line .= "<label for='npcavatar' style='width:65px; float:left;display:block;'>Avatar</label><input id='npcavatar' name='avatar' maxlength='255'  value='".$_POST['avatar']."'/><br />\n";
				$line .= "<label for='npctext'>Bescheibender Text</label><br />\n<textarea id='npctext' name='text' rows='10' cols='100'>".$_POST['text']."</textarea><br />\n";
				$line .= "<input type='submit' value='Weiter zur Bestätigung' /></form><br />\n";
				rawoutput($line);
				addnav('', 'npc.php?op=insert');
			} else {
				$pre_npc = npc::previewCreate($_POST['name'], $_POST['text'], $session['user']['acctid'], $_POST['avatar']);
				output("`c`gNun kannst du die eingegebenen Daten noch einmal Überprüfen. Wenn du zufrieden bist, klicke auf \"Erschaffen\", wenn nicht, kannst du es noch einmal neu versuchen.`c`n`n");
				output($pre_npc->printBio(), true);
				$form = "<form action='npc.php?op=insert&valid=true' method='POST'>\n";
				$form .= "\t<input type='hidden' name='name' value='" . $_POST['name'] . "' />\n";
				$form .= "\t<input type='hidden' name='text' value='" . $_POST['text'] . "' />\n";
				$form .= "\t<input type='hidden' name='avatar' value='" . $_POST['avatar'] . "' />\n";
				$form .= "\t<input type='submit' value='Erschaffen!' /></form>";
				rawoutput($form);
				addnav('', 'npc.php?op=insert&valid=true');
				addnav('Zurück');
				addnav('Noch einmal versuchen', 'npc.php?op=create');
			}
		} else {
			$npc = npc::create($_POST['name'], $_POST['text'], $session['user']['acctid'], $_POST['avatar']);
			if ($npc) {
				$cost = npc::getCost();
				output("`c`b`^Erfolgreiche Schöpfung!`0`b`c`n");
				output("`tDein NPC '" . $_POST['name'] . "`t wurde erschaffen. Du kannst ihn nun benutzen.`n`n`i(Dir wurden dafür `4" . $cost['price'] . " Punkte`t abgezogen");
			} else {
				output("`c`b`$ Fehler! `0`b`c`n");
				output("Die Erschaffund deines NPCs schlug fehl, eventuell hast du nicht genügend Punkte");
			}
		}
		break;
	
	case 'activate':
		page_header("Aktivierung für die NPC-Nutzung");
		if (npc::activate()) {
			output("Du bist nun für die Nutzung von NPCs freigeschaltet!");
		} else {
			output("Uuups... da ist wohl was schie gegangen.. versuche es bitte noch einmal.");
		}
		break;
	
	default:
		page_header("NPC-Details");
		$npcs = npc::getAllOf(0, false);
		$list = "<h3>Folgende NPCs gibt es in diesem Ort:</h3>\n";
		$list .= "<table border='1'>\n\t<tr class='trhead'><th>Name</th><th>Ersteller</th><th>Spieler</th><th>Ops</th></tr>\n";
		for($i = 0, $max = count($npcs); $i < $max; $i++) {
			$list .= "\t" . $npcs[$i]->printRow($i % 2 == 0 ? 'trlight' : 'trdark');
			addnav('', $npcs[$i]->getLink());
			addnav('', 'bio.php?char=' . $npcs[$i]->getErstellerLogin() . "&ret=" . URLEncode($_SERVER['REQUEST_URI']));
		}
		$list .= "</table>\n";
		output($list, true);
		break;
}
addnav("Weitere Orte");
addnav("Verwaltung", "npc.php?op=start");
addnav("NPC-Liste", "npc.php");
addnav('Ausgang');
addnav('Ins Rathaus', 'rathaus.php');
addnav('Ins Dorf', 'village.php');
page_footer();
?>