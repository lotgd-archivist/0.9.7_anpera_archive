<?php

//This is VOutput, or Variable Output.

?>