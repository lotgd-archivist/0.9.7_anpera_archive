<?
	$dwid=$args['dwid'];
	if($args['type']=="dwinns")
		blocknav("runmodule.php?module=dwellings&op=keys&dwid=$dwid");
?>
