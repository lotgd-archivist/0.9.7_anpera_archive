<?php
	require_once("lib/commentary.php");
	addcommentary();
	commentdisplay("", "coffers-$dwid","Speak into this dwelling",25,"echoes through the walls");
?>