<?php
	module_addhook("dwellings-list-interact");
	module_addhook("dwellings-management");
	module_addhook("newday-runonce");
	module_addhook("newday");
	module_addhook("pvpcount");
?>