<?php
	set_module_pref("cofferwiths", 0, "dwellings");
	set_module_pref("cofferdeps", 0, "dwellings");
?>