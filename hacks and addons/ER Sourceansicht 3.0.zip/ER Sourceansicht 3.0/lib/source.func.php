<?php 
/*
	A mod from "Basilius-Extensions"
	ER-Sourceviewer 2007 v2.0
	2007 by Basilius "Wasili" Sauter
*/

// ERSV-Functions

function ERSV_GetSizeString($size) {
	// Anzeige in Binärzeichen
	if($size < 1024) {
		return $size.' bytes';
	}
	elseif($size < 1024*1024) {
		//$KiB = floor($size/1024);
		//$Bytes = $size - $KiB * 1024;
		$KiB = $size/1024;
		$KiB = round($KiB, 2);
		$KiB = number_format($KiB, 2, ',', '\'');
		
		return $KiB.' KiB';
	}
	else {
		$MiB = $size/1024/1024;
		$MiB = round($KiB, 2);
		$MiB = number_format($MiB, 2, ',', '\'');
		
		return $MiB.' MiB';
	}
}


function ERSV_Crawl($dir) {
	$filetypes = explode('|', ERSV_FILETYPES);
	
	// Check die Datenbank auf vorhandensein
	$res = db_query('SELECT `dirid` FROM `ersv_dirs` WHERE `dirname` = "'.mysql_escape_string($dir).'"');
	if(db_num_rows($res) === 0) {
		db_query('INSERT INTO `ersv_dirs` (`dirname`, `allowed`) VALUES ("'.mysql_escape_string($dir).'", "'.ERSV_DEFDIRSTAT.'")');
		$dirID = db_insert_id();
	}
	else {
		$row = db_fetch_assoc($res);
		$dirID = $row['dirid'];
	}
	
	$d = dir($dir);
	
	while (false !== ($entry = $d->read())) {
		// dotfiles ausblenden
		if(substr($entry, 0, 1) != '.') {
			if(is_dir($entry)) {
				// Crawl!
				ERSV_Crawl($dir.$entry.'/');
			}
			elseif(is_file($dir.$entry)) {
				// Dateityp intressant?
				$lastdot = strrpos($entry, '.');
				$ext = substr($entry, $lastdot);
				if(array_search($ext, $filetypes) !== false) {
					// Gibts dat file schon inner DB?
					$completfilename = $dir.$entry;
					// print $completfilename;
					$entry = basename($entry);
					$res = db_query('SELECT `fileid` FROM `ersv_files` WHERE `dirid` = "'.$dirID.'" AND `filename` = "'.mysql_escape_string($entry).'"');
					if(db_num_rows($res) === 0) {
						// Datei gytts nyt
						db_query('INSERT INTO `ersv_files` (`dirid`, `filename`, `status`, `size`, `cdate`, `checked`) VALUES ('.$dirID.', "'.mysql_escape_string($entry).'", "'.ERSV_DEFFILESTAT.'", "'.filesize($completfilename).'", "'.date('Y-m-d h:i:s', filectime($completfilename)).'", "1")');
					}
					else {
						// Datei gytts
						db_query('UPDATE `ersv_files` SET `size` = "'.filesize($completfilename).'", `cdate` =  "'.date('Y-m-d h:i:s', filectime($completfilename)).'", checked= "1" WHERE `dirid` = "'.$dirID.'" AND `filename` = "'.mysql_escape_string($entry).'"');
					}
				}
			}
		}
	}
}

class ERSV_Highlight_File {
	protected $data = ''; // Generated Data
	protected $file = ''; // Loaded Data
	
	protected $linenum = 0;
	
	protected $manualtemplate = '<a href="http://ch2.php.net/manual/de/function.%s">%s</a>';
	protected $styletemplate = '<span style="color: %s">%s</span>';
	
	protected $defaultcolors = array();
	protected $ersvcolors = array(
		'string' => '#FF9900',
		'number' => '#606000',
		'comment' => '#808080',
		'keyword' => '#000099',
		'bg' => '#FFFFFF',
		'default' => '#000000',
		'variable' => '#7F0000',
		'html' => '#000000',
		'operator' => '#102060',
	);
	
	public $usedcolors = array();
	
	protected $return = true;
	
	public function __construct($return = true, $usedefaultcolors = false) {
		if($usedefaultcolors === true) {
			$this->defaultcolors = array(
				'string' => ini_get('highlight.string'),
				'number' => ini_get('highlight.string'),
				'comment' => ini_get('highlight.comment'),
				'keyword' => ini_get('highlight.keyword'),
				'bg' => ini_get('highlight.bg'),
				'default' => ini_get('highlight.default'),
				'variable' => ini_get('highlight.default'),
				'html' => ini_get('highlight.html'),
				'operator' => ini_get('highlight.default'),
			);
			
			$this->usedcolors = $this->defaultcolors;
		}
		else {
			$this->usedcolors = $this->ersvcolors;
		}
		
		$this->return = $return;
	}
	
	public function highlight_file($file) {
		$this->file = file_get_contents($file);
		
		// Getting pure file with highlighting
		$this->highlight($this->file);
		
		$lines = explode("\n", $this->data);
		$this->linenum = count($lines);
	
		$filenumlist = '';
		for($i = 1; $i<=$this->linenum; $i++) {
			$filenumlist .= "$i\n";
		}
		
		$this->data = '<table cellspacing="0" cellpading="0" style="width: 100%" border="0" class="onestyle">
			<tr style="vertical-align: top; width: 100%">
				<td>
					<pre>'.$this->data.'</pre>
				</td>
			</tr>
		</table>';
		
		// Tabellenzeilen-Tabelle oO
		$this->data2 = '<table cellspacing="0" cellpading="0" style="width: 100%%" border="0" style="twostyle">
			%s
		</table>';
		
		$spacer = '';
		
		foreach($lines as $line=>$cont) {
			$spacer.= '<tr style="vertical-align: top; width: 100%" class="everyline">
				<td style="background-color: #D0D0D0; width: 3em; text-align: right;">
					<pre style="color: #000000"">'.$line.'</pre>
				</td>
				<td style="text-align: left;" onmouseover="this.style.backgroundColor=&quot;#cccccc&quot;" onmouseout="this.style.backgroundColor=&quot;#ffffff&quot;">
					<pre>'.$cont.'</pre>
				</td>
			</tr>';
		}

		$this->data2 = sprintf($this->data2, $spacer);
		
		if($this->return === true) {
			return $this->data;
		}
		else {
			print $this->data;
		}
	}
	
	public function getLinedData() {
		return $this->data2;
	}
	
	protected function highlight($data) {
		$tokens = token_get_all($data);
		$this->token_fix($tokens);
		
		//var_dump($tokens);
		//echo T_OPEN_TAG;
		
		$allfunctions = get_defined_functions();
		
		
		foreach($tokens as $n=>$token) {
			switch($token[0]) {
				// PHP-Tags
				case T_OPEN_TAG:
				case T_OPEN_TAG_WITH_ECHO:
				case T_CLOSE_TAG: 
					$this->data .= sprintf($this->styletemplate, $this->usedcolors['default'], HTMLSpecialchars($token[1]));
					break;
					
				// Kommentare
				case T_COMMENT:
				case T_DOC_COMMENT:
				case T_ML_COMMENT: # PHP4
					$this->data .= sprintf($this->styletemplate, $this->usedcolors['comment'], HTMLSpecialchars($token[1]));
					break;
					
				// Strings
				case T_NUM_STRING:
				case T_CONSTANT_ENCAPSED_STRING:
				case T_DOC_COMMENT:
				case 314:
					$this->data .= sprintf($this->styletemplate, $this->usedcolors['string'], HTMLSpecialchars($token[1]));
					break;
					
				// Wrong " and '
				case '"':
				case '\'':
					$this->data .= sprintf($this->styletemplate, $this->usedcolors['string'], HTMLSpecialchars($token[0]));
					break;
					
				// Zahlen
				case T_DNUMBER:
				case T_LNUMBER:
					$this->data .= sprintf($this->styletemplate, $this->usedcolors['number'], HTMLSpecialchars($token[1]));
					break;
					
				// Eigene Funktionen, Konstanten
				case T_STRING:
					if(strtolower($token[1]) === 'false' OR strtolower($token[1]) === 'true') {
						$this->data .= sprintf($this->styletemplate, $this->usedcolors['keyword'], HTMLSpecialchars($token[1]));
					}
					else {
						//var_dump($tokens[$n+1], $tokens[$n-2]);
						if($tokens[$n+1] == '(' AND $tokens[$n-1][0] != T_FUNCTION) {
							// Funktion		
							if(in_array($token[1], $allfunctions['internal'])) {
								// PHP-Funktion
								$highlight = sprintf($this->styletemplate, $this->usedcolors['default'], HTMLSpecialchars($token[1]));
								$this->data .= sprintf($this->manualtemplate, $token[1], $highlight);
							}
							else {
								$this->data .= sprintf($this->styletemplate, $this->usedcolors['default'], HTMLSpecialchars($token[1]));
							}
						}
						else {
							$this->data .= sprintf($this->styletemplate, $this->usedcolors['default'], HTMLSpecialchars($token[1]));
						}
					}
					break;
					
				// PHP-Codewörter
				case T_FUNCTION:
				case T_ABSTRACT:
				case T_IF:
				case T_ELSE:
				case T_ELSEIF:
				case T_ECHO:
				case T_PRINT:
				case T_DEFINE:
				case T_PRIVATE:
				case T_PUBLIC:
				case T_PROTECTED:
				case T_REQUIRE:
				case T_REQUIRE_ONCE:
				case T_RETURN:
				case T_UNSET:
				case T_VAR:
				case T_OLD_FUNCTION:
				case T_DO:
				case T_ENDIF:
				case T_ENDSWITCH:
				case T_ENDWHILE:
				case T_EVAL:
				case T_EXIT:
				case T_IMPLEMENTS:
				case T_EXTENDS:
				case T_EMPTY:
				case T_ARRAY:
				case T_AS:
				case T_CONTINUE:
				case T_CLONE:
				case T_CLASS:
				case T_DOUBLE_CAST:
				case T_BOOL_CAST:
				case T_ARRAY_CAST:
				case T_INT_CAST:
				case T_OBJECT_CAST:
				case T_STRING_CAST:
				case T_UNSET_CAST:
				case T_INCLUDE_ONCE:
				case T_INCLUDE:
				case T_HALT_COMPILER:
				case T_GOTO:
				case T_GLOBAL:
				case T_ISSET:
				case T_INTERFACE:
				case T_INSTANCEOF:
				case T_ENDDECLARE:
				case T_ENDFOR:
				case T_ENDFOREACH:
				case T_DECLARE:
				case T_BREAK:
				case T_CASE:
				case T_CATCH:
				case T_DEFAULT:
				case T_FINAL:
				case T_FOR:
				case T_FOREACH:
				case T_WHILE:
				case T_CONST:
				case T_STATIC:
				case T_NEW:
				case T_THROW:
				case T_TRY:
				case T_SWITCH:
				case T_LIST:
				case T_USE:
					$this->data .= sprintf($this->styletemplate, $this->usedcolors['keyword'], HTMLSpecialchars($token[1]));
					break;
				
				// PHP-Magische Konstanten
				case T_DIR:
				case T_LINE:
				case T_FILE:
				case T_CLASS_C:
				case T_FUNC_C:
				case T_METHOD_C:
				case T_NS_C:
				case T_METHOD_C:
				case T_METHOD_C:
				case T_METHOD_C:
					$this->data .= sprintf($this->styletemplate, $this->usedcolors['keyword'], HTMLSpecialchars($token[1]));
					break;
					
				// Variablen
				case T_VARIABLE:
				case T_DOLLAR_OPEN_CURLY_BRACES:
				case T_STRING_VARNAME:
					$this->data .= sprintf($this->styletemplate, $this->usedcolors['variable'], HTMLSpecialchars($token[1]));
					break;
				
				// Leerzeichen
				case T_WHITESPACE:
				case T_CHARACTER:
				case T_BAD_CHARACTER:
					//if(substr($token[1], -1) == "\n" OR substr($token[1], -1) == "\r") {
					//	$this->linenum++;
					//}
					$this->data .= $token[1];
					break;
					
				// Inline-HTML
				case T_INLINE_HTML:
					$this->data .= sprintf($this->styletemplate, $this->usedcolors['html'], HTMLSpecialchars($token[1]));
					break;
					
				// Symbole
				case T_AND_EQUAL: // &=
				case T_BOOLEAN_AND: // &&
				case T_BOOLEAN_OR: // ||
				case T_DOUBLE_ARROW: // =>
				case T_DOUBLE_COLON: // ::
				case T_LOGICAL_AND: // AND
				case T_LOGICAL_OR: // OR
				case T_LOGICAL_XOR: // XOR
				case T_MINUS_EQUAL: // -=
				case T_MOD_EQUAL: // %=
				case T_MUL_EQUAL: // *=
				case T_XOR_EQUAL: // ^=
				case T_CONCAT_EQUAL: // .=
				case T_DEC: // --
				case T_INC: // ++
				case T_DIV_EQUAL: // /=
				case T_SL: // <<
				case T_SL_EQUAL: // <<=
				case T_SR: // >>
				case T_SR_EQUAL: // >>=
				case T_START_HEREDOC: // <<<
				case T_END_HEREDOC: // XYZ;
				case T_PAAMAYIM_NEKUDOTAYIM: // ::
				case T_PLUS_EQUAL: // +=
				case T_OR_EQUAL: // |=
				case T_OBJECT_OPERATOR: // ->
				case T_IS_EQUAL: // ==
				case T_IS_GREATER_OR_EQUAL: // >=
				case T_IS_IDENTICAL: // ===
				case T_IS_NOT_EQUAL: // !=, <>
				case T_IS_NOT_IDENTICAL: // !==
				case T_IS_SMALLER_OR_EQUAL: // <=
				case T_CURLY_OPEN:
					$this->data .= sprintf($this->styletemplate, $this->usedcolors['operator'], HTMLSpecialchars($token[1]));
					break;
				
				// Andere Zeichen mit Spezialbedeutung
				case '(':
				case ')':
				case '[':
				case ']':
				case '{':
				case '}':
				case '.':
				case ',':
				case ';':
				case ':':
				case '=':
				case '!':
				case '?':
				case '&':
				case '|':
				case '<':
				case '>':
					$this->data .= sprintf($this->styletemplate, $this->usedcolors['operator'], HTMLSpecialchars($token[0]));
					break;
					
				default:
					$this->data .= "<span>".HTMLSpecialchars($token[1])."</span>";
			}
		}
	}
	
	// from php.net
	//fixes related bugs: 29761, 34782 => token_get_all returns ?php NOT as T_OPEN_TAG
	function token_fix( &$tokens ) {
		if (!is_array($tokens) || (count($tokens)<2)) {
			return;
		}
	   //return of no fixing needed
		if (is_array($tokens[0]) && (($tokens[0][0]==T_OPEN_TAG) || ($tokens[0][0]==T_OPEN_TAG_WITH_ECHO)) ) {
			return;
		}
		//continue
		$p1 = (is_array($tokens[0])?$tokens[0][1]:$tokens[0]);
		$p2 = (is_array($tokens[1])?$tokens[1][1]:$tokens[1]);
		$p3 = '';

		if (($p1.$p2 == '<?') || ($p1.$p2 == '<%')) {
			$type = ($p2=='?')?T_OPEN_TAG:T_OPEN_TAG_WITH_ECHO;
			$del = 2;
			//update token type for 3rd part?
			if (count($tokens)>2) {
				$p3 = is_array($tokens[2])?$tokens[2][1]:$tokens[2];
				$del = (($p3=='php') || ($p3=='='))?3:2;
				$type = ($p3=='=')?T_OPEN_TAG_WITH_ECHO:$type;
			}
			//rebuild erroneous token
			$temp = array($type, $p1.$p2.$p3);
			if (version_compare(phpversion(), '5.2.2', '<' )===false) {
				$temp[] = $token[0][2];
			}
			//rebuild
			$tokens[1] = '';
			if ($del==3) $tokens[2]='';
			$tokens[0] = $temp;
		}
		return;
	}
}


define('ERSV_NAME', 'ER Sourceansicht');
define('ERSV_VERSION', '3.0');

define('ERSV_AUTOCRAWL', getsetting('ERSV_AUTOCRAWL', 1));
define('ERSV_LASTCRAWL', date('YmdH', intval(getsetting('ERSV_LASTCRAWL', '0000000000'))));
define('ERSV_NOW', date('YmdH'));

define('ERSV_DEFFILESTAT', getsetting('ERSV_DEFFILESTAT', 'open'));
define('ERSV_DEFDIRSTAT', getsetting('ERSV_DEFDIRSTAT', '1'));
define('ERSV_FILETYPES', getsetting('ERSV_FILETYPES', '.php'));

?>