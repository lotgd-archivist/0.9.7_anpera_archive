<?php
/*
	A mod from "Basilius-Extensions"
	ER-Sourceviewer 2007 v2.0
	2007 by Basilius "Wasili" Sauter
*/

define('ER_ALLOWNONNAV', true);
define('ER_ALLOWANONYMOUS', true);

Require_once 'common.php';
Require_once 'lib/source.func.php';

if(ERSV_AUTOCRAWL && (ERSV_NOW - ERSV_LASTCRAWL) > 60*60*24) {
	ERSV_Crawl('./');
	savesetting('ERSV_LASTCRAWL', time());
}

$scandirs = array();

$res = db_query('SELECT `dirid`, `dirname` FROM `ersv_dirs` WHERE `allowed` = "1" ORDER BY `dirid`') or die(db_error());

while($row = db_fetch_assoc($res)) {
	$scandirs[$row['dirid']] = $row['dirname'];
}

if(empty($_POST['fileid'])) {	
	$title =  ERSV_NAME.' '.ERSV_VERSION;
	
}
else {
	$REQUESTED_FILE_RES = db_query('SELECT * FROM `ersv_files` WHERE `fileid` = '.intval($_POST['fileid']).' AND (`status` = "" OR `status` = "open")');
	
	if(db_num_rows($REQUESTED_FILE_RES) > 0) {
		$REQUESTED_FILE = db_fetch_assoc($REQUESTED_FILE_RES);
		$title = ERSV_NAME.' '.ERSV_VERSION.' » '.$scandirs[$REQUESTED_FILE['dirid']].$REQUESTED_FILE['filename'];
	}
	else {
		$title =  ERSV_NAME.' '.ERSV_VERSION;
	}
}

$filelist = '';

$res = db_query('SELECT * FROM `ersv_files` WHERE `status` != "hidden" ORDER BY `dirid`, `filename`');
$aDir = false;

$i = 0;
while($row = db_fetch_assoc($res)) {
	if(empty($scandirs[$row['dirid']])) {
		# Lösche nicht anzeigbare Dateien aus der Datenbank
		db_query('DELETE FROM `ersv_files` WHERE `fileid` = '.$row['fileid']);
	}
	else {
		if($row['filename'] != 'dbconnect.php') {
			$i++;
			if($aDir !== $row['dirid']) {

				$aDir2 = $aDir;
				$aDir = $row['dirid'];
			}
			
			$dirname = $scandirs[$row['dirid']];
			
			if($row['status'] === 'blocked') {
				$filelist .= '<option class="blocked" value="blocked">'.HTMLSpecialChars($dirname.$row['filename']).'</option>';
			}
			else {
				$filelist .= '<option class="notblocked" value="'.$row['fileid'].'" '
					.($row['fileid']==$_POST['fileid']?'selected="selected"':'').'>'
					.HTMLSpecialChars($dirname.$row['filename']).'</option>';
			}
		}
	}
}

$fileprint = '';

if($_POST['fileid'] == 'blocked') {
	$fileprint = '<div style="color: red; padding: 0.5em;">Aufruf der Blockierten Datei zurückgewiesen: Du darfst diese Datei nicht aufrufen.</div>';
}
elseif(!empty($REQUESTED_FILE)) {
	// Wenn nicht leer und nicht blockiert - Dann Dateiausgabe ^^
	$fileprint = '';
	
	if($REQUESTED_FILE['filename'] == 'dbconnect.php') {
		// Schütze uns vor Gewieften Dieben!
		$content = file_get_contents('index.php');
		$content = highlight_string($content, true);
		$content = str_replace("\r", "", $content);
		$fileprint.= "<pre>$content</pre>";
	}
	else {
		//$content = file_get_contents($scandirs[$REQUESTED_FILE['dirid']].$REQUESTED_FILE['filename']);
		//$content = highlight_string($content, true);
		$Highlight = new ERSV_Highlight_File();
		$content = $Highlight->highlight_file($scandirs[$REQUESTED_FILE['dirid']].$REQUESTED_FILE['filename']);
		$content = str_replace("\r", "", $content);
		$fileprint.= "<div id=\"filelistall\" class=\"pre\" style=\"visibility: hidden; display: none;\">$content</div>";
		
		$content2 = $Highlight->getLinedData();
		$content2 = str_replace("\r", "", $content2);
		$fileprint.= "<div id=\"filelistlines\" class=\"pre\" style=\"visibility: visible; display: block;\">$content2</div>";
		
		$fileinfo = '%s, Zuletzt geändert am %s';
		
		$fileinfo = sprintf($fileinfo, ERSV_GetSizeString($REQUESTED_FILE['size']), date('d.m.Y G:i', strtotime($REQUESTED_FILE['cdate'])));
	}
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de-CH" lang="de-CH">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
		<title><?php echo $title ?></title>
		
		<script type="text/javascript">			
			function switchCodeStyle(that) {
				ob = document.getElementById("filelistall");
				ob2 = document.getElementById("filelistlines");
				
				if(ob.style.visibility == "hidden") {
					ob.style.visibility = "visible";
					ob.style.display = "block";
					
					ob2.style.visibility = "hidden";
					ob2.style.display = "none";
					
					that.innerHTML = 'Zeilen einblenden';
				}
				else {
					ob.style.visibility = "hidden";
					ob.style.display = "none";
					
					ob2.style.visibility = "visible";
					ob2.style.display = "block";
					
					that.innerHTML = 'Zeilen ausblenden';
				}
			}
		</script>
		
		<style type="text/css">
			<!--
			
			body {
				background-color: #333;
				color: #DDD;
				font-family: "Helvetica", "Arial", sans-serif;
			}
			
			table, tr {
				padding: 0;
				margin: 0;
				line-height: 1em;
				border: none;
			}
			
			td {
				padding: 0em;
				margin: 0;
			}
			
			table tbody {
				width: 100%;
			}
			
			tr.everyline:hover {
				background-color: #cccccc;
			}
			
			a {
				text-decoration: none;
				color: #F60;
			}
			
			a:hover {
				color: #FF0;
			}
			
			div.pre {
				background-color: #fff;
				font-family: "Courier New", "Courier", monospace;
				font-size: 1em;
			}
			
			pre {
				line-height: 1em;
				margin-top: 0;
				margin-bottom: 0;
				padding: 0.1em;
				
				padding-left: 0.5em !important;
			}
			
			pre a {
				text-decoration: underline;
			}
			
			body {
				margin: 0;
				padding: 0;
			}
			
			div.header {
				position: fixed;
				top: 0em;
				
				height: 2em;
				width: 100%;
				
				background-color: buttonface;
				color: buttontext;
				
				vertical-align: center;
				
				padding: 0.2em;
			}
			
			div.footer {
				position: fixed;
				bottom: 0em;
				
				height: 1em;
				width: 100%;
				
				background-color: buttonface;
				color: buttontext;
				
				padding: 0.5em;
			}
			
			div.content {
				/*margin-top: 2.5em;
				margin-bottom: 2em;*/
				position: fixed;
				
				top: 2.5em;
				bottom: 2em;
				
				left: 0em;
				right: 0em;
				
				overflow: scroll;
			}
			
			div.header img {
				float: left;
			}
			
			div.header h1 {
				display: block;
				float: left;
				
				font-size: inherit;
				font-weight: bold;
				
				margin-top: 0.5em;
				margin-bottom: 0.5em;
				margin-right: 5em;
				margin-right: 1em;
			}
			
			#lineswitch {
				display: block;
				margin-top: 0.5em;
				margin-bottom: 0.5em;
				margin-left: auto;
				margin-right: 1em;
				
				text-align: right;
			}
			
			div.footer fieldset {
				border: 0;
				padding: 0;
				margin: 0;
				
				float: left;
			}
			
			table.onestyle pre {
				line-height: 1.19em !important;
			}
			
			div.footer div {
				margin-left: auto;
				margin-right: 1em;
				
				text-align: right;
			}
			
			fieldset option.blocked {
				text-decoration: line-through;
			}
			-->
		</style>
	</head>
	
	<body onload="document.getElementById(&quot;fileshowbutton&quot;).style.visibility=&quot;hidden&quot;;ocument.getElementById(&quot;fileshowbutton&quot;).style.display=&quot;none&quot;">
	
		<div id="nonFooter">
			<div id="header" class="header">
				<img src="./images/source-logo.png" style="height: 2em; width: 2em;" alt="Logo" />
				<h1 id="oben"><?php echo $title ?></h1>
				
				<button id="lineswitch" onclick="switchCodeStyle(this)" type="submit">Zeilen ausblenden</button>
				
				<div style="clear: both;"></div>
			</div>
			
			<div id="content" class="content">
				<?php echo $fileprint ?>
			</div>
		</div>
		
		<div id="footer" class="footer">
			<form name="filechooseform" method="post" action="source.php">
				<fieldset>
					<label for="choosefile">Datei auswählen</label>
					<select id="choosefile" onchange="document.filechooseform.submit();" name="fileid">
						<?php echo $filelist ?>
					</select>
					
					<input type="submit" id="fileshowbutton" value="Anzeigen" />
				</fieldset>
			</form>
			
			<div id="fileinfo">
				<?php echo $fileinfo ?>
			</div>
		</div>
	</body>
</html>