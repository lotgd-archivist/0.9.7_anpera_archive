<?php
/*
	A mod from "Basilius-Extensions"
	ER-Sourceviewer 2007 v2.0
	2007 by Basilius "Wasili" Sauter
*/

Require_once 'common.php';
Require_once 'lib/source.func.php';

if(ERSV_AUTOCRAWL && (ERSV_LASTCRAWL < ERSV_NOW)) {
	ERSV_Crawl('./');
	savesetting('ERSV_LASTCRAWL', time());
}

$scandirs = array();

$res = db_query('SELECT `dirid`, `dirname` FROM `ersv_dirs` WHERE `allowed` = "1" ORDER BY `dirid`') or die(db_error());

while($row = db_fetch_assoc($res)) {
	$scandirs[$row['dirid']] = $row['dirname'];
}

if(empty($_GET['dir']) || empty($_GET['file'])) {	
	$title =  ERSV_NAME.' '.ERSV_VERSION;
	
}
else {
	$REQUESTED_FILE_RES = db_query('SELECT * FROM `ersv_files` WHERE (`dirid` = '.intval($_GET['dir']).' AND `fileid` = '.intval($_GET['file']).') AND (`status` = "" OR `status` = "open")');
	
	if(db_num_rows($REQUESTED_FILE_RES) > 0) {
		$REQUESTED_FILE = db_fetch_assoc($REQUESTED_FILE_RES);
		$title = ERSV_NAME.' '.ERSV_VERSION.' >> '.$scandirs[$REQUESTED_FILE['dirid']].$REQUESTED_FILE['filename'];	
	}
	else {
		$title =  ERSV_NAME.' '.ERSV_VERSION;
	}
}

$dirlist = '';
foreach($scandirs as $dirid => $dir) {
	$dirlist.= '<li><a href="#dir_'.$dirid.'" onClick="view(getElementById(\'filelist_'.$dirid.'\')); return false;">'.$dir.'</a></li> ';
}

$filelist = '';
$js_func_hideall = '';

$res = db_query('SELECT * FROM `ersv_files` WHERE `status` != "hidden" ORDER BY `dirid`, `filename`');
$aDir = false;

$i = 0;
while($row = db_fetch_assoc($res)) {
	if(empty($scandirs[$row['dirid']])) {
		# L�sche nicht anzeigbare Dateien aus der Datenbank
		db_query('DELETE FROM `ersv_files` WHERE `fileid` = '.$row['fileid']);
	}
	else {
		if($row['filename'] != 'dbconnect.php') {
			$i++;
			if($aDir !== $row['dirid']) {
				if($i > 1) {$filelist.= '</li>'; }
				$filelist.= '<li id="filelist_'.$row['dirid'].'">
					<h2 id="dir_'.$row['dirid'].'">'.$scandirs[$row['dirid']].'</h2>
					<p><a href="#oben">Hoch</a></p>
				
				';
				
				$js_func_hideall .= 'document.getElementById("filelist_'.$row['dirid'].'").style.visibility = "hidden";
				document.getElementById("filelist_'.$row['dirid'].'").style.display = "none";
				';
				
				$aDir2 = $aDir;
				$aDir = $row['dirid'];
			}
			
			if($row['status'] === 'blocked') {
				# Blockierte Dateien
				$filelist.= '<dl class="file gesperrt">
					<dt>'.$row['filename'].'</dt>
					<dd>
						<dl>
							<dt>Gesperrt: </dt>
							<dd>'.HTMLEntities($row['blocktext']).'</dd>
							
							<dt>Gr�sse: </dt>
							<dd>'.ERSV_GetSizeString($row['size']).'</dd>
							
							<dt>Letzte �nderung </dt>
							<dd>'.date('d.m.Y G:i', strtotime($row['cdate'])).'</dd>
							'.(empty($row['download'])? '' : '
							<dt>Download</dt>
							<dd><a href="'.$row['download'].'">'.basename($row['download']).'</a></dd>').'
						</dl>
					</dd>
				</dl>
				';
			}
			else {
				# Unblockierte Dateien; K�nnen nicht versteckt sein ^^
				$filelist.= '<dl class="file">
					<dt><a href="source.php?dir='.$row['dirid'].'&amp;file='.$row['fileid'].'">'.$row['filename'].'</a></dt>
					<dd>
						<dl>						
							<dt>Gr�sse: </dt>
							<dd>'.ERSV_GetSizeString($row['size']).'</dd>
							
							<dt>Letzte �nderung </dt>
							<dd>'.date('d.m.Y G:i', strtotime($row['cdate'])).'</dd>
							'.(empty($row['download'])? '' : '
							<dt>Download</dt>
							<dd><a href="'.$row['download'].'">'.basename($row['download']).'</a></dd>').'
						</dl>
					</dd>
				</dl>
				';
			}
		}
	}
}
$filelist .= '</li>';

$fileprint = '';

if(!empty($REQUESTED_FILE)) {
	// Wenn nicht leer - Dann Dateiausgabe ^^
	$fileprint = '<hr />
	<h2 id="showsource">Source anzeigen</h2>
	<p><a href="#oben">Nach Oben</a></p>
	';
	
	if($REQUESTED_FILE['filename'] == 'dbconnect.php') {
		// Sch�tze uns vor Gewieften Dieben!
		$content = file_get_contents('index.php');
		$content = highlight_string($content, true);
		$content = str_replace("\r", "", $content);
		$fileprint.= "<pre>$content</pre>";
	}
	else {
		$content = file_get_contents($scandirs[$REQUESTED_FILE['dirid']].$REQUESTED_FILE['filename']);
		$content = highlight_string($content, true);
		$content = str_replace("\r", "", $content);
		$fileprint.= "<pre>$content</pre>";
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de-CH" lang="de-CH">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
		<title><?=$title ?></title>
		
		<script type="text/javascript">
			function hideall() {
				<?=$js_func_hideall ?>
			}
			
			function view(ob) {
				if(ob.style.visibility == "hidden") {
					ob.style.visibility = "visible";
					ob.style.display = "block";
				}
				else {
					ob.style.visibility = "hidden";
					ob.style.display = "none";
				}
			}
		</script>
		
		<style type="text/css">
			<!--
			* {
				font-family: "Helvetic", "Arial", sans-serif;
			}
			
			body {
				background-color: #333;
				color: #DDD;
			}
			
			ul {
				list-style-type: none;
			}
			
			dl.file, 
			dl.file > dd {
				margin-bottom: 1em;
			}
			
			dl.file > dt {
				font-weight: bold;
			}
			
			dl.file dd dl {
				font-size: 0.8em;
			}
			
			dl.file dd dt {
				font-weight: normal;
			}
			
			dl.file dd dd {
				font-style: italic;
			}
			
			dl.gesperrt > dt {
				color: #F00;
			}
			
			a {
				text-decoration: none;
				color: #F60;
			}
			
			a:hover {
				color: #FF0;
			}
			
			pre {
				font-family: "Courier New", "Courier", monospace;
				font-size: 0.8em;
				background-color: #fff;
				border: 1px solid gray;
				padding: 1em;
			}
			
			pre span, pre font {
				font-family: "Courier New", "Courier", monospace;
			}
			
			pre a {
				text-decoration: underline;
			}
			
			
			-->
		</style>
	</head>
	
	<body>
<h1 id="oben"><?=ERSV_NAME.' '.ERSV_VERSION ?></h1>
<p>Alle Dateien, die hier eingesehen werden k�nnen, sind unter der GNU GPL lizenziert. Wenn du etwas darin findest, das du gerne h�ttest, so schreibe mir doch bitte eine Anfrage damit ich, wenn ich es rausgeben will, alle �nderungen raussuchen k�nnte. Denn ich �bernehme keine Verantwortung, solltest du was rausnehmen und es geht nicht. Und Support deswegen geb ich schon gar nicht.</p>

<p>Solltest du eine Schwachstelle im Code finden, sei es eine kritische L�cke oder eine M�glichkeit zu cheaten, dann bitte ich dich, mir das mitzuteilen. Solltest du beim cheaten erwischt werden, werde ich deinen Account eigenh�ndig l�schen &amp; bannen; Solltest du meinen Server angreifen, so werde ich meine Rechtsschutzversicherung kontaktieren.</p>

<p><a href="#showsource">Zur Source springen</a></p>

<p>Verzeichnisse:</p>
<ul><?=$dirlist ?></ul>

<ul><?=$filelist ?></ul>

<script type="text/javascript">
	hideall();
</script>
		
<?=$fileprint ?>

	</body>
</html>