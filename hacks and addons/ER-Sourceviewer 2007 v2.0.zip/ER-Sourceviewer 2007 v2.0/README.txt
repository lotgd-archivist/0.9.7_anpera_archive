+---------------------------------------+
|                                       |
|  ER-Sourceviewer 2007 v2.0-rc         |
|                                       |
+---------------------------------------+



=====================
 Installation
=====================

 Dateien
---------------------

In das LotGD-Rootvereichnis geh�ren:
 - source.su.php
 - source.php (...Die alte damit ersetzen...)

In das Subdir "lib" geh�ren:
 - source.func.php


 �nderungen
---------------------

~~ configuration.php ~~

	--[Suche]--

		"Mail Einstellungen,title",
		"mailsizelimit"=>"Maximale Anzahl an Zeichen in einer Nachricht,int",
		"inboxlimit"=>"Anzahl an Nachrichten in der Inbox,int",
		"oldmail"=>"Alte Nachrichten automatisch l�schen nach x Tagen. x =,int",


	--[F�ge danach ein]--

		'ER-Sourceviewer 2007,title',
		'ERSV_DEFFILESTAT' => 'Neue Dateien sind bei aufnahme,enum,open,Ge�ffnet,blocked,Blockiert',
		'ERSV_DEFDIRSTAT' => 'Neue Verzeichnisse Standardgem�ss aktiviert?, bool',
		'ERSV_FILETYPES' => 'Die hier gelisteten Dateierweiterungen werden beim crawlen eingefangen (Bitte keine Bin�rdateien wie Bilder!!!)',
		'ERSV_AUTOCRAWL' => 'Jede Stunde alle Dateien automatisch einfangen?, bool',

~~ source.su.php ~~

	--[Suche]--
		if ($session[user][superuser]>=3) addnav("User Editor","user.php");

	--[F�ge danach ein]--
		if ($session['user']['superuser']>=3) addnav('`iER Sourceviewer 2007`i >> `bEditor`b', 'source.su.php');

=====================
 Datenbankstrukturen
=====================

CREATE TABLE `ersv_dirs` (
  `dirid` tinyint(3) unsigned NOT NULL auto_increment,
  `dirname` varchar(255) NOT NULL,
  `allowed` enum('0','1') NOT NULL default '1',
  PRIMARY KEY  (`dirid`)
) ENGINE=MyISAM;

CREATE TABLE `ersv_files` (
  `fileid` smallint(5) unsigned NOT NULL auto_increment,
  `dirid` tinyint(3) unsigned default NULL,
  `filename` varchar(255) NOT NULL,
  `status` enum('open','hidden','blocked') NOT NULL,
  `download` varchar(255) default NULL,
  `blocktext` varchar(255) NOT NULL,
  `size` int(11) NOT NULL,
  `cdate` datetime NOT NULL,
  `checked` enum('0','1') NOT NULL default '0',
  PRIMARY KEY  (`fileid`),
  KEY `dirid` (`dirid`,`filename`)
) ENGINE=MyISAM ;


=====================
 Versions-History
=====================
	
	1.0: Finale Version, unver�ffentlicht, ohne Datenbank
	2.0-rc: Releasecandidate; Datenbankunterst�tzung mit Einstellungen, dbconnect.php idiotensicher versteckt.