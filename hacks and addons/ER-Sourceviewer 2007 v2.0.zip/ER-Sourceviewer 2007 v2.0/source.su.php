<?php
/*
	A mod from "Basilius-Extensions"
	ER-Sourceviewer 2007 v2.0
	2007 by Basilius "Wasili" Sauter
*/

Require_once 'common.php';
Require_once 'lib/source.func.php';

define('ERSV_DEFFILESTAT', getsetting('ERSV_DEFFILESTAT', 'open'));
define('ERSV_DEFDIRSTAT', getsetting('ERSV_DEFDIRSTAT', '1'));
define('ERSV_FILETYPES', getsetting('ERSV_FILETYPES', '.php'));

page_header(ERSV_NAME.' '.ERSV_VERSION.' >> Editor');

addnav('Editor');
addnav('�bersicht', 'source.su.php');
addnav('Verzeichnisse verwalten', 'source.su.php?q=dirs');
addnav('Dateien verwalten', 'source.su.php?q=files');
addnav('Dateitabelle aktualisieren', 'source.su.php?q=refreshdb');

addnav('Zur�ck');
addnav('Weltliches', 'village.php');
addnav('Grotte', 'superuser.php');

switch(empty($_GET['q']) ? '' : $_GET['q']) {
	case 'files':
		rawoutput('<h2>'.ERSV_NAME.' '.ERSV_VERSION.' >> Editor >> Dateien</h2>');
		
		if(isset($_GET['op']) && $_GET['op'] == 'save') {
			# �nderungen speichern
			foreach($_POST['status'] as $fileid  => $status) {
				db_query('UPDATE `ersv_files` SET 
					`status` = "'.mysql_escape_string(stripslashes($status)).'",
					`blocktext` = "'.mysql_escape_string(stripslashes($_POST['blocktext'][$fileid])).'",
					`download` = '.(empty($_POST['download'][$fileid]) ? 'NULL' : '"'.mysql_escape_string(stripslashes($_POST['download'][$fileid])).'"').'
					WHERE `fileid` = "'.intval($fileid).'"') or die(db_eror());
			}
		}
		
		$res = db_query('SELECT `ersv_files`.*, `ersv_dirs`.`dirname` FROM `ersv_files` INNER JOIN `ersv_dirs` USING(`dirid`)');
		
		if(db_num_rows($res) > 0) {
			$tablecontent = '';
			
			$i = 0;
			while($row = db_fetch_assoc($res)) {
				$tableclass = $i%2?'trdark':'trlight';
				$tablecontent .= '<tr class="'.$tableclass.'">
				<td>'.$row['dirname'].'</td>
				<td>'.$row['filename'].'</td>
				<td><select name="status['.$row['fileid'].']" size="1">
					<option value="open" '.($row['status'] === 'open' ? 'selected="selected"' : '').'>Offen</option>
					<option value="blocked" '.($row['status'] === 'blocked'? 'selected="selected"' : '').'>Blockiert</option>
					<option value="hidden" '.($row['status'] === 'hidden'? 'selected="selected"' : '').'>Versteckt</option>
				</select></td>
				<td>'.ERSV_GetSizeString($row['size']).'</td>
				<td>'.date('d.m.Y G:i', strtotime($row['cdate'])).'</td>
				<td><input type="text" name="blocktext['.$row['fileid'].']" maxlenght="255" size="20" value="'.$row['blocktext'].'" /></td>
				<td><input type="text" name="download['.$row['fileid'].']" maxlenght="255" size="20" value="'.$row['download'].'" /></td>
			<tr>';
				$i++;
			}
		}
		else {
			$tablecontent = '<tr class="trdark">
				<td colspan="2">Tja. Lasse erst einmal die Spinne laufen, bevor du hier �nderungen vornimmst :)</td>
			<tr>';
		}
		
		addnav('', 'source.su.php?q=files&op=save');
		rawoutput('<form action="source.su.php?q=files&op=save" method="POST">
		<table border="0" cellpadding="2" cellspacing="1" bgcolor="#999999">
			<tr class="trhead" style="font-weight: bold;">
				<td>Verzeichnis</td>
				<td>Dateiname</td>
				<td>Status</td>
				<td>Gr�sse</td>
				<td>Letzte �nderung</td>
				<td>Blockiertext</td>
				<td>Download</td>
			</tr>'.$tablecontent.'<tr class="trhead" style="font-weight: bold; padding-top: 1em;">
				<td colspan="6"><input type="submit" value="�nderungen �bernehmen" class="button"/></td>
				<td style="text-align: right;">'.db_num_rows($res).' Dateien total</td>
			</tr>
		</table>
		</form>');
		break;
		
	case 'dirs':
		rawoutput('<h2>'.ERSV_NAME.' '.ERSV_VERSION.' >> Editor >> Verzeichnisse</h2>');
		
		if(isset($_GET['op']) && $_GET['op'] == 'save') {
			# �nderungen speichern
			foreach($_POST['dirs'] as $dirid => $allowed) {
				db_query('UPDATe `ersv_dirs` SET `allowed` = "'.intval($allowed).'" WHERE `dirid` = "'.$dirid.'"');
			}
		}
		
		$res = db_query('SELECT * FROM `ersv_dirs`');
		
		if(db_num_rows($res) > 0) {
			$tablecontent = '';
			
			$i = 0;
			while($row = db_fetch_assoc($res)) {
				$tableclass = $i%2?'trdark':'trlight';
				$tablecontent .= '<tr class="'.$tableclass.'">
				<td>'.$row['dirname'].'</td>
				<td><select name="dirs['.$row['dirid'].']" size="1">
					<option value="0" '.($row['allowed']==0?'selected="selected"':'').'>Zugriff Blockieren</option>
					<option value="1" '.($row['allowed']==1?'selected="selected"':'').'>Zugriff erlauben</option>
				</select></td>
			<tr>';
				$i++;
			}
		}
		else {
			$tablecontent = '<tr class="trdark">
				<td colspan="2">Tja. Lasse erst einmal die Spinne laufen, bevor du hier �nderungen vornimmst :)</td>
			<tr>';
		}
		
		addnav('', 'source.su.php?q=dirs&op=save');
		rawoutput('<form action="source.su.php?q=dirs&op=save" method="POST">
		<table border="0" cellpadding="2" cellspacing="1" bgcolor="#999999">
			<tr class="trhead" style="font-weight: bold;">
				<td>Verzeichnisname</td>
				<td>Optionen</td>
			</tr>'.$tablecontent.'<tr class="trhead" style="font-weight: bold; padding-top: 1em;">
				<td><input type="submit" value="�nderungen �bernehmen" class="button"/></td>
				<td style="text-align: right;">'.db_num_rows($res).' Verzeichnisse total</td>
			</tr>
		</table>
		</form>');
		break;
		
	case 'refreshdb':
		db_query('UPDATE `ersv_files` SET `checked` = "0"');
		
		// Cache leeren
		clearstatcache();
		
		// Crawl!
		ERSV_Crawl('./');
		
		db_query('DELETE FROM `ersv_files` WHERE `checked` = "0"');
		break;
		
	default:
		rawoutput('<h2>'.ERSV_NAME.' '.ERSV_VERSION.' >> Editor</h2>
		
		<p>Willkommen im Editor f�r den '.ERSV_NAME.'. Hier kannst du Dateien blockieren oder erlauben, je nach dem, was deine Spieleinstellungen so erz�hlen. Im folgenden die aktuellen Einstellungen aufgelistet; In den Spieleinstellungen kannst du sie einstellen:</p>
		
		<dl style="margin: 2em 1em;">
			<dt style="font-weight: bold; color: #0b0">Standardstatus bei neuen Dateien</dt>
			<dd style="font-style: italic; color: #ee0">'.ERSV_DEFFILESTAT.'</dd>
			
			<dt style="font-weight: bold; color: #0b0">Neue Verzeichnisse automatisch "offen":</dt>
			<dd style="font-style: italic; color: #ee0">'.(ERSV_DEFDIRSTAT == 0 ? 'Nein' : 'Ja').'</dd>
			
			<dt style="font-weight: bold; color: #0b0">Dateitypen, die eingetragen werden sollen:</dt>
			<dd style="font-style: italic; color: #ee0">'.ERSV_FILETYPES .'</dd>
			
			<dt style="font-weight: bold; color: #0b0">Autocrawlen jede Stunde:</dt>
			<dd style="font-style: italic; color: #ee0">'.(ERSV_AUTOCRAWL == 0 ? 'Nein' : 'Ja').'</dd>
			
			<dt style="font-weight: bold; color: #0b0">Letztes Crawlen:</dt>
			<dd style="font-style: italic; color: #ee0">'.(date('Y.m.d H:i:s', getsetting('ERSV_LASTCRAWL', '0'))).'</dd>
		</dl>
		
		<p>Erkl�rungen zu den M�glichkeiten:</p>
		
		<dl>
			<dt style="font-weight: bold; color: #0b0">Verzeichnisse verwalten</dt>
			<dd>Hier kannst du die Verzeichnisse, welche die Spinne findet, deaktivieren, respektive aktivieren.</dd>
			
			<dt style="font-weight: bold; color: #0b0">Dateien verwalten</dt>
			<dd>Dateien, welche die Spinne gefunden hat und dem eingestellten Suchmuster entsprechen werden in einer Tabelle gesammelt und sind sofort in der Source verf�gbar. Hier kannst du die Dateien einzeln bearbeiten, sie sperren, verstecken oder sonstwas mit ihnen tun.</dd>
			
			<dt style="font-weight: bold; color: #0b0">Dateitabelle aktualisieren</dt>
			<dd>Hier kannst du die Verzeichnisse, welche die Spinne findet, deaktivieren, respektive aktivieren.</dd>
		</dl>');
		break;
}


page_footer();
?>