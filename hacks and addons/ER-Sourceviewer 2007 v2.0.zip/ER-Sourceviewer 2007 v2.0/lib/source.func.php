<?php 
/*
	A mod from "Basilius-Extensions"
	ER-Sourceviewer 2007 v2.0
	2007 by Basilius "Wasili" Sauter
*/

// ERSV-Functions

function ERSV_GetSizeString($size) {
	// Anzeige in Bin�rzeichen
	if($size < 1024) {
		return $size.' bytes';
	}
	elseif($size < 1024*1024) {
		//$KiB = floor($size/1024);
		//$Bytes = $size - $KiB * 1024;
		$KiB = $size/1024;
		$KiB = round($KiB, 2);
		$KiB = number_format($KiB, 2, ',', '\'');
		
		return $KiB.' KiB';
	}
	else {
		$MiB = $size/1024/1024;
		$MiB = round($KiB, 2);
		$MiB = number_format($MiB, 2, ',', '\'');
		
		return $MiB.' MiB';
	}
}


function ERSV_Crawl($dir) {
	$filetypes = explode('|', ERSV_FILETYPES);
	
	// Check die Datenbank auf vorhandensein
	$res = db_query('SELECT `dirid` FROM `ersv_dirs` WHERE `dirname` = "'.mysql_escape_string($dir).'"');
	if(db_num_rows($res) === 0) {
		db_query('INSERT INTO `ersv_dirs` (`dirname`, `allowed`) VALUES ("'.mysql_escape_string($dir).'", "'.ERSV_DEFDIRSTAT.'")');
		$dirID = db_insert_id();
	}
	else {
		$row = db_fetch_assoc($res);
		$dirID = $row['dirid'];
	}
	
	$d = dir($dir);
	
	while (false !== ($entry = $d->read())) {
		// dotfiles ausblenden
		if(substr($entry, 0, 1) != '.') {
			if(is_dir($entry)) {
				// Crawl!
				ERSV_Crawl($dir.$entry.'/');
			}
			elseif(is_file($dir.$entry)) {
				// Dateityp intressant?
				$lastdot = strrpos($entry, '.');
				$ext = substr($entry, $lastdot);
				if(array_search($ext, $filetypes) !== false) {
					// Gibts dat file schon inner DB?
					$completfilename = $dir.$entry;
					// print $completfilename;
					$entry = basename($entry);
					$res = db_query('SELECT `fileid` FROM `ersv_files` WHERE `dirid` = "'.$dirID.'" AND `filename` = "'.mysql_escape_string($entry).'"');
					if(db_num_rows($res) === 0) {
						// Datei gibbets net
						db_query('INSERT INTO `ersv_files` (`dirid`, `filename`, `status`, `size`, `cdate`, `checked`) VALUES ('.$dirID.', "'.mysql_escape_string($entry).'", "'.ERSV_DEFFILESTAT.'", "'.filesize($completfilename).'", "'.date('Y-m-d h:i:s', filectime($completfilename)).'", "1")');
					}
					else {
						// Datei gibbets ^^
						db_query('UPDATE `ersv_files` SET `size` = "'.filesize($completfilename).'", `cdate` =  "'.date('Y-m-d h:i:s', filectime($completfilename)).'", checked= "1" WHERE `dirid` = "'.$dirID.'" AND `filename` = "'.mysql_escape_string($entry).'"');
					}
				}
			}
		}
	}
}

define('ERSV_NAME', 'ER-Sourceviewer 2007');
define('ERSV_VERSION', 'v2.0');

define('ERSV_AUTOCRAWL', getsetting('ERSV_AUTOCRAWL', 1));
define('ERSV_LASTCRAWL', date('YmdH', intval(getsetting('ERSV_LASTCRAWL', '0000000000'))));
define('ERSV_NOW', date('YmdH'));

?>