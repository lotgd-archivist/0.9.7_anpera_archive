<?php
//This file automatically created by installer.php on Nov 10, 2012 10:02 pm
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = 'password';
$DB_NAME = 'elvenhall';
$DB_PREFIX = 'free_';
$DB_USEDATACACHE = 1;
$DB_DATACACHEPATH = '/var/www/Improbable-Island/cache';
?>
