This is a git repository based off the Dragonprime game engine, for the game Improbable Island.


Improbable Island is a PBORPG by Dan Hall, aka Caveman Joe (http://www.improbableisland.com)

Legend of the Green Dragon
by  Eric "MightyE" Stevens (http://www.mightye.org)
and JT "Kendaer" Traub (http://www.dragoncat.net)

Software Project Page for orginal engine:
http://sourceforge.net/projects/lotgd

Modification AND Support Community Page:
http://dragonprime.net


Primary game servers for Legend of the Green Dragon:
http://lotgd.net
http://logd.dragoncat.net

For a new installation or upgrading , see the INSTALLATION.txt. If you want a fully supported, stable engine visit Dragonprime at the address above.

This repository, and all files contained within are under the Creative Commons Non-Commerical Share-Alike License. For full leagal terms, see http://creativecommons.org/licenses/by-nc-sa/2.0/legalcode. For a briefer explanation of the license and why is was chosen, see LICENSE.txt
