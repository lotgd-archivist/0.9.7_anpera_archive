<?php
$setindex = 3;
$setname = "Set 3";
$setcopy = "&copy; 2005 <a href='http://wits.deviantart.com'>Whitney Spencer</a>"
?>
