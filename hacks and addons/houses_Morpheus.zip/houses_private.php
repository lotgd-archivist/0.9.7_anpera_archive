<?php 
// Name: houses_private.php 
// Autor: tcb / Talion f�r http://lotgd.drachenserver.de (mail: t@ssilo.de) 
// Erstellungsdatum: 9.5.05 
// Erfordert Mods in Dateien: houses.php, suhouses.php 
// Beschreibung: 
//        Erweiterung, die Privatr�ume in H�usern erm�glicht. Zutritt haben dort nur der Hausbesitzer und von ihm autorisierte Personen 
//        Mit Chatarea 
//         Info, ob bestimmter Schl�sselbesitzer hier rein darf, wird in value2 des Schl�ssels gespeichert.. bisherige Funktion war leicht unn�tig :) 
// �nderungen: 
//         11.5.05: tcb:     Systemmails eingebaut 
//                        Umstellung auf value2 System 
//        23.5.05: tcb:    Sicherungskopie der Kommentare beim L�schen 

require_once("common.php"); 
page_header("Privatgem�cher"); 

addcommentary(); 

checkday(); 

is_new_day(); 

if(!isset($session['housekey'])) {redirect("houses.php");} 

$op = (isset($_GET['op'])) ? $_GET['op'] : ''; 

switch($op) { 

    case '':    // Chat anzeigen 

        output("`2`b`cPrivatgem�cher`b`c`n"); 

        output('Durch eine breite, aber immer gut verschlossene T�r im hinteren Teil des Hauses gelangst du in '.(($session['user']['house']==$session['housekey'])?'deine Privatgem�cher':'die Privatgem�cher des Hausherrn').'. Hier kannst du dich mit den anderen Hausbewohnern austauschen, die einen Schl�ssel zu diesem Raum besitzen:`n`n`n'); 

	//if (getsetting('activategamedate','0')==1) output("`qWir schreiben den `^".getgamedate()."`q im Zeitalter des Drachen.`n");
	output("Die Uhr am Kamin zeigt `^".getgametime()."`2 Uhr und drau�en ist es heute `^".$settings['weather']."`2.`0");
	//output("Drau�en ist es heute `^".$settings['weather']."`q.`0");

        viewcommentary('house-'.$session['housekey'].'_private',"Mit Mitbewohnern reden:",30,"sagt"); 

        output("`n`n`n`2`bZutritt haben:`b `0",true); 

        $sql = "SELECT items.*,accounts.acctid AS aid,accounts.name AS besitzer FROM items LEFT JOIN accounts ON accounts.acctid=items.owner WHERE value1=".$session['housekey']." AND items.class='Schl�ssel' AND value2=999 ORDER BY id ASC"; 

        $result = db_query($sql) or die(db_error(LINK)); 

        for ($i=1;$i<=db_num_rows($result);$i++){ 

            $item = db_fetch_assoc($result); 

            output("`n`2".$i.": `&$item[besitzer]`0"); 

        } 

        if ($session['user']['house']==$session['housekey']) { 

            addnav("Aktionen"); 

            addnav("Einladen","houses_private.php?op=geben"); 
            addnav("Ausladen","houses_private.php?op=nehmen"); 
            addnav("Aufr�umen","houses_private.php?op=sauber"); 
        } 

        addnav("Verschiedenes"); 

        addnav("Log Out","houses.php?op=drin&act=logout"); 

        addnav("Zur�ck zum Haus","houses.php?op=drin"); 
        //addnav("Zum Wohnviertel","houses.php"); 
        //addnav("Zum Dorf","village.php"); 
        break; 

    case 'geben':    // Person autorisieren 

        $sql = "SELECT a.name, i.id AS itemid FROM items i LEFT JOIN accounts a ON a.acctid=i.owner WHERE i.class='Schl�ssel' AND i.owner!=".$session['user']['acctid']." AND i.value1=".$session['housekey']." AND i.value2!=999 GROUP BY i.owner ORDER BY a.name"; 
        $res = db_query($sql); 

        if(!db_num_rows($res)) { 
            output("`2Es gibt keine Personen, denen du Zugang gew�hren k�nntest!"); 
        } 
        else { 

            output("<form action='houses_private.php?op=geben_ok' method='POST'>",true); 

            output("`2Wem willst du Zugang zu deinen Privatgem�chern gew�hren? <select name='ziel'>",true); 

            while ( $p = db_fetch_assoc($res) ) { 

                output("<option value=\"".$p['itemid']."\">".preg_replace("'[`].'","",$p['name'])."</option>",true); 

            } 

            output("</select>`n`n",true); 

            output("<input type='submit' class='button' value='Einladen'></form>",true); 
            addnav("","houses_private.php?op=geben_ok"); 
        } 

        addnav("Zur�ck","houses_private.php"); 

        break; 

    case 'geben_ok':    // Person autorisieren 2 

        $ziel = (int)$_POST['ziel']; 

        if($ziel) { 

            $sql = "SELECT i.owner, a.name, i.value2 FROM items i, accounts a WHERE a.acctid=i.owner AND i.id=".$ziel; 
            $res = db_query($sql); 
            $p = db_fetch_assoc($res); 

            if( $p['value2'] == 999 ) { 
                output("`2".$p['name']."`2 hat schon Zugang zu deinen Privatgem�chern!"); 
                addnav("Zur�ck","houses_private.php?op=geben"); 
            } 
            else { 
                $sql = "UPDATE items SET value2=999 WHERE id=".$ziel; 
                db_query($sql) or die (db_error(LINK)); 

                systemmail($p['owner'],"`@Zugang zu Privatgem�chern erhalten!`0","`&{$session['user']['name']}`& hat dir einen Schl�ssel zu ".(($session['user']['sex'])?"ihren":"seinen")." Privatgem�chern �bergeben!`nEin gro�er Vertrauensbeweis, also entt�usch ".(($session['user']['sex'])?"sie":"ihn")." nicht!"); 

                output("`2Du �bergibst ".$p['name']." `2einen Schl�ssel zu deinen privaten R�umen."); 

                addnav("Zur�ck","houses_private.php"); 
            } 
        } 

        else { 
            redirect("houses_private.php?op=geben"); 
        } 

        break; 

    case 'nehmen':    // Person ausladen 

        $sql = "SELECT a.name, i.id AS itemid FROM items i LEFT JOIN accounts a ON a.acctid=i.owner WHERE i.class='Schl�ssel' AND i.value1=".$session['housekey']." AND i.value2=999 ORDER BY a.name"; 
        $res = db_query($sql); 

        if(!db_num_rows($res)) { 
            output("`2Es hat noch niemand Zugang zu deinen Privatgem�chern!"); 
        } 
        else { 

            output("<form action='houses_private.php?op=nehmen_ok' method='POST'>",true); 

            output("`2Wem willst du den Zugang zu deinen Privatgem�chern entziehen? <select name='ziel'>",true); 

            while ( $p = db_fetch_assoc($res) ) { 

                output("<option value=\"".$p['itemid']."\">".preg_replace("'[`].'","",$p['name'])."</option>",true); 

            } 

            output("</select>`n`n",true); 

            output("<input type='submit' class='button' value='Ausladen'></form>",true); 
            addnav("","houses_private.php?op=nehmen_ok"); 
        } 

        addnav("Zur�ck","houses_private.php"); 

        break; 

    case 'nehmen_ok':    // Person ausladen 2 

        $ziel = (int)$_POST['ziel']; 

        if($ziel) { 

            $sql = "SELECT i.owner, a.name, i.value2 FROM items i, accounts a WHERE a.acctid=i.owner AND i.id=".$ziel; 
            $res = db_query($sql); 
            $p = db_fetch_assoc($res); 

            $sql = "UPDATE items SET value2=0 WHERE id=".$ziel; 
            db_query($sql) or die (db_error(LINK)); 

            systemmail($p['owner'],"`@Zugang zu Privatgem�chern entzogen!`0","`&{$session['user']['name']}`& hat dir den Schl�ssel zu ".(($session['user']['sex'])?"ihren":"seinen")." Privatgem�chern wieder abgenommen."); 

            output("`2Du nimmst ".$p['name']." `2den Schl�ssel zu deinen privaten R�umen wieder ab!"); 

            addnav("Zur�ck","houses_private.php"); 

        } 

        else { 
            redirect("houses_private.php?op=nehmen"); 
        } 

        break; 

    case 'sauber':    // Kommentare entfernen 

        output("`2Du entschlie�t dich, in deinen Privatgem�chern etwas aufzur�umen. Doch sei dir dar�ber im Klaren, dass dann alle Ereignisse der letzten Zeit hier drin in Vergessenheit geraten!"); 

        addnav("Ja, aufr�umen!","houses_private.php?op=sauber_ok"); 
        addnav("Nein, zur�ck!","houses_private.php"); 

        break; 

    case 'sauber_ok':    // Kommentare entfernen 2 

        // Sicherung 
        $sql = "UPDATE commentary SET section='house-".$session['housekey']."_p' WHERE section='house-".$session['housekey']."_private'"; 
        db_query($sql); 
        // Sicherung Ende 

        //$sql = "DELETE FROM commentary WHERE section='house-".$session['housekey']."_private'"; 
        //db_query($sql) or die (db_error(LINK)); 
        redirect("houses_private.php"); 

        break; 

    default: 
        output('Hier d�rfte ich nicht sein.. op: '.$op); 
        addnav("Zur�ck","village.php"); 
        break; 
} 

page_footer(); 

// END houses_private.php 
?>