<?php

// 08092004

/*
* Author:	anpera
* Email:		logd@anpera.de
* 
* Purpose:	Houses for storing gold and gems and for a save place to sleep (logout)
*		
* Features:	Build house, sell house, buy house, share house with others, private chat-area, PvP
*
* Every warrior can have his own house. He can build it with his own hands or buy one that was sold (or left) before.
* In a house he can store some of his gems and gold and houses are the savest place for log out.
* The player can give keys to other players. So he is able to share his gems and gold for example
* with his wife or he can make up a clan house. A player can only have one house but unlimited keys.
* Each house has its own private chat area. 
* Other players can rob a house if they beat the guard and all players that are sleeping in the house.
*
*
* SEE  INSTRUCTIONS  FOR  INSTALLATION  AT  http://www.anpera.net/forum/viewtopic.php?t=323
* English translation available at DragonPrime
*
* Added furniture 05/25/2004
*  (Buy at vendor - vendor.php)
* Added Durandil's hidden path 05/30/2004
*
* Ok, lets do the code...
*/

	
require_once("common.php");
addcommentary();
checkday();

// base values for pricing and chest size:
$goldcost=30000;
$gemcost=50;
// all other values are controlled by banksettings

//not needed v
if ($session[user][slainby]!=""){
	page_header("Du wurdest besiegt!");
		output("`\$Du wurdest in ".$session[user][killedin]."`\$ von `%".$session[user][slainby]."`\$ besiegt und um alles Gold beraubt, das du bei dir hattest. Das kostet dich 5% deiner Erfahrung. Meinst du nicht es ist Zeit f�r Rache?");
	addnav("Weiter",$REQUEST_URI);
	$session[user][slainby]="";
	$session['user']['donation']+=1;
	page_footer();
}
// ^

page_header("Das Wohnviertel");

if ($_GET[op]=="newday"){
	output("`n`2Gut erholt wachst du im Haus auf und bist bereit f�r neue Abenteuer.");
	$session[user][location]=0;
	$sql = "UPDATE items SET hvalue=0 WHERE hvalue>0 AND owner=".$session[user][acctid]." AND class='Schl�ssel'";
	db_query($sql) or die(sql_error($sql));
	//addnav("T�gliche News","news.php");
	addnav("W?Zum Wohnviertel","houses.php");
	addnav("S?Zum Stadtplatz","village.php");
}else if ($_GET[op]=="bio"){
	if (!$_GET[id]) redirect("houses.php");
	$sql="SELECT houses.*,accounts.name AS besitzer FROM houses LEFT JOIN accounts ON accounts.acctid=houses.owner WHERE houseid=$_GET[id]";
	$result = db_query($sql) or die(db_error(LINK));
	$row = db_fetch_assoc($result);
	output("`c`b`6Infos �ber Haus Nummer $row[houseid]`b`c`n`n`2Du n�herst dich Haus Nummer $row[houseid], um es aus der N�he zu betrachten. ");
	if($row[description]){
		output("�ber dem Eingang  von $row[housename]`2 steht geschrieben:`n`& $row[description]`n`n");
	}else{
		output("Das Haus tr�gt den Namen \"`&$row[housename]`2\".`n");
	}
	$sql="SELECT * FROM items WHERE class='M�bel' AND value1={$_GET['id']} ORDER BY id ASC";
	$result = db_query($sql);
	if ($row[besitzer]=="") $row[besitzer]="niemandem";
	output("`2Das Haus geh�rt `^$row[besitzer]`2 und ist ");
	if ($row[status]==0) output("noch im Bau. ");
	if ($row[status]==1) output("bewohnt. ");
	if ($row[status]==2) output("zum Verkauf angeboten. ");
	if ($row[status]==3) output("verlassen. ");
	if ($row[status]==4) output("eine Bauruine. ");
	output("`2Du riskierst einen Blick durch eines der Fenster");
	if (db_num_rows($result)>0){
		output(" und erkennst ");
		for ($i=0;$i<db_num_rows($result);$i++){
			$row2 = db_fetch_assoc($result);
			output("`@$row2[name]");
			if($i+1<db_num_rows($result)) output(", ");
		}
		output(".`n");
	}else{
		output(", aber das Haus hat sonst nichts weiter zu bieten.");
	}
	if (getsetting("dailyspecial",0)=="Waldsee"){
		output("`n`n`6W�hrend du dir das Haus genau ansiehst, f�llt dir ein kleiner Trampelpfad auf...");
		addnav("Trampelpfad","paths.php?ziel=forestlake");
	}
	if ($_GET[id]==$session[user][housekey]) addnav("Haus betreten","houses.php?op=drin&id=$_GET[id]");
	addnav("Zur�ck","houses.php");
}else if ($_GET[op]=="build"){
	if ($_GET[act]=="start") {
		$sql = "INSERT INTO houses (owner,status,gold,gems,housename) VALUES (".$session[user][acctid].",0,0,0,'".$session[user][login]."s Haus')";
		db_query($sql) or die(db_error(LINK));
		if (db_affected_rows(LINK)<=0) redirect("houses.php");
		$sql = "SELECT * FROM houses WHERE status=0 AND owner=".$session[user][acctid]." ORDER BY houseid DESC";
		$result = db_query($sql) or die(db_error(LINK));
		$row = db_fetch_assoc($result);
		$session[user][house]=$row[houseid];
		output("`n`6Du erkl�rst das Fleckchen Erde zu deinem Besitz und kannst mit dem Bau von Hausnummer `^$row[houseid]`6 beginnen.`n`n");
		output("`0<form action=\"houses.php?op=build&act=build2\" method='POST'>",true);
		output("`nGebe einen Namen f�r dein Haus ein: <input name='housename' maxlength='25'>`n",true);
		output("`nWieviel Gold anzahlen? <input type='gold' name='gold'>`n",true);
		output("`nWieviele Edelsteine? <input type='gems' name='gems'>`n",true);
		output("`n<input type='submit' class='button' value='Bauen'>",true);
		addnav("","houses.php?op=build&act=build2");
	}else if ($_GET[act]=="build2") {
		$sql = "SELECT * FROM houses WHERE status=0 AND owner=".$session[user][acctid]." ORDER BY houseid DESC";
		$result = db_query($sql) or die(db_error(LINK));
		$row = db_fetch_assoc($result);
		$paidgold=(int)$_POST['gold'];
		if ($_POST['housename']>""){
			$housename=stripslashes($_POST['housename']);
		}else{
			$housename=stripslashes($row[housename]);
		}
		$paidgems=(int)$_POST['gems'];
		if ($session[user][gold]<$paidgold || $session[user][gems]<$paidgems) {
			output("`n`6Du hast nicht genug dabei!");
			addnav("Nochmal","houses.php?op=build");
		} else if ($session[user][turns]<1){
			output("`n`6Du bist zu m�de, um heute noch an deinem Haus zu arbeiten!");
		} else if ($paidgold<0 || $paidgems<0){
			output("`n`6Versuch hier besser nicht zu beschummeln.");
		} else {
			output("`n`6Du baust f�r `^$paidgold`6 Gold und `#$paidgems`6 Edelsteine an deinem Haus \"`&$housename`6\"...`n");
			$row[gold]+=$paidgold;
			$session[user][gold]-=$paidgold;
			output("`nDu verlierst einen Waldkampf.");
			$session[user][turns]--;
			if ($row[gold]>$goldcost) {
				output("`nDu hast die kompletten Goldkosten bezahlt und bekommst das �bersch�ssige Gold zur�ck.");
				$session[user][gold]+=$row[gold]-$goldcost;
				$row[gold]=$goldcost;
			}
			$row[gems]+=$paidgems;
			$session[user][gems]-=$paidgems;
			if ($row[gems]>$gemcost) {
				output("`nDu hast die kompletten Edelsteinkosten bezahlt und bekommst �bersch�ssige Edelsteine zur�ck.");
				$session[user][gems]+=$row[gems]-$gemcost;
				$row[gems]=$gemcost;
			}
			$goldtopay=$goldcost-$row[gold];
			$gemstopay=$gemcost-$row[gems];
			$done=round(100-((100*$goldtopay/$goldcost)+(100*$gemstopay/$gemcost))/2);
			output("`n`nDein Haus ist damit zu `\$$done%`6 fertig.`nDu musst noch `^$goldtopay`6 Gold und `#$gemstopay `6Edelsteine bezahlen, bis du einziehen kannst.");
			if ($row[gems]>=$gemcost && $row[gold]>=$goldcost) {
				output("`n`n`^`bGl�ckwunsch!`b `6Dein Haus ist fertig. Du bekommst `^`b10`b `6Schl�ssel �berreicht, von denen du 9 an andere weitergeben kannst, und besitzt nun deine eigene kleine Burg.");
				$row[gems]=0;
				$row[gold]=0;
				$session[user][housekey]=$row[houseid];
				$row[status]=1;
				addnews("`2".$session[user][name]."`3 hat das Haus `2$row[housename]`3 fertiggestellt.");
				//$sql="";
				for ($i=1;$i<10;$i++){
					$sql = "INSERT INTO items (name,owner,class,value1,value2,gold,gems,description) VALUES ('Hausschl�ssel',".$session[user][acctid].",'Schl�ssel',$row[houseid],$i,0,0,'Schl�ssel f�r Haus Nummer $row[houseid]')";
					db_query($sql);
					if (db_affected_rows(LINK)<=0) output("`\$Fehler`^: Dein Inventar konnte nicht aktualisiert werden! Bitte benachrichtige den Admin. ");
				}
			}
			$sql = "UPDATE houses SET gold=$row[gold],gems=$row[gems],housename='".addslashes($housename)."',status=".(int)$row[status]." WHERE houseid=$row[houseid]";
			db_query($sql);
		}
	} else {
		if ($session[user][housekey]>0) {
			output("`n`6Du hast bereits Zugang zu einem fertigen Haus und brauchst kein zweites. Wenn du ein neues oder ein eigenes Haus bauen willst, musst du erst aus deinem jetzigen Zuhause ausziehen.");
		} else if ($session[user][dragonkills]<1 || ($session[user][dragonkills]==1 && $session[user][level]<5)) {
			output("`6`nDu hast noch nicht genug Erfahrung, um ein eigenes Haus bauen zu k�nnen. Du kannst aber bei einem Freund einziehen, wenn er dir einen Schl�ssel f�r sein Haus gibt.");
		} else if ($session[user][turns]<1) {
			output("`n`6Du bist zu ersch�pft, um heute noch irgendetwas zu bauen. Warte bis morgen.");
		} else if ($session[user][house]>0) {
			$sql = "SELECT * FROM houses WHERE status=0 AND owner=".$session[user][acctid]." ORDER BY houseid DESC";
			$result = db_query($sql) or die(db_error(LINK));
			$row = db_fetch_assoc($result);
			output("`n`6Du besichtigst die Baustelle deines neuen Hauses mit der Hausnummer `^$row[houseid]`6.`n`n");
			$goldtopay=$goldcost-$row[gold];
			$gemstopay=$gemcost-$row[gems];
			$done=round(100-((100*$goldtopay/$goldcost)+(100*$gemstopay/$gemcost))/2);
			output(grafbar(100,$done,"100%",20),true);
			output("`nEs ist zu `\$$done%`6 fertig.`nDu musst noch `^$goldtopay`6 Gold und `#$gemstopay `6Edelsteine bezahlen.`n`n`^Willst du jetzt weiter bauen?`6`n`n");
			output("`0<form action=\"houses.php?op=build&act=build2\" method='POST'>",true);
			output("`nWieviel Gold zahlen? <input type='gold' name='gold'>`n",true);
			output("`nWieviele Edelsteine? <input type='gems' name='gems'>`n",true);
			output("`n<input type='submit' class='button' value='Bauen'>",true);
			addnav("","houses.php?op=build&act=build2");
		} else {
			output("`n`6Du siehst ein sch�nes Fleckchen f�r ein Haus und �berlegst dir, ob du nicht selbst eines bauen solltest, anstatt ein vorhandenes zu kaufen oder noch l�nger in Kneipe und Feldern zu �bernachten.");
			output(" Ein Haus zu bauen w�rde dich `^$goldcost Gold`6 und `#$gemcost Edelsteine`6 kosten. Du mu�t das nicht auf einmal bezahlen, sondern k�nntest immer wieder mal f�r einen kleineren Betrag ein St�ck ");
			output("weiter bauen. Wie schnell du zu deinem Haus kommst, h�ngt also davon ab, wie oft und wieviel du bezahlst.`n");
			output("Du kannst in deinem zuk�nftigen Haus alleine wohnen, oder es mit anderen teilen. Es bietet einen sicheren Platz zum �bernachten und einen Lagerplatz f�r einen Teil deiner Reicht�mer.");
			output(" Ein gestartetes Bauvorhaben kann nicht abgebrochen werden.`n`n`^Willst du mit dem Hausbau beginnen?`6");
			addnav("Hausbau beginnen","houses.php?op=build&act=start");
		}
	}
	addnav("W?Zum Wohnviertel","houses.php");
	addnav("S?Zum Stadtplatz","village.php");
}else if ($_GET[op]=="einbruch"){
	if (!$_GET[id]){
		if ($_POST['search']>"" || $_GET['search']>""){
			if ($_GET['search']>"") $_POST['search']=$_GET['search'];
			if (strcspn($_POST['search'],"0123456789")<=1){
				$search="houseid=".intval($_POST[search])." AND ";
			}else{
				$search="%";
				for ($x=0;$x<strlen($_POST['search']);$x++){
					$search .= substr($_POST['search'],$x,1)."%";
				}
				$search="housename LIKE '".$search."' AND ";
			}
		}else{
			$search="";
		}
		$ppp=25; // Player Per Page to display
		if (!$_GET[limit]){
			$page=0;
		}else{
			$page=(int)$_GET[limit];
			addnav("Vorherige Strasse","houses.php?op=einbruch&limit=".($page-1)."&search=$_POST[search]");
		}
		$limit="".($page*$ppp).",".($ppp+1);
		$sql = "SELECT * FROM houses WHERE $search status=1 AND owner<>".$session[user][acctid]." ORDER BY houseid ASC LIMIT $limit";
		output("`c`b`^Einbruch`b`c`0`n");
		output("`6Du siehst dich um und suchst dir ein bewohntes Haus f�r einen Einbruch aus. ");
		output("Leider kannst du nicht erkennen, wieviele Bewohner sich gerade darin aufhalten und wie stark diese sind. So ein Einbruch ist also sehr riskant. F�r welches Haus entscheidest du dich?`n`n");
		output("<form action='houses.php?op=einbruch' method='POST'>Nach Hausname oder Nummer <input name='search' value='$_POST[search]'> <input type='submit' class='button' value='Suchen'></form>",true);
		addnav("","houses.php?op=einbruch");
		if ($session['user']['pvpflag']=="5013-10-06 00:42:00") output("`n`&(Du hast PvP-Immunit�t gekauft. Diese verf�llt, wenn du jetzt angreifst!)`0`n`n");
		output("<table cellspacing=0 cellpadding=2 align='center'><tr><td>`bHausNr.`b</td><td>`bName`b</td><td>`bEigent�mer`b</td></tr>",true);
		$result = db_query($sql) or die(db_error(LINK));
		if (db_num_rows($result)>$ppp) addnav("N�chste Strasse","houses.php?op=einbruch&limit=".($page+1)."&search=$_POST[search]");
		if (db_num_rows($result)==0){
  			output("<tr><td colspan=4 align='center'>`&`iEs gibt momentan keine bewohnten H�user`i`0</td></tr>",true);
		}else{
			for ($i=0;$i<db_num_rows($result);$i++){
	  			$row = db_fetch_assoc($result);
				$bgcolor=($i%2==1?"trlight":"trdark");
				output("<tr class='$bgcolor'><td align='right'>$row[houseid]</td><td><a href='houses.php?op=einbruch&id=$row[houseid]'>$row[housename]</a></td><td>",true);
				$sql = "SELECT name FROM accounts WHERE acctid=$row[owner] ORDER BY acctid DESC";
			 	$result2 = db_query($sql) or die(db_error(LINK));
				$row2 = db_fetch_assoc($result2);
				output("$row2[name]</td></tr>",true);
				addnav("","houses.php?op=einbruch&id=$row[houseid]");
			}
		}
		output("</table>",true);
		addnav("Umkehren","houses.php");
	}else{
		if ($session[user][turns]<1 || $session[user][playerfights]<=0){
			output("`nDu bist wirklich schon zu m�de, um ein Haus zu �berfallen.");
			addnav("Zur�ck","houses.php");
		}else{
			output("`2Du n�herst dich vorsichtig Haus Nummer $_GET[id].");
			$session[housekey]=$_GET[id];
			// Abfrage, ob Schl�ssel vorhanden!!
			$sql = "SELECT id FROM items WHERE owner=".$session[user][acctid]." AND class='Schl�ssel' AND value1=".(int)$_GET[id]." ORDER BY id DESC";
			$result2 = db_query($sql) or die(db_error(LINK));
			$row2 = db_fetch_assoc($result2);
			if (db_num_rows($result2)>0) {
				output(" An der Haust�r angekommen suchst du etwas, um die T�r m�glichst unauff�llig zu �ffnen. Am besten d�rfte daf�r der Hausschl�ssel geeignet sein, ");
				output(" den du einstecken hast.`nWolltest du wirklich gerade in ein Haus einbrechen, f�r das du einen Schl�ssel hast?");
				addnav("Haus betreten","houses.php?op=drin&id=$_GET[id]");
				addnav("S?Zum Stadtplatz","village.php");
			} else {
				// Wache besiegen
				output("Deine geb�ckte Haltung und der schleichende Gang machen eine Stadtwache aufmerksam...`n");
				$pvptime = getsetting("pvptimeout",600);
				$pvptimeout = date("Y-m-d H:i:s",strtotime(date("r")."-$pvptime seconds"));
				$days = getsetting("pvpimmunity", 5);
				$exp = getsetting("pvpminexp", 1500);
				$sql = "SELECT acctid,level,maxhitpoints,login,housekey FROM accounts WHERE 
				(locked=0) AND 
				(alive=1 AND location=2) AND 
				(laston < '".date("Y-m-d H:i:s",strtotime(date("r")."-".getsetting("LOGINTIMEOUT",900)." sec"))."' OR loggedin=0) AND
				(age > $days OR dragonkills > 0 OR pk > 0 OR experience > $exp) AND
				(acctid <> ".$session[user][acctid].") AND 
				(pvpflag <> '5013-10-06 00:42:00') AND 
				(pvpflag < '$pvptimeout') ORDER BY maxhitpoints DESC";
				$result = db_query($sql) or die(db_error(LINK));
				$hp=0;
				$count=0;
				// count chars at home and find strongest
				if(db_num_rows($result)){
					for ($i=0;$i<db_num_rows($result);$i++){
						$row = db_fetch_assoc($result);
						$sql = "SELECT value1 FROM items WHERE value1=".(int)$session[housekey]." AND owner=$row[acctid] AND class='Schl�ssel' AND hvalue=".(int)$session[housekey]." ORDER BY id";
						$result2 = db_query($sql) or die(db_error(LINK));
						if (db_num_rows($result2)>0 || ((int)$row[housekey]==(int)$session[housekey] && 0==db_num_rows(db_query("SELECT hvalue FROM items WHERE hvalue<>0 AND class='Schl�ssel' AND value1<>$session[housekey] AND owner=$row[acctid]")))){
							if ($row[maxhitpoints]>$hp){
								$hp=(int)$row[maxhitpoints];
								$count++;
							}
						}
						db_free_result($result2);
					}
				}
				if ($count>0){
					$badguy = array("creaturename"=>"Stadtwache","creaturelevel"=>$session[user][level],"creatureweapon"=>"Holzkn�ppel","creatureattack"=>$session[user][attack],"creaturedefense"=>$session[user][defence],"creaturehealth"=>abs($session[user][maxhitpoints]-$hp)+1, "diddamage"=>0);
				}else{
					$badguy = array("creaturename"=>"Stadtwache","creaturelevel"=>$session[user][level],"creatureweapon"=>"starker Holzkn�ppel","creatureattack"=>$session[user][attack],"creaturedefense"=>$session[user][defence],"creaturehealth"=>abs(max($session[user][maxhitpoints], $session[user][hitpoints])), "diddamage"=>0);
					$session[user][playerfights]--;
					$session[user][reputation]-=7;
				} 
				$session[user][badguy]=createstring($badguy); 
				$fight=true;
			}
		}
	} 
}elseif ($_GET['op'] == "fight") { 
	$fight=true; 
} elseif ($_GET['op'] == "run") { 
	//output("`%Die Wache l�sst dich nicht entkommen!`n");
	//$session[user][reputation]--;
	//$fight=true; 
	$badguy = createarray($session['user']['badguy']);
	// fight against guard
	if ($badguy['creaturename']=='Stadtwache') {
		output("`%Die Wache l�sst dich nicht entkommen!`n");
		$session[user][reputation]--;
	}
	// fight against pet
	else {
		output("`%".$badguy['creaturename']."`% l�sst dich nicht entkommen!`n");
	}
	$fight=true;
}else if ($_GET[op]=="einbruch2"){
	$badguy = createarray($session['user']['badguy']);
	$fightpet = false;
	// check for pet
	if ($badguy['creaturename']=='Stadtwache') {
		$sql = 'SELECT accounts.petid AS pet, items.name, items.buff FROM accounts LEFT JOIN items ON accounts.petid=items.id WHERE accounts.house='.$session['housekey'].' AND accounts.petfeed > NOW()';
		$result = db_query($sql);
		if ($row = db_fetch_assoc($result)) {
			if ($row['pet']>0) {
				$petbuff = unserialize($row['buff']);
				$badguy = array('creaturename'=>$row['name'],
									'creaturelevel'=>$session['user']['level'],
									'creatureweapon'=>$petbuff['name'],
									'creatureattack'=>$petbuff['atkmod'],
									'creaturedefense'=>$petbuff['defmod'],
									'creaturehealth'=>$petbuff['regen'],
									'diddamage'=>0);
				$session['user']['badguy'] = createstring($badguy);
				$fight = $fightpet = true;
				output('`$Gerade willst du ins Haus schleichen, als du hinter dir pl�tzlich ein Knurren vernimmst.`0`n');
			}
		}
	}

	if (!$fightpet) {
	// Spieler besiegen
	$pvptime = getsetting("pvptimeout",600);
	$pvptimeout = date("Y-m-d H:i:s",strtotime(date("r")."-$pvptime seconds"));
	$days = getsetting("pvpimmunity", 5);
	$exp = getsetting("pvpminexp", 1500);
	$sql = "SELECT acctid,name,maxhitpoints,defence,attack,level,laston,loggedin,login,housekey FROM accounts WHERE 
	(locked=0) AND 
	(alive=1 AND location=2) AND 
	(laston < '".date("Y-m-d H:i:s",strtotime(date("r")."-".getsetting("LOGINTIMEOUT",900)." sec"))."' OR loggedin=0) AND
	(age > $days OR dragonkills > 0 OR pk > 0 OR experience > $exp) AND
	(acctid <> ".$session[user][acctid].") AND 
	(pvpflag <> '5013-10-06 00:42:00') AND 
	(pvpflag < '$pvptimeout') ORDER BY maxhitpoints DESC";
	$result = db_query($sql) or die(db_error(LINK));
	$athome=0;
	$name="";
	$hp=0;
	// count chars at home and find strongest
	for ($i=0;$i<db_num_rows($result);$i++){
		$row = db_fetch_assoc($result);
		$sql = "SELECT value1 FROM items WHERE value1=".(int)$session[housekey]." AND class='Schl�ssel' AND owner=$row[acctid] AND hvalue=".(int)$session[housekey]." ORDER BY id";
		$result2 = db_query($sql) or die(db_error(LINK));
		if (db_num_rows($result2)>0 || ((int)$row[housekey]==(int)$session[housekey] && 0==db_num_rows(db_query("SELECT hvalue FROM items WHERE hvalue<>0 AND class='Schl�ssel' AND value1<>$session[housekey] AND owner=$row[acctid]")))){
			$athome++;
			if ($row[maxhitpoints]>$hp){
				$hp=$row[maxhitpoints];
				$name=$row[login];
			}
		}
		db_free_result($result2);
	}
	addnav("Fl�chte","village.php");
	if ($athome>0){
		output("`n Dir kommen $athome misstrauische Bewohner schwer bewaffnet entgegen. Der wahrscheinlich St�rkste von ihnen wird sich jeden Augenblick auf dich st�rzen, ");
		output(" wenn du die Situation nicht sofort entsch�rfst.");
		addnav("K�mpfe","pvp.php?act=attack&bg=2&name=".rawurlencode($name));
	} else {
		output(" Du hast Gl�ck, denn es scheint niemand daheim zu sein. Das wird sicher ein Kinderspiel.");
		addnav("Einsteigen","houses.php?op=klauen&id=$session[housekey]");
	}
	}

}else if ($_GET[op]=="klauen"){
	if (!$_GET[id]){
		output("Und jetzt? Bitte benachrichtige den Admin. Ich wei� nicht, was ich jetzt tun soll...");
		addnav("S?Zum Stadtplatz","village.php");
	} else {
		addnav("S?Zum Stadtplatz","village.php");
		$sql = "SELECT * FROM houses WHERE houseid=".$session[housekey]." ORDER BY houseid ASC";
		$result = db_query($sql) or die(db_error(LINK));
		$row = db_fetch_assoc($result);
		$wasnu=e_rand(1,3);
		switch($wasnu){
			case 1:
			$getgems=0;
			$getgold=e_rand(0,round($row[gold]/10));
			$sql = "UPDATE houses SET gold=gold-$getgold WHERE houseid=$row[houseid]";
			break;
			case 2:
			$getgems=e_rand(0,round($row[gems]/10));
			$getgold=e_rand(0,round($row[gold]/10));
			$sql = "UPDATE houses SET gold=gold-$getgold,gems=gems-$getgems WHERE houseid=$row[houseid]";
			break;
			case 3:
			$getgems=e_rand(0,round($row[gems]/10));
			$getgold=0;
			$sql = "UPDATE houses SET gems=gems-$getgems WHERE houseid=$row[houseid]";
			break;
		}
		db_query($sql) or die(db_error(LINK));
		$session[user][gold]+=$getgold;
		$session[user][gems]+=$getgems;
		output("`6`nEs gelingt dir, `^$getgold `6Gold und  `#$getgems `6Edelsteine aus dem Schatz zu klauen!");
		addnews("`6".$session[user][name]."`6 erbeutet `#$getgems`6 Edelsteine und `^$getgold`6 Gold bei einem Einbruch!");
		systemmail($row[owner],"`\$Einbruch!`0","`\${$session['user']['name']}`\$ ist in dein Haus eingebrochen und hat `^$getgold`\$ Gold und `#$getgems`\$ Edelsteine erbeutet!");
	}
}else if ($HTTP_GET_VARS[op]=="fight"){
		$battle=true;
}else if ($HTTP_GET_VARS[op]=="run"){
	output("`\$Dein Stolz verbietet es dir, vor diesem Kampf wegzulaufen!`0");
	$HTTP_GET_VARS[op]="fight";
	$battle=true;

}else if ($_GET[op]=="buy"){
/*
	if ( $session[user][house]>0) {
		output("`6Du hast bereits ein Haus und brauchst kein zweites. Wenn du ein anderes Haus haben willst, musst du erst aus deinem jetzigen Zuhause ausziehen.");
	} else
*/
	 if (!$_GET[id]){
		$ppp=10; // Player Per Page to display
		if (!$_GET[limit]){
			$page=0;
		}else{
			$page=(int)$_GET[limit];
			addnav("Vorherige Seite","houses.php?op=buy&limit=".($page-1)."");
		}
		$limit="".($page*$ppp).",".($ppp+1);
		$sql = "SELECT * FROM houses WHERE status=2 OR status=3 OR status=4 ORDER BY houseid ASC LIMIT $limit";
		output("`c`b`qUnbewohnte H�user`b`c`0`n");
		output("<table cellspacing=0 cellpadding=2 align='center'><tr><td>`bHausNr.`b</td><td>`bName`b</td><td>`bGold`b</td><td>`bEdelsteine`b</td><td>`bBemerkung`b</td></tr>",true);
		$result = db_query($sql) or die(db_error(LINK));
		if (db_num_rows($result)>$ppp) addnav("N�chste Seite","houses.php?op=buy&limit=".($page+1)."");
		if (db_num_rows($result)==0){
  			output("<tr><td colspan=4 align='center'>`&`iEs stehen momentan keine H�user zum Verkauf`i`0</td></tr>",true);
		}else{
			for ($i=0;$i<db_num_rows($result);$i++){
	  			$row = db_fetch_assoc($result);
				$bgcolor=($i%2==1?"trlight":"trdark");
				output("<tr class='$bgcolor'><td align='right'>$row[houseid]</td><td><a href='houses.php?op=buy&id=$row[houseid]'>$row[housename]</a></td><td align='right'>$row[gold]</td><td align='right'>$row[gems]</td><td>",true);
				if ($row[status]==3){
					output("`4Verlassen`0");
				}else if ($row[status]==4){
					output("`\$Bauruine`0");
				}else if ($row[owner]==0){
					output("`^Maklerverkauf`0");
				}else{
					output("`6Privatverkauf`0");
				}
				output("</td></tr>",true);
				addnav("","houses.php?op=buy&id=$row[houseid]");
			}
		}
		output("</table>",true);
	} else {
		$sql = "SELECT * FROM houses WHERE houseid=".(int)$_GET[id]." ORDER BY houseid DESC";
		$result = db_query($sql) or die(db_error(LINK));
		$row = db_fetch_assoc($result);
		if ($session[user][acctid]==$row[owner]) {
			output("`6du h�ngst doch zu sehr an deinem Haus und beschlie�t, es noch nicht zu verkaufen.");
			$session[user][housekey]=$row[houseid];
			$sql = "UPDATE houses SET gold=0,gems=0,status=1 WHERE houseid=$row[houseid]";
			db_query($sql);
		}else if ($session[user][gold]<$row[gold] || $session[user][gems]<$row[gems]){
			output("`6Dieses edle Haus �bersteigt wohl deine finanziellen Mittel.");
		}else {
			output("`6Gl�ckwunsch zu deinem neuen Haus!`n`n");
			$session[user][gold]-=$row[gold];
			$session[user][gems]-=$row[gems];
			$session[user][house]=$row[houseid];
			output("Du �bergibst `^$row[gold]`6 Gold und `#$row[gems]`6 Edelsteine an den Verk�ufer, und dieser h�ndigt dir daf�r einen Satz Schl�ssel f�r Haus `b$row[houseid]`b aus."); 
			if ($row[owner]>0){
				$sql = "UPDATE accounts SET goldinbank=goldinbank+$row[gold],gems=gems+$row[gems],house=0,housekey=0 WHERE acctid=$row[owner]";
				db_query($sql);
				systemmail($row[owner],"`6Haus verkauft!`0","`&{$session['user']['name']}`2 hat dein Haus gekauft. Du bekommst `^$row[gold]`2 Gold auf die Bank und `#$row[gems]`2!");
				$session[user][housekey]=$row[houseid];
			}
			if ($row[status]==3){
				$sql = "UPDATE houses SET status=1,owner=".$session[user][acctid]." WHERE houseid=$row[houseid]";
				db_query($sql);
				$sql = "UPDATE items SET owner=".$session[user][acctid]." WHERE owner=0 and class='Schl�ssel' AND value1=$row[houseid]";
				output(" Bitte bedenke, dass du ein verlassenes Haus gekauft hast, zu dem vielleicht noch andere einen Schl�ssel haben!");
				$session[user][housekey]=$row[houseid];
			}else if ($row[status]==4){
				$sql = "UPDATE houses SET status=0,owner=".$session[user][acctid]." WHERE houseid=$row[houseid]";
				output(" Bitte bedenke, dass du eine Bauruine gekauft hast, die du erst fertigbauen musst!");
			}else{
				$sql = "UPDATE houses SET gold=0,gems=0,status=1,owner=".$session[user][acctid]." WHERE houseid=$row[houseid]";
				db_query($sql);
				$sql = "UPDATE items SET owner=".$session[user][acctid]." WHERE class='Schl�ssel' AND value1=$row[houseid]";
				$session[user][housekey]=$row[houseid];
			}
			db_query($sql);
		}
	}
	addnav("W?Zum Wohnviertel","houses.php");
	addnav("S?Zum Stadtplatz","village.php");
}else if ($_GET[op]=="sell"){
	$sql = "SELECT * FROM houses WHERE houseid=".$session[user][housekey]." ORDER BY houseid DESC";
	$result = db_query($sql) or die(db_error(LINK));
	$row = db_fetch_assoc($result);
	$halfgold=round($goldcost/3);
	$halfgems=round($gemcost/3);
	if ($_GET[act]=="sold"){
		if (!$_POST[gold] && !$_POST[gems]){
			output("`6Du denkst ernsthaft dar�ber nach, dein H�uschen zu verkaufen. Wenn du selbst einen Preis festlegst, bedenke, da� er auf einmal bezahlt werden muss ");
			output(" und vom K�ufer nicht in Raten abgezahlt werden kann. Au�erdem kannst du weder ein neues Haus bauen, noch in diesem Haus wohnen, bis es verkauft ist.");
			output(" Du bekommst dein Geld erst, wenn das Haus verkauft ist. Der Verkauf l��t sich abbrechen, indem du selbst das Haus von dir kaufst.");
			output("`nWenn du sofort Geld sehen willst, musst du dein Haus f�r `^$halfgold`6 Gold und `#$halfgems`6 Edelsteine an einen Makler verkaufen.");
			output("`0<form action=\"houses.php?op=sell&act=sold\" method='POST'>",true);
			output("`nWieviel Gold willst du verlangen? <input type='gold' name='gold'>`n",true);
			output("`nWieviele Edelsteine soll das Haus kosten? <input type='gems' name='gems'>`n",true);
			output("<input type='submit' class='button' value='Anbieten'>",true);
			addnav("","houses.php?op=sell&act=sold");
			addnav("An den Makler","houses.php?op=sell&act=makler");
		}else{
			$halfgold=(int)$_POST[gold];
			$halfgems=(int)$_POST[gems];
			if (($halfgold<$goldcost/40 && $halfgems<$gemcost/10) || ($halfgold==0 && $halfgems<$gemcost/2) || ($halfgold<$goldcost/20 && $halfgems==0)){
				output("`6Du solltest vielleicht erst deinen Ale-Rausch ausschlafen, bevor du �ber einen Preis nachdenkst. Wie? Du bist n�chtern? Das glaubt dir so kein Mensch.");
				addnav("Neuer Preis","houses.php?op=sell&act=sold");
			}else if ($halfgold>$goldcost*2 || $halfgems>$gemcost*4){
				output("`6Bei so einem hohen Preis bist du dir nicht sicher, ob du wirklich verkaufen sollst. �berlege es dir nochmal.");
				addnav("Neuer Preis","houses.php?op=sell&act=sold");
			}else{
				output("`6Dein Haus steht ab sofort f�r `^$halfgold`6 Gold und `#$halfgems`6 Edelsteine zum Verkauf. Du und alle Mitbewohner habt den Schatz des Hauses gleichm��ig ");
				output(" unter euch aufgeteilt und deine Untermieter haben ihre Schl�ssel abgegeben.");
				// Gold und Edelsteine an Bewohner verteilen und Schl�ssel einziehen
				$sql = "SELECT owner FROM items WHERE value1=$row[houseid] AND class='Schl�ssel' AND owner<>$row[owner] ORDER BY id ASC";
				$result = db_query($sql) or die(db_error(LINK));
				$amt=db_num_rows($result);
				$goldgive=round($row[gold]/($amt+1));
				$gemsgive=round($row[gems]/($amt+1));
				$session[user][gold]+=$goldgive;
				$session[user][gems]+=$gemsgive;
				// $sql="";
				for ($i=0;$i<db_num_rows($result);$i++){
					$item = db_fetch_assoc($result);
					$sql = "UPDATE accounts SET goldinbank=goldinbank+$goldgive,gems=gems+$gemsgive WHERE acctid=$item[owner]";
					db_query($sql);
					systemmail($item[owner],"`6Rauswurf!`0","`&{$session['user']['name']}`2 hat das Haus `b$row[housename]`b`2 verkauft, in dem du als Untermieter gewohnt hast. Du bekommst `^$goldgive`2 Gold auf die Bank und `#$gemsgive`2 Edelsteine aus dem gemeinsamen Schatz ausbezahlt!");
				}
				$sql = "UPDATE items SET owner=$row[owner] WHERE class='Schl�ssel' AND value1=$row[houseid]";
				db_query($sql);
				// Variablen setzen und Datenbank updaten
				$row[gold]=$halfgold;
				$row[gems]=$halfgems;
				$session[user][housekey]=0;
				$sql = "UPDATE houses SET gold=$row[gold],gems=$row[gems],status=2 WHERE houseid=$row[houseid]";
				db_query($sql);
			}
		}
	}else if ($_GET[act]=="makler"){
		output("`6Dem Makler entf�hrt ungewollt ein freudiges Glucksen, als er dir `^$halfcost`6 Gold und die `#$halfcost`6 Edelsteine vorz�hlt.`n`n");
		output("Ab sofort steht dein Haus zum Verkauf und du kannst ein neues bauen, woanders mit einziehen, oder ein anderes Haus kaufen.");
		// Gold und Edelsteine an Bewohner verteilen und Schl�ssel einziehen
		$sql = "SELECT owner FROM items WHERE value1=$row[houseid] AND class='Schl�ssel' AND owner<>$row[owner] ORDER BY id ASC";
		$result = db_query($sql) or die(db_error(LINK));
		$goldgive=round($row[gold]/(db_num_rows($result)+1));
		$gemsgive=round($row[gems]/(db_num_rows($result)+1));
		$session[user][gold]+=$goldgive;
		$session[user][gems]+=$gemsgive;
		//$sql="";
		for ($i=0;$i<db_num_rows($result);$i++){
			$item = db_fetch_assoc($result);
			$sql = "UPDATE accounts SET goldinbank=goldinbank+$goldgive,gems=gems+$gemsgive WHERE acctid=$item[owner]";
			db_query($sql);
			systemmail($item[owner],"`6Rauswurf!`0","`&{$session['user']['name']}`2 hat das Haus `b$row[housename]`b`2 verkauft, in dem du als Untermieter gewohnt hast. Du bekommst `^$goldgive`2 Gold auf die Bank und `#$gemsgive`2 Edelsteine aus dem gemeinsamen Schatz ausbezahlt!");

		}
		$sql = "UPDATE items SET owner=0 WHERE class='Schl�ssel' AND value1=$row[houseid]";
		db_query($sql);
		// Variablen setzen und Datenbank updaten
		$row[gold]=$goldcost-$halfgold;
		$row[gems]=$gemcost;
		$session[user][gold]+=$halfgold;
		$session[user][gems]+=$halfgems;
		$session[user][house]=0;
		$session[user][housekey]=0;
		$session[user][donation]+=1;
		$sql = "UPDATE houses SET owner=0,gold=$row[gold],gems=$row[gems],status=2 WHERE houseid=$row[houseid]";
		db_query($sql);
	} else {
		output("`6Gib einen Preis f�r dein Haus ein, oder lass einen Makler den Verkauf �bernehmen. Der schmierige Makler w�rde dir sofort `^$halfgold`6 Gold und `#$halfgems`6 Edelsteine geben. ");
		output("Wenn du selbst verkaufst, kannst du vielleicht einen h�heren Preis erzielen, musst aber auf dein Geld warten, bis jemand kauft.`nAlles, was sich noch im Haus befindet, wird ");
		output("gleichm�ssig unter allen Bewohnern aufgeteilt.`n`n");
		output("`0<form action=\"houses.php?op=sell&act=sold\" method='POST'>",true);
		output("`nWieviel Gold verlangen? <input type='gold' name='gold'>`n",true);
		output("`nWieviele Edelsteine? <input type='gems' name='gems'>`n`n",true);
		output("<input type='submit' class='button' value='F�r diesen Preis verkaufen'></form>",true);
		addnav("","houses.php?op=sell&act=sold");
		addnav("An den Makler","houses.php?op=sell&act=makler");
	}
	addnav("W?Zum Wohnviertel","houses.php");
	addnav("S?Zum Stadtplatz","village.php");
}else if ($_GET[op]=="drin"){
	if ($_GET[id]) $session[housekey]=(int)$_GET[id];
	if (!$session[housekey]) redirect("houses.php");
	$sql = "SELECT * FROM houses WHERE houseid=".$session[housekey]." ORDER BY houseid DESC";
	$result = db_query($sql) or die(db_error(LINK));
	$row = db_fetch_assoc($result);
	if ($_GET[act]=="takekey"){
		if (!$_POST[ziel]){
			$sql = "SELECT owner FROM items WHERE value1=$row[houseid] AND class='Schl�ssel' ORDER BY value2 ASC";
			$result = db_query($sql) or die(db_error(LINK));
			output("<form action='houses.php?op=drin&act=takekey' method='POST'>",true);
			output("`n`2Wem willst du den Schl�ssel wegnehmen? <select name='ziel'>",true);
			for ($i=0;$i<db_num_rows($result);$i++){
				$item = db_fetch_assoc($result);
				$sql = "SELECT acctid,name,login FROM accounts WHERE acctid=$item[owner] ORDER BY login DESC";
				$result2 = db_query($sql) or die(db_error(LINK));
				$row2 = db_fetch_assoc($result2);
				if ($amt!=$row2[acctid] && $row2[acctid]!=$row[owner]) output("<option value=\"".rawurlencode($row2['name'])."\">".preg_replace("'[`].'","",$row2['name'])."</option>",true);
				$amt=$row2[acctid];
			}
			output("</select>`n`n",true);
			output("<input type='submit' class='button' value='Schl�ssel abnehmen'></form>",true);
			addnav("","houses.php?op=drin&act=takekey");
		}else{
			$sql = "SELECT acctid,name,login,gold,gems FROM accounts WHERE name='".addslashes(rawurldecode(stripslashes($_POST['ziel'])))."' AND locked=0";
			$result2 = db_query($sql);
			$row2  = db_fetch_assoc($result2);
			output("`n`2Du verlangst den Schl�ssel von `&$row2[name]`2 zur�ck.`n");
			$sql = "SELECT owner FROM items WHERE value1=$row[houseid] AND class='Schl�ssel' AND owner<>$row[owner] ORDER BY id ASC";
			$result = db_query($sql) or die(db_error(LINK));
			$goldgive=round($row[gold]/(db_num_rows($result)+1));
			$gemsgive=round($row[gems]/(db_num_rows($result)+1));
			systemmail($row2[acctid],"`6Schl�ssel zur�ckverlangt!`0","`&{$session['user']['name']}`2 hat den Schl�ssel zu Haus Nummer `b$row[houseid]`b ($row[housename]`2) zur�ckverlangt. Du bekommst `^$goldgive`2 Gold auf die Bank und `#$gemsgive`2 Edelsteine aus dem gemeinsamen Schatz ausbezahlt!");
			output("`n$row2[name]`2 bekommt `^$goldgive`2 Gold und `#$gemsgive`2 Edelsteine aus dem gemeinsamen Schatz.");
			$sql = "UPDATE items SET owner=$row[owner],hvalue=0 WHERE owner=$row2[acctid] AND class='Schl�ssel' AND value1=$row[houseid]";
			db_query($sql);
			$sql = "UPDATE accounts SET goldinbank=goldinbank+$goldgive,gems=gems+$gemsgive WHERE acctid=$row2[acctid]";
			db_query($sql);
			$sql = "UPDATE houses SET gold=gold-$goldgive,gems=gems-$gemsgive WHERE houseid=$row[houseid]";
			db_query($sql);
			$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'house-".$row[houseid]."',".$session[user][acctid].",'/me `^nimmt $row2[name]`^ einen Schl�ssel ab. $row2[name]`^ bekommt einen Teil aus dem Schatz.')";
			db_query($sql) or die(db_error(LINK));
		}
		addnav("Zur�ck zum Haus","houses.php?op=drin");
	}else if ($_GET[act]=="givekey"){
		if (!$_POST['ziel']){
			output("`n`2Einen Schl�ssel f�r dieses Haus hat:`n`n");
			$sql = "SELECT items.*,accounts.name AS besitzer FROM items LEFT JOIN accounts ON accounts.acctid=items.owner WHERE value1=$row[houseid] AND class='Schl�ssel' AND owner<>".$session[user][acctid]." ORDER BY value2 ASC";
			$result = db_query($sql) or die(db_error(LINK));
			for ($i=0;$i<db_num_rows($result);$i++){
				$item = db_fetch_assoc($result);
				output("`c`& $item[besitzer]`0`c");
			}
			$sql = "SELECT value2 FROM items WHERE value1=$row[houseid] AND class='Schl�ssel' AND owner=$row[owner] ORDER BY id ASC";
			$result = db_query($sql) or die(db_error(LINK));
			if (db_num_rows($result)>0) {
				output("`n`2Du kannst noch `^`b".db_num_rows($result)."`b `2Schl�ssel vergeben.");
				output("<form action='houses.php?op=drin&act=givekey' method='POST'>",true);
				output("An wen willst du einen Schl�ssel �bergeben? <input name='ziel'>`n", true);
				output("`n<input type='submit' class='button' value='�bergeben'></form>",true);
				output("`nWenn du einen Schl�ssel vergibst, wird der Schatz des Hauses gemeinsam genutzt. Du kannst einem Mitbewohner zwar jederzeit den Schl�ssel wieder wegnehmen, ");
				output("aber er wird dann einen gerechten Anteil aus dem gemeinsamen Schatz bekommen.");
				addnav("","houses.php?op=drin&act=givekey");
			}else{
				output("`n`2Du hast keine Schl�ssel mehr �brig. Vielleicht kannst du in der J�gerh�tte noch einen nachmachen lassen?");
			} 
		} else {
			if ($_GET['subfinal']==1){
				$sql = "SELECT acctid,name,login,lastip,emailaddress,dragonkills,level,sex FROM accounts WHERE name='".addslashes(rawurldecode(stripslashes($_POST['ziel'])))."' AND locked=0";
			}else{
				$ziel = stripslashes(rawurldecode($_POST['ziel']));
				$name="%";
				for ($x=0;$x<strlen($ziel);$x++){
					$name.=substr($ziel,$x,1)."%";
				}
				$sql = "SELECT acctid,name,login,lastip,emailaddress,dragonkills,level,sex FROM accounts WHERE name LIKE '".addslashes($name)."' AND locked=0";
			}
			$result2 = db_query($sql);
			if (db_num_rows($result2) == 0) {
				output("`n`2Es gibt`$ niemanden `2mit einem solchen Namen. `^Versuchs nochmal!`2");
			} elseif(db_num_rows($result2) > 100) {
				output("`n`2Es gibt �ber 100 Krieger mit einem �hnlichen Namen. Bitte sei etwas genauer.");
			} elseif(db_num_rows($result2) > 1) {
				output("`n`2Es gibt mehrere m�gliche Krieger, denen du einen Schl�ssel �bergeben kannst.`n");
				output("`n<form action='houses.php?op=drin&act=givekey&subfinal=1' method='POST'>",true);
				output("`n`2Wen genau meinst du? <select name='ziel'>",true);
				for ($i=0;$i<db_num_rows($result2);$i++){
					$row2 = db_fetch_assoc($result2);
					output("<option value=\"".rawurlencode($row2['name'])."\">".preg_replace("'[`].'","",$row2['name'])."</option>",true);
				}
				output("</select>`n`n",true);
				output("<input type='submit' class='button' value='Schl�ssel �bergeben'></form>",true);
				addnav("","houses.php?op=drin&act=givekey&subfinal=1");
				//addnav("","houses.php?op=drin&act=givekey"); // why the hell was this in there?
			} else {
				$row2  = db_fetch_assoc($result2);
				$sql = "SELECT owner FROM items WHERE owner=$row2[acctid] AND value1=$row[houseid] AND class='Schl�ssel' ORDER BY id ASC";
				$result = db_query($sql) or die(db_error(LINK));
				$item = db_fetch_assoc($result);
				if ($row2[login] == $session[user][login]) {
					output("`n`2Du kannst dir nicht selbst einen Schl�ssel geben.");
				} elseif ($item[owner]==$row[owner]) {
					output("`n`2$row2[name]`2 hat bereits einen Schl�ssel!");
		 		} elseif ($session['user']['lastip'] == $row2['lastip'] || ($session['user']['emailaddress'] == $row2['emailaddress'] && $row2[emailaddress])){
					output("`n`2Deine Charaktere d�rfen leider nicht miteinander interagieren!");
				} elseif ($row2['level']<5 && $row2['dragonkills']<1){
					output("`n`2$row2[name]`2 ist noch nicht lange genug um Dorf, als dass du ".($row2['sex']?"ihr":"ihm")." vertrauen k�nntest. Also beschlie�t du, noch eine Weile zu beobachten.");
				} else {
					$sql = "SELECT value2 FROM items WHERE value1=$row[houseid] AND class='Schl�ssel' AND owner=$row[owner] ORDER BY id ASC LIMIT 1";
					$result = db_query($sql) or die(db_error(LINK));
					$knr = db_fetch_assoc($result);
					$knr=$knr[value2];
					output("`n`2Du �bergibst `&$row2[name]`2 einen Schl�ssel f�r dein Haus. Du kannst den Schl�ssel zum Haus jederzeit wieder wegnehmen, aber $row2[name]`2 wird dann ");
					output("einen gerechten Anteil aus dem gemeinsamen Schatz des Hauses bekommen.`n");
					systemmail($row2[acctid],"`6Schl�ssel erhalten!`0","`&{$session['user']['name']}`2 hat dir einen Schl�ssel zu Haus Nummer `b$row[houseid]`b ($row[housename]`2) gegeben!");
					$sql = "UPDATE items SET owner=$row2[acctid],hvalue=0 WHERE owner=$row[owner] AND class='Schl�ssel' AND value1=$row[houseid] AND value2=$knr";
					db_query($sql);
					$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'house-".$row[houseid]."',".$session[user][acctid].",'/me `^gibt $row2[name]`^ einen Schl�ssel.')";
					db_query($sql) or die(db_error(LINK));
				}
			}
		}
		addnav("Zur�ck zum Haus","houses.php?op=drin");
   	}else if ($_GET[act]=="takemaxgold"){ 
      		$maxtfer = $session[user][level]*getsetting("transferperlevel",25); 
      		$transleft = getsetting("transferreceive",3) - $session[user][transferredtoday]; 
		$amt = $maxtfer*$transleft; 
		if ($amt==0) output("`2Du hats heute schon genug Gold mitgenommen"); 
		else if ($amt>$row[gold]) { // Alles mitnehmen
      			$session[user][gold]+=$row[gold]; 
         			output("`2Du hast `^$row[gold]`2 Gold genommen. Insgesamt befindet sich jetzt noch `^0`2 Gold im Haus."); 
         			$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'house-".$row[houseid]."',".$session[user][acctid].",'/me `\$nimmt `^$row[gold]`\$ Gold.')"; 
         				db_query($sql) or die(db_error(LINK)); 
         				$session[user][transferredtoday]+=abs($row[gold]/$maxtfer)+1; // 
         				$row[gold]=0; 
          
         				$sql = "UPDATE houses SET gold=$row[gold] WHERE houseid=$row[houseid]"; 
         				db_query($sql) or die(db_error(LINK)); 
      	} else { //maximum mitnehmen 
         		$session[user][gold]+=$amt; 
         		$row[gold]-=$amt; 
         		$session[user][transferredtoday]=getsetting("transferreceive",3); 
         		output("`2Du hast `^$amt`2 Gold genommen. Insgesamt befindet sich jetzt noch `^$row[gold]`2 Gold im Haus."); 
         		$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'house-".$row[houseid]."',".$session[user][acctid].",'/me `\$nimmt `^$amt`\$ Gold.')"; 
         			db_query($sql) or die(db_error(LINK)); 
         			$sql = "UPDATE houses SET gold=$row[gold] WHERE houseid=$row[houseid]"; 
         			db_query($sql) or die(db_error(LINK));   
      		} 
      		addnav("Zur�ck zum Haus","houses.php?op=drin");
	}else if ($_GET[act]=="takegold"){
		$maxtfer = $session[user][level]*getsetting("transferperlevel",25);
		if (!$_POST[gold]){
			$transleft = getsetting("transferreceive",3) - $session[user][transferredtoday];
			output("`n`2Es befindet sich `^$row[gold]`2 Gold in der Schatztruhe des Hauses.`n`nDu darfst heute noch $transleft x bis zu `^$maxtfer`2 Gold mitnehmen.`n");
			output("`2<form action=\"houses.php?op=drin&act=takegold\" method='POST'>",true);
			output("`nWieviel Gold mitnehmen? <input type='gold' name='gold'>`n`n",true);
			output("<input type='submit' class='button' value='Mitnehmen'>",true);
			addnav("","houses.php?op=drin&act=takegold");
		}else{
			$amt=abs((int)$_POST[gold]);
			if ($amt>$row[gold]){
				output("`n`2So viel Gold ist nicht mehr da.");
			}else if ($maxtfer<$amt){
				output("`n`2Du darfst maximal `^$maxtfer`2 Gold auf einmal nehmen.");
			}else if ($amt<0){
				output("`n`2Wenn du etwas in den Schatz legen willst, versuche nicht, etwas negatives herauszunehmen.");
			}else if($session[user][transferredtoday]>=getsetting("transferreceive",3)){
				output("`n`2Du hast heute schon genug Gold bekommen. Du wirst bis morgen warten m�ssen.");
			}else{
				$row[gold]-=$amt;
				$session[user][gold]+=$amt;
				$session[user][transferredtoday]+=1;
				$sql = "UPDATE houses SET gold=$row[gold] WHERE houseid=$row[houseid]";
				db_query($sql) or die(db_error(LINK));
				output("`n`2Du hast `^$amt`2 Gold genommen. Insgesamt befindet sich jetzt noch `^$row[gold]`2 Gold im Haus.");
				$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'house-".$row[houseid]."',".$session[user][acctid].",'/me `\$nimmt `^$amt`\$ Gold.')";
				db_query($sql) or die(db_error(LINK));
			}
		}
		addnav("Zur�ck zum Haus","houses.php?op=drin");
	}else if ($_GET[act]=="givegold"){
		$maxout = $session[user][level]*getsetting("maxtransferout",25);
		if (!$_POST[gold]){
			$transleft = $maxout - $session[user][amountouttoday];
			output("`n`2Du darfst heute noch `^$transleft`2 Gold deponieren.`n");
			output("`n`2<form action=\"houses.php?op=drin&act=givegold\" method='POST'>",true);
			output("`nWieviel Gold deponieren? <input type='gold' name='gold'>`n`n",true);
			output("<input type='submit' class='button' value='Deponieren'>",true);
			addnav("","houses.php?op=drin&act=givegold");
		}else{
			$amt=abs((int)$_POST[gold]);
			if ($amt>$session[user][gold]){
				output("`n`2So viel Gold hast du nicht dabei.");
			}else if($row[gold]>round($goldcost)){
				output("`n`2Der Schatz ist voll.");
			}else if($amt>(round($goldcost)-$row[gold])){
				output("`n`2Du gibst alles, aber du bekommst beim besten Willen nicht so viel in den Schatz.");
			}else if ($amt<0){
				output("`n`2Wenn du etwas aus dem Schatz nehmen willst, versuche nicht, etwas negatives hineinzutun.");
			}else if ($session[user][amountouttoday]+$amt > $maxout) {
				output("`n`2Du darfst nicht mehr als `^$maxout`2 Gold pro Tag deponieren.");
			}else{
				$row[gold]+=$amt;
				$session[user][gold]-=$amt;
				$session[user][amountouttoday]+= $amt;
				output("`n`2Du hast `^$amt`2 Gold deponiert. Insgesamt befinden sich jetzt `^$row[gold]`2 Gold im Haus.");
				$sql = "UPDATE houses SET gold=$row[gold] WHERE houseid=$row[houseid]";
				db_query($sql) or die(db_error(LINK));
				$sql="INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'house-".$row[houseid]."',".$session[user][acctid].",'/me `@deponiert `^$amt`@ Gold.')";
				db_query($sql) or die(db_error(LINK));
			}
		}
		addnav("Zur�ck zum Haus","houses.php?op=drin");
	}else if ($_GET[act]=="takegems"){
		if (!$_POST[gems]){
			output("`n`2Es befinden sich `#$row[gems]`2 Edelsteine in der Schatztruhe des Hauses.`n`n");
			output("`n`2<form action=\"houses.php?op=drin&act=takegems\" method='POST'>",true);
			output("`nWieviele Edelsteine mitnehmen? <input type='gems' name='gems'>`n`n",true);
			output("<input type='submit' class='button' value='Mitnehmen'>",true);
			addnav("","houses.php?op=drin&act=takegems");
		}else{
			$amt=abs((int)$_POST[gems]);
			if ($amt>$row[gems]){
				output("`n`2So viele Edelsteine sind nicht mehr da.");
			}else if ($amt<0){
				output("`n`2Wenn du etwas in den Schatz legen willst, versuche nicht, etwas negatives herauszunehmen.");
			}else{
				$row[gems]-=$amt;
				$session[user][gems]+=$amt;
				$sql = "UPDATE houses SET gems=$row[gems] WHERE houseid=$row[houseid]";
				db_query($sql);
				output("`n`2Du hast `#$amt`2 Edelsteine genommen. Insgesamt befinden sich jetzt noch `#$row[gems]`2 Edelsteine im Haus.");
				$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'house-".$row[houseid]."',".$session[user][acctid].",'/me `\$nimmt `#$amt`\$ Edelsteine.')";
				db_query($sql) or die(db_error(LINK));
			}
		}
		addnav("Zur�ck zum Haus","houses.php?op=drin");
	}else if ($_GET[act]=="givegems"){
		if (!$_POST[gems]){
			output("`n`2<form action=\"houses.php?op=drin&act=givegems\" method='POST'>",true);
			output("`nWieviele Edelsteine deponieren? <input type='gems' name='gems'>`n`n",true);
			output("<input type='submit' class='button' value='Deponieren'>",true);
			addnav("","houses.php?op=drin&act=givegems");
		}else{
			$amt=abs((int)$_POST[gems]);
			if ($amt>$session[user][gems]){
				output("`n`2So viele Edelsteine hast du nicht.");
			}else if($row[gems]>=round($gemcost)){
				output("`n`2Der Schatz ist voll.");
			}else if($amt>(round($gemcost)-$row[gems])){
				output("`n`2Du gibst alles, aber du bekommst beim besten Willen nicht so viel in den Schatz.");
			}else if ($amt<0){
				output("`n`2Wenn du etwas aus dem Schatz nehmen willst, versuche nicht, etwas negatives hineinzutun.");
			}else{
				$row[gems]+=$amt;
				$session[user][gems]-=$amt;
				$sql = "UPDATE houses SET gems=$row[gems] WHERE houseid=$row[houseid]";
				db_query($sql);
				output("`n`2Du hast `#$amt`2 Edelsteine deponiert. Insgesamt befinden sich jetzt `#$row[gems]`2 Edelsteine im Haus.");
				$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'house-".$row[houseid]."',".$session[user][acctid].",'/me `@deponiert `#$amt`@ Edelsteine.')";
				db_query($sql) or die(db_error(LINK));
			}
		}
		addnav("Zur�ck zum Haus","houses.php?op=drin");
	}else if ($_GET[act]=="gemraum"){
			if (!$_POST[housename]){
			output("`n`2 Du betrittst einen Nebenraum des Hauses, in dessen Mitte eine offene `QFeuerstelle`2 ist. Von oben ist sie mit Steinen ummauert, so dass man darauf sitzen kann. `n");
			output("`2 In der Feuerstelle brennt ein `\$Feuer`2, das eine wohlige `QW�rme `2 verstr�mt.`n");
			output("`2 An der Wand h�ngen Zierwaffen und Schilde mit den Wappen m�chtiger Krieger sowie eine Dartscheibe mit Pfeilen.`n");
			output("`n`2 Ein gem�tlicher Raum, um sich am Feuer zu versammeln und Geschichten auszutauschen oder einfach nur zu reden.`n`n");
			viewcommentary("gemraum".$row[houseid],"Mit Mitbewohnern reden:`n",30,"sagt");
		}
		$sql = "SELECT * FROM items WHERE value1=$row[houseid] AND class='M�bel' ORDER BY class,id ASC";
		$result = db_query($sql) or die(db_error(LINK));
		for ($i=1;$i<=db_num_rows($result);$i++){
			$item = db_fetch_assoc($result);
			if ($item[name]=="Holztisch") output("`n`6Holztisch`0 (`i$item[description]`i)");
			if ($item[name]=="4 Holzst�hle") output("`n`64 Holzst�hle`0 (`i$item[description]`i)");
			if ($item[name]=="Statue des Nyx") output("`n`6Statue des Nyx`0 (`i$item[description]`i)");
			if ($item[name]=="Statue der Lilith") output("`n`6Statue der Lilith`0 (`i$item[description]`i)");
			if ($item[name]=="Statue des Morpheus") output("`n`6Statue des Morpheus`0 (`i$item[description]`i)");
		}
		addnav("Zur�ck zum Wohnzimmer","houses.php?op=drin");

	}else if ($_GET[act]=="badezimmer"){
			if (!$_POST[housename]){
			output("`n`3 Du betrittst das Badezimmer des Hauses, das mit einfachen `tFliesen `3gekachelt ist.");
			output("`3 Beheizt wird das `#Bad `3mit der `qwarmen Luft`3, die vom `4Kamin `3des Wohnzimmers durch Kan�le in den W�nden str�mt.`n");
			output("`3 Du kannst einen `vVorhang `3sehen, der zu gezogen werden kann, damit man bei der `tMorgen- `3oder `tAbendtoillete`3 nicht gest�rt wird.");
			output("`n`3 Au�erdem steht auf dem Boden ein `TEimer `3mit `#Wasser`3, der zur Sp�lung des einfachen WCs dient, da� an der Au�enwand befestigt ist.`n`n");
			viewcommentary("badezimmer".$row[houseid],"Mit Mitbewohnern reden:`n",30,"sagt");
		}
		$sql = "SELECT * FROM items WHERE value1=$row[houseid] AND class='M�bel' ORDER BY class,id ASC";
		$result = db_query($sql) or die(db_error(LINK));
		for ($i=1;$i<=db_num_rows($result);$i++){
			$item = db_fetch_assoc($result);
			if ($item[name]=="Gro�er Spiegel") addnav("Spiegel","houses.php?op=drin&act=mirror");
			if ($item[name]=="Badezuber") addnav("Badezuber","houses.php?op=drin&act=bad");
			if ($item[name]=="Gro�er Spiegel") output("`n`6Gro�er Spiegel`0 (`i$item[description]`i)");
			if ($item[name]=="Badezuber") output("`n`6Badezuber`0 (`i$item[description]`i)");
			if ($item[name]=="Badezimmerteppich") output("`n`6Badezimmerteppich`0 (`i$item[description]`i)");
			if ($item[name]=="Badezimmerschrank") output("`n`6Badezimmerschrank`0 (`i$item[description]`i)");
			if ($item[name]=="Gem�lde Eythgim") output("`n`6Gem�lde Eythgim`0 (`i$item[description]`i)");
		}
		addnav("Zur�ck zum Wohnzimmer","houses.php?op=drin");

	}else if ($_GET[act]=="kueche"){
			if (!$_POST[housename]){
	output("`3Du betrittst den Raum und blickst Dich um.");
	output("`3Die K�che ist recht modern eingerichtet, es steht ein Steinbackofen an der Au�enwand, daneben ein Ofen, mit dem die K�che auch geheizt wird.");
	output("`3Er besitzt 4 Platten, auf denen man T�pfe zum Kochen abstellen kann, dar�ber h�ngen einige Regale, in denen verschiedene Beh�lter mit Lebensmitteln stehen.`n`n");
	viewcommentary("kueche".$row[houseid],"Mit Mitbewohnern reden:`n",30,"sagt");
		}
		$sql = "SELECT * FROM items WHERE value1=$row[houseid] AND class='M�bel' ORDER BY class,id ASC";
		$result = db_query($sql) or die(db_error(LINK));
		for ($i=1;$i<=db_num_rows($result);$i++){
			$item = db_fetch_assoc($result);
			if ($item[name]=="Wasserspender") addnav("t?Etwas trinken","houses.php?op=drin&act=trinken");
			if ($item[name]=="Fr�hst�cksset") addnav("F?Fr�hst�ck machen","houses.php?op=drin&act=frueh");
			if ($item[name]=="T�pfe und Pfannen") addnav("M?Mittagessen machen","houses.php?op=drin&act=mittag");
			if ($item[name]=="Abendessensset") addnav("A?Abendessen machen","houses.php?op=drin&act=abend");
			if ($item[name]=="Wasserspender") output("`n`6Wasserspender`0 (`i$item[description]`i)");
			if ($item[name]=="Fr�hst�cksset") output("`n`6Fr�hst�cksset`0 (`i$item[description]`i)");
			if ($item[name]=="T�pfe und Pfannen") output("`n`6T�pfe und Pfannen`0 (`i$item[description]`i)");
			if ($item[name]=="Abendessensset") output("`n`6Abendessensset`0 (`i$item[description]`i)");
			if ($item[name]=="K�chenschrank") output("`n`6K�chenschrank`0 (`i$item[description]`i)");
			if ($item[name]=="K�chentisch") output("`n`6K�chentisch`0 (`i$item[description]`i)");
			if ($item[name]=="4 K�chenst�hle") output("`n`64 K�chenst�hle`0 (`i$item[description]`i)");
			if ($item[name]=="Gem�lde der G�tter") output("`n`6Gem�lde der G�tter`0 (`i$item[description]`i)");
		}
	addnav("Z?Zur�ck zum Wohnzimmer","houses.php?op=drin");

	}else if ($_GET[act]=="privates"){
			if (!$_POST[housename]){
  				 if($_GET[id])
	      				$session[housekey]=(int)$_GET[id];
   					if(!$session[housekey])
      					redirect("houses.php");
   					$sql="SELECT * FROM houses WHERE houseid=".$session[housekey]." ORDER BY houseid DESC";
   					$result=db_query($sql)or die(db_error(LINK));
   					$row=db_fetch_assoc($result);
   					output("`2`b`c$row[housename] `2(das Schlafzimmer)`c`b`n");
   					if($row[description])
   					output("`0`c$row[description]`c`n");
   					if ($showroomimages)
    					output("<img src='images/house-candle.gif' width='62' height='100' align='right'/>",true);
   					if($_GET[act]=="logout")
   					{
      				if(($session[user][housekey]!=$session[housekey]) || ($showownersleepstatus==TRUE))
     				 // pk: Optional Schlafstatus des Besitzers anzeigen
     				{  $sql="UPDATE items SET hvalue=".$session[housekey]." WHERE value1=".(int)$session[housekey]." AND owner=".$session[user][acctid]." AND class='Schl�ssel'";
         				db_query($sql)or die(sql_error($sql));
      				}
      				$session['user']['loggedin']=0;
      				$session['user']['location']=2;
      				$sql="UPDATE accounts SET loggedin=0,location=2,housesleep=".$session[housekey]." WHERE acctid = ".$session[user][acctid];
      				db_query($sql)or die(sql_error($sql));
      				$session=array();
      				redirect("index.php");
   			}
   			// Nun Ehepartner raussuchen
  			 $partnerexists=FALSE;
  			 $lover="";
  			 $loverID=$session[user][marriedto];
  			 $loved=$session[user][login];
  			 $lovedID=$session[user][acctid];
  			 if($session[user][marriedto]>0)
   			{
   			   $sql="SELECT acctid,login,marriedto FROM accounts WHERE acctid=$loverID AND marriedto=$lovedID ORDER BY acctid DESC";
   			   $result=db_query($sql)or die(db_error(LINK));
   			   if(db_num_rows($result)>0)
   			   {
   			      $row=db_fetch_assoc($result);
   			      $lover=$row[login];
   			   }
   			}
   			  if($loverID==4294967295)
     			{
     			 if($sesssion[user][sex]==0)
     			 {
     			    $lover="Violet";
     			 }
     			 else
     			 {
     			    $lover="Seth";
     			 }
   		}
  			 if(($loverID>0) && ($session[user][charisma]==4294967295))
  			 {
      			if(strcmp($session[user][acctid],$session[user][marriedto])<0)
      			{
       			  $chat="hflirt-".$session[housekey]."-".$session[user][acctid]."_".$session[user][marriedto];
      			}
      			else
      			{
      			   $chat="hflirt-".$session[housekey]."-".$session[user][marriedto]."_".$session[user][acctid];
      			}
      			$partnerexists=TRUE;
      			$partnersleeps=FALSE;
      			// Liste der schlafenden Personen
     			 $sql = "SELECT * FROM houses WHERE houseid=".$session[housekey]." ORDER BY houseid DESC";
     			 $result = db_query($sql)or die(db_error(LINK));
     			 $row = db_fetch_assoc($result);
     			 $sql="SELECT * FROM items WHERE value1=$session[housekey] AND class='Schl�ssel' ORDER BY id ASC";
     			 $result=db_query($sql)or die(db_error(LINK));
     			 for($i=1; $i <= db_num_rows($result); $i++)
     			 {
     			    $item=db_fetch_assoc($result);
     			    $sql="SELECT acctid,name FROM accounts WHERE acctid=$item[owner] ORDER BY login DESC";
     			    $result2=db_query($sql)or die(db_error(LINK));
     			    $row2=db_fetch_assoc($result2);
     			    if(($row2[name]!="") && ($item['hvalue']>0) && ($row2[acctid]==$loverID))
     			    //{ output("`2$row2[name] schl�ft gerade hier.`0`n"); }
     			    {
     			       $partnersleeps=TRUE;
     			    }
     			 }
     			 if($partnersleeps==FALSE)
     			 {
     			    output("`2Hier kannst Du dich mit `^$lover`2 ungest�rt unterhalten, ohne eure Mitbewohner zu st�ren.`n`n");
     			    viewcommentary($chat,"Mit Partner reden:",30,"sagt");
     			 }
     			 else
     			 {
     			    output("`2W�rde `^$lover`2 nicht schlafen, k�nntet ihr euch hier ungest�rt unterhalten, ohne eure Mitbewohner zu st�ren.`n`n");
     			    viewcommentary($chat,"In's Ohr fl�stern:",30,"fl�stert");
     			 }
   			}			
   			else
   			{
   			   if($loverID==4294967295)
   			   {
   			      output("`2`^$lover`2 mu�te den ganzen Tag in der Kneipe schon so viel erz�hlen und ist jetzt zu m�de f�r weitere Unterhaltungen, ansonsten k�nntet ihr euch hier unterhalten, ohne eure Mitbewohner zu st�ren.`n`n");
   			   }
   			   else
   			   {
   			      output("`2W�rst Du verheiratet, k�nntest Du dich hier mit Deinem Partner ungest�rt unterhalten, ohne eure Mitbewohner zu st�ren. So hast Du immerhin ein Zimmer ganz f�r dich alleine!`n`n");
   			   }
   			}

		$sql = "SELECT * FROM items WHERE value1=$row[houseid] AND class='M�bel' ORDER BY class,id ASC";
		$result = db_query($sql) or die(db_error(LINK));
		for ($i=1;$i<=db_num_rows($result);$i++){
			$item = db_fetch_assoc($result);
			if ($session[user][house]==$session[housekey]){
				if ($item[name]=="Himmelbett") addnav("Himmelbett","houses.php?op=drin&act=hbett");
				if ($item[name]=="Himmelbett") output("`n`6Himmelbett`0 (`i$item[description]`i)");
				if ($item[name]=="Teppich") output("`n`6Teppich`0 (`i$item[description]`i)");
				if ($item[name]=="Mehrarmiger Kerzenst�nder") output("`n`6Mehrarmiger Kerzenst�nder`0 (`i$item[description]`i)");
				if ($item[name]=="Kleiderschrank") output("`n`6Kleiderschrank`0 (`i$item[description]`i)");
				if ($item[name]=="Kleines Ledersofa") output("`n`6Kleines Ledersofa`0 (`i$item[description]`i)");
				if ($item[name]=="Drahtring") output("`n`6Drahtring`0 (`i$item[description]`i)");
				if ($item[name]=="Kupferring") output("`n`6Kupferring`0 (`i$item[description]`i)");
				if ($item[name]=="Eisenring") output("`n`6Eisenring`0 (`i$item[description]`i)");
				if ($item[name]=="Billiger Ring") output("`n`6Billiger Ring`0 (`i$item[description]`i)");
				if ($item[name]=="Medaillon aus Kupfer") output("`n`6Medaillon aus Kupfer`0 (`i$item[description]`i)");
				if ($item[name]=="Medaillon aus Eisen") output("`n`6Medaillon aus Eisen`0 (`i$item[description]`i)");
				if ($item[name]=="Reich verzierter Silberring") output("`n`6Reich verzierter Silberring`0 (`i$item[description]`i)");
				if ($item[name]=="Goldring") output("`n`6Goldring`0 (`i$item[description]`i)");
				if ($item[name]=="Ehering aus Silber") output("`n`6Ehering aus Silber`0 (`i$item[description]`i)");
				if ($item[name]=="Ehering aus Gold") output("`n`6Ehering aus Gold`0 (`i$item[description]`i)");
				if ($item[name]=="Reich verzierter Ehering aus Gold mit Diamantsplittern") output("`n`6Reich verzierter Ehering aus Gold mit Diamantsplittern`0 (`i$item[description]`i)");
				if ($item[name]=="Freunschaftsb�ndchen") output("`n`6Freundschaftsb�ndchen`0 (`i$item[description]`i)");
				if ($item[name]=="Freundschaftsanh�nger") output("`n`6Freundschaftsanh�nger`0 (`i$item[description]`i)");
				if ($item[name]=="Halskette") output("`n`6Halskette`0 (`i$item[description]`i)");
				if ($item[name]=="Pl�schdrachen") output("`n`6Pl�schdrachen`0 (`i$item[description]`i)");
				if ($item[name]=="Beutel Heilkr�uter") output("`n`6Beutel Heilkr�uter`0 (`i$item[description]`i)");
				if ($item[name]=="Goldenes Amulett") output("`n`6Goldenes Amullet`0 (`i$item[description]`i)");
				if ($item[name]=="Drahtring") output("`n`6Drahtring`0 (`i$item[description]`i)");
				if ($item[name]=="Gem�lde Nollopa") output("`n`6Gem�lde Nollopa`0 (`i$item[description]`i)");
			   }
   			   else
   			   {
			if ($item[name]=="4 Haengematten") addnav("4 Haengematten","houses.php?op=drin&act=matten");
			if ($item[name]=="4Gaestebetten") addnav("4Gaestebetten","houses.php?op=drin&act=gbetten");
			if ($item[name]=="4 Haengematten") output("`n`64 Haengematten`0 (`i$item[description]`i)");
			if ($item[name]=="4Gaestebetten") output("`n`64Gaestebetten`0 (`i$item[description]`i)");
			if ($item[name]=="Kleiner Kleiderschrank") output("`n`6Kleiner Kleiderschrank`0 (`i$item[description]`i)");
			if ($item[name]=="Kleines Regal") output("`n`6Kleines Regal`0 (`i$item[description]`i)");
		}
		}
		}
   			addnav("Aktionen");
   			addnav("Einschlafen","houses.php?op=drin&act=logout");
   			addnav("Zur�ck zum Wohnzimmer","houses.php?op=drin");

	}else if ($_GET[act]=="zusatzraum"){
			if (!$_POST[housename]){
			output("`n`3 Du betrittst einen Raum, der recht gemuetlich gestaltet ist mit warmen Farben an den W�nden, dessen Verwenduung aber noch nicht definiert ist.");
			output("`3 Ein kleiner `4K`qa`6m`qi`4n`3, in dem ein gem�tliches `qFe`6u`qer `3brennt, das den Raum angenehm erw�rmt und gleichzeitig `6Li`^c`6ht`3 spendet.`n");
			output("`3 Es gibt genug Platz f�r M�bel, die dann den entg�ltigen Zweck des Raumes bestimmen.`n`n");
			viewcommentary("zusatztzimmer".$row[houseid],"Mit Mitbewohnern reden:`n",30,"sagt");
		}
		$sql = "SELECT * FROM items WHERE value1=$row[houseid] AND class='M�bel' ORDER BY class,id ASC";
		$result = db_query($sql) or die(db_error(LINK));
		for ($i=1;$i<=db_num_rows($result);$i++){
			$item = db_fetch_assoc($result);
			if ($item[name]=="Babywiege") output("`n`6Babywiege`0 (`i$item[description]`i)");
			if ($item[name]=="Kinderbett") output("`n`6Kinderbett`0 (`i$item[description]`i)");
			if ($item[name]=="Hantelbank") output("`n`6Hantelbank`0 (`i$item[description]`i)");
			if ($item[name]=="Bodenmatte") output("`n`6Bodenmatte`0 (`i$item[description]`i)");
			if ($item[name]=="Staffelei") output("`n`6Staffelei`0 (`i$item[description]`i)");
			if ($item[name]=="Leinwand") output("`n`6Leinwand`0 (`i$item[description]`i)");
			if ($item[name]=="Pinsel") output("`n`6Pinsel`0 (`i$item[description]`i)");
			if ($item[name]=="Holzschrank") output("`n`6Holzschrank`0 (`i$item[description]`i)");
			if ($item[name]=="Holzst�hle") output("`n`6Holzst�hle`0 (`i$item[description]`i)");
			if ($item[name]=="Kleiner Holztisch") output("`n`6Kleiner Holztisch`0 (`i$item[description]`i)");
			if ($item[name]=="Spielzeug") output("`n`6Spielzeug`0 (`i$item[description]`i)");
			if ($item[name]=="Stoffballen") output("`n`6Stoffballen`0 (`i$item[description]`i)");
			if ($item[name]=="N�hzubeh�r") output("`n`6N�hzubeh�r`0 (`i$item[description]`i)");
			if ($item[name]=="Spinnrad") output("`n`6Spinnrad`0 (`i$item[description]`i)");
			if ($item[name]=="Webstuhl") output("`n`6Webstuhl`0 (`i$item[description]`i)");
			if ($item[name]=="Schwertkampfdummie") output("`n`6Schwertkampfdummie`0 (`i$item[description]`i)");
		}
		addnav("Zur�ck zum Haus","houses.php?op=drin");

	}else if($_GET[act]=="stable"){
	  	 // Stall ,,....................................
	  	 if($_GET[id])
 	  	   $session[housekey]=(int)$_GET[id];
 	  	if(!$session[housekey])
 	  	   redirect("houses.php");
 	  	$sql="SELECT * FROM houses WHERE houseid=".$session[housekey]." ORDER BY houseid DESC";
 	  	$result=db_query($sql)or die(db_error(LINK));
	  	 $row=db_fetch_assoc($result);
	  	 output("`2`b`c$row[housename]`c`b`n");
	  	 if($row[description])
	  	    output("`0`c$row[description]`c`n");
	  	 $sql="SELECT acctid,name,hashorse FROM accounts WHERE hashorse>0 ORDER BY acctid DESC";
	  	 $result=db_query($sql)or die(db_error(LINK));
	  	 $mountcount=0;
	 	  $mountlist="";
	 	  for($i=1; $i <= db_num_rows($result); $i++)
	 	  {  $acct=db_fetch_assoc($result);
	 	     $sql2 = "SELECT owner FROM items WHERE owner=$acct[acctid] AND value1='".$session[housekey]."' AND class='Schl�ssel'";
	 	     $result2 = db_query($sql2)or die(db_error(LINK));
	 	     if(db_num_rows($result2)>0)
	 	     {  $sql3="SELECT mountname FROM mounts WHERE mountid=$acct[hashorse]";
	 	        $result3=db_query($sql3)or die(db_error(LINK));
	 	        if(db_num_rows($result3)>0)
	 	        {  $horse=db_fetch_assoc($result3);
	 	           $mountlist .= "`n`&$acct[name]: `7$horse[mountname]";
	 	           $mountcount++;
	 	        }
	 	     }
	 	  }
	 	  if($mountcount==0)
	 	  {
	 	     output("`2Du gehst zur Haust�re heraus und in den Stall, der hinten an das Haus angebaut ist. Hier sieht noch alles ganz frisch eingerichtet und ungenutzt aus, was wohl daran liegt, dass niemand in diesem Haus ein Tier besitzt.`n");
	 	  }
	 	  else
	 	  {
	 	     output("`2Du gehst zur Haust�re heraus und in den Stall, der hinten an das Haus angebaut ist. Hier siehst Du die Tiere Deiner Mitbewohner bzw. deren leere Boxen.`n");
	 	     output($mountlist);
	 	  }
	 	  addnav("Zur�ck in das Haus","houses.php?op=drin");
		  addnav("Ins Wohnviertel","houses.php");
		  addnav("Zur Stadt","village.php");

	}else if ($_GET[act]=="rename"){
		if (!$_POST[housename]){
			output("`n`2Das Haus umbenennen kostet `^1000`2 Gold und `#1`2 Edelstein.`n`n");
			output("`0<form action=\"houses.php?op=drin&act=rename\" method='POST'>",true);
			output("`nGebe einen neuen Namen f�r dein Haus ein: <input name='housename' maxlength='25'>`n",true);
			output("`n<input type='submit' class='button' value='Umbenennen'>",true);
			addnav("","houses.php?op=drin&act=rename");
		}else{
			if ($session[user][gold]<1000 || $session[user][gems]<1){
				output("`n`2Das kannst du nicht bezahlen.");
			}else{
				output("`n`2Dein Haus `@$row[housename]`2 hei�t jetzt `@".stripslashes($_POST[housename])."`2.");
				$sql = "UPDATE houses SET housename='".$_POST[housename]."' WHERE houseid=$row[houseid]";
				db_query($sql);
				$session[user][gold]-=1000;
				$session[user][gems]-=1;
			}
		}
		addnav("Zur�ck zum Haus","houses.php?op=drin");
	}else if ($_GET[act]=="desc"){
		if (!$_POST[desc]){
			output("`n`2Hier kannst du die Beschreibung f�r dein Haus �ndern.`n`nDie aktuelle Beschreibung lautet:`n`n`0$row[description]`0`n");
			output("`0<form action=\"houses.php?op=drin&act=desc\" method='POST'>",true);
			output("`n`2Gebe eine Beschreibung f�r dein Haus ein:`n`n<input name='desc' maxlength='250' size='50'>`n",true);
			output("`n<input type='submit' class='button' value='Abschicken'>",true);
			addnav("","houses.php?op=drin&act=desc");
		}else{
			output("`n`2Die Beschreibung wurde ge�ndert und lautet nun:`n`n`0".stripslashes($_POST[desc])."`2.");
			$sql = "UPDATE houses SET description='".$_POST[desc]."' WHERE houseid=$row[houseid]";
			db_query($sql);
		}
		addnav("Zur�ck zum Haus","houses.php?op=drin&act=badezimmer");
	}else if ($_GET[act]=="logout"){
		if ($session[user][housekey]!=$session[housekey]){
			$sql = "UPDATE items SET hvalue=".$session[housekey]." WHERE value1=".(int)$session[housekey]." AND owner=".$session[user][acctid]." AND class='Schl�ssel'";
			db_query($sql) or die(sql_error($sql));
		}
		debuglog("logged out in a house ");
		$session['user']['location']=2;
		$session['user']['loggedin']=0;
		$sql = "UPDATE accounts SET loggedin=0,location=2 WHERE acctid = ".$session[user][acctid];
		db_query($sql) or die(sql_error($sql));
		$session=array();
		redirect("index.php");
// actions by items/furniture
	}else if ($_GET[act]=="mirror"){
		switch(e_rand(1,5)){
			case 1:
			output("`2Du blickst in den Spiegel, in der Hoffnung etwas erfreuliches zu sehen. ");
			break;
			case 2:
			output("`2Dir starrt ".($session[user][sex]?"eine v�llig unbekannte Frau":"ein v�llig unbekannter Mann")." entgegen. ");
			break;
			case 3:
			if ($session[user][charm]<10) output("`2Du fragst dich, warum dieses h��liche Bild im Haus h�ngt. ");
			if ($session[user][charm]>=10 and $session[user][charm]<50) output("`2Naja, wer auch immer dieses Bild gemalt hat, hat Talent, sollte aber noch etwas �ben. ");
			if ($session[user][charm]>=50) output("`2Das ist ein wirklich tolles Bild von ".($session[user][sex]?"einer Frau":"einem Mann")."! ");
			break;
			case 4:
			output("`2Erstaunlicher Apparat. ");
			break;
			case 5:
			output("`2Du verbringst eine ganze Weile vor dem Spiegel. ");
			if (e_rand(1,3)==2 && $sesion[user][turns]>0){
				output("Dabei merkst du nicht, wie die Zeit vergeht. Du vertr�delst einen Waldkampf! ");
				$session[user][turns]--;
			}
			break;
		}
		$was=e_rand(1,3);
		if ($was==1 && $session[user][turns]>0){
			$session[user][charm]--;
			if ($session[user][charm]<=0) $session[user][charm]=0;
			output("`nDu `4verlierst`2 einen Charmepunkt!");
		}else if ($was==3 && $session[user][turns]>0){
			$session[user][charm]++;
			output("`nDu `@bekommst`2 einen Charmepunkt.");
		}else if ($session[user][turns]<=0){
			output("`nDu hast heute keine Zeit mehr, dich um dein �u�eres zu k�mmern.");
		}else{
		}
		addnav("Zur�ck zum Bad","houses.php?op=drin&act=badezimmer");
	}else if ($_GET[act]=="bad"){
		$session['user']['clean']=0;
		switch(e_rand(1,5)){
			case 1:
			output("`n`2Du nimmst ein erfrischendes Bad. ");
			break;
			case 2:
			output("`n`2Du blickst an Dir herabund denkst, da� ".($session[user][sex]?"keine andere Frau":"kein anderer Mann")." einen solchen K�rper hat wie Du. ");
			break;
			case 3:
			if ($session[user][charm]<10) output("`n`2Du blickst in Dein Spiegelbild im Wasser, betrachtest Deinen K�rper und denkst, da� Du noch was f�r Deine Sch�nheit tun solltest. ");
			if ($session[user][charm]>=10 and $session[user][charm]<50) output("`n`2Du blickst auf Dein Spiegelbild im Wasser, dann auf Deinen K�rper und denkst, da� es schon ganz okay aussieht, aber durchaus sch�ner sein k�nnte. ");
			if ($session[user][charm]>=50) output("`n`2DU betrachtest Dein Spiegelbild im Wasser, schaust auf Deinen K�rper und denkst, da� Du doch ".($session[user][sex]?"die sch�nste Frau":"der sch�nste Mann")."weit und breit bist! ");
			break;
			case 4:
			output("`n`2So ein Bad tut doch immer wieder gut. ");
			break;
			case 5:
			output("`n`2Du planscht im Wasser herum und spielst mit einer Gummiente. ");
			if (e_rand(1,3)==2 && $sesion[user][turns]>0){
				output("Dabei merkst du nicht, wie die Zeit vergeht und Du vertr�delst einen Waldkampf! ");
				$session[user][turns]--;
			}
			break;
		}
		$was=e_rand(1,3);
		if ($was==1 && $session[user][turns]>0){
			$session[user][charm]--;
			if ($session[user][charm]<=0) $session[user][charm]=0;
			output("`n`nDu `4verlierst`2 einen Charmepunkt!");
		}else if ($was==3 && $session[user][turns]>0){
			$session[user][charm]++;
			output("`n`nDu `@bekommst`2 einen Charmepunkt.");
		}else if ($session[user][turns]<=0){
			output("`n`nDu hast heute keine Zeit mehr, ein Bad zu nehmen.");
		}else{
		}
		addnav("Zur�ck zum Bad","houses.php?op=drin&act=badezimmer");
	}else if ($_GET[act]=="hbett"){
			output("`n`tDu entz�ndest die 2 `&Kerz`qe`^n`t, die rechts und links neben dem Bett auf `5schmiedeeisernen `tKerzenhaltern stehen und l�scht alle anderen `&Kerz`qe`^n`t im Raum, bevor Du die `vDecke `tzur�ck schl�gst und Dich auf die gem�tliche, gro�e Matratze legst. ");
			output("`n`t Du kuschelst Dich ein in die wundervolll weiche, gro�e `vDaunendecke`t, schnappst Dir welche der vielen `vKissen`t, die auf dem Bett liegen und machst es Dir richtig gem�tlich.. ");
			output("`n`tAch, das ist genau der richtige Ort zum Schlafen, kuscheln und tr�umen.... ");
		
		addnav("Schlafen","houses.php?op=drin&act=logout");
		addnav("Aufstehen","houses.php?op=drin&act=privates");
	}else if ($_GET[act]=="matten"){
			output("`n`3 An den W�nden entdeckst Du Hacken, an denen, zusammen gelegt,`v H�ngematten `3h�ngen. ");
			output("`n`3 Da eine H�ngematte immer noch besser ist, als die `vMatten `3auf dem Boden, faltest Du eine auseinander, h�ngst sie auf und legst die`v Matte `3als Unterlage drauf, anschlie�ende ein `vKissen `3und eine `vDecke`3. ");
			output("`n`3Kein Bett, aber bequemer als der Boden oder Cedis Strohbetten.");
		
		addnav("Schlafen","houses.php?op=drin&act=logout");
		addnav("Aufstehen","houses.php?op=drin&act=gastzimmer");
	}else if ($_GET[act]=="gbetten"){
			output("`n`3 An der Seite des Zimmers siehst Du auch zusammen geklappte `vBetten `3stehen, die f�r G�ste gedacht sind.");
			output("`n`3 Du klappst eines auf, legst Deine `3Decke `3und Dein `vKissen `3darauf und kuschelst Dich ein, wobei Du feststellst, da� das `vBett `3doch weicher ist als angenommen. ");
			output("`n`3 Na ja, kein `#Himmelbett`3, aber besser als der Boden oder eine `vH�ngematte`3... ");
		
		addnav("Schlafen","houses.php?op=drin&act=logout");
		addnav("Aufstehen","houses.php?op=drin&act=gastzimmer");
	}else if ($_GET[act]=="trinken"){
		output("`n`3Du gehst zum Tisch, nimmst Dir ein Glas und f�llst es mit `#frischem Wasser`3.`n`n");
			$rand1 = e_rand(1,24);
     			 	switch ($rand1){
    			     		case 1:
    			     		output("`^Das tat gut!");
    			     		break;
    			     		case 2:
     			     		output("`^Am Grund des Glases findest Du `#1 Edelstein`^!`3");
     			     		$session[user][gems]+=1;
     			    		break;
      			     		case 3:
      			     		output("`^Das tat gut!");
      			     		break;
      			     		case 4:
      			     		output("`^Das tat gut!");
       			     		break;
       			     		case 5:
       			     		output("`^Das tat gut!");
       			     		break;
			     		case 6:
           		    	     		output("`^Das tat gut!");
   		                     		break;
  		            	     		case 7:
          		       	     		output("`3Du trinkst zu hastig, verschluckst Dich, beginnst zu husten und st��t Dir den Kopf am Regal!");
			     		output("`4Du verlierst einige Lebenspunkte!");
		        	     		$session[user][hitponits]*=0.9;
        	       		     		break;
    	        		     		case 8:
    	           		     		output("`^Das tat gut!");
  	                  	     		break;
	            		    		case 9:
        	       		     		output("`^Das tat gut!");
         	       		     		break;
   	            		     		case 10:
       		       	     		output("`^Das tat gut!");
     		       	     		break;
    	        		     		case 11:
        	       		     		output("`^Das tat gut!");
  	               		     		break;
  	            		     		case 12:
 	              		     		output("`^Das tat gut!");
           	      		     		break;
    		    	     		case 13:
    		      	     		output("`^Das tat gut!");
    		     	     		break;
    		   	     		case 14:
     		       	     		output("`3Als Du das Glas zur�ck stellst, findest Du ein Versteck mit `^Gold`3!");
        	       		     		$session[user][gold]+=200;
     		       	     		break;
      		    	     		case 15:
      		       	     		output("`^Das tat gut!");
      		       	     		break;
      		    	     		case 16:
      		       	     		output("`^Das tat gut!");
       		       	     		break;
       		    	     		case 17:
       		       	     		output("`^Das tat gut!");
       		       	     		break;
	                       	     		case 18:
           	       	       	     		output("`^Du f�hlst Dich herrlich erfrischt und k�nntest jetzt noch ein Monster mehr erschlagen!");
        	       	       	     		$session[user][turns]+=1;
   	               		     		break;
  	            		     		case 19:
          	       		     		output("`^Das tat gut!");
        	       		     		break;
    	        		     		case 20:
    			     		output("`^Das tat gut!");
  	               		     		break;
	            		     		case 21:
          	       		     		output("`3Du trinkst zu hastig, verschluckst Dich, beginnst zu husten und st��t Dir den Kopf am Regal!");
			     		output("`4Du verlierst einige Lebenspunkte!");
        	       		     		$session[user][hitponits]*=0.9;
   	            		     		case 22:
       		       	     		output("`^Das tat gut!");
     		       	     		break;
    	            		     		case 23:
        	       		     		output("`^Das tat gut!");
  	               		     		break;
  	            		     		case 24:
 	              		    		output("`^Du f�hlst Dich gekr�ftigt!");
        	       		    	 	$session[user][hitponits]+=50;
           	      		    		break;
			    		}
			addnav("Zur�ck zur K�che","houses.php?op=drin&act=kueche");
	}else if ($_GET[act]=="frueh"){
		output("`n`3Du kochst frischen `%Tee `3und`n`n");
			$rand1 = e_rand(1,10);
				switch ($rand1){
    					case 1:
    					output("`3machst frisches `^R�`&hr`^ei`3, dazu `TBrot `3mit `5Schinken`3.");
    					break;
    					case 2:
     					output("`3deckst den Tisch mit `TBrot`3, `^Butter`3, `5Wurst `3und `6K�se`3.");
     					break;
      					case 3:
      					output("`3deckst den Tisch mit `tWei�brot`3, `^Butter `3und `4Marmelade`3!");
      					break;
      					case 4:
       					output("`3deckst den Tisch mit `TBrot`3, `^Butter `3und `6K�se`3.`n`n");
					output("`4Leider war der `6K�se`4 schon schlecht und Du `4verlierst einige Lebenspunkte!");
        	       				$session[user][hitpoints]*=0.9;
       					break;
       					case 5:
       					output("`3deckst den Tisch mit `TBrot`3, `^Butter`3, `4Marmelade `3und `6K�se`3.");
       					break;
	                			case 6:
           	                			output("`3deckst den Tisch mit `TBrot`3, `^Butter`3, `5Wurst`3 und `6K�se`3.");
   	                			break;
  	                			case 7:
          	       				output("`3deckst den Tisch mit `TBrot`3, `^Butter `3und `5Wurst`3.");
        	                			break;
    	        				case 8:
    	                			output("`3machst frisches `&Sp`^ie`&ge`^lei`3, dazu `TBrot `3mit `5Schinken`3.");
  	                			break;
	                			case 9:
        	       				output("`3machst frisches `&Sp`^ie`&ge`^lei`3, dazu `TBrot `3mit `5Wurst`3.");
         	       				break;
   	                			case 10:
       					output("`3machst hart gekochte `&E`^i`&e`^r`3, dazu `TBrot `3mit `4Marmelade`3.");
     					break;
    	        				case 11:
        	       				output("`3machst hart gekochte `&E`^i`&e`^r`3, dazu `TBrot `3mit `6K�se`3.");
  	                			break;
  	                			case 12:
 	                			output("`3machst hart gekochte `&E`^i`&e`^r`3, dazu `TBrot `3mit `5Wurst`3.");
           	      				break;
    					case 13:
    					output("`3machst frisches `&Sp`^ie`&ge`^lei`3, dazu `TBrot `3mit `6K�se`3.");
    					break;
    					case 14:
     					output("`3deckst den Tisch mit frischem `@O`qb`^s`4t`3, `TSchwarzbrot `3und `6K�se`3!");
					output("`3Die `^G�tter`3 finden das gesunde Essen sehr lobenswert und schenken Dir `^100 Gold`3!");
        	       				$session[user][gold]+=100;
     					break;
      					case 15:
      					output("`3deckst den Tisch mit `TBrot`3, `^Butter `3und `5Schinken`3.");
      					break;
      					case 16:
      					output("`3deckst den Tisch mit `4Marmelade`3, `6Honig`3, `TBrot `3und `^Butter`3.");
       					break;
       					case 17:
       					output("`3deckst den Tisch mit `TBrot`3, `^Butter `3und `6K�se`3.");
					output("`4Leider war der `6K�se`4 schon schlecht und Du verlierst einige Lebenspunkte!`3");
        	       				$session[user][hitpoints]*=0.9;
       					break;
	                			case 18:
           	       				output("`3deckst den Tisch mit allem, was die K�che hergibt: @O`qb`^s`4t`3, `&E`^i`&e`^r`3, `6K�se`3, `^Butter`3, `5Schinken `3und `5Wurst`3.");
					output("`^Nach dem Fr�hst�ck f�hlst Du dich gest�rkt und k�nntest noch ein Monster mehr erschlagen!`3");
        	       				$session[user][turns]+=1;
   	                			break;
  	                			case 19:
          	       				output("`3deckst den Tisch mit `TBrot`3, `^Butter `3und `6K�se.`3");
        	       				break;
    	        				case 20:
    	           				output("`3machst hart gekochte `&E`^i`&e`^r`3, dazu `TBrot `3mit `4Marmelade `3und frisches @O`qb`^s`4t`3.");
  	                			break;
	               				case 21:
        	       				output("`3machst frisches `^R�`&hr`^ei`3, dazu `TBrot `3mit `5Wurst`3.");
         	       				break;
   	                			case 22:
       					output("`3machst frisches `^R�`&hr`^ei`3, dazu `TBrot `3mit `6K�se`3.");
     					break;
    	                			case 23:
        	       				output("`3machst frisches `^R�`&hr`^ei`3, dazu `TBrot `3mit `6K�se`3 und `5Schinlken`3.");
  	                			break;
  	                			case 24:
 	              				output("`3deckst den Tisch mit frischem @O`qb`^s`4t`3, dazu `TBrot `3mit `6Honig`3.");
					output("`^Du f�hlst Dich gekr�ftigt!`3");
        	       				$session[user][hitpoints]+=50;
           	      				break;
					}
			addnav("Zur�ck zur K�che","houses.php?op=drin&act=kueche");
	}else if ($_GET[act]=="mittag"){
		output("`n`3Du beschlie�t, heute mal das Mittagessen zu machen, schwingst den Kochl�ffel und`n`n");
			$rand1 = e_rand(1,24);
     				switch ($rand1){
    		    			case 1:
    		    			output("`3kochst einen leckeren `6Maisbrei`3.");
    		    			break;
    		    			case 2:
     		    			output("`3bereitest einen leckeren `@Gurkensalat`3.`n`n");
		    			output("`^Als Du die Gurke aufschneidest, findest Du `# 1 Edelstein`3.");
     		    			$session[user][gems]+=1;
     		    			break;
      		    			case 3:
      		    			output("`3machst einen leckeren `6Hirsebrei`3.");
      		    			break;
      		    			case 4:
      		    			output("`3machst einen leckeren `&Grie�brei`3.");
       		    			break;
       		    			case 5:
       		    			output("`3machst einen leckeren `&Grie�brei `3mit frischen `4Kirschen`3.");
       		    			break;
	            	    			case 6:
           	       	    			output("`3machst einen leckeren `&Grie�brei `3mit frischen `@�pfeln`3.");
   	                    			break;
  	            	    			case 7:
          	       	    			output("`3kochst einen `6Maisbrei`3, doch leider war der Mais schon leicht verfault.`n`n");
		    			output("`4Du verlierst einige Lebenspunkte!");
        	       	    			$session[user][hitpoints]*=0.9;
        	       	    			break;
    	        	    			case 8:
    	           	    			output("`3kochst frischen `2Gr�nkohl`3, dazu gibt es `TBrot`3.");
  	                    			break;
	            	    			case 9:
        	       	    			output("`3br�tst ein `tKaninchen`3, dazu gibt es `TBrot`3.");
         	       	    			break;
   	            	    			case 10:
       		    			output("`3br�tst ein `tHuhn`3, dazu gibt es `TBrot`3.");
     		    			break;
    	            	    			case 11:
        	       	    			output("`3kochst `2Erbsen`3, `qM�hren `3und `TSchwarzwurzeln`3.");
  	               	    			break;
  	            	    			case 12:
 	              	    			output("`3kochst einen leckeren `6Maisbrei`3, dazu gebratenes `tHuhn`3!");
           	      	    			break;
    		    			case 13:
    		    			output("`3machst einen `6Hirsebrei`3, dazu gibt es frisches `TBrot`3.");
    		    			break;
    		    			case 14:
     		    			output("`3br�tst einen `tTruthahn`3, in dessen Magen Du beim Ausnehmen `^100 Gold`3 findest.");
        	       	    			$session[user][gold]+=100;
     		    			break;
      		    			case 15:
      		    			output("`3kochst ein `@Apfelmus `3aus frischen `@�pfeln`3.");
      		    			break;
      		    			case 16:
      		    			output("`3kochst eine `#Wassersuppe `3mit `TBrot`3.");
       		    			break;
       		    			case 17:
       		    			output("`3kochst eine `6Rinderbr�he`3.");
       		    			break;
	                    			case 18:
           	       	    			output("`3br�tst zwei `tRebh�hner`3, dazu machst Du `tKn�del`3!`n`n");
		    			output("`^Nach diesem Mahl k�nntest Du noch ein Monster mehr erschlagen!");
        	       	    			$session[user][turns]+=1;
   	               	    			break;
  	            	    			case 19:
          	       	    			output("`3kochst gef�llte `tKl��e `3mit `tSo�e`3.");
        	       	    			break;
    	            	    			case 20:
    	        	    			output("`3kochst eine `6H�hnersuppe`3.");
  	               	    			break;
	            	    			case 21:
          	       	    			output("`3br�tst ein `tHuhn`3. Weil Du so gierig schlingst, schluckst Du einen H�hnerknochen, den Du grade noch aushusten kannst.`n`n");
		    			output("`4Du verlierst einige Lebenspunkte!");
        	       	    			$session[user][hitpoints]*=0.5;
   	            	    			case 22:
       		    			output("`3br�tst `&Spie`^g`&eleier `3mit `4Speck`3.");
     		    			break;
    	        	    			case 23:
        	       	    			output("`3kochst eine `tBiersuppe`3!");
		    			$session[user][drunkenness]+=10;
  	               	    			break;
  	                    			case 24:
 	                    			output("`3kochst eine `gGem�sesuppe`3 mit frischem `gGem�se`3.`n`n");
		    			output("`^Du f�hlst Dich gekr�ftigt!");
        	      	    			$session[user][hitpoints]+=50;
           	                    			break;
					}
			addnav("Zur�ck zur K�che","houses.php?op=drin&act=kueche");
	}else if ($_GET[act]=="abend"){
		output("`n`3Du kochst frischen `%Tee`3 und`n`n");
			$rand1 = e_rand(1,10);
     				switch ($rand1){
    		    			case 1:
    		        			output("`3machst frisches `^R�`&hr`^ei`3, dazu `TBrot `3mit `5Schinken`3.");
    		        			break;
    		    			case 2:
     		       			output("`3deckst den Tisch mit `TBrot`3, `^Butter`3, `5Wurst `3und `6K�se`3.");
     		       			break;
      		    			case 3:
      		       			output("`3deckst den Tisch mit `tWei�brot`3, `^Butter `3und `6K�se`3!");
      		       			break;
      		    			case 4:
       		       			output("`3deckst den Tisch mit `TBrot, `^Butter `3und `6K�se`3.`n`n");
					output("`4Leider war der `6K�se`4 schon schlecht und Du verlierst einige Lebenspunkte!");
        	       				$session[user][hitponits]*=0.9;
       		       			break;
       		    			case 5:
       		       			output("`3deckst den Tisch mit `TBrot`3, `^Butter`3, `2Gurken `3und `6K�se`3.");
       		       			break;
	            				case 6:
           	       				output("`3deckst den Tisch mit `TBrot, `&Kren`3, `^Butter `3und `6K�se`3.");
   	               				break;
  	            				case 7:
          	       				output("`3deckst den Tisch mit `TBrot`3, `^Butter `3und `5Wurst`3.");
        	       				break;
    	        				case 8:
    	           				output("`3machst frisches `&Sp`^ie`&ge`^lei`3, dazu `TBrot `3mit `5Schinken`3.");
  	               				break;
	            				case 9:
        	       				output("`3machst frisches `&Sp`^ie`&ge`^lei`3, dazu `TBrot `3mit `5Wurst`3.");
         	       				break;
   	            				case 10:
       		       			output("`3machst hart gekochte `&E`^i`&e`^r`3, dazu `TBrot `3mit `5Schinken`3.");
     		       			break;
    	            				case 11:
        	       				output("`3machst hart gekochte `&E`^i`&e`^r`3, dazu `TBrot `3mit `6K�se`3.");
  	               				break;
  	            				case 12:
 	              				output("`3machst hart gekochte `&E`^i`&e`^r`3, dazu `TBrot `3mit `5Wurst`3.");
           	      				break;
    		    			case 13:
    		        			output("`3machst frisches `&Sp`^ie`&ge`^lei`3, dazu `TBrot `3mit `6K�se`3.");
    		        			break;
    		    			case 14:
     		       			output("`3deckst den Tisch mit frischem `@O`qb`^s`4t`3, `TSchwarzbrot `3und `6K�se`3.");
					output("`3Die `^G�tter`3 finden das gesunde Essen sehr lobenswert und schenken Dir `^100 Gold`3!");
        	       				$session[user][gold]+=100;
     		       			break;
      		    			case 15:
      		       			output("`2deckst den Tisch mit Brot, Butter und `5Schinken`2.");
      		       			break;
      		    			case 16:
      		      			output("`2deckst den Tisch mit Wassersuppe, Brot und Butter.");
       		       			break;
       		    			case 17:
       		       			output("`2deckst den Tisch mit Brot, Butter und `6K�se`2. Leider war der `6K�se`2 schon `5schlecht!");
        	       				$session[user][hitponits]*=0.9;
       		       			break;
	            				case 18:
           	       				output("`2mit allem, was die K�che hergibt: Obst, `&Eier`2, `6K�se`2, Butter, `5Schinken `2und `5Wu`%r`5st`2. Nach dem Fr�hst�ck k�nntest Du noch ein Monster mehr erschlagen!");
        	       				$session[user][turns]+=1;
   	               				break;
  	            				case 19:
          	       				output("`2`2deckst den Tisch mit Brot, Butter und `6K�se`2 und Obst.");
        	       				break;
    	            				case 20:
    	               				output("`2machst hart gekochte `&Eier`2, dazu Brot mit `6K�se`2 und frisches Obst.");
  	               				break;
	            				case 21:
        	       				output("`2machst frisches `^R�hrei`2, dazu Brot mit `5Wu`%r`5st`2.");
         	       				break;
   	            				case 22:
       		       			output("`2machst frisches `^R�hrei`2, dazu Brot mit `6K�se`2.");
     		       			break;
    	            				case 23:
        	       				output("`2machst frisches `^R�hrei`2, dazu Brot mit `6K�se`2 und `5Schinken`2.");
  	               				break;
  	            				case 24:
 	              				output("`2deckst den Tisch mit frischem Obst, dazu Brot und Obst! Du f�hlst Dich gekr�ftigt");
        	       				$session[user][hitponits]+=50;
           	      				break;
				   }
			addnav("Zur�ck zur K�che","houses.php?op=drin&act=kueche");
// end items
	}else{
		output("`2`b`c$row[housename]`c`b`n");
		if ($row[description]) output("`0`c$row[description]`c`n");
		output("`2Du und deine Mitbewohner haben `^$row[gold]`2 Gold und `#$row[gems]`2 Edelsteine im Haus gelagert.`n");
		if (getsetting('activategamedate','0')==1) output("Wir schreiben den `^".getgamedate()."`2 im Zeitalter des Drachen.");
		output (" Es ist jetzt `^".getgametime()."`2 Uhr.`n");
		output ("An der hinteren Wand befindet sich ein `qoffener Kamin `2f�r kalte Tage.`n`n");
		viewcommentary("house-".$row[houseid],"Mit Mitbewohnern reden:`n",30,"sagt");
		output("`n`n`n<table width='100%' border='0'><tr><td width='40%'>`2`bDie Schl�ssel:`b `0</td><td width='60%'>`2`bExtra Ausstattung:`b</td></tr><tr><td valign='top'>",true);
		$sql = "SELECT items.*,accounts.acctid AS aid,accounts.name AS besitzer FROM items LEFT JOIN accounts ON accounts.acctid=items.owner WHERE value1=$row[houseid] AND class='Schl�ssel' ORDER BY id ASC";
		$result = db_query($sql) or die(db_error(LINK));
		for ($i=1;$i<=db_num_rows($result);$i++){
			$item = db_fetch_assoc($result);
			if ($item[besitzer]==""){
				output("`n`2$i: `4`i~~ verloren ~~`i`0");
			}else{
				output("`n`2$i: `&$item[besitzer]`0");
			}
			if ($item[aid]==$row[owner]) output(" *");
			if ($item['hvalue']>0 && $item['owner']>0) output("`n`i~~ schl�ft hier ~~`i");
		}
		output("`n`n`i* der Eigent�mer`i`n`n");
		if (db_num_rows(db_query("SELECT id FROM items WHERE owner=$row[owner] AND value1<>$row[houseid] AND hvalue>0 AND class='Schl�ssel'"))==0 && db_num_rows(db_query("SELECT acctid FROM accounts WHERE acctid=$row[owner] AND location=2"))>0) output("`n`iDer Eigent�mer schl�ft hier`i");
		output("</td><td valign='top'>",true);
		$sql = "SELECT * FROM items WHERE value1=$row[houseid] AND class='M�bel' ORDER BY class,id ASC";
		$result = db_query($sql) or die(db_error(LINK));
		for ($i=1;$i<=db_num_rows($result);$i++){
			$item = db_fetch_assoc($result);
			if ($item[name]=="Ledersofa") output("`n`6Ledersofa`0 (`i$item[description]`i)");
			if ($item[name]=="Ledersessel") output("`n`6Ledersessel`0 (`i$item[description]`i)");
			if ($item[name]=="Verzierter Schreibtisch") output("`n`6Verzierter Schreibtsisch`0 (`i$item[description]`i)");
			if ($item[name]=="Zimmerpflanze") output("`n`6Zimmerpflanze`0 (`i$item[description]`i)");
			if ($item[name]=="Gro�er Teppich") output("`n`6Gro�er Teppich`0 (`i$item[description]`i)");
			if ($item[name]=="Vase") output("`n`6Vase`0 (`i$item[description]`i)");
			if ($item[name]=="Kerzenst�nder") output("`n`6Kerzenst�nder`0 (`i$item[description]`i)");
			if ($item[name]=="Kasten") output("`n`6Kasten`0 (`i$item[description]`i)");
			if ($item[name]=="Bild") output("`n`6Bild`0 (`i$item[description]`i)");
			if ($item[name]=="Gem�lde Tetharion") output("`n`6Gem�lde Tetharion`0 (`i$item[description]`i)");
			if ($item[name]=="Schachspiel aus Edelholz") output("`n`6Schachspiel aus Edelholz`0 (`i$item[description]`i)");
			if ($item[name]=="Edler Wohnzimmerschrank") output("`n`6Edler Wohnzimmerschrank`0 (`i$item[description]`i)");
			if ($item[name]=="Wandteppich 'Welt Tetharions'") output("`n`6Wandteppich 'Welt Tetharions'`0 (`i$item[description]`i)");
			if ($item[name]=="Statue eines Drachen") output("`n`6Statue eines Drachen`0 (`i$item[description]`i)");
			if ($item[name]=="Uhr") output("`n`6Uhr`0 (`i$item[description]`i)");
			if ($item[name]=="Hundek�rbchen") output("`n`6Hundek�rbchen`0 (`i$item[description]`i)");
			if ($item[name]=="Wandregal") output("`n`6Wandregal`0 (`i$item[description]`i)");
			if ($item[name]=="Vorh�nge") output("`n`6Vorh�nge`0 (`i$item[description]`i)");
		}
		output("</td></tr></table>",true);
		addnav("Gold");
		addnav("Deponieren","houses.php?op=drin&act=givegold");
		addnav("Mitnehmen","houses.php?op=drin&act=takegold");
		addnav("Max mitnehmen","houses.php?op=drin&act=takemaxgold");
		addnav("Edelsteine");
		addnav("Deponieren","houses.php?op=drin&act=givegems");
		addnav("Mitnehmen","houses.php?op=drin&act=takegems");
		addnav("Zimmer");
		addnav("Gemeinschaftsraum","houses.php?op=drin&act=gemraum");
		addnav("K�che","houses.php?op=drin&act=kueche");
		addnav("Badezimmer","houses.php?op=drin&act=badezimmer");
		addnav("Schlafzimmer","houses.php?op=drin&act=privates");
		addnav("Privatgemach","houses_private.php");
		addnav("Zusatzraum","houses.php?op=drin&act=zusatzraum");
		addnav("In den Stall","houses.php?op=drin&act=stable");
		if ($session[user][house]==$session[housekey]){
			addnav("Schl�ssel");
			addnav("Vergeben","houses.php?op=drin&act=givekey");
			addnav("n?Zur�cknehmen","houses.php?op=drin&act=takekey");
		}
		addnav("Sonstiges");
		if ($session[user][house]==$session[housekey]){
			addnav("Haus umbenennen","houses.php?op=drin&act=rename");
			addnav("Beschreibung �ndern","houses.php?op=drin&act=desc");
		}
		addnav("W?Zur Wohnsiedlung","houses.php");
		addnav("S?Zum Stadtplatz","village.php");
	}
}else if ($_GET[op]=="enter"){
	output("`n`6Du hast Zugang zu folgenden H�usern:`n`n");
	$sql = "UPDATE items SET hvalue=0 WHERE hvalue>0 AND owner=".$session[user][acctid]." AND class='Schl�ssel'";
	db_query($sql) or die(sql_error($sql));
	$sql = "SELECT * FROM items WHERE owner=".$session[user][acctid]." AND class='Schl�ssel' ORDER BY id ASC";
	$result = db_query($sql) or die(db_error(LINK));
	output("<table cellpadding=2 align='center'><tr><td>`bHausNr.`b</td><td>`bName`b</td></tr>",true);
	$ppp=25; // Player Per Page +1 to display
	if (!$_GET[limit]){
		$page=0;
	}else{
		$page=(int)$_GET[limit];
		addnav("Vorherige Stra�e","houses.php?op=enter&limit=".($page-1)."");
	}
	$limit="".($page*$ppp).",".($ppp+1);
	if ($session[user][house]>0 && $session[user][housekey]>0){
		$sql = "SELECT houseid,housename FROM houses WHERE houseid=".$session[user][house]." ORDER BY houseid DESC LIMIT $limit";
		$result2 = db_query($sql) or die(db_error(LINK));
		$row2 = db_fetch_assoc($result2);
		output("<tr><td align='center'>$row2[houseid]</td><td><a href='houses.php?op=drin&id=$row2[houseid]'>$row2[housename]</a> (dein eigenes)</td></tr>",true);
		addnav("","houses.php?op=drin&id=$row2[houseid]");
	}else if ($session[user][house]>0 && $session[user][housekey]==0){
		output("<tr><td colspan=2 align='center'>`&`iDein Haus ist noch im Bau oder steht zum Verkauf`i`0</td></tr>",true);
	}
	if (db_num_rows($result)>$ppp) addnav("N�chste Seite","houses.php?op=enter&limit=".($page+1)."");
	if (db_num_rows($result)==0){
		output("<tr><td colspan=4 align='center'>`&`iDu hast keinen Schl�ssel`i`0</td></tr>",true);
	}else{
		$rebuy=0;
		for ($i=0;$i<db_num_rows($result);$i++){
			$item = db_fetch_assoc($result);
			if ($item[value1]==$session[user][house] && $session[user][housekey]==0) $rebuy=1;
			$bgcolor=($i%2==1?"trlight":"trdark");
			$sql = "SELECT houseid,housename FROM houses WHERE houseid=$item[value1] ORDER BY houseid DESC";
			$result2 = db_query($sql) or die(db_error(LINK));
			$row2 = db_fetch_assoc($result2);
			if ($amt!=$item[value1] && $item[value1]!=$session[user][house]){
				output("<tr class='$bgcolor'><td align='center'>$row2[houseid]</td><td><a href='houses.php?op=drin&id=$row2[houseid]'>$row2[housename]</a></td></tr>",true);
				addnav("","houses.php?op=drin&id=$row2[houseid]");
			}
			$amt=$item[value1];
		}
	}
	output("</table>",true);
	if ($rebuy==1) addnav("Verkauf r�ckg�ngig","houses.php?op=buy&id=".$session[user][house]."");
	if (getsetting("dailyspecial",0)=="Waldsee"){
		output("`n`n`6W�hrend du deine Schl�ssel suchst, f�llt dir ein kleiner Trampelpfad auf...");
		addnav("Trampelpfad","paths.php?ziel=forestlake");
	}
	addnav("S?Zum Stadtplatz","village.php");
	addnav("W?Zum Wohnviertel","houses.php");
}else{
	output("`q`b`cDas Wohnviertel`c`b`n");
	$session[housekey]=0;
	$sql = "SELECT * FROM items WHERE owner=".$session[user][acctid]." AND class='Schl�ssel' ORDER BY id ASC";
	$result2 = db_query($sql) or die(db_error(LINK));
	if (db_num_rows($result2)>0 || $session[user][housekey]>0) addnav("Haus betreten","houses.php?op=enter");
	output("`6Du verl�sst den Dorfplatz und schlenderst Richtung Wohnviertel. In diesem sch�n angelegten Teil des Dorfes siehst du einige Baustellen zwischen bewohnten ");
	output("und unbewohnten H�usern. Hier wohnen also die Helden ...`n`n");
	if ($_POST['search']>""){
		if ($_GET['search']>"" || $_GET['search']>"") $_POST['search']=$_GET['search'];
		if (strcspn($_POST['search'],"0123456789")<=1){
			$search="houseid=".intval($_POST[search])." AND ";
		}else{
			$search="%";
			for ($x=0;$x<strlen($_POST['search']);$x++){
				$search .= substr($_POST['search'],$x,1)."%";
			}
			$search="housename LIKE '".$search."' AND ";
		}
	}else{
		$search="";
	}
	$ppp=30; // Player Per Page +1 to display
	if (!$_GET[limit]){
		$page=0;
	}else{
		$page=(int)$_GET[limit];
		addnav("Vorherige Stra�e","houses.php?limit=".($page-1)."&search=$_POST[search]");
	}
	$limit="".($page*$ppp).",".($ppp+1);
	//$sql = "SELECT * FROM houses WHERE status<100 ORDER BY houseid ASC LIMIT $limit";
	
	//DOC JOKUS/TWEANS: Performancekillenden Schleifenquery entsorgt
	$sql = "SELECT houses.*,accounts.name AS schluesselinhaber FROM houses 
	LEFT JOIN accounts ON accounts.acctid=houses.owner 
	WHERE $search status<100 ORDER BY houseid ASC LIMIT $limit";
	output("<form action='houses.php' method='POST'>Nach Hausname oder Nummer <input name='search' value='$_POST[search]'> <input type='submit' class='button' value='Suchen'></form>",true);
	addnav("","houses.php");
	output("<table cellpadding=2 cellspacing=1 bgcolor='#999999' align='center'><tr class='trhead'><td>`bHausNr.`b</td><td>`bName`b</td><td>`bEigent�mer`b</td><td>`bStatus`b</td></tr>",true);
	$result = db_query($sql) or die(db_error(LINK));
	if (db_num_rows($result)>$ppp) addnav("N�chste Stra�e","houses.php?limit=".($page+1)."&search=$_POST[search]");
	if (db_num_rows($result)==0){
  		output("<tr><td colspan=4 align='center'>`&`iEs gibt noch keine H�user`i`0</td></tr>",true);
	}else{
		for ($i=0;$i<db_num_rows($result);$i++){
			$row = db_fetch_assoc($result);
			$bgcolor=($i%2==1?"trlight":"trdark");
			output("<tr class='$bgcolor'><td align='right'>$row[houseid]</td><td><a href='houses.php?op=bio&id=$row[houseid]'>$row[housename]</a></td><td>",true);
			addnav("","houses.php?op=bio&id=$row[houseid]");
	//DOC JOKUS/TWEANS: Performancekillenden Schleifenquery entsorgt

			output("$row[schluesselinhaber]</td><td>",true);
			if ($row[status]==0) output("`6im Bau`0");
			if ($row[status]==1) output("`!bewohnt`0");
			if ($row[status]==2) output("`^zum Verkauf`0");
			if ($row[status]==3) output("`4Verlassen`0");
			if ($row[status]==4) output("`\$Bauruine`0");
			output("</tr>",true);
		}
	}
	output("</table>",true);
	if ($session[user][housekey]) {
		output("`nStolz schwingst du den Schl�ssel zu deinem Haus im Gehen hin und her.");
	}
	if ($session[user][house] && $session[user][housekey]) {
		addnav("Haus verkaufen","houses.php?op=sell");
	} else {
		if (!$session[user][house] ) addnav("Haus kaufen","houses.php?op=buy");
		addnav("Haus bauen","houses.php?op=build");
	}
	if (getsetting("pvp",1)==1) addnav("Einbrechen","houses.php?op=einbruch");
	//if (@file_exists("well.php")) addnav("Dorfbrunnen","well.php");
	if ($session[user][superuser]) addnav("Admin Grotte","superuser.php");
	addnav("S?Zum Stadtplatz","village.php");
}
if ($fight){ 
	if (count($session[bufflist])>0 && is_array($session[bufflist]) || $HTTP_GET_VARS[skill]!=""){ 
		$HTTP_GET_VARS[skill]=""; 
		if ($HTTP_GET_VARS['skill']=="") $session['user']['buffbackup']=serialize($session['bufflist']); 
		$session[bufflist]=array(); 
		output("`&Die ungewohnte Umgebung verhindert den Einsatz deiner besonderen F�higkeiten!`0"); 
	} 
	include "battle.php"; 
	if ($victory){ 
		addnav("Weiter zum Haus","houses.php?op=einbruch2&id=$session[housekey]");
	addnav("S?Zum Stadtplatz","village.php");
	// check for pet
	if ($badguy['creaturename']=='Stadtwache') {
		output("`n`#Du hast die Stadtwache besiegt und der Weg zum Haus ist frei!`nDu bekommst ein paar Erfahrungspunkte.");
		$session['user']['experience'] += $session['user']['level']*10;
		$session['user']['turns']--;
	}
	else {
		output('`n`#'.$badguy['creaturename'].'`# zieht sich jaulend zur�ck und gibt den Weg zum Haus frei!');
	}

		$badguy=array();
	}elseif ($defeat){ 
		if ($badguy['creaturename']=='Stadtwache') {
		output("`n`\$Die Stadtwache hat dich besiegt. Du bist tot!`nDu verlierst 10% deiner Erfahrungspunkte, aber kein Gold.`nDu kannst morgen wieder k�mpfen."); 
		$session[user][hitpoints]=0; 
		$session[user][alive]=false;
		$session[user][experience]=round($session[user][experience]*0.9);
		$session[user][badguy]="";
		addnews("`%".$session[user][name]."`3 wurde von der Stadtwache bei einem Einbruch besiegt.");
		addnav("T�gliche News","news.php");
			}
	else {
		output('`n`$'.$badguy['creaturename'].'`$ hat dich besiegt. Du liegst schwer verletzt am Boden!`nDu verlierst 3 Charmepunkte und fast alle Lebenspunkte.');
		$session['user']['hitpoints'] = 1;
		$session['user']['charm'] -= 3;
		addnews("`%".$session['user']['name']."`3 stie� bei einem Einbruch auf unerwartete Gegenwehr und verletzte sich schwer.");
		addnav('Davonkriechen',"houses.php?op=leave");
	}

	}else{ 
		fightnav(false,true); 
	} 
}

page_footer();
?>GET_VARS[skill]!=""){ 
		$HTTP_GET_VARS[skill]=""; 
		if ($HTTP_GET_VARS['skill']=="") $session['user']['buffbackup']=serialize($session['bufflist']); 
		$session[bufflist]=array(); 
		output("`&Die ungewohnte Umgebung verhindert den Einsatz deiner besonderen F�higkeiten!`0"); 
	} 
	include "battle.php"; 
	if ($victory){ 
		addnav("Weiter zum Haus","houses.php?op=einbruch2&id=$session[housekey]");
	addnav("S?Zum Stadtplatz","village.php");
	// check for pet
	if ($badguy['creaturename']=='Stadtwache') {
		output("`n`#Du hast die Stadtwache besiegt und der Weg zum Haus ist frei!`nDu bekommst ein paar Erfahrungspunkte.");
		$session['user']['experience'] += $session['user']['level']*10;
		$session['user']['turns']--;
	}
	else {
		output('`n`#'.$badguy['creaturename'].'`# zieht sich jaulend zur�ck und gibt den Weg zum Haus frei!');
	}

		$badguy=array();
	}elseif ($defeat){ 
		if ($badguy['creaturename']=='Stadtwache') {
		output("`n`\$Die Stadtwache hat dich besiegt. Du bist tot!`nDu verlierst 10% deiner Erfahrungspunkte, aber kein Gold.`nDu kannst morgen wieder k�mpfen."); 
		$session[user][hitpoints]=0; 
		$session[user][alive]=false;
		$session[user][experience]=round($session[user][experience]*0.9);
		$session[user][badguy]="";
		addnews("`%".$session[user][name]."`3 wurde von der Stadtwache bei einem Einbruch besiegt.");
		addnav("T�gliche News","news.php");
			}
	else {
		output('`n`$'.$badguy['creaturename'].'`$ hat dich besiegt. Du liegst schwer verletzt am Boden!`nDu verlierst 3 Charmepunkte und fast alle Lebenspunkte.');
		$session['user']['hitpoints'] = 1;
		$session['user']['charm'] -= 3;
		addnews("`%".$session['user']['name']."`3 stie� bei einem Einbruch auf unerwartete Gegenwehr und verletzte sich schwer.");
		addnav('Davonkriechen',"houses.php?op=leave");
	}

	}else{ 
		fightnav(false,true); 
	} 
}

page_footer();
?>