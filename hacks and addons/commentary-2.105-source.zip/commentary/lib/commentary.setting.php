<?php
/**
 * Commentary: A Class which provides the rp-chat in logd
 * 
 * @author		Basilius Sauter
 * @copyright	2006-2009
 * @version		2.9
 * @package		commentary
 */

if(!defined('NOBIO')) {
	/**
	 * Hack, um den Biograpie-Link zu unterdr�cken
	 * @const NOBIO
	 */
	define('NOBIO',false);
}

/**
 * Kompabilit�tsmodus f�r alte LoGD's aktivieren. Meint zur Zeit vor allem, alte Wrapper-Funktionen brauchen
 * @const COMMENTARY_USE_COMPABILITY_MODE
 */
define('COMMENTARY_USE_COMPABILITY_MODE', true);

/**
 * Cache-Funktionalit�t aktivieren
 * @const COMMENTARY_USE_CACHED_QUERIES
 */
define('COMMENTARY_USE_CACHED_QUERIES', false);

/**
 * Angabe der Spaltenzahl f�r Textareas
 * @const COMMENTARY_TEXTAREA_COLS
 */
define('COMMENTARY_TEXTAREA_COLS', 50);

/**
 * Angabe der Zeilenzahl f�r Textareas
 * @const COMMENTARY_TEXTAREA_ROWS
 */
define('COMMENTARY_TEXTAREA_ROWS', 3);

/**
 * Fontfamliy-CSS-Attribut f�r die Textarea
 * @const COMMENTARY_TEXTAREA_FONTFAMILY
 */
define('COMMENTARY_TEXTAREA_FONTFAMILY', 'sans');

/**
 * Anzahl �brig bleibender Zeichen anzeigeh?
 * @const COMMENTARY_TEXTAREA_SHOWCHARS
 */
define('COMMENTARY_TEXTAREA_SHOWCHARS', false);

/**
 * Gr�sse des Input-Feldes f�r die Zeichenanzeige in Zeichen
 * @const COMMENTARY_SHOWCHARS_SIZE
 */
define('COMMENTARY_SHOWCHARS_SIZE', 7);

/**
 * Gr�sse des Input-Feldes f�r den Chatpost in Zeichen
 * @const COMMENTARY_INPUTFIELD_SIZE
 */
define('COMMENTARY_INPUTFIELD_SIZE', 50);

/**
 * Automatische Textarea
 * @const COMMENTARY_AUTOTEXTAREA
 */
define('COMMENTARY_AUTOTEXTAREA',  true);

/**
 * Textarea an?
 * @const COMMENTARY_ACTIVETEXTAREA
 */
define('COMMENTARY_ACTIVETEXTAREA',  false);


/**
 * Anzahl Zeichen, bei der im Autotextarea-Modus die Textarea angezeigt werden soll
 * @const COMMENTARY_AUTEXTAREA_CHARS
 */
define('COMMENTARY_AUTEXTAREA_CHARS',  200);

/**
 * Standardlimite f�r angezeigte Posts
 * @const COMMENTARY_DEFAULTLIMIT
 */
define('COMMENTARY_DEFAULTLIMIT', 7);

/**
 * Standardsprechprefix ($user >>sagt<<: "")
 * @const COMMENTARY_DEFAULTTALKLINE
 */
define('COMMENTARY_DEFAULTTALKLINE', 'sagt');

/**
 * Standard�berschrift f�r den Chat
 * @const COMMENTARY_DEFAULTMESSAGE
 */
define('COMMENTARY_DEFAULTMESSAGE', 'Spiele hier Rollenspiel:'); # Standard�berschrift f�r den Chat

/**
 * Maximale Zeichenanzahl je Post
 * @const COMMENTARY_MAXLENGHT
 */
define('COMMENTARY_MAXLENGHT', 2000);

/**
 * Paragraphen-Tags verwenden?
 * @const COMMENTARY_USEPARAGRAPHS
 */
define('COMMENTARY_USEPARAGRAPHS', true);

/**
 * Abs�tze in Chats erlauben (\n)
 * @const COMMENTARY_INPUTFIELD_SIZE
 */
define('COMMENTARY_ALLOWPARAGRAPHS', true);

/**
 * Markieren von Abs�tzen mithilfe eines Extra-Charakters erlauben (f�r Einzeilfelder..)
 * @const COMMENTARY_MANUALPARAGRAPHCHAR
 * @todo Auch verwenden, haha..
 */
define('COMMENTARY_MANUALPARAGRAPHCHAR', '\n');

/**
 * Zwischenabst�nde zwischen einzelnen Posts, wenn Paragraphen benutzt werden
 * @const COMMENTARY_PARAGRAPHS_MARGIN
 */
define('COMMENTARY_PARAGRAPHS_MARGIN', 1);

/**
 * Zeilenh�he f�r die Posts
 * @const COMMENTARY_LINEHEIGHT
 */
define('COMMENTARY_LINEHEIGHT', 1.15);

/**
 * Ist der Farbmod (�Farben-in-der-Datenbank�) installiert?
 * @const COMMENTARY_FARBHACK_IS_INSTALLED
 */
define('COMMENTARY_FARBHACK_IS_INSTALLED', false);

/**
 * Anzeigetyp f�r die Navigation: anchor, button, fakebutton
 * @const COMMENTARY_NAVIGATION_DISPLAYTYPE
 */
define('COMMENTARY_NAVIGATION_DISPLAYTYPE', 'anchor');

/**
 * Navigationsanzeige: oben (top), unten (bottom) oder an beiden Orten (both)?
 * @const COMMENTARY_NAVIGATION_POSITION
 */
define('COMMENTARY_NAVIGATION_POSITION', 'bottom');

/**
 * Navigation: Verwende "Letzte Kommentare" und "Neuste"
 * @const COMMENTARY_NAVIGATION_USE_SKIPLINKS
 */
define('COMMENTARY_NAVIGATION_USE_SKIPLINKS', true);

/**
 * Exportieren von geposteten Kommentaren erlauben?
 * @const COMMENTARY_GUILDTAG_DISPLAY
 */
define('COMMENTARY_ALLOW_EXPORT', false);

/**
 * RP-Speichern-Link-Position: oben (top), unten (bottom) oder an beiden Orten (both)?
 * @const COMMENTARY_EXPORTLINK_POSITION
 */
define('COMMENTARY_EXPORTLINK_POSITION', 'bottom');

/**
 * Verwendete, typographisch-korrekte Anf�hrungs- und Schlusszeichen.
 * 	english => Anf�hrungszeichen oben und oben
 *  german => Anf�hrungszeichen unten und oben
 * 	french => Guillemets mit Leerschlag vor und nachher
 * 	swiss-guillemets => Guillemets offen-zu (Without spaces!)
 *  german-guillemets => Guillemets zu-offen (Without spaces!)
 * @const COMMENTARY_QUOTATION_TYPE 
 */
define('COMMENTARY_QUOTATION_TYPE', 'swiss-guillemets');

/**
 * Chatvorschau verwenden?
 * @const COMMENTARY_USE_CHATPREVIEW
 */
define('COMMENTARY_USE_CHATPREVIEW', true);

/**
 * Zeit anzeigen?
 * @const COMMENTARY_TIMESTAMP_DISPLAY
 */
define('COMMENTARY_TIMESTAMP_DISPLAY', true);

/**
 * Zeitanzeigetyp
 * @const COMMENTARY_TIMESTAMP_TYPE
 */
define('COMMENTARY_TIMESTAMP_TYPE', '');

/**
 * Zeitanzeigeformat (Identisch zu date())?
 * @const COMMENTARY_TIMESTAMP_FORMAT
 */
define('COMMENTARY_TIMESTAMP_FORMAT', 'G:i');

/**
 * Gildentag-Version (dashguild, eliguild, eliguildv2)
 * @const COMMENTARY_GUILDTAG_VERSION
 */
define('COMMENTARY_GUILDTAG_VERSION', '');

/**
 * Gildentags anzeigen?
 * @const COMMENTARY_GUILDTAG_DISPLAY
 */
define('COMMENTARY_GUILDTAG_DISPLAY', false);

/**
 * Template f�r den HTML-Link zur Biographie, {LOGIN}, {REQUESTURI}, {ACCTID}, {NAME}, {POPUP}
 * @const COMMENTARY_BIO_LINKTEMPLATE
 */
define('COMMENTARY_BIO_LINKTEMPLATE', "`0<a href=\"bio.php?char={LOGIN}&ret={REQUESTURI}\" style=\"text-decoration: none\">\r\n`&{NAME}`0</a>\r\n"); # Der Link mit Name (Anzeige) f�r die Bio. Geparst wird: {LOGIN}, {REQUESTURI}, {ACCTID}, {NAME}, {POPUP}

/**
 * Template f�r den Link selbst (f�r die Whitelist), geparst wird {LOGIN}, {REQUESTURI}, {ACCTID}
 * @const COMMENTARY_BIO_LINK
 */
define('COMMENTARY_BIO_LINK', 'bio.php?char={LOGIN}&ret={REQUESTURI}'); # Der reine Link (Whiteliste der Navigation) f�r die Bio. Geparst wird: {LOGIN}, {REQUESTURI}, {ACCTID}

/**
 * Level, das f�r das "Live-L�schen" gebraucht wird (L�schlink vor jedem Kommentar, egal ob eigen oder nicht)
 * @const COMMENTARY_LIVEDELETING_SULEVEL
 */
define('COMMENTARY_LIVEDELETING_SULEVEL', 3);

/**
 * Zielort f�r das Livedeleting
 * @const COMMENTARY_LIVEDELETING_DELETETARGET
 */
define('COMMENTARY_LIVEDELETING_DELETETARGET', 'superuser.php?op=commentdelete');

/**
 * F�r Admins den Schreiber eines /X-Emotes entlarven?
 * @const COMMENTARY_DISPLAYEMOTLERNAME
 */
define('COMMENTARY_DISPLAYEMOTLERNAME', true);

/**
 * Mindest-Sulevel, das gebraucht wird, um diese Anzeige sehen zu k�nnen
 * @const COMMENTARY_DISPLAYEMOTLERNAME_SULEVEL
 */
define('COMMENTARY_DISPLAYEMOTLERNAME_SULEVEL', 2); # 

/**
 * Verwende RP-Punkte-Verteilung. False f�r keine-Verwendung, ansonsten einer der folgenden Werte, je nach RP-Punkte-Verteilungssystem:
 * 	engelsreich => F�r Engelsreich-RP-Punkte,
 *  luzifel => F�r Luzifels System,
 *  wintertal => F�r das Wintertal-System,
 *  silienta => F�r das Silienta-System
 * @const COMMENTARY_USE_RPPOINTS
 */
define('COMMENTARY_USE_RPPOINTS', false);

/**
 * Verwende RP-CMD. false f�r keine-Verwendung, aonsten einer der folgenden Werte, je nach gew�nschtem System:
 *  meteora => Meteoras RPCMD-System
 * @const COMMENTARY_USE_RPCMD
 */
define('COMMENTARY_USE_RPCMD', false);

/**
 * Mindest-Userlevel um Admin-RPCMD's verwenden zu k�nnen
 * @const COMMENTARY_RPCMD_SULEVEL
 */
define('COMMENTARY_RPCMD_SULEVEL', 3);

# Wenn Farbhack installiert ist, Farben vom Farbhack holen.
if(COMMENTARY_FARBHACK_IS_INSTALLED === true) {
	$var = $appoencode_str;
}
# Wenn nicht, Standardfarben nehmen
else {
	$var = '123456789!@#$%&QqRr*~^?VvGgTtAa';
}

/**
 * Mindest-Sulevel, das gebraucht wird, um diese Anzeige sehen zu k�nnen
 * @const COMMENTARY_DISPLAYEMOTLERNAME_SULEVEL
 */
define('COMMENTARY_ALLOWEDTAGS', $var);


// Support f�r wz_tooltip,  ab Version 4.12 garantiert
if(COMMENTARY_TIMESTAMP_TYPE == 'wz_tooltip') {
	#define('COMMENTARY_TOOLTIP_PATH', getsetting('COMMENTARY_TOOLTIP_PATH', 'wz_tooltip.js'));
}

if(!defined('ER_NAV_EXTRA')) {
	define('ER_NAV_EXTRA', $session['counter']."-".date("His"));
}
?>
