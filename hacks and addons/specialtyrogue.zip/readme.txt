To install just place specialtyrogue.php and robbank.php into your green dragon 
modules folder, then install the modules in the superusergrotto.
Credits go out to the original authors and Todd!
What was changed:
in the rob bank module you now have to have the rogue specialty in order
to rob the bank. The reasoning behind it was that not all classes would
behave in such a manner :)
