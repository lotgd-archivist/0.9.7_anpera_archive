<?php
/*

This is part of a series of specialties I'm making to recreate the core D&D classes in LoGD.
This also works well as a basic drop-in specialty because the core specialties are basically
a thief, and two magic users.  The game really needs a basic Fighter specialty, IMO.

-- Enderandrew
Since Enderandrew never got around to it, the Rogue specialty was created using his fighter specialty as a basis. 
*/

function specialtyrogue_getmoduleinfo(){
	$info = array(
		"name" => "Specialty - Rogue",
		"author" => "Miskatonic",
		"version" => "1.0",
		"download" => "https://dragonprime-reborn.ca/",
		"vertxtloc"=>"https://dragonprime-reborn.ca/ucp.php?sid=9508e77d9721b02e444e873477b47e8e",
		"category" => "Specialties",
		"description"=>"This adds a D&D inspired Rogue specialty to the game.",
		"prefs" => array(
			"Specialty - Rogue User Prefs,title",
			"skill"=>"Skill points in Rogue Feats,int|0",
			"uses"=>"Uses of Rogue Feats allowed,int|0",
		),
		"settings"=> array(
			"Specialty - Rogue Settings,title",
			"mindk"=>"How many DKs do you need before the specialty is available?,int|5",
			"cost"=>"How many points do you need before the specialty is available?,int|5",
		),
	);
	return $info;
}

function specialtyrogue_install(){
	$specialty="RO";
	module_addhook("apply-specialties");
	module_addhook("castlelib");
	module_addhook("castlelibbook");
	module_addhook("choose-specialty");
	module_addhook("dragonkill");
	module_addhook("fightnav-specialties");
	module_addhook("incrementspecialty");
	module_addhook("newday");
	module_addhook("pointsdesc");
	module_addhook("set-specialty");
	module_addhook("specialtycolor");
	module_addhook("specialtymodules");
	module_addhook("specialtynames");
	return true;
}

function specialtyrogue_uninstall(){
	// Reset the specialty of anyone who had this specialty so they get to
	// rechoose at new day
	$sql = "UPDATE " . db_prefix("accounts") . " SET specialty='' WHERE specialty='RO'";
	db_query($sql);
	return true;
}

function specialtyrogue_dohook($hookname,$afis){
	global $session,$resline;
	tlschema("fightnav");

	$spec = "RO";
	$name = "Rogue Feats";
	$ccode = "`2";
	$cost = get_module_setting("cost");
	$op69 = httpget('op69');

	switch ($hookname) {

	case "apply-specialties":
		$skill = httpget('skill');
		$l = httpget('l');
		if ($skill==$spec){
			if (get_module_pref("uses") >= $l){
				switch($l){
				case 1:
					apply_buff('ro1', array(
						"startmsg"=>"`2You scan the area, on the search for an easy mark.  It's time to sneak around that target!",
						"name"=>"`@Backstab",
						"rounds"=>5,
						"wearoff"=>"You just can't seem to manuever around the target...",
						"effectmsg"=>"`@With cat-like agility you manuever around and backstab `^{badguy}`6 for `^{damage}`) points.",
						"effectnodmgmsg"=>"`@You try to manuever around {badguy}, but he catches on and stays fascing you!",
						"atkmod"=>1.5,
						"schema"=>"specialtyrogue"
					));
					break;
				case 2:
					apply_buff('ro2', array(
						"startmsg"=>"`2Your finely-honed reflexes allows you to react quickly and avoid the brunt of a strike.",
						"name"=>"`@Uncanny Dodge",
						"rounds"=>5,
						"wearoff"=>"Your begin to slow down.",
						"effectmsg"=>"`@You quickly jump on {badguy} and strike for {damage} damage.",
						"defmod"=>1.6,
						"schema"=>"specialtyrogue"
					));
					break;
				case 3:
					apply_buff('ro3', array(
						"startmsg"=>"`2Your pour knowledge of exploits alows you to target weak points in {badguy}'s weaponry and armor.",
						"name"=>"`@Reliable Talent",
						"rounds"=>5,
						"wearoff"=>"{badguy} seems to catch on to what you are doing.",
						"effectmsg"=>"`@You target {badguy}'s weakened armor and strike for {damage} damage.",
						"effectnodmgmsg"=>"`@Despite {badguy}'s weakened armor, you still MISS!",
						"badguydefmod"=>0.5,
						"badguyatkmod"=>0.5,
						"schema"=>"specialtyrogue"
					));
					break;
				case 5:
					apply_buff('ro5', array(
						"startmsg"=>"`2You have secretly studied the environment and have deduced a way to end the fight once and for all.",
						"name"=>"`@Dirty Fighting",
						"rounds"=>3,
						"wearoff"=>"You give it your all and are spent...",
						"effectmsg"=>"`@Quicky grab some dirt and throw it in `^{badguy}`6's eyes and strike while they are blind for `^{damage}`) points.",
						"effectnodmgmsg"=>"`@Perhaps you overestimated the target and because {badguy} saw it coming!",
						"badguydefmod"=>0.5,
						"atkmod"=>10.5,
						"schema"=>"specialtyrogue"
					));
					break;
				}
				set_module_pref("uses", get_module_pref("uses") - $l);
			}else{
				apply_buff('ro0', array(
					"startmsg"=>"Looks can be decieving, your eyes scan your opponent as you size them up.",
					"rounds"=>1,
					"schema"=>"specialtyrogue"
				));
			}
		}
		break;

	case "castlelib":
		if ($op69 == 'rogue'){
			output("You sit down and open up the book Way of the Rogue.`n");
			output("You read for a while... in the time it takes you to read you use up`n");
			output("3 Turns.`n`n");
			output("To learn the way of the rogue is to learn exploits, and although you can't do so simply by reading `n");
			output("a book, it sure does help--especially if that book is Way of the Rogue.  Unlike it's more`n");
			output("famous cousin, Unconventional Fighting, this book doesn't deal with vague general strategies.  This is a`n");
			output("fairly specific treatise on the art of dirty fighting.`n");
			output("`@You become more skilled as a Rogue!`n");
			$session['user']['turns']-=3;
			set_module_pref('skill',(get_module_pref('skill','specialtyrogue') + 1),'specialtyrogue');
			set_module_pref('uses', get_module_pref("uses",'specialtyrogue') + 1,'specialtyrogue');
			addnav("Continue","runmodule.php?module=lonnycastle&op=library");
			}
		break;

	case "castlelibbook":
		output("Way of the Rogue. (3 Turns)`n");
		addnav("Read a Book");
		addnav("Way of the Rogue","runmodule.php?module=lonnycastle&op=library&op69=rogue");
		break;

	case "choose-specialty":
		if ($session['user']['dragonkills']>=get_module_setting("mindk")) {
			if ($session['user']['specialty'] == "" ||
				$session['user']['specialty'] == '0') {
				addnav("$ccode$name`0","newday.php?setspecialty=".$spec."$resline");
				$t1 = translate_inline("Using exploits and dirty tactics");
				$t2 = appoencode(translate_inline("$ccode$name`0"));
				rawoutput("<a href='newday.php?setspecialty=$spec$resline'>$t1 ($t2)</a><br>");
				addnav("","newday.php?setspecialty=$spec$resline");
			}
		}
		break;

	case "dragonkill":
		set_module_pref("uses", 0);
		set_module_pref("skill", 0);
		break;

	case "fightnav-specialties":
		$uses = get_module_pref("uses");
		$script = $afis['script'];
		if ($uses > 0) {
			addnav(array("%s%s (%s points)`0", $ccode, $name, $uses), "");
			addnav(array("%s &#149; Backstab`7 (%s)`0", $ccode, 1), 
					$script."op=fight&skill=$spec&l=1", true);
		}
		if ($uses > 1) {
			addnav(array("%s &#149; Uncanny Dodge`7 (%s)`0", $ccode, 2),
					$script."op=fight&skill=$spec&l=2",true);
		}
		if ($uses > 2) {
			addnav(array("%s &#149; Reliable Talent`7 (%s)`0", $ccode, 3),
					$script."op=fight&skill=$spec&l=3",true);
		}
		if ($uses > 4) {
			addnav(array("%s &#149; Dirty Fighting`7 (%s)`0", $ccode, 5),
					$script."op=fight&skill=$spec&l=5",true);
		}
		break;

	case "incrementspecialty":
		if($session['user']['specialty'] == $spec) {
			$new = get_module_pref("skill") + 1;
			set_module_pref("skill", $new);
			$c = $afis['color'];
			output("`n%sYou gain a level in `&%s%s to `#%s%s!",
					$c, $name, $c, $new, $c);
			$x = $new % 3;
			if ($x == 0){
				output("`n`^You gain an extra use point!`n");
				set_module_pref("uses", get_module_pref("uses") + 1);
			}else{
				if (3-$x == 1) {
					output("`n`^Only 1 more skill level until you gain an extra use point!`n");
				} else {
					output("`n`^Only %s more skill levels until you gain an extra use point!`n", (3-$x));
				}
			}
			output_notl("`0");
		}
		break;

	case "newday":
		$bonus = getsetting("specialtybonus", 1);
		if($session['user']['specialty'] == $spec) {
			if ($bonus == 1) {
				output("`n`2For being interested in %s%s`2, you receive `^1`2 extra `&%s%s`2 use for today.`n",$ccode,$name,$ccode,$name);
			} else {
				output("`n`2For being interested in %s%s`2, you receive `^%s`2 extra `&%s%s`2 uses for today.`n",$ccode,$name,$bonus,$ccode,$name);
			}
		}
		$amt = (int)(get_module_pref("skill") / 3);
		if ($session['user']['specialty'] == $spec) $amt++;
		set_module_pref("uses", $amt);
		break;

	case "pointsdesc":
		$cost = get_module_setting("cost");
		if ($cost > 0){
			$afis['count']++;
			$format = $afis['format'];
			$str = translate("The Rogue Specialty is availiable upon reaching %s Dragon Kills and %s points.");
			$str = sprintf($str, get_module_setting("mindk"),$cost);
		}
		output($format, $str, true);
		break;

	case "set-specialty":
		if($session['user']['specialty'] == $spec) {
			page_header($name);
			$session['user']['donationspent'] = $session['user']['donationspent'] + $cost;
			output("`2Whether driven by desperation, the desire for greed, or the desire to become infamous, ");
			output("You decided to spend your childhood days and nights studying the ways of the criminal underworld. ");
			output("It also could be that you had inordinate fascination with all things pretty and shiny. ");
			output("Maybe you were trying to cover up, and deal with some internal inadequacy or face some ");
			output("demon of your youth.  I never really thought about this before, but we could probably ");
			output("spend days psycho-analyzing why you decided to pursue a career in stealing things.`n`n");
			output("Then again, considering you're a trained rogue, maybe I'll just drop the subject ");
			output("and be on my merry way...`n`n");
		}
		break;

	case "specialtycolor":
		$afis[$spec] = $ccode;
		break;

	case "specialtymodules":
		$afis[$spec] = "specialtyrogue";
		break;

	case "specialtynames":
		$pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
		if ($session['user']['superuser'] & SU_EDIT_USERS || $session['user']['dragonkills'] >= get_module_setting("mindk") || get_module_setting("cost") <= $pointsavailable){
			$afis[$spec] = translate_inline($name);
		}
		break;
	}
	return $afis;
}

function specialtyrogue_run(){
}
?>