<?php
/*Die newprivacy.php wurde 2018 f�r Die Legende von An Daingean (www.andaingean.de) von Hades erstellt, dem hier amtierenden Admin (hades-at-andaingean.de).
Sie ist die sichtbarste Anpassung des LogD an die neue EU-Datenschutz-Grundverordnung (DSGVO), bedarf aber eines Einbaus.
Wenn du sie nutzen willst, f�hle dich frei, das zu tun (Komplett-Anleitung s.u.), einschlie�lich Anpassungen und �nderungen. In dem Fall belasse aber bitte diese drei Autoren-Zeilen drin. 
Die Anleitung kannst du gern l�schen, du musst sie aber anderen zug�nglich machen, wenn jemand die Datei und die �nderungen einbauen will.*/

/*Einbau, was zu tun ist:
1. Verfasse eine Datenschutzrichtlinie f�r dein LogD. Es gibt Generatoren im Netz, die dir dabei helfen. Unsere, teils hosterspezifische, kannst du hier nachlesen:
https://www.andaingean.de/petition.php?op=privacy&c=187-133534
Suche in der petition.php die Zeite "}else if($_GET['op']=="faq1"){" (die "" sind nat�rlich jeweils wegzulassen).
F�ge davor:
"}else if($_GET['op']=="privacy"){
popup_header("Der Datenschutz in XXX");
output("<a href='petition.php?op=faq'>Inhaltsverzeichnis</a>`n
<a href='petition.php?op=rules1'>Nutzungsbedingungen</a>`n`n
ZZZ",true);}"
ein, ersetze XXX durch deinen Spielnahmen, ZZZ durch deinen Datenschutztext.

2. Verlinke die Richtlinie auf der Startseite (�blicherweise index.php: "addnav("D?Unser Datenschutz","petition.php?op=privacy",false,true);" - Unter FAQ & Co.).

3. Lege in deiner Datenbank eine weitere Spalte an: `DSGVO` int(11) NOT NULL DEFAULT '0' (in accounts, chardata, account_extra_info oder wo es dir passt - bei uns in den
"accounts", weil das im Zweifelsfall ohne gro�e Erkl�rung erkl�rbar ist).
* Das ist die Zustimmungsspalte, entsprechend ist der Standartwert 0, also keine Zustimmung. Die muss sich jeder Account erst noch holen. Und das geht so:

4. �ffne die create.php. Unter "Charakter erstellen" (... "
 output("`&`cCharakter erstellen`b`c`n");
	output("`0<form action=\"create.php?op=create".($_GET['r']>""?"&r=".$_GET['r']:"")."\" method='POST'>",true);
    output("`n<table style='border:none;'><tr><td>Wie willst Du in dieser Welt hei�en?</td><td><input name='name'></td></tr>",true);"
gibt es (bei uns) ein K�stchen, mit dem man den Nutzungsbestimmungen zustimmen kann (und muss, will man einen Account anlegen).
Suche die Zeilen "output("<input type='submit' class='button' value='Charakter erstellen' id='send' style='color:#555555;background:#222222;border:1px solid #111111;' disabled>",true);
output('<input type="checkbox" onClick="var x=document.getElementById(\'send\');if(x.disabled){x.style.color=\'#CCCC00\';x.style.background=\'#422B00\';x.style.border=\'1px solid #947356\';x.disabled=false;}else{x.style.color=\'#555555\';x.style.background=\'#222222\';x.style.border=\'1px solid #111111\';x.disabled=true;}">
<a href="petition.php?op=privacy" target="_blank">Ja, ich habe die Nutzungsbedingungen und Datenschutzregeln gelesen und stimme ihnen und der Nutzung meiner Daten in diesem Rahmen zu.</a></form>',true);"

(die Farbwerte (color=\#555555...) werden bei euch anders aussehen). �blicherweise sind die Nutzungsbedingen verlinkt ("petition.php?op=rules1"), stelle die auf das Wichtigste 
um, die Datenschutzregeln n�mlich (die jetzt "privacy" hei�en, vgl. Zeile 12 in der Erkl�rung hier). �ndere den "Ja, ich habe..."-Text in "Ja, ich habe die 
Nutzungsbedingungen und Datenschutzregeln gelesen und stimme ihnen und der Nutzung meiner Daten in diesem Rahmen zu."
Verlinke den "privacy"-Eintrag auch andernorts in der petition.php:
-> <a href='petition.php?op=privacy'>Der DATENSCHUTZ in XXX</a>`n hinter "<a href='petition.php?op=rules1'>Nutzungsbedingungen</a>`n", zu finden irgendwo hinter "if ($_GET['op']=="faq"){").
--> XXX wieder durch deinen Spielnamen ersetzen

5. �ffne die newday.php. Suche die Zeile "if(isset($_POST['untouched'])){".
F�ge danach "$session['user']['DSGVO'] = 1;" ein.
Damit stellst du den DSGVO-Eintrag in der DB f�r neue Accounts auf Ja bzw. 1 - der DB-Eintrag f�r "Ja, ich habe die Datenschutzregeln gelesen und stimme ihnen zu."

Was ist mit den bereits bestehenden Accounts? Die Nutzer/-innen m�ssen auch noch zustimmen. Wir fahren fort:
6. Nimm die newprivacy.php, passe Text und Farbe an dein Spiel an und lege sie in deinem Hauptverzeichnis/ Wurzelverzeichnis (da, wo alle Daten, das Favicon, die village.php liegen) auf dem Server ab.
Jetzt wird sie verlinkt:
7. �ffne die village.php (oder die Orts-Datei, die man bei dir im Spiel als erstes erreicht; die Beschreibung bezieht sich auf die village.php, du musst ggf. etwas anpassen).
Suche die erste Zeile mit Umleitungen ("if ($session['user']['alive']){ }else{
        redirect("shades.php");
		}" -> ziemlich weit oben). F�ge davor ein:
if($_GET[op]=='DSGVO'){
   $session['user']['DSGVO'] = 1;
  }
  
if (($session['user']['DSGVO'])<1)
        redirect("newprivacy.php");
Das erste "if" fragt ab, ob die Nutzerin �ber die newprivacy.php hergekommen ist (also zugestimmt hat, vgl. "addnav("`RDen Datenschutzregeln zustimmen`0","village.php?op=DSGVO");" in dieser Datei),
und setzt in dem Fall den Wert in der DB auf 1, also ja, hat zugestimmt.
Das zweite "if" fragt, ob der Nutzer bereits zugestimmt hat. Wenn nicht, wird er zwingend auf die newprivacy.php umgeleitet.*/

require_once "common.php";
page_header("Neue Nutzungsbedigungen");


addnav("Was tun?");
addnav("Unsere neuen Datenschutzregeln - LESEN!","petition.php?op=privacy",false,true); //�ffnet ein pop-up, damit man die Seite nicht verl�sst
addnav("Den Datenschutzregeln zustimmen","village.php?op=DSGVO");
addnav ("Zum Profil","prefs.php");
addnav("Logout","login.php?op=logout",true);
if($session[user][bib]>0 && $session[user][DSGVO]>0 || $session[user][superuser]>=2 && $session[user][DSGVO]>0) addnav("Club der toten Bibliothekare","club.php"); //wichtig, einen Link f�r Mods, Admins... zu haben, von wo aus sie zur�ckkommen, wenn sie


output("`n`b`cNeue Nutzungsbedingungen erfordern deine Zustimmung!`b`c`n");
output("`n`nWas ist geschehen? Die DSGVO ist in Kraft getreten!`n`n
Liebe Spielerin, lieber Spieler.`n
Entschuldige die kurze Unterbrechung, aber da m�ssen wir jetzt beide durch.`n
Laut nun g�ltiger Datenschutz-Grundverordnung (DSGVO) sind online-Angebote gehalten (gezwungen), etwas �ber ihre Datenverarbeitung zu schreiben.`n
Nun, `@An Daingean`O `iist`i ein online-Angebot und nun haben wir auch einen Datenschutzpassus (links in den Links), der Inhalt der Nutzungsbedingungen wurde. Daf�r 
brauchen wir deine Zustimmung.`n
Ganz praktisch �ndert sich f�r dich nichts, was da niedergeschrieben steht, war schon immer unsere Praxis (wir speichern deine E-Mail-Adresse, wir erhalten vom Hoster 
deine genutzte IP-Adresse, die nach 7 Tagen wieder gel�scht wird, wir binden kein Facebook, keine Google Fonts, kein Google Analytics ein... u.s.w.).`n
Dennoch geben wir dir, gesetzeskonform, die M�glichkeit, auf diese Neuerung zu reagieren:`n`n
Du kannst den neuen Datenschutzregeln zustimmen. Dann kommst du zur�ck zum Dorfplatz und alles ist, wie es zuvor war.`n
Du kannst von hier aus das Profil erreichen und die E-Mail-Adresse in eine �ndern, von der es nicht schlimm ist, wenn Fremde (wie wir) sie haben.`n
Du kannst uns auch Fragen zur neuen Datenschutzregel stellen, gleich hier unten im Chatbereich, und noch einmal �ber deine Zustimmung nachdenken. Das Team schaut 
t�glich mehrfach hier vorbei, um m�gliche Fragen zu beantworten. Wenn du dich dann wieder einloggst, kommst du hier her zur�ck.`n
Du kannst unsere neu niedergeschriebenen Datenschutzregeln auch doof finden. Dann musst du uns die Genehmigung entziehen, diese Daten zu speichern und abzufragen. 
Das bedeutet, weil zu diesen Daten auch deine E-Mail-Adresse geh�rt, dass du deinen Account l�schen musst. Auch daf�r nutze bitte den Link zum Profil.`n`n
Wir danken f�r deine Aufmerksamkeit. Keine Sorge, diese Seite bekommst du nur einmal (naja, pro Account).`n
Und nun viel Spa� beim Spiel!
`n");
//Kommentare erlauben
addcommentary();
viewcommentary("DSGVO","",45);
//Kommentare erlauben Ende
page_footer();
?>
