<?php
$setindex = 1;
$setname = "Set 1";
$setcopy = "&copy; 2004-2005 <a href='http://www.michelledockrey.com'>Michelle Dockrey</a>"
?>
