Specify  the folder you want the PHP files to be stored in the docker-compose (Default is the existing lotgd folder)

run docker-compuse up -d

Access at localhost:4040 (or whatever port you specified)

The default login for the game is 

Username: admin
Password: lotgdadmin