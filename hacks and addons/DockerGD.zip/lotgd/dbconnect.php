<?php
//This file automatically created by installer.php on Aug 13, 2020 03:53 am
$DB_HOST = 'lotgd-db';
$DB_USER = 'root';
$DB_PASS = 'lotgd';
$DB_NAME = 'lotgd';
$DB_PREFIX = '';
$DB_USEDATACACHE = 0;
$DB_DATACACHEPATH = '';
?>
